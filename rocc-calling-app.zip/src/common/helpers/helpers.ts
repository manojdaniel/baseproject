/*
 * Created on Fri Sept 03 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { ECallStatus, EClinicalRole, EConnectionMode, EConnectionState, EConnectionType, ERbacRole, EROCC_CONTEXT, FeatureFlagHelper, getLocationDetailsForId, getRoomDetailFromUuid, IAppReducer, IAVCallDetails, ICallDetails, ICallStatus, IConsoleSession, IContactInfo, ICustomerReducer, IIncomingCallDetails, IModalReducer, IParticipantInfo, IUserReducer, parseIntBase10, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import { Dispatch } from "redux"
import { APP_REDUCER, CALL_FAILED, CALL_MESSAGES, CONFIG_REDUCER, CONSOLE_REDUCER, CONSOLE_STORE, CUSTOMER_REDUCER, DEVICE, DEVICE_ROLE_ROOM, MODAL_REDUCER, PARENT_STORE, USER_REDUCER } from "../../constants/constants"
import { GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import { IWorkflowInfo } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalConfigs, fetchGlobalLocations, fetchGlobalURLs, getGlobalStoreDetails } from "../../redux/store/externalAppStates"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"
import { ESidePanelTabs } from "../../types/types"
import { onCallAcceptWithHoldWarning, onCallReject } from "../modules/avmessages/av-messages/MessageHelper"

const FUNCTION = "function"
export const getCurrentUserAndUrlsReduxState = () => {
    const { currentUser } = getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: USER_REDUCER })
    const urls = fetchGlobalURLs()

    return { currentUser, urls }
}

export const isAdmin = () => {
    const { currentUser } = getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: USER_REDUCER })
    return currentUser.clinicalRole === EClinicalRole.ADMIN
}

export const getActiveStyles = (activeItem: ESidePanelTabs, panelItem: ESidePanelTabs) => {
    return activeItem === panelItem ? "active" : "inactive"
}

export const getUserReducerFromGlobalStore = (): IUserReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: USER_REDUCER })
}

export const getCustomrReducerFromGlobalStore = (): ICustomerReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: CUSTOMER_REDUCER })
}

export const getAppReducerFromGlobalStore = (): IAppReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: APP_REDUCER })
}

export const getConfigReducerFromGlobalStore = () => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: CONFIG_REDUCER })
}

export const getModalReducerFromGlobalStore = (): IModalReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: MODAL_REDUCER })
}

export const getStateValueDependency = (workflows: IWorkflowInfo[]) => JSON.stringify(
    workflows.map(
        (workflow: IWorkflowInfo) => workflow.state.value
    )
)

export const sortContacts = (contacts: IContactInfo[]) => {
    const { AVAILABLE, BUSY, IN_CALL, DND, OFFWORK, AWAY, OFFLINE } = EUserPresence
    const order = [
        AVAILABLE, BUSY, IN_CALL,
        DND, OFFWORK, AWAY, OFFLINE,
    ]
    contacts.sort((a: IContactInfo, b: IContactInfo) => a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1)
    return contacts.sort((a: IContactInfo, b: IContactInfo) =>
        order.indexOf(a.status) > order.indexOf(b.status) ? 1 :
            order.indexOf(a.status) === order.indexOf(b.status) ? 1 : -1)
}

export const checkIfParticipantIsGuest = (participant: IParticipantInfo) => {
    return participant && participant.clinicalRole === EClinicalRole.DEVICE && participant.secondaryName === ""
}

export const generateInitials = (displayName: string) => {
    const secondLetter: string = (displayName && displayName.includes(" ")) ? displayName.split(" ")[1].charAt(0) : ""
    const userInitials = (displayName && displayName.length > 0) ? (displayName.charAt(0) + secondLetter) : ""
    return userInitials.toUpperCase()
}

export const convertContactToDisplayList = (contact: IContactInfo, getUserAction: (props?: any) => JSX.Element[]) => {
    const { id, status, secondaryUUID, uuid, name, description, siteId, clinicalRole, secondaryName, loggedInLocation } = contact
    const { intl } = getIntlProvider()
    const guest = intl.formatMessage({ id: "content.room.guest", defaultMessage: en["content.room.guest"] })
    const isGuest = (clinicalRole === DEVICE && secondaryUUID === "")
    return {
        id: id,
        uuid: secondaryUUID || uuid,
        title: isGuest ? guest : (secondaryName !== "" ? secondaryName : name),
        metaData: secondaryUUID !== "" ? getRoleName(TECHNOLOGIST) : getRoleName(clinicalRole),
        description: clinicalRole === DEVICE ? `${name} ${renderHTMLCd('&#8226;')} ` + getSiteName(description, siteId) : (loggedInLocation || ""),
        presence: status,
        userActions: getUserAction(),
    }
}

export const getAnywhereLocationNameText = () => {
    const { intl } = getIntlProvider()
    return intl.formatMessage({ id: "content.locations.anywhere", defaultMessage: en["content.locations.anywhere"] })
}
export const fetchDisplayableContact = (contact: IContactInfo) => {
    const { id, secondaryUUID, uuid, name, description, clinicalRole, siteId, secondaryName } = contact
    const isGuest = (clinicalRole === DEVICE && secondaryUUID === "")
    return {
        id, uuid: secondaryUUID || uuid, title: secondaryName || name,
        metaData: secondaryUUID !== "" ? getRoleName(TECHNOLOGIST) : getRoleName(clinicalRole),
        description: isGuest ? getSiteName(description, siteId) : `${name} ${renderHTMLCd('&#8226;')} ${getSiteName(description, siteId)}`
    }
}

export const fetchConsoleReducer = () => getGlobalStoreDetails({ storeName: CONSOLE_STORE, reducerPath: CONSOLE_REDUCER })

/* REVIEW: Check if this method or its usages need to be modified */
export const checkForSeamlessEditFromConsoleApp = () => {
    const consoleReducer = fetchConsoleReducer()
    const response = { isActiveEditSession: false, isActiveEmeraldSession: false }
    if (consoleReducer) {
        const { consoleSessions } = consoleReducer
        const editSessions: IConsoleSession[] = consoleSessions.filter((session: IConsoleSession) => session.connectionType === EConnectionType.FULL_CONTROL)
        if (editSessions.length) {
            response.isActiveEditSession = true
            response.isActiveEmeraldSession = !!editSessions.find(session => session.connectionMode === EConnectionMode.EMERALD)
        }
    }
    return response
}

export const fetchActiveEditSession = () => {
    const consoleReducer = fetchConsoleReducer()
    const connectedCallDetailsContextId = store.getState().callReducer.callDetails.connectedCallDetails.contextId
    return consoleReducer?.consoleSessions.find((session: IConsoleSession) => session.connectionType === EConnectionType.FULL_CONTROL && session?.additionalData?.callContextId === connectedCallDetailsContextId)
}

export const checkIfConsoleAvailable = (callContextId: string) => {
    const consoleReducer = fetchConsoleReducer()
    return consoleReducer?.consoleSessions.find((session: IConsoleSession) =>
        [EConnectionState.PARKED, EConnectionState.CONNECTED].includes(session.connectionStatus) && session?.additionalData?.callContextId === callContextId)
}

export const checkIfMultiEditWithoutParkResumeFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME)
}

export const checkIfMultiEditWithParkResumeFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITH_PARK_AND_RESUME)
}

/* NOTE: Seamless edit is responsible for multi-edit and park-resume (seamless edit) */
export const checkIfSeamlessEditFeatureExist = () => {
    return (checkIfMultiEditWithoutParkResumeFeatureEnabled() || checkIfMultiEditWithParkResumeFeatureEnabled())
        && !checkForSeamlessEditFromConsoleApp().isActiveEmeraldSession
}

export const checkToAllowParkResume = () => {
    const state = store.getState()
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    const { isActiveEditSession, isActiveEmeraldSession } = checkForSeamlessEditFromConsoleApp()
    return checkIfMultiEditWithParkResumeFeatureEnabled() && (connectedCallDetails.contextId || onHoldCallDetails.length) && isActiveEditSession && !isActiveEmeraldSession
}

export const checkToAllowMultiEdit = () => {
    const state = store.getState()
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    return checkIfMultiEditWithoutParkResumeFeatureEnabled() && (connectedCallDetails.contextId || onHoldCallDetails.length) && !checkForSeamlessEditFromConsoleApp().isActiveEmeraldSession
}

export const checkIfMultiAudioEnabled = (featureFlags: any) => {
    return FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_MULTI_AUDIO, false)
        || FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME, false)
}

export const checkIfCallGoingOn = (videoCallStatus: ICallStatus[], phoneCallStatus: ECallStatus) => {
    const { CALLING, CONNECTED, CONNECTING, RINGING, PAUSED } = ECallStatus
    return videoCallStatus.some((videoCall) => [CALLING, CONNECTING, CONNECTED, RINGING, PAUSED].includes(videoCall.callStatus))
        || phoneCallStatus.includes(CALLING)
}

export const getCallsWithParticipant = (participantUuid: string, avCallDetails: IAVCallDetails[]) => {
    const participants: IParticipantInfo[] = []
    avCallDetails.forEach(call => participants.push(...call.participants))
    return participants.some(participant => [participant.uuid, participant.secondaryUUID].includes(participantUuid))
}

export const checkIfActiveConnectedCall = (contextId: string) => {
    const { connectedCallDetails } = store.getState().callReducer.callDetails
    return connectedCallDetails.contextId === contextId
}

export const checkIfCallGoingOnForContext = (contextId: string) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().callReducer.callDetails
    return !![...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
}

const { FRONTDESK, SCHEDULER, EXPERTUSER, TECHNOLOGIST, ADMIN } = EClinicalRole

export const getRoleName = (role: string | EClinicalRole | ERbacRole) => {
    const { intl } = getIntlProvider()
    switch (role) {
        case ERbacRole.EXPERTUSER_ROLE:
        case EXPERTUSER:
            return intl.formatMessage({ id: "content.roles.expertUser", defaultMessage: en["content.roles.expertUser"] })
        case ADMIN:
            return intl.formatMessage({ id: "content.roles.Admin", defaultMessage: en["content.roles.Admin"] })
        case TECHNOLOGIST:
            return intl.formatMessage({ id: "content.roles.technologist", defaultMessage: en["content.roles.technologist"] })
        case DEVICE_ROLE_ROOM:
            return intl.formatMessage({ id: "content.roles.room", defaultMessage: en["content.roles.room"] })
        case FRONTDESK:
            return intl.formatMessage({ id: "content.roles.frontdesk", defaultMessage: en["content.roles.frontdesk"] })
        case SCHEDULER:
            return intl.formatMessage({ id: "content.roles.scheduler", defaultMessage: en["content.roles.scheduler"] })
        case ERbacRole.PROTOCOL_MANAGER_ROLE:
            return intl.formatMessage({ id: "content.roles.protocolManager", defaultMessage: en["content.roles.protocolManager"] })
        case ERbacRole.EXPERTUSER_WITH_INCOGNITO_ROLE:
            return intl.formatMessage({ id: "content.roles.euIncognito", defaultMessage: en["content.roles.euIncognito"] })
        case DEVICE:
            return intl.formatMessage({ id: "content.roles.Device", defaultMessage: en["content.roles.Device"] })
        default:
            return role
    }
}

export const getSiteName = (description: string, siteId: string[]) => {
    let siteName = description
    if (siteName === "") {
        const locationList = fetchGlobalLocations()
        for (const site of siteId) {
            const name = getLocationDetailsForId(locationList, parseIntBase10(site)).name
            if (name) {
                siteName = name
                break
            }
        }
    }
    return siteName
}

export const prepareIncomingCallModal = (incomingCall: IIncomingCallDetails, deviceType: EROCC_CONTEXT, setShowIncomingModal: any, dispatch: Dispatch<any>) => {
    const { participant, contextId } = incomingCall
    const { name, secondaryName, clinicalRole, siteId, description, uuid, loggedInLocation } = participant
    const header = secondaryName ? `${secondaryName} - ${name}` : name
    const subHeader = secondaryName ? getRoleName(EClinicalRole.TECHNOLOGIST) : getRoleName(clinicalRole)
    const descriptionValue = (clinicalRole == DEVICE) ? getSiteName(description, siteId) : (loggedInLocation || "")
    const startCall = () => {
        setShowIncomingModal(false)
        onCallAcceptWithHoldWarning({ contextId, dispatch, contactUuid: uuid })
    }
    const endCall = () => {
        setShowIncomingModal(false)
        onCallReject({ contextId, setState: true, dispatch })
    }
    return { header, subHeader, description: descriptionValue, deviceType, startCall, endCall }
}

export const isRenderableComponent = (component: any) => {
    return isFunctionComponent(component) || isClassComponent(component) || isElement(component)
}

export const isElement = (element: any) => {
    return React.isValidElement(element)
}

export const isFunctionComponent = (component: any) => {
    return typeof component === FUNCTION
        && React.isValidElement(component)
}

export const isClassComponent = (component: any) => {
    return typeof component === FUNCTION
        && !!component.prototype.isReactComponent
}

export const isDev = () => {
    const configs = fetchGlobalConfigs()
    return configs.ROCC_DEV === "true"
}

export const renderHTMLCd = (str: string) => {
    return str.replace(/(&#(\d+);)/g, function (match, capture, charCode) {
        return String.fromCharCode(charCode)
    })
}

export const getTranslatedCallType = (callMessage: string) => {
    const { intl } = getIntlProvider()
    switch (callMessage) {
        case CALL_MESSAGES.CALLMISSED:
            return intl.formatMessage({ id: "content.callMessage.callMissed", defaultMessage: en["content.callMessage.callMissed"] })
        case CALL_MESSAGES.CALLDECLINED:
        case CALL_MESSAGES.CALL_REJECTED:
            return intl.formatMessage({ id: "content.callMessage.callDeclined", defaultMessage: en["content.callMessage.callDeclined"] })
        case CALL_MESSAGES.CALLUNANSWERED:
            return intl.formatMessage({ id: "content.callMessage.callUnanswered", defaultMessage: en["content.callMessage.callUnanswered"] })
        case CALL_MESSAGES.CALL_FAILED:
        case CALL_FAILED:
            return intl.formatMessage({ id: "content.callMessage.callFailed", defaultMessage: en["content.callMessage.callFailed"] })
        case CALL_MESSAGES.CALL_CANCELLED:
            return intl.formatMessage({ id: "content.callMessage.callCancelled", defaultMessage: en["content.callMessage.callCancelled"] })
        default:
            return callMessage
    }
}

export const updateCallMuteStatus = (contextId: string, isMuted: boolean, callDetails: ICallDetails) => {
    const { connectedCallDetails, onHoldCallDetails } = callDetails
    if (connectedCallDetails.contextId === contextId) {
        connectedCallDetails.isMuted = isMuted
    }
    const newOnHoldCallDetails = onHoldCallDetails.map((call: IAVCallDetails) => call.contextId === contextId ? { ...call, isMuted } : { ...call })
    return { onHoldCallDetails: newOnHoldCallDetails, connectedCallDetails: { ...connectedCallDetails } }
}

export const updateCallDeafenStatus = (contextId: string, isDeafened: boolean, callDetails: ICallDetails) => {
    const { connectedCallDetails, onHoldCallDetails } = callDetails
    if (connectedCallDetails.contextId === contextId) {
        connectedCallDetails.isDeafened = isDeafened
    }
    const newOnHoldCallDetails = onHoldCallDetails.map((call: IAVCallDetails) => call.contextId === contextId ? { ...call, isDeafened } : call)
    return { onHoldCallDetails: newOnHoldCallDetails, connectedCallDetails: { ...connectedCallDetails } }
}

export const hideNotificationModal = () => {
    const notificationModal = { showModal: false }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

export const fetchEditConnectionRoomDetails = (activeEditSession: any) => {
    const { rooms, locations } = getCustomrReducerFromGlobalStore()
    const activeSession = activeEditSession
    const { roomUuid } = activeSession
    const roomDetails = getRoomDetailFromUuid(rooms, roomUuid)
    const locationDetails = getLocationDetailsForId(locations, roomDetails.locationId)
    return { activeSession, roomDetails, locationDetails }
}

export const checkToDaemonizeCall = (nextSessionDetails: any) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().callReducer.callDetails
    return (
        (nextSessionDetails?.callContextId && !checkIfCallGoingOnForContext(nextSessionDetails.callContextId))
        || (nextSessionDetails?.contactUuid && !getCallsWithParticipant(nextSessionDetails.contactUuid, [...onHoldCallDetails, connectedCallDetails]))
    )
}
