"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest.mock import Mock, patch

from src.exceptions.RoccException import RoccException
from src.modules.db_operations.insertion_services.user_db_services import compute_user_roles, update_user_status_in_dict, fetch_email_id_from_employee_id, extract_employee_info_from_db, fetch_userlist, prepare_invitation_mail_object, check_if_new_user
from src.constants.enums import EDBRoles
from src.constants.constants import IS_SUCCESSFULL, IS_NEW, ROCC_USERS


class UserRoleTest(unittest.TestCase):
    def setUp(self):
        self.unique_id = "uniqueID"
        self.user = {
            "Role": "Expert User,Technologist,Admin",
            "Additional functionality for Expert user": "Protocol Manager,Incognito"
        }
        self.emp_dict = {
            self.unique_id: {
                "employee_id": "1",
                "Location Name (Multiple Location is allowed)": "NA",
                "Last Name": "Pendragon",
                "Email ID /Unique ID": self.unique_id,
                "Multiple Scanner/Rooms Technologist Belongs To( To be filled by Philips)": "SHSN001MR01",
                "Role": "Expert User,Technologist,Admin",
                "Hospital or DIC": "NA",
                "First Name": "Morgana",
                "Room or Device Name": "NA",
                "IDN (Multi-hospital system name)": "Silver Health Systems",
                "Modality (CT or MR)": "CT,MR",
                "Multiple Hospital/DIC Identifier Employee Belongs To( To be filled by Philips)": "SHSN001,SHSW001",
                "Additional functionality for Expert user": "Protocol Manager,Incognito",
                "Phone Number (with Country code)": "+1 4252432321",
                "isNew": True
            }
        }

    def test_compute_user_roles(self):
        roles = compute_user_roles(self.emp_dict[self.unique_id])
        self.assertListEqual([EDBRoles.EXPERTUSERROLE, EDBRoles.PROTOCOLMANAGERROLE, EDBRoles.INCOGNITOROLE, EDBRoles.TECHNOLOGISTROLE, EDBRoles.ADMINROLE], roles)

    def test_update_user_status_in_dict(self):
        emp_dict = update_user_status_in_dict(self.emp_dict, self.unique_id, is_successful=True, employee_id=1)
        self.assertEqual(emp_dict[self.unique_id][IS_SUCCESSFULL], True)
        self.assertEqual(emp_dict[self.unique_id]["employee_id"], 1)

    def test_fetch_email_id_from_employee_id_success(self):
        response = fetch_email_id_from_employee_id(emp_dict=self.emp_dict, employee_id="1")
        self.assertEqual(response, self.unique_id)

    def test_fetch_email_id_from_employee_id_false(self):
        response = fetch_email_id_from_employee_id(emp_dict=self.emp_dict, employee_id="2")
        self.assertEqual(response, None)

    def test_extract_employee_info_from_db_success(self):
        user_input = {
            "roles": [],
            "sites": [],
            "modalities": [],
            "resources": ""
        }
        mock_client = Mock()
        mock_client.execute.return_value = {
            "rocc_rocc_application_roles": [{
                "application_role_id": 1
            }],
            "rocc_sites": [],
            "rocc_modality_types": [],
            "rocc_scanner_resources": []
        }
        expected = {"roles": [1], "sites": [], "modalities": [], "resources": []}
        response = extract_employee_info_from_db(user=user_input, client=mock_client)
        self.assertEqual(response, expected)

    def test_extract_employee_info_from_db_failed(self):
        user_input = {
            "roles": [],
            "sites": [],
            "modalities": [],
            "resources": ""
        }
        mock_client = Mock()
        mock_client.execute.side_effect = Exception()

        self.assertRaises(RoccException, extract_employee_info_from_db, user_input, mock_client)

    @patch("src.modules.db_operations.insertion_services.user_db_services.extract_employee_info_from_db")
    def test_fetch_userlist(self, mock_extract_employee):
        mock_extract_employee.return_value = {"roles": [1], "sites": [], "modalities": [], "resources": []}
        response = fetch_userlist(emp_dict=self.emp_dict, org_db_id=1, client="")
        expected = [{
            "metasiteId": 1,
            "firstName": "Morgana",
            "lastName": "Pendragon",
            "phoneNumber": "+1 4252432321",
            "uniqueId": self.unique_id.lower(),
            "emailId": self.unique_id.lower(),
            "clinicalRoles": [1],
            "sites":[],
            "modalities": [],
            "resources": [],
        }]
        self.assertEqual(response, expected)

    @patch("src.modules.db_operations.insertion_services.user_db_services.update_summary_for_entity")
    def test_check_if_new_user_false(self, mock_update_summary_for_entity):
        mock_update_summary_for_entity.return_value = "entity"
        mock_client = Mock()
        mock_client.execute.return_value = {ROCC_USERS: [{
            "id": 1,
            "unique_identity": self.unique_id
        }
        ]}
        resp1, resp2 = check_if_new_user(emp_dict=self.emp_dict, client=mock_client, transaction_data="")
        self.assertEqual(resp1[self.unique_id][IS_NEW], False)
        self.assertEqual(resp2, "entity")

    @patch("src.modules.db_operations.insertion_services.user_db_services.update_summary_for_entity")
    def test_check_if_new_user_true(self, mock_update_summary_for_entity):
        mock_update_summary_for_entity.return_value = "entity"
        mock_client = Mock()
        mock_client.execute.return_value = {ROCC_USERS: [{
            "id": 1,
            "unique_identity": "sda"
        }
        ]}
        resp1, resp2 = check_if_new_user(emp_dict=self.emp_dict, client=mock_client, transaction_data="")

        self.assertEqual(resp1[self.unique_id][IS_NEW], True)
        self.assertEqual(resp2, "entity")

    @patch("src.modules.db_operations.insertion_services.user_db_services.update_summary_for_entity")
    def test_check_if_new_user_on_exception(self, mock_update_summary_for_entity):
        mock_update_summary_for_entity.return_value = "entity"
        mock_client = Mock()
        mock_client.execute.side_effect = Exception()
        self.assertRaises(Exception, check_if_new_user, self.emp_dict, mock_client, "")

    def test_prepare_invitation_mail_object(self):
        response = prepare_invitation_mail_object(successfully_added_list=[self.unique_id], emp_dict=self.emp_dict)
        expected = [{
            "userId": "1",
            "action": "Invite"
        }]
        self.assertEqual(response, expected)


suite = unittest.TestSuite()
suite.addTest(UserRoleTest("test_compute_user_roles"))
suite.addTest(UserRoleTest("test_update_user_status_in_dict"))
suite.addTest(UserRoleTest("test_prepare_invitation_mail_object"))
