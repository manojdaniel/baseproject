/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import React, { useEffect } from "react"
import { useDispatch } from "react-redux"
import { INCOMING_CALL, CALL_ACCEPT, ADD_PARTICIPANT, CALL_REJECT, CALL_END, CALL_MISSED, ALREADY_ON_CALL } from "../../../../constants/constants"
import { setVideoCallStatus } from "../../../../redux/actions/callActions"
import CallRing from "./call-sound/CallRingHandler"
import { addParticipant } from "./event-handlers/AddParticipant"
import { alreadyOnCall } from "./event-handlers/AlreadyOnCall"
import { callAccepted } from "./event-handlers/CallAccepted"
import { callEnd } from "./event-handlers/CallEnd"
import { callMissed } from "./event-handlers/CallMissed"
import { callRejected } from "./event-handlers/CallRejected"
import { incomingCall } from "./event-handlers/IncomingCall"

interface MessageHandlerProps {
    eventType: string
    contextId: string
    participant: string
}

const MessageHandler = (props: MessageHandlerProps) => {

    const { eventType, contextId, participant } = props

    const dispatch = useDispatch()

    useEffect(() => {
        return (() => {
            dispatch(setVideoCallStatus([{ contextId: "", callStatus: ECallStatus.IDLE }]))
        })
    }, [])

    useEffect(() => {
        switch (eventType.toLowerCase()) {
            case INCOMING_CALL.toLowerCase():
                incomingCall({ contextId, dispatch })
                break
            case CALL_ACCEPT.toLowerCase():
                callAccepted({ contextId, dispatch })
                break
            case ADD_PARTICIPANT.toLowerCase():
                addParticipant({ contextId, participant, dispatch })
                break
            case CALL_REJECT.toLowerCase():
                callRejected({ contextId, dispatch })
                break
            case CALL_END.toLowerCase():
                callEnd({ contextId, dispatch })
                break
            case CALL_MISSED.toLowerCase():
                callMissed({ contextId, dispatch })
                break
            case ALREADY_ON_CALL.toLowerCase():
                alreadyOnCall({ contextId, participant, dispatch })
                break
            default:
        }
    }, [eventType, contextId])

    return <CallRing />
}

export default MessageHandler
