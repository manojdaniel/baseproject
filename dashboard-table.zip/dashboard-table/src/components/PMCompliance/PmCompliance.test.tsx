import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import Pmcompliance from "./Pmcompliance";

jest.mock("moment", () => ({
	__esModule: true,
	default: jest.fn(() => ({
		format: jest.fn(),
	})),
}));

jest.mock("antd", () => {
	const mockTable = jest.fn(() => null);
	return { Table: mockTable };
});

const data = [
	{
		assetTag: "A001",
		assetSapNumber: "1001",
		workOrder: "WO001",
		plannedDate: "2023-05-10",
		completionDate: "2023-05-11",
		compliance: "Completed",
	},
	// Add more sample data as needed
];

describe("Pmcompliance Component", () => {
	beforeEach(() => {
		jest.clearAllMocks();
	});

	//   test("renders table with correct data", () => {
	//     render(<Pmcompliance data={data} />);

	//     expect(screen.getByRole("table")).toBeInTheDocument();
	//   });

	//   test("displays correct column titles", () => {
	//     render(<Pmcompliance data={data} />);

	//     expect(screen.getByText("ASSET TAG")).toBeInTheDocument();
	//     expect(screen.getByText("ASSET SAP NUMBER")).toBeInTheDocument();
	//     expect(screen.getByText("WORK ORDER #")).toBeInTheDocument();
	//     expect(screen.getByText("PLANNED DATE")).toBeInTheDocument();
	//     expect(screen.getByText("COMPLETION DATE")).toBeInTheDocument();
	//     expect(screen.getByText("COMPLIANCE")).toBeInTheDocument();
	//   });

	//   test("displays paginated data correctly", () => {
	//     render(<Pmcompliance data={data} />);

	//     expect(screen.getByText("A001")).toBeInTheDocument();
	//     expect(screen.getByText("1001")).toBeInTheDocument();
	//     expect(screen.getByText("WO001")).toBeInTheDocument();
	//     expect(screen.getByText("")).toBeInTheDocument(); // Mocked date format
	//     expect(screen.getByText("")).toBeInTheDocument(); // Mocked date format
	//     expect(screen.getByText("Completed")).toBeInTheDocument();
	//   });

	//   test("updates current page on pagination change", () => {
	//     render(<Pmcompliance data={data} />);

	//     // Simulate pagination change
	//     // Assuming there are 10 items per page and we want to move to page 2
	//     const nextPageButton = screen.getByText("2");
	//     nextPageButton.click();

	//     // Assert that the current page is updated
	//     expect(nextPageButton).toHaveClass("ant-pagination-item-active");
	//     expect(screen.getByText("A001")).toBeInTheDocument(); // Assuming item A001 is on page 2
	//   });

	test("mocks the Table component import", () => {
		render(<Pmcompliance data={data} />);

		expect(jest.requireMock("antd").Table).toHaveBeenCalled();
	});

	test("renders without error when data is empty", () => {
		const emptyData = [];
		render(<Pmcompliance data={emptyData} />);
		expect(screen.queryByRole("table")).toBeNull();
	});
});
