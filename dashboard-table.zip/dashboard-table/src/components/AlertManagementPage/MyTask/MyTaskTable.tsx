import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../../assets/common/CommonTables.scss";
import moment from "moment";
import { getDateTimeFormatted } from "../../../utility/helper";
interface Props {
	data: any[];
	onClickWorkFlowPage: any;
	loading: any
}
const MyTaskTable = ({ data, onClickWorkFlowPage, loading }: Props) => {
	// Time Formate work :Start
	const [mytask, setMytask] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);

		let mydata = data.map(function (item: any) {
			return {
				AlertID: item.alertId,
				Affiliate: item.affiliate,
				Plant: item.plant,
				AssetID: item.assetId,
				AssetName: item.assetName,
				AnomolyType: item.anomalyType,
				LongLeadAction: item.longLeadAction,
				AssignedTo: item.assignedTo,
				timeStamp: getDateTimeFormatted(item.timeStamp),
				Open: (
					<div
						className="cus-button"
						onClick={() => onClickWorkFlowPage(item.alertId, item.currentStage)}
					>
						Open
					</div>
				),
			};
		});
		setMytask(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "ALERT ID",
			dataIndex: "AlertID",
			key: "AlertID",
			width: "10%",
		},
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: "10%",
		},
		{
			title: "PLANT",
			dataIndex: "Plant",
			key: "Plant",
			width: "10%",
		},
		{
			title: "ASSET ID ",
			dataIndex: "AssetID",
			key: "AssetID",
			width: "10%",
		},
		{
			title: "ASSET NAME ",
			dataIndex: "AssetName",
			key: "AssetName",
			width: "10%",
		},
		{
			title: "ANIMALY TYPE",
			dataIndex: "AnomolyType",
			key: "AnomolyType",
			width: "10%",
		},
		{
			title: "LONG LEAD ACTION",
			dataIndex: "LongLeadAction",
			key: "LongLeadAction",
			width: "10%",
		},
		{
			title: "ASSIGNED TO",
			dataIndex: "AssignedTo",
			key: "AssignedTo",
			width: "10%",
		},
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: "10%",
		},
		{
			title: "Action",
			dataIndex: "Open",
			key: "Open",
			width: "10%",
		},
	];

	const mobileColumns = [
		{
			title: "ALERT ID",
			dataIndex: "AlertID",
			key: "AlertID",
			width: 80,
		},
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: 100,
		},
		{
			title: "PLANT",
			dataIndex: "Plant",
			key: "Plant",
			width: 100,
		},
		{
			title: "ASSET ID ",
			dataIndex: "AssetID",
			key: "AssetID",
			width: 70,
		},
		{
			title: "ASSET NAME ",
			dataIndex: "AssetName",
			key: "AssetName",
			width: 100,
		},
		{
			title: "ANOMALY TYPE",
			dataIndex: "AnomolyType",
			key: "AnomolyType",
			width: 100,
		},
		{
			title: "LONG LEAD ACTION",
			dataIndex: "LongLeadAction",
			key: "LongLeadAction",
			width: 50,
		},
		{
			title: "ASSIGNED TO",
			dataIndex: "AssignedTo",
			key: "AssignedTo",
			width: 100,
		},
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: 100,
		},
		{
			title: "Open",
			dataIndex: "Open",
			key: "Open",
			width: 100,
		},
	];
	return (
		<div>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Table
							loading={loading}
							columns={columns}
							dataSource={mytask}
							tableLayout="fixed"
							pagination={{ pageSize: 10, showSizeChanger: false }}
							scroll={{ y: "100%" }}
						/>
					);
				} else {
					return (
						<Table
							loading={loading}
							columns={mobileColumns}
							tableLayout={undefined}
							dataSource={mytask}
							pagination={{ pageSize: 10, showSizeChanger: false }}
							scroll={{ x: "900px" }}
						/>
					);
				}
			})()}
		</div>
	);
};

export default MyTaskTable;
