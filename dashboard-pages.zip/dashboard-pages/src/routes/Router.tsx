// @ts-nocheck
import React, { lazy } from "react";
import Home from "../pages/Home";
import Affiliates from "../pages/Affiliates";
import Plant from "../pages/Plant";
import Assets from "../pages/Assets";
import UserProfile from "../pages/UserProfile";
import { Routes, Route, Navigate } from "react-router-dom";
import {
    HOME_ROUTE, AFFILIATES_ROUTE, ASSETS_ROUTE, PLANT_ROUTE, All_PLANTS_ROUTE,
    PMT_ROUTE, USERPROFILE_ROUTE,
    ALERT_MANGAEMENT_ROUTE, ALERT_SATISTICS_ROUTE, MODEL_PERFORMANCE_ROUTE,
    PM_COMPLIANCE_ROUTE, ALERT_DASHBOARD_ROUTE, ALERT_LIST_ROUTE, PLANT_TIMELINE_ROUTE,
    PERFORMANCE_DASHBOARD_ROUTE, PLANT_MONTH_WISE_ROUTE,
    ASSET_MODEL_ROUTE, LIVE_TRACKING_ROUTE, ASSET_TIMELINE_ROUTE,
    ASSET_ALERT_LIST_ROUTE, PLOTS_ROUTE, REFERENCE_TABLE_ROUTE, SPARE_PARTS_ROUTE,
    AMP_HOME_ROUTE, AMP_MASTER_ROUTE, AMP_MYTASK_ROUTE, AMP_REPORTS_ROUTE,
    AMP_UTILIZATION_ROUTE, INFOPAGE, ADMIN_ROUTE, AFFILIATEROLLOUT_ROUTE, PLANTROLLOUT_ROUTE,
    USER_ROLL_MAPPING, ASSET_MODEL_CONFIG, EXCEPTION_MONITORING, SAP_ROUTE, SENSORGROUP_ROUTE,
    AMP_WORKFLOW_ROUTE, PREDICTION_CASE, AMP_NOTIFICATION_MYTASK_ROUTE, AMP_NOTIFICATION_WORKFLOW_ROUTE, LOGOUT_ROUTE
} from "../constant/constants"
import NotFound from "../pages/NotFound";
import Protected from "./Protected";
import { history } from "../utility/history";


const PmtDashboard = lazy(() => import("../pages/PlantPage/PmtDashboard"));
const AlertSatistics = lazy(() => import("../pages/PlantPage/AlertSatistics"));
const Alertdashboard = lazy(() => import("../pages/PlantPage/AlertSatistics/AlertDashboard"));
const AlertList = lazy(() => import("../pages/PlantPage/AlertSatistics/AlertList"));
const PlantTimeline = lazy(() => import("../pages/PlantPage/AlertSatistics/PlantTimeline"));
const AlertManagementPage = lazy(() => import("../pages/PlantPage/AlertManagementPage"));
const PmCompliance = lazy(() => import("../pages/PlantPage/PmCompliance"));
const ModelPerformance = lazy(() => import("../pages/PlantPage/ModelPerformance"));
const PerformanceDashboard = lazy(() => import("../pages/PlantPage/ModelPerformance/PerformanceDashboard"));
const PlantMonthWise = lazy(() => import("../pages/PlantPage/ModelPerformance/PlantMonthWise"));

const AssetModel = lazy(() => import("../pages/AssetsPage/AssetModel/AssetModel"));
const LiveTracking = lazy(() => import("../pages/AssetsPage/LiveTracking/LiveTracking"));
const AssetTimeLine = lazy(() => import("../pages/AssetsPage/AssetTimeLine/AssetTimeLine"));
const AssetAlertList = lazy(() => import("../pages/AssetsPage/AlertList/AlertList"));
const Plot = lazy(() => import("../pages/AssetsPage/Plot/Plot"));
const ReferenceTable = lazy(() => import("../pages/AssetsPage/ReferenceTable/ReferenceTable"));
const SpareParts = lazy(() => import("../pages/AssetsPage/SpareParts/SpareParts"));
const PredictionCase = lazy(() => import("../pages/AssetsPage/PredictionCase/PredictionCase"));
const Sap = lazy(() => import("../pages/AssetsPage/SpareParts/SAP"));
const SensorGroup = lazy(() => import("../pages/AssetsPage/SpareParts/SensorGroup"));
const AllPlants = lazy(() => import("../pages/AllPlants"));

const AmpHome = lazy(() => import("../pages/PlantPage/AlertManagementPage/AmpHome"));
const MyTask = lazy(() => import("../pages/PlantPage/AlertManagementPage/MyTask"));
const Reports = lazy(() => import("../pages/PlantPage/AlertManagementPage/Reports"));
const Utilization = lazy(() => import("../pages/PlantPage/AlertManagementPage/Utilization"));
const Master = lazy(() => import("../pages/PlantPage/AlertManagementPage/Master"));

const AffiliateRollout = lazy(() => import("../pages/Admin/AffiliateRollout"));
const PlantRollout = lazy(() => import("../pages/Admin/PlantRollout"));
const UserRoleMapping = lazy(() => import("../pages/Admin/UserRoleMapping"));
const INFO = lazy(() => import("../pages/Info"));
const AdminConfiguration = lazy(() => import("../pages/AdminConfiguration"));
const AssetModelConfig = lazy(() => import("../pages/Admin/AssetModelConfig"));
const ExceptionMonitoring = lazy(() => import("../pages/Admin/ExceptionMonitoring"));

const Workflow = lazy(() => import("../pages/PlantPage/AlertManagementPage/Workflow"));
const Logout = lazy(() => import("../pages/Logout"));

const Alert = lazy(() => import("../pages/Alert"));

const PlantShutdown = lazy(() => import("../pages/Admin/PlantShutdown"));


const Router = () => {
    const userRole = "user";
    const superadminRole = "Superadmin"
    const plantadminRole = "Plantadmin"
    const onePlantUser = "onePlantUser"
    const oneAffiliateUser = "oneAffiliateUser"

    return (
        <Routes history={history} navigator={history}>
            <Route index element={<Protected role={userRole}><Home /></Protected>} />
            <Route index path={HOME_ROUTE} element={<Protected role={userRole}><Home /></Protected>} />
            <Route path={AFFILIATES_ROUTE} element={<Protected role={oneAffiliateUser}><Affiliates /></Protected>} />
            <Route path={All_PLANTS_ROUTE} element={<Protected role={onePlantUser}><AllPlants /></Protected>} />
            <Route path="/alertId/:alertId" element={<Protected role={userRole}><Alert /></Protected>} />
            <Route path="/notfound" element={<NotFound />} />
            <Route path="/plantShutdown" element={<Protected role={superadminRole}><PlantShutdown /></Protected>} />
            {/* <Route path={AMP_WORKFLOW_ROUTE} element={<WorkFlow />} /> */}
            {/* Plant Navigations */}
            <Route path={PLANT_ROUTE} element={<Protected role={userRole}><Plant /></Protected>}>
                <Route index element={<Protected role={userRole}><PmtDashboard /></Protected>} />
                <Route path={PMT_ROUTE} element={<Protected role={userRole}><PmtDashboard /></Protected>} >
                    <Route path={AMP_WORKFLOW_ROUTE} element={<Protected role={userRole}><Workflow /></Protected>} />
                </Route>


                <Route path={ALERT_SATISTICS_ROUTE} element={<Protected role={userRole}><AlertSatistics /></Protected>} >
                    <Route index element={<Protected role={userRole}><Alertdashboard /></Protected>} />
                    <Route index path={ALERT_DASHBOARD_ROUTE} element={<Protected role={userRole}><Alertdashboard /></Protected>} />
                    <Route path={ALERT_LIST_ROUTE} element={<Protected role={userRole}><AlertList /></Protected>} />
                    <Route path={PLANT_TIMELINE_ROUTE} element={<Protected role={userRole}><PlantTimeline /></Protected>} />
                </Route>
                <Route path={MODEL_PERFORMANCE_ROUTE} element={<Protected role={userRole}><ModelPerformance /></Protected>} >
                    <Route index element={<Protected role={userRole}><PerformanceDashboard /></Protected>} />
                    <Route index path={PERFORMANCE_DASHBOARD_ROUTE} element={<Protected role={userRole}><PerformanceDashboard /></Protected>} />
                    <Route path={PLANT_MONTH_WISE_ROUTE} element={<Protected role={userRole}><PlantMonthWise /></Protected>} />
                </Route>
                <Route path={ALERT_MANGAEMENT_ROUTE} element={<Protected role={userRole}><AlertManagementPage /></Protected>} >
                    <Route index element={<Protected role={userRole}><AmpHome /></Protected>} />
                    <Route index path={AMP_HOME_ROUTE} element={<Protected role={userRole}>< AmpHome /></Protected>} />
                    <Route path={AMP_MYTASK_ROUTE} element={<Protected role={userRole}><MyTask /></Protected>} >
                        <Route path={AMP_WORKFLOW_ROUTE} element={<Protected role={userRole}><Workflow /></Protected>} />
                    </Route>
                    <Route path={AMP_REPORTS_ROUTE} element={<Protected role={userRole}><Reports /></Protected>} />
                    <Route path={AMP_UTILIZATION_ROUTE} element={<Protected role={superadminRole}><Utilization /></Protected>} />
                    <Route path={AMP_MASTER_ROUTE} element={<Protected role={superadminRole}><Master /></Protected>} />
                </Route>
                <Route path={PM_COMPLIANCE_ROUTE} element={<Protected role={userRole}><PmCompliance /></Protected>} />
            </Route>
            {/* Asset Navigations */}
            <Route path={ASSETS_ROUTE} element={<Protected role={userRole}><Assets /></Protected>} >
                <Route index element={<Protected role={userRole}><AssetModel /></Protected>} />
                <Route path={ASSET_MODEL_ROUTE} element={<Protected role={userRole}><AssetModel /></Protected>} />
                <Route path={LIVE_TRACKING_ROUTE} element={<Protected role={userRole}><LiveTracking /></Protected>} />
                <Route path={ASSET_TIMELINE_ROUTE} element={<Protected role={userRole}><AssetTimeLine /></Protected>} />
                <Route path={ASSET_ALERT_LIST_ROUTE} element={<Protected role={userRole}><AssetAlertList /></Protected>} >
                    <Route path={AMP_WORKFLOW_ROUTE} element={<Protected role={userRole}><Workflow /></Protected>} />
                </Route>
                <Route path={PLOTS_ROUTE} element={<Protected role={userRole}><Plot /></Protected>} />
                <Route path={REFERENCE_TABLE_ROUTE} element={<Protected role={userRole}><ReferenceTable /></Protected>} />
                <Route path={PREDICTION_CASE} element={<Protected role={userRole}><PredictionCase /></Protected>} />
                <Route path={SPARE_PARTS_ROUTE} element={<Protected role={userRole}><SpareParts /></Protected>} >
                    <Route path={SAP_ROUTE} element={<Protected role={userRole}><Sap /></Protected>} />
                    <Route path={SENSORGROUP_ROUTE} element={<Protected role={userRole}><SensorGroup /></Protected>} />
                </Route>
            </Route>
            <Route path={USERPROFILE_ROUTE} element={<Protected role={userRole}><UserProfile /></Protected>} />
            <Route path={INFOPAGE} element={<Protected role={userRole}><INFO /></Protected>} />
            <Route path={AMP_NOTIFICATION_MYTASK_ROUTE} element={<Protected role={userRole}><MyTask /></Protected>} >
                <Route path={AMP_NOTIFICATION_WORKFLOW_ROUTE} element={<Protected role={userRole}><Workflow /></Protected>} />
            </Route>
            {/* Admin configurations */}
            <Route path={ADMIN_ROUTE} element={<Protected role={plantadminRole}><AdminConfiguration /></Protected>} >
                <Route path={AFFILIATEROLLOUT_ROUTE} element={<Protected role={superadminRole}><AffiliateRollout /></Protected>} />
                <Route path={PLANTROLLOUT_ROUTE} element={<Protected role={superadminRole}><PlantRollout /></Protected>} />
                <Route path={USER_ROLL_MAPPING} element={<Protected role={plantadminRole}><UserRoleMapping /></Protected>} />
                <Route path={ASSET_MODEL_CONFIG} element={<Protected role={plantadminRole}><AssetModelConfig /></Protected>} />
                <Route path={EXCEPTION_MONITORING} element={<Protected role={plantadminRole}><ExceptionMonitoring /></Protected>} />
            </Route>
            <Route path={LOGOUT_ROUTE} element={<Logout />} />
            <Route
                path="*"
                element={<Navigate to="/home" replace />}
            />
        </Routes>
    )
}

export default Router;
