/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HTTP_STATUS } from "../../../../../constants/constants"
import { ECallStatus } from "@rocc/rocc-client-services"
import { incomingCall } from "./IncomingCall"
import * as clientService from "@rocc/rocc-client-services"

const dispatch = jest.fn()

jest.mock("../../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("../../../../helpers/helpers", () => ({
    getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
        rooms: []
    }),
    getUserReducerFromGlobalStore: () => ({
        contacts: []
    })
}))

jest.mock("../../messageService", () => ({
    getContextDetails: jest.fn().mockReturnValue(Promise.resolve({
        status: HTTP_STATUS.OK,
        data: {
            requester: {
                primaryUuid: "primaryUuid",
                callStatus: "INCOMING_CALL",
                userContext: {
                    twilioToken: "twilioToken",
                    callerId: "callerId",
                }
            },
            participants: [{
                primaryUuid: "primaryUuid",
                callStatus: "INCOMING_CALL",
            }],
        }
    }))
}))

jest.mock("../../../../../redux/store/store", () => ({
    getState: jest.fn().mockImplementation(() => ({
        callReducer: {
            videoCallStatus: [{ callStatus: ECallStatus.IDLE, contextId: "" }],
        },
        externalReducer: {
            currentUser: {
                uuid: "uuid",
            }
        }

    }))
}))

jest.mock("../../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
}))

jest.mock("../../../../../redux/actions/callActions", () => ({
    setVideoCallStatus: jest.fn(),
    updateCallTimeout: jest.fn(),
    setIncomingCallDetails: jest.fn(),
    setCallRingStatus: jest.fn(),
    setCallMessage: jest.fn(),
}))

describe("incomingCall tests", () => {
    it("should able to update redux with incoming call details", () => {
        jest.spyOn(clientService, "getDetailsByUUID").mockReturnValue(Promise.resolve({ ...clientService.DEFAULT_CONTACT_INFO, uuid: "uuid" }))
        incomingCall({
            contextId: "contextId", dispatch
        })
        expect(dispatch).toBeDefined()
    })

    it("incoming call when uuid is not available", () => {
        jest.spyOn(clientService, "getDetailsByUUID").mockReturnValue(Promise.resolve({ ...clientService.DEFAULT_CONTACT_INFO, uuid: "" }))

        incomingCall({
            contextId: "contextId", dispatch
        })
        expect(dispatch).toBeDefined()
    })
})
