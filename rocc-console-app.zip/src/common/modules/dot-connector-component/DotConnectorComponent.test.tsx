/*
 * Created on Fri Nov 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import DotConnectorComponent from "./DotConnectorComponent"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentStep: {},
    })
}))
describe("Dot Connector component", () => {
    let wrapper: any
    let dotConnectorComponent: any
    beforeEach(() => {
        wrapper = shallow(<DotConnectorComponent />)
        dotConnectorComponent = wrapper.find("#dotConnector")
    })

    it("should render a grid row", () => {
        expect((dotConnectorComponent).find("GridRow")).toHaveLength(1)
    })
})
