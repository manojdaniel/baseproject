/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { IUserInfo, EClinicalRole, EAppStates, EConnectionStatus } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { SYNC_PARENT_REDUCERS } from "../actions/types"
import { IExternalReducer } from "../interfaces/types"
import { getRoomInfoDetails, getWorkflowInfo } from "../transformer/callingTransformer"

const INIT_CURRENT_USER_PROFILE: IUserInfo = {
    accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "",
    locale: "", modalities: [], name: "", onBoarded: false,
    orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "",
    clinicalRole: EClinicalRole.DEFAULT, secondaryUUID: "", secondaryName: "", description: ""
}

export const initialStateForExternalReducer: IExternalReducer = {
    currentUser: INIT_CURRENT_USER_PROFILE,
    appState: EAppStates.INIT,
    sideBar: {
        activeRightPanel: "",
        displayRightSidePanel: false,
        activeLeftPanel: "",
        displayLeftSidePanel: false,
        desktopFullScreen: false
    },
    featureFlags: {},
    permissions: {},
    notificationMessage: {
        message: [{
            header: "",
            content: ""
        }],
        isSuccess: false,
        isWarning: false,
        isNotification: false,
        showNotification: false,
        closeMessage: () => { return false },
    },
    rooms: [],
    forceCleanUp: false,
    workflows: [],
    applicationConnectionState: EConnectionStatus.ONLINE
}

const externalReducer: Reducer = (state: IExternalReducer = initialStateForExternalReducer, action: any) => {
    switch (action.type) {
        case SYNC_PARENT_REDUCERS: {
            const { currentUser, sideBar, notificationMessage, rooms, forceCleanUp, featureFlags, workflows, appState, applicationConnectionState, permissions } = action.payload
            const updatedRooms = getRoomInfoDetails(rooms)
            const updatedWorkflows = getWorkflowInfo(workflows)
            return { ...state, currentUser, rooms: updatedRooms, sideBar, notificationMessage, forceCleanUp, featureFlags, workflows: updatedWorkflows, appState, applicationConnectionState, permissions }
        }
    }
    return { ...state }
}

export default externalReducer
