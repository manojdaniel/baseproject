/*
 * Created on Fri May 21 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const LOGIN_ROUTE = "/login"
export const LOGOUT_ROUTE = "/logout"
export const REGISTER_ROUTE = "/register"
export const UNAUTHORIZED_ROUTE = "/unauthorized"
export const FORGOT_PD_ROUTE = "/forgotpassword"
export const SET_PD_ROUTE = "/setpassword"
export const RESET_PD_ROUTE = "/resetpassword"
export const SESSION_EXPIRED = "/sessionexpired"
export const IDN_ROUTE = "/idn"
export const ADMIN_ROUTE = "/admin"
export const EXPERT_USER_MANUAL_ROUTE = "/expertUserManual"
export const ADMIN_USER_MANUAL_ROUTE = "/adminUserManual"
export const TRANSITION_ROUTE = "/transition"
export const CONSULTS_ROUTE = "/consults"
export const PHARMA_ROUTE = "/pharma"
export const CALLING_ROUTE = "/calling"
export const SCHEDULING_ROUTE = "/scheduler"
export const SUPPORT_ROUTE = "/support"
export const SETTINGS_ROUTE = "/settings"
export const DEMO_ENV_CONSOLE_ROUTE = "/demoEnvConsole"
export const ROOM_MONITORING_ROUTE = "/cctv"
