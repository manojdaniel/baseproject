"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import unittest
from unittest.mock import patch
from src.constants.config_keys import VAULT_PARENT_ORG_ID
from src.constants.constants import TWILIO_APP_NAME

from src.services.customer_services import CustomerService
from tests.mocks.mock_cf_client import MockCloudFoundryClient


class TestUserServices(unittest.TestCase):
    @patch("src.services.customer_services.get_profile_data", side_effect=lambda: json.loads(json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2"})))
    @patch("src.services.customer_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid:  None)
    @patch("src.services.customer_services.fetch_data_from_vcap_app", side_effect=lambda key, default_value:  "target_endpoint")
    @patch("src.services.customer_services.CustomerService.populate_service_tokens", side_effect=lambda: None)
    @patch("src.services.customer_services.CloudFoundryClient", side_effect=MockCloudFoundryClient)
    def test_populate_service_token(self,m_profile, m_client, m_vcap_app, m_st, m_cfc):
        os.environ[TWILIO_APP_NAME] = "dummy"
        customer_service=CustomerService(service_user_uuid="", customer_identifer="", customer_org_infra_uuid="", token="", force_clean=False)
        customer_service._org_infra_uuid="abc"
        customer_service.safe_audit({},{},{},{},{})
        with self.assertRaises(Exception):
            customer_service.fetch_customer_service_token()
        with self.assertRaises(Exception):
            customer_service.offboard_customer()
        m_client.assert_called()
        m_vcap_app.assert_called()
        m_st.assert_called()
        m_cfc.assert_called()
        m_profile.assert_called()
