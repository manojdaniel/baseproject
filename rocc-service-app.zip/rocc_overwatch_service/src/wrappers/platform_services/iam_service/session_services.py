"""
 Created on Thu Sep 10 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, ORG_CTXT_HEADER, PHILIPS_ROCC_URI, AUTHORIZATION

LOG = create_logger("Session service")

def fetch_access_token(url, username, pwd, org_ctxt=None):
    headers = {CONTENT_TYPE: APPLICATION_JSON}
    if org_ctxt:
        headers[ORG_CTXT_HEADER] = org_ctxt
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/sessionmgmt/Session",
                                data=json.dumps({"loginUserName": username, "loginUserKey": pwd}),
                                headers=headers)
        if response.status_code == 200:
            LOG.info("User logged in successfully")
            api_response = json.loads(response.text)
            return {"data": api_response, "status": response.status_code}
        else:
            LOG.info("User login failed!")
            return {"data": response.json(), "status": response.status_code}

    except requests.exceptions.Timeout as ex:
        LOG.info("Request Timedout during token creation: {}".format(ex))
    except requests.exceptions.TooManyRedirects as ex:
        LOG.info("Token creation failed with TooManyRedirects Exception: {}".format(ex))
    except requests.exceptions.RequestException as ex:
        LOG.info("Token creation failed with RequestException Exception: {}".format(ex))
    return None

def revoke_access_token(url, session_id, token, org_ctxt=None):
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    if org_ctxt:
        headers[ORG_CTXT_HEADER] = org_ctxt
    try:
        response = requests.delete(f"{url}{PHILIPS_ROCC_URI}/sessionmgmt/Session/{session_id}",
                                    headers=headers)
        if response.status_code == 200:
            LOG.info("User logged out successfully")
            return "204"
        else:
            LOG.info("User logout failed!")
            return {"data": response.json(), "status": response.status_code}

    except requests.exceptions.Timeout as ex:
        LOG.info("Request Timedout during Logout: {}".format(ex))
    except requests.exceptions.TooManyRedirects as ex:
        LOG.info("Logout failed with TooManyRedirects Exception: {}".format(ex))
    except requests.exceptions.RequestException as ex:
        LOG.info("Logout failed with RequestException Exception: {}".format(ex))
    return None


def fetch_device_access_token(url, device_id, org_ctxt=None):
    headers = {CONTENT_TYPE: APPLICATION_JSON}
    if org_ctxt:
        headers[ORG_CTXT_HEADER] = org_ctxt
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/sessionmgmt/DeviceSession",
                                data=json.dumps({"deviceId": device_id}),
                                headers=headers)
        if response.status_code == 200:
            LOG.info(f"Device token is generated successfully for device: {device_id}")
            api_response = json.loads(response.text)
            return {"data": api_response, "status": response.status_code}
        else:
            LOG.error(f"Device token is generation failed for device: {device_id}")
            return {"data": response.json(), "status": response.status_code}

    except requests.exceptions.Timeout as ex:
        LOG.info("Request Timedout during token creation: {}".format(ex))
    except requests.exceptions.TooManyRedirects as ex:
        LOG.info("Token creation failed with TooManyRedirects Exception: {}".format(ex))
    except requests.exceptions.RequestException as ex:
        LOG.info("Token creation failed with RequestException Exception: {}".format(ex))
    return None
