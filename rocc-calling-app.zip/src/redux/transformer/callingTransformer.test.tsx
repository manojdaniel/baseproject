/*
 * Created on Thu Dec 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IWorkflow } from "@rocc/rocc-client-services"
import { getRoomInfoDetails, getWorkflowInfo } from "./callingTransformer"

describe("callingTransformer tests", () => {
    it("Get room info details", () => {
        const id = "id"
        const dummyName = "dummyName"
        const loggedInTech = { techUuid: "", techName: "" }
        const presenceData = {}
        const props = [{
            identity: {
                uuid: id,
                name: dummyName,
                address: dummyName
            },
            locationId: id,
            loggedInTech: { techUuid: "", techName: "" },
            presenceData: {}
        }]
        expect(getRoomInfoDetails(props)).toStrictEqual([{
            roomUuid: id,
            roomName: dummyName,
            presenceData: presenceData,
            loggedInTech: loggedInTech
        }])
    })

    it("Get workflow info", () => {
        const workflows = [
            { id: "1", type: "WTYPE1", workflow: {}, state: {}, eventQueue: [], service: {} },
            { id: "2", type: "WTYPE2", workflow: {}, state: {}, eventQueue: [], service: {} },
        ] as unknown as IWorkflow[]

        expect(getWorkflowInfo(workflows)).toStrictEqual([
            { id: "1", type: "WTYPE1", state: {} },
            { id: "2", type: "WTYPE2", state: {} },
        ])
    })
})
