/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { LOGOUT } from "../actions/types"
import appReducer, { initialStatesForApp } from "./appReducer"
import configReducer, { initialStatesForConfigs } from "./configReducer"
import customerReducer, { initialStatesForCustomer } from "./customerReducer"
import userReducer, { initialStatesForUser } from "./userReducer"
import featureFlagsReducer, { initialFeatureFlagReducer } from "./featureFlagsReducer"
import clientStatusReducer, { initialStatesForClientStatus } from "./clientStatusReducer"
import modalReducer, { initialStatesForModals } from "./modalReducer"
import { combineReducers } from "redux"
import workflowReducer, { initialStatesForWorkflowReducer } from "./workflowReducer"

const appsReducer = combineReducers({
    userReducer,
    appReducer,
    configReducer,
    customerReducer,
    featureFlagsReducer,
    clientStatusReducer,
    modalReducer,
    workflowReducer,
})

export const initialStatesForAllReducers = {
    appReducer: initialStatesForApp,
    configReducer: initialStatesForConfigs,
    customerReducer: initialStatesForCustomer,
    userReducer: initialStatesForUser,
    featureFlagsReducer: initialFeatureFlagReducer,
    clientStatusReducer: initialStatesForClientStatus,
    modalReducer: initialStatesForModals,
    workflowReducer: initialStatesForWorkflowReducer
}

const rootReducer = (state: any, action: any) => {

    if (action.type === LOGOUT) {
        const configData = state.configReducer.configData
        sessionStorage.clear()
        sessionStorage.setItem("language", configData.language)
        sessionStorage.setItem("locale", configData.preferredLocale)
        const appReducer = {
            ...initialStatesForAllReducers.appReducer, sideBar: {
                activeRightPanel: "",
                displayRightSidePanel: false,
                activeLeftPanel: "",
                displayLeftSidePanel: false,
                desktopFullScreen: false
            }, roomMonitoringWindow: false
        }
        const configReducer = {
            ...initialStatesForConfigs, configData
        }
        state = { ...initialStatesForAllReducers, appReducer, configReducer }
    }
    return appsReducer(state, action)
}

export default rootReducer
