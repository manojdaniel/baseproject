// @ts-nocheck
/** Application Routes */
export const HOME_ROUTE = "/home"
export const AFFILIATES_ROUTE = "/affiliates"
export const PLANT_ROUTE = "/plant"
export const ASSETS_ROUTE = "/assets"
export const USERPROFILE_ROUTE = "/profile"
export const All_PLANTS_ROUTE = "/allPlants"

export const AMP_WORKFLOW_ROUTE = "workFlow"


export const HOME = "HOME"
export const AFFILIATE = "AFFILIATE"
export const PLANT = "PLANT"
export const PMT = "PMT"
export const ASSETS = "ASSETS"
export const USERPROFILE = "USERPROFILE"

// Plant Page Routes
export const PMT_ROUTE = "pmt"
export const ALERT_SATISTICS_ROUTE = "alertSatistics"
export const MODEL_PERFORMANCE_ROUTE = "modelPerformance"
export const ALERT_MANGAEMENT_ROUTE = "alertManagementPage"
export const PM_COMPLIANCE_ROUTE = "pmCompliance"

export const ALERT_DASHBOARD_ROUTE = "alertDashboard"
export const ALERT_LIST_ROUTE = "alertList"
export const PLANT_TIMELINE_ROUTE = "plantTimeline"

export const PERFORMANCE_DASHBOARD_ROUTE = "performanceDashboard"
export const PLANT_MONTH_WISE_ROUTE = "plantMonthWise"

// Asset Page Routes
export const ASSET_MODEL_ROUTE = "assetModel"
export const LIVE_TRACKING_ROUTE = "liveTracking"
export const ASSET_TIMELINE_ROUTE = "assetTimeLine"
export const ASSET_ALERT_LIST_ROUTE = "alertList"
export const PLOTS_ROUTE = "plots"
export const REFERENCE_TABLE_ROUTE = "referenceTable"
export const PREDICTION_CASE = "predictioncase"
export const SPARE_PARTS_ROUTE = "spareParts"
export const SENSORGROUP_ROUTE = "sensorgroup"
export const SAP_ROUTE = "sap"

// Alert Management Page Routes
export const AMP_HOME_ROUTE = "ampHome"
export const AMP_MYTASK_ROUTE = "ampMyTask"
export const AMP_REPORTS_ROUTE = "ampReports"
export const AMP_UTILIZATION_ROUTE = "ampUtilizationReport"
export const AMP_MASTER_ROUTE = "ampMasterReport"
export const AMP_NOTIFICATION_WORKFLOW_ROUTE = "workFlow"
export const AMP_NOTIFICATION_MYTASK_ROUTE = "ampMyTask"

//Info Page Route
export const INFOPAGE = "/info"
// Logout Route
export const LOGOUT_ROUTE = "/logout"

//Admin Page Route
export const ADMIN_ROUTE = "/admin"
export const AFFILIATEROLLOUT_ROUTE = "affiliateRollout"
export const PLANTROLLOUT_ROUTE = "plantRollout"
export const USER_ROLL_MAPPING = "userRoleMapping"
export const ASSET_MODEL_CONFIG = "assetModelConfig"
export const EXCEPTION_MONITORING = "exceptionMonitoring"
export const HTTP_CALL = `${process.env.REACT_HTTP_CALL}`
export const initialSelectedData = { "value": 0, "label": "" }
