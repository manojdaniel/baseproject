"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import uuid
import requests

from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_customer_configurations
from src.constants.config_keys import INFRA_CFG_DEVICE_PROPOSITION_NAME, VAULT_DEVICE_MDM_URL, INFRA_CFG_DEVICE_APP_NAME, INFRA_CFG_DEVICE_OAUTH_CLIENT_NAME, \
    VAULT_HSDP_IDM_URL, INFRA_CFG_DEVICE_OAUTH_GROUP_NAME, INFRA_CFG_DEVICE_TYPE_NAME
from src.constants.constants import APPLICATION_JSON, CONTENT_TYPE, AUTHORIZATION, API_VERSION, ACCEPT
from src.loggers.log import create_logger
from src.wrappers.platform_services.iam_service.device_mgmt_services import store_device_details
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.utility.utility import generate_random_string
from src.utility.utility import log_error_reasons

LOG = create_logger("DeviceMDMServices")


def provision_devices_service(number_of_devices, vault_response, provision_token, token):
    org_ctxt_header = {"Org-Id": vault_response["data"]["hsdpOrganizationId"]}
    new_device_ids = []
    if provision_token is not None:
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: f"Bearer {provision_token}",
            API_VERSION: "1",
            ACCEPT: APPLICATION_JSON
        }
        data = {"resourceType": "Parameters",
                "parameter": [
                    {"name": "type",
                        "valueString": vault_response["data"]["deviceTypeName"]},
                    {"name": "identityType", "valueString": "device"}
                ]}
        while number_of_devices != 0:
            try:
                device_response = requests.post(os.environ["DEVICE_PROVISION_URL"],
                                                data=json.dumps(data),
                                                headers=headers)
                if device_response.status_code == 200:
                    device_id = store_device_details(
                        device_response.json(), token, str(org_ctxt_header))
                    new_device_ids.append(device_id)
                else:
                    LOG.error(
                        f"Error while Creating Device {json.dumps(device_response.json())}")
                    device_response.raise_for_status()
            except Exception as ex:
                LOG.error(ex)
            number_of_devices -= 1
    return new_device_ids


def manage_device_proposition_service(root_org_token, sub_org_token, org_id, infra_configs, client):
    """ Device proposition creation """
    error_reasn = ""
    device_bootstrap_client_id = None
    device_bootstrap_client_secret = None
    device_group_id = None
    device_type_id = None
    status = False
    create_device_application_error_reasn = ""
    device_boot_strap_client_error_reasn = ""
    device_group_error_reasn = ""
    device_type_error_reasn = ""

    profile_configs = get_profile_data()
    proposition_device_id, error_reasn = create_device_proposition(token=sub_org_token,
                                                                   org_id=org_id,
                                                                   profile_configs=profile_configs,
                                                                   infra_configs=infra_configs)
    if proposition_device_id is not None:
        log_error_reasons(log=LOG, log_type="info",
                          error_reason=f"proposition_device_id::::::{proposition_device_id}\n", method_name="manage_device_proposition_service")
        update_proposition_status(token=sub_org_token,
                                  proposition_id=proposition_device_id,
                                  profile_configs=profile_configs)
        """ Device application creation """
        application_response, create_device_application_error_reasn = create_device_application(token=sub_org_token,
                                                                                                proposition_id=proposition_device_id,
                                                                                                profile_configs=profile_configs,
                                                                                                app_name=infra_configs[
                                                                                                    INFRA_CFG_DEVICE_APP_NAME],
                                                                                                infra_configs=infra_configs,
                                                                                                client=client)
        log_error_reasons(log=LOG, log_type="info",
                          error_reason=f"DeviceApplicationId:::::: {application_response['id']}\n", method_name="manage_device_proposition_service")
        if application_response["id"] is not None:
            """ Device boot strap client creation """
            device_oauth_client_response, device_boot_strap_client_error_reasn = create_device_boot_strap_client(token=sub_org_token,
                                                                                                                 application_id=application_response[
                                                                                                                     "id"],
                                                                                                                 oauth_cname=infra_configs[
                                                                                                                     INFRA_CFG_DEVICE_OAUTH_CLIENT_NAME],
                                                                                                                 profile_configs=profile_configs,
                                                                                                                 infra_configs=infra_configs,
                                                                                                                 client=client)
            log_error_reasons(log=LOG, log_type="info",
                              error_reason=f"DeviceOAuthClientDetails:::::: {device_oauth_client_response}\n", method_name="manage_device_proposition_service")
            device_bootstrap_client_id = device_oauth_client_response["bootstrapClientId"]
            device_bootstrap_client_secret = device_oauth_client_response["bootstrapClientSecret"]

            if device_oauth_client_response["id"] is not None:
                update_device_client_scope(token=root_org_token,
                                           bootstrap_client_id=device_oauth_client_response[
                                               "bootstrapClientGuid"]["value"],
                                           profile_configs=profile_configs)
                log_error_reasons(
                    log=LOG, log_type="info", error_reason=f"DeviceOAuthClientId:::::: {device_oauth_client_response['id']}\n", method_name="manage_device_proposition_service")
            """ Device Group creation """
            device_group_id, device_group_error_reasn = create_device_group(token=sub_org_token,
                                                                            application_id=application_response["id"],
                                                                            group_name=infra_configs[
                                                                                INFRA_CFG_DEVICE_OAUTH_GROUP_NAME],
                                                                            profile_configs=profile_configs,
                                                                            infra_configs=infra_configs,
                                                                            client=client)
            log_error_reasons(log=LOG, log_type="info",
                              error_reason=f"DeviceGroupId:::::: {device_group_id}\n", method_name="manage_device_proposition_service")
            if device_group_id != "None":
                """ Device Type creation """
                device_type_id, device_type_error_reasn = create_device_type(token=sub_org_token,
                                                                             device_group_id=device_group_id,
                                                                             type_name=infra_configs[INFRA_CFG_DEVICE_TYPE_NAME],
                                                                             profile_configs=profile_configs,
                                                                             infra_configs=infra_configs,
                                                                             client=client)
                log_error_reasons(
                    log=LOG, log_type="info", error_reason=f"DeviceTypeId:::::: {device_type_id}\n", method_name="manage_device_proposition_service")
                status = True
    if not error_reasn:
        error_reasn = create_device_application_error_reasn
    if not error_reasn:
        error_reasn = device_boot_strap_client_error_reasn
    if not error_reasn:
        error_reasn = device_group_error_reasn
    if not error_reasn:
        error_reasn = device_type_error_reasn

    return {"device_bootstrap_client_id": device_bootstrap_client_id,
            "device_bootstrap_client_secret": device_bootstrap_client_secret,
            "device_group_id": device_group_id,
            "device_type_id": device_type_id,
            "status": status,
            "error_reasn": error_reasn}


def create_device_proposition(token, org_id, profile_configs, infra_configs):
    device_proposition_id = None
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": infra_configs[INFRA_CFG_DEVICE_PROPOSITION_NAME],
            "description": infra_configs[INFRA_CFG_DEVICE_PROPOSITION_NAME],
            "resourceType": "Proposition",
            "organizationGuid": {"value": org_id, "system": f"{profile_configs[VAULT_DEVICE_MDM_URL]}/connect/mdm"},
            "globalReferenceId": str(uuid.uuid4()),
            "defaultCustomerOrganizationGuid": {"value": org_id, "system": f"{profile_configs[VAULT_DEVICE_MDM_URL]}/connect/mdm"},
            "status": "DRAFT"}
    try:
        response = requests.post(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/Proposition",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Device proposition created successfully")
            device_proposition_id = response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Device proposition is already present, hence not creating: {json.dumps(response.json())}")
            error_reasn = f"Device proposition is already present, hence not creating: {json.dumps(response.json())}"
        else:
            LOG.error(
                f"Error while creating device proposition: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while creating device proposition: {exception}")
        error_reasn = f"Error while creating OAuthClient: {repr(exception.args)}"
    return device_proposition_id, error_reasn


def update_proposition_status(token, proposition_id, profile_configs):
    update_proposition_stat = False
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"id": proposition_id,
            "resourceType": "Proposition", "status": "ACTIVE"}
    try:
        response = requests.put(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/Proposition/{proposition_id}",
                                data=json.dumps(data),
                                headers=iam_headers)
        if response.status_code == 200:
            update_proposition_stat = True
            LOG.info("Proposition Status updated to Active")
        else:
            LOG.error(
                f"Error while updating device Proposition: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while updating device Proposition: {exception}")
        error_reasn = f"Error while updating device Proposition: {repr(exception.args)}"
    return update_proposition_stat, error_reasn


def create_device_application(token, proposition_id, app_name, profile_configs, infra_configs, client, retry=0):
    device_application_response = None
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": app_name,
            "description": app_name,
            "resourceType": "Application",
            "propositionId": {"reference": f"Proposition/{proposition_id}"},
            "globalReferenceId": str(uuid.uuid4())}

    try:
        response = requests.post(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/Application/",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Device application is created successfully")
            device_application_response = response.json()
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Device application is already present: {response.json()}")
            if retry < 3:
                LOG.info(
                    f"Retrying Device application creation, retry number: {retry}")
                updated_val = generate_random_string(app_name, 16)
                # Update the infra configuration with newly generated value
                update_customer_configurations(
                    client, infra_configs, INFRA_CFG_DEVICE_APP_NAME=updated_val)
                device_application_response, error_reasn = create_device_application(token=token,
                                                                                     proposition_id=proposition_id,
                                                                                     app_name=updated_val,
                                                                                     profile_configs=profile_configs,
                                                                                     infra_configs=infra_configs,
                                                                                     client=client,
                                                                                     retry=retry + 1)
            else:
                LOG.error("Retrying Device application creation failed")
                error_reasn = "Retrying Device application creation failed"
        else:
            LOG.error(
                f"Error while creating device application: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while creating device application: {exception}")
        error_reasn = f"Error while creating device application:{repr(exception.args)}"
    return device_application_response, error_reasn


def create_device_boot_strap_client(token, application_id, oauth_cname, profile_configs, infra_configs, client, retry=0):
    device_boot_strap_client_response = None
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": oauth_cname,
            "description": oauth_cname,
            "resourceType": "OAuthClient",
            "applicationId": {"reference": f"Application/{application_id}"},
            "bootstrapClientRevoked": False,
            "globalReferenceId": str(uuid.uuid4()),
            "userClient": False}

    try:
        response = requests.post(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/OAuthClient/",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Device boot-strap OAuthClient created successfully")
            device_boot_strap_client_response = response.json()
        elif response.status_code == 409 or (response.status_code == 422 and response.json()["issue"][0]["details"]["text"] == "Duplicate OAuthClient found with the same name"):
            """ TODO: Check response """
            LOG.warning(
                f"Looks like a similar Device boot-strap OAuthClient is already present: {json.dumps(response.json())}")
            if retry < 3:
                LOG.info(
                    f"Retrying Device boot-strap OAuthClient creation, retry number: {retry}")
                """ Recommended regex pattern ^[a-zA-Z0-9_ .!*{}-]+$ """
                updated_val = generate_random_string(oauth_cname, 16)
                # Update the infra configuration with newly generated value
                update_customer_configurations(
                    client, infra_configs, INFRA_CFG_DEVICE_OAUTH_CLIENT_NAME=updated_val)
                device_boot_strap_client_response, error_reasn = create_device_boot_strap_client(token=token,
                                                                                                 application_id=application_id,
                                                                                                 oauth_cname=updated_val,
                                                                                                 profile_configs=profile_configs,
                                                                                                 infra_configs=infra_configs,
                                                                                                 client=client,
                                                                                                 retry=retry + 1)
            else:
                LOG.error(
                    "Retrying Device boot-strap OAuthClient creation failed")
                error_reasn = "Retrying Device boot-strap OAuthClient creation failed"
        else:
            LOG.error(
                f"Error while creating Device boot-strap OAuthClient: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(
            f"Error while creating Device boot-strap OAuthClient: {exception}")
        error_reasn = f"Error while creating Device boot-strap OAuthClient: {repr(exception.args)}"
    return device_boot_strap_client_response, error_reasn


def update_device_client_scope(token, bootstrap_client_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"defaultScopes": ["?.?.prv.device.create-identity"],
            "scopes": ["?.?.prv.device.create-identity"]}
    try:
        response = requests.put(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Client/{bootstrap_client_id}/$scopes",
                                data=json.dumps(data),
                                headers=iam_headers)
        if response.status_code == 204:
            LOG.info("Device Client Scope updated Successfully ")
            return True
        else:
            LOG.error(
                f"Error while updating Device clientScope: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while updating Device clientScope: {exception}")
    return None


def create_device_group(token, application_id, group_name, profile_configs, infra_configs, client, retry=0):
    device_group_response = None
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": group_name,
            "description": group_name,
            "resourceType": "DeviceGroup",
            "applicationId": {"reference": f"Application/{application_id}"}}
    try:
        response = requests.post(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/DeviceGroup/",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Device MDM group created successfully")
            device_group_response = response.json()["id"]
        elif response.status_code == 409 or (response.status_code == 422 and response.json()["issue"][0]["details"]["text"] == "Duplicate DeviceGroup found with the same name"):
            """ TODO: Check response """
            LOG.warning(
                f"Looks like a similar Device MDM group is already present: {response.json()}")
            if retry < 3:
                LOG.info(
                    f"Retrying Device MDM group creation, retry number: {retry}")
                updated_val = generate_random_string(group_name, 10)
                # Update the infra configuration with newly generated value
                update_customer_configurations(
                    client, infra_configs, INFRA_CFG_DEVICE_OAUTH_GROUP_NAME=updated_val)
                device_group_response, error_reasn = create_device_group(token=token,
                                                                         application_id=application_id,
                                                                         group_name=updated_val,
                                                                         profile_configs=profile_configs,
                                                                         infra_configs=infra_configs,
                                                                         client=client,
                                                                         retry=retry + 1)
            else:
                LOG.error("Retrying Device MDM group creation failed")
                error_reasn = "Retrying Device MDM group creation failed"
        else:
            LOG.error(
                f"Error while creating MDM device Group: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while creating MDM device Group: {exception}")
        error_reasn = f"Error while creating MDM device Group {repr(exception.args)}"
    return device_group_response, error_reasn


def create_device_type(token, device_group_id, type_name, profile_configs, infra_configs, client, retry=0):
    device_type_id = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": type_name,
            "description": type_name,
            "resourceType": "DeviceType",
            "deviceGroupId": {"reference": f"DeviceGroup/{device_group_id}"},
            "ctn": type_name}
    try:
        response = requests.post(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/DeviceType/",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("DeviceType service created successfully")
            device_type_id = response.json()["id"]
        elif response.status_code in (409, 422):
            """ TODO: Check response """
            LOG.warning(
                f"Looks like a similar DeviceType service is already present: {response.json()}")
            if retry < 3:
                LOG.info(
                    f"Retrying DeviceType service creation, retry number: {retry}")
                """ Supported regex pattern ^[a-zA-Z0-9_-]+$" """
                updated_val = generate_random_string(type_name, 10)
                # Update the infra configuration with newly generated value
                update_customer_configurations(
                    client, infra_configs, INFRA_CFG_DEVICE_TYPE_NAME=updated_val)
                device_type_id, error_reasn = create_device_type(token=token,
                                                                 device_group_id=device_group_id,
                                                                 type_name=updated_val,
                                                                 profile_configs=profile_configs,
                                                                 infra_configs=infra_configs,
                                                                 client=client,
                                                                 retry=retry + 1)
            else:
                LOG.error("Retrying DeviceType service creation failed")
                error_reasn = "Retrying DeviceType service creation failed"
        else:
            LOG.error(
                f"Error while creating DeviceType service: {response.json()}")
            response.raise_for_status()
    except Exception as exception:
        LOG.error(f"Error while creating DeviceType service: {exception}")
        error_reasn = f"Error while creating DeviceType service: {repr(exception.args)}"
    return device_type_id, error_reasn


def cleanup_device_group(token, group_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.delete(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/DeviceGroup/{group_id}",
                                   headers=iam_headers)
        if response.status_code in [200, 204]:
            LOG.info(
                f"Device MDM group with id: {group_id} cleaned up successfully. Response {response}")
            return True
        else:
            LOG.error(
                f"Failed to clean up MDM device Group: {group_id} with error: {response}")
    except Exception as exception:
        LOG.error(
            f"Failed to clean up MDM device Group: {group_id} with Exception: {exception}")
    return False


def cleanup_device_type(token, type_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.delete(f"{profile_configs[VAULT_DEVICE_MDM_URL]}/DeviceType/{type_id}",
                                   headers=iam_headers)
        if response.status_code in [200, 204]:
            LOG.info(
                f"Device MDM type with id: {type_id} cleaned up successfully. Response {response} ")
            return True
        else:
            LOG.error(
                f"Failed to clean up MDM device Type: {type_id} with error: {response}")
    except Exception as exception:
        LOG.error(
            f"Failed to clean up MDM device Type: {type_id} with Exception: {exception}")
    return False
