import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../assets/common/CommonTables.scss";
import moment from "moment";
import Link from "antd/es/typography/Link";
import "./admin-table.scss";

interface Props {
	data: any[];
	exceptionHandle: any
}
const ExceptionMonitoringTable = ({ data, exceptionHandle }: Props) => {
	// Time Formate work :Start
	const [exceptionMonitoringList, setExceptionMonitoringList] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				logDate: moment(new Date(`${item.logDate}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				logId: item.logId,
				exceptionMsg: item.exceptionMsg,
				exceptionType: item.exceptionType,
				exceptionSource: item.exceptionSource,
				stackTrace: item.stackTrace,
				details: <Link onClick={() => onClickHandle(item.logId)}>Details</Link>
			};
		});
		setExceptionMonitoringList(mydata);
	}, [data]);
	// Time Formate work :End
	const onClickHandle = (logId) => {
		exceptionHandle(logId)
	}
	const columns = [
		{
			title: "LOG ID",
			dataIndex: "logId",
			key: "logId",
			width: '5%',
		},
		{
			title: "EXE MESSAGE",
			dataIndex: "exceptionMsg",
			key: "exceptionMsg",
			width: '25%',
		},
		{
			title: "EXE TYPE",
			dataIndex: "exceptionType",
			key: "exceptionType",
			width: '10%',
		},
		{
			title: "EXE SOURCE",
			dataIndex: "exceptionSource",
			key: "exceptionSource",
			width: '10%',
		},
		{
			title: "STACK TRACE",
			dataIndex: "stackTrace",
			key: "stackTrace",
			width: '25%',
		},
		{
			title: "EXCEPTION DATE",
			dataIndex: "logDate",
			key: "logDate",
			width: '10%',
		},
		{
			title: "DETAILS",
			dataIndex: "details",
			key: "details",
			width: '10%',
		},
	];
	const mobileColumns = [
		{
			title: "LOG ID",
			dataIndex: "logId",
			key: "logId",
			width: 100,
		},
		{
			title: "EXE MESSAGE",
			dataIndex: "exceptionMsg",
			key: "exceptionMsg",
			width: 150,
		},
		{
			title: "EXE TYPE",
			dataIndex: "exceptionType",
			key: "exceptionType",
			width: 100,
		},
		{
			title: "EXE SOURCE",
			dataIndex: "exceptionSource",
			key: "exceptionSource",
			width: 100,
		},
		{
			title: "STACK TRACE",
			dataIndex: "stackTrace",
			key: "stackTrace",
			width: 100,
		},
		{
			title: "EXCEPTION DATE",
			dataIndex: "logDate",
			key: "logDate",
			width: 100,
		},
		{
			title: "DETAILS",
			dataIndex: "details",
			key: "details",
			width: 100,
		},
	];
	return (
		<div>
			<div>
				{(() => {
					if (currentScreenWidth > 1200) {
						return (
							<Table
								columns={columns}
								dataSource={exceptionMonitoringList}
								tableLayout="fixed"
								pagination={{ pageSize: 10, showSizeChanger: false }}
							/>
						);
					} else {
						return (
							<Table
								columns={mobileColumns}
								tableLayout={undefined}
								dataSource={exceptionMonitoringList}
								pagination={{ pageSize: 10, showSizeChanger: false }}
								scroll={{ x: '750px', y: 200 }}
							/>
						);
					}
				})()}
			</div>
		</div>
	);
};
export default ExceptionMonitoringTable;
