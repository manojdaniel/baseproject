/*
 * Created on Tue Dec 17 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { APPLICATION_JSON, CONTENT_TYPE } from "../../constants/constants"
import { GENERIC_SERVICE_API_URI, PHILIPS_API_URI, VALIDATE_TOKEN } from "../../constants/endpoints"
import { checkInternetConnectionState, setChatClientStatus } from "../../redux/actions/clientStatusActions"
import { getService, postCall, refreshToken, safeURL } from "../../utility/api/apiUtility"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { IParentStore, EConnectionStatus } from "@rocc/rocc-client-services"

const NetworkDetector = () => {
    const [connectionState, setConnectionState] = useState(true)
    const { currentUser, urls, configs, isProxy, applicationConnectionState } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        urls: state.configReducer.urls,
        configs: state.configReducer.configs,
        isProxy: state.configReducer.isProxy,
        applicationConnectionState: state.clientStatusReducer.applicationConnectionState
    }))
    const dispatch = useDispatch()

    const isTokenValid = async () => {
        try {
            const { status, data } = await postCall({
                url: `${safeURL(urls.IAM_SERVICES_URL, PHILIPS_API_URI)}${VALIDATE_TOKEN}`,
                body: { accessToken: currentUser.accessToken },
                headers: { [CONTENT_TYPE]: APPLICATION_JSON },
            })
            return (status === 200 && data && data.active) ? true : false
        } catch (error) {
            errorLogger(`Token validation failed for session: ${currentUser.sessionId} with error: ${errorParser(error)}`)
            return false
        }

    }

    const handleConnectionChange = () => {
        const condition = navigator.onLine ? "online" : "offline"
        if (condition === "online") {
            const pingEp = safeURL(GENERIC_SERVICE_API_URI, configs.PING_URL)
            const url = isProxy === "true" ? `${window.location.origin}${PHILIPS_API_URI}${pingEp}` : `${safeURL(urls.IAM_SERVICES_URL, PHILIPS_API_URI)}${pingEp}`
            const webPing = setInterval(() => {
                getService({ url, headers: { [CONTENT_TYPE]: APPLICATION_JSON } }).then(() => {
                    setConnectionState(true)
                    clearInterval(webPing)
                }).catch(() => {
                    errorLogger("NetWorkDetector: Internet is still down!")
                })
            }, 3000)
        } else {
            setConnectionState(false)
            dispatch(setChatClientStatus(EConnectionStatus.OFFLINE))
            dispatch(checkInternetConnectionState(EConnectionStatus.OFFLINE))
        }
    }

    useEffect(() => {
        if (applicationConnectionState !== EConnectionStatus.ONLINE) {
            dispatch(checkInternetConnectionState(EConnectionStatus.ONLINE))
        }
        window.addEventListener("online", handleConnectionChange)
        window.addEventListener("offline", handleConnectionChange)
        return () => {
            window.removeEventListener("online", handleConnectionChange)
            window.removeEventListener("offline", handleConnectionChange)
        }
    }, [])

    useEffect(() => {
        const checkTokens = async () => {
            if (connectionState && urls.IAM_SERVICES_URL) {
                if (!await isTokenValid()) {
                    refreshToken().then(() => {
                        infoLogger(`Succesfully able to refresh the token.`)
                    }).catch(error => errorLogger(`Failed to refresh the token : ${error}`))
                }
                if (applicationConnectionState !== EConnectionStatus.ONLINE) {
                    dispatch(checkInternetConnectionState(EConnectionStatus.ONLINE))
                }
            }
        }
        checkTokens()
    }, [connectionState])

    return <div id={"NetworkDetector"} />
}

export default NetworkDetector
