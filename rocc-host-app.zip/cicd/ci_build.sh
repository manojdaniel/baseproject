#!/bin/bash
set -e
set -x
export no_proxy=artifactory-ehv.ta.philips.com
CICD_FOLDER=cicd

echo "Building rocc-cc-host-app"
build_type=$1
export no_proxy=artifactory.pic.philips.com,artifactory-ehv.ta.philips.com
currentDir=$(pwd)

echo "processing in directory : {$currentDir}"


echo "====================================="
echo "Download tool kit dependencies"
echo "====================================="

echo "====================================="
echo "building client"
echo "====================================="
echo "ROCC_DEV=$ROCC_DEV" > .env
npm install
npm run build
# if [ "$build_type" = "tag_build" ]; then
#     npm run build
# else
#     npm run build:dev
# fi
npm run test:coverage
echo "====================================="
echo "copying required content to $CICD_FOLDER folder"
echo "====================================="

cp -r node_modules $CICD_FOLDER
cp package.json $CICD_FOLDER
#rm -rf dist/rocsrcmp/
cp -r dist $CICD_FOLDER

