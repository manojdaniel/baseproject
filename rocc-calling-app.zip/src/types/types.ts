import { EROCC_CONTEXT, IContactInfo } from "@rocc/rocc-client-services"

export interface ITabbarItems {
    name: ESidePanelTabs
    value: string
    type: ETabbarType
    component?: JSX.Element
}

/* TODO: Remove this interface after Tab component is moved out of calling app */
export interface IContactProps {
    contact: IContactInfo
    permissions: any
    featureFlags: any
}

/* TODO: Remove this interface after Tab component is moved out of calling app */
export interface ITelepresencePanel extends IAppProps {
    visible: boolean
    ContactListComponentTab: any
    activeItem: ESidePanelTabs
    setActiveItem: (activeItem: ESidePanelTabs) => void
    contactCardActions: (props: IContactProps) => any[]
}

export enum ETabbarType {
    COMPONENT,
    STRING,
}

/* TODO: Remove this interface after Tab component is moved out of calling app */
export enum ESidePanelTabs {
    Contacts = "Contacts",
    MissedCalls = "Missed calls",
    Active = "Active",
}

/* TODO: Relook at this interface after Tab component is moved out of calling app */
export interface IAppProps {
    contacts: IContactInfo[]
    connectedCallProps?: IConnectedCallProps
}

export interface ICallFeatures {
    deviceType: EROCC_CONTEXT
    modalityName: string
}

export interface IConnectedCallProps {
    customCallControls?: [(contactUuid: string) => JSX.Element]
    participantCards?: ICardComponent
    contactCards?: ICardComponent
    callOperations?: ICallOperations
    callNotifications?: JSX.Element
}

export interface ICardComponent {
    components: [(contactUuid: string) => JSX.Element]
}

export interface ICallOperations {
    callEnd: ICallHookProps
}

export interface ICallHookProps {
    preHook: (...args: any) => void
    postHook: (...args: any) => void
}

export enum EActiveCallPanel {
    DEFAULT,
    CALL_MESSAGE,
    CONNECTING_CALL,
    OUTGOING_CALL,
    ONGOING_WEB_TO_PHONE_CALL,
    ONGOING_WEB_TO_WEB_CALL,
}

export enum ECommunicationRoomType {
    GO = "go",
    PEER_TO_PEER = "peer-to-peer",
    GROUP = "group",
    GROUP_SMALL = "group-small",
}
