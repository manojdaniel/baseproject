/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoomMoinitorRenderState } from "@rocc/rocc-client-services"
import { RoomMonitoringItem } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger } from "@rocc/rocc-logging-module"
import cx from "classnames"
import { times } from "lodash"
import React from "react"
import { Grid, GridColumn, GridRow } from "semantic-ui-react"
import { NO_VIDEO_PROP } from "../../../common/constants/constants"
import { cameraName } from "../../../common/helpers/multiCameraUtility"
import styles from "../room-monitoring-stream-view/RoomMonitoringStreamView.scss"

interface IRoomMonitoringDefaultView {
    roomMonitorMessage: any
    renderState: ERoomMoinitorRenderState
    maxSupportedCameras: number
    singleRecieverView: boolean
    isSwitchingConsoleSession: boolean
    currentUserUuid: string
}

const RoomMonitoringDefaultView = ({ roomMonitorMessage, maxSupportedCameras, singleRecieverView, renderState, isSwitchingConsoleSession, currentUserUuid }: IRoomMonitoringDefaultView) => {

    const { intl } = getIntlProvider()

    const getDefaultView = () => {
        const props = {
            cameraState: false,
            fullscreenState: false,
            hideFullscreenControl: true,
            hideCameraControl: true,
            renderState: renderState,
            videoTrackItem: NO_VIDEO_PROP,
            isSwitchingConsoleSession,
        }
        return times(maxSupportedCameras, (num: number) => {
            return <RoomMonitoringItem
                key={num}
                {...props}
                currentUserUuid={currentUserUuid}
                consoleContextId={""}
                infoLogger={infoLogger}
                message={roomMonitorMessage}
                cameraName={cameraName(num, intl)}
                
            />
        })
    }

    return <Grid className={cx(styles.roomMonitorStreamGrid, singleRecieverView ? styles.singleReceiverGrid : styles.multiReceiverGrid)} id={"roomMonitorDefaultView"} >
        {getDefaultView().map((roomMonitoringItem: any) => {
            return singleRecieverView ? <GridColumn className={styles.roomMonitorStreamColumn}>
                {roomMonitoringItem}
            </GridColumn>
                : <GridRow className={styles.roomMonitorStreamRow}>
                    {roomMonitoringItem}
                </GridRow>
        })}
    </Grid>
}

export default RoomMonitoringDefaultView
