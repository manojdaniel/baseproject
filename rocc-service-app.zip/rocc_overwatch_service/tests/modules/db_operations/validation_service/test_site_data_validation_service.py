import unittest
from src.constants.headers import EXCEL_HOSPITAL_FRONTDESK_PHONE, EXCEL_HOSPITAL_SCHEDULER_PHONE, EXCEL_HOSPITAL_DISPLAY_NAME, EXCEL_STREET_ADDRESS, EXCEL_HOSPITAL_CITY, \
    EXCEL_HOSPITAL_PROVINCE, EXCEL_HOSPITAL_POSTAL_CODE
from src.modules.db_operations.validation_service.site_data_validation_service import check_if_site_exists


class SitesDataValidationTest(unittest.TestCase):
    def test_check_if_site_exists(self):
        site_info = {}
        site_info[EXCEL_STREET_ADDRESS] = "street address"
        site_info[EXCEL_HOSPITAL_CITY] = "hospital city"
        site_info[EXCEL_HOSPITAL_PROVINCE] = "hospital province"
        site_info[EXCEL_HOSPITAL_POSTAL_CODE] = " hospital postal code"
        site_info[EXCEL_HOSPITAL_FRONTDESK_PHONE] = "front desk phone"
        site_info[EXCEL_HOSPITAL_SCHEDULER_PHONE] = "scheduler phone"
        site_info[EXCEL_HOSPITAL_DISPLAY_NAME] = "hospital display name"
        sites = check_if_site_exists({}, "site_identifier", site_info)
        self.assertIsNone(sites)

    def test_check_if_site_exists_with_no_site(self):
        site_info = {}
        sites = check_if_site_exists({}, "site_identifier", site_info)
        self.assertIsNone(sites)
