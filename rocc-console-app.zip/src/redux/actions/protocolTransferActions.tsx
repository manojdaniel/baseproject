/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoomDetails } from "@rocc/rocc-client-services"
import isEmpty from "lodash.isempty"
import { Dispatch } from "redux"
import { EProtocolTransferSteps, IStore } from "../interfaces/types"
import {
    GLOBAL_SET_PROTOCOL_TRANSFER_STATUS,
    GLOBAL_SET_PROTOCOL_TRANSFER_EXIT,
    GLOBAL_SET_SOURCE_SCANNER,
    GLOBAL_SET_DESTINATION_SCANNER,
    GLOBAL_SET_PROTOCOL_TRANSFER_STEP,
    GLOBAL_CLEAR_DESTINATIONS,
    GLOBAL_SET_INITIATION_ROUTE,
    UPDATE_DESTINATION_SCANNERS,
} from "./types"

export const setProtocolTransferStatus = (protocolTransferStatus: boolean) => (dispatch: Dispatch, getState: any) => {
    resetStates(dispatch, getState)
    dispatch({ type: GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, payload: { protocolTransferStatus: protocolTransferStatus } })
}

export const setProtocolTransferExitInProgress = (protocolTransferExit: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, payload: { protocolTransferExit: protocolTransferExit } })
}

export const setSourceScanner = (sourceScanner: IRoomDetails) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_SOURCE_SCANNER, payload: { selectedSource: sourceScanner } })
}

export const setDestinationScanner = (destinationScanner: IRoomDetails) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_DESTINATION_SCANNER, payload: { selectedDestination: destinationScanner } })
}

export const setProtocolTransferStep = (step: EProtocolTransferSteps) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_PROTOCOL_TRANSFER_STEP, payload: { currentStep: step } })
}

export const updateDestinationScanners = (destinationScanner: string) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_DESTINATION_SCANNERS, selectedDestination: destinationScanner })
}

export const setInitiationRoute = (initiationRoute: string) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_INITIATION_ROUTE, payload: { initiationRoute: initiationRoute } })
}

export const resetAllStates = () => (dispatch: Dispatch, getState: any) => {
    resetStates(dispatch, getState)
}

export const resetDestination = () => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    if (!isEmpty(state.protocolTransferReducer.selectedDestination)) {
        dispatch({ type: GLOBAL_SET_DESTINATION_SCANNER, payload: { selectedDestination: {} } })
    }
    if (state.protocolTransferReducer.currentStep != EProtocolTransferSteps.SelectDestinationScanner) {
        dispatch({ type: GLOBAL_SET_PROTOCOL_TRANSFER_STEP, payload: { currentStep: EProtocolTransferSteps.SelectDestinationScanner } })
    }
    dispatch({ type: GLOBAL_CLEAR_DESTINATIONS })
}

const resetStates = (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    if (state.protocolTransferReducer.currentStep != EProtocolTransferSteps.SelectSourceScanner) {
        dispatch({ type: GLOBAL_SET_PROTOCOL_TRANSFER_STEP, payload: { currentStep: EProtocolTransferSteps.SelectSourceScanner } })
    }
    if (!isEmpty(state.protocolTransferReducer.selectedSource)) {
        dispatch({ type: GLOBAL_SET_SOURCE_SCANNER, payload: { selectedSource: {} } })
    }
    if (!isEmpty(state.protocolTransferReducer.selectedDestination)) {
        dispatch({ type: GLOBAL_SET_DESTINATION_SCANNER, payload: { selectedDestination: {} } })
    }
    dispatch({ type: GLOBAL_CLEAR_DESTINATIONS })
}
