/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { COLUMN_SEPERATOR, DEFAULT_CUSTOMER_NAME, ROW_SEPERATOR, SECOND_POSITION, THIRD_POSITION } from "../../constants/constants"
import { EUserPresence } from "../../types/types"
import { ICustomerMetadata, ILocationInfo, IRoomDetails, EClinicalRole, IModality, ERoomStatus } from "@rocc/rocc-client-services"
import sortBy from "lodash.sortby"
import { populateSiteContactsForLocation } from "../../utility/helpers/helpers"
import { insertObjectIfNotExists } from "../../utility/list/listUtility"
import { parseIntBase10 } from "../../utility/math/mathUtility"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"

export const fetchLocationInfoForCurrentUserTransformer = (data: any) => {
    const { resourcesInfo } = data
    const customerMetaData: ICustomerMetadata = { id: -1, displayName: DEFAULT_CUSTOMER_NAME, name: DEFAULT_CUSTOMER_NAME, orgId: "", contacts: [] }
    let locations: ILocationInfo[] = []
    let rooms: IRoomDetails[] = []
    let allModalties: IModality[] = []

    customerMetaData.id = resourcesInfo[0].org_id
    customerMetaData.displayName = resourcesInfo[0].org_name
    customerMetaData.name = resourcesInfo[0].org_identifier
    customerMetaData.orgId = resourcesInfo[0].org_uuid

    resourcesInfo.forEach((object: any) => {

        const modalities: string[] = object.modality.split(",")
        allModalties = insertObjectIfNotExists(allModalties,
            { id: parseIntBase10(modalities[0].split(COLUMN_SEPERATOR)[0]), modality: modalities[0].split(COLUMN_SEPERATOR)[1] },
            "id")
        const site: string[] = object.sites.split(ROW_SEPERATOR)
        const siteContacts: string[] = object.site_contacts.split(ROW_SEPERATOR)
        const location: ILocationInfo = {
            id: parseIntBase10(site[0].split(COLUMN_SEPERATOR)[0]), name: site[0].split(COLUMN_SEPERATOR)[SECOND_POSITION],
            address: site[0].split(COLUMN_SEPERATOR)[THIRD_POSITION], shortName: site[0].split(COLUMN_SEPERATOR)[1],
            modalityList: [], roomsFetched: false,
            locationContacts: [], totalRooms: 0,
        }
        populateSiteContactsForLocation(siteContacts, location)
        locations = insertObjectIfNotExists(locations, location, "id")
        const room: IRoomDetails = {
            identity: { id: -1, name: "", uuid: "" }, locationId: -1, address: "",
            modality: "", modalityId: "", favourite: false, phoneNumber: "", disabled: false, isRoomStarred: false,  roomStatus: ERoomStatus.UNKNOWN,
            presenceData: { presence: EUserPresence.OFFLINE, mapId: "" }, isConnecting: false, loggedInTech: { techName: "", techUuid: "" }, monitorsCount: 1, modalityConnection: []
        }
        room.identity.id = object.resource_id
        room.identity.name = object.resource_name
        room.identity.uuid = object.device_uuid
        room.identity.address = object.resource_location
        room.phoneNumber = object.resource_phone
        room.isRoomStarred = object.user_favourite
        room.locationId = parseIntBase10(site[0].split(COLUMN_SEPERATOR)[0])
        room.modalityId = modalities[0].split(COLUMN_SEPERATOR)[0]
        room.modality = modalities[0].split(COLUMN_SEPERATOR)[1]
        room.address = object.resource_location
        room.monitorsCount = object.monitorsCount
        room.additionalAttributes = object.additional_attributes ? object.additional_attributes : null
        room.modalityConnection = object.modality_connection
        rooms.push(room)

    })
    rooms = sortBy(rooms, (room: IRoomDetails) => room.identity.name.toLowerCase())
    locations.forEach((location: ILocationInfo) => {
        location.modalityList = allModalties
        location.roomsFetched = true
    })
    locations = sortBy(locations, "name".toLowerCase())
    return { customerMetaData, locations, rooms }
}

export const addressHelper = (address: string, city: string, state: string, postal: string) => {
    let partialAddress = ""
    partialAddress = (city && !address.includes(city)) ? city : partialAddress
    partialAddress = (state && !address.includes(state)) ? (partialAddress ? `${partialAddress}, ${state}` : state) : partialAddress
    partialAddress = (postal && !address.includes(postal)) ? (partialAddress ? `${partialAddress} - ${postal}` : postal) : partialAddress
    return address.includes(partialAddress) ? address : `${address}, ${partialAddress}`
}

export const convertContact = (dbContactType: string, contact_id: string) => {
    let clinicalRole = EClinicalRole.DEFAULT
    switch (dbContactType) {
        case "front-desk":
            contact_id = `fd${contact_id}`
            clinicalRole = EClinicalRole.FRONTDESK
            break
        case "patient-transport":
            contact_id = `pt${contact_id}`
            clinicalRole = EClinicalRole.TRANSPORT
            break
        case "scheduler-registrar":
            contact_id = `sr${contact_id}`
            clinicalRole = EClinicalRole.SCHEDULER
            break
        default:
            break
    }
    return { clinicalRole, contact_id }
}

export const initRoomDetails: IRoomDetails = {
    identity: { id: -1, name: "", uuid: "" }, locationId: -1, address: "",
    modality: "", modalityId: "", favourite: false, phoneNumber: "", disabled: false, roomStatus: ERoomStatus.UNKNOWN,
    presenceData: { presence: EUserPresence.OFFLINE, mapId: "" }, isConnecting: false, loggedInTech: { techName: "", techUuid: "" }, isRoomStarred: false,
    monitorsCount: 1
}

export const fetchRoomDetailsForDeviceTransformer = (data: any, prevRooms: IRoomDetails[]) => {
    const { roomsData } = data
    const rooms: IRoomDetails[] = []
    roomsData.map((item: any) => {
        const room: IRoomDetails = {
            identity: { id: -1, name: "", uuid: "" }, locationId: -1, address: "", roomStatus: ERoomStatus.UNKNOWN,
            modality: "", modalityId: "", favourite: false, phoneNumber: "", disabled: false, isRoomStarred: false,
            presenceData: { presence: EUserPresence.OFFLINE, mapId: "" }, isConnecting: false, loggedInTech: { techName: "", techUuid: "" },
            monitorsCount: 1, modalityConnection: []
        }
        room.isRoomStarred = false
        room.favourite = false
        room.isConnecting = false
        room.disabled = false
        room.address = item.location
        room.locationId = item.site_id
        room.modalityId = item.modality_id
        room.modality = item.modality
        room.phoneNumber = item.primary_phone
        room.identity.address = item.location
        room.identity.id = item.resource_id
        room.identity.name = item.resource_name
        room.identity.uuid = item.device_hsdp_uuid
        room.monitorsCount = item.monitorsCount
        room.modalityConnection = item.modality_connection
        if (prevRooms && prevRooms.length > 0) {
            const prevRoom = prevRooms.find(element => (element.identity.uuid === room.identity.uuid && room.identity.uuid !== ""))
            room.presenceData.presence = (prevRoom) ? prevRoom.presenceData.presence : EUserPresence.OFFLINE
            room.presenceData.mapId = (prevRoom) ? prevRoom.presenceData.mapId : ""
        }
        rooms.push(room)
    })
    return rooms
}

export const getRoomRelevantForCurrentUserTransformer = (data: any) => {
    const room: IRoomDetails = {
        identity: { id: -1, name: "", uuid: "" }, locationId: -1, address: "", roomStatus: ERoomStatus.UNKNOWN,
        modality: "", modalityId: "", favourite: false, phoneNumber: "", disabled: false, isRoomStarred: false,
        presenceData: { presence: EUserPresence.OFFLINE, mapId: "" }, isConnecting: false, loggedInTech: { techName: "", techUuid: "" },
        monitorsCount: 1, modalityConnection: []
    }
    const { deviceDetails } = data
    const sites: string[] = deviceDetails[0].sites.split(ROW_SEPERATOR)
    const modalities: string[] = deviceDetails[0].modality.split(",")
    room.identity.id = deviceDetails[0].resource_id
    room.identity.name = deviceDetails[0].resource_name
    room.identity.uuid = deviceDetails[0].device_uuid
    room.modalityId = modalities[0].split(COLUMN_SEPERATOR)[0]
    room.modality = modalities[0].split(COLUMN_SEPERATOR)[1]
    room.locationId = parseIntBase10(sites[0].split(COLUMN_SEPERATOR)[0])
    room.address = deviceDetails[0].resource_location ? deviceDetails[0].resource_location : ""
    room.phoneNumber = deviceDetails[0].resource_primary_phone ? deviceDetails[0].resource_primary_phone : ""
    room.monitorsCount = deviceDetails[0].monitorsCount
    room.modalityConnection = deviceDetails[0].modality_connection
    return room
}

export const fetchCustomerDetailsForAdminTransformer = (data: any) => {
    const customerMetaData: ICustomerMetadata = { id: -1, displayName: DEFAULT_CUSTOMER_NAME, name: DEFAULT_CUSTOMER_NAME, orgId: "", contacts: [] }
    try {
        if (data.metasites.length > 0) {
            const metasite = data.metasites[0]
            customerMetaData.id = metasite.id
            customerMetaData.displayName = metasite.name
            customerMetaData.name = metasite.metasite
        }
    } catch (error) {
        errorLogger(`Error occurred while fetching customer metadata: ${errorParser(error)}`)
    }
    return { customerMetaData }
}
