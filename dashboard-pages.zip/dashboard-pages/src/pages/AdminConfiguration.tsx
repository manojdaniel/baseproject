import React, { useRef, useState, useEffect } from "react";
import MenuContainer from "components/MenuContainer";
import AffiliateRollout from "./Admin/AffiliateRollout";
import PlantRollout from "./Admin/PlantRollout";
import { useNavigate, useLocation } from "react-router-dom";
import { Outlet } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import { getGlobalSearch } from "../redux/reducers/CommonReducer";

const ADMIN_MENU_DATA = [
	{ id: "RolloutNewAffiliate", value: "ROLLOUT NEW AFFILIATE" },
	{ id: "RolloutNewPlant", value: "ROLLOUT NEW PLANT" },
	{ id: "AsetModelConfig", value: "ASSET MODEL CONFIG" },
	{ id: "UserRoleMapping", value: "USER ROLE MAPPING" },
	{ id: "ExceptionMonitoring", value: "EXCEPTION MONITORING" },
];

const AdminConfiguration = () => {
	let navigate = useNavigate();
	const location = useLocation();
	let dispatch = useDispatch();

	const { loggedInUserDetails, globalSearchData, userRole } = useSelector(
		(state: any) => ({
			loggedInUserDetails: state.Common.loggedInUserDetails,

			globalSearchData: state.Common.globalSearchData,
			userRole: state.Common.userRole,
		})
	);

	// useEffect(() => {
	//     if (Object.keys(loggedInUserDetails).length > 0) {
	//         if (loggedInUserDetails.result.roleName === "Super Admin") {
	//             handleMenuClick(1)
	//         }
	//         else if (loggedInUserDetails.result.roleName === "Plant Admin") {
	//             handleMenuClick(3)
	//         }
	//     } else {
	//         handleMenuClick(0);
	//     }
	// }, []);

	useEffect(() => {
		if (location.pathname.split("/")[2] === undefined) {
			if (Object.keys(loggedInUserDetails).length > 0) {
				if (userRole === "Super Admin") {
					navigate("/admin/affiliateRollout");
				} else if (userRole === "Plant Admin") {
					navigate("/admin/assetModelConfig");
				}
			}
		}
	}, [location.pathname]);

	const [selectedID, setSelectedID] = useState();

	const [roleName, setRoleName] = useState("");

	const [adminMenuData, setAdminMenuData] = useState<any[]>([]);

	useEffect(() => {
		if (Object.keys(loggedInUserDetails).length > 0) {
			setRoleName(userRole);
			if (globalSearchData.length < 1) {
				dispatch(getGlobalSearch(""));
			}
		}
	}, [loggedInUserDetails]);

	useEffect(() => {
		if (roleName === "Super Admin") {
			let dte = [
				{ id: "AffiliateRollout", value: "ROLLOUT NEW AFFILIATE" },
				{ id: "PlantRollout", value: "ROLLOUT NEW PLANT" },
				{ id: "AssetModelConfig", value: "ASSET MODEL CONFIG" },
				{ id: "UserRoleMapping", value: "USER ROLE MAPPING" },
				{ id: "ExceptionMonitoring", value: "EXCEPTION MONITORING" },
			];
			setAdminMenuData(dte);
		} else if (roleName === "Plant Admin") {
			let dte = [
				{ id: "AssetModelConfig", value: "ASSET MODEL CONFIG" },
				{ id: "UserRoleMapping", value: "USER ROLE MAPPING" },
				{ id: "ExceptionMonitoring", value: "EXCEPTION MONITORING" },
			];
			setAdminMenuData(dte);
		}
	}, [roleName, loggedInUserDetails]);

	const handleMenuClick = (id: any) => {
		setSelectedID(id);
		switch (id) {
			// case 0:
			//     navigate('/admin');
			//     break;
			case "AffiliateRollout":
				navigate("/admin/affiliateRollout");
				break;
			case "PlantRollout":
				navigate("/admin/plantRollout");
				break;
			case "AssetModelConfig":
				navigate("/admin/assetModelConfig");
				break;
			case "UserRoleMapping":
				navigate("/admin/userRoleMapping");
				break;
			case "ExceptionMonitoring":
				navigate("/admin/exceptionMonitoring");
				break;

			default:
				break;
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	let updatedCurrentPath: any;

	try {
		let currentPathname =
			location.pathname.split("/")[2] !== undefined
				? location.pathname.split("/")[2]
				: "";
		updatedCurrentPath =
			currentPathname.charAt(0).toUpperCase() + currentPathname.slice(1);
	} catch (error) {}

	const getSelectedclassName = (id: any) =>
		updatedCurrentPath === id ? "active" : "notselected";
	return (
		<>
			<MenuContainer
				data={adminMenuData}
				handleMenuClick={handleMenuClick}
				getSelectedclassName={getSelectedclassName}
			/>
			<Outlet />
		</>
	);
};
export default AdminConfiguration;
