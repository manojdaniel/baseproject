"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.loggers.log import create_logger
from packaging import version

LOG = create_logger("Semver")


def parse_version(version_string):
    try:
        semver = version.parse(version_string)
        return semver
    except TypeError as ex:
        LOG.error(f"Parsing version failed with exception: {ex}")
