/*
 * Created on Thu Apr 28 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getIntlProvider } from "@rocc/rocc-global-components"
import React, { useEffect } from "react"
import { withRouter } from "react-router"
import { getFullApplicationName } from "../../utility/helpers/helpers"
import styles from "./RoomMonitoring.module.scss"
import en from "../../resources/translations/en-US"
import { BEFORE_UNLOAD, CCTV_WINDOW_CLOSE, UNLOAD } from "../../constants/constants"
import syncSessions from "../../redux/store/syncSessions"

const RoomMonitoringWindowFeature = React.lazy(() => import("roccConsole/RoomMonitoringWindowFeature").catch(() => false))

const RoomMonitoring = () => {
    const { intl } = getIntlProvider()

    useEffect(() => {
        syncSessions.postMessage({ type: CCTV_WINDOW_CLOSE, open: true })
        window.addEventListener(BEFORE_UNLOAD, function (e) {
            e.preventDefault()
            return e.returnValue = ""
        })
        window.addEventListener(UNLOAD, function (e) {
            syncSessions.postMessage({ type: CCTV_WINDOW_CLOSE, open: false })
            e.preventDefault()
            return ""
        })
    }, [])
    return (
        <>
            <div className={styles.roomMonitoringContainer} id={"roomMonitoring"}>
                <div className={styles.navHeader} >
                    <div className={styles.appName}>{getFullApplicationName()}</div>
                    <div className={styles.tabName}>{intl.formatMessage({ id: "content.camera.liveVideo", defaultMessage: en["content.camera.liveVideo"] })}</div>
                </div>
                <RoomMonitoringWindowFeature />
            </div>
        </>

    )
}
export default withRouter(RoomMonitoring)
