import React from 'react'
import { useNavigate } from "react-router-dom";
import {
    getLoggedInUserDetails
} from "../redux/reducers/CommonReducer";
import { useDispatch } from "react-redux";
import "../assets/common/notfound.scss"
import whatIsTheAssetHealthCareIllustration from '../assets/images/whatIsTheAssetHealthCareIllustration.svg';
import image_Sabic_Logo from '../assets/images/image_Sabic_Logo.svg';
import { BASE_URL } from '../utility/api';

function Logout() {
    const navigate = useNavigate();
    let dispatch = useDispatch();

    const handleLogin = () => {
        // dispatch(getLoggedInUserDetails(""));
        // navigate('/home', { replace: true })
        window.open(BASE_URL, "_self");
        window.close();
    }

    return (
        <div id="notfound">
            <div id="container">
                <div id="header">
                    <div className="header-inner">
                        <div className="logoname">ASSET HEALTH CARE</div>
                        <div className="rightside"><img src={image_Sabic_Logo} /></div>
                    </div>
                </div>
                <div id="content">
                    <div><img src={whatIsTheAssetHealthCareIllustration} /></div>
                    <h3>Your session has expired due to inactivity. Please click on login to continue</h3>
                    <div className='loginbutton' onClick={() => handleLogin()} style={{ cursor: 'pointer' }}>Login</div>
                </div>
            </div>

        </div>

    )
}

export default Logout