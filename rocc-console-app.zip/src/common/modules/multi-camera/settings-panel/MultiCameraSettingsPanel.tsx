/*
 * Created on Fri Dec 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { useSelector } from "react-redux"
import styles from "./MultiCameraSettingsPanel.scss"
import en from "../../../../resources/translations/en-US"
import React from "react"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { IStore } from "../../../../redux/interfaces/types"
import MultiCameraSettingsController from "../settings-controller/MultiCameraSettingsController"
import { dispatchToParentStore } from "../../../../redux/store/externalAppStates"
import { GLOBAL_LEFTSIDE_PANEL } from "../../../../redux/actions/types"
import { EConnectionType, IConsoleSession } from "@rocc/rocc-client-services"
import cx from "classnames"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"

const componentName = "MultiCameraSettingsPanel"

const MultiCameraSettingsPanel = () => {

    const {
        currentUserUuid,
        consoleSessions
    } = useSelector(
        (state: IStore) => ({
            currentUserUuid: state.externalReducer.currentUser.uuid,
            consoleSessions: state.consoleReducer.consoleSessions,
        }),
    )

    const getSideBarHeight = () => {
        const index = consoleSessions.findIndex((activeSession: IConsoleSession) => ![EConnectionType.VIEW].includes(activeSession.connectionType))
        return index === -1 ? styles.largeLeftPanel : styles.smallLeftPanel
    }

    const { intl } = getIntlProvider()

    return <div id={"multiCameraSettingsPanel"} className={cx(styles.multiCameraSettingsPanel, getSideBarHeight())}>
        <div className={styles.panelHeader}>
            <span className={styles.headerText}>
                {intl.formatMessage({ id: "content.room.cameraSettings", defaultMessage: en["content.room.cameraSettings"] })}
            </span>
            <span
                className={styles.closeIcon}
                onClick={() => {
                    sendLogsToAzure({ contextData: { component: componentName, event: "Camera settings off", Event_By: currentUserUuid }})
                    dispatchToParentStore({
                        type: GLOBAL_LEFTSIDE_PANEL,
                        payload: {
                            displayLeftSidePanel: false,
                            activeLeftPanel: "",
                            desktopFullScreen: false,
                        }
                    })
                }}
            >
                <i className="icon Cross huge" />
            </span>
        </div>
        <div className={styles.subHeader}>
            {intl.formatMessage({ id: "content.room.selectCameras", defaultMessage: en["content.room.selectCameras"] })}
        </div>
        <MultiCameraSettingsController />
    </div>
}
export default MultiCameraSettingsPanel
