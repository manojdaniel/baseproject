/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, EAppStates, EConnectionStatus, IUserInfo, DEFAULT_PERMISSION_LIST, EAppContext } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { DEFAULT_ONGOING_CALL_DETAILS } from "../../common/constants/constants"
import { SYNC_CALL_REDUCERS_CALL_DETAILS, SYNC_PARENT_REDUCERS } from "../actions/types"
import { IExternalReducer } from "../interfaces/types"
import { getRoomInfoDetails, getWorkflowInfo } from "../transformer/consoleTransformer"

const INIT_CURRENT_USER_PROFILE: IUserInfo = {
    ...DEFAULT_CONTACT_INFO, accessTokenExpiryTime: "",
    accessToken: "", onBoarded: false, locale: "", sessionId: "",
}

export const initialStateForExternalReducer: IExternalReducer = {
    currentUser: INIT_CURRENT_USER_PROFILE,
    permissions: DEFAULT_PERMISSION_LIST,
    notificationMessage: {
        message: [{
            header: "",
            content: ""
        }],
        isSuccess: false,
        isWarning: false,
        isNotification: false,
        showNotification: false,
        closeMessage: () => { return false },
    },
    applicationConnectionState: EConnectionStatus.ONLINE,
    notificationModal: {
        showModal: false,
        modalContent: "",
        header: "",
        showCloseIcon: false,
    },
    rooms: [],
    featureFlags: {},
    activeTabIndex: -1,
    displayRightSidePanel: false,
    displayLeftSidePanel: false,
    desktopFullScreen: false,
    callDetails: {
        videoCallStatus: [],
        connectedCallDetails: DEFAULT_ONGOING_CALL_DETAILS,
        onHoldCallDetails: [],
    },
    forceCleanUp: false,
    workflows: [],
    appState: EAppStates.INIT,
    appContext: EAppContext.DEFAULT,
}

const externalReducer: Reducer = (state: IExternalReducer = initialStateForExternalReducer, action: any) => {
    switch (action.type) {
        case SYNC_PARENT_REDUCERS: {
            const { currentUser, permissions, applicationConnectionState, rooms, notificationMessage, notificationModal, featureFlags, activeTabIndex, displayLeftSidePanel, displayRightSidePanel, desktopFullScreen, forceCleanUp, workflows, appState, appContext } = action.payload
            const updatedRooms = getRoomInfoDetails(rooms)
            const updatedWorkflows = getWorkflowInfo(workflows)
            return { ...state, currentUser, permissions, applicationConnectionState, rooms: updatedRooms, notificationMessage, notificationModal, featureFlags, activeTabIndex, displayLeftSidePanel, displayRightSidePanel, desktopFullScreen, forceCleanUp, workflows: updatedWorkflows, appState, appContext }
        }
        case SYNC_CALL_REDUCERS_CALL_DETAILS: {
            const { videoCallStatus, connectedCallDetails, onHoldCallDetails } = action.payload
            return { ...state, callDetails: { ...state.callDetails, videoCallStatus, connectedCallDetails, onHoldCallDetails } }
        }
        default:
    }
    return { ...state }
}

export default externalReducer
