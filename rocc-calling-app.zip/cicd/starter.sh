#!/bin/bash

if [ "$#" -ne 8 ]; then
    echo "ERROR: Invalid number of arguments passed! Expected 8 arguments"
    echo """
    Arguments:
    1. DEPLOY_MODE: cloud/local
    2. DOCKER_REPO: Docker Registry name with path
    3. IMAGE_TAG: Image tag that you wish to provide
    4. CF_USERNAME_USR: CF user name
    5. CF_DOCKER_PASSWORD: CF docker password
    6. CODE1_ID: Code1 ID
    7. CODE1_EMAIL: Code1 EmailID
    8. CODE1_PASSWORD: Code1 Password
    Run in the following format:
    bash starter.sh <DEPLOY_MODE> <DOCKER_REPO> <IMAGE_TAG> <CF_USERNAME_USR> <CF_DOCKER_PASSWORD> <CODE1_ID> <CODE1_PASSWORD> <CODE1_EMAIL>

    Ex: bash starter.sh cloud docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips latest $CF_USERNAME_USR "$CF_DOCKER_PASSWORD" $CODE1_ID $CODE1_EMAIL $CODE1_PASSWORD
    Ex: bash starter.sh local docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips latest $CF_USERNAME_USR "$CF_DOCKER_PASSWORD" $CODE1_ID $CODE1_EMAIL $CODE1_PASSWORD
"""
    exit 1
fi
if [[ $1 != local ]] && [[ $1 != cloud ]]; then
    echo "ERROR: DEPLOY_MODE should be either: 'local' or 'cloud'"
    exit 1
fi

DEPLOY_MODE=$1
DOCKER_REPO=$2
IMAGE_TAG=$3
CF_USERNAME_USR=$4
CF_DOCKER_PASSWORD=$5
CODE1_ID=$6
CODE1_EMAIL=$7
CODE1_PASSWORD=$8
IMAGE_NAME=rocc-mfe-ui-image
APP_NAME=rocc-mfe-ui-app
CICD_FOLDER=cicd
MANIFEST_FILE=manifest_cf.yaml
VARS=vars_clienttest_us-east.yaml
SEP="====================================="

echo "Building $APP_NAME client"

currentDir=$(pwd)

echo "Processing in directory : {$currentDir}"
cd ../client

echo $SEP
echo "Building $APP_NAME"
echo $SEP

npm install
sleep 15
npm run build

echo $SEP
echo "Copying required content to $CICD_FOLDER folder"
echo $SEP

cp -r dist ../$CICD_FOLDER

echo $SEP
echo "Building $APP_NAME docker image"
echo $SEP
cd ../$CICD_FOLDER
docker build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy -t $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG .
echo "Removing content from $CICD_FOLDER folder"
rm -rf dist 

if [[ $1 == local ]]; then
    echo "Staring docker container"
    docker-compose up -d
    echo "You can access app at: http://localhost:5006/"
    echo $SEP
fi

if [[ $DEPLOY_MODE == cloud ]]; then
    echo $SEP
    echo "Pushing docker image"
    docker push $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG
    echo $SEP
    echo "Cleaning up local docker image after push to registry"
    docker rmi $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG
    echo $SEP
    echo "Pushing cf app and starting it"
    CF_DOCKER_PASSWORD=$CF_DOCKER_PASSWORD cf push $APP_NAME -f $MANIFEST_FILE -m 512M --docker-image $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG --docker-username $CF_USERNAME_USR --vars-file $VARS
    echo $SEP
fi
echo "$APP_NAME app UI setup completed"
echo $SEP
