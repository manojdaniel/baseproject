import unittest

from src.utility.utility import construct_negative_response
from src.exceptions.RoccException import RoccException


class RoccExceptionTestCases(unittest.TestCase):
    def setUp(self) -> None:
        self.ex = RoccException(status_code=400, title="title", payload="payload", additional_info="info")

    def test_rocc_exception_to_dict(self):
        self.setUp()
        self.assertEqual(self.ex.to_dict(), construct_negative_response(400, "title", "payload", "info"))
