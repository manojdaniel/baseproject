# import statements

import json
import os

# Read the Previous String Count

track_file = open("string_count_check.json", "r")
track_previous_string_count = json.load(track_file)
track_file.close()
print("previous_strings_count %s"% track_previous_string_count['previous_strings_count'])

# Read the Current String Count

us_file = open(os.environ['WORKSPACE'] + "/en_US.json", "r", encoding="utf8")
track_current_string_count = json.load(us_file)
us_file.close()
print("current_strings_count %s"% len(track_current_string_count))

# Compare the string count and update the file

if len(track_current_string_count) <= track_previous_string_count['previous_strings_count']:
    track_previous_string_count['status'] = "true"
    update_file = open("string_count_check.json", "w")
    json.dump(track_previous_string_count, update_file)
    update_file.close()    
else:
    track_previous_string_count['previous_strings_count'] = len(track_current_string_count)
    track_previous_string_count['status'] = "false"
    update_file = open("string_count_check.json", "w")
    json.dump(track_previous_string_count, update_file)
    update_file.close()