"""
 Created on Fri Dec 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os

from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import BB_BOXILLA_IP, BB_BOXILLA_USER, BOXILLA_REST_USER_PASS_VALUE, BOXILLA_USER_PASS_VALUE, DATA
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data, post_vault_values_for_path
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.management_service.manage_redis_services import update_key_in_redis_for_org

LOG = create_logger("ConfigurationServices")


class ConfigService(object):

    def __init__(self, vault_path, service_user_uuid):
        """ Use parent org_id, since update can happen for both Customer and Global configurations """
        self._profile_configs = get_profile_data()
        self._org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
        self._parent_service_token = self.fetch_service_token()
        self._service_user_uuid = service_user_uuid
        self._vault_path = vault_path

    def fetch_service_token(self):
        try:
            token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                    issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                    private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            return token

        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!")

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_id:
            try:
                prepare_and_post_audit(event_type="Manage Configurations", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_id, token=self._parent_service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.warning(f"Audit logging failed with error: {ex}")

    def fetch_config_data_for_path(self):
        try:
            vault_values = get_path_specific_vault_values(path_name=self._vault_path)
            return {"data": vault_values[DATA]}, 200
        except Exception as ex:
            LOG.exception(f"Failed to fetch configurations for path: {self._vault_path} with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload=f"Failed to fetch configurations for path: {self._vault_path}")

    def update_config_data(self, key, value, redis_path=None):
        try:
            vault_values = get_path_specific_vault_values(path_name=self._vault_path)

            present = key in vault_values[DATA]
            if not present:
                LOG.error(f"Key: {key} is not present in path: {self._vault_path}")
                raise RoccException(status_code=400,
                                    title="400 Bad request",
                                    payload=f"Key: {key} is not present in path: {self._vault_path}")
            LOG.info(f"Vault data for path: {self._vault_path} before update is: {vault_values[DATA]}")
            vault_values[DATA][key] = value

            post_vault_values_for_path(path=self._vault_path, body=vault_values[DATA])
            self.safe_audit(event_subtype="Config data updation in vault", action="U", outcome="0", code=f"Config update for path: {self._vault_path}", value="Success")
            if redis_path is not None and self.check_if_redis_update_required_or_not(key=key):
                update_key_in_redis_for_org(url=os.environ.get("ROCC_PROXY_URL"),
                                            token=self._parent_service_token,
                                            org_id=redis_path,
                                            key=key,
                                            value=value)
                self.safe_audit(event_subtype="Config data updation in redis", action="U", outcome="0", code=f"Config update for path: {self._vault_path}", value="Success")
            LOG.info(f"Successfully updated configurations data for path: {self._vault_path}")
            new_vault_values = get_path_specific_vault_values(path_name=self._vault_path)
            return {"message": "Successfully updated configurations data", "data": new_vault_values[DATA]}, 200
        except Exception as ex:
            LOG.exception(f"Failed to update configurations for path: {self._vault_path} with error: {ex}")
            self.safe_audit(event_subtype="Config data updation in vault/redis", action="U", outcome="8", code=f"Config update for path: {self._vault_path}", value="Failed")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload=f"Failed to update configurations for path: {self._vault_path}")

    def check_if_redis_update_required_or_not(self, key):
        vault_key_lists = [BB_BOXILLA_IP, BB_BOXILLA_USER, BOXILLA_REST_USER_PASS_VALUE, BOXILLA_USER_PASS_VALUE]
        if key in vault_key_lists:
            LOG.info("Skipping redis update for the key {} as the key is not present in redis".format(key))
            return False
        else:
            return True
