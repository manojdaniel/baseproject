export interface INavBar {
  appName: string
  appVersion: string
  userName?: string
  appSwitcher?: boolean
  primaryMenuItems?: Array<INavMenu>
  searchIcon?: boolean
  statusIcon?: boolean
  notificationIcon?: boolean
  notificationValue: string
  settingsIcon?: boolean
  aboutIcon?: boolean
  secondaryMenuItems: Array<INavMenu>
  isMobile?: boolean
  useAppNameLink?: boolean
  appNameLink?: string
}

export enum EMenuTypes {
  dropdown,
  menu,
  icon,
}

export interface INavMenu {
  type: EMenuTypes | string
  label: string
  items: Array<INavMenuItem>
}

export interface INavMenuItem {
  text: string
  target?: string
  as?: React.ReactNode
  to?: string | null
  onClick?: () => void
}
