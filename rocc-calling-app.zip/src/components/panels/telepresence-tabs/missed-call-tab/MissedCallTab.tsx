/*
 * Created on Wed Sep 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { getActiveStyles } from "../../../../common/helpers/helpers"
import { ESidePanelTabs } from "../../../../types/types"
import styles from "./MissedCallTab.scss"
import cx from "classnames"
import MissedCallPanel, { IMissedCallPanel } from "../../../missed-call-panel/MissedCallPanel"

const MissedCallTab = (props: IMissedCallPanel) => {

  const { activeItem } = props

  const activeStyle = getActiveStyles(activeItem, ESidePanelTabs.MissedCalls)

  return <div className={cx(styles.missedCallTab, activeStyle)} id={"missedCallTab"}>
    <MissedCallPanel {...props} />
  </div>
}

export default MissedCallTab
