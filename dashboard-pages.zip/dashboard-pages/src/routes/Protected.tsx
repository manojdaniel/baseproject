import React, { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import {
	getLoggedInUserDetails
} from "../redux/reducers/CommonReducer";
import { useDispatch, useSelector } from "react-redux";

function Protected({ role, children }) {
	let dispatch = useDispatch();
	const [signedIn, setSignedIn] = useState<any>(false);
	const { loggedInUserDetails, userRole
	} = useSelector((state: any) => ({
		loggedInUserDetails: state.Common.loggedInUserDetails,
		userRole: state.Common.userRole,

	}));

	useEffect(() => {
		if (Object.keys(loggedInUserDetails).length < 1) {
			dispatch(getLoggedInUserDetails(""))
		}
	}, [loggedInUserDetails]);


	if (Object.keys(loggedInUserDetails).length > 0) {

		if (loggedInUserDetails.statusCode === 200) {
			if (loggedInUserDetails.message === "User Found") {
				if (role === "user") {
					return children;
				}
				else if (role === "Plantadmin") {
					// alert(loggedInUserDetails.result.roleName)
					if (userRole === "Plant Admin" || userRole === "Super Admin") {
						return children;
					}
					else {
						return <Navigate to="/notfound" replace />
					}
				}
				else if (role === "Superadmin") {
					if (userRole === "Super Admin") {
						return children;
					}
					else {
						return <Navigate to="/notfound" replace />
					}
				}
				else if (role === "onePlantUser") {
					if (loggedInUserDetails.result.onePlantUser !== 1) {
						return children;
					}
					else {
						return <Navigate to="/notfound" replace />
					}
				}
				else if (role === "oneAffiliateUser") {
					if (loggedInUserDetails.result.oneAffiliateUser !== 1) {
						return children;
					}
					else {
						return <Navigate to="/notfound" replace />
					}
				}
			}
			else {
				return <Navigate to="/notfound" replace />
			}
		}
		else {
			return <Navigate to="/notfound" replace />
		}
	}
}
export default Protected