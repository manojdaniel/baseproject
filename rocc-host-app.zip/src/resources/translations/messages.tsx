/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import en_US from "./en-US"
import fr_FR from "./fr-FR"
import en_GB from "./en-GB"
import de_DE from "./de-DE"
import nl_NL from "./nl-NL"

const messages: any = {
    "en-US": en_US,
    "fr-FR": fr_FR,
    "en-GB": en_GB,
    "de-DE": de_DE,
    "nl-NL": nl_NL,
    "en-AU": en_US
}

export default messages
