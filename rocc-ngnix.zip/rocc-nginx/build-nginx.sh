#!/bin/bash

echo "Building Nginx Server"
docker build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy -t docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-demo/philips/rocc-nginx-server .

echo "Pushing Nginx Server image to docker registry"
docker push docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-demo/philips/rocc-nginx-server

