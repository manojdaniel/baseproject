/*
 * Created on Fri May 21 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, ERoccWorkflow, EUserPresence, IContactInfo } from "@rocc/rocc-client-services"

/* DB query seperators */
export const SECOND_POSITION = 2
export const THIRD_POSITION = 3
export const FOURTH_POSITION = 4
/**TODO: Use a common seperator */
export const ROW_SEPERATOR = "~"
export const COLUMN_SEPERATOR = ":"
export const DEFAULT_CUSTOMER_NAME = "IDN/Hospital Name"

/* General constants */
export const TELEPRESENCE_SIDEBAR = "TelepresenceSidebar"
export const MULTI_CAMERA_SETTINGS_SIDEBAR = "MultiCameraSettingsSidebar"
export const TERMS_AND_CONDITIONS = "terms_and_conditions"
export const DEFAULT_PRESENCE_UPDATE_TIMEOUT = "5000"
export const applicationName = "Radiology Operations Command Center"
export const companyName = "Philips"

/* Log constants */
export const ERROR = "ERROR"
export const WARNING = "WARNING"
export const INFO = "INFO"
export const DEBUG = "DEBUG"

/* FSE related constants */
export const APP_URL_BASENAME = "-rocc.cloud.pcftest.com"
export const FSE_ADMIN_GROUP = "AdminGroup"

/* Onboarding constants */
export const ONBOARDING_WELCOME_VIDEO = "https://rocc.file.core.windows.net/rocc/Videos/Philips_ROCC_Onboarding_Video_1.0.mp4?st=2020-10-09T11%3A37%3A48Z&se=2040-10-10T11%3A37%3A00Z&sp=rl&sv=2018-03-28&sr=f&sig=9XDfFPxLsnZv4cDmuTAaxId3cOrJu4siawYWy%2B0XU9A%3D"

/* Global Store */
export const APP_NAME = "CC_HOST"
export const CALLING_APP_STORE = "CC_CALLING"
export const STORAGE_KEY = "REDUX_STATE"
export const CONSOLE_APP_STORE = "CC_CONSOLE"

/** API Constants */
export const ACCEPT = "Accept"
export const APPLICATION_JSON = "application/json"
export const CONTENT_TYPE = "Content-Type"
export const AUTHORIZATION = "Authorization"
export const API_VERSION = "api-version"
export const DEFAULT_API_VERSION = "1.0.0"
export const API_VERSION_1_1_0 = "1.1.0"
export const API_VERSION_2 = "2.0.0"
export const ORG_CONTEXT_TEXT = "org_ctxt_header"//should remove later
export const DUMMY_LOGIN_USERNAME = "abc@abc.com"
export const CHAT = "CHAT"
export enum HTTP_STATUS {
    OK = 200,
    CREATED = 201,
    UNAUTHORIZED = 401,
    BAD_REQUEST = 400,
    FORBIDDEN = 403,
    INTERNAL_SERVER_ERROR = 500,
}

export const ONBOARDING_STEPS = {
    WELCOME: "Welcome",
    AGREEMENT: "End User License Agreement",
    COMPLETE: "Complete",
}

export const displayLoginErrorMessages = {
    WRONG_USER_CREDENTIALS: "WRONG_USER_CREDENTIALS",
    DEFAULT_MESSAGE: "DEFAULT_MESSAGE",
    NETWORK_CONNECTIVITY: "NETWORK_CONNECTIVITY",
    FORBIDDEN: "FORBIDDEN",
    REQUEST_PROCESSING_FAILED: "REQUEST_PROCESSING_FAILED"
}

export enum EDbRole {
    EXPERTUSER_ROLE = "expertuserrole",
    EXPERTUSER_WITH_INCOGNITO_ROLE = "expertuserincognitorole",
    PROTOCOL_MANAGER_ROLE = "protocolmanagerrole",
    ADMIN_ROLE = "adminrole",
    TECHNOLOGIST_ROLE = "technologistrole",
    RADIOLOGIST_ROLE = "radiologistrole",
}

export enum ERbacRole {
    EXPERTUSER_ROLE = "Expert User",
    EXPERTUSER_WITH_INCOGNITO_ROLE = "Expert User (Incognito Function)",
    PROTOCOL_MANAGER_ROLE = "Expert User (Protocol Manager Function)",
    ADMIN_ROLE = "Admin",
    TECHNOLOGIST_ROLE = "Technologist",
    RADIOLOGIST_ROLE = "Radiologist",
}

/* Push Notification Constants */
export const PUSH_NOTIFICATION_SERVER_KEY = "BDxSCHB16lkJvZgTrOdI4yEe6dnI1uNSxU5Qvj2am0aqgxn-fuVbLgD97mCArRkpaBm6-0s9xRDbGIw0yLK8XP4"

export const subscriptionErrorMessages = {
    orgMismatchErrorMessage: "User Subscribers dont't belong to same Org",
}

export const TABID = "tabId"

/** Common Constants */
export const BEFORE_UNLOAD = "beforeunload"
export const UNLOAD = "unload"
export const RELOAD = "reload"
export const TRUE = "true"

export const DEFAULT_FEATURES_VALUES = {
    CONSOLE_VIEW: false,
    CONSOLE_VIEW_INCOGNITO: false,
    CONSOLE_EDIT: false,
    CONSOLE_EDIT_WITHOUT_AUTHORIZATION: false,
    CALL_VIDEO_CALL: false,
    CALL_DESKTOP_FULL_SCREEN: false,
    CALL_WEB_TO_WEB: false,
    CALL_WEB_TO_PHONE: false,
    CALL_ADD_PARTICIPANT: false,
    CALL_HYBRID_ROCC_CALL: false,
    ADMIN_USER_ADD: false,
    ADMIN_USER_EDIT: false,
    ADMIN_USER_READ: false,
    ADMIN_USER_DELETE: false,
    ADMIN_LOCATION_ADD: false,
    ADMIN_LOCATION_EDIT: false,
    ADMIN_LOCATION_DELETE: false,
    ADMIN_LOCATION_READ: false,
    ADMIN_ROOM_ADD: false,
    ADMIN_ROOM_EDIT: false,
    ADMIN_ROOM_DELETE: false,
    ADMIN_ROOM_READ: false,
    ADMIN_MODALITY_ADD: false,
    CONSOLE_DEMO_VIDEO_ENABLED: false,
    RESOURCE_STARRED_ROOMS: false,
    CALL_CONTACT_SPEED_DIAL: false
}

/** MFE Modules and URLs */
export const RAD_CONNECT_APP_TITLE = "Philips RadConnect"
export const RAD_CONNECT_RAD_APP = "RAD_CONNECT_RAD_APP"
export const RAD_CONNECT_TECH_APP = "RAD_CONNECT_TECH_APP"
export const ROCC_PHARMA_APP = "roccPharma"
export const ROCC_ADMIN_APP = "roccAdmin"
export const SELF_SERVICE_HOME_APP = "selfServiceHomeApp"
export const ROCC_SCHEDULER_APP = "roccScheduler"
export const RAD_CONNECT_RAD_APP_REMOTE_ENTRY = "app/consults/rad/remoteEntry.js"
export const RAD_CONNECT_TECH_APP_REMOTE_ENTRY = "app/consults/tech/remoteEntry.js"
export const ROCC_PHARMA_APP_REMOTE_ENTRY = "app/pharma/remoteEntry.js"
export const ROCC_ADMIN_APP_REMOTE_ENTRY = "app/admin/remoteEntry.js"
export const SELF_SERVICE_HOME_APP_REMOTE_ENTRY = "app/self-service-home/remoteEntry.js"
export const ROCC_SCHEDULER_APP_REMOTE_ENTRY = "app/scheduler/remoteEntry.js"

export const CONSOLE_REDUCER_DATA = {
    consoleReducer: {
        consoleOperation: { transactions: [] },
        consoleSessions: [],
        commandCenterDetails: { initilised: "" }
    },
    protocolTransferReducer: {
        protocolTransferStatus: true,
        selectedSource: "1",
        selectedDestination: "2",
        currentStep: 2,
    },
}

export const CALLING_REDUCER_DATA = {
    callReducer: {
        phoneCallStatus: "connected",
        videoCallStatus: [],
        missedCalls: []
    }
}

export const SIEMENS = "Siemens"
export const GE = "GE"
export const DEFAULT_LOCAL_VALUE = { locale: "en-US" }
export const INIT_CONFIG_DATA = {
    language: "",
    locales: [""],
    preferredLocale: "",
    theme: "Default"
}

export const APP_VERSION = "ROCC_VERSION"
export const DEFAULT_CONTACT: IContactInfo = {
    id: "",
    uuid: "",
    name: "",
    email: "",
    status: EUserPresence.OFFLINE,
    clinicalRole: EClinicalRole.DEFAULT,
    allRoles: [],
    orgId: "",
    phoneNumber: "",
    siteId: [],
    roomName: "",
    modalities: [],
    secondaryName: "",
    secondaryUUID: "",
    description: ""
}

export const UPDATE_PHONE_CALL_STATUS = "UPDATE_PHONE_CALL_STATUS"
export const NATIVE_APP = "NATIVE_APP"
export const TECH_DESKTOP_APP_INSTALLER = "TECH_DESKTOP_APP_INSTALLER"

/*PDF Viewer Constants */
export const PDF_VIEWER_SERVICE_WORKER = "https://unpkg.com/pdfjs-dist@2.10.377/build/pdf.worker.min.js"
export const BUFFER_TIME_MINUTES = 3

export const DEFAULT_SIGNALING_REGION = "gll"
export const DEFAULT_EDGE_LOCATION = "roaming"

/*CLI parameters constants **/
export const MANAGE_GRAPHQL_MUTATION_EP = "/data/Graphql"
export const MANAGE_GRAPHQL_BUNDLE_INFOS_EP = `${MANAGE_GRAPHQL_MUTATION_EP}/UserBundleInfos`
export const NFCC_BUNDLE_VERSION = "NFCC_BUNDLE_VERSION"
export const MANAGEMENT_SERVICE_URL = "MANAGEMENT_SERVICE_URL"
export const UPDATER_NAME = "Updater"
export const API_ENDPOINT = "apiEndpoint"
export const API_METHOD = "apiMethod"
export const API_VERSION_STRING = "apiVersion"
export const ORG_ID = "orgId"
export const BUNDLE_NAME = "bundleName"
export const BUNDLE_VERSION = "bundleVersion"
export const DOWNLOAD_URL = "downloadUrl"

/** NavBar Constants */
export const LIVE_VIDEO_INDEX = 0
export const PROTOCOL_TRANSFER_ICON_INDEX = 1
export const CALL_ICON_INDEX = 2
export const SETTINGS_ICON_INDEX = 3
export const SUPPORT_ICON_INDEX = 4
export const HELP_DROPDOWN_INDEX = 5
export const LEAVE_PROTOCOL_TRANSFER = "LeaveProtocolTransferConfirmDlg"
export const MASTER_LAYOUT = "MasterLayout"
export const MENU_TYPE = "menu"
export const DROPDOWN_TYPE = "dropdown"

export const CONFIG_WITHOUT_HARDWARE = "WITHOUT_HARDWARE"

export const DISPLAY_PARK_MODAL = "DISPLAY_PARK_MODAL"
export const CONFIRM = "CONFIRM"
export const CANCEL = "CANCEL"
export const FAILED = "FAILED"
export const HOST_LOGGED_OUT = "HOST_LOGGED_OUT"
export const LOGOUT_FAILED = "LOGOUT_FAILED"
export const FINISHED = "FINISHED"

export const { PARK_AND_INITIATE_CALL, PARK_AND_START_EDITING, PARK_AND_RESUME, MULTI_EDIT_INITIATE_CALL, MULTI_EDIT_START_EDITING, DISCONNECT_CALL, DISCONNECT_CONSOLE_SESSION, LOGOUT } = ERoccWorkflow

export const TRACKED_WORKFLOWS = [
    PARK_AND_INITIATE_CALL,
    PARK_AND_START_EDITING,
    PARK_AND_RESUME,
    MULTI_EDIT_INITIATE_CALL,
    MULTI_EDIT_START_EDITING,
    DISCONNECT_CALL,
    DISCONNECT_CONSOLE_SESSION,
    LOGOUT
]
export const LOCALHOST = "localhost"
export const CC_PATH = "/cc/"
export const CCTV_WINDOW_FEATURES = "toolbar=no,menubar=no,scrollbars=yes,dialog=yes,resizable=no,top=500,left=250,width=1920,height=1080"
export const CCTV_WINDOW_CLOSE = "CCTV_WINDOW_CLOSE"

export const REMOTE_LOAD_FAIL_MSG_SUB_STR = `In app: ${APP_NAME}, failed to load`

export const LANGUAGES = {
    ENGLISH: { TEXT: "English", LOCALE: "en-US" },
    FRENCH: { TEXT: "French", LOCALE: "fr-FR" },
    GREAT_BRITAIN: { TEXT: "Great Britain", LOCALE: "en-GB" },
    GERMAN: { TEXT: "German", LOCALE: "de-DE" }
}

export const MILLISECONDS_TO_SECONDS = 1000
export const SECONDS_TO_MINUTES = 60
export const TOKEN_ABOUT_TO_EXPIRE_TIME = 5 * SECONDS_TO_MINUTES * MILLISECONDS_TO_SECONDS
export const MINIMUM_EXPIRE_TIME_DIFFERENCE = 10 * SECONDS_TO_MINUTES * MILLISECONDS_TO_SECONDS
export const DEFAULT_TOKEN_EXPIRY_TIME = 20 * SECONDS_TO_MINUTES * MILLISECONDS_TO_SECONDS

export const HASH_REDIRECT = "redirect"
export const HASH_JWT = "hash"

export const ALL_ROOMS_TAB_KEY = ""

/*TODO: Replace constant with config value for away time */
export const USER_AWAY_TIMEOUT = 5 * 60 * 1000

export const TRACKER_ROLE_NAME = "ROCC UI Application"
export const TRACKER_ROLE_INSTANCE = "ROCC UI Application Instance"
