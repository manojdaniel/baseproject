import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../assets/common/CommonTables.scss";

interface Props {
	data: any[];
	handleUpdate;
}
// const EmployeeTable = ({ data, handleUpdate }: Props) => {
const EmployeeTable = ({ data, handleUpdate }: Props) => {
	// Data Formate work :Start
	const [employeeTableData, setEmployeeTableData] = useState<any>();
	useEffect(() => {
		let mydata = data.map(function (item: any, index: any) {
			return {
				key: index + 1,
				employeeID: item.employeeID,
				employeeName: item.employeeName,
				employeeEmail: item.employeeEmail,
				department: item.department,
				contactNo: item.contactNo,
				location: item.location
			};
		});
		setEmployeeTableData(mydata);
	}, [data]);

	// Data Formate work :End

	const columns = [
		{
			title: "Employee ID",
			dataIndex: "employeeID",
			key: "employeeID",
			width:"25%",
		},
		{
			title: "Employee Name",
			dataIndex: "employeeName",
			key: "employeeName",
			width:"25%",
		},
		{
			title: "Email",
			dataIndex: "employeeEmail",
			key: "employeeEmail",
			width:"25%",
		},
		{
			title: "Department",
			dataIndex: "department",
			key: "department",
			width:"25%",
		},
	];
	const rowSelection = {
		onChange: (selectedRowKeys, selectedRows) => {
			let selectedRowData = selectedRows[0];
			handleUpdate(
				selectedRowData.employeeID,
				selectedRowData.employeeName,
				selectedRowData.employeeEmail,
				selectedRowData.contactNo,
				selectedRowData.location,
				selectedRowData.department,
			);
		},
		getCheckboxProps: (record) => ({
			disabled: record.employeeName === "Disabled User",
			employeeName: record.employeeName,
		}),
	};
	return (
		<div>
			<Table
				columns={columns}
				dataSource={employeeTableData}
				pagination={false}
				rowSelection={{
					type: "radio",
					...rowSelection,
				}}
				scroll={{x:true, y: 200 }}
			/>
		</div>
	);
};
export default EmployeeTable;
