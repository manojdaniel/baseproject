/*
 * Created on Wed Oct 21 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import UnauthorizedComponent from "./UnauthorizedComponent"

describe("UnauthorizedComponent component", () => {
    let wrapper: any
    let unauthorizedComponentId: any
    beforeEach(() => {
        wrapper = shallow(<UnauthorizedComponent />)
        unauthorizedComponentId = wrapper.find("#UnauthorizedComponent")
    })
    it("should render with the correct id", () => {
        expect(unauthorizedComponentId).toHaveLength(1)
    })
})
