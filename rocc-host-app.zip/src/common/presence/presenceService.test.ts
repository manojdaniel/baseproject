/*
 * Created on Thu Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { DEFAULT_CONTACT_INFO, EClinicalRole, EIdlePermissionState, IUserInfo } from "@rocc/rocc-client-services"
import { subscriptionErrorMessages } from "../../constants/constants"
import { updateMetasiteIdForCurrentUser } from "../../redux/actions/userAction"
import * as apiUtility from "../../utility/api/apiUtility"
import * as presenceService from "./presenceService"

describe("fetchCommunicationClientDetails tests", () => {
    it("should return with OK response", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve({ status: 200, data: { twillioAccessToken: "twillioAccessToken", channelSid: "channelSid"}, headers: {}, statusText: "OK", config: {}}))
        presenceService.fetchCommunicationClientDetails("url", "token", "userId")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })

    it("should return with Error response", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockImplementation(() => {throw new Error()})
        presenceService.fetchCommunicationClientDetails("url", "token", "userId")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })
})

describe("updatePresenceService tests", () => {
    const dispatch = jest.fn()
    const mockState = jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {
                onBoarded: false,
                uuid: ""
            },
            contacts: [{
                uuid: "wewe-uas730-eaersd"
            }]
        },
        appReducer: {
            loadTimes: {
                loginClick: Date
            }
        }
    })
    const currentUser: IUserInfo = { ...DEFAULT_CONTACT_INFO, uuid: "uuid", accessToken: "accessToken", accessTokenExpiryTime: "", onBoarded: true, sessionId: "sessionId", locale: "en-US"}
    const presenceType = EUserPresence.AVAILABLE

    it("should dispatch an action to UPDATE_CURRENT_USER", () => {
        expect(updateMetasiteIdForCurrentUser("testName", EClinicalRole.EXPERTUSER)(dispatch, mockState)).toBeDefined()
    })
    
    it("should return with OK response", async () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve({ status: 200, data: { twillioAccessToken: "twillioAccessToken", channelSid: "channelSid" }, headers: {}, statusText: "OK", config: {} }))
        presenceService.updatePresenceService(currentUser, presenceType, "communicationServiceUrl", "userId", "", true)
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })

    it("should return with Error response", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockImplementation(() => { throw new Error() })
        presenceService.updatePresenceService(currentUser, presenceType, "communicationServiceUrl", "userId", "", true)
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })

    it("should skip presence update", () => {
        currentUser.status = presenceType
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve({ status: 200, data: { twillioAccessToken: "twillioAccessToken", channelSid: "channelSid" }, headers: {}, statusText: "OK", config: {} }))
        presenceService.updatePresenceService(currentUser, presenceType, "communicationServiceUrl", "uuid", "", false)
        expect(spy).toBeCalledTimes(0)
        spy.mockClear()
    })
})

describe("getSubscriptionsService tests", () => {
    it("should return with OK response", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve({ status: 200, data: [{ "interested_identity": "interested_identity", syncMapId: "syncMapId"}], headers: {}, statusText: "OK", config: {} }))
        presenceService.getSubscriptionsService("accessToken", "uuid", "presenceSuburl")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })

    it("should return with Error response", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockImplementation(() => { throw new Error() })
        presenceService.getSubscriptionsService("accessToken", "uuid", "presenceSuburl")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })
})

describe("updateSubscriptionsService tests", () => {
    it("should return with OK response", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve({ status: 200, data: [{ "interested_identity": "interested_identity", syncMapId: "syncMapId" }], headers: {}, statusText: "OK", config: {} }))
        presenceService.updateSubscriptionsService("accessToken", "uuid", ["subscribeUUID"], ["unSubscribeUUID"], "subPresenceUrl")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })

    it("should return with Error response", () => {
        const response = {
            status: 403,
            data: { defaultMessage: subscriptionErrorMessages.orgMismatchErrorMessage}
        }
        
        const spy = jest.spyOn(apiUtility, "putService").mockImplementation(() => { throw {response} })
        presenceService.updateSubscriptionsService("accessToken", "uuid", ["subscribeUUID"], ["unSubscribeUUID"], "subPresenceUrl")
        expect(spy).toHaveBeenCalled()
        spy.mockClear()
    })
})

describe("Presence Availble test", () => {
    const mockDispatch = jest.fn()
    it("should invoke the presenceAvailable", () => {
        const fakeIdleDetec = jest.fn()
        const FakeIdleDetector = jest.fn(() => ({
            putIdleDetectorData: fakeIdleDetec,
            addEventListener: jest.fn(),
        }));
        (window as any).IdleDetector = FakeIdleDetector
        presenceService.presenceAvailable(EIdlePermissionState.GRANTED, mockDispatch)
        expect(FakeIdleDetector).toBeDefined()
    })

})
