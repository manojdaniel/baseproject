import string
from random import *


def rand_string(N, corpus=string.ascii_uppercase + string.ascii_lowercase + string.digits):
    return ''.join(choices(corpus, k=N))
