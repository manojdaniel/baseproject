/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { graphqlClient, EResponse, IUserInfo } from "@rocc/rocc-client-services"
import { HTTP_HEADERS_KEY, HTTP_HEADERS_VALUE } from "../../constants/config"
import { LOGIN_ACCESS_URI, PHILIPS_API_URI, SERVER_LOGOUT } from "../../constants/endpoints"
import { QUERY_CURRENT_USER_DETAILS, QUERY_GET_METASITE_ID_FOR_CUSTOMER } from "../../graphql/queries/queries"
import { SUBSCRIPTION_CONTACTS_RELEVANT_TO_CURRENT_USER, SUBSCRIPTION_FOR_CURRENT_USER_BUNDLE_INFOS } from "../../graphql/queries/subscriptions"
import { deleteService, postService, safeURL } from "../../utility/api/apiUtility"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { getCurrentUserInfoTransformer } from "../transformer/contactsTransform"

export const getCurrentUserInfoService = (userEmail: string, uuid: string, prevCurrentUserDetails: any) => {
    const userInfo = graphqlClient.query({
        query: QUERY_CURRENT_USER_DETAILS,
        variables: { uuid },
    })
        .then((result: any) => {
            return getCurrentUserInfoTransformer(result.data, userEmail, prevCurrentUserDetails)
        })
    return userInfo
}

export const getMetasiteIdForCustomer = async (customerName: string) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_GET_METASITE_ID_FOR_CUSTOMER,
            variables: { customerName },
        })
        return result.data.metasites[0].id
    } catch (error) {
        errorLogger(`Fetching metasiteId failed with: ${errorParser(error)}`)
        return ""
    }
}

export const fetchContactsRelevantToCurrentUserService = (id: number, limit: number) => {
    const variables = limit ? { userId: id, limit } : { userId: id }
    const query = SUBSCRIPTION_CONTACTS_RELEVANT_TO_CURRENT_USER
    return graphqlClient.subscribe({
        query, variables
    })
}

export const logoutSession = async (user: IUserInfo, authUrl: string) => {
    const { sessionId, accessToken, uuid } = user
    try {
        const headers = {
            Authorization: accessToken,
        }
        await deleteService({ headers, url: `${authUrl}${LOGIN_ACCESS_URI}${sessionId}` })
        return EResponse.SUCCESS
    } catch (error) {
        errorLogger(`Failed to close session for the user: ${uuid} with error: ${errorParser(error)}`)
        return EResponse.ERROR
    }
}

export const closeSessionFromServer = (user: IUserInfo, url: string) => {
    const headers = {
        [HTTP_HEADERS_KEY.AUTHORIZATION]: user.accessToken,
        [HTTP_HEADERS_KEY.CONTENT_TYPE]: HTTP_HEADERS_VALUE.APPLICATION_JSON,
    }
    const data = {
        userUUID: user.uuid,
        sessionId: user.sessionId,
    }
    return postService({ headers, data, url: `${safeURL(url, PHILIPS_API_URI)}${SERVER_LOGOUT}` })
        .then(() => { infoLogger(`User: ${user.uuid} logged out successfully`) })
        .catch((error: Error) => { errorLogger(`Logout failed for user: ${user.uuid} with error: ${errorParser(error)}`) })
}

export const subscribeToCurrentUserBundleInfos = (userId: number, bundleName: string) => {
    return graphqlClient.subscribe({
        query: SUBSCRIPTION_FOR_CURRENT_USER_BUNDLE_INFOS,
        variables: { user_id: userId, bundle_name: bundleName }
    })
}
