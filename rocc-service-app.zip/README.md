# ROCC Customer Provisioning Portal Service
<a href=https://codescene.ta.philips.com/1710/analyses/latest/dashboard> <img src="https://codescene.com/status/analyzed-by-codescene-badge.svg" width="130"></a>
Setup ROCC Customer Provisioning Portal Service for ROCC Solution


## Prerequisites

1. Notes
    - Run this section while setting up service tools for the first time
    - Ensure that ROOT-ORG setup is done with Role: _SERVICEROLE_, Group: _ServiceGroup_ and Service: _servicetoolservice_
    - Ensure that Role: _SERVICEROLE_ has appropriate permissions including _CLIENT.SCOPE_
    - Ensure that Environment related configurations are stored in vault path - _ServiceConfigs_

2. Setup service tool infrastructure using *rocc_hsdp_installer* script
    - As part of this script the following items are setup:
        - Database schema
        - Master data
        - Backend and frontend applications deployment

3. Navigate to rocc-service-app/rocc_overwatch_service
    - Update *rocc_overwatch_service/cli_utility/configs/config.ini* with relevant configurations
    - Update *rocc_overwatch_service/resources/fse_user_details/fse_user_details.json* with relevant FSE user details
        - Currently available clinical_roles are:
            - _FSEEDITROLE_
            - _FSEVIEWROLE_
            - _FSEADMINROLE_
    - Initiate CLI
        > python cli.py -u <root_org_admin_username> -p <root_org_admin_password>
    - You will be prompted with the following options:

            1. Generate configs ( Will generate the config.ini for existing org )
            
            2. Parent org setup ( Will setup the required propositions/applications/policies for the parent org )
            
            3. Enable Service tool for Parent org ( Will setup service tools for the parent org and all existing suborgs )
            
            4. Create FSE users ( Will create FSE users for the parent org )

            q. Quit [q]
    - Select option *__2__* to initiate Parent org setup - Follow the steps interactively
    - Select option *__3__* Enable Service tool for Parent org - Follow the steps interactively
    - Select option *__4__* To create/edit FSE users - Follow the steps interactively
