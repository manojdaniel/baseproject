import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
    getAlertBreadCrumbs,
    getAlertBreadCrumbsEmpty,
    getGlobalSelecetedRegion,
    getGlobalSelecetedAffiliate,
    getGlobalSelecetedPlant,
    getGlobalSelecetedAsset,
    getBreadCrumbDate
} from "../redux/reducers/CommonReducer";
import { useParams, useNavigate } from 'react-router-dom';
import { encryptRSAData, } from "../utility/rsa";

const Alert = () => {
    let dispatch = useDispatch();
    let navigate = useNavigate();
    const { alertId } = useParams();
    const [taskData, setTaskData] = useState<any>(null);

    const {
        alertBreadCrumbs
    } = useSelector((state: any) => ({
        alertBreadCrumbs: state.Common.alertBreadCrumbs,
    }));

    useEffect(() => {
        try {
            const currentdate = new Date();
            let updatedDate: any;
            updatedDate = new Date(currentdate.setMonth(currentdate.getMonth() - 1));
            dispatch(getBreadCrumbDate({ id: "1M", updatedDate: updatedDate }));
        } catch (error) { }
        dispatch(getAlertBreadCrumbs(encryptRSAData(`alertId=${alertId}`)))
        //alert(alertId)
    }, [alertId]);  // Dependency array

    useEffect(() => {
        if (alertBreadCrumbs.length > 0) {
            dispatch(getGlobalSelecetedRegion({ value: alertBreadCrumbs[0].regionId, label: alertBreadCrumbs[0].regionName, }));
            dispatch(getGlobalSelecetedAffiliate({ value: alertBreadCrumbs[0].affiliateId, label: alertBreadCrumbs[0].affiliateName, }));
            dispatch(getGlobalSelecetedPlant({ value: alertBreadCrumbs[0].plantId, label: alertBreadCrumbs[0].plantName }));
            dispatch(getGlobalSelecetedAsset({ value: alertBreadCrumbs[0].assetId, label: alertBreadCrumbs[0].assetId }));
            dispatch(getAlertBreadCrumbsEmpty(""));
            navigate(`/assets/alertList`, { state: { alertId: alertId, alertIdFromEmail:"true" } })
        }
    }, [alertBreadCrumbs]);


    return (
        <div>
            <div>{taskData}</div>
        </div>
    )
}
export default Alert;