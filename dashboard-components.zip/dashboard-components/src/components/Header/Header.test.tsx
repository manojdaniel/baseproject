import React from "react";
import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import Header from "./Header";

describe("Header", () => {
	const data = [
		{
			id: 1,
			value: "Region A",
			identifier: "Region",
			color: "#FFC764",
			regionId: "R1",
			regionName: "Region A",
		},
		{
			id: 2,
			value: "Plant A",
			identifier: "Plant",
			color: "#3BB9FF",
			regionId: "R1",
			regionName: "Region A",
			affiliateId: "A1",
			affiliateName: "Affiliate A",
			plantId: "P1",
			plantName: "Plant A",
		},
	];
	const handleSearchBack = jest.fn();
	const assetEnabled = true;

	it("renders Header component", () => {
		const { getByTestId } = render(
			<Header
				data={data}
				handleSearchBack={handleSearchBack}
				assetEnabled={assetEnabled}
			/>
		);
		expect(getByTestId("header-component")).toBeInTheDocument();
	});

	it("selects an item from the search dropdown and clicks on search button", () => {
		const { getByPlaceholderText, getByText } = render(
			<Header
				data={data}
				handleSearchBack={handleSearchBack}
				assetEnabled={assetEnabled}
			/>
		);
		const searchInput = getByPlaceholderText("Search...");
		fireEvent.change(searchInput, { target: { value: "Reg" } });
		const searchDropdownOption = getByText("Region A");
		fireEvent.click(searchDropdownOption);
		const searchButton = getByText("Search");
		fireEvent.click(searchButton);
		expect(handleSearchBack).toHaveBeenCalledTimes(1);
	});
});
