/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { GlobalStore } from "redux-micro-frontend"
import { PARENT_STORE } from "../../common/constants/constants"

const getEnableDevToolStatus = () => {
    const tempGlobalStore = GlobalStore.Get().GetGlobalState()
    let enableDevTools = true
    if (tempGlobalStore[PARENT_STORE] && tempGlobalStore[PARENT_STORE].configReducer.configs) {
        const configs = tempGlobalStore[PARENT_STORE].configReducer.configs
        enableDevTools = configs.ROCC_DEV === "true"
    }
    return enableDevTools
}

const enableDevTools = getEnableDevToolStatus()

const globalStore = GlobalStore.Get(enableDevTools)

export default globalStore
