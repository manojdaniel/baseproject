/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { AxiosHandler } from "@rocc/rocc-http-client"

let roccHttpClient: AxiosHandler

export const setupAxiosHandler = (httpClient: AxiosHandler) => {
    roccHttpClient = httpClient
}

export const postCall = (params: any) => {
    return fetchHttpClient().postCall({ url: params.url, data: params.data, headers: params.headers })
}

export const putCall = (params: any) => {
    return fetchHttpClient().putCall({ url: params.url, data: params.data, headers: params.headers })
}

export const deleteCall = (params: any) => {
    return fetchHttpClient().deleteCall({ url: params.url, data: params.data, headers: params.headers })
}

export const getCall = (params: any) => {
    return fetchHttpClient().getCall({ url: params.url, data: params.data, headers: params.headers })
}

export const postService = (params: any) => {
    return fetchHttpClient().postService({ url: params.url, data: params.data, headers: params.headers })
}

export const putService = (params: any) => {
    return fetchHttpClient().putService({ url: params.url, data: params.data, headers: params.headers })
}

export const deleteService = (params: any) => {
    return fetchHttpClient().deleteService({ url: params.url, data: params.data, headers: params.headers })
}

export const getService = (params: any) => {
    return fetchHttpClient().getService({ url: params.url, headers: params.headers })
}

export const safeURL = (url: string, uri: string) => url.endsWith(uri) ? url : `${url}${uri}`

export const fetchHttpClient = () => roccHttpClient ? roccHttpClient : new AxiosHandler()

export const refreshToken = () => fetchHttpClient().refreshToken()
