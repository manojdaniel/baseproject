import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import {
	getReferenceTableModelData,
	getReferenceOffilineData,
	getCurrRegionValue,
	getAssetDropdownList,
	getModelDropdownList,
	getGlobalSelecetedAsset,
} from "../../../redux/reducers/CommonReducer";
import ReferenceTableComponent from "table/ReferenceTable";
import Dropdown from "components/Dropdown";
import "./ReferenceTable.scss";
import Loader from "components/Loader";
import { encryptRSAData } from "../../../utility/rsa";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const ReferenceTable = () => {
	let dispatch = useDispatch();
	const [searchParams, setSearchParams] = useSearchParams();
	const [selectedAsset, setSelectedAsset] = useState<any>("");
	const [selectedModel, setSelectedModel] = useState<any>("");
	const userId = 18;

	const {
		referenceTableModelData,
		referenceOffilineData,
		globalSelecetedAsset,
		globalSelecetedPlant,
		assetDropdownList,
		modelDropdownList,
		loadingReferenceOffilineData,
		loadingReferenceTableModelData,
		loadingAssetDropdownList,
		loadingModelNameDropdownList,
	} = useSelector((state: any) => ({
		referenceTableModelData: state.Common.referenceTableModelData,
		referenceOffilineData: state.Common.referenceOffilineData,
		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		assetDropdownList: state.Common.assetDropdownList,
		modelDropdownList: state.Common.modelDropdownList,

		loadingReferenceTableModelData: state.Common.loadingReferenceTableModelData,
		loadingReferenceOffilineData: state.Common.loadingReferenceOffilineData,
		loadingAssetDropdownList: state.Common.loadingAssetDropdownList,
		loadingModelNameDropdownList: state.Common.loadingModelNameDropdownList,
	}));

	useEffect(() => {
		if (
			Object.keys(globalSelecetedPlant).length > 0 &&
			Object.keys(globalSelecetedAsset).length > 0
		) {
			setSelectedAsset(globalSelecetedAsset);
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
			dispatch(
				getModelDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			); //{assetId}/{userId}
			dispatch(
				getReferenceTableModelData(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}&modelId=0`
					)
				)
			);
			dispatch(
				getReferenceOffilineData(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			);
		}
	}, []);

	useEffect(() => {
		dispatch(getCurrRegionValue(""));
	}, []);

	useEffect(() => {
		if (modelDropdownList.length > 0) {
			let data: any;
			data = modelDropdownList[0];
			setSelectedModel(data);
		}
	}, [modelDropdownList]);

	const handleAssetDropDown = (e: any) => {
		setSelectedAsset(e);
		setSelectedModel("");
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
		dispatch(
			getModelDropdownList(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`
				)
			)
		); //{assetId}/{userId}
		dispatch(
			getReferenceTableModelData(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${e.value}&modelId=0`
				)
			)
		);
		dispatch(
			getReferenceOffilineData(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`))
		);
	};
	const handleModeldDropDown = (e: any) => {
		setSelectedModel(e);
		dispatch(
			getReferenceTableModelData(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&modelId=${e.value}`
				)
			)
		);
		// dispatch(getReferenceOffilineData(`${e.value}/${userId}`));
	};

	const saveCurrentRegionStore = (data) => {
		dispatch(getCurrRegionValue(data));
		setSearchParams({ ["region"]: data });
	};

	return (
		<>
			<div id="reference-table">
				<div className="common-box-inner">
					<div className="title">REFERENCE TABLE</div>
					<div id="new-filter">
						<div className="nf-left">
							<div className="asset-name">
								{Object.keys(selectedAsset).length > 0
									? selectedAsset.value
									: null}
							</div>
						</div>
						<div className="nf-right">
							<div>
								<label className="cus-label">Asset ID</label>
								<Dropdown
									name={"AssetID"}
									options={assetDropdownList}
									handleChange={handleAssetDropDown}
									value={selectedAsset}
									defaultValue={""}
									loading={loadingAssetDropdownList}
								/>
							</div>
							<div>
								<label className="cus-label">Model Name</label>
								<Dropdown
									name={"Model Name"}
									options={modelDropdownList}
									handleChange={handleModeldDropDown}
									defaultValue={""}
									loading={loadingModelNameDropdownList}
									value={selectedModel}
								/>
							</div>
						</div>
					</div>
					<div className="common-box-content">
						<ReferenceTableComponent
							data={referenceTableModelData}
							saveCurrentRegionStore={saveCurrentRegionStore}
							loading={loadingReferenceTableModelData}
						/>
					</div>
				</div>
			</div>
			<div id="offline-condition">
				<div className="common-box-inner">
					<div className="common-box-filter">
						<div className="title">OFFLINE CONDITION</div>
					</div>

					<div className="common-box-asset-name">
						<div className="asset-name">
							{Object.keys(selectedAsset).length > 0
								? selectedAsset.value
								: null}
						</div>
					</div>
					{loadingReferenceOffilineData ? (
						<Loader />
					) : (
						<div className="common-box-content offlinetext">
							{referenceOffilineData.length > 0
								? referenceOffilineData[0].offlineCondition
								: null}
						</div>
					)}
				</div>
			</div>
		</>
	);
};

export default ReferenceTable;
