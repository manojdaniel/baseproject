/*
 * Created on Thu Oct 15 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useState, useEffect } from "react"
import { Message } from "semantic-ui-react"
import "./NotificationBubble.scss"
interface INotificationBubble {
    handleDismiss: () => void
    header: string
    content: string
    status: "success" | "error" | "warning" | "info" | "default"
    customStyle?: any
    timeOutValue?: number
}

const NotificationBubble = ({
    status, content, header, handleDismiss, timeOutValue }: INotificationBubble) => {
    let timeoutId: NodeJS.Timeout
    let icon = "CheckmarkCircle", className = "indicator success"
    const [showMessage, setShowMessage] = useState(false)
    switch (status) {
        case "warning":
            icon = "ExclamationMarkCircle"
            className = "indicator warning"
            break
        case "info":
            icon = "InformationCircle"
            className = "indicator info"
            break
        case "error":
            icon = "CrossCircle"
            className = "indicator error"
            break
        default:
    }
    useEffect(() => {
        if (timeOutValue) {
            setShowMessage(true)
            /* eslint-disable-next-line react-hooks/exhaustive-deps */
            timeoutId = setTimeout(() => {
                setShowMessage(false)
                handleDismiss()
            }, timeOutValue)
        }
        return () => {
            clearTimeout(timeoutId)
        }
    }, [])

    return (
        <Message
            id={"NotificationBubble"}
            hidden={!showMessage}
            compact
            icon={icon}
            header={header}
            content={content}
            className={className + " bubbleStyle"}
        />
    )
}

export default NotificationBubble
