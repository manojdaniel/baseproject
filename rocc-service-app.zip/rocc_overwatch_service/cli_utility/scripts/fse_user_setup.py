"""
 Created on Mon Nob 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import os

from cli_utility.scripts.utility import fetch_profile_configs_for_cli, prompt_and_get_rocc_url
from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_HSDP_IDM_URL
from src.constants.constants import DATA, ROCC_PROXY_URL, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, COMPLETED, ID, ROCC_ORGANIZATIONS
from src.constants.enums import EDBRoles
from src.constants.headers import FSE_USER_DETAILS_FILE_PATH
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import get_organization_user_mappings, update_user_org_mapping
from src.modules.db_operations.fse_user_db_service.fse_user_db_service import check_if_user_exists, get_roles_identifiers_for_fse_roles, insert_fse_user_into_db, get_all_customers
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import fetch_user_details_from_hsdp
from src.wrappers.infrastructure_services.roles_permissions_services.manage_roles_groups import create_group, get_group_details_by_name
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.management_service.user_management_service import insert_and_invite_user, edit_fse_user, task_add_fse_user_to_fse_group
from src.wrappers.platform_services.rbac_services.rbac_services import update_user_role_mapping

LOG = create_logger("FseUserSetup")


def add_fse_user(user_details):
    """
    1. Prompt user to enter proxy_url
    2. Read fse user details from file FSE_USER_DETAILS_FILE_PATH
    3. Check if user has any orgRole. If yes skip inserting or editing of user
    3. Check user info [{{HSDP_IDM_URL}}/authorize/identity/User?profileType=membership&userId={{email_id}}]
        - Not present : add to new_users list
        - Present:
            - Check and add user to FseGroup of parent org
            - Check user exist in DB
                - present: if role update needed add to new_roles_for_user else add to existing users
                - absent: add users to db_insert_users
    4. Insert and invite new_users
    5. Insert users in db_insert_users list into db
    6. Edit existing user with new roles

    """
    try:
        user_uuid = user_details["userId"]
        user_org = user_details["orgId"]
        token = user_details["token"]
        url = prompt_and_get_rocc_url()
        os.environ[ROCC_PROXY_URL] = url
        new_users = []
        existing_users = []  # Existing users with roles already present
        new_roles_for_user = []  # Existing users with new roles
        db_insert_users = []  # HSDP registered users not present in db
        list_of_fse_users = {}
        LOG.info("Initiate process to add FSE users ..!!")
        with open(FSE_USER_DETAILS_FILE_PATH) as fse_file:
            fse_user_details = json.load(fse_file)
        profile_configs, vault_credentials_response, _ = fetch_profile_configs_for_cli()
        global_vault_values = get_path_specific_vault_values(path_name=profile_configs["VAULT_ROCC_GLOBAL_PATH"], vault_credentials_response=vault_credentials_response)
        parent_token = create_service_token_from_vault(iam_url=profile_configs["HSDP_IAM_URL"],
                                                       issuer=global_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                       private_key=global_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
        client = get_client_connection(parent_token, url=url, org_infra_uuid=user_org)
        roles_ids_for_fse_role = get_roles_identifiers_for_fse_roles(client=client)
        group_id = task_get_fse_group_id(token=token, profile_configs=profile_configs)

        for fse_user in fse_user_details:
            list_of_fse_users[fse_user["email_id"]] = fse_user["allowed_customers"]
            LOG.info(f"list:{list_of_fse_users}", )
            check_for_org_role = check_if_customer_org_role_exists(fse_user)
            if not check_for_org_role:
                # Check user registered with hsdp
                LOG.info(f"Checking if user - {fse_user['email_id']} already registered with hsdp")
                user_details = fetch_user_details_from_hsdp(idm_url=profile_configs[VAULT_HSDP_IDM_URL], token=token, email_id=fse_user["email_id"])
                if isinstance(user_details, list):
                    if len(user_details) == 0:
                        # User not registered with hsdp
                        LOG.info("User is not registered with hsdp yet.")
                        new_users.append(prepare_user_obj(user=fse_user, clinical_role_id=get_clinical_roles_obj(fse_roles_details=roles_ids_for_fse_role, new_user_roles=fse_user["clinical_roles"]), user_id_from_db=None))
                        continue
                    # User registered with hsdp, Check and add to FseGroup
                    LOG.info("User is already registered with hsdp.")
                    response = add_to_fse_group_of_parent_org(profile_configs=profile_configs, group_id=group_id, hsdp_user_details=user_details[0], token=token)
                    if not response:
                        LOG.error(f"Failed to add user {fse_user['email_id']} to FseGroup")
                        continue
                    # Check user present in db
                    LOG.info(f"Checking if user {fse_user['email_id']} present in DB")
                    result = check_if_user_exists(client=client, email_id=fse_user["email_id"])
                    if len(result) > 0:
                        LOG.info("Verifying if user has new role to be added")
                        new_user_clinical_roles = compute_new_clinical_role(
                            new_roles_list=fse_user["clinical_roles"],
                            existing_roles_data_list=result[0]["applicationRoleMappingsByUserId"])
                        if new_user_clinical_roles and len(new_user_clinical_roles) > 0:
                            clinical_role_ids = get_clinical_roles_obj(fse_roles_details=roles_ids_for_fse_role, new_user_roles=fse_user["clinical_roles"])
                            new_roles_for_user.append(prepare_user_obj(user=fse_user, clinical_role_id=clinical_role_ids, user_id_from_db=result[0]["id"]))
                        else:
                            existing_users.append(fse_user)
                    else:
                        # User registered with hsdp but not in db
                        user_details[0]["role_ids"] = get_clinical_roles_obj(fse_roles_details=roles_ids_for_fse_role, new_user_roles=fse_user["clinical_roles"])
                        user_details[0]["clinical_roles"] = fse_user["clinical_roles"]
                        db_insert_users.append(user_details[0])
                else:
                    LOG.error(f"User does not have privilege to add user {fse_user['email_id'] }")

        if len(new_users) > 0:
            LOG.info("Adding new users to ROCC and Sending Email Invite")
            LOG.info(f"New Users List is, {new_users}")
            insert_and_invite_user(
                token=parent_token, user_list=new_users, org_id=profile_configs[VAULT_PARENT_ORG_ID],
                url=url, group_id=group_id, profile_configs=profile_configs)
            prepare_and_post_audit(event_type="User Management", event_subtype="Add User", action="C", outcome=0, user_detail=user_uuid,
                                   org_id=profile_configs[VAULT_PARENT_ORG_ID], token=parent_token, **{"User Management": COMPLETED}, **{"User Org Details": user_org})
        if len(db_insert_users) > 0:
            LOG.info("Adding hsdp registered users to db")
            LOG.info(f"List of hsdp registered users {[user['emailAddress'] for user in db_insert_users]}")
            manual_fse_user_insert(client=client, users=db_insert_users, current_user_uuid=user_uuid, token=parent_token, parent_org_uuid=profile_configs[VAULT_PARENT_ORG_ID])
            prepare_and_post_audit(event_type="User Management", event_subtype="Add User", action="C", outcome=0, user_detail=user_uuid,
                                   org_id=profile_configs[VAULT_PARENT_ORG_ID], token=parent_token, **{"User Management": COMPLETED}, **{"User Org Details": user_org})
        if len(new_roles_for_user) > 0:
            LOG.info("New roles for existing user will be added")
            LOG.info(f"List of existing users with new roles are {new_roles_for_user}")
            edit_fse_user(url=url, parent_token=parent_token, user_list=new_roles_for_user,
                          org_id=profile_configs[VAULT_PARENT_ORG_ID], group_id=group_id, profile_configs=profile_configs)
            prepare_and_post_audit(event_type="User Management", event_subtype="Edit User", action="E", outcome=0, user_detail=user_uuid,
                                   org_id=profile_configs[VAULT_PARENT_ORG_ID], token=parent_token, **{"User Management": COMPLETED}, **{"User Org Details": user_org})
        if len(existing_users) > 0:
            LOG.info(f"List of already existing users, {existing_users}")
        LOG.info("Adding FSE user process completes ..!!")
        initiate_user_org_mapping(client=client, fse_users_dic=list_of_fse_users, user_uuid=user_uuid)
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding fse user with error: {ex}")

def initiate_user_org_mapping(client, fse_users_dic, user_uuid):
    try:
        for key, value in fse_users_dic.items():
            insert_user_org_mapping(client=client, fse_user_email_id=key, fse_user_allowed_customers=value, user_uuid=user_uuid)
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding fse user and organization mapping with error: {ex}")

def compute_new_clinical_role(new_roles_list, existing_roles_data_list):
    """
    1. Get new_roles_list for user from file
    2. Get existing_roles_list for user from DB
    3. Create a union on both list to get new roles that needs to be added
    """
    roles_to_be_assigned = []
    existing_roles_list = []
    new_roles_list = [item.lower() for item in new_roles_list]
    try:
        LOG.info("Computing new clinical roles for user")
        for role_data in existing_roles_data_list:
            existing_roles_list.append(role_data["rocc_application_role"]["role"])

        roles_to_be_assigned = set(new_roles_list) - set(existing_roles_list)
        LOG.info(f"List of new clinical roles are ::::: {list(roles_to_be_assigned)}")
        return list(roles_to_be_assigned) if len(roles_to_be_assigned) > 0 else False
    except KeyError as key_error:
        LOG.exception(f"Key Error occurred while computing clinical role list with error: {key_error}")
    except Exception as ex:
        LOG.exception(f"Error occurred while computing clinical role list with error: {ex}")
    return False


def get_clinical_roles_obj(fse_roles_details, new_user_roles):
    """
    1. Get the new_clinical_roles_details for user from compute_clinical_role function
    2. Get the list of roles like FSE% from db(fse_clinical_roles_details)
    3. Prepare role_obj which contains only clinical role identifier
    """
    role_obj = []
    try:
        LOG.info(f"Fetching clinical roles identifiers for roles {new_user_roles}")
        new_user_roles = [item.lower() for item in new_user_roles]
        for role in fse_roles_details:
            if role["role"] in new_user_roles:
                role_obj.append(role["id"])
        return role_obj if len(role_obj) > 0 else False
    except KeyError as key_error:
        LOG.exception(f"Exception while fetching role identifiers from list with error: {key_error}")
    return False


def check_if_customer_org_role_exists(user):
    """
    1. Get all the Clinical Roles provided for FSE user
    2. Check if any orgRole "customer_org_role" exists in Clinical roles of FSE
    3. If exists return True. Else False
    """
    customer_org_role = [EDBRoles.EXPERTUSERROLE.value, EDBRoles.INCOGNITOROLE.value, EDBRoles.PROTOCOLMANAGERROLE.value, EDBRoles.TECHNOLOGISTROLE.value, EDBRoles.ADMINROLE.value]
    customer_org_role = [item.lower() for item in customer_org_role]

    fse_roles = user["clinical_roles"]
    fse_roles = [item.lower() for item in fse_roles]
    check_role = any(item in customer_org_role for item in fse_roles)
    if check_role:
        LOG.info(f"User {user['email_id']} contains customer org roles, hence skipping user management for this user.")
    else:
        LOG.info(f"User {user['email_id']} does not contain customer org roles, hence continuing with user management for this user.")
    return check_role


def prepare_user_obj(user, clinical_role_id, user_id_from_db=None):
    try:
        # Metasite is hardcoded to 0(Dummy Value). Validation of metasite is skipped at admin service using flag isfseUserCheck
        user_obj = {"clinicalRoles": clinical_role_id, "emailId": user["email_id"], "firstName": user["first_name"], "lastName": user["last_name"],
                    "uniqueId": user["email_id"], "isfseUserCheck": True, "metasiteId": 0, "phoneNumber": "", "sites": [],
                    "resources": [], "modalities": []}
        if user_id_from_db is not None:
            user_obj["user_id"] = user_id_from_db
        return user_obj
    except Exception as ex:
        LOG.exception(f"Exception occurred while preparing user object with error: {ex}")
        raise RoccException(500, f"Failed to retrieve user details with error: {ex}") from ex


def task_get_fse_group_id(token, profile_configs, group_name="FseGroup"):
    """
    - Check if group [FseGroup] exists for parent org
        - If yes return id
        - Otherwise, create group and return id
    """
    try:
        group_id = get_group_details_by_name(token=token, group_name=group_name, profile_configs=profile_configs)
        if not group_id:
            """ Need to create group """
            group_id = create_group(token=token,
                                    organization_id=profile_configs[VAULT_PARENT_ORG_ID],
                                    name=group_name,
                                    description="This Group is used to authorise ROCC service tool FSE users and ROCC Service Admin users to access data from GraphQl",
                                    profile_configs=profile_configs)
        return group_id
    except Exception as ex:
        LOG.exception(f"Failed to fetch group id for name: {group_name} with error: {ex}")
    return None


def add_to_fse_group_of_parent_org(profile_configs, group_id, hsdp_user_details, token):
    """
    check if parent org exists and is part of FseGroup
        - parent org does not exist -> Add user to FseGroup of ParentOrg [{{HSDP_IDM_URL}}/authorize/identity/Group/{{group_id}}/$add-members]
        - parent org exists, but not part of FseGroup -> Add user to FseGroup of ParentOrg
    """
    parent_org_id = profile_configs[VAULT_PARENT_ORG_ID]

    for org in hsdp_user_details["memberships"]:
        if org["organizationId"] == parent_org_id:
            if "FseGroup" in org["groups"]:
                return True
    return task_add_fse_user_to_fse_group(token=token, email_id=hsdp_user_details["emailAddress"], group_id=group_id, profile_configs=profile_configs)


def manual_fse_user_insert(client, users, current_user_uuid, token, parent_org_uuid):
    """
    Inserts user record into DB
    """
    for user in users:
        if update_fse_user_roles(roles=user["clinical_roles"], token=token, user_uuid=user["id"], parent_org_uuid=parent_org_uuid):
            response = insert_fse_user_into_db(client=client, new_user_details=user, current_user_uuid=current_user_uuid)
            if not isinstance(response, int):
                LOG.error(f"Failed to insert {user['emailAddress']} into DB")
            else:
                LOG.info(f"Inserted {user['emailAddress']} into DB successfully.")
        else:
            LOG.error(f"Failed to update roles for {user['emailAddress']} in RBAC.")


def update_fse_user_roles(roles, token, user_uuid, parent_org_uuid):
    """
    Update the fse user roles in rbac
    """
    url = os.environ[ROCC_PROXY_URL]
    user_role_mappings = []
    org_ctxt_header = {"Org-Id": parent_org_uuid}
    for role in roles:
        user_role_mappings.append({"userId": user_uuid, "role": role.upper()})
    return update_user_role_mapping(url=url, user_role_mapping=user_role_mappings, user_uuid=user_uuid, org_ctxt_header=org_ctxt_header, token=token)

check_if_all_orgs_mapping = lambda allowed_orgs: "*" in allowed_orgs

def insert_user_org_mapping(client, fse_user_email_id, fse_user_allowed_customers, user_uuid):
    """
    FSE User org mapping
    """
    try:
        new_organizations_mappings = []
        deleted_organization_mappings = []
        org_map = {}
        data = check_if_user_exists(client, fse_user_email_id)
        fse_user_id = data[0][ID]
        current_organization_mappings = get_organization_user_mappings(client=client, variable_values={"user_id": fse_user_id})
        orgs = get_all_customers(client)
        for org in orgs[ROCC_ORGANIZATIONS]:
            org_map[org["org_identifier"]] = org["id"]
        if check_if_all_orgs_mapping(fse_user_allowed_customers):
            LOG.info(f"FSE User {fse_user_id} is mapped to all orgs.")
            new_organizations_mappings += org_map.values()
        else:
            for organization_identifier in fse_user_allowed_customers:
                new_organizations_mappings.append(org_map[organization_identifier])
        if len(current_organization_mappings) > 0:
            for org in current_organization_mappings:
                if org["organization_id"] not in new_organizations_mappings:
                    deleted_organization_mappings.append(org["organization_id"])
                else:
                    new_organizations_mappings.remove(org["organization_id"])
        update_orgs_user_mapping(client=client,deleted_org_ids=deleted_organization_mappings, new_org_ids=new_organizations_mappings, fse_user_id=fse_user_id, user_uuid=user_uuid)
    except Exception as ex:
        LOG.exception(f"Failed to insert user org mapping with exception: {ex}")

def update_orgs_user_mapping(client, deleted_org_ids, new_org_ids, fse_user_id, user_uuid):
    """
    Update FSE User org mapping
    """
    try:
        org_mappings = []
        for org_id in new_org_ids:
            org_object = {
                "organization_id": org_id,
                "user_id": fse_user_id,
                "created_by": user_uuid,
                "modified_by": user_uuid
            }
            org_mappings.append(org_object)
        variable_values = {
            "delete_org_ids": deleted_org_ids,
            "org_mappings": org_mappings,
            "user_id": fse_user_id
        }
        update_user_org_mapping(client, variable_values)
        LOG.info("Completed User Organization Mappings")
    except Exception as ex:
        LOG.exception(f"Failed to update user organization mapping with exception: {ex}")
