import unittest
from src.modules.db_operations.db_utility.graphql_response_parser import extract_data_items_from_result, extract_items_from_result, check_if_id_is_present, check_if_field_is_present, extract_id_and_field_from_response, extract_data_from_table, extract_id_from_mutation_response, extract_response_from_mutation_response, extract_id_from_query_response, update_dicts_with_inserted_ids, get_aggregate_count

class ExtractDataItemsFromResult(unittest.TestCase):
    def setUp(self):
        table_data = [{
            "item_name": ["item1"]
        },
            {
            "item_name": ["item2"]
        }, {
            "item_name": ["item3"]
        }
        ]
        self.input = {
            "table_name": table_data
        }

        self.expected_output = ["item1", "item2", "item3"]

    def test_extract_of_items_on_success(self):
        self.setUp()
        expected_messages = self.expected_output

        response = extract_data_items_from_result(
            self.input, "table_name", "item_name")

        self.assertListEqual(response, expected_messages,
                             "Extract data items from result was not as expected.")

    def test_extract_of_items_when_exception_occurs(self):
        self.setUp()

        response = extract_data_items_from_result(
            self.input, "table_name", "item_name1")

        self.assertListEqual(response, [],
                             "Extract data items should be empty.")


class ExtractItemsFromResult(unittest.TestCase):
    def setUp(self):
        table_data = [{
            "item_name": "item1"
        },
            {
            "item_name": "item2"
        }, {
            "item_name": "item3"
        }
        ]
        self.input = {
            "table_name": table_data
        }

        self.expected_output = ["item1", "item2", "item3"]

    def test_extract_of_items_on_success(self):
        self.setUp()
        expected_messages = self.expected_output

        response = extract_items_from_result(
            self.input, "table_name", "item_name")

        self.assertListEqual(response, expected_messages,
                             "Extract items from result was not as expected.")

    def test_extract_of_items_when_exception_occurs(self):
        self.setUp()

        response = extract_items_from_result(
            self.input, "table_name", "item_name1")

        self.assertListEqual(response, [],
                             "Extract items should be empty.")

class OtherTestCases(unittest.TestCase):
    def setUp(self) -> None:
        table_data = [{
            "id": 1,
            "item_name": "item1"
        }
        ]
        self.input = {
            "table_name": table_data
        }
    def test_check_if_id_is_present(self):
        resp = check_if_id_is_present(data=self.input, table_name="table_name")
        self.assertEqual(resp, 1)
    def test_check_if_field_is_present(self):
        resp = check_if_field_is_present(data=self.input, table_name="table_name", field_name="item_name")
        self.assertEqual(resp, "item1")
    def test_extract_id_and_field_from_response(self):
        resp = extract_id_and_field_from_response(data=self.input, table_name="table_name", field_name="item_name")
        self.assertEqual(resp, (1, "item1"))
    def test_extract_data_from_table(self):
        resp = extract_data_from_table(data=self.input, table_name="table_name")
        self.assertEqual(resp, self.input["table_name"])
    def test_extract_id_from_mutation_response(self):
        input_data = {
            "table_name": {
                "returning": [
                    {"id": 1}
                ]
            }
        }
        resp = extract_id_from_mutation_response(data=input_data, table_name="table_name")
        self.assertEqual(resp, 1)
    def test_extract_response_from_mutation_response(self):
        input_data = {
            "table_name": {
                "returning": [
                    {"id": 1}
                ]
            }
        }
        resp = extract_response_from_mutation_response(data=input_data, table_name="table_name")
        self.assertEqual(resp, [{"id": 1}])
    def test_extract_id_from_query_response(self):
        input_data = {
            "table_name": [
                {"id": 1}
            ]
        }
        resp = extract_id_from_query_response(data=input_data, table_name="table_name")
        self.assertEqual(resp, 1)
    def test_update_dicts_with_inserted_ids(self):
        dicts = {
            1: {"item_excel_header": "unique_name"}
        }
        results = [{"unique_name": "unique_name", "id": 1}]
        resp = update_dicts_with_inserted_ids(dicts, results, "id_name", "item_excel_header", "unique_name")
        self.assertEqual(resp, dicts)
    def test_get_aggregate_count(self):
        input_data = {
            "table_name": {
                "aggregate": {
                    "count": 1
                }
            }
        }
        resp = get_aggregate_count(data=input_data,table_name="table_name")
        self.assertEqual(resp, 1)
