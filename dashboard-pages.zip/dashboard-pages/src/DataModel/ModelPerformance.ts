export const getmodelalertstatusbyassetbyplantid = [
  {
    state: "Overdue",
    countofAlerts: 629,
  },
  {
    state: "Closed",
    countofAlerts: 49,
  },
  {
    state: "Under investigation",
    countofAlerts: 29,
  },
];
export const getmodeltotalalertstatusbyasset_byplantid = [
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2K-3101"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2K-3101"
  },
  {
    "count": 4,
    "state": "Unclassified",
    "assetId": "2K-3101"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2K-3201"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2K-3201"
  },
  {
    "count": 3,
    "state": "Unclassified",
    "assetId": "2K-3201"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2K-4101"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2K-4101"
  },
  {
    "count": 1,
    "state": "Unclassified",
    "assetId": "2K-4101"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2K-4103"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2K-4103"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2K-4103"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3001A"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3001A"
  },
  {
    "count": 1,
    "state": "Unclassified",
    "assetId": "2Y-3001A"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3001B"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3001B"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3001B"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3003B"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3003B"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3003B"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3013A"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3013A"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3013A"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3013B"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3013B"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3013B"
  },
  {
    "count": 1,
    "state": "True_Positive",
    "assetId": "2Y-3123"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3123"
  },
  {
    "count": 1,
    "state": "Unclassified",
    "assetId": "2Y-3123"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3223"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3223"
  },
  {
    "count": 1,
    "state": "Unclassified",
    "assetId": "2Y-3223"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3602"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3602"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3602"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3605"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3605"
  },
  {
    "count": 3,
    "state": "Unclassified",
    "assetId": "2Y-3605"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3606"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3606"
  },
  {
    "count": 6,
    "state": "Unclassified",
    "assetId": "2Y-3606"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3607"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3607"
  },
  {
    "count": 6,
    "state": "Unclassified",
    "assetId": "2Y-3607"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3608"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3608"
  },
  {
    "count": 3,
    "state": "Unclassified",
    "assetId": "2Y-3608"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-3665"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-3665"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-3665"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-4123A"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-4123A"
  },
  {
    "count": 0,
    "state": "Unclassified",
    "assetId": "2Y-4123A"
  },
  {
    "count": 0,
    "state": "True_Positive",
    "assetId": "2Y-4123B"
  },
  {
    "count": 0,
    "state": "False_Positive",
    "assetId": "2Y-4123B"
  },
  {
    "count": 1,
    "state": "Unclassified",
    "assetId": "2Y-4123B"
  }
]
export const getmodelalertstatusbydepartmentbyplantid = [
  {
    date: "2022-0-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2022-8-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2022-9-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2022-10-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2022-11-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2022-12-1",
    precision: 77.78,
    recall: 100,
  },
  {
    date: "2023-1-1",
    precision: 77.78,
    recall: 100,
  },
];
