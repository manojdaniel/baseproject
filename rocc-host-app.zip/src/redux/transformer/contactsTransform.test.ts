/*
 * Created on Wed Dec 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getCurrentUserInfoTransformer } from "./contactsTransform"


describe("Unit tests for contacts transformer", () => {

    it("should convert  current user transformer", () => {
        const props = {
            employeeDetails: [{
                display_name: "John Doe",
                kvmUserName: "kvmUser",
                modality: "1:MR,2:CT",
                org_id: 1,
                org_identifier: "platinum",
                roles: "21:adminrole,22:expertuserrole,23:expertuserincognitorole,24:protocolmanagerrole",
                sites: "1:PHSM001:Platinum Healthcare - Miami:2222 Peter drive, Miami, FLAA~2:PHSNV01:Platinum Healthcare - Nashville:414 Union St, Nashville, TN - 37219~3:PHSNJ02:Platinum Healthcare - Newjersey:80 Sculptors Way Hamilton Township, Newjersey, NJ - 08619~4:PHSSA01:Platinum Healthcare - Seattle:22100 Bothell Everett Hwy, Seattle, WA - 98021~5:PHSCM01:Platinum Healthcare - Cambridge:2 Canal Park, Cambridge, MA  - 02141",
                user_email_id: "isomark@mailinator.com",
                user_hsdp_uuid: "28ea7b23-5e64-4384-9461-61f26fe0158d",
                user_id: 51,
                user_primary_phone: "+1234567890",
                web_onboarding: true,
            }]
        }
        const userEmail = "isomark@mailinator.com"
        const prevCurrentUserDetails = {
            accessToken: "e1c5c11e-b91c-4dde-8721-146db49634fa",
            allRoles: [],
            clinicalRole: "",
            description: "",
            email: "isomark@mailinator.com",
            id: "",
            locale: "",
            modalities: [],
            name: "",
            onBoarded: false,
            orgId: "",
            phoneNumber: "",
            roomName: "",
            secondaryName: "",
            secondaryUUID: "",
            sessionId: "34777832-6085-422d-a335-c3db4e2b9b56",
            siteId: [],
            status: "OFFLINE",
            uuid: "28ea7b23-5e64-4384-9461-61f26fe0158d",
        }
        const expectedResult = {
            currentUser: {
                accessToken: "",
                allRoles: ["Admin", "Expert user", "Incognito role", "Protocol Manager"],
                clinicalRole: "Expert user",
                description: "",
                email: "isomark@mailinator.com",
                id: 51,
                kvmUsername: "kvmUser",
                locale: "",
                modalities: ["MR", "CT"],
                name: "John Doe",
                onBoarded: true,
                orgId: 1,
                phoneNumber: "+1234567890",
                presenceMapId: "",
                roomName: "",
                secondaryName: "",
                secondaryUUID: "",
                sessionId: "",
                siteId: ["1", "2", "3", "4", "5"],
                status: "AVAILABLE",
                username: "isomark@mailinator.com",
                uuid: "28ea7b23-5e64-4384-9461-61f26fe0158d"
            },
            orgIdentifier: "platinum"
        }
        expect(getCurrentUserInfoTransformer(props, userEmail, prevCurrentUserDetails).orgIdentifier).toEqual(expectedResult.orgIdentifier)
    })
})
