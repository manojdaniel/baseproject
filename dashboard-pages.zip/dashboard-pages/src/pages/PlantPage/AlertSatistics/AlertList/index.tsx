import React, { useRef, useEffect, useState } from "react";
import AlertStatus from "./AlertStatus";
import './AlertStatus.scss';

const AlertList = () => {
  return (
    <>
      <div id="alert-list">
                    <AlertStatus />
            </div>
    </>
  );
};
export default AlertList;
