/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, EModalityType, IConsoleSession } from "@rocc/rocc-client-services"
import { RoomMonitoringReceiverInfo, RoomMonitoringSessionInfo } from "@rocc/rocc-console-components"
import { infoLogger, sendLogsToAzure, SERVER_LOGGER, setupTracker } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Grid } from "semantic-ui-react"
import { ACCESS_TOKEN, CCTV_WINDOW, CONSOLE_SESSIONS, INIT_CONSOLE_SESSION_DETAILS, ROOMS, ROOM_MONITORING_TRACKING, TRACKER_ROLE_INSTANCE, TRACKER_ROLE_NAME } from "../../common/constants/constants"
import { getDurationInFormat } from "../../common/helpers/dateTimeUtility"
import { getRoomDetails } from "../../common/helpers/helpers"
import { IReceiver, IRoomInfo, IStore } from "../../redux/interfaces/types"
import { fetchGlobalConfigs, fetchGlobalOrgName, fetchGlobalOrgUUID } from "../../redux/store/externalAppStates"
import syncSessions from "../../redux/store/syncSessions"
import RoomMonitoringStreamView from "./room-monitoring-stream-view/RoomMonitoringStreamView"
import styles from "./RoomMonitoringWindow.scss"

const componentName = "RoomMonitoringWindow.tsx"

const RoomMonitoringWindow = () => {

    const [consoleSessions, setConsoleSessions] = useState([] as IConsoleSession[])
    const [accessToken, setAccessToken] = useState("")
    const [rooms, setRooms] = useState([] as IRoomInfo[])

    const { receivers, currentUser } = useSelector((state: IStore) => ({
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        currentUser: state.externalReducer.currentUser,

    }))

    const { INSIGHTS_KEY, CUSTOMER_ANALYTICS_LOG_CONSENT } = fetchGlobalConfigs()
    const { uuid, clinicalRole, name, sessionId } = currentUser
    const loggerInitialMessage = `${componentName}: For user: ${currentUser.uuid}`

    useEffect(() => {
        if (uuid !== "") {
            setupTracker({
                userId: uuid,
                customerName: fetchGlobalOrgName() ?? "",
                roomName: "",
                iKey: INSIGHTS_KEY,
                profileType: clinicalRole,
                userName: CUSTOMER_ANALYTICS_LOG_CONSENT && CUSTOMER_ANALYTICS_LOG_CONSENT === "true" ? name : "NotCaptured",
                sessionId: sessionId,
                endPoint: SERVER_LOGGER,
                orgId: fetchGlobalOrgUUID(),
                roleName: TRACKER_ROLE_NAME,
                roleInstance: TRACKER_ROLE_INSTANCE
            })
        }
        syncSessions.postMessage({ type: CCTV_WINDOW, open: true })
        syncSessions.onmessage = function (msg: any) {
            if (msg.data.type === CONSOLE_SESSIONS) {
                setConsoleSessions([...msg.data.sessions])
            } else if (msg.data.type === ACCESS_TOKEN) {
                infoLogger(`${loggerInitialMessage} - Received new token for user: ${uuid} with sessionId: ${sessionId}`)
                setAccessToken(msg.data.accessToken)
            } else if (msg.data.type === ROOMS) {
                setRooms([...msg.data.rooms])
            } else if (msg.data.type === "Time") {
                sendLogsToAzure({
                    contextData: {
                        component: ROOM_MONITORING_TRACKING,
                        event: "Live window launched",
                        duration: getDurationInFormat(new Date(), msg.data.time)
                    }
                })
            }
        }
    }, [])

    const sortedReceivers = receivers.sort((a, b) => { return (a.monitorName as any) - (b.monitorName as any) })

    const checkIfActiveConsoleSession = (receiver: IReceiver) => {
        const updatedConsoleSession = consoleSessions.find((session: any) => session.receiverName === receiver.receiverName)
        return { active: !!updatedConsoleSession, consoleSession: updatedConsoleSession || INIT_CONSOLE_SESSION_DETAILS }
    }
    const borderColor = (receiver: IReceiver) => {
        const { active, consoleSession } = checkIfActiveConsoleSession(receiver)
        const { VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT } = EConnectionType
        if (active) {
            switch (consoleSession.connectionType) {
                case VIEW:
                    return styles.viewConsoleBorder
                case FULL_CONTROL:
                    return styles.editConsoleBorder
                case PROTOCOL_MANAGEMENT:
                    return styles.protocolManagementBorder
                default:
                    return ""
            }
        } else {
            return styles.roomMonitoringColumn
        }
    }

    const getConnectionType = (receiver: IReceiver) => {
        const { consoleSession } = checkIfActiveConsoleSession(receiver)
        return consoleSession.connectionType
    }

    const renderRoomInfoAndCamera = (receiver: IReceiver) => {
        const { active, consoleSession } = checkIfActiveConsoleSession(receiver)
        const room = rooms.find(({ roomUuid }) => roomUuid == consoleSession.roomUuid)

        return <>
            <div className={styles.sessionInfoContainer}>
                <div className={styles.bannerInfo}>
                    {active ?
                        <RoomMonitoringSessionInfo
                            isSessionGoingOn={true}
                            connectionType={consoleSession.connectionType}
                            roomModality={getRoomDetails(consoleSession).modality}
                            roomName={getRoomDetails(consoleSession).name}
                            roomLocation={getRoomDetails(consoleSession).location}
                            roomDepartment={getRoomDetails(consoleSession).address}
                        />
                        : <RoomMonitoringSessionInfo
                            isSessionGoingOn={false}
                            connectionType={EConnectionType.DEFAULT}
                            roomModality={EModalityType.MR}
                            roomName={""}
                            roomLocation={""}
                            roomDepartment={""}
                        />
                    }
                </div>
            </div>
            <div className={styles.CameraViewContainer}>
                <Grid className={styles.cameraInfo}>
                    <RoomMonitoringStreamView
                        singleRecieverView={receivers.length === 1}
                        consoleSession={consoleSession}
                        consoleSessions={consoleSessions}
                        currentUserUuid={uuid}
                        accessToken={accessToken}
                        roomCameraAvailable={room?.cameraAvailable}
                    />
                </Grid>
            </div>
        </>
    }

    return (
        <>
            <Grid columns="equal" className={styles.roomMonitoringContainer} id="roomMonitoringContainer">
                <Grid.Row className={styles.roomMonitoringRow}>
                    {sortedReceivers.map((receiver: IReceiver) => {
                        return (<Grid.Column className={`${borderColor(receiver)}`} key={receiver.id} >
                            <div className={styles.receiversContainer}>
                                <RoomMonitoringReceiverInfo connectionType={getConnectionType(receiver)} receiverName={receiver.monitorName} centered={true} />
                            </div>
                            {renderRoomInfoAndCamera(receiver)}
                        </Grid.Column>
                        )
                    })}
                </Grid.Row>
            </Grid>
        </>
    )
}

export default RoomMonitoringWindow
