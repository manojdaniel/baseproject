#!/bin/bash
set -e
set -x
export no_proxy=artifactory-ehv.ta.philips.com,artifactory.pic.philips.com
echo "Building rocc client"
build_type=$1
CICD_FOLDER=cicd
currentDir=$(pwd)

echo "processing in directory : {$currentDir}"


echo "====================================="
echo "Download tool kit dependencies"
echo "====================================="

echo "====================================="
echo "building client"
echo "====================================="
echo "ROCC_DEV=$ROCC_DEV" > .env
npm install
npm run build
# if [ "$build_type" = "tag_build" ]; then
#     npm run build
# else
#     npm run build:dev
# fi
npm run test:coverage

echo "====================================="
echo "copying required content to docker folder"
echo "====================================="

cp -r node_modules $CICD_FOLDER
cp package.json $CICD_FOLDER
cp -r dist/ $CICD_FOLDER
