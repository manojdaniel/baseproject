/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ADD_WORKFLOW_EVENT, DEFAULT_CONTACT_INFO, ECallStatus, IAVCallDetails, ICallStatus, IIncomingCallDetails, IMissedCallData, IOutgoingCallDetails, IParticipantInfo } from "@rocc/rocc-client-services"
import { infoLogger } from "@rocc/rocc-logging-module"
import lodashRemove from "lodash.remove"
import { Dispatch } from "redux"
import { checkIfCallIsAlreadyActive, upsertCallStatus } from "../../common/helpers/callUtility"
import { EAvSettingsType, EClientStatus, ICallMessage, ICallTimeout, ICommunicationVendor, IStore } from "../interfaces/types"
import { DEFAULT_ONGOING_CALL_DETAILS, DEFAULT_RECENT_MISSED_CALL } from "../reducers/callReducer"
import { dispatchToParentStore } from "../store/externalAppStates"
import { AV_SETTINGS, CALL_MESSAGE, CONNECTED_CALL_DETAILS, DEFAULT_AV_SETTINGS, DISCONNECT_CALL, IS_FIRST_PARTICPANT, ON_HOLD_CALLS, SET_AV_CALL_VOLUME, SET_CALL_DEAFEN, SET_CALL_MUTE, SET_CALL_RING_STATUS, SET_CHANNEL_SID, SET_COMMUNICATION_VENDOR, SET_CONVERSATION_CLIENT_STATUS, SET_FULL_SCREEN, SET_INCOMING_CALL_DETAILS, SET_MISSED_CALL_DATA, SET_OUTGOING_CALL_DETAILS, SET_RECENT_MISSED_CALL, UPDATE_CALL_TIMEOUT, UPDATE_CURRENT_AV_CALL, UPDATE_PHONE_CALL_STATUS, VIDEO_CALL_STATUS } from "./types"

export const sendWorkflowEvent = (id: string, eventType: string, payload?: Record<string, any>) => () => {
    dispatchToParentStore({ type: ADD_WORKFLOW_EVENT, payload: { id, event: { type: eventType, ...payload } } })
}

export const setPhoneCallStatus =
    (phoneCallStatus: ECallStatus, recipient: IParticipantInfo = DEFAULT_CONTACT_INFO) => (dispatch: Dispatch) => {
        dispatch({ type: UPDATE_PHONE_CALL_STATUS, phoneCallStatus, recipient })
    }

export const setDesktopCallWindowFullScreen = (isDesktopFullScreen: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: SET_FULL_SCREEN, isDesktopFullScreen })
}

export const setChannelSid = (channelSid: string) => (dispatch: Dispatch) => {
    dispatch({ type: SET_CHANNEL_SID, channelSid })
}

export const setIncomingCallDetails = (incomingCall: IIncomingCallDetails) => (dispatch: Dispatch) => {
    dispatch({ type: SET_INCOMING_CALL_DETAILS, incomingCall })
}

export const setOutgoingCallDetails = (outgoingCall: IOutgoingCallDetails) => (dispatch: Dispatch) => {
    dispatch({ type: SET_OUTGOING_CALL_DETAILS, outgoingCall })
}

export const storeCallDetails = (connectedCallDetails: IAVCallDetails) => (dispatch: Dispatch) => {
    dispatch({ type: CONNECTED_CALL_DETAILS, connectedCallDetails })
}

export const storeOnHoldCallDetails = (onHoldCallDetails: IAVCallDetails[]) => (dispatch: Dispatch) => {
    dispatch({ type: ON_HOLD_CALLS, onHoldCallDetails })
}

export const setCallMessage = (callMessage: ICallMessage, callRetryOption: boolean = false) => (dispatch: Dispatch) => {
    const { messageType, message, contact } = callMessage
    dispatch({ type: CALL_MESSAGE, messageType, message, contact, callRetryOption })
}

export const setVideoCallStatus = (callStatus: ICallStatus[]) => (dispatch: Dispatch) => {
    dispatch({ type: VIDEO_CALL_STATUS, videoCallStatus: callStatus })
}

export const setIsFirstParticipant = (isParticipant: boolean) => (dispatch: any) => {
    dispatch({ type: IS_FIRST_PARTICPANT, isParticipant })
}

export const settingsVideoAudioCallStatus = (avSettingType: EAvSettingsType, selectedValue: string) => (dispatch: any) => {
    switch (avSettingType) {
        case EAvSettingsType.AUDIO_INPUT:
            localStorage.setItem(EAvSettingsType.AUDIO_INPUT, selectedValue)
            break
        case EAvSettingsType.VIDEO_INPUT:
            localStorage.setItem(EAvSettingsType.VIDEO_INPUT, selectedValue)
            break
        case EAvSettingsType.AUDIO_OUTPUT:
            localStorage.setItem(EAvSettingsType.AUDIO_OUTPUT, selectedValue)
            break
        default:
    }
    dispatch({ type: AV_SETTINGS, avSettingType, selectedValue })
}

export const updateAVsettingsLocalstorage = () => (dispatch: Dispatch) => {
    //  fetch data from localStorage
    const audioInputSourceSelected = localStorage.getItem(EAvSettingsType.AUDIO_INPUT)
    const videoSourceSelected = localStorage.getItem(EAvSettingsType.VIDEO_INPUT)
    const audioOutputDestinationSelected = localStorage.getItem(EAvSettingsType.AUDIO_OUTPUT)
    dispatch({ type: DEFAULT_AV_SETTINGS, audioSource: audioInputSourceSelected, videoSource: videoSourceSelected, audioOutput: audioOutputDestinationSelected })

}

export const setAVCallVolume = (selectedValue: number) => (dispatch: Dispatch) => {
    // AV Call Set Volume
    dispatch({ type: SET_AV_CALL_VOLUME, volume: selectedValue })
}

export const setMissedCalls = (newMissedCalls: IMissedCallData[]) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const missedCalls = state.callReducer.missedCalls
    const recentMissedCall = state.callReducer.recentMissedCall
    newMissedCalls.forEach((newMissedCall) => {
        const found = missedCalls.find((missedCall) => missedCall.callContextId === newMissedCall.callContextId)
        if (found) {
            newMissedCall.seen = found.seen
        }
    })
    /** Storing most recent missed call in missedCall incase GET API does not return latest values */
    if (recentMissedCall && recentMissedCall.callContextId && !newMissedCalls.find((newMissedCall) => newMissedCall.callContextId === recentMissedCall.callContextId)) {
        newMissedCalls.push(recentMissedCall)
    }
    /** Resetting recent missed call once GET API is called */
    if (recentMissedCall.callContextId) {
        dispatch({ type: SET_RECENT_MISSED_CALL, missedCall: DEFAULT_RECENT_MISSED_CALL })
    }
    newMissedCalls.sort((a: IMissedCallData, b: IMissedCallData) => a.attemptedCallTime > b.attemptedCallTime ? -1 : 1)
    dispatch({ type: SET_MISSED_CALL_DATA, missedCalls: [...newMissedCalls] })
}

export const resetBadgeCountOfMissedCalls = (seen: boolean) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const { missedCalls } = state.callReducer
    missedCalls.forEach((item: IMissedCallData) => item.seen = seen)
    dispatch({ type: SET_MISSED_CALL_DATA, missedCalls })
}

export const setRecentMissedCall = (missedCall: IMissedCallData) => (dispatch: Dispatch) => {
    dispatch({ type: SET_RECENT_MISSED_CALL, missedCall })
}

export const updateCallTimeout = (timeout: ICallTimeout, status: boolean) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const { callTimeout } = state.callReducer
    if (status) {
        dispatch({ type: UPDATE_CALL_TIMEOUT, callTimeout: [...callTimeout, timeout] })
    } else {
        const newTimeouts = callTimeout.filter((item) => {
            if (item.contextId === timeout.contextId) {
                clearTimeout(item.timeoutId)
                return true
            }
            return false
        })
        dispatch({ type: UPDATE_CALL_TIMEOUT, callTimeout: newTimeouts })
    }
}

export const setCallRingStatus = (callRingStatus: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: SET_CALL_RING_STATUS, callRingStatus })
}

export const setConversationClientStatus = (status: EClientStatus) => (dispatch: Dispatch) => {
    dispatch({ type: SET_CONVERSATION_CLIENT_STATUS, status })
}

export const holdCall = () => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    if (!connectedCallDetails.contextId) {
        return
    }
    connectedCallDetails.callStatus = ECallStatus.PAUSED
    const newOnHoldCallDetails = [
        ...onHoldCallDetails.filter(callDetails => callDetails.contextId !== connectedCallDetails.contextId),
        connectedCallDetails,
    ]

    const callStatus = upsertCallStatus(connectedCallDetails.contextId, ECallStatus.PAUSED)
    dispatch({ type: VIDEO_CALL_STATUS, videoCallStatus: callStatus })
    dispatch({ type: UPDATE_CURRENT_AV_CALL, onHoldCallDetails: newOnHoldCallDetails, connectedCallDetails: DEFAULT_ONGOING_CALL_DETAILS })
}

export const resumeCall = (contextId: string) => (dispatch: Dispatch, getState: any) => {
    if (checkIfCallIsAlreadyActive(contextId)) {
        infoLogger(`Call context ${contextId} is already in active state`)
        return
    }

    const state: IStore = getState()
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    let [callToResume] = lodashRemove(
        onHoldCallDetails,
        (callDetails) => callDetails.contextId === contextId
    )

    if (!callToResume && connectedCallDetails.contextId === contextId) {
        callToResume = connectedCallDetails
    }

    if (callToResume) {
        callToResume.callStatus = ECallStatus.RESUMED
        const callStatus = upsertCallStatus(callToResume.contextId, ECallStatus.RESUMED)
        dispatch({ type: VIDEO_CALL_STATUS, videoCallStatus: callStatus })
    }

    dispatch({ type: UPDATE_CURRENT_AV_CALL, onHoldCallDetails, connectedCallDetails: callToResume || DEFAULT_ONGOING_CALL_DETAILS })
}

export const disconnectCall = (contextId: string) => (dispatch: Dispatch) => {
    dispatch({ type: DISCONNECT_CALL, payload: { contextId } })
}

export const setMuteCall = (activeCall: IAVCallDetails, isMuted: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: SET_CALL_MUTE, payload: { contextId: activeCall.contextId, isMuted } })
}

export const setDeafenCall = (activeCall: IAVCallDetails, isDeafened: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: SET_CALL_DEAFEN, payload: { contextId: activeCall.contextId, isDeafened } })
}

export const setCommunicationVendorName = (communicationVendor: ICommunicationVendor) => (dispatch: Dispatch) => {
    dispatch({ type: SET_COMMUNICATION_VENDOR, communicationVendor })
}
