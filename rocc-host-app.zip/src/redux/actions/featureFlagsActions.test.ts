/*
 * Created on Tue May 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { UPDATE_FEATURE_FLAGS, UPDATE_FEATURE_FLAG_CONFIGS, UPDATE_DEFAULT_FLAGS } from "./types"
import { updateFeatureFlags, setDefaultFeatureFlags, setFeatureFlagConfig } from "./featureFlagsActions"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import fetchMock from "fetch-mock"
import { initialFeatureFlagReducer } from "../reducers/featureFlagsReducer"

describe("Feature Flags actions", () => {

    const middlewares = [thunk]
    const mockStore = configureMockStore(middlewares)

    afterEach(() => {
        fetchMock.restore()
    })

    const store = mockStore(initialFeatureFlagReducer)

    it("should create an action to UPDATE_FEATURE_FLAGS", () => {
        const featureFlags = { FLAG_SELF_SERVICE: true }
        const expectedAction = {
            type: UPDATE_FEATURE_FLAGS,
            featureFlags: { featureFlags }
        }

        expect(store.dispatch(updateFeatureFlags(featureFlags))).toEqual(expectedAction)
    })

    it("should create an action to UPDATE_FEATURE_FLAG_CONFIGS", () => {
        const featureFlagConfig = { "provider": { "configuration": { "clientId": "60058a077337f70a60e8bbdf" }, "type": "LD" } }
        const expectedAction = {
            type: UPDATE_FEATURE_FLAG_CONFIGS,
            featureFlagConfig: { featureFlagConfig }
        }

        expect(store.dispatch(setFeatureFlagConfig(featureFlagConfig))).toEqual(expectedAction)
    })

    it("should create an action to UPDATE_DEFAULT_FLAGS", () => {
        const defaultFlags = { "enabledFeatures": ["rocc-web-call"] }
        const expectedAction = {
            type: UPDATE_DEFAULT_FLAGS,
            defaultFeatureFlags: defaultFlags
        }

        expect(store.dispatch(setDefaultFeatureFlags(defaultFlags))).toEqual(expectedAction)
    })
})
