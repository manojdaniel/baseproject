/*
 * Created on Tue Nov 24 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, parseIntBase10, EConnectionState } from "@rocc/rocc-client-services"
import React, { useEffect, useRef } from "react"
import { useSelector } from "react-redux"
import { IReceiver, IReceiverSelectionModal, IStore } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalConfigs } from "../../redux/store/externalAppStates"
import { EEventType, INIT_NOTIFICATION_MODAL } from "../../common/constants/constants"
import { ConsoleMonitorSelectionModal } from "@rocc/rocc-console-components"
import { GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import styles from "./ConsoleMonitorSelection.module.scss"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"
import { onReceiverUseConfirmation } from "../../common/helpers/consoleUtility"
import { getConnectionAdapter } from "../../common/helpers/connection"

const componentName = "Multi console: monitor selection"

interface IConsoleMonitorSelection {
    roomUuid: string,
    receiverSelectionModal: IReceiverSelectionModal
    connectionType: EConnectionType
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
}

const ConsoleMonitorSelection = (props: IConsoleMonitorSelection) => {

    const {
        consoleSessions,
        receivers,
        currentUser,
        rooms,
        featureFlags
    } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        currentUser: state.externalReducer.currentUser,
        rooms: state.externalReducer.rooms,
        featureFlags: state.externalReducer.featureFlags
    }))

    const { roomUuid, receiverSelectionModal, connectionType, setReceiverSelectionModal } = props
    const { showReceiverModal } = receiverSelectionModal
    const configs = fetchGlobalConfigs()
    const consoleSessionsRef = useRef(consoleSessions)

    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    const handleMonitorSelectionCancel = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: `${EEventType.CANCEL}`, Event_By: currentUser.uuid } })
        setReceiverSelectionModal({ showReceiverModal: false, connectionType: EConnectionType.DEFAULT })
        dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: INIT_NOTIFICATION_MODAL } })
    }

    const handleMonitorSelection = (receiverName: string, selectedReceiver: string) => {
        if (selectedReceiver === receiverName) {
            sendLogsToAzure({ contextData: { component: componentName, event: `${EEventType.UNSELECT}.`, Receiver_Name: receiverName, Event_By: currentUser.uuid } })
        } else {
            if (selectedReceiver) {
                sendLogsToAzure({ contextData: { component: componentName, event: `${EEventType.SWITCH}.`, From_Reciever: selectedReceiver, To_Reciever: receiverName, Event_By: currentUser.uuid } })
            } else {
                sendLogsToAzure({ contextData: { component: componentName, event: `${EEventType.SELECT}.`, Receiver_Name: receiverName, Event_By: currentUser.uuid } })
            }
        }
    }

    const handleMonitorSelectionApply = (selectedReceiver: string, roomUuid: string) => {
        sendLogsToAzure({ contextData: { component: componentName, event: `${EEventType.INITIATE_CONSOLE_SESSION}`, Call_To: roomUuid, receiverName: selectedReceiver, Call_From: currentUser.uuid } })
        setReceiverSelectionModal({ showReceiverModal: false, connectionType: EConnectionType.DEFAULT })
        const props = {
            connectionMode : EModalityConnectionMode.KVM,
            subConnectionMode: EModalitySubConnectionMode.CC,
            roomUuid,
            connectionType,
            receivers,
            selectedReceiver,
            consoleSessions: consoleSessionsRef.current,
            onReceiverSelectionRequired: ()=> setReceiverSelectionModal({ showReceiverModal: true, connectionType }),
            onReceiverUseConfirmation : (props: any)=> onReceiverUseConfirmation({...props, setReceiverSelectionModal}),
            featureFlags,
            componentName
        }
        getConnectionAdapter().connect(props)
    }

    const checkMaxConsoleSessionReached = () => {
        return configs.MAX_NUM_OF_CONSOLE_SESSION ? consoleSessions.length === parseIntBase10(configs.MAX_NUM_OF_CONSOLE_SESSION) : false
    }

    const getConsoleReceiverDetails = () => {
        //To Do create array of custom room and receiver details
        const updatedReceivers: any[] = []
        receivers.forEach((receiver: IReceiver) => {
            const activeConsoleSession = consoleSessionsRef.current.find(console => console.receiverName === receiver.receiverName)
            let roomDetails: any
            if (activeConsoleSession) {
                roomDetails = rooms.find((room) => room.roomUuid === activeConsoleSession.roomUuid)
            }
            const consoleDetails = {
                roomName: roomDetails?.roomName || "",
                roomAddress: roomDetails?.address || "",
                connectionType: activeConsoleSession?.connectionType || EConnectionType.DEFAULT,
                connectionStatus: activeConsoleSession?.connectionStatus || EConnectionState.DEFAULT
            }
            const updatedInfo = { ...receiver, consoleDetails: consoleDetails, disabled: activeConsoleSession?.connectionStatus === EConnectionState.PARKED }
            updatedReceivers.push(updatedInfo)
        })
        return updatedReceivers
    }

    return <div className={styles.consoleMonitorSelection} id="consoleMonitorSelectionModal">
        <ConsoleMonitorSelectionModal
            show={showReceiverModal}
            roomUuid={roomUuid}
            consoleReceiverDetails={getConsoleReceiverDetails()}
            maxConsoleSessionsReached={checkMaxConsoleSessionReached()}
            onCancel={handleMonitorSelectionCancel}
            onApplyClick={handleMonitorSelectionApply}
            onMonitorClick={handleMonitorSelection}
        />
    </div>
}

export default ConsoleMonitorSelection
