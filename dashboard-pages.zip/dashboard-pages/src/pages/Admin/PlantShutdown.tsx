import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import PlantShutdownTable from "table/PlantShutdownTable";
import {
	getPlantShutdown,
	updatePlantRollout,
	updatePlantRolloutStatus,
} from "../../redux/reducers/CommonReducer";
import PushNotification from "components/PushNotification";
import Loader from "components/Loader";

const PlantShutdown = () => {
	let dispatch = useDispatch();
	const [loading, setLoading] = useState<any>(false);
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);
	const { plantShutdownData, loadingPlantShutdown, plantRolloutStatus } =
		useSelector((state: any) => ({
			plantShutdownData: state.Common.plantShutdown,
			loadingPlantShutdown: state.Common.loadingPlantShutdown,
			plantRolloutStatus: state.Common.plantRolloutStatus,
		}));

	useEffect(() => {
		dispatch(getPlantShutdown(`18`));
		if (plantShutdownData.length > 0) {
			setParentData(plantShutdownData);
			setData(plantShutdownData);
		}
	}, [plantShutdownData]);

	useEffect(() => {
		if (plantRolloutStatus.length > 0) {
			if (!plantRolloutStatus.hasOwnProperty("Succeeded")) {
				if (plantRolloutStatus[0].retVal === 1) {
					PushNotification("success", plantRolloutStatus[0].retMsg);
				} else {
					PushNotification("error", plantRolloutStatus[0].retMsg);
				}
			} else {
				PushNotification("error", plantRolloutStatus.Message);
			}
			const emptyObj = [];
			dispatch(updatePlantRolloutStatus(emptyObj));
		} else {
			if (plantRolloutStatus.hasOwnProperty("Succeeded")) {
				PushNotification("error", plantRolloutStatus.Message);
			}
		}
		dispatch(getPlantShutdown(`18`));
	}, [plantRolloutStatus]);

	const handleUpdate = (plantID, isRollout) => {
		setLoading(true);
		dispatch(updatePlantRollout(`${plantID}/${isRollout}/18`));
		dispatch(getPlantShutdown(`18`));
		setLoading(false);
	};

	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.affiliateName !== null &&
				item.affiliateName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.plantName !== null &&
				item.plantName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.countryName !== null &&
				item.countryName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.abbreviation !== null &&
				item.abbreviation
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.startDate !== null &&
				item.startDate
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.endDate !== null &&
				item.endDate
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.remarks !== null &&
				item.remarks
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};
	return (
		<div id="plantshutdown">
			{loading ? <Loader /> : null}
			<div id="new-filter" className="mt0">
				<div className="nf-left">
					<div className="title">PLANT SHUTDOWN</div>
					<div className="asset-name"></div>
				</div>
				<div className="nf-right">
					<div className="rightsearch">
						<input
							type="search"
							value={query}
							onChange={handleChange}
							placeholder="Search..."
						/>
					</div>
				</div>
			</div>
			<div className="common-box-content">
				{loadingPlantShutdown ? (
					<Loader />
				) : (
					<PlantShutdownTable data={data} handleUpdate={handleUpdate} />
				)}
			</div>
		</div>
	);
};
export default PlantShutdown;
