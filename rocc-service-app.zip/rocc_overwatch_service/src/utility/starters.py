"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
from src.constants.config_keys import VAULT_LOG_PRODUCT_KEY, VAULT_SECRET_KEY, VAULT_SHARED_KEY
from src.constants.constants import API_SIGNATURE_SECRET_KEY, API_SIGNATURE_SHARED_KEY, DATA, VAULT_ROCC_CRED_PATH
from src.modules.event_management.events_initializer import setup_listeners
from src.loggers.log import create_logger
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values

LOG = create_logger("Starters")


def initialize_server():
    """
    - Setup rabbitMQ listeners
    """
    try:
        LOG.info("Initializing kibana logging")
        load_envs(path_name=os.environ.get(VAULT_ROCC_CRED_PATH))
        LOG.info("Starting listenters setup")
        setup_listeners()
    except Exception as ex:
        LOG.exception(f"Exception occurred while initializing server: {ex}")


def load_envs(path_name=None, vault_credentials_response=None, profile_configs=None):
    try:
        if profile_configs:
            os.environ[API_SIGNATURE_SHARED_KEY] = profile_configs[VAULT_SHARED_KEY]
            os.environ[API_SIGNATURE_SECRET_KEY] = profile_configs[VAULT_SECRET_KEY]
            os.environ[VAULT_LOG_PRODUCT_KEY] = profile_configs[VAULT_LOG_PRODUCT_KEY]
            LOG.info(f"Loading API_SIGNATURE_SHARED_KEY, API_SIGNATURE_SECRET_KEY and LOG_PRODUCT_KEY in the env")
            return True

        elif os.environ.get("ENV_TYPE", "dev") in ["cloud", "dev"]:
            vault_values = get_path_specific_vault_values(path_name, vault_credentials_response)
            os.environ[API_SIGNATURE_SHARED_KEY] = vault_values[DATA]["signatureAuthSharedKey"]
            os.environ[API_SIGNATURE_SECRET_KEY] = vault_values[DATA]["signatureAuthSecretKey"]
            os.environ[VAULT_LOG_PRODUCT_KEY] = vault_values[DATA]["logProductKey"]
            LOG.info(f"Loading API_SIGNATURE_SHARED_KEY, API_SIGNATURE_SECRET_KEY and LOG_PRODUCT_KEY in the CF env")
            return True

    except Exception as ex:
        LOG.error(f"Failed to load envs with error: {ex}")
    return False
