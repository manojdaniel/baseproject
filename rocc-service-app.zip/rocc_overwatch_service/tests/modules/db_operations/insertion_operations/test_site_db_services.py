import unittest
from unittest.mock import patch
from src.exceptions.RoccException import RoccException
from src.constants.headers import EXCEL_HOSPITAL_FRONTDESK_PHONE, EXCEL_HOSPITAL_SCHEDULER_PHONE
from src.modules.db_operations.insertion_services.sites_db_services import construct_front_desk_object, construct_scheduler_object, fetch_contact_type_id, construct_kvm_boxilla_object, construct_site_contacts_object, construct_eula_documents, \
    construct_new_org_details_object, construct_sites


class SiteDBServiceTest(unittest.TestCase):
    @patch("src.modules.db_operations.insertion_services.sites_db_services.fetch_contact_type_id", side_effect=lambda access_token, org_infra_uuid, is_fse:  None)
    def test_insert_existing_customer_information(self, mock_fn):
        mock_fn.return_value = "device_id"
        data = {EXCEL_HOSPITAL_FRONTDESK_PHONE: "100", }
        site_details_list = construct_front_desk_object([], 1, 1, data, {}, "")
        self.assertIsNotNone(site_details_list)

    @patch("src.modules.db_operations.insertion_services.sites_db_services.fetch_contact_type_id", side_effect=lambda access_token, org_infra_uuid, is_fse:  None)
    def test_check_if_customer_exists(self, mock_fn):
        mock_fn.return_value = "device_id"
        data = {EXCEL_HOSPITAL_SCHEDULER_PHONE: "100", }
        site_details_list = construct_scheduler_object([], 1, 1, data, {}, "")
        self.assertIsNotNone(site_details_list)

    @patch("src.modules.db_operations.insertion_services.sites_db_services.fetch_contact_type_id", side_effect=lambda access_token, org_infra_uuid, is_fse:  None)
    def test_check_if_customer_not_exists(self, mock_fn):
        mock_fn.return_value = "device_id"
        self.assertRaises(Exception, fetch_contact_type_id, {}, {}, {})

    @patch("src.modules.db_operations.insertion_services.sites_db_services.fetch_contact_type_id", side_effect=lambda access_token, org_infra_uuid, is_fse:  None)
    def test_construct_front_desk_object_exc(self, mock_fn):
        mock_fn.side_effect = RoccException(500, 'RoccException')
        data = {EXCEL_HOSPITAL_FRONTDESK_PHONE: "100", }
        self.assertRaises(RoccException, construct_front_desk_object, [], 1, 2, data, {}, "")

    @patch("src.modules.db_operations.insertion_services.sites_db_services.update_summary_for_entity", side_effect=lambda access_token, org_infra_uuid, is_fse, param:  None)
    def test_construct_kvm_boxilla_object(self, mock_fn):
        mock_fn.return_value = "abc"
        kvm_dict = {"abc": {"KVM Boxilla IP- To be filled by Philips": "123",
                            "KVM Boxilla User Name - To be filled by Philips": "123",
                            "KVM Boxilla Rest User Name - To be filled by Philips": "12"}}
        response = construct_kvm_boxilla_object(kvm_dict, "abcd", {}, "anc")
        self.assertIsNotNone(response)

    @patch("src.modules.db_operations.insertion_services.sites_db_services.construct_front_desk_object", side_effect=lambda access_token, org_infra_uuid, is_fse, param1, param2, param3:  None)
    @patch("src.modules.db_operations.insertion_services.sites_db_services.construct_scheduler_object", side_effect=lambda access_token, org_infra_uuid, is_fse, param1, param2, param3:  None)
    def test_construct_site_contacts_object_exe(self, mock_fn1, mock_fn2):
        mock_fn1.return_value = "abc"
        mock_fn2.return_value = "abc"
        kvm_dict = {"abc": {"KVM Boxilla IP- To be filled by Philips": "123",
                            "KVM Boxilla User Name - To be filled by Philips": "123",
                            "KVM Boxilla Rest User Name - To be filled by Philips": "12"}}
        response = construct_site_contacts_object(kvm_dict, "abcd", {}, "anc", "")
        self.assertIsNone(response)

    @patch("src.modules.db_operations.insertion_services.sites_db_services.construct_eula_documents", side_effect=lambda access_token, org_infra_uuid, is_fse, param:  None)
    def test_construct_eula_documents(self, mock_fn):
        mock_fn.return_value = "abc"
        kvm_dict = {}
        response = construct_eula_documents(kvm_dict, 1, "app")
        self.assertIsNotNone(response)

    def test_construct_new_org_details_object(self):
        data_dict = {"SITES_DICT": [{"IDN/Customer Identifier- To be filled by Philips": "actual org name",
                                     "IDN (Multi-hospital system name)": "display name"}],
                     "KVM_CONFIGURATION_DICT": ""}

        self.assertRaises(Exception, construct_new_org_details_object, data_dict, {}, {}, "org_hsdp_uuid", "user_uuid", [], "customer-short-name")

    def test_construct_sites(self):
        data_dict = {"SITES_DICT": [{"IDN/Customer Identifier- To be filled by Philips": "actual org name",
                                     "IDN (Multi-hospital system name)": "display name"}],
                     "KVM_CONFIGURATION_DICT": ""}

        self.assertRaises(Exception, construct_sites, data_dict, {}, {}, "org_hsdp_uuid")
