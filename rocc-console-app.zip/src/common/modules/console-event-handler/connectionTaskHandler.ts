/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, ETransactionStatus, IConsoleSession, IUserInfo } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { IConsoleTransaction } from "../../../redux/interfaces/types"
import { getCurrentConsoleSession, handleAuthorizeCCConnection, handleCCDisconnect, handleCCDisconnectAll, handleDirectCCConnection } from "../../helpers/consoleUtility"
import { displayErrorModal } from "../../helpers/helpers"
import { transformSessionTypeForAnalytics } from "../../helpers/TelemetryTrackingHelper"

export interface IHandleConnection {
    consoleSessions: IConsoleSession[]
    consoleTransaction: IConsoleTransaction
    currentUser: IUserInfo
    dispatch: Dispatch<any>
    seatName: string
}

export const handleConsoleConnection = async (props: IHandleConnection) => {
    const { currentUser, dispatch, seatName, consoleTransaction, consoleSessions } = props
    const { connectionType, roomUuid, connectionMode, contextId } = consoleTransaction
    const { VIEW, FULL_CONTROL, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT } = EConnectionType
    const componentName = "Connection Task Handler"
    // add tracking - connection initiation
    const allContextIds = consoleSessions.length ? consoleSessions.map((consoleSession) => consoleSession.contextId) : []
    const contextIds = [...allContextIds, contextId]
    sendLogsToAzure({ contextData: { component: componentName, event: transformSessionTypeForAnalytics(connectionType), source: transformSessionTypeForAnalytics(connectionMode), Call_From: currentUser.uuid, Call_To: roomUuid } })
    contextIds.length > 1 && sendLogsToAzure({ contextData: { component: componentName, event: "Active concurrent console connections", contextIds: contextIds, source: transformSessionTypeForAnalytics(connectionMode), Call_From: currentUser.uuid, Call_To: roomUuid } })

    switch (connectionType) {
        case VIEW:
        case INCOGNITO_VIEW:
        case PROTOCOL_MANAGEMENT: {
            const props = { consoleTransaction, currentUser, dispatch, seatName, updateIfNotFound: true }
            return await handleDirectCCConnection(props)
        }
        case FULL_CONTROL: {
            if (consoleTransaction.contextId) {
                const props = { consoleTransaction, currentUser, dispatch, contextId: consoleTransaction.contextId }
                return await handleAuthorizeCCConnection(props)
            } else {
                errorLogger(`Failed to initiate console session for user ${currentUser.uuid} since ContextId is not available for transaction ${JSON.stringify(consoleTransaction)}`)
                displayErrorModal()
            }
            break
        }
        default:
            infoLogger(`Requested connectionType ${connectionType} is not supported.`)
    }
    return ETransactionStatus.FAILED
}

export const handleCommandCenterConnection = async (props: IHandleConnection) => {
    return handleConsoleConnection(props)
}

export const handleEmeraldConnection = async (props: IHandleConnection) => {
    return handleConsoleConnection(props)
}

export interface IHandleDisconnction extends IHandleConnection {
    componentName: string
}

export const handleConsoleDisconnection = async (props: IHandleDisconnction) => {
    const { consoleSessions, consoleTransaction, dispatch, currentUser, componentName } = props
    const { contextId } = consoleTransaction
    let returnValue = ETransactionStatus.FAILED
    if (contextId) {
        const currentSession = getCurrentConsoleSession(consoleSessions, contextId)
        if (!currentSession) {
            errorLogger(`Requested contextId ${contextId} doesn't exist in console sessions.`)
            return returnValue
        }
        const params = { consoleSessions, currentSession, dispatch, currentUser, componentName }
        returnValue = await handleCCDisconnect(params)
    } else {
        errorLogger(`Failed to disconnect console connection since contextId is missing`)
    }
    return returnValue
}

export const handleConsoleDisconnectionAll = async (props: IHandleDisconnction) => {
    const { consoleSessions, dispatch, currentUser, componentName } = props
    const params = { consoleSessions, dispatch, currentUser, componentName }
    return await handleCCDisconnectAll(params)
}
