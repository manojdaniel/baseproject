/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EConnectionMode, EConnectionType, EPosition, FeatureFlagHelper, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { RoomBannerCameraControls, RoomBannerUserDetails } from "@rocc/rocc-console-components"
import cx from "classnames"
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { roomMonitoringMessage } from "../../../common/helpers/consoleUtility"
import { isRoomMonitoringEnabled, isRoomMonitoringEnabledForCC } from "../../../common/helpers/helpers"
import MultiCameraController from "../../../common/modules/multi-camera/controller/MultiCameraController"
import cameraStyles from "../../../common/modules/multi-camera/gallery-view/MultiCameraGalleryView.scss"
import { toggleDisplayCamera } from "../../../common/modules/multi-camera/MultiCameraHelper"
import ConsoleTrigger from "../../../ConsoleTrigger"
import { IActiveSessionWithMultiCamera, IStore } from "../../../redux/interfaces/types"
import styles from "../console-view-banner/ViewConsoleBanner.scss"

const ProtocolManagerBanner = (props: IActiveSessionWithMultiCamera) => {

    const { roomUuid, currentSession, technologistName, displayCameraState, showCameraSettings, showCameraControls, multiCameraDisabled, rightSidePanel, handleCameraSettingsClick, handleCameraSliderClick } = props

    const {
        receivers, featureFlags, displayLeftSidePanel, rooms
    } = useSelector((state: IStore) => ({
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        featureFlags: state.externalReducer.featureFlags,
        displayLeftSidePanel: state.externalReducer.displayLeftSidePanel,
        rooms: state.externalReducer.rooms
    }))

    const widthStyle = displayLeftSidePanel ? styles.narrowWidth : styles.maxWidth
    const { mediaRoomDetails, displayCameraToggle } = currentSession
    const { mediaRoomId } = mediaRoomDetails
    const roomMonitoringFeature = isRoomMonitoringEnabled(featureFlags)
    let cameraAvailable = rooms.find((roomInfo) => roomInfo.roomUuid === roomUuid)?.cameraAvailable
    cameraAvailable = cameraAvailable === undefined ? true : cameraAvailable
    const dispatch = useDispatch()

    useEffect(() => {
        if (mediaRoomId && cameraAvailable && (!roomMonitoringFeature || currentSession.connectionMode !== EConnectionMode.CC) && FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.MULTI_CAMERA) && !displayCameraToggle) {
            toggleDisplayCamera(currentSession, dispatch)
        }

    }, [mediaRoomId])

    const consoleCameraController = () => {
        return isRoomMonitoringEnabledForCC(featureFlags, currentSession) ?
            receivers.length > 1 ? <div className={styles.cameraContainer}>{roomMonitoringMessage(widthStyle, cameraStyles)}</div>
                : <></>
            : <div className={styles.cameraContainer}><MultiCameraController consoleSession={currentSession} /></div>
    }

    return (
        <div className={cx(styles.mainContainer, rightSidePanel && styles.sideBarOpenStyles)} id={"protocolManagementSessionContainer"}>
            <div className={styles.roomBannerContainer} id="protocolManagementBannerContainer">
                <RoomBannerUserDetails name={technologistName} />
                {showCameraControls && <RoomBannerCameraControls
                    displayCamerasState={displayCameraState}
                    showCameraSettings={showCameraSettings}
                    isDisabled={multiCameraDisabled}
                    handleCameraSettingsClick={() => handleCameraSettingsClick()}
                    handleCameraSliderClick={() => handleCameraSliderClick()}
                />}
                <div className={styles.consoleButtons} id="bannerButtons">
                    <div>
                        <ConsoleTrigger
                            connectionType={EConnectionType.PROTOCOL_MANAGEMENT}
                            roomUuid={roomUuid}
                            showTitle={true}
                            iconPosition={EPosition.VERTICAL}
                        />
                    </div>
                </div>
            </div>

            {consoleCameraController()}
        </div>
    )
}

export default ProtocolManagerBanner
