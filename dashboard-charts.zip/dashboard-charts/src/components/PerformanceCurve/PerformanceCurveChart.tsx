// @ts-nocheck
import React, { useRef, useLayoutEffect, useState, useEffect } from 'react';
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import "./PerformanceCurveChart.scss";
import { useNavigate } from "react-router-dom";
interface Props {
  buttonName: string;
  onClickHandler: any;
}

let data = [
  {
    "assetId": "22P-301",
    "flow": 30,
    "power": 262.92,
    "efficiency": 51.37,
    "head": 1355.9,
    "powerY": 340.93,
    "powerX": 37,
    "efficiencyY": 56.93,
    "efficiencyX": 37,
    "headY": 1278.93,
    "headX": 37,
  },
  {
    "assetId": "22P-301",
    "flow": 35,
    "power": 285.88,
    "efficiency": 54.44,
    "head": 1347.56,
    "powerY": 340.93,
    "powerX": 37,
    "efficiencyY": 56.93,
    "efficiencyX": 37,
    "headY": 1278.93,
    "headX": 37,
  },
  {
    "assetId": "22P-301",
    "flow": 40,
    "power": 308.86,
    "efficiency": 56.75,
    "head": 1329.61,
    "powerY": 340.93,
    "powerX": 37,
    "efficiencyY": 56.93,
    "efficiencyX": 37,
    "headY": 1278.93,
    "headX": 37,
  },
  {
    "assetId": "22P-301",
    "flow": 45,
    "power": 332.78,
    "efficiency": 57.52,
    "head": 1294.33,
    "powerY": 340.93,
    "powerX": 37,
    "efficiencyY": 56.93,
    "efficiencyX": 37,
    "headY": 1278.93,
    "headX": 37,
  },
];

const data3 = [
  {
    "avgY": 561.93,
    "avgX": 37,
    bulletSettings: {
      fill: am5.color(0x946B49)
    }
  },
]

let data2 = [
  {
    "localTime": "2020-10-12T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Bearing",
    "distance": 3.134,
    "alertThreshold": 52.955,
    "warningThreshold": 27.97,
    "status": "Normal"
  },
  {
    "localTime": "2020-10-13T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Performance",
    "distance": 0.664,
    "alertThreshold": 41.955,
    "warningThreshold": 27.97,
    "status": "Poor data"
  },
  {
    "localTime": "2020-10-14T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Mixer Gearbox Bearing",
    "distance": 1.569,
    "alertThreshold": 41.955,
    "status": "warning"
  },
  {
    "localTime": "2020-10-15T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Mixer Bearing",
    "distance": 1.653,
    "alertThreshold": 41.955,
    "warningThreshold": 27.97,
    "status": "AssetOff"
  },
  {
    "localTime": "2020-10-16T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Gear Pump Motor Bearing",
    "distance": 0.186,
    "alertThreshold": 41.955,
    "warningThreshold": 27.97,
    "status": "Pi disconnection"
  },

]

let Topdata1 = [
  {
    "localTime": "2020-10-12T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Bearing",
    "power": 3.134,
    "temperature": 41.955,
    "pressure": 27.97
  },
  {
    "localTime": "2020-10-13T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Performance",
    "power": 0.664,
    "temperature": 48.955,
    "pressure": 32.97
  },

  {
    "localTime": "2020-10-14T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Performance",
    "power": 2.3,
    "temperature": 61.7,
    "pressure": 40.3
  },
  {
    "localTime": "2020-10-16T01:27:00",
    "assetSapId": "310061001",
    "sensorGroupName": "Main Motor Performance",
    "power": 1.2,
    "temperature": 24.5,
    "pressure": 15.6
  },
]



const PerformanceCurveChart = () => {
  const navigate = useNavigate();
  useLayoutEffect(() => {
    var root = am5.Root.new("chartdiv");

    root.setThemes([
      am5themes_Animated.new(root)
    ]);

    var chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        focusable: true,
        panX: true,
        panY: true,
        wheelX: "panX",
        wheelY: "zoomX",
        pinchZoomX: true
      })
    );

    var yRenderer2 = am5xy.AxisRendererY.new(root, {})
    yRenderer2.labels.template.set('visible', false)

    var yAxis2 = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        maxDeviation: 1,
        renderer: yRenderer2,
      })
    );

    var xAxis = chart.xAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererX.new(root, {}),
        tooltip: am5.Tooltip.new(root, {})
      })
    );

    function createSeries1(name, field, opposite, colorCode, fieldX, fieldY) {
      let yRenderer = am5xy.AxisRendererY.new(root, {
        opposite: opposite
      });
      let yAxis1 = chart.yAxes.push(
        am5xy.ValueAxis.new(root, {
          maxDeviation: 1,
          renderer: yRenderer
        })
      );
      if (chart.yAxes.indexOf(yAxis1) > 0) {
        yAxis1.set("syncWithAxis", chart.yAxes.getIndex(0));
      }
      let Series1 = chart.series.push(
        am5xy.LineSeries.new(root, {
          name: name,
          marginRight: 40,
          paddingRight: 20,
          xAxis: xAxis,
          yAxis: yAxis1,
          valueYField: field,
          stroke: am5.color(colorCode),
          valueXField: "flow",
          tooltip: am5.Tooltip.new(root, {
            pointerOrientation: "horizontal",
            labelText: "{valueX}/{valueY}",
          })
        })
      );
      Series1.strokes.template.setAll({ strokeWidth: 3 });
      yRenderer.grid.template.set("strokeOpacity", 0.05);
      yRenderer.labels.template.set("fill", am5.color(colorCode));
      yRenderer.setAll({
        stroke: am5.color(colorCode),
        strokeOpacity: 1,
        opacity: 1
      });
      Series1.data.setAll(data);
      var series = chart.series.push(
        am5xy.LineSeries.new(root, {
          minBulletDistance: 10,
          xAxis: xAxis,
          yAxis: yAxis1,
          valueYField: fieldY,
          valueXField: fieldX,
          tooltip: am5.Tooltip.new(root, {
            pointerOrientation: "horizontal",
            labelText: "{valueX}/{valueY}",
          })
        })
      );
      var bulletTemplate = am5.Template.new({
        fill: am5.color(0xE6E6E6)
      });
      series.bullets.push(function () {
        return am5.Bullet.new(root, {
          sprite: am5.Circle.new(root, {
            radius: 10,
            fill: am5.color(colorCode)
          }, bulletTemplate)
        });
      });
      series.data.setAll(data)
    }

    let cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
      xAxis: xAxis,
      behavior: "none"
    }));
    cursor.lineY.set("visible", false);
    cursor.lineX.set("visible", false);

    if (data.filter(item => item.power === null).length === 0) {
      createSeries1("Power", "power", false, 0x2a7a2d, "powerX", "powerY")
    }
    if (data.filter(item => item.efficiency === null).length === 0) {
      createSeries1("Efficiency", "efficiency", false, 0xc74e0e, "efficiencyX", "efficiencyY")
    }
    if (data.filter(item => item.head === null).length === 0) {
      createSeries1("Head", "head", false, 0x3e6691, "headX", "headY")
    }

    var bulletformat = {

      fill: am5.color(0x946B49)
    }

    // Make stuff animate on load
    // https://www.amcharts.com/docs/v5/concepts/animations/
    chart.appear(100, 100);


    return () => {
      root.dispose();
    };
  }, []);

  const handleNavigation = () => {
    navigate('/assets/plots')
  }

  return (
    <div id="performance-curve">
      <div className="performance-left">
        <div id="chartdiv" style={{ width: "100%", height: "400px", }}></div>

      </div>
      <div className='performance-right'>
        <div id="performance-names-names">
          <div className="performance-list">

            <div onClick={handleNavigation} style={{ cursor: "pointer" }}><span style={{ background: '#3bb44a' }}></span><span>Power</span></div>

            <div onClick={handleNavigation} style={{ cursor: "pointer" }}><span style={{ background: '#4e79a7' }}></span><span>Efficiency</span></div>

            <div onClick={handleNavigation} style={{ cursor: "pointer" }}><span style={{ background: '#e35205' }}></span><span>Head</span></div>

            <div onClick={handleNavigation} style={{ cursor: "pointer" }}><span style={{ background: '#000000' }}></span><span>Flow</span></div>

          </div>
        </div>
      </div>
    </div>

  );
};
export default PerformanceCurveChart;