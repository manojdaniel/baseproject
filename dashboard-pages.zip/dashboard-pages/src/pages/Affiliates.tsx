import React, { useRef, useEffect, useState } from "react";
import Dropdown from "components/Dropdown";
import ListComponent from "components/ListComponent";
import HealthIndexComponent from "components/HealthIndexComponent";
import NoData from "components/NoData";
import {
	getRegionDropdownList,
	getAffiliateTopBar,
	getAffiliateDetails,
	getGlobalSelecetedRegion,
	getGlobalSelecetedAffiliate,
} from "../redux/reducers/CommonReducer";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Status from "components/Status";
import "./Affiliates.scss";
import { All_PLANTS_ROUTE } from "../constant/constants";
import Loader from "components/Loader";
import { encryptRSAData } from "../utility/rsa";

const Affiliates = () => {
	let dispatch = useDispatch();
	let navigate = useNavigate();

	const [selectedRegion, setSelectedRegion] = useState<any>({
		value: 0,
		label: "All",
	});
	const [sortedData, setSortedData] = useState<any>([]);

	const {
		searchValue,
		regionDropdownList,
		affiliateTopBar,
		affiliateDetails,
		globalSelecetedRegion,
		loadingRegionDropdownList,
		loadingAffiliateDetails,
		loadingAffiliateTopBar,
		onePlantUser,
	} = useSelector((state: any) => ({
		searchValue: state.Common.searchValue,
		regionDropdownList: state.Common.regionDropdownList,
		affiliateTopBar: state.Common.affiliateTopBar,
		affiliateDetails: state.Common.affiliateDetails,
		globalSelecetedRegion: state.Common.globalSelecetedRegion,

		loadingRegionDropdownList: state.Common.loadingRegionDropdownList,
		loadingAffiliateDetails: state.Common.loadingAffiliateDetails,
		loadingAffiliateTopBar: state.Common.loadingAffiliateTopBar,

		onePlantUser: state.Common.onePlantUser,
	}));

	useEffect(() => {
		if (Object.keys(globalSelecetedRegion).length > 0) {
			dispatch(getRegionDropdownList("")); //{userId}
			setSelectedRegion(globalSelecetedRegion);
			dispatch(
				getAffiliateTopBar(
					encryptRSAData(`regionId=${globalSelecetedRegion.value}`)
				)
			); //{regionId}/{userId}
			dispatch(
				getAffiliateDetails(
					encryptRSAData(`regionId=${globalSelecetedRegion.value}`)
				)
			); //{ regionId}/{userId}
		} else {
			dispatch(getRegionDropdownList("")); //{userId}
			dispatch(getAffiliateTopBar(encryptRSAData(`regionId=0`))); //{regionId}/{userId}
			dispatch(getAffiliateDetails(encryptRSAData(`regionId=0`))); //{ regionId}/{userId}
		}
	}, [globalSelecetedRegion]);

	const handleRegionDropDown = (e: any) => {
		setSelectedRegion(e);
		dispatch(getAffiliateTopBar(encryptRSAData(`regionId=${e.value}`))); //{regionId}/{userId}
		dispatch(getAffiliateDetails(encryptRSAData(`regionId=${e.value}`))); //{ regionId}/{userId}
		dispatch(
			getGlobalSelecetedRegion({
				value: e.value,
				label: e.label,
			})
		);
	};

	const handleOnClick = (item: any) => {
		dispatch(
			getGlobalSelecetedRegion({
				value: selectedRegion.value,
				label: selectedRegion.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedAffiliate({ value: item.affiliateId, label: item.name })
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		navigate(All_PLANTS_ROUTE);
	};

	useEffect(() => {
		let list = affiliateDetails
			.slice()
			.sort((a, b) => b.healthIndex - a.healthIndex);
		setSortedData(list);
	}, [affiliateDetails]);

	useEffect(() => {
		if (onePlantUser === 1) {
			navigate(`/plant/pmt`);
		}
	}, []);

	return (
		<>
			{loadingAffiliateTopBar ? (
				<div className="statusloader">
					<Loader />
				</div>
			) : affiliateTopBar.length === 0 ? (
				<NoData />
			) : (
				<Status data={affiliateTopBar} page={"AFFILIATE"} healthIndex={[]} />
			)}
			<div id="affilates-page">
				<div id="affilates-left">
					<div className="common-box-inner">
						<div className="common-box-filter">
							<div className="title">
								{Object.keys(selectedRegion).length > 0
									? `${selectedRegion.label} AFFILIATES LIST`
									: "GLOBAL AFFILIATES LIST"}
							</div>
						</div>

						<div id="new-filter">
							<div className="nf-left">
								<div className="subtext-name">
									Click on the affiliate to get more details
								</div>
							</div>
							<div className="nf-right">
								<div>
									<label className="cus-label">Region</label>
									<Dropdown
										name={"Asset Id"}
										options={regionDropdownList}
										handleChange={handleRegionDropDown}
										value={selectedRegion}
										defaultValue={""}
										loading={loadingRegionDropdownList}
									/>
								</div>
							</div>
						</div>
						<div className="affilates-box">
							{loadingAffiliateDetails ? (
								<div className="fullloader">
									<Loader />
								</div>
							) : affiliateDetails.length === 0 ? (
								<div className="fullloader">
								<NoData />
								</div>
							) : (
								<>
									{affiliateDetails.map((item: any) => (
										<ListComponent
											item={item}
											handleOnClick={handleOnClick}
											title={"AFFILIATE"}
										/>
									))}
								</>
							)}
						</div>
					</div>
				</div>
				<div id="affilates-right">
					<div className="common-box-inner">
						<div className="common-box-filter">
							<div className="title">AFFILIATES HEALTH INDEX</div>
						</div>

						<div className="common-box-asset-name custheight-list">
							<div className="asset-name">
								Click on the affiliate to get more details
							</div>
						</div>
						<div className="affilates-box">
							{loadingAffiliateDetails ? (
								<div className="fullloader">
									<Loader />
								</div>
							) : sortedData.length === 0 ? (
								<div className="fullloader"><NoData /></div>
							) : (
								<>
									{sortedData.map((item: any) => (
										<HealthIndexComponent item={item} title={"AFFILIATE"} />
									))}
								</>
							)}
						</div>
					</div>
				</div>
			</div>
		</>
	);
};

export default Affiliates;

{
	/* <div>{searchValue.id}</div> */
}
