"""
 Created on Wed Sep 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import traceback

import requests

from src.constants.config_keys import CUSTOMER_OB_SELECTED_ROLES, VAULT_PARENT_ORG_ID
from src.exceptions.RoccException import RoccException
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, PHILIPS_ROCC_URI, AUTHORIZATION, ORG_CTXT_HEADER, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, DATA
from src.constants.headers import RBAC_PERMISSIONS_FILE_PATH, RBAC_MAPPINGS_FILE_PATH, FSE_RBAC_ROLES_FILE_PATH
from src.loggers.log import create_logger
from src.utility.utility import log_error_reasons
from src.modules.db_operations.db_utility.common_query_functions import fetch_clinical_role_id
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values

LOG = create_logger("ROCCRBACRoleServices")


def fetch_rbac_role_for_devices(url, device_ids, token, org_ctxt_header):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token,
        ORG_CTXT_HEADER: str(org_ctxt_header)
    }
    extract_device_ids = []
    try:
        response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/UserRoleMapping/bulk",
                                 data=json.dumps(device_ids),
                                 headers=headers)
        if response.status_code == 200:
            LOG.info("Rbac roles for given ids fetched successfully")
            response_array = response.json()
            for response_object in response_array:
                if response_object["roles"] is None or "DEVICEROLE" not in response_object["roles"]:
                    extract_device_ids.append(
                        {"userId": response_object["userId"], "role": "DEVICEROLE"})
        else:
            LOG.error(
                f"Failed to fetch user-role mapping for devices with error:  {response.json()}")
    except Exception as ex:
        LOG.exception(
            f"Exception occured while fetching user-role mapping for devices, error: {ex}")
    return extract_device_ids


def create_user_role_mapping(url, user_role_mapping, token, org_ctxt_header):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token,
        ORG_CTXT_HEADER: str(org_ctxt_header)
    }
    try:
        response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/UserRoleMapping",
                                 data=json.dumps(user_role_mapping),
                                 headers=headers)
        if response.status_code == 201:
            LOG.info("User Role Mappings are created successfully....")
            return True
        else:
            LOG.error(
                f"Failed to create user role mapping :  {response.json()}")

    except Exception as ex:
        LOG.exception(
            f"Exception occured while creating user role mapping : {ex}")
    return False


def update_user_role_mapping(url, user_role_mapping, token, user_uuid, org_ctxt_header):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token,
        ORG_CTXT_HEADER: str(org_ctxt_header)
    }
    try:
        response = requests.put(url=f"{url}{PHILIPS_ROCC_URI}/UserRoleMapping/{user_uuid}",
                                data=json.dumps(user_role_mapping),
                                headers=headers)
        if response.status_code == 200:
            LOG.info("User Role Mappings in RBAC updated successfully")
            return True
        else:
            LOG.error(
                f"Failed to create user role mapping in RBAC with error : {response.json()}")

    except Exception as ex:
        LOG.exception(
            f"Failed while creating user role mapping in RBAC with exception: {ex}")
    return False


def setup_fse_rbac_role_mappings_for_parent_org(proxy_url, profile_configs, vault_credentials_response, org_id, user_uuid):
    """
    1. Check if roles exists already in db, else insert into DB
    2. Check if all roles, permission, role-permission mappings exists, if not insert
    """
    parent_token = ""
    fse_rbac_details = []
    try:
        global_vault_values = get_path_specific_vault_values(
            path_name=profile_configs["VAULT_ROCC_GLOBAL_PATH"], vault_credentials_response=vault_credentials_response)

        parent_token = create_service_token_from_vault(iam_url=profile_configs["HSDP_IAM_URL"],
                                                       issuer=global_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                       private_key=global_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
        client = get_client_connection(access_token=parent_token,
                                       org_infra_uuid=org_id,
                                       url=proxy_url)
        with open(FSE_RBAC_ROLES_FILE_PATH) as rbac_roles_file:
            fse_rbac_details = json.load(rbac_roles_file)
            create_rbac_roles_in_db(
                client=client, rbac_roles=fse_rbac_details["ROLES"], user_uuid=user_uuid)
    except Exception as ex:
        LOG.exception(f"Exception occur while reading rbac role details: {ex}")
        LOG.info(traceback.print_exc())
    try:
        if create_roles_in_rbac(url=proxy_url,
                                token=parent_token,
                                org_id=profile_configs[VAULT_PARENT_ORG_ID],
                                rbac_roles=fse_rbac_details["ROLES"]):
            setup_rbac_permissions(url=proxy_url,
                                   token=parent_token,
                                   roles_of_parent_org=True)
            response, error_reasn = create_role_permissions_mapping(url=proxy_url, token=parent_token, org_id=profile_configs[VAULT_PARENT_ORG_ID], rbac_details=fse_rbac_details,
                                                                    roles_of_parent_org=True)
            log_error_reasons(log=LOG, log_type="error", error_reason=error_reasn,
                              method_name="setup_fse_rbac_role_mappings_for_parent_org")
            return response
    except Exception as ex:
        LOG.info(
            f"Exception occurred while creating roles and permission mapping: {ex}")
        LOG.info(traceback.print_exc())


def setup_roles_for_org_service(url, token, org_id, client, user_uuid, infra_configs):
    response = ""
    error_reasn = ""
    try:
        create_rbac_roles_in_db(
            client, rbac_roles=infra_configs[CUSTOMER_OB_SELECTED_ROLES]["ROLES"], user_uuid=user_uuid)
    except Exception as ex:
        LOG.exception(f"Exception occur while reading rbac role details: {ex}")
        error_reasn = f"Exception occur while reading rbac role details: {repr(ex.args)}"

    if create_roles_in_rbac(url, token, org_id, infra_configs[CUSTOMER_OB_SELECTED_ROLES]["ROLES"]):
        response, response_error_reasn = create_role_permissions_mapping(
            url, token, org_id, infra_configs[CUSTOMER_OB_SELECTED_ROLES]["ROLES"])
        if not error_reasn:
            error_reasn = response_error_reasn
    return response, error_reasn


def create_rbac_roles_in_db(client, rbac_roles, user_uuid):
    try:
        for role in rbac_roles:
            role_id = fetch_clinical_role_id(
                role, client=client, user_uuid=user_uuid)
            LOG.info(f"Id for role {role} is {role_id}")
    except Exception as ex:
        LOG.exception(
            f"Exception occur while rbac role creation in DB with error: {ex}")


def create_roles_in_rbac(url, token, org_id, rbac_roles):
    try:
        roles_object = []
        if len(rbac_roles) > 0:
            available_roles = get_rolelist_for_organization(url, token, org_id)
            for role in rbac_roles:
                if role not in available_roles:
                    roles_object.append({"role": role.upper()})
        if len(roles_object) > 0:
            headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token,
                       ORG_CTXT_HEADER: str({"Org-Id": org_id})}
            response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/Role",
                                     data=json.dumps(roles_object),
                                     headers=headers)
            if response.status_code == 201:
                LOG.info(f"Roles are created successfully for org: {org_id}")
                return True
            else:
                LOG.error(
                    f"Failed to create roles for org: {org_id} : {response.json()}")
        else:
            LOG.info(
                f"All roles are already available in RBAC for org: {org_id}")
            return True
    except Exception as ex:
        LOG.exception(
            f"Exception occurred while creating roles for org: {org_id} : {ex}")
    return False


def get_rolelist_for_organization(url, token, org_id):
    roles = []
    try:
        headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token,
                   ORG_CTXT_HEADER: str({"Org-Id": org_id})}
        response = requests.get(url=f"{url}{PHILIPS_ROCC_URI}/OrgRole",
                                headers=headers)
        if response.status_code == 200:
            json_response = response.json()
            LOG.info(f"Get RoleList : {json_response}")
            for role_object in json_response:
                roles.append(role_object["role"])
    except Exception as ex:
        LOG.exception(
            f"Exception occurred while fetching roles for org_id: {org_id} : {ex}")

    return set(roles)


def create_role_permissions_mapping(url, token, org_id, rbac_details, roles_of_parent_org=False):
    response_status = False
    error_reasn = ""
    try:
        all_role_permission = []
        new_role_mappings = []
        rbac_roles = []
        if not roles_of_parent_org:
            # If Rbac for Org. rbac_details will be rbac_roles. Like "ADMINROLE, EXPERUSERROL"
            rbac_roles = rbac_details
            with open(RBAC_MAPPINGS_FILE_PATH) as rbac_mapping_file:
                all_role_permission = json.load(rbac_mapping_file)
        else:
            # If Rbac for Parent Org. Rbac details will be Json containing Roles, Permissions and Mappings
            rbac_roles = rbac_details["ROLES"]
            all_role_permission = rbac_details["MAPPINGS"]
        for role in rbac_roles:
            permissions = []
            if role in all_role_permission.keys():
                role_permission = all_role_permission[role]
                new_role_mappings = generate_role_mappings(
                    url, token, org_id, role_permission, new_role_mappings, permissions, role)
        if len(new_role_mappings) > 0:
            LOG.info(f"New new_role_mappings : {new_role_mappings}")
            headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token,
                       ORG_CTXT_HEADER: str({"Org-Id": org_id})}
            response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/RolePermissionMapping/",
                                     data=json.dumps(new_role_mappings),
                                     headers=headers)
            if response.status_code == 201:
                LOG.info(
                    f"Role Permission mappings are created successfully for org: {org_id}")
                response_status = True
            else:
                LOG.error(
                    f"Failed to create Role Permission mappings for org: {org_id} with error: {response.json()}")
                error_reasn = f"Failed to create Role Permission mappings for org: {org_id} with error: {response.json()}"
        else:
            LOG.info(f"Role Permissions are already available for {org_id}")
            response_status = True

    except Exception as ex:
        LOG.exception(
            f"Exception occured while creating role permission mapping for org: {org_id} with error: {ex}")
        error_reasn = f"Exception occured while creating role permission mapping for org: {org_id} with error: {repr(ex.args)}"
    return response_status, error_reasn


def generate_role_mappings(url, token, org_id, role_permission, new_role_mappings, permissions, infra_role):
    available_permissions = get_existing_permission_list_for_org(
        url, token, infra_role, org_id)
    for resource, actions in role_permission.items():
        action_list = actions.split(",")
        for action in action_list:
            permission = {"resource": resource, "action": action.strip()}
            if permission not in available_permissions:
                permissions.append(permission)
        if len(permissions) > 0:
            new_role_mappings.append(
                {"role": infra_role, "permissions": permissions})
    return new_role_mappings


def get_existing_permission_list_for_org(url, token, infra_role, org_id):
    role_permissions = []
    try:
        headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token,
                   ORG_CTXT_HEADER: str({"Org-Id": org_id})}
        response = requests.get(url=f"{url}{PHILIPS_ROCC_URI}/RolePermissionMapping/{infra_role}",
                                headers=headers)
        if response.status_code == 200:
            json_response = response.json()
            if "permissions" in json_response:
                return json_response["permissions"]
        else:
            LOG.warn(
                f"Could not get Role: {infra_role} reason: {response.json()}")

    except Exception as ex:
        LOG.exception(f"Exception occurred while roles creation : {ex}")

    return role_permissions


def get_available_permissions(url, token):
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    permissions = []
    try:
        response = requests.get(
            url=f"{url}{PHILIPS_ROCC_URI}/Permission", headers=headers)
        if response.status_code == 200:
            json_response = response.json()
            for permission in json_response:
                permissions.append(
                    {"action": permission["action"], "resource": permission["resource"]})
        else:
            LOG.error(
                f"Failed to fetch existing permissions with error: {response.json()}")
    except Exception as ex:
        LOG.error(f"Failed to fetch existing permissions with error: {ex}")
    return permissions


def get_roles_for_organization(url, token):
    try:
        LOG.info("Getting roles for organization")
        headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: token}
        response = requests.get(url=f"https://{url}{PHILIPS_ROCC_URI}/OrgRole",
                                headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception
    except Exception as ex:
        LOG.exception(
            f"Exception occurred while fetching roles for org : {ex}")


def update_roles_for_organization(url, added_roles, deleted_roles, org_id, token, client, user_uuid):
    update_success = True
    try:
        if len(deleted_roles):
            response_delete = delete_roles_for_organization(
                url, deleted_roles, token)
            if not response_delete:
                update_success = False
        if (update_success and len(added_roles) > 0):
            try:
                create_rbac_roles_in_db(
                    client, rbac_roles=added_roles, user_uuid=user_uuid)
            except Exception as ex:
                LOG.exception(
                    f"Exception occur while creating rbac roles in db : {ex}")
                return False

            if create_roles_in_rbac(url, token, org_id, added_roles):
                response, error_reasn = create_role_permissions_mapping(
                    url, token, org_id, added_roles)
                log_error_reasons(
                    log=LOG, log_type="error", error_reason=f"error in create_role_permissions_mapping due to:{error_reasn}", method_name="update_roles_for_organization")
                if not response:
                    update_success = False
    except Exception as ex:
        LOG.exception(f"Exception occur while updating rbac roles : {ex}")
    return update_success


def delete_roles_for_organization(url, deleted_roles, token):
    rbac_headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    try:
        for role in deleted_roles:
            response = requests.delete(f"{url}/philips/rocc//Role/{role.get('id')}",
                                       headers=rbac_headers)
            if response.status_code not in [200, 204]:
                LOG.info(
                    f"role deletion failed: {role.get('role')}. Response {response}")
                return False

    except Exception as ex:
        LOG.exception(f"Exception occur while deleting rbac roles : {ex}")
        return False
    return True


def setup_rbac_permissions(url, token, roles_of_parent_org=False):
    # Permissions setup during root org creation
    try:
        resource_action_list = []
        permissions = []
        new_permissions = []
        if not roles_of_parent_org:
            with open(RBAC_PERMISSIONS_FILE_PATH) as rbac_permissions_file:
                resource_action_list = json.load(rbac_permissions_file)
        else:
            with open(FSE_RBAC_ROLES_FILE_PATH) as rbac_roles_file:
                data = json.load(rbac_roles_file)
                resource_action_list = data["PERMISSIONS"]
        for resource, action_list in resource_action_list.items():
            for action in action_list:
                permissions.append(
                    {"resource": resource.upper(), "action": action.upper()})

        available_permissions = get_available_permissions(url, token)
        for permission in permissions:
            if permission not in available_permissions:
                new_permissions.append(permission)

        if len(new_permissions) > 0:
            LOG.info(
                f"New Permissions that will be considered for setup are: {new_permissions}")
            headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
            try:
                response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/Permission",
                                         data=json.dumps(new_permissions),
                                         headers=headers)
                if response.status_code == 201:
                    LOG.info("RBAC Permissions are created successfully")
                    return True
                else:
                    LOG.error(
                        f"Failed to create permissions with error: {response.json()}")
            except Exception as ex:
                LOG.error(f"Failed to create permissions with error: {ex}")
        else:
            LOG.info(
                "All permissions are already present in Rocc RBAC service, hence skipping the operation")
            return True
    except Exception as ex:
        LOG.exception(f"Failed to create permissions with exception: {ex}")
        raise ex
    return False


def validate_permissions(url, token, resource_name, action_name, userid, org_infra_uuid):
    request_body = [{"resource": resource_name, "action": action_name}]
    org_ctxt_header = {"Org-Id": org_infra_uuid}
    headers = {CONTENT_TYPE: APPLICATION_JSON,
               AUTHORIZATION: token,
               "org_ctxt_header": str(org_ctxt_header)}
    try:
        response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/Validate/{userid}",
                                 data=json.dumps(request_body),
                                 headers=headers)
        if response.status_code == 200:
            LOG.info("RBAC Permissions validated successfully")
            return True
        else:
            LOG.error(f"RBAC Permissions validated failed {response}")
            raise RoccException(status_code=403,
                                title="Not Allowed",
                                payload="Insufficient permission to perform this action")
    except RoccException as ex:
        raise ex
    except Exception as ex:
        raise RoccException(status_code=500,
                            title="Internal Server Error",
                            payload="RbAc permission validation failure") from ex
