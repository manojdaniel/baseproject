import React, { useState, useEffect } from "react";
import { Table, Layout, Tooltip } from "antd";
import moment from "moment";
import Link from "antd/es/typography/Link";

interface Props {
	data: any[];
	handleUpdate: any;
}
const AlertStatusList = ({ data, handleUpdate }: Props) => {
	const [alertStatuslist, setAlertStatuslist] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);

		let mydata = data.map(function (item: any) {
			return {
				timeStamp: moment(new Date(`${item.timeStamp}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				assetId: (
					<Link
						className="table-cust-link"
						onClick={() => handleClickAsset(item.assetId)}
					>
						{item.assetId}
					</Link>
				),
				alertId: (
					<Link
						className="table-cust-link"
						onClick={() => handleClickAlert(item.assetId, item.sensorGroupId, item.modelName, item.state, item.alertId)}
					>
						{item.alertId}
					</Link>
				),
				assetDescription: (
					<Link
						className="leftalignlink table-cust-link"
						onClick={() => handleClickAsset(item.assetId)}
					>
						{item.assetDescription}
					</Link>
				),
				modelName: (
					<Link
						className="leftalignlink table-cust-link"
						onClick={() =>
							handleClickModel(item.assetId, item.sensorGroupId, item.modelName)
						}
					>
						{item.modelName}
					</Link>
				),
				alertStatus: item.alertStatus,
				modelStatus: item.modelStatus,
				alertType: item.alertType,
				ageing: item.ageing,
				recommendation: item.recommendation,
				state: item.state,
				department: item.department,
			};
		});
		setAlertStatuslist(mydata);
	}, [data]);

	const getTooltipContentAlertStatus = (getdata: any) => {
		try {
			const getRecommendationAlertStatus = alertStatuslist.filter(
				({ alertId }) => alertId === getdata
			);
			const getmsgAlertStatus = getRecommendationAlertStatus[0].recommendation;
			const replacenumAlertStatus = getmsgAlertStatus.replace(/[0-9]/g, "");
			const splitvalueAlertStatus = replacenumAlertStatus.split(".");
			const getTooltipArAlertStatus = splitvalueAlertStatus.filter(function (
				v: any
			) {
				return v !== " ";
			});
			const getTooltipArAlertStatusFinal = getTooltipArAlertStatus.filter(
				(item) => item
			);

			return getTooltipArAlertStatusFinal.map((item: any, index: any) => (
				<div>
					<span>{index + 1}.</span>
					<span>{item}</span>
				</div>
			));
		} catch (error) { }
	};

	const handleClickAlert = (assetId, sensorId, modelName, state, alertId) => {
		handleUpdate('alertlist', assetId, sensorId, modelName, state, alertId )

	}
	const handleClickAsset = (assetId) => {
		handleUpdate("assetModel", assetId);
	};
	const handleClickModel = (assetId, sensorId, modelName) => {
		handleUpdate("plots", assetId, sensorId, modelName);
	};

	const columns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: "10%",
		},
		{
			title: "ASSET ID",
			dataIndex: "assetId",
			key: "assetId",
			width: "8%",
		},
		{
			title: "ALERT ID",
			dataIndex: "alertId",
			key: "alertId",
			render: (alertId: any) => (
				<Tooltip title={getTooltipContentAlertStatus(alertId)}>
					{alertId}
				</Tooltip>
			),
			width: "8%",
		},
		{
			title: "ASSET DESCRIPTION",
			dataIndex: "assetDescription",
			key: "assetdescription",
			width: "15%",
		},
		{
			title: "MODEL NAME",
			dataIndex: "modelName",
			key: "modelName",
			width: "13%",
		},
		{
			title: "ALERT STATUS",
			dataIndex: "alertStatus",
			key: "alertStatus",
			width: "7%",
		},

		{
			title: "MODEL STATUS",
			dataIndex: "modelStatus",
			key: "modelStatus",
			width: "10%",
		},
		{
			title: "STATE",
			dataIndex: "state",
			key: "state",
			width: "5%",
		},
		{
			title: "ALERT CLASS",
			dataIndex: "alertType",
			key: "alertType",
			width: "10%",
		},
		{
			title: "DEPARTMENT",
			dataIndex: "department",
			key: "department",
			width: "10%",
		},
		{
			title: "AGEING",
			dataIndex: "ageing",
			key: "ageing",
			width: "5%",
		},
	];

	const mobileColumns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: 90,
		},
		{
			title: "ASSET ID",
			dataIndex: "assetId",
			key: "assetId",
			width: 90,
		},
		{
			title: "ALERT ID",
			dataIndex: "alertId",
			key: "alertId",
			render: (alertId: any) => (
				<Tooltip title={getTooltipContentAlertStatus(alertId)}>
					{alertId}
				</Tooltip>
			),
			width: 100,
		},
		{
			title: "ASSET DESCRIPTION",
			dataIndex: "assetDescription",
			key: "assetdescription",
			width: 100,
		},
		{
			title: "MODEL NAME",
			dataIndex: "modelName",
			key: "modelName",
			width: 100,
		},
		{
			title: "ALERT STATUS",
			dataIndex: "alertStatus",
			key: "alertStatus",
			width: 100,
		},
		{
			title: "MODEL STATUS",
			dataIndex: "modelStatus",
			key: "modelStatus",
			width: 120,
		},
		{
			title: "STATE",
			dataIndex: "state",
			key: "state",
			width: 120,
		},
		{
			title: "ALERT CLASS",
			dataIndex: "alertType",
			key: "alertType",
			width: 120,
		},
		{
			title: "DEPARTMENT",
			dataIndex: "department",
			key: "department",
			width: 120,
		},
		{
			title: "AGEING",
			dataIndex: "ageing",
			key: "ageing",
			width: 80,
		},
	];
	return (
		<>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Table
							columns={columns}
							dataSource={alertStatuslist}
							tableLayout="fixed"
							pagination={{ pageSize: 10, showSizeChanger: false }}
						/>
					);
				} else {
					return (
						<Table
							columns={mobileColumns}
							tableLayout={undefined}
							dataSource={alertStatuslist}
							pagination={{ pageSize: 10, showSizeChanger: false }}
							scroll={{ x: "900px" }}
						/>
					);
				}
			})()}
		</>
	);
};

export default AlertStatusList;
