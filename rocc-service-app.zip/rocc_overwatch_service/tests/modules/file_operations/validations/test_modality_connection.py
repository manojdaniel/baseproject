import unittest
from src.modules.file_operations.validations.modality_connection import (
    validating_modality_connection_rows,
    validate_modality_connection_ip_and_priority,
    adding_extra_columns_to_properties,
    appending_modality_connection_rows,
    group_modality_rows,
    grouped_rows,
    checking_connection_mode_and_priority,
    validated_connection_mode_and_priority,
    add_default_connections,
    validate_grouped_modality_connection,
    get_types_and_priority_list,
    append_connection_mode,
    append_modality_connection_to_room_dict,
    assign_default_modality_connection_data,
    validate_room_identifier,
    append_modality_to_rooms,
    add_default_modality_conn
)
class FileReaderTest(unittest.TestCase):
    def test_validating_modality_connection_rows(self):
        documents = validating_modality_connection_rows({}, {}, [], [])
        self.assertIsNone(documents)
    def test_validate_modality_connection_ip_and_priority(self):
        documents = validate_modality_connection_ip_and_priority({}, {}, [], [])
        self.assertIsNone(documents)
    def test_adding_extra_columns_to_properties(self):
        documents = adding_extra_columns_to_properties({}, {}, [], [])
        self.assertIsNone(documents)
    def test_appending_modality_connection_rows(self):
        documents = appending_modality_connection_rows({}, [])
        self.assertIsNotNone(documents)
    def test_group_modality_rows(self):
        documents = group_modality_rows([], [])
        self.assertIsNotNone(documents)
    def test_grouped_rows(self):
        documents = grouped_rows([],"", [], [])
        self.assertIsNone(documents)
    def test_checking_connection_mode_and_priority(self):
        documents = checking_connection_mode_and_priority([],[], "", [])
        self.assertIsNone(documents)
    def test_validated_connection_mode_and_priority_case1(self):
        documents = validated_connection_mode_and_priority([],{"Connection_mode": "VNC"}, {"Connection_mode": "RDP"}, "", [])
        self.assertIsNone(documents)
    def test_validated_connection_mode_and_priority_case2(self):
        documents = validated_connection_mode_and_priority([],{"Priority": "1"}, {"Priority": "1"}, "", [])
        self.assertIsNone(documents)
    def test_validated_connection_mode_and_priority_case3(self):
        documents = validated_connection_mode_and_priority([],{"Connection_mode": "VNC"}, {"Connection_mode": "VNC"}, "", [])
        self.assertIsNone(documents)
    def test_add_default_connections(self):
        documents = add_default_connections({"Modality_Connection": [{"Connection_mode": "VNC"}]}, [])
        self.assertIsNotNone(documents)
    def test_validate_grouped_modality_connection_case1(self):
        documents = validate_grouped_modality_connection({}, [])
        self.assertIsNotNone(documents)
    def test_validate_grouped_modality_connection_case2(self):
        documents = validate_grouped_modality_connection({"room001": {"Priority": ""}}, [])
        self.assertIsNone(documents)
    def test_get_types_and_priority_list(self):
        documents = get_types_and_priority_list([], [], [])
        self.assertIsNotNone(documents)
    def test_append_connection_mode(self):
        documents = append_connection_mode([], [], [])
        self.assertIsNotNone(documents)
    def test_append_modality_connection_to_room_dict_case1(self):
        documents = append_modality_connection_to_room_dict({}, {}, [])
        self.assertIsNone(documents)
    def test_append_modality_connection_to_room_dict_case2(self):
        documents = append_modality_connection_to_room_dict({"room_001":{"Priority": 1}}, {}, [])
        self.assertIsNone(documents)
    def test_assign_default_modality_connection_data(self):
        documents = assign_default_modality_connection_data({}, {})
        self.assertIsNotNone(documents)
    def test_validate_room_identifier_case1(self):
        documents = validate_room_identifier({}, {}, [], [])
        if documents:
            append_modality_to_rooms({}, {}, [])
        self.assertIsNone(documents)
    def test_add_default_modality_conn_case1(self):
        documents = add_default_modality_conn([], {}, [])
        self.assertIsNotNone(documents)
    def test_add_default_modality_conn_case2(self):
        documents = add_default_modality_conn([], ["data"], [])
        self.assertIsNone(documents)
    def test_append_modality_to_rooms(self):
        documents = append_modality_to_rooms({}, {}, [], [])
        self.assertIsNone(documents)
        