/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import { locations } from "../mocks/mock-data"
import RoomsLayout from "./RoomsLayout"

const mockDispatch = jest.fn()

jest.mock("react-redux", () => ({
  useSelector: () => ({
    activeLocationId: "1",
    sideBar: {},
    locations: ["a"]
  }),
}))

jest.mock("../redux/store/externalAppStates", () => ({
  fetchGlobalActiveLocation: jest.fn(() => {
    return 4
  }),
  fetchGlobalLocations: jest.fn(() => {
    return locations
  }),
  fetchGlobalMetaSite: jest.fn(() => {
    return "Platinum Healthcare Systems"
  }),
  fetchGlobalSideBar: jest.fn(() => {
    return ""
  }),
  fetchGlobalAppVersion: jest.fn(() => {
    return "test-123"
  }),
  dispatchToParentStore: () => mockDispatch
}))
describe("Rooms Layout", () => {
  let wrapper: any
  let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
  afterEach(() => {
    jest.clearAllMocks()
  })
  it("render rooms layout", () => {
    useEffect = jest.spyOn(React, "useEffect")
    const mockUseEffect = () => {
      useEffect.mockImplementationOnce(f => f())
    }
    mockUseEffect()
    wrapper = shallow(<RoomsLayout />)
    expect(wrapper.find("IdnComponent").exists()).toBeTruthy()
    expect(wrapper.find("RoomsComponent").exists()).toBeTruthy()
    wrapper.find("IdnComponent").props().handleIdnSearch({ value: "Seatle" })
    wrapper.find("IdnComponent").props().getActiveLocation({ location: locations[1] })
    expect(useEffect).toHaveBeenCalled()
  })
})
