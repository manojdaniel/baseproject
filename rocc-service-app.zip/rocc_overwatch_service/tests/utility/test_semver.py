"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from random import randint
import unittest
from unittest.mock import Mock, patch

from tests.mocks.random import rand_string
from src.utility.semver import *

from src.constants.constants import UTF_8


class SemverTestCase(unittest.TestCase):
    @patch("src.utility.semver.create_logger.error")
    def test_version_parse_exception(self, mock_error):
        parse_version({})
        parse_version([])
        parse_version(bytearray(rand_string(10), UTF_8))

        mock_error.assert_called()
        mock_error.assert_called()
        mock_error.assert_called()

    @patch("src.utility.semver.create_logger.error")
    def test_version_parse(self, mock_error):
        version_string = f"{randint(0, 10)}.{randint(0, 10)}.{randint(0, 10)}"

        version_parsed = parse_version(version_string)

        mock_error.assert_not_called()
        self.assertEqual(version_parsed, version.parse(version_string))
        self.assertEqual(str(version_parsed), version_string)

    @patch("src.utility.semver.create_logger.error")
    def test_version_parse_legacy_fallback(self, mock_error):
        version_string = rand_string(10)

        version_parsed = parse_version(version_string)

        mock_error.assert_not_called()
        self.assertEqual(version_parsed, version.parse(version_string))
        self.assertEqual(str(version_parsed), version_string)
