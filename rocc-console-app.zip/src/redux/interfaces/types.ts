/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EAppContext, EAppStates, EConnectionMode, EConnectionStatus, EConnectionType, EOperationStatus, ETransactionStatus, IAVCallDetails, ICallStatus, IConsoleSession, ILoggedInTech, INotificationMessage, INotificationModal, IReceiver as IReceiverBase, IRequester, IRoomDetails, IUserInfo, IUserPermissions, IWorkflow, TransactionValue } from "@rocc/rocc-client-services"
import { Dispatch, ReactFragment } from "react"

/* TODO: Use const enum instead of enum */

export interface IStore {
    consoleReducer: IConsoleReducer
    protocolTransferReducer: IProtocolTransferReducer
    externalReducer: IExternalReducer
}

export interface IExternalReducer {
    currentUser: IUserInfo
    permissions: IUserPermissions,
    appState: EAppStates,
    appContext: EAppContext
    notificationMessage: INotificationMessage
    notificationModal: INotificationModal
    rooms: IRoomInfo[]
    featureFlags: any
    applicationConnectionState: EConnectionStatus
    activeTabIndex: number
    displayRightSidePanel: boolean
    displayLeftSidePanel: boolean
    desktopFullScreen: boolean
    callDetails: {
        videoCallStatus: ICallStatus[]
        connectedCallDetails: IAVCallDetails
        onHoldCallDetails: IAVCallDetails[]
    }
    forceCleanUp: boolean
    workflows: IWorkflowInfo[]
}

export type IWorkflowInfo = Pick<IWorkflow, "id" | "type" | "state">

export interface IRoomInfo {
    roomUuid: string
    roomName: string
    address: string
    locationId: number
    phoneNumber: string
    loggedInTech: ILoggedInTech
    additionalAttributes?: any
    cameraAvailable?: boolean
}

export interface IConsoleReducer {
    consoleSessions: IConsoleSession[]
    commandCenterDetails: ICommandCenterDetails
    consoleOperation: IConsoleOperation
    consoleMessages: IConsoleMessage[]
    contextPidMappings: IContextPidMapping[]
    nfccAppPath: string
}

export interface ICommandCenterDetails {
    initialised: ECommandCenterAccessMode
    commandCenterSeat: ICommandCenterSeat
}

export enum ECommandCenterAccessMode {
    INIT = "INIT",
    WITHOUT_HARDWARE = "WITHOUT_HARDWARE",
    WITH_HARDWARE = "WITH_HARDWARE",
}

export interface IMultiCameraListItem {
    cameraStreamName: string
    selected: boolean
    thumbnail?: any
}

export interface ICommandCenterSeat {
    organizationId: number
    seatName: string
    receivers: IReceiver[]
}

export interface IReceiver extends IReceiverBase {
    isSelected: boolean
}

export interface IConsoleOperation {
    operationId: string
    operationStatus: EOperationStatus
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
    transactions: IConsoleTransaction[]
}

export interface IConsoleTransaction {
    transactionId: string
    groupId: string
    transactionStatus: ETransactionStatus
    roomUuid: string
    connectionType: EConnectionType
    connectionMode: EConnectionMode
    connectionStatus: TransactionValue
    receiverName: string
    contextId?: string
    additionalData?: IObject
    groupedTasks?: string[]
}

export interface IObject {
    [key: string]: any
}

export interface IConsoleMessage {
    mesageType: EMessageType
    displayTitle: string
    displayContent: string
    timeout?: number        // In Seconds
}

export interface ICommandCenterLocation {
    seatName: string
    organizationId: number
}

export interface IWizardStep {
    stepNumber: number
    content: ReactFragment
    isPrevEnabled: boolean
    isNextEnabled: boolean
}

export interface IModalDetail {
    state: boolean
    content: string
}

export interface IContextPidMapping {
    contextId: string,
    pid: number
}

export interface IProtocolTransferReducer {
    protocolTransferStatus: boolean
    protocolTransferExitInProgress: boolean
    selectedSource: any
    selectedDestination: any
    completedDestinations: string[]
    currentStep: EProtocolTransferSteps
    initiationRoute: any
}

export interface ILeaveProtocolTransferConfirmProps {
    show: boolean
    postConfirmCallback: () => void
    onDialogClosed: () => void
}

export interface IConfirmModal {
    show: boolean
    onConfirm: (...args: any) => void
    onCancel: (...args: any) => void
}
export interface IReceiverSelectionModal {
    showReceiverModal: boolean
    connectionType: EConnectionType | string
}

export interface IUpdateDoNotShowCheckboxStatus {
    room: IRoomDetails,
    rooms: IRoomDetails[]
    status: boolean
    consoleUrl: string
    accessToken: string
    dispatch: Dispatch<any>
}

export interface IPerformConsoleConnectionOps {
    connectionMode: EConnectionMode
    consoleSessions: IConsoleSession[]
    connectionType: EConnectionType
    roomUuid: string
    receivers: IReceiver[]
    selectedReceiver?: string
    dispatch?: any
    setReceiverSelectionModal?: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    componentName: string
    featureFlags: any
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
}

export interface IMediaRoomApiResponse {
    mediaRoomId: string
    mediaRoomType: string
    callState: string
    participants: string[]
    requester: IRequester
}

export interface IActiveConsoleSession {
    contextId: string
    roomUuid: string
    currentSession: IConsoleSession
    buttonTitle: boolean
}

export enum EMessageType {
    INFO,
    WARN,
    ERROR,
}

export enum ELocationSelectionPage {
    LAUNCH = "launch",
    HARDWARE = "hardware",
    INPUT = "input",
    CONFIRM = "confirm",
    NOMODAL = "nomodal",
}

export enum EACCESS_MODE_SET {
    YES = "YES",
    NO = "NO"
}

export enum EProtocolTransferSteps {
    SelectSourceScanner = 1,
    ConnectToSourceScanner,
    SelectDestinationScanner,
    ConnectToDestinationScanner,
    CompletionStep
}

export enum EGridWidth {
    ONE = 1,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN,
    ELEVEN,
    TWELVE
}

export enum ESessionContentType {
    TAB_HEADER = "TAB_HEADER",
    TAB_CONTENT = "TAB_CONTENT"
}

export interface IActiveConsoleSession {
    contextId: string
    roomUuid: string
    currentSession: IConsoleSession
    buttonTitle: boolean
    technologistName: string
    rightSidePanel: boolean
}

export interface IActiveSessionWithMultiCamera extends IActiveConsoleSession {
    showCameraControls: boolean
    displayCameraState: boolean
    showCameraSettings: boolean
    multiCameraDisabled: boolean
    handleCameraSettingsClick: () => void
    handleCameraSliderClick: () => void
}

export interface IHandleAppUri {
    roomUuid: string
    connectionState: TransactionValue
    consoleSessions: IConsoleSession[]
    accessToken: string
    contextId?: string
}

export interface ICommandCenter {
    seatName: string
    registeredCount: Number
    seatId: Number
    orgId: Number
    commandCenterLocation: string
}
