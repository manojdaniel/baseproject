import { EUserPresence, ERoomStatus } from "@rocc/rocc-client-services"

export interface IMoreOptions {
  roles: IRoles[]
  isDisabled?: boolean
}

interface IRoles {
  roleId: string,
  roleName: string
}

export interface IUserNameComponentProps {
  techUserId: string,
  techUserName: string,
}

export interface IModalityInfo {
  modalityName: string,
  modalityStyles: string
}

export enum EConnectionMode {
  CC = "COMMANDCENTER",
  VNC = "VNC",
  EMERALD = "EMERALD"
}

export enum EConnectionType {
  VIEW = "VIEW",
  INCOGNITO_VIEW = "INCOGNITO_VIEW",
  PROTOCOL_MANAGEMENT = "PROTOCOL_MANAGEMENT",
  FULL_CONTROL = "FULL_CONTROL",
  DEFAULT = "DEFAULT",
}

export interface IRoomCardFlags {
  isStarredFlagEnabled: boolean
  isMultiConsoleFlagEnabled: boolean
  disabledFlags?: {
    isMoreOptionsDisabled: boolean
    isRoomCardFooterDisabled: boolean
  }
  isRoomActiveSession: boolean
  protocolTransferFlagEnabled: boolean
  moreOptionsFlag?: boolean
  phoneCallStatus?: boolean
  videoCallStatus?: boolean
}

export interface IRoomConnectionProps {
  connectionType: string
  connectionMode: string
}

export interface IProtocolTranferProps {
  protocolTransferStatus: boolean,
  completedDestinations: boolean,
}

export interface IRoomCard {
  roomIdentity: IRoomIdentity
  isStarred: boolean
  roomStatus: ERoomStatus
  modalityProps: IModalityInfo
  userNameProps: any
  moreOptionsProps?: IMoreOptions
  flags: IRoomCardFlags
  connectionProps: IRoomConnectionProps
  protocolTransferReducerProps: IProtocolTranferProps
  monitorName: string,
  footerProps: IRoomCardFooter
}

export interface IRoomIdentity {
  id: number
  name: string
  uuid: string
  address: string
}

export interface IRoomsViewBody {
  starredRoomsList: IRoomCard[]
  otherRoomsList: IRoomCard[]
  allRoomsList: IRoomCard[]
}

export interface IRoomCardFooter {
  phoneNumbers: Array<any>,
  roomUuid: string,
  isDisabled: boolean,
  modalityName: string
  roomName: string
  presence: EUserPresence
}


export enum EGridWidth {
  ONE = 1,
  TWO = 2,
  THREE = 3,
  FOUR = 4,
  FIVE = 5,
  SIX = 6,
  SEVEN = 7,
  EIGHT = 8,
  NINE = 9,
  TEN = 10,
  ELEVEN = 11,
  TWELVE = 12,
  THIRTEEN = 13,
  FOURTEEN = 14,
  FIFTEEN = 15,
  SIXTEEN = 16,
}

export enum ESidePanelTabs {
  Contacts = "Contacts",
  MissedCalls = "Missed calls",
  Active = "Active",
}
