/*
 * Created on Fri July 15 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import AudioVideoParticipants from "./AudioVideoParticipants"

import { withHooks } from "jest-react-hooks-shallow"
import { mockCommunication } from "./AudioVideoRoom.test"

jest.mock("react-redux", () => ({
    useSelector: () => ({}),
    connect: (stateToProps: any, dispatchToProps: any) => (connectComponent: any) => ({
        stateToProps,
        dispatchToProps,
        connectComponent,
    }),
    useDispatch: () => void (0),
}))

jest.mock("../../helpers/helpers", () => ({
    getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
        rooms: [{
            identity: {
                uuid: "uuid"
            }
        }]
    }),
    getUserReducerFromGlobalStore: jest.fn().mockReturnValue({
        contacts: []
    })

}))

jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        SIGNALING_REGION: "gll",
        MAX_VIDEO_BITRATE: 1500000,
        MAX_SUBSCRIPTION_BITRATE: 240000,
    })
}))

jest.mock("react-redux", () => ({
    useDispatch: jest.fn().mockReturnValue(jest.fn),
    useSelector: jest.fn().mockReturnValue({
        connectedCallDetails: {
            contextId: "contextId",
            roomName: "roomName",
            roomType: "Group",
            participants: [{
                uuid: "uuid",

            }]
        },
        communicationVendor: { vendorId: 1, vendorName: "TWILIO" },
        videoSource: "videoSource",
        audioSource: "audioSource",
        currentUser: {
            uuid: "uuid",
            clinicalRole: "Expert User"
        },
        audioOutput: "",
        rooms: []
    })
}))

describe("AudioVideoParticipant New Design component", () => {
    let wrapper: any
    let props: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        props = {
            activeRoom: {
                localParticipant: {},
                participants: [{ identity: "uuid" }],
                disconnect: jest.fn(),
                isRecording: false,
                mediaRegion: "",
                name: "",
                sid: "",
                state: ""
            },
            remoteMediaRef: null,
            dominantSpeaker: undefined,
            setCallStarted: jest.fn(),
            setRemoteUserVideoStatus: jest.fn(),
            setDominantSpeaker: jest.fn(),
            updateRemoteAudioTrackStatus: jest.fn(),
            vendorService: mockCommunication()
        }
        wrapper = shallow(<AudioVideoParticipants {...props} />)
    })
    it("should render empty Fragment component", () => {
        expect(wrapper.find("Fragment")).toHaveLength(1)
    })

    it("should render AudioVideoParticipantNewDesign component with all the props", () => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        withHooks(() => {
            expect(wrapper.props("activeRoom")).toBeDefined()
            expect(wrapper.props("activeCall")).toBeDefined()
            expect(wrapper.props("remoteMediaRef")).toBeDefined()
            expect(wrapper.props("dominantSpeaker")).toBeDefined()
            expect(wrapper.props("vendorService")).toBeDefined()
            expect(wrapper.props("updateRemoteAudioTrackStatus")).toBeDefined()
            expect(wrapper.props("remoteUserVideoStatus")).toBeDefined()
            expect(wrapper.props("setRemoteUserVideoStatus")).toBeDefined()
            mockUseEffect()

        })
    })
})
