"""
 Created on Thu Oct 29 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, ORG_CTXT_HEADER, PHILIPS_ROCC_URI
from src.constants.headers import SECURITY_QUES_FILE_PATH

LOG = create_logger("ManageIAMInfraSetupServices")


def create_security_questions(url, token, org_id=None):
    security_questions = []
    existing_questions_object = get_security_questions(
        url=url, token=token, org_id=org_id)
    existing_questions_list = [o["question"]
                               for o in existing_questions_object]
    LOG.info(
        f"{len(existing_questions_list)} Existing questions - {existing_questions_list}")
    with open(SECURITY_QUES_FILE_PATH) as temp_file:
        data = json.load(temp_file)
        security_questions = data["SECURITY_QUESTIONS"]
    final_security_question_list = []
    if len(security_questions) > 0:
        for question in security_questions:
            if question not in existing_questions_list:
                final_security_question_list.append(question)
        headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
        if org_id:
            headers[ORG_CTXT_HEADER] = str({"Org-Id": org_id})
        data = {"questions": final_security_question_list}
        LOG.info(
            f"Following questions will be added: {final_security_question_list}")
        try:
            if len(final_security_question_list) > 0:
                response = requests.post(f"{url}{PHILIPS_ROCC_URI}/manage/SecurityQuestions",
                                         data=json.dumps(data),
                                         headers=headers)
                if response.status_code == 201:
                    LOG.info("SecurityQuestions created successfully")
                    return response.json()
                else:
                    LOG.error(
                        f"Failed to create security questions with exception: {response.json()}")
            else:
                LOG.info("There are no new questions to add.")
        except Exception as ex:
            LOG.exception(
                f"Failed to create security questions with exception: {ex}")
    return False


def create_allowed_org_rocc(url, token, org_id):
    allowed_org_rocc_response = ""
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: token, ORG_CTXT_HEADER: str({"Org-Id": org_id})}
    data = {"identityOrgId": org_id, "instanceId": org_id}
    response = requests.post(f"{url}{PHILIPS_ROCC_URI}/authorize/AllowedOrg",
                             data=json.dumps(data),
                             headers=iam_headers)
    try:
        if response.status_code == 201:
            LOG.info("Allowed Org mapping created Successfully")
            allowed_org_rocc_response = response.json()
        else:
            LOG.error(
                f"Allowed Org mapping creation failed with error: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Allowed Org mapping creation failed with error: {ex}")
        error_reasn = f"Allowed Org mapping creation failed with error: {repr(ex.args)}"
    return allowed_org_rocc_response, error_reasn


def get_security_questions(url, token, org_id=None):
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    if org_id:
        headers[ORG_CTXT_HEADER] = str({"Org-Id": org_id})
    try:
        response = requests.get(f"{url}{PHILIPS_ROCC_URI}/manage/SecurityQuestions",
                                headers=headers)
        if response.status_code == 200:
            LOG.info("SecurityQuestions fetched successfully")
            return response.json()["questions"]
        else:
            LOG.error(
                f"Failed to create security questions with exception: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.exception(
            f"Failed to create security questions with exception: {ex}")
    return []
