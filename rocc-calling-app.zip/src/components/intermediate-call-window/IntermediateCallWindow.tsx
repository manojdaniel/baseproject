/*
 * Created on Mon Sep 13 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { ReactFragment } from "react"
import { CallInfo } from "@rocc/rocc-calling-components"
import styles from "./IntermediateCallWindow.scss"
import cx from "classnames"

interface IIntermediateCallWindow {
    displayName: string
    metaData: ReactFragment | string
    description: string
    callMessage: string
    callWindowFullscreen: boolean
    subMessage?: ReactFragment | string
    customStyle?: any
    additionalComponent?: () => JSX.Element
}

const IntermediateCallWindow = (props: IIntermediateCallWindow) => {

    const {
        displayName, metaData, description, callMessage, callWindowFullscreen, subMessage,
        customStyle, additionalComponent
    } = props

    return <div className={cx(styles.callWindow, customStyle)} id={"intermediateCallWindow"}>
        <CallInfo
            avatarSize={"massive"}
            displayName={displayName}
            metaData={metaData}
            subMessage={subMessage}
            description={description}
            callStatus={callMessage}
            fullScreen={callWindowFullscreen}
        />
        {additionalComponent && additionalComponent()}
    </div>
}

export default IntermediateCallWindow
