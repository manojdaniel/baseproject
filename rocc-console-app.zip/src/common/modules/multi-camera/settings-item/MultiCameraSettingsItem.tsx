/*
 * Created on Thu Mar 18 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Checkbox } from "semantic-ui-react"
import React, { MutableRefObject, useEffect, useRef } from "react"
import styles from "./MultiCameraSettingsItem.scss"
import cx from "classnames"
import { IMultiCameraListItem } from "../../../../redux/interfaces/types"

interface IMultiCameraSettingsItem {
    cameraStreamItem: IMultiCameraListItem
    selectCamera: (name: string, state: boolean) => void
}

const MultiCameraSettingsItem = (props: IMultiCameraSettingsItem) => {

    const { cameraStreamItem, selectCamera } = props
    const thumbnailCanvasRef: MutableRefObject<any> = useRef()

    useEffect(() => {
        if (cameraStreamItem.thumbnail && thumbnailCanvasRef.current) {
            thumbnailCanvasRef.current.src = cameraStreamItem.thumbnail
        }
    }, [cameraStreamItem])

    const displayStyle = (state: boolean) => state ? "" : styles.hideItem

    return <div id={"multiCameraSettingsItem"} className={styles.multiCameraSettingsItem} onClick={() => selectCamera(cameraStreamItem.cameraStreamName, !cameraStreamItem.selected)}>
            <Checkbox checked={cameraStreamItem.selected} label={cameraStreamItem.cameraStreamName} disabled />
            <img className={cx(styles.thumbnail, displayStyle(cameraStreamItem.thumbnail))} id="settingsThumbnail" ref={thumbnailCanvasRef} />
            <span className={cx(styles.thumbnail, styles.noThumbnail, displayStyle(!cameraStreamItem.thumbnail))} />
        </div>
}

export default MultiCameraSettingsItem
