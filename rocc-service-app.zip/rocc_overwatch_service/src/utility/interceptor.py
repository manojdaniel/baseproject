"""
 Created on Fri Sep 18 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import re
from flask import request, jsonify

from src.loggers.log import create_logger
from src.constants.constants import AUTHORIZATION, ROCC_PROXY_URL
from src.wrappers.platform_services.iam_service.authorization_services import validate_token


LOG = create_logger("Interceptor")


def interceptor():
    if request.method == "OPTIONS":
        return None
    if check_protected_route(request.url):
        return evaluate()
    return None


def check_protected_route(request_url):
    protected_routes = [
        "\/philips\/rocc-overwatch\/Customer",
        "\/philips\/rocc-overwatch\/CommandCenter",
        "\/philips\/rocc-overwatch\/Site",
        "\/philips\/rocc-overwatch\/Scanner",
        "\/philips\/rocc-overwatch\/User",
        "\/philips\/rocc-overwatch\/File",
        "\/philips\/rocc-overwatch\/Configs",
        "\/philips\/rocc-overwatch\/Eula",
        "\/philips\/rocc-overwatch\/EmailTemplate",
        "\/philips\/rocc-overwatch\/OrgRole",
        "\/philips\/rocc-overwatch\/FseUser",
        "\/philips\/rocc-overwatch\/MfaPolicy",
        "\/philips\/rocc-overwatch\/ReInviteFseUser",
        "\/philips\/rocc-overwatch\/ReactivateFseUser",
        "\/philips\/rocc-overwatch\/ActivateFseUser"
    ]
    for route in protected_routes:
        if re.search(route, request_url):
            return True
    return False


def evaluate():
    try:
        token = request.headers[AUTHORIZATION]
        """ TODO: Need to enable evaluate token call """
        return validate_token(token=token, url=os.environ[ROCC_PROXY_URL])
    except KeyError as ex:
        LOG.error(f"Token is neccessary to process this request: {ex}")
        return jsonify({"error": "Token is neccessary to process this request"}), 401
    except Exception as ex:
        LOG.error(f"Following error occured while evaluating token: {ex}")
    return None
