import React, { useRef, useEffect, useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import "./ModelPerformance.scss";
import {
	getPlotAssetDropDown,
	getAssetDropdownList,
	getModelPerformanceAssetDropdownChange,
} from "../../../redux/reducers/CommonReducer";
import { useDispatch, useSelector } from "react-redux";
import Dropdown from "components/Dropdown";
import { encryptRSAData } from "../../../utility/rsa";

const ModelPerformance = () => {
	let navigate = useNavigate();
	let dispatch = useDispatch();
	const location = useLocation();

	const [selectedAsset, setSelectedAsset] = useState<any>();
	const [localDropdownAssetList, setLocalDropdownAssetList] = useState<any>([]);

	const {
		globalSelecetedPlant,
		assetDropdownList,
		modelPerformanceAssetDropdownChangedValue,
	} = useSelector((state: any) => ({
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		assetDropdownList: state.Common.assetDropdownList,
		modelPerformanceAssetDropdownChangedValue:
			state.Common.modelPerformanceAssetDropdownChangedValue,
	}));

	useEffect(() => {
		if (Object.keys(globalSelecetedPlant).length > 0) {
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
		}
	}, []);

	useEffect(() => {
		if (assetDropdownList.length > 0) {
			let plantIdArray = [
				{ value: `${globalSelecetedPlant.value}`, label: "All" },
			];
			let mergedArray = [...plantIdArray, ...assetDropdownList];
			setSelectedAsset(plantIdArray);
			setLocalDropdownAssetList(mergedArray);
		}
	}, [assetDropdownList]);

	useEffect(() => {
		// Loading with asset Id
		if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
			setSelectedAsset(modelPerformanceAssetDropdownChangedValue);
		}
	}, [modelPerformanceAssetDropdownChangedValue]);

	// useEffect(() => {
	//     if (assetDropdownList.length > 0) {
	//         setSelectedAsset(assetDropdownList[0])
	//         dispatch(getModelPerformanceAssetDropdownChange(assetDropdownList[0]));
	//     }
	// }, [assetDropdownList]);

	// useEffect(() => {
	//     let data = plotAssetDropDown.map(function (item: any) {
	//         return { value: item.assetId, label: item.assetId };
	//     });
	//     setAssetData(data);
	// }, [plotAssetDropDown]);

	useEffect(() => {
		//handleMenuClick(1)
	}, []);

	const DATA = [
		{ id: "PerformanceDashboard", value: "PERFORMANCE DASHBOARD" },
		{ id: "PlantMonthWise", value: "PLANT MONTHWISE" },
	];

	const [elements, setElements] = useState(DATA);
	const [selectedID, setSelectedID] = useState(); // you could set a default id as well

	const handleMenuClick = (id: any) => {
		setSelectedID(id);
		switch (id) {
			case "PerformanceDashboard":
				navigate("/plant/modelPerformance/performanceDashboard");
				break;
			case "PlantMonthWise":
				navigate("/plant/modelPerformance/plantMonthWise");
				break;
			default:
				break;
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	const handleAssetDropDown = (e: any) => {
		setSelectedAsset(e);
		dispatch(getModelPerformanceAssetDropdownChange(e));
	};

	let updatedCurrentPath;

	try {
		let currentPathname =
			location.pathname.split("/")[3] !== undefined
				? location.pathname.split("/")[3]
				: "";
		updatedCurrentPath =
			currentPathname.charAt(0).toUpperCase() + currentPathname.slice(1);
	} catch (error) {}

	useEffect(() => {
		if (location.pathname.split("/")[3] === undefined) {
			if (location.pathname.split("/")[2] === "modelPerformance") {
				navigate("/plant/modelPerformance/performanceDashboard");
			}
		}
	}, [location.pathname]);

	const getSelectedclassName = (id: any) =>
		updatedCurrentPath === id ? "active" : "notselected";

	const TopContainer = () => {
		return (
			<>
				{elements.map((el) => (
					<a
						key={el.id}
						className={`top-container-conten ${getSelectedclassName(el.id)}`}
						// className={updatedCurrentPath === el.id ? "active" : ""}
						onClick={() => handleMenuClick(el.id)}
					>
						{el.value}
					</a>
				))}
			</>
		);
	};

	return (
		<div>
			<div id="model-menu">
				<div className="model-menu-left">
					<TopContainer />
				</div>
				<div className="model-menu-right">
					<div className="model-option">
						<label className="cus-label">Asset ID</label>
						<Dropdown
							name={"Asset"}
							// options={[{ "value": 32, "label": "Cycle Gas Flow 15-40-FT-4129A", 'color': '#E35205' }, { "value": 34, "label": "Cycle1234 Gas Flow 15-40-FT-4129A", 'color': '#E35205' }]}
							handleChange={handleAssetDropDown}
							options={localDropdownAssetList}
							value={selectedAsset}
						/>
					</div>
				</div>
			</div>
			<Outlet />
		</div>
	);
};
export default ModelPerformance;
