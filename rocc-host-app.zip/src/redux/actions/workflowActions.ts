import { ADD_WORKFLOW_EVENT, ERoccWorkflow, IWorkflow, IWorkflowConfig, IWorkflowOptions, REGISTER_WORKFLOW, WorkflowEvent, EPresignedStatus, IPresignedWorkflow } from "@rocc/rocc-client-services"
import { Dispatch } from "redux"
import { ADD_PRESIGNED_WORKFLOW, REMOVE_WORKFLOW_EVENT, SET_WORKFLOWS, SET_WORKFLOW_STATE, UPDATE_PRESIGNED_WORKFLOW, UPDATE_PRESIGNED_WORKFLOW_STATUS, UPDATE_WORKFLOW_SERVICE } from "./types"

export const setWorkflows = (workflows: IWorkflow[]) => (dispatch: Dispatch) => {
    dispatch({ type: SET_WORKFLOWS, payload: { workflows } })
}

export const setWorkflowState = (id: string, workflowState: IWorkflow["state"]) => (dispatch: Dispatch) => {
    dispatch({ type: SET_WORKFLOW_STATE, payload: { id, workflowState } })
}

export const registerRawWorkflow = (workflowConfig: IWorkflowConfig, workflowOptions?: IWorkflowOptions) => (dispatch: Dispatch) => {
    dispatch({ type: REGISTER_WORKFLOW, payload: { workflowConfig, workflowOptions } })
}

export const registerWorkflow = (
    type: ERoccWorkflow,
    {
        context,
        states,
        actions,
        guards,
        delays,
    }: {
        context?: IWorkflowConfig["context"],
        states?: IWorkflowConfig["states"],
        actions?: IWorkflowOptions["actions"],
        guards?: IWorkflowOptions["guards"],
        delays?: IWorkflowOptions["delays"],
    } = {}
) => (dispatch: Dispatch) => {
    dispatch({ type: REGISTER_WORKFLOW, payload: { type, context, states, actions, guards, delays } })
}

export const setServiceInstance = (id: string, service: IWorkflow["service"]) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_WORKFLOW_SERVICE, payload: { id, service } })
}

export const sendRawWorkflowEvent = (id: string, event: WorkflowEvent) => (dispatch: Dispatch) => {
    dispatch({ type: ADD_WORKFLOW_EVENT, payload: { id, event } })
}

export const sendWorkflowEvent = (id: string, eventType: WorkflowEvent["type"], payload?: Omit<WorkflowEvent, "type">) => (dispatch: Dispatch) => {
    dispatch({ type: ADD_WORKFLOW_EVENT, payload: { id, event: { type: eventType, ...payload } } })
}

export const removeWorkflowEvent = (id: string, event: WorkflowEvent) => (dispatch: Dispatch) => {
    dispatch({ type: REMOVE_WORKFLOW_EVENT, payload: { id, event } })
}

// TODO: Implement batch event queueing
// export const pushBatchEvents = (type: ERoccWorkflow, events: EventObject[]) => (dispatch: Dispatch) => {
//     dispatch({ type: ADD_WORKFLOW_EVENTS_BATCH, payload: { id, events } })
// }

export const addPresignedWorkflow = (presignedWorkflow: IPresignedWorkflow) => (dispatch: Dispatch) => {
    dispatch({ type: ADD_PRESIGNED_WORKFLOW, payload: { presignedWorkflow } })
}

export const updatePresignedWorkflow = (presignedId: string, presignedWorkflow: IPresignedWorkflow) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_PRESIGNED_WORKFLOW, payload: { presignedId, presignedWorkflow } })
}

export const updatePresignedWorkflowStatus = (presignedId: string, presignedStatus: EPresignedStatus) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_PRESIGNED_WORKFLOW_STATUS, payload: { presignedId, presignedStatus } })
}
