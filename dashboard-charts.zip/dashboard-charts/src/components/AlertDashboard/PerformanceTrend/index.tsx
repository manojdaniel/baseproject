// @ts-nocheck
import React, { useRef, useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

interface Props {
	data: any[]
}

const PerformanceTrend = ({ data }: Props) => {
	useLayoutEffect(() => {
		if (data.length > 0) {

			let Chartdata = []
			data.forEach((device, index) => {
				Chartdata[index] = { ...device }
			})
			/* Chart code */
			// Create root element
			// https://www.amcharts.com/docs/v5/getting-started/#Root_element
			let root = am5.Root.new("chartdiv3");

			/* remove amchart logo */

			root._logo.dispose();

			// Set themes
			// https://www.amcharts.com/docs/v5/concepts/themes/
			root.setThemes([am5themes_Animated.new(root)]);

			// Create chart
			// https://www.amcharts.com/docs/v5/charts/xy-chart/
			let chart;
			if(window.innerWidth > 2000){
			chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					focusable: true,
					panX: true,
					panY: true,
					wheelX: "panX",
					wheelY: "zoomX",
					pinchZoomX: true,
					x: 270,
					// width: 500,
				})
			);
			}else{
			chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					focusable: true,
					panX: true,
					panY: true,
					wheelX: "panX",
					wheelY: "zoomX",
					pinchZoomX: true,
					x: 280,
				})
			);
			}

			chart.get("colors").set("colors", [
				am5.color(0xE35205),//red
				am5.color(0x3BB44A), //green
				am5.color(0x4E79A7),//sky blue
				am5.color(0x929292),//Gray

			]);

			// let easing = am5.ease.linear;
			// chart.get("colors").set("step", 3);

			// Create axes
			// https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
			let xAxis = chart.xAxes.push(
				am5xy.DateAxis.new(root, {
					maxDeviation: 0.1,
					groupData: false,
					baseInterval: {
						timeUnit: "day",
						count: 1
					},
					renderer: am5xy.AxisRendererX.new(root, {}),
					tooltip: am5.Tooltip.new(root, {
						dy: -10,
					})
				})
			);

			xAxis.get("renderer").labels.template.set("forceHidden", false);
			let xRenderer = xAxis.get("renderer");
            xRenderer.labels.template.setAll({
                fontSize: "0.8rem"
              });
			function createAxisAndSeries(startValue, opposite, field, name) {
				let yRenderer = am5xy.AxisRendererY.new(root, {
					opposite: opposite
				});
				let yAxis = chart.yAxes.push(
					am5xy.ValueAxis.new(root, {
						maxDeviation: 1,
						renderer: yRenderer
					})
				);
				yAxis.get("renderer").labels.template.setAll({fontSize: "0.8rem"  });
				if (chart.yAxes.indexOf(yAxis) > 0) {
					yAxis.set("syncWithAxis", chart.yAxes.getIndex(0));
				}

				// Add series
				// https://www.amcharts.com/docs/v5/charts/xy-chart/series/
				let series = chart.series.push(
					am5xy.LineSeries.new(root, {
						name: name,
						xAxis: xAxis,
						yAxis: yAxis,
						valueYField: field,
						valueXField: "datee",
						tooltip: am5.Tooltip.new(root, {
							pointerOrientation: "horizontal",
							labelText: "{valueY}",
							fontSize:"0.8rem",
						})
					})
				);
					var tooltip= am5.Tooltip.new(root,{
						fontSize: "2.8rem"
					})
				//series.fills.template.setAll({ fillOpacity: 0.2, visible: true });
				series.strokes.template.setAll({ strokeWidth: 1 });

				yRenderer.grid.template.set("strokeOpacity", 0.05);
				yRenderer.labels.template.set("fill", series.get("fill"));
				yRenderer.setAll({
					stroke: series.get("fill"),
					strokeOpacity: 1,
					opacity: 1
				});

				// Set up data processor to parse string dates
				// https://www.amcharts.com/docs/v5/concepts/data/#Pre_processing_data
				series.data.processor = am5.DataProcessor.new(root, {
					dateFormat: "yyyy-MM-dd",
					dateFields: ["datee"]
				});

				series.bullets.push(function (root) {
					return am5.Bullet.new(root, {
						sprite: am5.Circle.new(root, {
							radius: 4,
							fill: series.get("fill")
						})
					});
				});

				series.data.setAll(Chartdata);
			}

			// Add cursor
			// https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
			let cursor = chart.set(
				"cursor",
				am5xy.XYCursor.new(root, {
					xAxis: xAxis,
					behavior: "none"
				})
			);
			cursor.lineY.set("visible", false);


			createAxisAndSeries("100", false, "utilization", "Utilization");
			createAxisAndSeries("100", false, "overdueAlerts", "Overdue Investigation");
			createAxisAndSeries("100", false, "averageResponseTime", "Average Response Time");
			createAxisAndSeries("100", false, "newAlerts", "New Alerts");

			// legends need to check
		if(window.innerWidth > 2000){
			var legend = chart.leftAxesContainer.children.push(am5.Legend.new(root, {
				background: am5.Rectangle.new(root, {
				}),
				height: am5.percent(80),
				centerX: am5.percent(8),
				x: -245,
				y: 40,
				position: "absolute",
				fontSize:"0.8rem",
				centerY: am5.percent(20),
				useDefaultMarker: true
			}));
		}else{
			var legend = chart.leftAxesContainer.children.push(am5.Legend.new(root, {
				background: am5.Rectangle.new(root, {
				}),
				height: am5.percent(80),
				centerX: am5.percent(8),
				x: -265,
				y: 40,
				position: "absolute",
				fontSize:"0.8rem",
				centerY: am5.percent(20),
				useDefaultMarker: true
			}));
		}
			legend.markerRectangles.template.setAll({
				width: 25,
				height: 10,
				cornerRadiusTL: 8,
				cornerRadiusTR: 7,
				cornerRadiusBL: 7,
				cornerRadiusBR: 7,
				fontSize:"0.9rem",
				y: 4,
				x: -12,
			});
			if(window.innerWidth > 3000){
			legend.labels.template.setAll({
				fontSize:"0.6rem",
				marginLeft: 10,

			});
			}else{
			legend.labels.template.setAll({
				fontSize:"0.9rem",
				marginLeft: 10,

			});
			}
			legend.valueLabels.template.setAll({
				fontSize: 0,
				fontWeight: "0",

			});
			//  When legend item container is unhovered, make all series as they are
			legend.itemContainers.template.events.on("pointerout", function (e) {
				var itemContainer = e.target;
				var series = itemContainer.dataItem.dataContext;
			})
			legend.itemContainers.template.set("width", am5.percent(40));
			// legend.itemContainers.template.set("height", am5.percent(200));


			legend.data.setAll(chart.series.values.slice(0, 4));

			// Make stuff animate on load
			// https://www.amcharts.com/docs/v5/concepts/animations/
			chart.appear(1000, 100);

			// Generates random data, quite different range


			return () => {
				root.dispose();
			};
		}
	}, [data]);
	return (
		<div id="chartdiv3" title="Scroll Mouse to Zoom In/Out" style={{ width: "100%", height: "250px", cursor:"all-scroll" }}></div>
	);
};

export default PerformanceTrend;