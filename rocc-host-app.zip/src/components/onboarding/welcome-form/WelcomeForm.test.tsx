/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import { Button } from "semantic-ui-react"
import WelcomeForm from "./WelcomeForm"

describe("WelcomeForm component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<WelcomeForm username={"User1"} getStarted={jest.fn()} />)
    })
    it("should render header", () => {
        const welcomeHeader = wrapper.find("Header")
        expect(welcomeHeader).toHaveLength(1)
    })

    it("should render grid", () => {
        expect(wrapper.find("Grid")).toHaveLength(1)
    })

    it("should render video", () => {
        expect(wrapper.find("video")).toHaveLength(1)
    })

    it("should render a modal window with 1 buttons", () => {
        expect(wrapper.find(Button).children()).toHaveLength(1)
    })

})
