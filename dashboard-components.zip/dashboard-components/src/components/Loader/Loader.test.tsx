import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import App from "./index";

describe("App", () => {
	it("renders the Spin component", () => {
		const { container } = render(<App />);
		const spinElement = container.querySelector(".ant-spin");
		expect(spinElement).toBeInTheDocument();
	});
});
