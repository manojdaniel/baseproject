"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import sys
import time
import traceback

import jwt
import requests
from requests.auth import HTTPBasicAuth

from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger

from src.constants.constants import CONTENT_TYPE, APPLICATION_FORM_URLENCODED, API_VERSION

LOG = create_logger("ManageTokenServices")


def create_service_token_from_vault(iam_url, issuer, private_key):
    private_key_pem = f"-----BEGIN RSA PRIVATE KEY-----\n {private_key} \n-----END RSA PRIVATE KEY-----"

    jwt_data = {"aud": [f"{iam_url}/oauth2/access_token"], "iss": issuer, "sub": issuer, "exp": int(round(time.time())) + 1800}

    jwt_token = jwt.encode(jwt_data, private_key_pem, algorithm="RS256")

    iam_headers = {CONTENT_TYPE: APPLICATION_FORM_URLENCODED, API_VERSION: "2"}
    body = b"grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + jwt_token
    try:
        response = requests.post(f"{iam_url}/authorize/oauth2/token", data=body, headers=iam_headers)
        if response.status_code == 200:
            return response.json()["access_token"]
        else:
            LOG.error(f"Error while creating service token {response.json()}")
            response.raise_for_status()
    except requests.exceptions.RequestException as ex:
        LOG.error(ex)
        LOG.error(traceback.print_exc())
        raise RoccException(ex.response.status_code, str(sys.exc_info()[1])) from ex


def create_device_provision_token(iam_url, vault_response):
    LOG.info("Creating Device Provision access Token")

    try:
        response = requests.post(f"{iam_url}/authorize/oauth2/token",
                                 data="grant_type=client_credentials",
                                 headers={CONTENT_TYPE: APPLICATION_FORM_URLENCODED, API_VERSION: "2"},
                                 auth=HTTPBasicAuth(vault_response["data"]["deviceClientId"], vault_response["data"]["deviceClientSecret"]))

        if response.status_code == 200:
            return response.json()["access_token"]

        LOG.error(f"Error While creating AccessToken: {json.dumps(response.json())}")
        return response.raise_for_status()
    except Exception as ex:
        LOG.error(ex)


def create_access_token_from_hsdp(iam_url, username, password, client_id, client_secret):
    LOG.info("Creating access Token")
    iam_login_data = f"grant_type=password&username={username}&password={password}"
    iam_headers = {CONTENT_TYPE: APPLICATION_FORM_URLENCODED, API_VERSION: "2"}
    try:
        response = requests.post(f"{iam_url}/authorize/oauth2/token",
                                 data=iam_login_data,
                                 headers=iam_headers,
                                 auth=HTTPBasicAuth(client_id, client_secret))
        if response.status_code == 200:
            return response.json()["access_token"]
        else:
            LOG.error(f"Error While creating AccessToken {json.dumps(response.json())}")
            return response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While creating AccessToken {ex}")
    return False
