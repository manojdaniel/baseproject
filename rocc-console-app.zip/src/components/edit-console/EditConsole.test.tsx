/*
 * Created on Thu Dec 9 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EConnectionType, EOperationStatus, EPosition } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import EditConsole from "./EditConsole"
import * as consoleOperations from "../../common/helpers/consoleUtility"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        featureFlags: { "rocc-command-center-edit": true, "rocc-emerald-edit": true },
        permissions : {CONSOLE_EDIT : true},
        consoleConnectionInProgress: {
            inProgress: false,
            roomUuid: "id",
            connectionType: EConnectionType.VIEW
        },
        consoleSessions: [{ roomUuid: "id", connectionType: EConnectionType.VIEW }],
        consoleOperation: {
            operationId: "", operationStatus: EOperationStatus.IDLE, transactions: []
        },
        currentUser: { kvmUsername: "admin" },
        receivers: [{ id: "id" }],
        workflows: [],
    }),
    useDispatch: () => void (0),
}))
jest.mock("../../common/helpers/helpers", () => ({
    ...jest.requireActual("../../common/helpers/helpers"),
    checkIfViewAndEditConsoleEnabled: jest.fn().mockReturnValueOnce(true),
    fetchAllEditConsoleType: jest.fn().mockReturnValueOnce(["FULL_CONTROL", "FULL_CONTROL_USB", "PROTOCOL_MANAGEMENT"]),
    checkIfEmeraldEditEnabled: jest.fn().mockReturnValueOnce(true),
}))

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        consoleReducer: { commandCenterDetails: { commandCenterSeat: { receivers: [{ id: "id" }] } } },
        externalReducer: { featureFlags: {} }
    })
}))

describe("EditConsole Component", () => {
    let useEffect1: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    const useEffectMockMethod = () => {
        useEffect1 = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect1.mockImplementationOnce(f => f())
        }
        mockUseEffect()
    }
    let wrapper: any
    const props = {
        roomUuid: "id",
        showTitle: true,
        iconPosition: EPosition.HORIZONTAL,
        setReceiverSelectionModal: jest.fn()
    }

    it("should render Edit console component", () => {
        expect(true).toBeDefined()
    })
})
