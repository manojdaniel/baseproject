import React, { useRef, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
// import UserRoleMappingTable from "table/UserRoleMappingTable";
import UserRoleMappingTable from "./UserRoleMappingTable";
import EmployeeTable from "table/EmployeeTable";
import Dropdown from "components/Dropdown";
import DropdownMultiselect from "components/DropdownMultiselect";
import {
	getRoleMappingRoleDropdownList,
	getRoleMappingPlantDropdownList,
	getRoleMappingAffiliateDropdownList,
	addRoleMapping,
	getRoleMappingWorklist,
	getEmployeeList,
	addRoleMappingStatus,
} from "../../redux/reducers/CommonReducer";
import "./Admin.scss";
import Loader from "components/Loader";
import PushNotification from "components/PushNotification";
import { encryptRSAData } from "../../utility/rsa";

const UserRoleMapping = () => {
	let dispatch = useDispatch();
	const [loading, setLoading] = useState<any>(false);
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);
	const {
		roleAddMappingStatus,
		roleMappingRoleDropdownList,
		roleMappingAffiliateDropdownList,
		loadingAffiliateListDropdown,
		roleMappingPlantDropdownList,
		loadingPlantListDropdown,
		roleMappingStatus,
		roleMappingWorklist,
		loadingRoleMappingWorklist,
		employeeList,
	} = useSelector((state: any) => ({
		roleAddMappingStatus: state.Common.roleAddMappingStatus,
		roleMappingRoleDropdownList: state.Common.roleListDropdown,
		roleMappingAffiliateDropdownList: state.Common.affiliateListDropdown,
		loadingAffiliateListDropdown: state.Common.loadingAffiliateListDropdown,
		roleMappingPlantDropdownList: state.Common.plantListDropdown,
		loadingPlantListDropdown: state.Common.loadingPlantListDropdown,
		roleMappingStatus: state.Common.roleMappingStatus,
		roleMappingWorklist: state.Common.roleMappingWorklist,
		loadingRoleMappingWorklist: state.Common.loadingRoleMappingWorklist,
		employeeList: state.Common.employeeList,
	}));

	const [mappingData, setMappingData] = useState<any>({
		userId: "",
		userName: "",
		roleMasterId: 0,
		email: "",
		lastLoginTime: "2023-05-05T06:50:25.738Z",
		active: true,
		mappingType: "",
		loginUserId: "0",
		plantIds: "",
		affiateIds: "",
		contactNo: "",
		location: "",
		department: "",
	});

	const [showPopup, setShowPopup] = useState<any>(false);
	const [selectedRole, setSelectedRole] = useState<any>("");
	const [selectedAffiliate, setSelectedAffiliate] = useState<any>([]);
	const [selectedPlant, setSelectedPlant] = useState<any>([]);
	const [searchText, setSearchText] = useState<any>("");

	const [checkPlant, setCheckPlant] = useState<any>(false);
	const [mapping, setMapping] = useState<any>(true);
	const userRoleMappingData = [
		{
			name: "Ali",
			affiliate: "SAFCO",
			plant: "BRN",
		},
		{
			name: "Sadiq",
			affiliate: "SAFCO",
			plant: "BRN",
		},
		{
			name: "Vijay",
			affiliate: "SAFCO",
			plant: "BRN",
		},
		{
			name: "Amit",
			affiliate: "SAFCO",
			plant: "BRN",
		},
		{
			name: "Manoj",
			affiliate: "SAFCO",
			plant: "BRN",
		},
	];
	const roleDropdownList = [
		{
			roleId: 1,
			roleName: "Super Admin",
		},
		{
			roleId: 2,
			roleName: "Plant Admin",
		},
		{
			roleId: 3,
			roleName: "Plant User",
		},
	];
	const employeeData = [
		{
			key: "1",
			employeeID: "123456",
			employeeName: "Ali",
			employeeEmail: "ali@sabic.com",
			department: "Technology",
		},
		{
			key: "2",
			employeeID: "123457",
			employeeName: "Saim",
			employeeEmail: "saim@sabic.com",
			department: "Technology",
		},
		{
			key: "3",
			employeeID: "123458",
			employeeName: "Abhay",
			employeeEmail: "abhay@sabic.com",
			department: "Technology",
		},
		{
			key: "4",
			employeeID: "123459",
			employeeName: "Raza",
			employeeEmail: "raza@sabic.com",
			department: "Technology",
		},
	];
	useEffect(() => {
		dispatch(getRoleMappingRoleDropdownList(""));
		dispatch(getRoleMappingAffiliateDropdownList(""));
		dispatch(getRoleMappingWorklist(""));
	}, [roleMappingStatus]);

	// useEffect(() => {
	//   dispatch(getRoleMappingPlantDropdownList(`${selectedAffiliate}`))
	// }, [selectedAffiliate])

	useEffect(() => {
		if (roleAddMappingStatus.length > 0) {
			if (!roleAddMappingStatus.hasOwnProperty("Succeeded")) {
				if (roleAddMappingStatus[0].retVal === 1) {
					PushNotification("success", roleAddMappingStatus[0].retMsg);
				} else {
					PushNotification("error", roleAddMappingStatus[0].retMsg);
				}
			} else {
				PushNotification("error", roleAddMappingStatus.Message);
			}
			const emptyObj = [];
			dispatch(addRoleMappingStatus(emptyObj));
		} else {
			if (roleAddMappingStatus.hasOwnProperty("Succeeded")) {
				PushNotification("error", roleAddMappingStatus.Message);
			}
		}
	}, [roleAddMappingStatus]);

	const assetDropdownTransformer = (data: any) => {
		let result: any[] = [];
		result = data.map(function (item: any) {
			return { value: item.roleId, label: item.roleName };
		});

		return result;
	};
	const handleRoleDropDown = (e: any) => {
		setMappingData((data) => ({ ...data, roleMasterId: e.value }));
		setSelectedRole(e);
		if (e.value === 1) {
			setMapping(true);
		} else {
			setMapping(false);
		}
		setMappingData((data) => ({
			...data,
			mappingType: "",
			plantIds: "",
			affiateIds: "",
		}));
		setSelectedAffiliate([]);
		setSelectedPlant([]);
		setCheckPlant(false);
	};

	const handlePlantRadio = (e: any) => {
		const target = e.target;
		if (target.checked && target.value == "2") {
			setCheckPlant(true);
			setMappingData((data) => ({ ...data, mappingType: "plant" }));
		} else {
			setCheckPlant(false);
			setMappingData((data) => ({
				...data,
				plantIds: "",
				mappingType: "affiliate",
			}));
		}
	};
	const handleSearch = () => {
		dispatch(getEmployeeList(encryptRSAData(`search=${searchText}`)));
	};
	const onInputchange = (event) => {
		setSearchText(event.target.value);
	};
	const handleAffiliateDropDown = (e: any) => {
		let value = e.map((item: any, index: any) => item.value);
		let affiliateIds = value.toString();
		let affId = value[value.length - 1];
		dispatch(
			getRoleMappingPlantDropdownList(
				encryptRSAData(`affiliateId=${affiliateIds}`)
			)
		);
		setMappingData((data) => ({ ...data, affiateIds: affiliateIds }));
		let value2 = e.map((item: any, index: any) => ({
			...item,
			item: item.value,
		}));
		setSelectedAffiliate(value2);
	};
	const handlePlantDropDown = (e: any) => {
		let value = e.map((item: any, index: any) => item.value);
		let plantIds = value.toString();
		setMappingData((data) => ({ ...data, plantIds: plantIds }));
		let value2 = e.map((item: any, index: any) => ({
			...item,
			item: item.value,
		}));
		setSelectedPlant(value2);
	};
	const handleUpdate = (
		employeeID,
		employeeName,
		employeeEmail,
		contactNo,
		location,
		department
	) => {
		setMappingData((data) => ({
			...data,
			userId: employeeID,
			userName: employeeName,
			email: employeeEmail,
			contactNo: contactNo,
			location: location,
			department: department,
		}));
		setMappingData((data) => ({
			...data,
			mappingType: "",
			plantIds: "",
			affiateIds: "",
			roleMasterId: "",
		}));

		setSelectedRole("");

		setSelectedAffiliate([]);

		setSelectedPlant([]);

		setMapping(true);

		setCheckPlant(false);
		setShowPopup(false);
	};

	const dataValidation = () =>{
        if(mappingData.userId === ""){
            PushNotification("error", "Select the user");
            return false;
        }
        console.log("roleid",mappingData.roleMasterId)
        if(mappingData.roleMasterId === ""){
            PushNotification("error", "Select the Role");
            return false;
        }
        if(mappingData.roleMasterId === 2 || mappingData.roleMasterId === 3){
            if(mappingData.mappingType === ""){
                PushNotification("error", "Select the Mapping Type");
                return false;
            }
            else if(mappingData.mappingType === "affiliate" && mappingData.affiateIds === ""){
                PushNotification("error", "Select atleast One Affiliate");
                return false;
            }
            else if(mappingData.mappingType === "plant" && (mappingData.affiateIds === "" || mappingData.plantIds=== "")){
                PushNotification("error", "Select atleast One Affiliate and One Plant");
                return false;
            }
            else{
                return true;
            }
        }
        else{
            return true;
        }
    }
    const submitData = () => {
        if (dataValidation()) {
            setLoading(true);
            dispatch(addRoleMapping(mappingData));
            setMappingData((data) => ({
                ...data,
                mappingType: "",
                plantIds: "",
                affiateIds: "",
                userId: "",
                roleMasterId: "",
            }));
            setSelectedRole("");
            setSelectedAffiliate([]);
            setSelectedPlant([]);
            setMapping(true);
            setLoading(false);
			dispatch(getRoleMappingWorklist(""));
            // PushNotification("error", "Select the user");
        } 
    };
	

	useEffect(() => {
		if (roleMappingWorklist.length > 0) {
			setParentData(roleMappingWorklist);

			setData(roleMappingWorklist);
		}
	}, [roleMappingWorklist]);

	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.userId
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.name
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.roleMasterName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.emailId
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};

	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9-@., ]+$/i.test(keyValue)) event.preventDefault();
	};

	const handleSearchKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if(event.key === 'Enter') handleSearch();
		if (!/^[a-z0-9@., ]+$/i.test(keyValue)) event.preventDefault();
	};

	return (
		<>
			<div id="user-rolemapping">
				{loading ? <div className="tc-loaderpd"><Loader /></div> : null}
				<div className="common-secondary-box">
					<div className="userrolemapping-filters">
						<div className="urm-col1">
							<div className="urm-searchrole">
								<div className="urm-search">
									<label>USER</label>
									<div>
										<input
											type="text"
											value={mappingData.userId}
											onClick={() => {
												dispatch(getEmployeeList(encryptRSAData(`search=""`)));
												setShowPopup(true);
											}}
										/>
										{/* <button>GO</button> */}
									</div>
								</div>
								<div className="urm-role">
									<label>ROLE</label>
									<Dropdown
										name={"Role ID"}
										options={roleMappingRoleDropdownList}
										handleChange={handleRoleDropDown}
										value={selectedRole}
										defaultValue={""}
									/>
								</div>
							</div>
							<div className="urm-map-out">
								{!mapping ? (
									<>
										<div className="urm-mapping">
											<div className="urm-optionbox">
												<div className="urm-roption urmroption2">
													<label>MAPPING TYPE</label>
													<div className="urm-radio">
													<label><input
															type="radio"
															name="mapping"
															value="1"
															onChange={handlePlantRadio}
															checked={mappingData.mappingType === "affiliate"}
															disabled={mapping}
														/>
														AFFILIATE</label>
													</div>
													<div className="urm-radio">
													<label><input
															type="radio"
															name="mapping"
															value="2"
															onChange={handlePlantRadio}
															checked={mappingData.mappingType === "plant"}
															disabled={mapping}
														/>
														PLANT</label>
													</div>
												</div>
											</div>
											<div className="urm-optionbox urmrplant">
												<div className="urm-roption">
													<DropdownMultiselect
														name={"Affiliate ID"}
														options={roleMappingAffiliateDropdownList}
														handleChange={handleAffiliateDropDown}
														defaultValue={""}
														value={selectedAffiliate}
														loading={loadingAffiliateListDropdown}
													/>
													{checkPlant ? (
														<DropdownMultiselect
															name={"Plant ID"}
															options={roleMappingPlantDropdownList}
															handleChange={handlePlantDropDown}
															defaultValue={""}
															value={selectedPlant}
															loading={loadingPlantListDropdown}
														/>
													) : (
														""
													)}
												</div>
											</div>
										</div>
									</>
								) : (
									""
								)}
							</div>
						</div>
						<div className="urm-btns">
							<button onClick={submitData}>ADD MAPPING</button>
						</div>
					</div>
				</div>
				<div className="common-box-inner">
					<div id="new-filter">
						<div className="nf-left">
							<div className="title">User Role Mapping</div>
						</div>
						<div className="nf-right">
							<div className="rightsearch">
								<input
									type="search"
									value={query}
									onChange={handleChange}
									placeholder="Search..."
									onKeyPress={handleKeyPress}
								/>
							</div>
						</div>
					</div>
					<div className="common-box-content">
						{loadingRoleMappingWorklist ? (
							<div className="tc-loaderpd"><Loader /></div>
						) : (
							<UserRoleMappingTable data={data} />
						)}
					</div>
				</div>
				{showPopup === true ? (
					<div id="asset-popup2">
						<div id="ap-content2">
							<span
								className="ap-closePopup"
								onClick={() => setShowPopup(false)}
							>
								x
							</span>
							<div className="urm-pop-filter">
								<div className="urm-pop-title">SEARCH EMPLOYEE</div>
								<div className="urm-textbsearch">
									<input
										type="text"
										onKeyPress={handleSearchKeyPress}
										onChange={onInputchange}
									/>
									<button onClick={handleSearch}>Search</button>
								</div>
							</div>
							<div id="ap-heatmap">
								<div className="common-box-content" id="search-emplo">
									<EmployeeTable
										data={employeeList}
										handleUpdate={handleUpdate}
									/>
								</div>
							</div>
						</div>
					</div>
				) : (
					""
				)}
			</div>
		</>
	);
};
export default UserRoleMapping;
