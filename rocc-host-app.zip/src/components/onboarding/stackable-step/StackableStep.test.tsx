/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import StackableStep from "./StackableStep"

describe("StackableStep component", () => {
    let wrapper: any
    const props: any = {
        steps: [{
            key: 0,
            title: "Welcome",
            onClick: jest.fn()
        }, {
            key: 0,
            title: "Welcome",
            onClick: jest.fn()
        }],
        activePage: 0,
        onClick: jest.fn()
    }
    beforeEach(() => {
        wrapper = shallow(<StackableStep {...props} />)
    })
    it("should render header", () => {
        const stepperGrid = wrapper.find("GridColumn")
        expect(stepperGrid).toHaveLength(1)
    })

    it("should render item content", () => {
        const divs = wrapper.find("Stepper")
        expect(divs).toHaveLength(1)
        const stepGroup = wrapper.find("StepGroup")
        stepGroup.prop("steps")
        expect(stepGroup).toHaveLength(1)
    })
})
