"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import sys
import traceback

from cfenv import AppEnv
import requests

from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.constants.constants import HSDP_VAULT, HSDP_RABBITMQ, CONTENT_TYPE, APPLICATION_JSON

LOG = create_logger("cf_utility")


def get_cf_services(name):
    env = AppEnv()
    return env.get_service(label=name)


def vault_credentials():
    try:
        if os.environ.get("ENV_TYPE") == "cloud":
            vault = get_cf_services(HSDP_VAULT).credentials
            role_id = vault.get("role_id")
            secret_id = vault.get("secret_id")
            vault_url = vault.get("endpoint")
            vault_url = vault_url if vault_url[-1] == "/" else f"{vault_url}/"
        else:
            role_id = os.environ.get("VAULT_ROLE_ID")
            secret_id = os.environ.get("VAULT_SECRET_ID")
            vault_url = os.environ.get("VAULT_URL")
            vault_url = vault_url if vault_url[-1] == "/" else f"{vault_url}/"
            
    except Exception as ex:
        traceback.print_exc()
        LOG.exception("Error while fetching cf env: {}".format(ex))
    return get_vault_credentials(role_id, secret_id, vault_url)


def get_vault_credentials(role_id, secret_id, vault_url):
    client_token = ""
    space_id = ""
    LOG.info(f"Need to fetch client token and space_id from vault API with role_id: {role_id}, secret_id: {secret_id} and vault_url: {vault_url}")
    try:
        response = requests.post(f"{vault_url}/v1/auth/approle/login",
                                 data=json.dumps({"role_id": role_id, "secret_id": secret_id}),
                                 headers={CONTENT_TYPE: APPLICATION_JSON})
        if response.status_code != 200:
            LOG.error("Error while creating Vault credentials: {}".format(response.json()))
            response.raise_for_status()
        client_token = response.json()["auth"]["client_token"]
        space_id = response.json()["auth"]["metadata"]["space_id"]
    except requests.exceptions.RequestException as ex:
        LOG.error(ex)
        LOG.error(traceback.print_exc())
        raise RoccException(ex.response.status_code, str(sys.exc_info()[1]))
    return {
        "space_id": space_id,
        "client_token": client_token,
        "vault_url": vault_url
    }


def get_rabbitmq_credentials():
    try:
        rabbitmq = get_cf_services(HSDP_RABBITMQ).credentials
        amqp_url = rabbitmq["protocols"]["amqp"]["uri"]
        return amqp_url
    except KeyError as ex:
        LOG.error("Loading of CF rabbitMQ URL failed with KeyError: {}".format(ex))
    except Exception as ex:
        LOG.error("Loading of CF rabbitMQ URL failed with error: {}".format(ex))


def fetch_app_name(app_name="ROCCServiceToolBackendService"):
    try:
        app_name = fetch_data_from_vcap_app(key="name", default_value=app_name)
    except Exception as ex:
        LOG.exception(f"Failed to fetch app name with error: {ex}")
    return app_name


def fetch_data_from_vcap_app(key, default_value=""):
    try:
        vcap_value = default_value
        exec_env = os.environ.get("ENV_TYPE", "dev")
        if exec_env == "cloud":
            vcap_application = json.loads(os.getenv("VCAP_APPLICATION", {}))
            if vcap_application:
                vcap_value = vcap_application.get(key, default_value)
        elif exec_env == "dev":
            vcap_value = os.environ.get(key, default_value)
    except Exception as ex:
        LOG.exception(f"Failed to fetch vcap value with error: {ex}")
    return vcap_value
