// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import HighchartsExporting from "highcharts/modules/exporting";

HighchartsExporting(Highcharts);
Highcharts.AST.allowedAttributes.push("onclick");

interface Props {
	GraphicalImageByAssetId: any[];
	mysensorGroupId: any;
	AnomalyModelbyAssetId: any[];
	popupFunc: any;
}
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const GraphicalOverview = ({
	GraphicalImageByAssetId,
	mysensorGroupId,
	AnomalyModelbyAssetId,
	popupFunc,
}: Props) => {
	const navigate = useNavigate();
	const [getGraphicalData, setGraphicalData] = useState<any[]>(
		AnomalyModelbyAssetId
	);
	const [imageData, setImageData] = useState<any>("");
	const AnomalyModelbyAssetIdCopy = [...AnomalyModelbyAssetId]; // Creating copy of AnomalyModelbyAssetId due to chart bug.
	const navigationFunc = async (
		key: any,
		data: any,
		data2: any,
		data3: any
	) => {
		await delay(200);
		navigate(`/${key}`, { state: { data: data, data2: data2, data3: data3 } });
	};
	useEffect(() => {
		if (GraphicalImageByAssetId && GraphicalImageByAssetId.length > 0) {
			setImageData(GraphicalImageByAssetId[0].image);
		}
	}, [GraphicalImageByAssetId]);

	useEffect(() => {
		mysensorGroupId !== ""
			? setGraphicalData(
					AnomalyModelbyAssetId.filter(
						({ sensorGroupId }) => sensorGroupId === mysensorGroupId
					)
			  )
			: setGraphicalData(AnomalyModelbyAssetId);
	}, [mysensorGroupId]);

	//==================Globalfailureprediction filter data ==================================
	let Globalfailureprediction = [];
	AnomalyModelbyAssetId.forEach((device: any, index: any) => {
		Globalfailureprediction[index] = { ...device };
	});
	let getfailureprediction = [];
	for (var i = 0; i < Globalfailureprediction.length; i++) {
		if (Globalfailureprediction[i].rul !== -999) {
			let localdata = {
				modelName: Globalfailureprediction[i].modelName,
				modelId: Globalfailureprediction[i].modelId,
				rul: Globalfailureprediction[i].rul,
				confidenceFactor: Globalfailureprediction[i].confidenceFactor,
			};
			getfailureprediction.push(localdata);
		}
	}
	//======================END===============================================================

	// Navigation of tooltip=========================================================
	(function (H) {
		H.wrap(H.Tooltip.prototype, "refresh", function (proceed, point) {
			proceed.apply(this, Array.prototype.slice.call(arguments, 1));

			var button = this.label.div.querySelectorAll("button");
			var chart = this.chart;
			var hoverPoint = chart.hoverPoint;
			var tooltip = chart.tooltip;
			if (button[0] && !button[0].addedEvent) {
				button[0].addEventListener("click", function () {
					navigationFunc(
						"assets/alertList",
						point.assetId,
						point.sensorGroupId,
						point.modelName
					);
				});
				button[0].addedEvent = true;
			}
			if (button[1] && !button[1].addedEvent) {
				button[1].addEventListener("click", function () {
					navigationFunc(
						"assets/plots",
						point.assetId,
						point.sensorGroupId,
						point.modelName
					);
				});
				button[1].addedEvent = true;
			}
			if (button[2] && !button[2].addedEvent) {
				button[2].addEventListener("click", function () {
					if (point.rul !== -999) {
						const data = {
							modelId: point.sensorGroupId,
							rul: point.rul,
							modelName: point.modelName,
						};
						popupFunc(data);
					}
				});
				button[2].addedEvent = true;
			}
		});
	})(Highcharts);
	//===================End navigation tooltip========================================

	function tooltipdata(rul) {
		if (rul !== -999)
			return `<button id="FailurePredicationButton" class="toolbtt sample" type="button" style="font-family:'SabicRegular';pointer-events: auto">Go to Failure Prediction</button>`;
		else return ``;
	}

	const getHighcharts = () => ({
		chart: {
			type: "scatter",
			zoomType: "xy",
			backgroundColor: "#ffffff",
			plotBackgroundImage: `${imageData}`,
		},
		title: {
			text: null,
		},
		xAxis: {
			visible: false,
			min: 0,
			max: 100,
		},
		yAxis: {
			visible: false,
			min: 0,
			max: 100,
		},

		navigation: {
			buttonOptions: {
				theme: {
					states: {
						hover: {
							fill: "#fff",
						},
						select: {
							fill: "#f7f8fa",
						},
					},
				},
			},
			menuItemStyle: {
				fontWeight: "normal",
				color: "#4d4d4d",
			},
			menuItemHoverStyle: {
				fontWeight: "bold",
				background: "#009FDF",
				color: "#fff",
			},
		},
		plotOptions: {
			series: { stickyTracking: false },
			scatter: {
				marker: {
					radius: 12.5,
					symbol: "square",
					lineWidth: 0.5,
					lineColor: "black",
					states: {
						hover: {
							enabled: true,
						},
					},
				},
				states: {
					hover: {
						marker: {
							enabled: false,
						},
					},
				},
			},
		},
		tooltip: {
			// followPointer: true,
			useHTML: true,
			backgroundColor: "#000000",
			borderRadius: 10,
			borderColor: "#000000",
			valueDecimals: 2,
			animation: false,
			font: "SabicRegular",
			style: {
				color: "white",
				opacity: 0.8,
				shadow: "0px 3px 6px #000000",
				// pointerEvents: 'painted'
			},
			hideDelay: 3000,
			formatter() {
				const { point } = this;
				return `<div style="width:250px;padding:25px;border-radius:5px !important;font-family:'SabicRegular';"><div><div style="font-size:1rem;text-transform:uppercase;border-bottom:1px solid white;white-space:break-spaces;margin-bottom:10px;width:100%;text-align:center;padding-bottom:5px;font-weight:normal !important;font-family: 'SabicHeadlineRegular';">${
					point.sensorGroup
				}</div><button id="AlertList" class="toolbtt" type="button"  style="font-family:'SabicRegular;pointer-events: auto;'">Go to Alert List</button><br><button class="toolbtt" type="button"   style="font-family:'SabicRegular'; pointer-events: auto">Go to Plot</button><br>${tooltipdata(
					point.rul
				)}</div></div>`;
			},
		},
		series: [
			{
				showInLegend: false,
				data:
					mysensorGroupId !== undefined
						? getGraphicalData
						: AnomalyModelbyAssetIdCopy,
			},
		],
	});

	return (
		<>
			<HighchartsReact highcharts={Highcharts} options={getHighcharts()} />
		</>
	);
};

export default GraphicalOverview;
