export const alertListData = [
  {
    "timeStamp": "2022-10-17T12:40:59",
    "modelName": "Compressor Seal Gas Performance",
    "alertId": 132042,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Seal Gas Vent To Flare 232FI414",
    "influencingSensor2": "CG Discharge Pressure 232PI496",
    "influencingSensor3": "Comp Shaft Axial Pos 232ZI472AA",
    "influencingSensor4": "CG Suction Pressure 232PI495",
    "influencingSensor5": "CG Seal Gas DP 232PDI417",
    "influencingSensor6": "N/A",
    "taskAssignedTo": "30757058",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1596
  },
  {
    "timeStamp": "2022-10-17T12:40:59",
    "modelName": "Compressor Seal Gas Performance",
    "alertId": 132042,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Seal Gas Vent To Flare 232FI414",
    "influencingSensor2": "CG Discharge Pressure 232PI496",
    "influencingSensor3": "Comp Shaft Axial Pos 232ZI472AA",
    "influencingSensor4": "CG Suction Pressure 232PI495",
    "influencingSensor5": "CG Seal Gas DP 232PDI417",
    "influencingSensor6": "N/A",
    "taskAssignedTo": "30757058",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1596
  },
  {
    "timeStamp": "2022-10-17T12:40:59",
    "modelName": "Compressor Seal Gas Performance",
    "alertId": 132042,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Seal Gas Vent To Flare 232FI414",
    "influencingSensor2": "CG Discharge Pressure 232PI496",
    "influencingSensor3": "Comp Shaft Axial Pos 232ZI472AA",
    "influencingSensor4": "CG Suction Pressure 232PI495",
    "influencingSensor5": "CG Seal Gas DP 232PDI417",
    "influencingSensor6": "N/A",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1596
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30757265",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30757265",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-04T08:22:24",
    "modelName": "Motor Journal Bearing",
    "alertId": 133366,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Bearing Temp 1 232TI409",
    "influencingSensor2": "Moter Bearing Temp 2 232TI410",
    "influencingSensor3": "Motor Shaft Y-Axis 232VI476B",
    "influencingSensor4": "Motor Shaft X-Axis 232VI476A",
    "influencingSensor5": "CG Lube Oil Pressure 232PI489",
    "influencingSensor6": "Motor Shaft Y-Axis 232VI475B",
    "taskAssignedTo": "SABICCORP\\30757265",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1593
  },
  {
    "timeStamp": "2022-11-19T08:16:05",
    "modelName": "Motor Performance",
    "alertId": 136479,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Winding Phase C 232TI448A",
    "influencingSensor2": "Moter Winding Phase A 232TI450A",
    "influencingSensor3": "Moter Winding Phase B 232TI449A",
    "influencingSensor4": "Motor Cooler Air Out 232TI421",
    "influencingSensor5": "Motor Cooler Air In 232TI420",
    "influencingSensor6": "Motor Current 232II400",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1592
  },
  {
    "timeStamp": "2022-11-19T08:16:05",
    "modelName": "Motor Performance",
    "alertId": 136479,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Winding Phase C 232TI448A",
    "influencingSensor2": "Moter Winding Phase A 232TI450A",
    "influencingSensor3": "Moter Winding Phase B 232TI449A",
    "influencingSensor4": "Motor Cooler Air Out 232TI421",
    "influencingSensor5": "Motor Cooler Air In 232TI420",
    "influencingSensor6": "Motor Current 232II400",
    "taskAssignedTo": "SABICCORP\\30751967",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1592
  },
  {
    "timeStamp": "2022-11-19T08:16:05",
    "modelName": "Motor Performance",
    "alertId": 136479,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Winding Phase C 232TI448A",
    "influencingSensor2": "Moter Winding Phase A 232TI450A",
    "influencingSensor3": "Moter Winding Phase B 232TI449A",
    "influencingSensor4": "Motor Cooler Air Out 232TI421",
    "influencingSensor5": "Motor Cooler Air In 232TI420",
    "influencingSensor6": "Motor Current 232II400",
    "taskAssignedTo": "SABICCORP\\30757265",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1592
  },
  {
    "timeStamp": "2022-11-19T08:16:05",
    "modelName": "Motor Performance",
    "alertId": 136479,
    "modelStatus": "Alert",
    "alertStatus": "Overdue",
    "influencingSensor1": "Moter Winding Phase C 232TI448A",
    "influencingSensor2": "Moter Winding Phase A 232TI450A",
    "influencingSensor3": "Moter Winding Phase B 232TI449A",
    "influencingSensor4": "Motor Cooler Air Out 232TI421",
    "influencingSensor5": "Motor Cooler Air In 232TI420",
    "influencingSensor6": "Motor Current 232II400",
    "taskAssignedTo": "SABICCORP\\30757265",
    "assignedDepartment": "Digitalization Champion",
    "takeAction": "Take Action",
    "sensorGroupId": 1592
  }
]

export const topbarData = [
  {
    alerts: 0,
    active: 28,
    overdueInvestigation: 3,
    closed: 12,
    underInvestigation: 13,
  },
];

export const assetIdDropdown = [
  {
    assetId: "2K-3101",
    assetName: "Cycle Gas Compressor 4",
  },
  {
    assetId: "2K-3201",
    assetName: "Cycle Gas Compressor 5",
  },
  {
    assetId: "2K-4101",
    assetName: "Cycle Gas Compressor 6",
  },
  {
    assetId: "2K-4103",
    assetName: "VRC",
  },
  {
    assetId: "2Y-3001A",
    assetName: "JSW N2 compressors",
  },
  {
    assetId: "2Y-3001B",
    assetName: "JSW N2 compressors",
  },
  {
    assetId: "2Y-3003A",
    assetName: "JSW C2 compressors",
  },
  {
    assetId: "2Y-3003B",
    assetName: "JSW C2 compressors",
  },
  {
    assetId: "2Y-3013A",
    assetName: "JSW H2 compressors",
  },
  {
    assetId: "2Y-3013B",
    assetName: "JSW H2 compressors",
  },
  {
    assetId: "2Y-3223",
    assetName: "Extruder 5",
  },
  {
    assetId: "2Y-3601",
    assetName: "Atlas Copco N2 Compressor",
  },
  {
    assetId: "2Y-3602",
    assetName: "Atlas Copco N2 Compressor",
  },
  {
    assetId: "2Y-3603",
    assetName: "Atlas Copco N2 Compressor",
  },
  {
    assetId: "2Y-3604",
    assetName: "Atlas Copco N2 Compressor",
  },
  {
    assetId: "2Y-3605",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-3606",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-3607",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-3608",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-3609",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-3630",
    assetName: "Atlas Copco Air Compressor",
  },
  {
    assetId: "2Y-4123A",
    assetName: "Extruder 6",
  },
  {
    assetId: "2Y-4123B",
    assetName: "Extruder 7",
  },
  {
    assetId: "2Y-3665",
    assetName: "ORC",
  },
  {
    assetId: "2Y-3123",
    assetName: "Extruder 4",
  },
];

export const modelNameDropdown = [
  {
    assetSapId: "310017625",
    sensorGroupName: "Compressor Performance",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Compressor Thrust Bearing",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Aftercooler Performance",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Compressor Journal Bearing",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Dry Gas Seal",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Lube Oil System",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Motor Journal Bearing",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Motor Performance",
  },
  {
    assetSapId: "310017625",
    sensorGroupName: "Compressor Performance_Fe",
  },
];

export const modelStatusDropdown = [
  {
    sensorGroupName: "Motor Performance",
    modelStatus: "Asset-Off",
    sensorGroupId: 1405,
  },
  {
    sensorGroupName: "Motor Performance",
    modelStatus: "Asset-Off",
    sensorGroupId: 1405,
  },
];
