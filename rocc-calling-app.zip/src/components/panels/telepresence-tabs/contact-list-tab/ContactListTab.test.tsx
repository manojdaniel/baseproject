/*
 * Created on Wed Sep 01 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ContactsListTab from "./ContactListTab"
import { shallow } from "enzyme"
import { ESidePanelTabs } from "../../../../types/types"

jest.mock("../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

describe("ContactsListTab Component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<ContactsListTab ContactListComponentTab={() => <>Sample</>} activeItem={ESidePanelTabs.Active} contacts={[]} />)
    })

    it("should render ActiveCallTab component", () => {
        expect(wrapper.find("#contactsListTab")).toHaveLength(1)
    })
})
