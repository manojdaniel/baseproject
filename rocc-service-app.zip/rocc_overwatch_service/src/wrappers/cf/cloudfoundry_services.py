"""
 Created on Tue Nov 17 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from cloudfoundry_client.client import CloudFoundryClient
from cloudfoundry_client.v2.routes import RouteManager
from cloudfoundry_client.v2.service_bindings import ServiceBindingManager
from cloudfoundry_client.v2.service_instances import ServiceInstanceManager
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger

LOG = create_logger("CloudfoundryServices")

def get_app_guid_by_name(app_name, client: CloudFoundryClient):

    for app in client.v2.apps:
        if app["entity"]["name"] == app_name:
            LOG.info(f"Found app {app_name} with guid: {app['metadata']['guid']}")
            return app['metadata']['guid']
    LOG.error(f"App {app_name} not found")
    raise RoccException(404, f"App: {app_name} not found")

def get_domain_guid_by_name(domain_name, client: CloudFoundryClient):
    for domain in client.v3.domains:
        if domain['name'] == domain_name:
            LOG.info(f"Found domain {domain_name} with guid: {domain['guid']}")
            return domain['guid']
    LOG.error(f"Domain {domain_name} not found")
    raise RoccException(404, f"Domain: {domain_name} not found")

def get_space_guid_by_name(space_name, client: CloudFoundryClient):
    for space in client.v3.spaces:
        if space['name'] == space_name:
            LOG.info(f"Found space {space_name} with guid: {space['guid']}")
            return space['guid']
    LOG.info(f"Space {space_name} not found")
    raise RoccException(404, f"Space: {space_name} not found")

def get_route_guid_by_name(route_name, client: CloudFoundryClient):
    for route in client.v2.routes:
        if route['entity']['host'] == route_name:
            LOG.info(f"Found route {route_name} with guid: {route['metadata']['guid']}")
            return route["metadata"]["guid"]
    LOG.info(f"Route {route_name} not found")
    raise RoccException(404, f"Route: {route_name} not found")

def get_service_plan_guid_by_name(plan_name, client: CloudFoundryClient):
    for plan in client.v2.service_plans:
        if plan['entity']['name'] == plan_name:
            LOG.info(f"Found service plan {plan_name} with guid: {plan['metadata']['guid']}")
            return plan["metadata"]["guid"]
    LOG.info(f"Service plan {plan_name} not found")
    raise RoccException(404, f"Service plan: {plan_name} not found")

def get_service_instance_guid_by_name(service_instance_name, client: CloudFoundryClient):
    for service_instance in client.v2.service_instances:
        if service_instance['entity']['name'] == service_instance_name:
            LOG.info(f"Found service instance {service_instance_name} with guid: {service_instance['metadata']['guid']}")
            return service_instance["metadata"]["guid"]
    LOG.info(f"Service instance {service_instance_name} not found")
    raise RoccException(404, f"Service instance: {service_instance_name} not found")

def get_service_binding_guid_by_service_instance_guid(service_instance_guid, client: CloudFoundryClient):
    for service_binding in client.v2.service_bindings:
        if service_binding['entity']['service_instance_guid'] == service_instance_guid:
            LOG.info(f" Binding found: {service_binding['metadata']['guid']}")
            return service_binding["metadata"]["guid"]
    LOG.info(f"Service binding for instance: {service_instance_guid} not found")

def delete_route(route_name, target_endpoint, client):
    try:
        route_manager = RouteManager(target_endpoint, client)
        route_guid = get_route_guid_by_name(route_name=route_name, client=client)
        if route_guid:
            LOG.info(f"Deleting route {route_name}")
            route_manager._remove(resource_id=route_guid)
            LOG.info(f"Successfully deleted route {route_name}")
        else:
            LOG.error(f"Route {route_name} not found.")
    except Exception as ex:
        LOG.error(f"Error while deleting the route {route_name}. Error {ex}")

def delete_service_and_bindings(service_instance_name, target_endpoint, client, delete_instance=True):
    try:
        service_instance_manager = ServiceInstanceManager(target_endpoint, client)
        service_binding_manager = ServiceBindingManager(target_endpoint, client)
        service_instance_guid = get_service_instance_guid_by_name(service_instance_name, client)
        service_binding_guid = get_service_binding_guid_by_service_instance_guid(service_instance_guid, client)
        if service_binding_guid:
            LOG.info(f"Deleting service binding {service_binding_guid}")
            service_binding_manager._remove(resource_id=service_binding_guid)
            LOG.info(f"Successfully deleted service binding {service_binding_guid}")
        if service_instance_guid and delete_instance:
            LOG.info(f"Deleting service instance {service_instance_guid}")
            service_instance_manager._remove(resource_id=service_instance_guid)
            LOG.info(f"Successfully deleted service instance {service_instance_guid}")

    except Exception as ex:
        LOG.error(f"Error while deleting the service instance {service_instance_name}. Error {ex}")
