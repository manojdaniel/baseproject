
/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ReactFragment } from "react"


export interface IDataGrid {
    title: string
    data: any
    columns: ITableColumn[]
    pagination: boolean
    initialPageSize: number
    filter: boolean
    multiSelect: boolean
    search: boolean
    searchBox?: any
    initialSortColumn?: ISortColumn
    moreAction: boolean     // TODO: array of action objects
    onDrillDown?(itemId: number): void | undefined
    tableHeadButton?: any
    detailsComponent?: (itemId: number, handleDeselectDataClick: () => void) => ReactFragment | undefined
    disableSort?: boolean
    noRecords?: boolean
}

export interface ISortColumn {
    path: string
    order: string
}

export interface ITableColumn {
    key?: string
    path: string
    label: string
    type: string
    display: boolean
    className?: string
    width?: number
}

export interface ITableHeader {
    columns: any
    sortColumn: ISortColumn
    onSort(column: ISortColumn): void
    multiSelect: boolean
}

export interface ITableHead {
    title: string
    actions: any
}


export interface ITableBody {
    loading: boolean
    data: any
    columns: ITableColumn[]
    initialPageSize: number
    selectedRowIndex: Array<number>
    multiSelect: boolean
    onRowClick?(rowIndex: number, row: any): void
    onDrillDown?(itemId: number): void
    currentRow: number
}


export enum EColumn {
    pk,
    string,
    number,
    link,
    date,
    datetime,
    status,
    object,
    entityObject,
    entityObjectList,
    list,
    name,
    overflow
}

export interface ITable {
    loading: boolean
    title: string | undefined
    data: any,
    columns: ITableColumn[]
    initialPageSize: number
    sortColumn: ISortColumn
    selectedRowIndex: Array<number>
    multiSelect: boolean
    onSort(column: ISortColumn): void
    onRowClick(rowIndex: number, row: any): void
    onDrillDown?(itemId: number): void
    tableHeadButton?: any
    currentRow: number
    searchBox?: any
    noRecords?: boolean
}
