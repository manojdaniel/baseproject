/*
 * Created on Mon Dec 8 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EConnectionType, EPosition } from "@rocc/rocc-client-services"
import { RoomBannerCameraControls, RoomBannerUserDetails } from "@rocc/rocc-console-components"
import cx from "classnames"
import React, { useEffect, useRef } from "react"
import { useSelector } from "react-redux"
import { roomMonitoringMessage } from "../../../common/helpers/consoleUtility"
import { isRoomMonitoringEnabledForCC } from "../../../common/helpers/helpers"
import MultiCameraController from "../../../common/modules/multi-camera/controller/MultiCameraController"
import cameraStyles from "../../../common/modules/multi-camera/gallery-view/MultiCameraGalleryView.scss"
import ConsoleTrigger from "../../../ConsoleTrigger"
import { IActiveSessionWithMultiCamera, IStore } from "../../../redux/interfaces/types"
import styles from "../console-view-banner/ViewConsoleBanner.scss"

const WebCallFeature = React.lazy(() => import("roccCalling/WebCallFeature").catch(() => false))
const PhoneCallFeature = React.lazy(() => import("roccCalling/PhoneCallFeature").catch(() => false))

const EditConsoleBanner = (props: IActiveSessionWithMultiCamera) => {
    const {
        consoleSessions, rooms, receivers, featureFlags, displayLeftSidePanel
    } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        rooms: state.externalReducer.rooms,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        featureFlags: state.externalReducer.featureFlags,
        displayLeftSidePanel: state.externalReducer.displayRightSidePanel
    }))

    const { currentSession, roomUuid, technologistName, buttonTitle, displayCameraState, showCameraSettings, showCameraControls, multiCameraDisabled, rightSidePanel, handleCameraSettingsClick, handleCameraSliderClick } = props

    const consoleSessionsRef = useRef(consoleSessions)

    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    const getPhoneNumbers = () => {
        const phoneNmbers = []
        const room = rooms.find(room => room.roomUuid === roomUuid)
        if (room) {
            phoneNmbers.push({ key: room.phoneNumber, text: room.phoneNumber, value: room.phoneNumber })
        }
        return phoneNmbers
    }

    const getCameraDetails = () => {
        return showCameraControls ? <RoomBannerCameraControls
            displayCamerasState={displayCameraState}
            showCameraSettings={showCameraSettings}
            isDisabled={multiCameraDisabled}
            handleCameraSettingsClick={() => handleCameraSettingsClick()}
            handleCameraSliderClick={() => handleCameraSliderClick()}
        /> : <></>
    }

    const widthStyle = displayLeftSidePanel ? styles.narrowWidth : styles.maxWidth

    const getCallOptions = () => {
        return (
            <div className={styles.callButtons}>
                <div className={styles.webCallIcon}>
                    <WebCallFeature contactUuid={roomUuid} isDisabled={false} background={true} showTitle={buttonTitle} />
                </div>
                <div className={styles.phoneCallIcon}>
                    <PhoneCallFeature contactUuid={roomUuid} phoneNumbers={getPhoneNumbers()} isDisabled={false} showTitle={buttonTitle} background={true} />
                </div>
            </div>
        )
    }

    const cameraController = () => {
        return isRoomMonitoringEnabledForCC(featureFlags, currentSession) ?
            receivers.length > 1 ? <div className={styles.cameraContainer}>{roomMonitoringMessage(widthStyle, cameraStyles)}</div>
                : <></>
            : <div className={styles.cameraContainer}><MultiCameraController consoleSession={currentSession} /></div>
    }

    return (
        <div className={cx(styles.mainContainer, rightSidePanel && styles.sideBarOpenStyles)} id={"editSessionContainer"}>
            <div className={styles.roomBannerContainer} id="editBannerContainer">
                {<RoomBannerUserDetails name={technologistName} />}
                {getCameraDetails()}
                {getCallOptions()}
                <div className={styles.consoleButtons} id="bannerButtons">
                    <div className={styles.viewButton}>
                        <ConsoleTrigger
                            connectionType={EConnectionType.VIEW}
                            roomUuid={roomUuid}
                            showTitle={buttonTitle}
                            iconPosition={EPosition.VERTICAL}
                        />
                    </div>
                    <div>
                        <ConsoleTrigger
                            connectionType={EConnectionType.FULL_CONTROL}
                            roomUuid={roomUuid}
                            showTitle={buttonTitle}
                            iconPosition={EPosition.VERTICAL}
                        />
                    </div>
                </div>

            </div>
            {cameraController()}
        </div>
    )
}

export default EditConsoleBanner
