"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import time
from cloudfoundry_client.client import CloudFoundryClient, AppManagerV2, ServiceInstanceManager, ServiceBindingManager
from cloudfoundry_client.v2.routes import RouteManager
from src.constants.config_keys import CUSTOMER_OB_COUNTRY_ISO_CODE, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_PARENT_ORG_ID, VAULT_HSDP_IAM_URL
from src.constants.constants import CF_DOMAIN, CF_SPACE_NAME, CF_TARGET_ENDPOINT, ENTITY_ID, FAILED, JOB_LIST, CURRENT_JOB, PROXY_APP_NAME, ROCC_PROXY_URL, ROCC_SUFFIX, \
    TRANSACTION_ID, INIT, COMPLETED, JOB_NAME, INDEX, STATUS, HSDP_IAM_URL, DATA, SERVICE_AUTH_ISSUER, \
    SERVICE_AUTH_PRIVATE_KEY, ID, TRANSACTION_DATA, TWILIO_APP_NAME, TWILIO_PLAN_SUBACCOUNT, TWILIO_POOL_APP_NAME, USER_UUID, FAILED_AT
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_job_id_from_name, get_infra_configs, update_service_job_transaction_status, \
    get_service_job_transactions_details, fetch_tasks_for_job, update_tasks_for_transaction
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.job_management.job_handler import JobHandler
from src.wrappers.cf.cf_utility import fetch_data_from_vcap_app
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.cf.cloudfoundry_services import delete_route, delete_service_and_bindings, get_app_guid_by_name, get_domain_guid_by_name, get_route_guid_by_name, \
    get_service_instance_guid_by_name, get_service_plan_guid_by_name, get_space_guid_by_name
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.communication_services.communication_profile_services import create_org_comm_profile_service

LOG = create_logger("CFCustomerSetupJob")


class CFCustomerSetupJob(JobHandler):

    def __init__(self):
        self._success = False
        self._cf_space_name = False
        self._domain_name = False
        self._proxy_app_name = False
        self._twilio_app_name = False
        self._cf_twilio_pool_app_name = False
        self._cf_client = False
        self._nginx_guid = False
        self._domain_guid = False
        self._space_guid = False
        self._service_plan_guid = False
        self._payload = False
        self._user_detail = False
        self._customer_name = False
        self._transaction_id = False
        self._customer_vault_values = False
        self._customer_token = False
        self._parent_token = False
        self._parent_org_id = False
        self._client = False
        self._job_id = False
        self._transaction_data = False
        self._db_customer_id = False
        self._infra_configs = False
        self._tasks_list = False
        self._profile_configs = False
        self._target_endpoint = False
        self._twilio_pool_guid = False

    def initalize_job(self):
        try:
            self.load_vault_configs()
            self._target_endpoint = fetch_data_from_vcap_app(key=CF_TARGET_ENDPOINT, default_value="https://api.cloud.pcftest.com")
            self._cf_space_name = fetch_data_from_vcap_app(key=CF_SPACE_NAME)
            if not self._cf_space_name:
                LOG.exception("Did not get a valid space name!")
                raise RoccException(status_code=500, payload="Did not find valid space name")
            self._domain_name = os.environ[CF_DOMAIN]
            self._proxy_app_name = os.environ[PROXY_APP_NAME]
            self._twilio_app_name = os.environ[TWILIO_APP_NAME]
            self._cf_twilio_pool_app_name = os.environ[TWILIO_POOL_APP_NAME]
            proxy = dict(http=os.environ.get("HTTP_PROXY", ""), https=os.environ.get("HTTPS_PROXY", ""))
            self._cf_client = CloudFoundryClient(self._target_endpoint, proxy=proxy, verify=False)
            self._cf_client.init_with_user_credentials(self._profile_configs["CF_USERNAME"], self._profile_configs["CF_PASSWORD"])
            self._nginx_guid = get_app_guid_by_name(app_name=self._proxy_app_name, client=self._cf_client)
            self._domain_guid = get_domain_guid_by_name(domain_name=self._domain_name, client=self._cf_client)
            self._space_guid = get_space_guid_by_name(self._cf_space_name, client=self._cf_client)
            self._service_plan_guid = get_service_plan_guid_by_name(TWILIO_PLAN_SUBACCOUNT, client=self._cf_client)
            self._twilio_pool_guid = get_app_guid_by_name(app_name=self._cf_twilio_pool_app_name, client=self._cf_client)
        except Exception as ex:
            LOG.exception(f"Failed to initialize CF configurations JOB with error: {ex}")
            self.post_message(payload=self._payload, error_message=repr(ex.args))

    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            self._user_detail = self._payload[USER_UUID]
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            self.initalize_job()
            self._customer_name = self._payload[ENTITY_ID]
            self._transaction_id = self._payload[TRANSACTION_ID]
            self._customer_vault_values = get_path_specific_vault_values(self._customer_name)
            self._customer_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                                   issuer=self._customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                                   private_key=self._customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])

            self._parent_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                 issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                 private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])

            self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._client = get_client_connection(self._parent_token, org_infra_uuid=self._parent_org_id)
            job_transaction_details = self.fetch_transaction_from_db(transaction_id=self._payload[TRANSACTION_ID])
            self._job_id = fetch_job_id_from_name(EJobs.CF_CUSTOMER_SETUP.value, self._client)
            self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
            self._db_customer_id = job_transaction_details[0]["entity_id"]
            self.load_infra_configs(customer_id=self._db_customer_id)
            if len(job_transaction_details) != 0:
                self.fetch_all_tasks()
                self.update_transaction_in_db_wrt_job(status=INIT, task_name=ETasks.CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER.value, job_status_update=True, update_record_status=False)
                self.execute_tasks()
                prepare_and_post_audit(event_type=EJobs.CF_CUSTOMER_SETUP.value, event_subtype=EJobs.CF_CUSTOMER_SETUP.value, action="E", outcome=0,
                                       user_detail=self._user_detail, org_id=self._parent_org_id, token=self._parent_token,
                                       **{EJobs.CF_CUSTOMER_SETUP.value: COMPLETED},
                                       **{TRANSACTION_ID: self._transaction_id})
            else:
                LOG.info(f"{self._payload[CURRENT_JOB]} Job is completed and transaction details are, {self._payload[TRANSACTION_ID]}")

            self.post_message(payload=self._payload)
            LOG.info(f"Finished Job: {EJobs.CF_CUSTOMER_SETUP.value}")

        except RoccException as ex:
            LOG.exception(f"ROCC Exception while running CFCustomerSetup Job {ex}")
            self.post_message(payload=self._payload, error_message=str("" if ex.payload is None else ex.payload))
            raise RoccException(ex.status_code, str(ex.payload)) from ex
        except Exception as ex:
            LOG.exception(f"General Exception while running CFCustomerSetup Job: {ex}")
            self.post_message(payload=self._payload, error_message=repr(ex.args))
            raise RoccException(500, f"General Exception while running CFCustomerSetup Job{ex}") from ex

    def load_infra_configs(self, customer_id):
        """Fetch corresponding infra configs from infrastructure_configurations table"""
        response = get_infra_configs(self._client, customer_id)
        if response and len(response) > 0:
            self._infra_configs = response[0]
        else:
            LOG.error(f"Could not retrieve infrastructure configs for customer_id: {customer_id} with transaction: {self._payload[TRANSACTION_ID]}")
            raise RoccException(status_code=500,
                                payload=f"Could not retrieve infrastructure configs for customer_id: {customer_id} with transaction: {self._payload[TRANSACTION_ID]}")

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(job_id=self._job_id, client=self._client)
        LOG.info(f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def fetch_transaction_from_db(self, transaction_id):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(transaction_id, client=self._client)
        LOG.info(f"Fetch job details for transaction_id, {transaction_id} is successful")
        return transaction_details

    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        if update_record_status:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self._client)
            LOG.info(f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._payload[TRANSACTION_ID],
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[ID],
                                                              transaction_data_object=self._transaction_data,
                                                              status=status,
                                                              client=self._client,
                                                              job_status_update=job_status_update,
                                                              reason=error_reason)

    def load_vault_configs(self):
        """Fetch vault data from corresponding vault profile"""
        try:
            self._profile_configs = get_profile_data()
        except Exception as ex:
            LOG.exception(f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}, with error: {ex}")
            raise RoccException(status_code=500, payload=f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}") from ex

    def execute_tasks(self):
        """
        Tasks:
        - CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER
        - CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER
        """
        try:
            LOG.info(f"Transaction: {self._transaction_id} - Executing tasks under job: {EJobs.CF_CUSTOMER_SETUP.value}")
            self.task_create_proxy_route()
            self.task_create_twilio_subaccount()
            self.task_create_org_comm_profile()
            LOG.info(f"Transaction: {self._transaction_id} - All tasks under job: {EJobs.CF_CUSTOMER_SETUP.value} is completed")
            self.update_transaction_in_db_wrt_job(COMPLETED, ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value, job_status_update=True)
            self._success = True

        except Exception as ex:
            LOG.exception(f"Error occured while executing JOB: CfCustomerSetup {ex}.")
            LOG.info("Executing rollback mechanism")
            self.roll_back_on_failure()

    def post_message(self, payload, error_message=""):
        """
        1. Post message to RabbitMQ with Payload
        """
        try:
            if self._success:
                current_record = list(filter(
                    lambda item: item[JOB_NAME] == EJobs.CF_CUSTOMER_SETUP.value, payload[JOB_LIST]))[0]
                for job in payload[JOB_LIST]:
                    if job[JOB_NAME] == EJobs.CF_CUSTOMER_SETUP.value:
                        job[STATUS] = COMPLETED
                    if job[INDEX] == current_record[INDEX] + 1:
                        payload[CURRENT_JOB] = job[JOB_NAME]
                        job[STATUS] = INIT
                LOG.info(f"Publishing a rabbitMQ message after completing current Job: {EJobs.CF_CUSTOMER_SETUP.value}")

            else:
                self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value, job_status_update=True, error_reason=error_message)
                payload[CURRENT_JOB] = EJobs.FAILED.value
                payload[FAILED_AT] = EJobs.CF_CUSTOMER_SETUP.value
                LOG.warn(f"Publishing FAILED rabbitMQ message, since the current job: {EJobs.CF_CUSTOMER_SETUP.value} is failed")
            publish_message(payload=payload)
        except Exception as ex:
            LOG.exception(f"Failed to post message with error: {ex}")

    def roll_back_on_failure(self):
        self.task_cleanup_route(route_name=f"{self._customer_name}{ROCC_SUFFIX}")
        self.task_cleanup_services(service_instance_name=f"{self._twilio_app_name}-{self._customer_name}")

    def task_cleanup_route(self, route_name):
        delete_route(route_name, target_endpoint=self._target_endpoint, client=self._cf_client)

    def task_cleanup_services(self, service_instance_name):
        delete_service_and_bindings(service_instance_name, target_endpoint=self._target_endpoint, client=self._cf_client)

    def task_create_proxy_route(self):
        error_reasn = ""
        try:
            route_manager = RouteManager(target_endpoint=self._target_endpoint, client=self._cf_client)
            route_manager.create_host_route(domain_guid=self._domain_guid, space_guid=self._space_guid, host=f"{self._customer_name}{ROCC_SUFFIX}")
            LOG.info(f"Successfully created host route {self._customer_name}{ROCC_SUFFIX}")
        except Exception as ex:
            LOG.exception(f"Failed to create proxy route with error: {ex}")
            if ex.body and ex.body["code"] == 210003:
                LOG.warning(f"Skipping route creation since route {self._customer_name}{ROCC_SUFFIX} already exists")
            else:
                LOG.error(f"Error while creating host route {self._customer_name}{ROCC_SUFFIX}. Error: {ex}")
                error_reasn = f"Error while creating host route {self._customer_name}{ROCC_SUFFIX}. Error: {repr(ex.args)}"
                self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER.value, error_reason=error_reasn)
                raise RoccException(500, f"Error while creating host route {self._customer_name}{ROCC_SUFFIX}. Error: {ex}") from ex

        try:
            route_guid = get_route_guid_by_name(route_name=f"{self._customer_name}{ROCC_SUFFIX}", client=self._cf_client)
            app_manager = AppManagerV2(target_endpoint=self._target_endpoint, client=self._cf_client)
            app_manager.associate_route(application_guid=self._nginx_guid, route_guid=route_guid)
            LOG.info(f"Successfully mapped host route {self._customer_name}{ROCC_SUFFIX} to app {os.environ[PROXY_APP_NAME]}")
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER.value)
        except Exception as ex:
            LOG.exception(f"Error occured while trying to map {self._customer_name}{ROCC_SUFFIX} to app {os.environ[PROXY_APP_NAME]}. Error: {ex}")
            error_reasn = f"Error occured while trying to map {self._customer_name}{ROCC_SUFFIX} to app {os.environ[PROXY_APP_NAME]}. Error: {repr(ex.args)}"
            self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER.value, error_reason=error_reasn)
            raise RoccException(500, f"Error occured while trying to map {self._customer_name}{ROCC_SUFFIX} to app {os.environ[PROXY_APP_NAME]}. Error: {ex}") from ex

    def task_create_twilio_subaccount(self):
        error_reasn = ""
        try:
            service_manager = ServiceInstanceManager(target_endpoint=self._target_endpoint, client=self._cf_client)
            service_manager.create(space_guid=self._space_guid, name=f"{self._twilio_app_name}-{self._customer_name}", service_plan_guid=self._service_plan_guid)
            LOG.info(f"Successfully created service instance {self._twilio_app_name}-{self._customer_name}")
        except Exception as ex:
            LOG.exception(f"Failed to create twilio sub-account service with error: {ex}")
            if ex.body and ex.body["code"] == 60002:
                LOG.warning(f"Skipping creating service instance {self._twilio_app_name}-{self._customer_name} since it already exists.")
            else:
                LOG.error(f"Error while creating service instance. Error {ex}")
                error_reasn = f"Error while creating service instance. Error {repr(ex.args)}"
                self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value, error_reason=error_reasn)
                raise RoccException(500, f"Error while creating service instance. Error {ex}") from ex

        try:
            service_instance_guid = get_service_instance_guid_by_name(service_instance_name=f"{self._twilio_app_name}-{self._customer_name}", client=self._cf_client)
            service_binding_manager = ServiceBindingManager(target_endpoint=self._target_endpoint, client=self._cf_client)
            LOG.info("Waiting for 20 seconds")
            time.sleep(20)
            service_binding_manager.create(app_guid=self._twilio_pool_guid, instance_guid=service_instance_guid)
            LOG.info(f"Successfully binded service instance {self._twilio_app_name}-{self._customer_name} to app {os.environ[TWILIO_POOL_APP_NAME]}")
            app_manager = AppManagerV2(target_endpoint=self._target_endpoint, client=self._cf_client)
            LOG.info(f"Stopping the application {self._cf_twilio_pool_app_name}")
            app_manager.stop(application_guid=self._twilio_pool_guid)
            LOG.info(f"Starting the application {self._cf_twilio_pool_app_name}")
            app_manager.start(application_guid=self._twilio_pool_guid)
            LOG.info(f"Application started !! {self._cf_twilio_pool_app_name}")
            LOG.info("Waiting for 20 seconds")
            time.sleep(20)
            LOG.info("Resuming execution.")
            self.update_transaction_in_db_wrt_job(COMPLETED, ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value)
        except Exception as ex:
            LOG.exception(f"Failed to bind twilio sub-account service with error: {ex}")
            if ex.body and ex.body["code"] == 90003:
                LOG.warning(f"Skipping binding since the service {self._twilio_app_name}-{self._customer_name} is already bound to the app {os.environ[TWILIO_POOL_APP_NAME]}.")
            else:
                error_reasn = f"Exception occured while binding app to the service: Error {repr(ex.args)}"
                self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value, error_reason=error_reasn)
                LOG.error(f"Exception occured while binding app to the service: {ex}")
                raise RoccException(500, f"Exception occured while binding app to the service: {ex}") from ex

    def task_create_org_comm_profile(self):
        response, error_reasn = create_org_comm_profile_service(url=os.environ[ROCC_PROXY_URL],
                                                                org_name=self._payload[ENTITY_ID],
                                                                token=self._customer_token,
                                                                org_id=self._customer_vault_values[DATA]["hsdpOrganizationId"],
                                                                country_iso_code=self._infra_configs["infra_configs"][CUSTOMER_OB_COUNTRY_ISO_CODE],
                                                                sub_acc_name=f"{self._twilio_app_name}-{self._customer_name}")
        prepare_and_post_audit(event_type=EJobs.CF_CUSTOMER_SETUP.value, event_subtype=ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value, action="C", outcome=0,
                               user_detail=self._user_detail, org_id=self._parent_org_id, token=self._parent_token,
                               **{ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value: COMPLETED},
                               **{TRANSACTION_ID: self._transaction_id})
        if not response:
            LOG.error(f"Task: {ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(FAILED, ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value, error_reason=error_reasn)
            prepare_and_post_audit(event_type=EJobs.CF_CUSTOMER_SETUP.value, event_subtype=ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value, action="C", outcome=12,
                                   user_detail=self._user_detail, org_id=self._parent_org_id, token=self._parent_token,
                                   **{ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value: FAILED},
                                   **{TRANSACTION_ID: self._transaction_id})
            raise RoccException(status_code=500, payload=str("Failed to create org_comm_profile"))
        self.update_transaction_in_db_wrt_job(COMPLETED, ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value)
