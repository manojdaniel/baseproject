/*
 * Created on Thu Dec 9 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, EConnectionMode, EConnectionType, EDefaultTransactionValue, ETransactionStatus, EUserPresence, IAVCallDetails } from "@rocc/rocc-client-services"
import * as consoleService from "../../../services/consoleService"
import { handleAuthorizationRequest, IAuthorizationRequest } from "./authorizationTaskHandler"
import * as consoleActions from "../../../redux/actions/consoleActions"
import * as helpers from "../../helpers/helpers"

const mockDispatch = jest.fn()
const authorizationRequest: IAuthorizationRequest = {
    auth: false,
    consoleTransaction: {
        transactionStatus: ETransactionStatus.IDLE,
        roomUuid: "roomUuid",
        connectionType: EConnectionType.DEFAULT,
        connectionMode: EConnectionMode.CC,
        connectionStatus: EDefaultTransactionValue.CONNECTING,
        receiverName: "recieverName", transactionId: "", groupId: ""
    },
    currentUser: {
        id: "1",
        uuid: "uuid",
        siteId: ["siteId"],
        orgId: "1",
        status: EUserPresence.AVAILABLE,
        name: "name",
        phoneNumber: "phoneNumber",
        clinicalRole: EClinicalRole.EXPERTUSER,
        email: "email",
        roomName: "roomName",
        allRoles: [EClinicalRole.EXPERTUSER],
        secondaryName: "secondaryName",
        secondaryUUID: "secondaryUUID",
        modalities: ["modalities"],
        description: "description",
        accessToken: "accessToken",
        onBoarded: true,
        sessionId: "sessionId",
        locale: "locale",
        accessTokenExpiryTime: ""
    },
    seatName: "seatName",
    dispatch: mockDispatch
}

jest.mock("react-redux", () => ({
    useDispatch: () => mockDispatch
}))


describe("handleAuthorizationRequest tests", () => {
    it("should be defined", () => {
        jest.spyOn(helpers, "getCallContextByContactUuid").mockReturnValue({ contextId: "callContextId" } as IAVCallDetails)
        jest.spyOn(consoleService, "requestAuthorizationService").mockReturnValue(Promise.resolve("ContextId"))
        jest.spyOn(consoleActions, "updateSpecificDataToTransactionGroup")
        expect(handleAuthorizationRequest(authorizationRequest)).toBeDefined()
    })
})
