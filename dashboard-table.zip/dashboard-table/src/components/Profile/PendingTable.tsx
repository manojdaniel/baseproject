import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../assets/common/CommonTables.scss";
import moment from "moment";

interface Props {
	data: any[];
}
const PendingTable = ({ data }: Props) => {
    // Time Formate work :Start
    const [pendingTableData, setPendingTableData] = useState<any>();
    useEffect(() => {
        let mydata = data.map(
            function (item: any) {
                return {
                    AlertID: item.AlertID,Affiliate:item.Affiliate, Plant:item.Plant, AssetID:item.AssetID, AssetName:item.AssetName,AnomolyType:item.AnomolyType,LongLeadAction:item.LongLeadAction, TaskAssignedTo: item.TaskAssignedTo , TimeStamp: moment(new Date(`${item.TimeStamp}`)).format("DD/MM/YYYY HH:MM:SS A") 
                };
            });
            setPendingTableData(mydata);
    }, [data]);
    // Time Formate work :End
    const columns = [
        {
            title: "ALERTID",
            dataIndex: "AlertID",
            key: "AlertID",
            width:"10%"
        },
        {
            title: "AFFILIATE",
            dataIndex: "Affiliate",
            key: "Affiliate",
            width:"10%"
        },
        {
            title: "PLANT",
            dataIndex: "Plant",
            key: "Plant",
            width:"10%"
        },
        {
            title: "ASSET ID ",
            dataIndex: "AssetID",
            key: "AssetID",
            width:"10%"
        },
        {
            title: "ASSET NAME ",
            dataIndex: "AssetName",
            key: "AssetName",
            width:"20%"
        },
        {
            title: "ANOLMOLY TYPE",
            dataIndex: "AnomolyType",
            key: "AnomolyType",
            width:"10%"
        },
        {
            title: "LONG LEAD ACTION",
            dataIndex: "LongLeadAction",
            key: "LongLeadAction",
            width:"10%"
        },
        {
            title: "ASSIGNED TO",
            dataIndex: "TaskAssignedTo",
            key: "TaskAssignedTo",
            width:"10%"
        },
        {
            title: "TIMESTAMP",
            dataIndex: "TimeStamp",
            key: "TimeStamp",
            width:"10%"
        }
    ];


    return (
        <div>
            <Table
                columns={columns}
                dataSource={pendingTableData}
                pagination={false}
                scroll={{x:true, y: 300 }}
            />
        </div>
    );
};

export default PendingTable;
