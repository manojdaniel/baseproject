import React, { useRef, useEffect, useState } from "react";
import { Table, Switch, Button, Modal, Form, Select } from "antd";
import { useDispatch, useSelector } from "react-redux";
import DropdownMultiselect from "components/DropdownMultiselect";
import Dropdown from "components/Dropdown";
//import '../../assets/common/CommonTables.scss';
import moment from "moment";
import axios from "axios";
import { BASE_URL2, Api } from "../../utility/api";
import {
	getRoleMappingWorklist,
	getRoleMappingPlantDropdownList,
	updateRoleMappingStatus,
	updateRoleMapping,
} from "../../redux/reducers/CommonReducer";
import Loader from "components/Loader";
import PushNotification from "components/PushNotification";
import { encryptRSAData } from "../../utility/rsa";
interface Props {
	data: any[];
}
const UserRoleMappingTable = ({ data }: Props) => {
	let dispatch = useDispatch();
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [worklist, setWorklist] = useState<any>();
	const [loading, setLoading] = useState<any>(false);
	useEffect(() => {
		let mydata = data.map(function (item: any) {
			return {
				affilliateId: item.affilliateId,
				plantId: item.plantId,
				//AlertStatus: item.alertStatus,
				name: item.name,
				userId: item.userId,
				affiliate: item.affiliate,
				plant: item.plant,
				roleId: item.roleId,
				roleMasterName: item.roleMasterName,
				mappingType: item.mappingType,
				email: item.emailId,
				// InfluencingSensor6: item.influencingSensor6,
				// AssignedDepartment: item.assignedDepartment,
				// TaskAssignedTo: item.taskAssignedTo,
			};
		});
		setWorklist(mydata);
	}, [data]);
	const [selectVal, setSelectVal] = useState<any>({
		value: "",
		label: "",
	});
	const [selectAffiliate, setSelectAffiliate] = useState([]);
	const [selectedAffiliate, setSelectedAffiliate] = useState<any>([]);
	const [selectedPlant, setSelectedPlant] = useState<any>([]);
	const [selectPlant, setSelectPlant] = useState([]);
	const [mapping, setMapping] = useState<any>(false);
	const [checkPlant, setCheckPlant] = useState<any>(false);
	const [mappingData, setMappingData] = useState<any>({
		userId: "",
		userName: "",
		roleMasterId: 0,
		email: "",
		lastLoginTime: "2023-05-05T06:50:25.738Z",
		active: true,
		mappingType: "",
		loginUserId: "0",
		plantIds: "",
		affiateIds: "",
	});
	const {
		roleMappingRoleDropdownList,
		roleMappingAffiliateDropdownList,
		roleMappingPlantDropdownList,
		loadingAffiliateListDropdown,
		loadingPlantListDropdown,
		roleUpdateMappingStatus,
	} = useSelector((state: any) => ({
		roleMappingRoleDropdownList: state.Common.roleListDropdown,
		roleMappingAffiliateDropdownList: state.Common.affiliateListDropdown,
		roleMappingPlantDropdownList: state.Common.plantListDropdown,
		loadingAffiliateListDropdown: state.Common.loadingAffiliateListDropdown,
		loadingPlantListDropdown: state.Common.loadingPlantListDropdown,

		roleUpdateMappingStatus: state.Common.roleUpdateMappingStatus,
	}));

	useEffect(() => {
		if (roleUpdateMappingStatus.length > 0) {
			if (!roleUpdateMappingStatus.hasOwnProperty("Succeeded")) {
				if (roleUpdateMappingStatus[0].retVal === 1) {
					PushNotification("success", roleUpdateMappingStatus[0].retMsg);
				} else {
					PushNotification("error", roleUpdateMappingStatus[0].retMsg);
				}
			} else {
				PushNotification("error", roleUpdateMappingStatus.Message);
			}
			const emptyObj = [];
			dispatch(updateRoleMappingStatus(emptyObj));
		}
	}, [roleUpdateMappingStatus]);

	const columns = [
		{
			title: "NAME",
			dataIndex: "name",
			key: "name",
		},
		{
			title: "ROLE",
			dataIndex: "roleMasterName",
			key: "roleMasterName",
		},
		{
			title: "MAPPING",
			dataIndex: "mappingType",
			key: "mappingType",
		},
		{
			title: "AFFILIATE",
			dataIndex: "affiliate",
			key: "affiliate",
		},
		{
			title: "PLANT",
			dataIndex: "plant",
			key: "plant",
		},
		{
			title: "EDIT",
			key: "edit",
			dataIndex: "key",
			render: (text, record) => (
				<Button className="cus-button" onClick={() => userRoleEditAction(record)}>{"Edit"}</Button>
			),
		},
	];

	const userRoleEditAction = (record: any) => {
		setSelectedAffiliate([]);
		setSelectedPlant([]);
		dispatch(
			getRoleMappingPlantDropdownList(
				encryptRSAData(`affiliateId=${record.affilliateId}`)
			)
		);
		let affID = record.affilliateId.split(",");
		let aff = record.affiliate.split(",");
		let plantID = record.plantId.split(",");
		let plants = record.plant.split(",");
		let affiliateData = affID.map((id, index) => {
			return {
				value: parseInt(id),
				label: aff[index],
			};
		});
		let plantData = plantID.map((id, index) => {
			return {
				value: parseInt(id),
				label: plants[index],
			};
		});

		setMappingData((data) => ({
			...data,
			affiateIds: record.affilliateId,
			plantIds: record.plantId,
			mappingType: record.mappingType,
		}));
		setMappingData((data) => ({
			...data,
			userId: record.userId,
			userName: record.name,
			email: record.email,
			roleMasterId: record.roleId,
		}));
		setSelectedAffiliate(affiliateData);
		setSelectedPlant(plantData);
		setSelectVal({
			value: record.roleId,
			label: record.roleMasterName,
		});
		if (record.mappingType === "plant") {
			setCheckPlant(true);
		} else {
			setCheckPlant(false);
		}
		setIsModalOpen(true);
		// setMappingData(record);
	};

	const showModal = () => {
		setIsModalOpen(true);
	};

	const dataValidation = () => {
        if (mappingData.roleMasterId === 2 || mappingData.roleMasterId === 3) {
            if (mappingData.mappingType === "") {
                PushNotification("error", "Select the Mapping Type");
                return false;
            }
            else if (mappingData.mappingType === "affiliate" && mappingData.affiateIds === "") {
                PushNotification("error", "Select atleast One Affiliate");
                return false;
            }
            else if (mappingData.mappingType === "plant" && (mappingData.affiateIds === "" || mappingData.plantIds === "")) {
                PushNotification("error", "Select atleast One Affiliate and One Plant");
                return false;
            }
            else {
                return true;
            }
        } else {
            return true;
        }
    }
    const saveUpdateUserRoleMap = () => {
        if (dataValidation()) {
            setIsModalOpen(false);
            setLoading(true);
            dispatch(updateRoleMapping(mappingData));
            dispatch(getRoleMappingWorklist(""));
        } 
    };

	const handleCancel = () => {
		setIsModalOpen(false);
	};

	const handleAffiliateDropDown = (e: any) => {
		let value = e.map((item: any, index: any) => item.value);
		let affiliateIds = value.toString();
		let affId = value[value.length - 1];
		setMappingData((data) => ({ ...data, affiateIds: affiliateIds }));
		let value2 = e.map((item: any, index: any) => ({
			...item,
			item: item.value,
		}));
		setSelectedAffiliate(value2);
		dispatch(
			getRoleMappingPlantDropdownList(
				encryptRSAData(`affiliateId=${affiliateIds}`)
			)
		);
	};

	const handlePlantDropDown = (e: any) => {
		let value = e.map((item: any, index: any) => item.value);
		let plantIds = value.toString();
		setMappingData((data) => ({ ...data, plantIds: plantIds }));
		let value2 = e.map((item: any, index: any) => ({
			...item,
			item: item.value,
		}));
		setSelectedPlant(value2);
	};

	const handleRoleDropDown = (e: any) => {
		setMappingData((data) => ({ ...data, roleMasterId: e.value }));
		setSelectVal({
			value: e.value,
			label: e.label,
		});
		// setSelectedRole(e);
		if (e.value === 1) {
			setMapping(true);
		} else {
			setMapping(false);
		}
		setSelectedAffiliate([]);
		setMappingData((data) => ({
			...data,
			mappingType: "",
			plantIds: "",
			affiateIds: "",
		}));
		setSelectedPlant([]);
		setCheckPlant(false);
		// alert('role'+selectedRole.label)
	};

	const handlePlantRadio = (e: any) => {
		const target = e.target;
		setMappingData((data) => ({ ...data, mappingType: target.value }));
		if (target.checked && target.value == "2") {
			setCheckPlant(true);
			setMappingData((data) => ({ ...data, mappingType: "plant" }));
		} else {
			setCheckPlant(false);
			setMappingData((data) => ({
				...data,
				plantIds: "",
				mappingType: "affiliate",
			}));
		}
	};

	return (
		<div>
			{loading ? <Loader /> : null}
			<Table
				columns={columns}
				dataSource={worklist}
				pagination={{ pageSize: 10, showSizeChanger: false }}
				scroll={{ x: true }}
			/>
			<Modal
				title="Edit User Role Mapping"
				open={isModalOpen}
				onOk={saveUpdateUserRoleMap}
				onCancel={handleCancel}
			>
				<div className="pop-title">{mappingData.userName}</div>
				<div className="pop-role">
					<span className="cus-label">Role</span>
					<Dropdown
						name={"RoleID"}
						options={roleMappingRoleDropdownList}
						handleChange={handleRoleDropDown}
						value={selectVal}
						defaultValue={selectVal}
					/>
				</div>
				{selectVal.value !== 1 ? (
					<div className="pop-mapping-box">
						<div className="pop-mapping">
							<span className="cus-label">Mapping Type</span>
							<label className="cus-label"><input
								type="radio"
								name="mapping"
								value="1"
								onChange={handlePlantRadio}
								checked={mappingData.mappingType === "affiliate"}
								disabled={mapping}
							/>
							Affiliate</label>
							<label className="cus-label"><input
								type="radio"
								name="mapping"
								value="2"
								onChange={handlePlantRadio}
								checked={mappingData.mappingType === "plant"}
								disabled={mapping}
							/>
							Plant</label>
						</div>
						<DropdownMultiselect
							name={"AffiliateID"}
							options={roleMappingAffiliateDropdownList}
							handleChange={handleAffiliateDropDown}
							defaultValue={""}
							value={selectedAffiliate}
							loading={loadingAffiliateListDropdown}
						/>
						{checkPlant ? (
							<DropdownMultiselect
								name={"PlantID"}
								options={roleMappingPlantDropdownList}
								handleChange={handlePlantDropDown}
								defaultValue={""}
								value={selectedPlant}
								loading={loadingPlantListDropdown}
							/>
						) : (
							""
						)}
					</div>
				) : (
					""
				)}
			</Modal>
		</div>
	);
};
export default UserRoleMappingTable;
