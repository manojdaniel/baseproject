declare module "app2/homeApp"
declare module "enzyme"

/* Add a declartion here while consuming a child MFE app */
