/*
 * Created on Wed Oct 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect } from "react"
import { IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import store, { persistor } from "./redux/store/store"
import { PersistGate } from "redux-persist/integration/react"
import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import { IWebCallTrigger } from "./redux/interfaces/types"
import WebCallTrigger from "./components/call-trigger/WebCallTrigger"
import { setupLogger } from "@rocc/rocc-logging-module"
import { isDev } from "./common/helpers/helpers"

const WebCallFeature = (props: IWebCallTrigger) => {
    const httpClient = useRoccHttpClient()
    useEffect(() => {
        setupAxiosHandler(httpClient)
        setupLogger({ isDev: isDev() })
    }, [])

    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                <HttpClientProvider client={httpClient}>
                    <IntlProvider
                        defaultLocale={"en-US"}
                        locale={"en"}
                    >
                        <>
                            <WebCallTrigger {...props} />
                        </>
                    </IntlProvider>
                </HttpClientProvider>
            </PersistGate>
        </Provider>
    </>
}

export default WebCallFeature
