/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import App from "./App"
import { shallow } from "enzyme"
import globalStore from "./redux/store/globalStore"
import { mockCongifData } from "./mocks/commonMocks"

jest.mock("./redux/store/globalStore", () => ({ GetGlobalState: jest.fn() }))
jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: jest.fn(),
}))
jest.mock("./redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        configs: { ROCC_DEV: "true" }
    })
}))
describe("App Component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
    })

    it("App Component should render PersistGate component", () => {
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(mockCongifData)
        wrapper = shallow(<App />)
        expect(wrapper.find("PersistGate")).toHaveLength(1)
    })
})
