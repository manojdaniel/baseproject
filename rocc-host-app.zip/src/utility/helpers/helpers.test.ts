/*
 * Created on Mon Aug 09 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, EConnectionType, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { LOCALHOST, ONBOARDING_STEPS, RAD_CONNECT_TECH_APP_REMOTE_ENTRY } from "../../constants/constants"
import {
    fetchConsultRoutes, fetchDemoVideoUrl, fetchRenderPage, filterCurrentUserFromContacts, getApplicationName, getAppReducerData, getConFigs, getCurrentUserData, getFullApplicationName,
    getLandingPageRoute, getPreSignedUrls, getReduxState, getSingleKeyListFromList, getSteps, getUrls, hideNotificationModal, isAnyOfEmeraldEnabled, isDemoEnv, isDev, isEmptyObject, isExpert,
    loginErrorMessages, openLiveWindow, populateSiteContactsForLocation
} from "./helpers"
import { CONSULTS_ROUTE } from "../../constants/routes"
import en from "../../resources/locales/en_US.json"
import { EUserPresence } from "../../types/types"
import { sendActiveConsoleEndLog } from "./helpers"
import * as  loggsendLogsToAzure from "@rocc/rocc-logging-module"
import { getUserAccessToken } from "../../services/authentication/AuthenticationService"

const mockDispatch = jest.fn()

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {
                id: "1", uuid: "1", clinicalRole: "Expert user", onBoarded: true, allRoles: ["Expert user", EClinicalRole.TECHNOLOGIST, EClinicalRole.RADIOLOGIST], accessToken: "token"
            }
        },
        appReducer: {
            nfccUpgradeAvailable: true, fseData: {}
        },
        featureFlagsReducer: {
            featureFlags: {
                [ROCC_FEATURES.FLAG_RADCONNECT]: "true"
            }
        },
        configReducer: {
            configs: {
                ROCC_DEV: true,
                DEMO_ENV: false,
                DEMO_CONSOLE_VIDEOS: {
                    SIEMENS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
                    GE_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
                    PHILIPS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
                    SIEMENS_MR_EDITCONSOLE_DEMO_ENV_VIDEO: "",
                    GE_MR_EDITCONSOLE_DEMO_ENV_VIDEO: "",
                    PHILIPS_MR_EDITCONSOLE_DEMO_ENV_VIDEO: ""
                }
            },
            urls: {},
            preSignedUrls: {}
        }
    })
}))

jest.mock("react-redux", () => ({
    useDispatch: () => mockDispatch
}))

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_CONSOLE: {
            consoleReducer: {
                consoleSessions: [{
                    roomUuid: "123",
                    connectionType: "PROTOCOL_MANAGEMENT",
                }]
            }
        }
    }),
    CreateStore: jest.fn(),
}))

describe("Unit tests for Helpers utility", () => {

    let windowSpy: any

    beforeEach(() => {
        windowSpy = jest.spyOn(window, "window", "get")
    })

    afterEach(() => {
        windowSpy.mockRestore()
    })

    it("should populate site contacts for location", () => {
        const siteContacts = [
            "contact-id::contact-name:9123456789:front-desk"
        ]
        const location = {
            locationContacts: []
        } as any
        const expectedLocation = {
            locationContacts: [{
                id: "fdcontact-id",
                name: "contact-name",
                phoneNumber: "9123456789",
                clinicalRole: "Frontdesk"
            }]
        }
        populateSiteContactsForLocation(siteContacts, location)
        expect(location).toEqual(expectedLocation)
    })

    it("should get application name", () => {
        expect(getApplicationName()).toEqual(en["content.applicationName"])
    })

    it("should get full application name", () => {
        const expectedResult = `${en["content.companyName"] + " " + en["content.applicationName"]}`
        expect(getFullApplicationName()).toEqual(expectedResult)
    })

    it("should render the steps", () => {
        expect(getSteps(ONBOARDING_STEPS.WELCOME)).toEqual(en["content.eu.welcome"])
        expect(getSteps(ONBOARDING_STEPS.AGREEMENT)).toEqual(en["content.terms.title"])
        expect(getSteps(ONBOARDING_STEPS.COMPLETE)).toEqual(en["content.eu.complete"])
        expect(getSteps("")).toEqual("")
    })

    it("should render login error messages for WRONG_USER_CREDENTIALS", () => {
        expect(loginErrorMessages("WRONG_USER_CREDENTIALS")).toEqual(en["content.displayErrorMessages.wrongUserCredentials"])
    })

    it("should true for empty object", () => {
        expect(isEmptyObject({})).toBeTruthy()
    })

    it("should false for empty object", () => {
        expect(isEmptyObject({ "test": 1 })).toBeFalsy()
    })

    it("should false for empty object", () => {
        const obj: any = [{ "test": 1 }]
        expect(getSingleKeyListFromList(obj, "test")).toBeTruthy()
    })

    it("should render filtered contacts", () => {
        const contacts = [{
            id: "1",
            uuid: "94734795-6b92-4fcd-bb6a-96f7d634fd6e",
            orgId: "1",
            status: EUserPresence.OFFLINE,
            name: "Don Bosco",
            phoneNumber: "+91 96636-02455",
            clinicalRole: EClinicalRole.EXPERTUSER,
            email: "carloancelotti@mailinator.com",
            presenceMapId: "MP129653c0c889495abe3e00b0ffda1cb6",
            roomName: "",
            secondaryName: "",
            secondaryUUID: "",
            siteId: ["3"],
            allRoles: [EClinicalRole.EXPERTUSER],
            modalities: ["MR"],
            description: ""
        }]
        const currentUser = {
            accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
            orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "94734795-6b92-4fcd-bb6a-96f7d634fd6e",
            clinicalRole: EClinicalRole.EXPERTUSER, secondaryUUID: "", secondaryName: "", description: "",

        }
        expect(filterCurrentUserFromContacts(contacts, currentUser)).toEqual([])
    })
    it("should test if user is Expert user", () => {
        const currentUser = {
            accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
            orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "94734795-6b92-4fcd-bb6a-96f7d634fd6e",
            clinicalRole: EClinicalRole.EXPERTUSER, secondaryUUID: "", secondaryName: "", description: "",

        }
        expect(isExpert(currentUser)).toBeFalsy()
    })
    it("should render login error messages for DEFAULT_MESSAGE", () => {
        expect(loginErrorMessages("DEFAULT_MESSAGE")).toEqual(en["content.displayErrorMessages.defaultMessage"])
    })
    it("should render login error messages for NETWORK_CONNECTIVITY", () => {
        expect(loginErrorMessages("NETWORK_CONNECTIVITY")).toEqual(en["content.displayErrorMessages.networkConnectivity"])
    })
    it("should render login error messages for empty string", () => {
        expect(loginErrorMessages("OTHER")).toEqual("")
    })
    it("should check for development environment", () => {
        expect(isDev()).toBeDefined()
    })
    it("should get redux state", () => {
        expect(getReduxState()).toBeDefined()
    })
    it("should get landing page route", () => {
        const currentUser = {
            accessToken: "token", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
            orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "94734795-6b92-4fcd-bb6a-96f7d634fd6e",
            clinicalRole: EClinicalRole.DEFAULT, secondaryUUID: "", secondaryName: "", description: "",
        }
        const fseData = {
            isFse: true,
            customerName: "customer",
            customerOrgId: ""
        }
        getLandingPageRoute(currentUser, fseData, [], [], mockDispatch, { state: { referer: "route" } })
        expect(mockDispatch).toHaveBeenCalled()
    })
    it("should check for demo environment", () => {
        expect(isDemoEnv()).toBeDefined()
    })

    it("should get demo env config [default][view]", () => {
        expect(fetchDemoVideoUrl("abPhilipscd", EConnectionType.VIEW)).toBeDefined()
    })
    it("should get demo env config [siemens][view]", () => {
        expect(fetchDemoVideoUrl("abSiemenscd", EConnectionType.VIEW)).toBeDefined()
    })
    it("should get demo env config [ge][view]", () => {
        expect(fetchDemoVideoUrl("abGEcd", EConnectionType.VIEW)).toBeDefined()
    })
    it("should get demo env config [default][full_control]", () => {
        expect(fetchDemoVideoUrl("abPhilipscd", EConnectionType.FULL_CONTROL)).toBeDefined()
    })
    it("should get demo env config [siemens][full_control]", () => {
        expect(fetchDemoVideoUrl("abSiemenscd", EConnectionType.FULL_CONTROL)).toBeDefined()
    })
    it("should get demo env config [ge][full_control]", () => {
        expect(fetchDemoVideoUrl("abGEcd", EConnectionType.FULL_CONTROL)).toBeDefined()
    })
    it("should check if any emerald flag is enabled", () => {
        const permissions = {
            CONSOLE_VIEW: true
        }
        expect(isAnyOfEmeraldEnabled(permissions)).toBeTruthy()
    })
    it("should dispatch hide notification modal action", () => {
        hideNotificationModal(mockDispatch)
        expect(mockDispatch).toHaveBeenCalledWith({
            type: expect.anything(),
            payload: {
                notificationModal: {
                    showModal: false
                }
            }
        })
    })
    it("should get current user data", () => {
        expect(getCurrentUserData()).toBeDefined()
    })
    it("should get app reducer data", () => {
        expect(getAppReducerData()).toBeDefined()
    })
    it("should get config data", () => {
        expect(getConFigs()).toBeDefined()
    })
    it("should all urls", () => {
        expect(getUrls()).toBeDefined()
    })
    it("should get preosigned urls", () => {
        expect(getPreSignedUrls()).toBeDefined()
    })

    it("should able to fetch Render page", () => {
        expect(fetchRenderPage()).toBe(CONSULTS_ROUTE)
    })

    it("should fetch consult route", () => {
        expect(fetchConsultRoutes()?.url).toBe(RAD_CONNECT_TECH_APP_REMOTE_ENTRY)
    })

    it("should call sendLogsToAzure function", () => {
        const spy = jest.spyOn(loggsendLogsToAzure, 'sendLogsToAzure').mockReturnValue()
        sendActiveConsoleEndLog()
        expect(spy).toBeCalled()
    })

    it("should cover loginError:REQUEST_PROCESSING_FAILED", () => {
        expect(loginErrorMessages("REQUEST_PROCESSING_FAILED")).toEqual(en["content.displayErrorMessages.requestProcessignFailed"])
    })

    it("should return access token", () => {
        expect(getUserAccessToken()).toBe("token")
    })

    it('should invoke openLiveWindow', () => {
        windowSpy.mockImplementation(() => ({
            location: {
                hostname: LOCALHOST
            },
            open: jest.fn().mockReturnValueOnce(null)
        }))
        openLiveWindow("example.com")
        expect(window.location.hostname).toEqual(LOCALHOST)
    })

})
