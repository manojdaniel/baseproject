/*
 * Created on Thu Oct 29 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { withRouter } from "react-router"
import { fetchDemoVideoUrl } from "../../utility/helpers/helpers"
import styles from "./DemoEnvConsoleVideo.scss"

const DemoEnvConsoleVideo = (props: any) => {
    const { match } = props
    const roomName = match && match.params && match.params.roomName
    const connectionType = match && match.params && match.params.connectionType
    const demoVideoUrl = fetchDemoVideoUrl(roomName, connectionType)
    return (
        <div className={styles.videoContainer} id="videoContainer">
            <video controls={true} muted={true} autoPlay>
                <source src={demoVideoUrl} type="video/mp4" />
            </video>
        </div>

    )
}
export default withRouter(DemoEnvConsoleVideo)
