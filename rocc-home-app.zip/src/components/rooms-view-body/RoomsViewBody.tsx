/*
 * Created on Tue Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getIntlProvider } from "@rocc/rocc-global-components"
import { StarredRooms, StarRoom } from "@rocc/rocc-rooms-components"
import cx from "classnames"
import React, { SyntheticEvent, useState } from "react"
import { useSelector } from "react-redux"
import { Accordion, Container, Icon } from "semantic-ui-react"
import { IRoomCard, IRoomsViewBody } from "../../lib/types"
import { IStore } from "../../redux/interfaces/types"
import en from "../../resources/translations/en-US"
import RoomCardComponent from "../room-card-component/RoomCardComponent"
import styles from "./RoomsViewBody.module.scss"

const { intl } = getIntlProvider()
export const RoomsViewBody = ({ starredRoomsList, otherRoomsList, allRoomsList }: IRoomsViewBody) => {
    const [activeIndexes, setActiveIndexes] = useState([0, 1])
    const handleAccordionClick = (_EVENT: SyntheticEvent, titleProps: any) => {
        const { index } = titleProps
        const newIndexes = [...activeIndexes]
        const currentIndexPosition = activeIndexes.indexOf(index)
        currentIndexPosition > -1 ? newIndexes.splice(currentIndexPosition, 1) : newIndexes.push(index)
        setActiveIndexes(newIndexes)
    }
    const {
        permissions
    } = useSelector((state: IStore) => ({
        permissions: state.externalReducer.permissions
    }))

    const hasStarRoomPermission = !!permissions.RESOURCE_STARRED_ROOMS

    const renderStarredAndUnstarredRooms = () => {
        return (
            <>
                <div id="roomsViewBody" className={styles.roomViewBodyWrapper}>
                    <Accordion defaultActiveIndex={0} onAccordionChange={handleAccordionClick}>
                        <Accordion.Title
                            index={0}
                            active={activeIndexes.includes(0)}
                            onClick={handleAccordionClick}
                            className={cx(styles.accordionTitle)}>
                            <Icon name="dropdown" className={cx(styles.accordionIcon)} />
                            <span className={styles.text}>
                                {intl.formatMessage({ id: "content.room.starredRooms", defaultMessage: en["content.room.starredRooms"] })}
                            </span>
                        </Accordion.Title>
                        <Accordion.Content className={styles.accordionContent}>
                            {activeIndexes.includes(0) ?
                                starredRoomsList.length > 0 ? starredRoomsList.map((room) => <RoomCardComponent key={room.roomIdentity.uuid} {...room} />) :
                                    <StarRoom /> : ""}
                        </Accordion.Content>

                        <Accordion.Title
                            active={activeIndexes.includes(1)}
                            onClick={handleAccordionClick}
                            index={1}
                            className={cx(styles.accordionTitle, styles.otherRooms)}>
                            <Icon name="dropdown" className={cx(styles.accordionIcon)} />
                            <span className={styles.text}>
                                {intl.formatMessage({ id: "content.room.otherRooms", defaultMessage: en["content.room.otherRooms"] })}
                            </span>
                        </Accordion.Title>
                        <Accordion.Content className={styles.accordionContent}>
                            {activeIndexes.includes(1) ?
                                otherRoomsList.length > 0 ? otherRoomsList.map((room) => <RoomCardComponent key={room.roomIdentity.uuid} {...room} />) :
                                    (starredRoomsList.length > 0 ? <StarredRooms /> :
                                        <Container className={styles.noOtherRooms}>
                                            {intl.formatMessage({ id: "content.room.noOtherRooms", defaultMessage: en["content.room.noOtherRooms"] })}
                                        </Container>)
                                : ""}
                        </Accordion.Content>
                    </Accordion>
                </div>
            </>)
    }

    const updateStarRoomFeature = () => {
        const updatedRoomList: IRoomCard[] = []
        allRoomsList.forEach(room => {
            room.flags.isStarredFlagEnabled = false
            updatedRoomList.push(room)
        })
        return updatedRoomList
    }

    const renderAllRooms = () => {
        return (
            <div id="displayAllRooms" className={styles.roomViewBodyWrapper}>
                <div className={styles.accordionContent}>
                    {updateStarRoomFeature().map((room) => <RoomCardComponent key={room.roomIdentity.uuid} {...room} />)}
                </div>
            </div>
        )
    }

    return (
        hasStarRoomPermission ? renderStarredAndUnstarredRooms() : renderAllRooms()
    )
}
