/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import FormInvoker from "../form-invoker/FormInvoker"
import { graphqlClient, OnBoardingServices, EROCC_CONTEXT, IUserInfo, IParentStore } from "@rocc/rocc-client-services"
import styles from "./FormController.scss"
import { parseIntBase10 } from "../../../utility/math/mathUtility"
import { updateOnBoardingStatus } from "../../../redux/actions/userAction"
import { getSteps } from "../../../utility/helpers/helpers"
import { LANGUAGES, ONBOARDING_STEPS } from "../../../constants/constants"
import { roccHttpClient } from "../../../utility/api/apiUtility"


const FormController = () => {
    const [init, setInit] = useState(false)
    const [consentData, setConsentData] = useState("")
    const { WELCOME, AGREEMENT, COMPLETE } = ONBOARDING_STEPS
    const {
        currentUser,
        preferredLocale,
        urls } = useSelector((state: IParentStore) => ({
            currentUser: state.userReducer.currentUser,
            preferredLocale: state.configReducer.configData.preferredLocale,
            urls: state.configReducer.urls
        }))

    const dispatch = useDispatch()

    useEffect(() => {
        const fetchTermsOfService = async () => {
            const data = await OnBoardingServices.getTermsAndConditionsService(Number(currentUser.orgId), preferredLocale)
            if (data) {
                setConsentData(data)
            }
            setInit(true)
        }
        if (!init) { fetchTermsOfService() }
    }, [])

    const steps = [
        {
            key: 0,
            title: getSteps(WELCOME),
            required: true
        },
        {
            key: 1,
            title: getSteps(AGREEMENT),
            required: preferredLocale !== LANGUAGES.GERMAN.LOCALE
        },
        {
            key: preferredLocale !== LANGUAGES.GERMAN.LOCALE ? 2 : 1,
            title: getSteps(COMPLETE),
            required: true
        },
    ]

    const setupCommunicationProfileForUser = async (currentUser: IUserInfo, twillioServerUrl: string) => {
        const { accessToken, uuid, orgId } = currentUser
        const response = await OnBoardingServices.createCommunicationProfileService(parseIntBase10(orgId), uuid, accessToken, twillioServerUrl, roccHttpClient)
        return response
    }

    const postSubmitActions = async () => {
        const { uuid } = currentUser
        let retry = 0
        while (retry <= 1) {
            const status = await setupCommunicationProfileForUser(currentUser, urls.COMMUNICATION_SERVICES_URL)
            if (uuid && status) {
                return await callSetOnboardingFlagForUserService(uuid)
            }
            retry++
        }
        return false
    }

    const callSetOnboardingFlagForUserService = async (uuid: string) => {
        let retry = 0
        while (retry <= 1) {
            const onboardingStatus = await OnBoardingServices.setOnboardingFlagForUserService(currentUser, EROCC_CONTEXT.DESKTOP, urls.MANAGEMENT_SERVICE_URL, roccHttpClient)
            if (onboardingStatus) {
                return updateOnboardingStatusInRedux(uuid)
            }
            retry++
        }
        return false
    }

    const updateOnboardingStatusInRedux = (uuid: string) => {
        dispatch(updateOnBoardingStatus(true, uuid))
        graphqlClient.cache.reset()
        return true
    }

    const fetchSteps = () => {
        return steps.filter((step: any) => step.required)
    }

    return <div id={"OnboardingFormController"} className={styles.onboardingFormController}>
        <FormInvoker
            isEulaRequired={preferredLocale !== LANGUAGES.GERMAN.LOCALE}
            steps={fetchSteps()}
            postSubmitActions={postSubmitActions}
            consentData={consentData}
        />
    </div>
}

export default FormController
