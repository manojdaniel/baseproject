/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { mount } from "enzyme"
import SyncExternalRedux from "./SyncExternalRedux"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            userReducer: {
                currentUser: {},
                forceCleanUp: false,
            },
            customerReducer: {
                rooms: [],
                permissions: {},
            },
            appReducer: {
                sideBar: {}
            },
            modalReducer: {
                notificationMessage: {}
            },
            featureFlagsReducer: {
                featureFlags: {}
            },
            workflowReducer: {
                workflows: []
            },
            clientStatusReducer: {
                applicationConnectionState: "ONLINE",
            }
        }
    }),
    DispatchAction: jest.fn(),
    SubscribeToPartnerState: jest.fn(),
    GetPartnerState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {}
        },
        customerReducer: {
            rooms: []
        }
    }),
}))

jest.mock("../../../redux/store/store", () => ({
    dispatch: jest.fn(),
}))

describe("SyncExternalRedux tests", () => {
    it("should render the fragment", () => {
        const wrapper = mount(<SyncExternalRedux />)
        expect(wrapper.find("Fragment")).toBeDefined()
    })
})
