/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ILoginWrapper, LoginTransitionPage, UserNamePasswordLogin } from "@rocc/rocc-authentication-components"
import { EAppContext, EAppStates, EConnectionStatus, EFetchStatus, EIdlePermissionState, EResponse, FeatureFlagHelper, IGraphqlClient, IParentStore, ROCC_FEATURES, setupOrGetGraphqlClient } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger, warningLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useHistory, useLocation } from "react-router"
import { HASH_JWT, HASH_REDIRECT, HTTP_STATUS, UNLOAD } from "../../constants/constants"
import { FORGOT_PD_ROUTE } from "../../constants/routes"
import { captureLoadTimes, setIdlePermissionState, updateAppContext } from "../../redux/actions/appActions"
import { LOGIN_SUCCESS, } from "../../redux/actions/types"
import { getCurrentUserInfo, updateAppState } from "../../redux/actions/userAction"
import { loginHandler, } from "../../services/authentication/AuthenticationService"
import { ELoadTimes, } from "../../types/types"
import { getApplicationName, getLandingPageRoute, } from "../../utility/helpers/helpers"
import queryString from "query-string"
import { iamAuthLoginHandler } from "../../services/authentication/hsdp-iam/iamAuthServices"
import { EAuthState, ROCC_IAM_EVENTS } from "../../services/authentication/hsdp-iam/iamAuthTypes"
import { presenceAvailable } from "../../common/presence/presenceService"

const { INIT, SUCCESS } = EResponse

const LoginComponent = () => {

    const { appState, currentUser, userState, fseData, urls, authConfigs, orgInfraUuid, loginMessage, featureFlags, chatClientStatus, forceCleanUp, locationFetched, contactsFetched, appContext, idlePermissionState } = useSelector((state: IParentStore) => ({
        appState: state.userReducer.appState,
        currentUser: state.userReducer.currentUser,
        userState: state.userReducer.userState,
        urls: state.configReducer.urls,
        fseData: state.appReducer.fseData,
        orgInfraUuid: state.customerReducer.metaData.orgId,
        loginMessage: state.userReducer.loginMessage,
        featureFlags: state.featureFlagsReducer.featureFlags,
        chatClientStatus: state.clientStatusReducer.chatClientStatus,
        forceCleanUp: state.userReducer.forceCleanUp,
        locationFetched: state.customerReducer.locationFetched,
        contactsFetched: state.userReducer.contactsFetched,
        appContext: state.appReducer.appContext,
        authConfigs: state.appReducer.authConfigs, 
        idlePermissionState: state.appReducer.idlePermissionState
    }))

    const [error, setError] = useState(false)
    const [submitLoading, setSubmitLoading] = useState(false)
    const [errorInfo, setErrorInfo] = useState({ statusCode: HTTP_STATUS.CREATED, message: "" })

    const { SHOW_SERVER_OTP, VALIDATE_SERVER_OTP, GET_SERVER_OTP } = EAuthState
    const dispatch = useDispatch()
    const history = useHistory()
    const location = useLocation()
    let loadTimeoutId: NodeJS.Timeout
    const chatClientReadyTimeout = 30000

    const handleLoginSuccess = async () => {
        if (currentUser && currentUser.uuid) {
            if (![INIT, SUCCESS].includes(userState)) {
                const props: IGraphqlClient = {
                    token: currentUser.accessToken,
                    graphQlUrl: urls.GRAPHQL_API_HSDP_URI,
                    graphQlWSUrl: urls.GRAPHQL_API_HSDP_WS_URI,
                    reInit: true,
                    orgInfraUuid,
                    isServiceAdmin: fseData.isFse
                }
                setupOrGetGraphqlClient(props)
                await Promise.resolve()
                dispatch(getCurrentUserInfo(currentUser.email, currentUser.uuid))
            }
        } else {
            errorLogger(`Issue in AppStates post successfull login. Contact Support`)
            dispatch({ type: LOGIN_SUCCESS, appState: EAppStates.SETUP_FAILED })
        }
    }

    const handleLoginFailure = () => {
        setError(true)
        setErrorInfo({ statusCode: HTTP_STATUS.BAD_REQUEST, message: loginMessage })
    }

    useEffect(() => {
        /* 
        On Login success
        1. Load currentUser details
        a. On success
        - Stop loader
        - Load Home Page
        b. On Failure: 
        > Stop loader
        > Display Appropriate error message
        > Set App status to error
        */
        switch (appState) {
            case EAppStates.SETUP_FAILED:
                break
            case EAppStates.LOGIN_SUCCESS:
                handleLoginSuccess()
                currentUser.onBoarded && computeLoadTime()
                break
            case EAppStates.READY:
                getLandingPageRoute(currentUser, fseData, featureFlags, history, dispatch, location)
                break
            case EAppStates.LOGIN_FAILED:
                handleLoginFailure()
                break
            default:
                break
        }
    }, [appState])

    useEffect(() => {
        const confirmationCode = queryString.parse(window.location.hash)
        const hashItems = Object.keys(confirmationCode)[0]
        let localAppContext = EAppContext.REGULAR
        if (hashItems?.includes(HASH_REDIRECT) && confirmationCode[hashItems]) {
            const hash = confirmationCode[Object.keys(confirmationCode)[1]]
            if (hash) {
                sessionStorage.setItem(HASH_JWT, hash.toString())
                localAppContext = EAppContext.PRE_SIGNED
                infoLogger("Launching Pre-signed url")
                /* TODO: Check if hash needs to be cleaned up from session storage */
            }
        }
        if (appContext !== localAppContext) {
            dispatch(updateAppContext(localAppContext))
        }
    }, [])

    const computeLoadTime = () => {
        if (!loadTimeoutId) {
            loadTimeoutId = setTimeout(() => {
                dispatch(captureLoadTimes(ELoadTimes.HOME_PAGE_LOADED))
                warningLogger(`User login took longer time, Home page was loaded after threshold wait of ${chatClientReadyTimeout} miliseconds`)
            }, chatClientReadyTimeout)
        }
        const chatClientReady = chatClientStatus === EConnectionStatus.ONLINE && contactsFetched
        if (chatClientReady && [EFetchStatus.success, EFetchStatus.failed].includes(locationFetched)) {
            dispatch(captureLoadTimes(ELoadTimes.HOME_PAGE_LOADED))
            if (loadTimeoutId) { clearTimeout(loadTimeoutId) }
        }
        if (forceCleanUp) {
            if (loadTimeoutId) { clearTimeout(loadTimeoutId) }
            dispatch(captureLoadTimes(ELoadTimes.HOME_PAGE_LOADED))
            warningLogger(`There was an issue in User login/refresh hence, Home page was loaded with forceCleanUp`)
        }
    }

    const updateAppStateToInit = () => {
        dispatch(updateAppState(EAppStates.INIT, EResponse.INIT, ""))
    }

    const setErrorMessageEvent = (event: any) => {
        setError(true)
        setSubmitLoading(false)
        dispatch(updateAppState(EAppStates.LOGIN_FAILED, EResponse.ERROR, event.detail))
        setErrorInfo({ statusCode: HTTP_STATUS.BAD_REQUEST, message: event.detail })
    }

    const setLoadingEvent = (event: any) => {
        setSubmitLoading(event.detail)
    }

    useEffect(() => {
        window.addEventListener(UNLOAD, updateAppStateToInit)
        window.addEventListener(ROCC_IAM_EVENTS.SET_ERR_MSG, setErrorMessageEvent)
        window.addEventListener(ROCC_IAM_EVENTS.SET_LOADING, setLoadingEvent)
        return (() => {
            window.removeEventListener(UNLOAD, updateAppStateToInit)
            window.removeEventListener(ROCC_IAM_EVENTS.SET_ERR_MSG, setErrorMessageEvent)
            window.removeEventListener(ROCC_IAM_EVENTS.SET_LOADING, setLoadingEvent)
        })
    }, [])

    const forgotPasswordHanlder = () => {
        window.location.hash = FORGOT_PD_ROUTE
    }


    const handleLoginMethod = async (props: any) => {
        setPermissionForUserState()
        if (authConfigs.appClientId) {
            setSubmitLoading(true)
            updateAppStateToInit()
            setError(false)
            const { loginUserName: username, loginUserKey: password } = props
            /* Using set time out to wait for set state loading,
             since the iamAuthHandler calls external function and setState flow is interupted */
            setTimeout(() => {
                iamAuthLoginHandler({ ...authConfigs, authState: EAuthState.INIT }, { username, password }, dispatch)
            }, 200)
            return true
        }
        else {
            return await loginHandler(props, dispatch)
        }
    }

    /* Idle Detector API supported and the set the value in Redux */
    const setPermissionForUserState = async () => {
        if ("IdleDetector" in window) {
            const state = await (window as any).IdleDetector.requestPermission()
            dispatch(setIdlePermissionState(state))
        }
    }

    useEffect(() => {
        const isAwayPresenceFlagEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_AWAY_PRESENCE_FLAG)
        if (idlePermissionState === EIdlePermissionState.GRANTED && isAwayPresenceFlagEnabled && appState === EAppStates.READY) {
            presenceAvailable(idlePermissionState, dispatch)
        } else if (isAwayPresenceFlagEnabled) {
            infoLogger(`Permission is Denied by userId : ${currentUser.uuid}`)
        }
    }, [featureFlags, appState])

    const requestNewOtp = async () => {
        updateAppStateToInit()
        setError(false)
        iamAuthLoginHandler({ ...authConfigs, authState: GET_SERVER_OTP }, {}, dispatch)
    }

    const submitOtp = async (otp: string, trustDevice: boolean) => {
        setSubmitLoading(true)
        updateAppStateToInit()
        setError(false)
        setTimeout(async () => {
            iamAuthLoginHandler({ ...authConfigs, authState: VALIDATE_SERVER_OTP }, { otp, trustDevice }, dispatch)
        }, 200)
        return 1
    }

    return (
        [EAppStates.LOADING, EAppStates.LOGIN_SUCCESS, EAppStates.FF_SETUP].includes(appState) ?
            <LoginTransitionPage applicationName={getApplicationName()} /> :
            <UserNamePasswordLogin
                loginHandler={(props: ILoginWrapper) => handleLoginMethod(props)}
                otpConfigs={{
                    onOtpSubmit: submitOtp,
                    onRequestOtp: requestNewOtp,
                    showTrustDevice: authConfigs.otpAllowTrustDevice
                }}
                showOtp={[SHOW_SERVER_OTP, VALIDATE_SERVER_OTP, GET_SERVER_OTP].includes(authConfigs.authState)}
                submitLoading={submitLoading}
                forgotPasswordHandler={forgotPasswordHanlder}
                applicationName={getApplicationName()}
                errorState={error}
                errorMessage={errorInfo.message}
            />
    )
}

export default LoginComponent
