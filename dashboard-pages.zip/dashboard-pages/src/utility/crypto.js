

import CryptoJS from 'crypto-js';

export function encryptData(data) {
    const stringifiedData = JSON.stringify(data);
    return CryptoJS.AES.encrypt(stringifiedData, `${process.env.REACT_REDUCER}`).toString();
}
export function decryptData(data) {
    const bytes = CryptoJS.AES.decrypt(data, `${process.env.REACT_REDUCER}`);
    const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
    return JSON.parse(decryptedData);
}

// Declare this key and iv values in declaration
let key = CryptoJS.enc.Utf8.parse('4512631236589784');
let iv = CryptoJS.enc.Utf8.parse('4512631236589784');

// Methods for the encrypt and decrypt Using AES
export const encryptUsingAES256 = (data) => {
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(data)), key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
   
    decryptUsingAES256(encrypted);
    return encrypted;
}

export const decryptUsingAES256 = (decString) => {

    var decrypted = CryptoJS.AES.decrypt(decString, key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
   

    return decrypted.toString(CryptoJS.enc.Utf8)
}