"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest


from src.utility.utility import check_if_array_is_empty, construct_negative_response, get_str_value, generate_random_string, generate_random_string_with_special_character
from tests.mocks.random import string, rand_string, randint, uniform


class ConstructNegativeResponseTestCase(unittest.TestCase):
    def test_negetive_response_contruction(self):
        code, title, error_message, add_info = int(rand_string(
            10, corpus=string.digits)), rand_string(10), rand_string(30), "a_info"
        expected_response = {
            "resourceType": "OperationOutcome",
            "issue": [
                {
                    "severity": "error",
                    "code": code,
                    "details": {
                        "text": error_message,
                        "additionalInformation": add_info
                    }
                }
            ],
            "id": title,
        }

        negative_response = construct_negative_response(
            code=code, title=title, error_message=error_message, additional_info="a_info")

        self.assertEqual(negative_response, expected_response)


class GetStrValueTestCase(unittest.TestCase):
    def test_str_values_all_primitives(self):
        input_int, input_float, input_str = randint(
            0, 100), uniform(0, 100), rand_string(10)

        inputs = [
            str(input_int),
            str(input_float),
            input_str
        ]

        expected_outputs = [
            str(input_int),
            str(int(input_float)),
            input_str
        ]

        outputs = [get_str_value(input) for input in inputs]

        self.assertListEqual(outputs, expected_outputs)


class CheckArrayEmptyOrNotTestCase(unittest.TestCase):
    def test_check_array_empty_or_not(self):
        inputs = [
            [],
            ["test"]
        ]

        expected_outputs = [
            True,
            False
        ]

        outputs = [check_if_array_is_empty(input) for input in inputs]
        self.assertListEqual(outputs, expected_outputs)

class RandomStringTest(unittest.TestCase):
    def test_random(self):
        res = generate_random_string("s", 9)
        self.assertIsNotNone(res, msg="Object is not none")

    def test_random_throw_error(self):
        generate_random_string("s", 9.1)
        self.assertRaises(Exception)


class RandomStringSpecialCharacter(unittest.TestCase):
    def test_random_special_character(self):
        res = generate_random_string_with_special_character("s", 9, ["-"])
        self.assertIsNotNone(res, msg="Object is not none")

    def test_random_special_character_throw_error(self):
        generate_random_string_with_special_character("s", 9.1, ["-"])
        self.assertRaises(Exception)
