import unittest
from unittest.mock import Mock, patch
from src.exceptions.RoccException import RoccException
from src.modules.file_operations.validator import check_if_customer_orgs_are_valid, get_modalities_from_db, validate_dicts, validate_kvm_dict_new_customer, validate_modality_of_employees, validate_resources_of_transmitters, validate_sites_of_resources, get_sites_from_excel, validate_sites_of_employee, validate_sheet_for_blanks, get_sites_from_db, get_resources_from_db, get_resources_from_excel
from src.constants.constants import EMP_DICT, ROOMS_DICT, SITES_DICT


class ValidatorTest(unittest.TestCase):
    def test_check_if_customer_orgs_are_valid(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        self.assertRaises(RoccException, check_if_customer_orgs_are_valid, mock_client, {'A': 'Test', 'B': 'Test'})

    def test_validate_sites_of_resources(self):
        self.assertRaises(RoccException, validate_sites_of_resources, {'A': 'Test', 'B': 'Test'}, {'A': 'Test'}, {'A': 'Test'})

    def test_get_sites_from_excel(self):
        sites = get_sites_from_excel({'A': {'Hospital/DIC Identifier- To be filled by Philips': 'abc'}})
        no_sites = get_sites_from_excel("")
        self.assertIsNone(no_sites)
        self.assertIsNotNone(sites)

    def test_validate_sites_of_employee(self):
        self.assertRaises(RoccException, validate_sites_of_employee, "", "", "")

    def test_validate_sites_of_employee_invalid(self):
        invalid_sites = validate_sites_of_employee({}, {}, {})
        self.assertIsNotNone(invalid_sites)

    def test_validate_sheet_for_blanks(self):
        self.assertRaises(Exception, validate_sheet_for_blanks, {})

    def test_get_sites_from_db(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        sites = get_sites_from_db(mock_client)
        no_sites = get_sites_from_db({})
        self.assertIsNotNone(sites)
        self.assertIsNotNone(no_sites)

    def test_get_resources_from_db(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        resources = get_resources_from_db(mock_client)
        no_resources = get_resources_from_db({})
        self.assertIsNotNone(resources)
        self.assertIsNotNone(no_resources)

    def test_get_resources_from_excel(self):
        resources = get_resources_from_excel({"key": {'Room Identifier (To be filled by Philips)': "value"}})
        no_resources = get_resources_from_excel("")
        self.assertIsNone(no_resources)
        self.assertIsNotNone(resources)

    def test_validate_resources_of_transmitters(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        resources = validate_resources_of_transmitters(
            mock_client, {'A': 'Test', 'B': 'Test'}, {'A': 'Test', 'B': 'Test'})
        self.assertIsNone(resources)

    def test_validate_modality_of_employees(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        self.assertRaises(RoccException, validate_modality_of_employees, mock_client, {
                          'A': 'Test', 'B': 'Test'}, {'A': 'Test', 'B': 'Test'})

    def test_get_modalities_from_db(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        resources = get_modalities_from_db(mock_client)
        self.assertIsNotNone(resources)

    def test_validate_modality_of_employees_success(self):
        validate_modality_of_employees({}, {}, {})
        self.assertIsNotNone("")

    @patch("src.modules.file_operations.validator.get_sites_from_db")
    @patch("src.modules.file_operations.validator.get_sites_from_excel")
    @patch("src.modules.file_operations.validator.validate_sites_of_resources")
    @patch("src.modules.file_operations.validator.fetch_org_db_id_from_identifier")
    def test_validate_modality_of_employees_success_1(self, m_fetch_org_db, m_validate_site_resource, m_get_sites_from_excel, m_get_sites_from_db):
        m_get_sites_from_db.return_value = {}
        m_get_sites_from_excel.return_value = {}
        m_validate_site_resource.return_value = []
        m_fetch_org_db.return_value = False
        validate_dicts({}, {SITES_DICT: {}, ROOMS_DICT: {}, EMP_DICT: {}}, [""], "customer-idn")
        with self.assertRaises(Exception):
            validate_kvm_dict_new_customer({}, False, "customer-idn")
        self.assertIsNotNone("")
