/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const GLOBAL_RIGHTSIDE_PANEL = "GLOBAL_RIGHTSIDE_PANEL"
export const GLOBAL_UPDATE_ROOMS = "GLOBAL_UPDATE_ROOMS"
export const GLOBAL_UPDATE_ACTIVE_LOCATION = "GLOBAL_UPDATE_ACTIVE_LOCATION"
export const GLOBAL_UPDATE_NOTIFICATION_MESSAGE = "GLOBAL_UPDATE_NOTIFICATION_MESSAGE"
export const GLOBAL_UPDATE_CHAT_CLIENT = "GLOBAL_UPDATE_CHAT_CLIENT"
export const SYNC_CONSOLE_STORE = "SYNC_CONSOLE_STORE"
export const SYNC_CALLING_STORE = "SYNC_CALLING_STORE"
export const SYNC_PROTOCOL_TRANSFER_STORE = "SYNC_PROTOCOL_TRANSFER_STORE"
export const SYNC_PARENT_REDUCERS = "SYNC_PARENT_REDUCERS"
