const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

const deps = require("./package.json").dependencies;
module.exports = {

  resolve: {
    extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
  },

  module: {
    rules: [
      {
        test: /\.m?js/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false,
        },
      },
      {
        test: /\.(css|s[ac]ss)$/i,
        use: ["style-loader", "css-loader", "postcss-loader", "sass-loader"],
      },
      {
        test: /\.(png|jp(e*)g|svg|gif)$/,
        exclude: /(node_modules)/,
        use: ["url-loader"],
      },
      {
        test: /\.(ts|tsx|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
        },
      },
    ],
  },

  plugins: [
    new ModuleFederationPlugin({
      name: "table",
      filename: "remoteEntry.js",
      remotes: {},
      exposes: {
        "./AssetCard": "./src/components/PmtComponent/AssetCard/AssetCard.tsx",
        "./PlantAlertList": "./src/components/PmtComponent/PlantAlertList/PlantAlertList.tsx",
        "./LiveModel": "./src/components/Asset/AssetModel/LiveModel.tsx",
        "./LiveTrackingTable": "./src/components/Livetracking/LiveTrackingTable.tsx",
        "./AlertStatusList": "./src/components/PLANTALERTSTATUS/ALERTSTATUS/AlertStatusList.tsx",
        "./ReferenceTable": "./src/components/ReferenceTable/ReferenceTable.tsx",
        "./MonthWiseTable": "./src/components/MonthwiseTable/MonthWise/MonthWiseTable.tsx",
        "./AlertListTable": "./src/components/Asset/AlertList/AlertList.tsx",
        "./MyTaskTable": "./src/components/AlertManagementPage/MyTask/MyTaskTable.tsx",
        "./ReportTable": "./src/components/AlertManagementPage/Report/ReportTable.tsx",
        "./RequestLogTable": "./src/components/AlertManagementPage/Report/RequestLogTable.tsx",
        "./UtilizationReportTable": "./src/components/AlertManagementPage/UtilizationReport/UtilizationReportTable.tsx",
        "./MasterDataReportTable": "./src/components/AlertManagementPage/MasterDataReport/MasterDataReportTable.tsx",
        "./Pmcompliance": "./src/components/PMCompliance/Pmcompliance.tsx",
        "./ActiveTable": "./src/components/Profile/ActiveTable.tsx",
        "./InboxTable": "./src/components/Profile/InboxTable.tsx",
        "./ClosedTable": "./src/components/Profile/ClosedTable.tsx",
        "./PendingTable": "./src/components/Profile/PendingTable.tsx",
        "./InfoTable": "./src/components/InfoTable.tsx",
        "./AffiliateRolloutTable": "./src/components/Admin/AffiliateRolloutTable.tsx",
        "./PlantRolloutTable": "./src/components/Admin/PlantRolloutTable.tsx",
        "./UserRoleMappingTable": "./src/components/Admin/UserRoleMappingTable.tsx",
        "./AssetModelConfigTable": "./src/components/Admin/AssetModelConfigTable",
        "./ExceptionMonitoringTable": "./src/components/Admin/ExceptionMonitoringTable.tsx",
        "./EmployeeTable": "./src/components/Admin/EmployeeTable.tsx",
        "./WorkflowTable": "./src/components/WorkflowTable",
        "./Compressor": "./src/components/SpareParts/SAP/Compressor/Compressor.tsx",
        "./CompressorSensor": "./src/components/SpareParts/SAP/Compressor/CompressorSensor.tsx",
        "./PlantShutdownTable": "./src/components/Admin/PlantShutdownTable.tsx",
      },
      shared: {
        ...deps,
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
      },
    }),
    new HtmlWebPackPlugin({
      template: "./src/index.html",
    }),
  ],
};
