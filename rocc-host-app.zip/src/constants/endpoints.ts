/*
 * Created on Thu Jul 29 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const PHILIPS_API_URI = "/philips/rocc"
/* Generic service API endpoints */
export const GENERIC_SERVICE_API_URI = "/ui/service"
export const UI_SERVICE_API_URI = `${PHILIPS_API_URI}${GENERIC_SERVICE_API_URI}`
export const APP_CONFIG_URI = `${UI_SERVICE_API_URI}/appConfigs`
export const DEFAULT_CONFIG_URI = `${UI_SERVICE_API_URI}/defaultConfigs`
export const SERVER_LOGIN = `${UI_SERVICE_API_URI}/serverlogin`
export const SERVER_LOGOUT = `${GENERIC_SERVICE_API_URI}/serverlogout`
/* Other API endpoints */
export const VALIDATE_TOKEN = "/authorize/validate"
export const LOGIN_ACCESS_URI = "/sessionmgmt/Session/"
export const FORGOT_PWD_EP = "/user/Password/reset"
export const SET_PWD_EP = "/user/Password/set"
export const ACTIVE_USER_PD_EP = "/setpassword"
export const RESET_USER_PD_EP = "/resetpassword"
export const COMMUNICATION_TOKEN_EP = "/Token"
export const COMMUNICATION_PRESENCE_SUBSCRIPTION_EP = "/presence/Subscription"
export const COMMUNICATION_PRESENCE__STATUS_EP = "/presence/PresenceStatus"
export const REGION_CONFIG_URI = "/RegionConfig"
export const TECHNOLOGIST_DESKTOP_APP_URI = "/tech/#/device/activate"
