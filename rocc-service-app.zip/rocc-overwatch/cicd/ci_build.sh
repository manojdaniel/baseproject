#!/bin/bash

set -e
set -x
export no_proxy=artifactory-ehv.ta.philips.com
SEP="====================================="
CICD_FOLDER=cicd
APP_NAME=rocc-cpp

echo "Building $APP_NAME client"

currentDir=$(pwd)

echo "Processing in directory : {$currentDir}"
cd client

echo $SEP
echo "Building client"
echo $SEP
npm install
npm run build
npm run lint
npm run test:coverage

echo $SEP
echo "Copying the client build contents to server"
echo $SEP
cp -r build/* ../server/dist

echo $SEP
echo "Building server"
echo $SEP
cd ../server
npm install
npm run build


echo $SEP
echo "Copying required content to $CICD_FOLDER folder"
echo $SEP
cp -r certificate dist package.json start-server.sh node_modules ../$CICD_FOLDER
