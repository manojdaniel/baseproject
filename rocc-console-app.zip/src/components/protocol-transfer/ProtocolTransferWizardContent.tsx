/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { ReactFragment } from "react"
import { Grid } from "semantic-ui-react"
import styles from "./ProtocolTransfer.scss"
import cx from "classnames"
import DotConnectorComponent from "../../common/modules/dot-connector-component/DotConnectorComponent"
import { EGridWidth } from "../../redux/interfaces/types"

interface IProtocolTransferWizardContent {
    sourceScannerContent: ReactFragment
    destinationScannerContent: ReactFragment
    stepMessageContent?: ReactFragment
    completionStepUI?: ReactFragment
}

const ProtocolTransferWizardContent = (props: IProtocolTransferWizardContent) => {
    return (
        <>
            <Grid padded={"horizontally"} centered={true} id="protocolTransferWizard">
                <Grid.Row>
                    <Grid.Column className={styles.selectionWizardColumn}>
                        <Grid>
                            <Grid.Column className={cx(styles.wizardGridColumn)} width={EGridWidth.FIVE}>
                                {props.sourceScannerContent}
                            </Grid.Column>
                            <Grid.Column className={cx(styles.wizardGridColumn)} width={EGridWidth.TWO}>
                                <DotConnectorComponent />
                            </Grid.Column>
                            <Grid.Column className={cx(styles.wizardGridColumn)} width={EGridWidth.FIVE}>
                                {props.destinationScannerContent}
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row className={cx(styles.wizardGridRow)} >
                    <Grid.Column className={cx(styles.messageContent)}>
                        {props.stepMessageContent}
                    </Grid.Column>
                </Grid.Row>
                {props.completionStepUI}
            </Grid>
        </>
    )
}

export default ProtocolTransferWizardContent
