/*
 * Created on Mon Sept 07 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ECallType, EOutGoingCallStatus, ERoccWorkflow, FeatureFlagHelper, getDetailsByUUID, IAVCallDetails, IContactInfo, IParticipantInfo, IUserInfo, REGISTER_WORKFLOW, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { postService, putService } from "../common/helpers/apiUtility"
import { checkAndAddMissedCallEntry, upsertCallStatus } from "../common/helpers/callUtility"
import { checkToAllowMultiEdit, checkToAllowParkResume, fetchActiveEditSession, getCustomrReducerFromGlobalStore, getTranslatedCallType, getUserReducerFromGlobalStore } from "../common/helpers/helpers"
import { updateCallDetails } from "../common/modules/av/AudioVideoHelper"
import { IEndCallProps, IInitiateVideoCallFunction } from "../common/modules/av/types"
import { outgoingCall } from "../common/modules/avmessages/av-messages/event-handlers/OutgoingCall"
import { ADD_PARTICIPANT, API_VERSION, API_VERSION_110, APPLICATION_JSON, AUTHORIZATION, CALLING, CALLTYPE, CALL_END, CALL_FAILED, CALL_REJECT, CONTENT_TYPE, DEFAULT_API_VERSION, HTTP_STATUS, RINGING, TABID, TELEPRESENCE_SIDEBAR, TIMEOUT_40000, VIDEO_CALL_MEDIATYPE } from "../constants/constants"
import { AV_CALL_EP, COMMUNICATION_TOKEN_EP } from "../constants/endpoints"
import { setCallMessage, setOutgoingCallDetails, setPhoneCallStatus, setVideoCallStatus } from "../redux/actions/callActions"
import { GLOBAL_RIGHTSIDE_PANEL, GLOBAL_SET_INITIATE_WEB_CALL } from "../redux/actions/types"
import { IStore } from "../redux/interfaces/types"
import { DEFAULT_OUTGOING_CALL_DEATILS } from "../redux/reducers/callReducer"
import { dispatchToParentStore, fetchGlobalConfigs, fetchGlobalFeatureFlags, fetchGlobalURLs } from "../redux/store/externalAppStates"
import store from "../redux/store/store"
import en from "../resources/translations/en-US"
import { ECommunicationRoomType } from "../types/types"

interface IInitiateWebCallHandler {
    contactUuid: string
    componentName: string
    dispatch: Dispatch<any>
    modalityName?: string
}

export const initiateWebCallHandler = ({ contactUuid, componentName, dispatch, modalityName }: IInitiateWebCallHandler) => {
    infoLogger(`Initiating a webcall for user ${contactUuid} ${modalityName}`)
    dispatch({
        type: GLOBAL_SET_INITIATE_WEB_CALL, payload: {
            initiateWebCall: { contactUuid, componentName, modalityName }
        }
    })
}

interface IInitiateAVCall {
    contactUuid: string
    dispatch: Dispatch<any>
}

interface IEnableWebCall extends IInitiateAVCall {
    componentName: string
    currentUserUuid: string,
    modalityName: string
}

export const enableWebToWebCallWrapper = (props: IEnableWebCall) => {
    if (checkToAllowMultiEdit()) {
        registerMultiEditInitiateCallWorkflow(props)
    } else if (checkToAllowParkResume()) {
        registerParkAndInitiateCallWorkflow(props)
    } else {
        enableWebToWebCall(props)
    }
}

export const enableWebToWebCall = async (props: IEnableWebCall) => {
    try {

        const { contactUuid, dispatch, componentName, currentUserUuid, modalityName } = props
        sendLogsToAzure({ contextData: { component: componentName, event: "Web to Web Call: Call Initiated", Call_To: contactUuid, Call_From: currentUserUuid, modality: modalityName } })
        infoLogger(`Initiate AV Call between ${currentUserUuid} and ${contactUuid}`)
        return await initiateAVCall({ contactUuid, dispatch })
    } catch (error) {
        errorLogger(`Exception occurred while call initiation: ${errorParser(error)}`)
    }
    return
}

const initiateAVCall = async (props: IInitiateAVCall) => {
    const { contactUuid, dispatch } = props
    const { currentUser, contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    const { intl } = getIntlProvider()
    const urls = fetchGlobalURLs()
    const participant = await getDetailsByUUID(contactUuid, contacts, rooms)
    const requester = {
        primaryUuid: currentUser.uuid,
        secondaryUuid: [currentUser.secondaryUUID],
        callStatus: CALLING,
        userContext: {}
    }
    try {
        const outgoingCallDetails = { participant, contextId: "", requester, callType: ECallType.WEB_TO_WEB, status: EOutGoingCallStatus.CALLING }
        dispatch(setOutgoingCallDetails(outgoingCallDetails))
        const response: any = await prepareVideoCall({
            contactUuid, currentUser, communicationServiceUrl: urls.COMMUNICATION_SERVICES_URL, dispatch,
        })
        if (response && response.status === HTTP_STATUS.OK) {
            outgoingCall({ ...props, contextDetails: response, participant })
            return response.data.contextId
        }
    } catch (err) {
        dispatch(setVideoCallStatus(upsertCallStatus("", ECallStatus.FAILED)))
        dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
        dispatch(setCallMessage({
            messageType: getTranslatedCallType(CALL_FAILED),
            message: intl.formatMessage({ id: "content.callMessage.callFailed", defaultMessage: en["content.callMessage.callFailed"] }), contact: participant
        }))
    }
    return
}

export interface IPrepareVideoCallFunction {
    contactUuid: string
    currentUser: IUserInfo
    dispatch: Dispatch<any>
    communicationServiceUrl: string

}

const prepareVideoCall = async (params: IPrepareVideoCallFunction) => {
    const {
        currentUser, contactUuid, dispatch
    } = params
    infoLogger(`Initiating video call between ${currentUser.uuid} and ${contactUuid}`)
    dispatch(setVideoCallStatus(upsertCallStatus("", ECallStatus.CONNECTING).map(callDetails => {
        if (callDetails.callStatus === ECallStatus.CONNECTED) { callDetails.callStatus = ECallStatus.DISCONNECTED }
        return callDetails
    })))
    dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: TELEPRESENCE_SIDEBAR, displayRightSidePanel: true, desktopFullScreen: false } })
    try {
        const featureFlags = fetchGlobalFeatureFlags()
        const communicationRoomType = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_PP_CALLING_MODE) ? ECommunicationRoomType.PEER_TO_PEER : ECommunicationRoomType.GROUP
        const response = await avCallService({ ...params, mediaType: VIDEO_CALL_MEDIATYPE, communicationRoomType })
        infoLogger(`Call request successfully sent from: ${currentUser.uuid} to ${contactUuid}`)
        return response
    } catch (error) {
        dispatch(setVideoCallStatus(upsertCallStatus("", ECallStatus.FAILED)))
        errorLogger(`Failed to initiate call between : ${currentUser.uuid} and ${contactUuid} with error: ${errorParser(error)}`)
        throw error
    }
}

export const avCallService = (params: IInitiateVideoCallFunction) => {
    const { currentUser, contactUuid, mediaType, communicationServiceUrl, communicationRoomType } = params
    const { COUNTRY_ISO_CODE, REGION } = fetchGlobalConfigs()
    const data: any = {
        callType: CALLTYPE,
        mediaType,
        roomType: communicationRoomType,
        requester: {
            primaryUuid: currentUser.uuid,
            userContext: { sessionTabId: `${currentUser.sessionId}_${sessionStorage.getItem(TABID)}` },
        },
        participant: {
            primaryUuid: contactUuid,
        },
        countryIsoCode: COUNTRY_ISO_CODE,
    }
    if (REGION && REGION !== "undefined") {
        data["region"] = REGION
    }
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        [AUTHORIZATION]: currentUser.accessToken,
        [API_VERSION]: API_VERSION_110,
    }
    const param = {
        url: `${communicationServiceUrl}${AV_CALL_EP}`,
        data,
        headers,
    }
    return postService(param)
}

interface IEnableWebToPhoneCall {
    contactUuid: string
    phoneNumber: string
    dispatch: Dispatch<any>
    componentName: string
    contactInfo?: IContactInfo
}

export const enableBrowserToPhoneCall = async ({ contactUuid, phoneNumber, dispatch, componentName, contactInfo }: IEnableWebToPhoneCall) => {
    const { currentUser, contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    if (contactUuid) {
        const contactInfo1 = await getDetailsByUUID(contactUuid, contacts, rooms)
        const participant: IParticipantInfo = { ...contactInfo1, selectedPhoneNumber: phoneNumber }
        sendLogsToAzure({ contextData: { component: componentName, event: "Web to Phone Call: Call Initiated", Call_To: contactUuid, Call_From: currentUser.uuid } })
        dispatch(setPhoneCallStatus(ECallStatus.CALLING, participant))
    }
    else if (contactInfo) {
        const participantInfo: IParticipantInfo = { ...contactInfo, selectedPhoneNumber: phoneNumber }
        dispatch(setPhoneCallStatus(ECallStatus.CALLING, participantInfo))
    }
    dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: TELEPRESENCE_SIDEBAR, displayRightSidePanel: true, desktopFullScreen: false } })
}

interface IAudioCallService {
    accessToken: string
    currentUserUuid: string
    phoneNumber: string
    communicationServiceUrl: string
}
export const audioCallService = async ({ accessToken, currentUserUuid, phoneNumber, communicationServiceUrl }: IAudioCallService) => {
    const data = {
        phoneNumber, userId: currentUserUuid, tokenType: ECallType.WEB_TO_PHONE
    }
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        [AUTHORIZATION]: accessToken,
        [API_VERSION]: DEFAULT_API_VERSION,
    }
    const params = { url: `${communicationServiceUrl}${COMMUNICATION_TOKEN_EP}`, data, headers }
    let response = { success: false, data: { capabilityToken: "", contextId: "", } }
    try {
        const apiResponse = await postService(params)
        if (apiResponse && apiResponse.status === HTTP_STATUS.OK) {
            response = { success: true, data: apiResponse.data }
        } else {
            errorLogger(`Failed to get token for WebToPhone call: response: ${apiResponse.status}`)
        }
    } catch (error) {
        errorLogger(`Exception occurred while token creation for webToPhone call : ${errorParser(error)}`)
    }
    return response
}

export const endCall = async (props: IEndCallProps) => {
    const { currentUser, communicationServiceUrl, contextId } = props
    const apiParam = {
        callStatus: CALL_END,
        requester: {
            primaryUuid: currentUser.uuid,
        },
    }
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        [AUTHORIZATION]: currentUser.accessToken,
        [API_VERSION]: DEFAULT_API_VERSION,
    }
    const param = {
        url: `${communicationServiceUrl}${AV_CALL_EP}${contextId}`,
        data: apiParam,
        headers,
    }
    putService(param)
}

interface IAddParticipantService {
    contextId: string
    contact: IContactInfo
    currentUser: IUserInfo
    communicationServiceUrl: string
}

export const addParticipantService = async ({ contextId, contact, currentUser, communicationServiceUrl }: IAddParticipantService) => {
    const { uuid, accessToken } = currentUser
    try {
        const apiParam = {
            callStatus: ADD_PARTICIPANT,
            requester: {
                primaryUuid: uuid,
            },
            participantDetails: {
                primaryUuid: contact.uuid,
            },
        }
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
            [AUTHORIZATION]: accessToken,
            [API_VERSION]: DEFAULT_API_VERSION,
        }
        const param = {
            url: `${communicationServiceUrl}${AV_CALL_EP}${contextId}`,
            data: apiParam,
            headers,
        }
        const response = await putService(param)
        if (response.status === HTTP_STATUS.OK) {
            return true
        }
    } catch (error: any) {
        errorLogger(`Exception occurred while adding participant to the call ${contextId}: ${errorParser(error)}`)
    }
    return false
}

export const checkIfParticipantAdded = (contextId: string, currentUser: IUserInfo, communicationUrl: string, uuid: string, dispatch: Dispatch<any>) => {
    try {
        const state: IStore = store.getState()
        const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
        const activeCall = [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
        if (activeCall && activeCall.participants) {
            checkAndAddMissedCallEntry(currentUser, uuid, connectedCallDetails, communicationUrl, contextId)
            activeCall.participants =
                activeCall.participants.filter((participant) =>
                    !(participant.uuid === uuid && [undefined, RINGING, CALL_REJECT].includes(participant.callStatus)))
            updateCallDetails(activeCall, dispatch, true)
        }
    } catch (error) {
        errorLogger(`An error occurred while cancelling a Participant addition to MPC with error: ${errorParser(error)}`)
    }
}

export const addUserToCall = async (activeCall: IAVCallDetails, user: IContactInfo, dispatch: Dispatch<any>) => {
    const state = store.getState()
    const { currentUser } = state.externalReducer
    const { participants, contextId } = activeCall
    const urls = fetchGlobalURLs()

    if (participants.find((participant) => participant.uuid === user.uuid)) {
        return
    }

    setTimeout(() => checkIfParticipantAdded(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL, user.uuid, dispatch), TIMEOUT_40000)
    user.callStatus = RINGING
    activeCall.participants = [...activeCall.participants, user]
    updateCallDetails(activeCall, dispatch, true)
    const serviceResponse = await addParticipantService({
        contextId,
        contact: user,
        currentUser,
        communicationServiceUrl: urls.COMMUNICATION_SERVICES_URL
    })

    if (!serviceResponse) {
        activeCall.participants = activeCall.participants.filter((participant) => participant.uuid !== user.uuid)
        updateCallDetails(activeCall, dispatch, true)
    }
}

interface IRegisterInitiateWorkflow {
    contactUuid: string
    contextId?: string
    modalTimeout?: number
    componentName?: string

}

export const registerMultiEditInitiateCallWorkflow = (props: IRegisterInitiateWorkflow) => {
    const { contactUuid, contextId, modalTimeout, componentName } = props
    const activeSession = fetchActiveEditSession()
    const state = store.getState()
    const { connectedCallDetails } = state.callReducer.callDetails
    const { currentUser } = state.externalReducer
    const context = {
        modalTimeout: modalTimeout || 0,
        prevSessionDetails: {
            callContextId: connectedCallDetails.contextId,
            consoleContextId: activeSession?.contextId || "",
            contactUuid,
        },
        nextSessionDetails: {
            contactUuid, callContextId: contextId || ""
        },
    }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.MULTI_EDIT_INITIATE_CALL, context } })
    sendLogsToAzure({ contextData: { component: componentName, event: "Web to Web Call: Multi Edit Initiate Call", Call_To: contactUuid, Call_From: currentUser.uuid, Hold_Call_Context: connectedCallDetails.contextId } })
}


export const registerParkAndInitiateCallWorkflow = (props: IRegisterInitiateWorkflow) => {
    const { contactUuid, contextId, modalTimeout, componentName } = props
    const activeSession = fetchActiveEditSession()
    const state = store.getState()
    const { connectedCallDetails } = state.callReducer.callDetails
    const { currentUser } = state.externalReducer
    const context = {
        modalTimeout: modalTimeout || 0,
        prevSessionDetails: {
            callContextId: connectedCallDetails.contextId,
            consoleContextId: activeSession?.contextId || "",
            contactUuid,
        },
        nextSessionDetails: {
            contactUuid, callContextId: contextId || ""
        },
    }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.PARK_AND_INITIATE_CALL, context } })
    sendLogsToAzure({ contextData: { component: componentName, event: "Web to Web Call: Park and Initiate Call", Call_To: contactUuid, Call_From: currentUser.uuid, Hold_Call_Context: connectedCallDetails.contextId } })
}

interface IHandleDisconnect {
    contextId: string
    componentName?: string
}

export const registerCallDisconnectWorkflow = (props: IHandleDisconnect) => {
    const { contextId, componentName } = props
    const { currentUser } = store.getState().externalReducer
    const context = { callContextId: contextId }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.DISCONNECT_CALL, context } })
    sendLogsToAzure({ contextData: { componentName, event: "Web to Web Call: Call Disconnected", Event_By: currentUser.uuid } })
}
