/*
 * Created on Tue Sep 28 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useRef, useState } from "react"
import { useDispatch } from "react-redux"
import { Button, Modal } from "semantic-ui-react"
import styles from "./SessionExpiryModal.scss"
import { LOGIN_ROUTE, SESSION_EXPIRED } from "../../constants/routes"
import en from "../../resources/translations/en-US"

import { TRACK } from "../../constants/tracking"
import { trackEvent } from "../../utility/helpers/helpers"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { handleApplicationLogout } from "../navbar/NavBarHelper"

const SessionExpiryModal = ({ resetSessionTimeout }: { resetSessionTimeout: (state: boolean) => void }) => {
    const sessionTimeout = useRef(undefined as any)
    const [modalOpen, setModalOpen] = useState(true)
    const [expiryInit, setExpiryInit] = useState(false)
    const [expiryWarningTime, setExpiryWarningTime] = useState(60)
    const { intl } = getIntlProvider()
    const dispatch = useDispatch()

    useEffect(() => {
        return () => {
            if (sessionTimeout.current) {
                clearTimeout(sessionTimeout.current)
                sessionTimeout.current = undefined
            }
        }
    }, [])

    useEffect(() => {
        if (expiryWarningTime === 0 && !expiryInit) {
            setExpiryInit(true)
            const { component, event: { sessionExpired } } = TRACK.LOGOUT
            trackEvent(component, sessionExpired)
            handleApplicationLogout(dispatch, SESSION_EXPIRED)
            updateModalState(false)
        }
        sessionTimeout.current = setTimeout(() => {
            if (expiryWarningTime > 0) {
                setExpiryWarningTime(expiryWarningTime - 1)
            }
        }, 1000)
    }, [expiryWarningTime])

    const updateModalState = (value: boolean) => {
        if (modalOpen !== value) {
            setModalOpen(false)
        }
    }
    const handleLogout = () => {
        const { component, event: { sessionEndClicked } } = TRACK.LOGOUT
        trackEvent(component, sessionEndClicked)
        handleApplicationLogout(dispatch, LOGIN_ROUTE)
        setModalOpen(false)
    }
    return (
        <div className={styles.sessionExpireWarning} id={"SessionExpiryModal"}>
            <Modal
                open={modalOpen}
                closeOnEscape={false}
                size={"small"}
                className={"sessionExpireWarningModal"}
            >
                <Modal.Header className={"headerTitle"}>
                    {intl.formatMessage({ id: "content.sessionexpire.header", defaultMessage: en["content.sessionexpire.header"] })}
                </Modal.Header>
                <Modal.Content className={"modalContent"}>
                    <p>
                        {`${intl.formatMessage({ id: "content.sessionexpire.messagepart1", defaultMessage: en["content.sessionexpire.messagepart1"] })} ${expiryWarningTime} ${intl.formatMessage({ id: "content.sessionexpire.messagepart2", defaultMessage: en["content.sessionexpire.messagepart2"] })}`}
                        <span className={"modalContentSubtext"}>
                            {intl.formatMessage({ id: "content.sessionexpire.messagepart3", defaultMessage: en["content.sessionexpire.messagepart3"] })}
                        </span>
                    </p>
                </Modal.Content>
                <Modal.Actions>
                    <Button id="endSession" onClick={handleLogout} negative={true} className={"secondaryBtn"}>
                        {intl.formatMessage({ id: "content.sessionexpire.secondaryBtn", defaultMessage: en["content.sessionexpire.secondaryBtn"] })}
                    </Button>
                    <Button
                        id="extendSession"
                        onClick={() => {
                            resetSessionTimeout(false)
                            const { component, event: { sessionExtended } } = TRACK.LOGIN
                            trackEvent(component, sessionExtended)
                        }
                        } primary={true} className={"primaryBtn"}>
                        {intl.formatMessage({ id: "content.sessionexpire.primaryBtn", defaultMessage: en["content.sessionexpire.primaryBtn"] })}
                    </Button>
                </Modal.Actions>
            </Modal>
        </div>
    )
}

export default SessionExpiryModal
