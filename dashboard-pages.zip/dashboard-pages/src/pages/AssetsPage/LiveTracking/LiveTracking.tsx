import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
	getLivetrackingtable,
	getAssetDropdownList,
	getModelDropdownList,
	getModelStatusDropdownList,
	getGlobalSelecetedAsset,
} from "../../../redux/reducers/CommonReducer";
import LiveTrackingTable from "table/LiveTrackingTable";
import Dropdown from "components/Dropdown";
import "./LiveTracking.scss";
import moment from "moment";
import axios from "axios";
import { Api } from "../../../utility/api";
import { encryptRSAData } from "../../../utility/rsa";

interface Props {
	buttonName: string;
	onClickHandler: any;
}
const LiveTracking = () => {
	let dispatch = useDispatch();

	const [selectedAsset, setSelectedAsset] = useState<any>("");
	const [selectedModel, setSelectedModel] = useState<any>("");
	const [selectedModelStatus, setSelectedModelStatus] = useState<any>("");
	const [page, setPage] = useState<any>(1);
	const [loading, setLoading] = useState<any>(false);
	//  const [liveTrackingData, setLiveTrackingData] = useState<any>([])
	let today = moment(new Date()).format("YYYY-MM-DD");

	const {
		livetrackingtable,
		globalSelecetedPlant,
		globalSelecetedAsset,
		assetDropdownList,
		modelDropdownList,
		modelStatusDropdownList,
		commonFromDateFormat,
		commonToDateFormat,
		selectedBreadCrumbDate,
		breadCrumbDateFormated,
		breadCrumbDate,
		commonToDate,
		commonFromDate,
		loadingAssetDropdownList,
		loadingModelNameDropdownList,
		loadingModelSensorDropdownList,
		loadinglivetrackingtable,
		loadingModelStatusDropdownList,
	} = useSelector((state: any) => ({
		livetrackingtable: state.Common.livetrackingtable,
		loadinglivetrackingtable: state.Common.loadinglivetrackingtable,

		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		assetDropdownList: state.Common.assetDropdownList,
		modelDropdownList: state.Common.modelDropdownList,
		modelStatusDropdownList: state.Common.modelStatusDropdownList,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		commonToDate: state.Common.commonToDate,
		commonFromDate: state.Common.commonFromDate,

		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
		breadCrumbDate: state.Common.breadCrumbDate,
		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,

		loadingAssetDropdownList: state.Common.loadingAssetDropdownList,
		loadingModelNameDropdownList: state.Common.loadingModelNameDropdownList,
		loadingModelSensorDropdownList: state.Common.loadingModelSensorDropdownList,
		loadingModelStatusDropdownList: state.Common.loadingModelStatusDropdownList,
	}));

	useEffect(() => {
		if (
			Object.keys(globalSelecetedPlant).length > 0 &&
			Object.keys(globalSelecetedAsset).length > 0
		) {
			setSelectedAsset(globalSelecetedAsset);
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
			dispatch(
				getModelDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			); //{assetId}/{userId}
		}
	}, []);

	useEffect(() => {
		if (modelDropdownList.length > 0) {
			setSelectedModel(modelDropdownList[0]);
			dispatch(
				getModelStatusDropdownList(
					encryptRSAData(`modelId=${modelDropdownList[0].value}`)
				)
			); //{assetid}/{userId}
		}
	}, [modelDropdownList]);

	useEffect(() => {
		if (modelStatusDropdownList.length > 0) {
			setSelectedModelStatus(modelStatusDropdownList[0]);
			// dispatch(getModelStatusDropdownList(`${modelDropdownList[0].value}/18`)); //{assetid}/{userId}
		}
	}, [modelStatusDropdownList]);

	useEffect(() => {
		if (
			breadCrumbDateFormated !== "" &&
			Object.keys(selectedAsset).length > 0 &&
			Object.keys(selectedModel).length > 0 &&
			Object.keys(selectedModelStatus).length > 0 &&
			breadCrumbDateFormated !== "Invalid date"
		) {
			let data = {
				plantId: globalSelecetedPlant.value,
				assetId: selectedAsset.value,
				modelId: selectedModel.value,
				userId: "0",
				fromDate: breadCrumbDateFormated,
				toDate: today,
				status:
					Object.keys(selectedModelStatus).length > 0
						? selectedModelStatus.value
						: 0,
				pageIndex: page,
				pageSize: 10,
				sortColumn: "TimeStamp",
				sortOrder: "ASc",
			};
			dispatch(getLivetrackingtable(data)); //live tracking table by default Asset ID
			// handleApiCall(data)
		}
	}, [
		breadCrumbDateFormated,
		selectedAsset,
		selectedModel,
		selectedModelStatus,
		page,
	]);

	useEffect(() => {
		if (
			commonToDateFormat !== "" &&
			Object.keys(selectedAsset).length > 0 &&
			Object.keys(selectedModel).length > 0 &&
			Object.keys(selectedModelStatus).length > 0 &&
			commonFromDateFormat !== "Invalid date"
		) {
			let data = {
				plantId: globalSelecetedPlant.value,
				assetId: globalSelecetedAsset.value,
				modelId: selectedModel.value,
				userId: "0",
				fromDate: commonFromDateFormat,
				toDate: commonToDateFormat,
				status:
					Object.keys(selectedModelStatus).length > 0
						? selectedModelStatus.value
						: 0,
				pageIndex: page,
				pageSize: 10,
				sortColumn: "TimeStamp",
				sortOrder: "ASc",
			};

			dispatch(getLivetrackingtable(data)); //live tracking table by default Asset ID
			// handleApiCall(data)
		}
	}, [
		commonToDateFormat,
		selectedAsset,
		selectedModel,
		selectedModelStatus,
		page,
	]);

	const handleAssetDropDown = (e: any) => {
		setPage(1);
		setSelectedAsset(e);
		setSelectedModel("");
		setSelectedModelStatus("");
		dispatch(
			getModelDropdownList(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`
				)
			)
		); //{assetId}/{userId}
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
	};

	const handleModeldDropDown = (e: any) => {
		setPage(1);
		setSelectedModel(e);
		setSelectedModelStatus("");
		dispatch(getModelStatusDropdownList(encryptRSAData(`modelId=${e.value}`))); //{assetid}/{userId}
	};

	const handleModeldStatusDropDown = (e: any) => {
		setPage(1);
		setSelectedModelStatus(e);
	};

	// const handleApiCall = (data: any) => {
	//     setLiveTrackingData([])
	//     setLoading(true)
	//     axios({
	//         method: 'post',
	//         url: Api.getApiLivetrackingtable,
	//         headers: {
	//             'Content-Type': 'application/json',
	//         },
	//         data: data
	//     }).then((response) => {
	//         setLiveTrackingData(response.data)
	//         setLoading(false)

	//     }).catch((error) => {
	//         setLoading(false)

	//     })
	// }

	return (
		<>
			<div id="live-tracking">
				<div className="common-box-inner">
					<div className="title">LIVE TRACKING</div>
					<div id="new-filter">
						<div className="nf-left">
							<div className="asset-name">
								{Object.keys(selectedAsset).length > 0
									? selectedAsset.value
									: null}
							</div>
						</div>
						<div className="nf-right">
							<div>
								<label className="cus-label">Asset ID</label>
								<Dropdown
									name={"AssetID"}
									options={assetDropdownList}
									handleChange={handleAssetDropDown}
									value={selectedAsset}
									defaultValue={""}
									loading={loadingAssetDropdownList}
								/>
							</div>
							<div>
								<label className="cus-label">Model Name</label>
								<Dropdown
									name={"Model Name"}
									options={modelDropdownList}
									handleChange={handleModeldDropDown}
									defaultValue={""}
									value={selectedModel}
									loading={loadingModelNameDropdownList}
								/>
							</div>
							<div>
								<label className="cus-label">Model Status</label>
								<Dropdown
									name={"Model Status"}
									options={modelStatusDropdownList}
									handleChange={handleModeldStatusDropDown}
									defaultValue={""}
									value={selectedModelStatus}
									loading={loadingModelStatusDropdownList}
								/>
							</div>
						</div>
					</div>
					<div className="common-box-content">
						<LiveTrackingTable
							loading={loadinglivetrackingtable}
							data={livetrackingtable}
							page={page}
							setPage={setPage}
						/>
					</div>
				</div>
			</div>
		</>
	);
};
export default LiveTracking;

//live tracking table by default Asset ID At Initial Load : start
// useEffect(() => {
//     if (assetDropdownList && assetDropdownList.length>0){
//     setDefaultValueAssetDropdown(assetData[0].value)
//  }

// }, [assetDropdownList]);
//live tracking table by default Asset ID At Initial Load : end

// const handlePlotAssetIdDropDown = (e: any) => {
//     setSelectedAsset(e.value)
//     dispatch(getPlotModelDropDown("18/18"));    //{assetId}/{userId}
// };
// {
//     "assetId": "2K-3201",
//         "modelId": 0,
//             "userId": "0",
//                 "fromDate": "2022-03-29T13:34:00.000",
//                     "toDate": "2023-03-20T13:34:00.000",
//                         "status": "Alert",
//                             "pageIndex": 1,
//                                 "pageSize": 100,
//                                     "sortColumn": "TimeStamp",
//                                         "sortOrder": "ASc"
// }
// let data = 1;
// axios({
//     method: 'get',
//     url: 'http://localhost:8053/api/v1/LiveTracking/getlivetrackingdata_byassetid/liveTracking',
//     headers: {
//         'Content-Type': 'application/json',
//     },
//     data: {
//         foo: 'bar', // This is the body part
//     }
// });
