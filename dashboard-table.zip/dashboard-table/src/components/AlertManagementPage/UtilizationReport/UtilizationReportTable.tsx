import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { Excel } from "antd-table-saveas-excel";
import "../../../assets/common/CommonTables.scss";
import "../alertmanagement-table.scss";

interface Props {
	data: any[];
	loading: any;
}
const UtilizationReportTable = ({ data, loading }: Props) => {
	// Time Formate work :Start
	const [utilizationreport, setutilizationreport] = useState<any>();
	useEffect(() => {
		let mydata = data.map(function (item: any) {
			return {
				Affiliate: item.affiliate,
				Plant: item.plant,
				OverDueCount: item.countS_Overdue,
				WorkInProgressCount: item.countS_workInProgress,
				NotAssignedCount: item.countS_NotAssigned,
				ClosedCount: item.countS_Closed,
			};
		});
		setutilizationreport(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: '150'
		},
		{
			title: "PLANTS",
			dataIndex: "Plant",
			key: "Plant",
			width: '150'
		},
		{
			title: "OVERDUE (COUNT)",
			dataIndex: "OverDueCount",
			key: "OverDueCount",
			width: '150'
		},
		{
			title: "WORK IN PROGRESS (COUNT)",
			dataIndex: "WorkInProgressCount",
			key: "WorkInProgressCount",
			width: '150'
		},
		{
			title: "NOT ASSIGNED (COUNT)",
			dataIndex: "NotAssignedCount",
			key: "NotAssignedCount",
			width: '150'
		},
		{
			title: "CLOSED (COUNT)",
			dataIndex: "ClosedCount",
			key: "ClosedCount",
			width: '150'
		},
	];

	//Utilization TableExcel: Start=============
	const handleClickUtilizationReport = () => {
		const excel = new Excel();
		excel
			.addSheet("test")
			.addColumns(columns)
			.addDataSource(utilizationreport, {
				str2Percent: true,
			})
			.saveAs("UtilizationTableExcel.xlsx");
	};

	return (
		<div id="utilization-report-table">
			<button
				className="alerttablebuttons"
				onClick={handleClickUtilizationReport}
				style={{ display: "none" }}
				id="handleClickUtilizationReport"
			>
				EXPORT TO EXCEL
			</button>
			<Table
				columns={columns}
				dataSource={utilizationreport}
				pagination={{ pageSize: 10, showSizeChanger: false }}
				scroll={{ x: true }}
				loading={loading}
			/>
		</div>
	);
};

export default UtilizationReportTable;
