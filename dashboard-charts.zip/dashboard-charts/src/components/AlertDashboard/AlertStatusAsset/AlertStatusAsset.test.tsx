import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AlertStatusAsset from "./index";

beforeEach(() => {
	// Create <div> which is needed by the chart
	document.body.innerHTML = `<div id="chartdiv"></div>`;
});

//Mock data for the chart component
const data = [
	{
		state: "Overdue investigation",
		countofAlerts: 35,
	},
	{
		state: "Closed",
		countofAlerts: 56,
	},
	{
		state: "under investigation",
		countofAlerts: 42,
	},
];

//Test Case to check chart exist in the component.
describe("AlertStatusAsset", () => {
	it("renders the chart with data", () => {
		const { container } = render(<AlertStatusAsset data={data} />);
		expect(container.querySelector("#chartdiv")).toBeInTheDocument();
	});
});
