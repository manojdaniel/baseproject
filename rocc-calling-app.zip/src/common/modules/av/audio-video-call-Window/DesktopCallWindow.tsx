/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { CallWindowHeader } from "@rocc/rocc-calling-components"
import { ECallStatus, IParticipantInfo } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { GridRow } from "semantic-ui-react"
import CallParticipants from "../../../../components/call-participants/CallParticipants"
import { CALL_ACCEPT, TELEPRESENCE_SIDEBAR } from "../../../../constants/constants"
import { GLOBAL_RIGHTSIDE_PANEL } from "../../../../redux/actions/types"
import { IStore } from "../../../../redux/interfaces/types"
import { dispatchToParentStore } from "../../../../redux/store/externalAppStates"
import en from "../../../../resources/translations/en-US"
import AvSettingsController from "../../av-settings/AvSettingsController"
import RenderRemoteMedia from "../RenderRemoteMedia"
import { ECallOptions, IAudioVideoCallWindowProps } from "../types"
import CallControls from "./CallControls"
import CallerDetails from "./CallerDetails"
import styles from "./DesktopCallWindow.scss"
import { useActiveCallOption } from "./DesktopCallWindowCustomHook"

const { ADD_PARTICIPANT, SETTINGS, NONE } = ECallOptions

interface IDisplayParticipant {
    participantName: string
    currentUser: boolean
    localMediaRef: React.MutableRefObject<any>
    videoStatus: boolean
}

const DesktopCallWindow = (props: IAudioVideoCallWindowProps) => {
    const [isDesktopFullScreen, setdesktopCallWindowFullScreen] = useState(false)
    const [remoteParticipants, setRemoteParticipants] = useState([] as IDisplayParticipant[])
    const { intl } = getIntlProvider()

    const {
        desktopCallWindowFullScreen,
        currentUser,
        permissions,
    } = useSelector((state: IStore) => ({
        desktopCallWindowFullScreen: state.externalReducer.sideBar.desktopFullScreen,
        currentUser: state.externalReducer.currentUser,
        permissions: state.externalReducer.permissions,
    }))

    const { selectedOption, changeActiveCallOption } = useActiveCallOption()

    useEffect(() => {
        if (desktopCallWindowFullScreen && permissions.CALL_DESKTOP_FULL_SCREEN) {
            setdesktopCallWindowFullScreen(true)
            changeActiveCallOption(NONE)
        } else {
            setdesktopCallWindowFullScreen(false)
            changeActiveCallOption(ADD_PARTICIPANT)
        }
    }, [desktopCallWindowFullScreen])

    const {
        remoteUserVideoStatus,
        remoteAudioTrackStatus,
        dominantSpeaker,
        localMediaRef,
        videoStatus,
        activeCall,
    } = props

    const { numOfParticipants } = activeCall

    useEffect(() => {
        const getRemoteParticipantList = () => {
            const participants: any[] = [{
                participantName: currentUser.name, currentUser: true, localMediaRef, videoStatus
            }]
            activeCall.participants.forEach((participant: IParticipantInfo) => {
                if (dominantSpeaker && participant.uuid !== dominantSpeaker.uuid) {
                    const loading = !(participant.callStatus && CALL_ACCEPT === participant.callStatus)
                    const participantItem = {
                        participantName: participant.name,
                        currentUser: false,
                        videoStatus: false,
                        loading,
                    }
                    participants.push(participantItem)
                }
            })
            setRemoteParticipants(participants)
        }
        getRemoteParticipantList()

    }, [activeCall, dominantSpeaker, videoStatus])

    const displayCallOptions = (updatedOption: ECallOptions) => {
        if (selectedOption === updatedOption) {
            isDesktopFullScreen ? changeActiveCallOption(NONE) : changeActiveCallOption(ADD_PARTICIPANT)
        } else {
            changeActiveCallOption(updatedOption)
        }
    }
    const expandClick = () => {
        sendLogsToAzure({ contextData: { component: "DesktopCallWindow", event: isDesktopFullScreen ? `Expand click` : `Collapse clicked`, Event_by: currentUser.uuid } })
        dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: TELEPRESENCE_SIDEBAR, displayRightSidePanel: true, desktopFullScreen: !isDesktopFullScreen } })
    }

    const videoHandlers = () => {
        if (props.activeCall.callStatus !== ECallStatus.PAUSED) {
            return (
                <>
                    {selectedOption === SETTINGS && <div className={cx(styles.settings, (selectedOption === SETTINGS) ? styles.active : styles.inactive)}>
                        <GridRow id="settingsContainer" className={styles.participantsRow}>
                            {intl.formatMessage({ id: "content.settings.title", defaultMessage: en["content.settings.title"] })}
                            <span className={styles.closeIcon} onClick={() => displayCallOptions(SETTINGS)}><i className="icon close" /></span>
                        </GridRow>
                        <AvSettingsController active={selectedOption === SETTINGS} component={"Active Call Panel Settings"} />
                    </div>}
                    <div id="participantsContainer" className={cx(styles.contacts, (selectedOption === ADD_PARTICIPANT) ? styles.active : styles.inactive)}>
                        <GridRow className={styles.participantsRow}>
                            {intl.formatMessage({ id: "content.videoComponent.participants", defaultMessage: en["content.videoComponent.participants"] })}
                            {
                                desktopCallWindowFullScreen ?
                                    <span className={styles.closeIcon} onClick={() => displayCallOptions(ADD_PARTICIPANT)} >
                                        <i className="icon close" />
                                    </span> :
                                    <span className={styles.closeIcon} onClick={() => displayCallOptions(ADD_PARTICIPANT)} />
                            }
                        </GridRow>
                        <CallParticipants {...props} />
                    </div>
                </>
            )
        }
        return <></>
    }

    const p2pRemoteUserVideoStatus = ((numOfParticipants === 1) && remoteUserVideoStatus)
    const videoCallingClassName = (p2pRemoteUserVideoStatus && !isDesktopFullScreen) ? styles.videoCalling : ""
    const audioCallingClassName = p2pRemoteUserVideoStatus ? "" : isDesktopFullScreen ? "" : styles.audioCalling

    return (
        <>
            <div className={cx(styles.callNotifictions)}>
                {props.connectedCallProps?.callNotifications ? props.connectedCallProps.callNotifications : <></>}
            </div>
            {isDesktopFullScreen && <div className={cx(styles.fullScreenVideoHandlers, selectedOption === NONE ? styles.inactive : styles.active)}>
                {videoHandlers()}
            </div>}
            <div className={cx(isDesktopFullScreen ? styles["call-window-full-screen"] : styles["call-window"], styles.active, videoCallingClassName, audioCallingClassName)}>
                <div className={cx(styles["call-header"])}>
                    <div className={cx(styles["call-list"])}>
                        <CallWindowHeader
                            sidePanelState={isDesktopFullScreen && [SETTINGS, ADD_PARTICIPANT].includes(selectedOption)}
                            callWindowFullscreen={isDesktopFullScreen}
                            callWindowFullscreenFeature={true}
                            participantsList={remoteParticipants}
                            toggleCallWindowFullscreen={expandClick}
                        />
                    </div>
                </div>
                <div className={!isDesktopFullScreen ? cx(styles["call-body"]) : cx(styles["fullScreen-call-body"])}>
                    <RenderRemoteMedia {...props} isDesktopFullScreen={isDesktopFullScreen} />
                    <div id="remoteMediaCallDetails" className={cx(styles["call-details"], p2pRemoteUserVideoStatus ? styles.displayUserDetails : "")}>
                        <CallerDetails
                            dominantSpeaker={dominantSpeaker}
                            remoteAudioTrackStatus={remoteAudioTrackStatus}
                            cssStyleClass={styles}
                            numOfParticipants={numOfParticipants}
                        />
                    </div>
                </div>
                <div className={cx(styles["call-footer"])} id="remoteMediaCallFooter">
                    <CallControls
                        {...props}
                        selectedOption={selectedOption}
                        setSelectedOption={changeActiveCallOption}
                        isDesktopFullScreen={isDesktopFullScreen} />
                </div>
                {!isDesktopFullScreen && <div className={styles.videoHandlers}>
                    {videoHandlers()}
                </div>}
            </div>
        </>
    )
}

export default DesktopCallWindow
