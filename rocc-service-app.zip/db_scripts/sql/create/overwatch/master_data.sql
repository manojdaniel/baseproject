--Insert Jobs to table service_jobs
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('CUSTOMER_DATA_INSERTION') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('VALIDATE_ONBOARDED_DATA') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('PARENT_ORG_SETUP') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('CUSTOMER_ORG_SETUP') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('CF_CUSTOMER_SETUP') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('RBAC_INFRA_SETUP') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('TIMED_WAIT') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('FAILED') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('COMPLETE') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;
INSERT INTO rocc_overwatch.service_jobs(job_name) VALUES('SETUP_SERVICE_TOOLS') ON CONFLICT ON CONSTRAINT service_jobs_job_name_key DO NOTHING;

--Insert Tasks for customer data insertion to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('SITE_DATA_INSERTION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CC_DATA_INSERTION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 2) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 2;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_ROOMS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 3) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 3;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_USERS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 4) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 4;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_EULA', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 5) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 5;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_KVM_CONFIGURATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_DATA_INSERTION'), 6) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 6;

--Insert Tasks for validate onboarded data to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('SITE_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CC_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 2) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 2;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('ROOMS_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 3) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 3;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('USERS_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 4) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 4;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('EULA_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 5) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 5;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('KVM_CONFIGURATION_DATA_VALIDATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'VALIDATE_ONBOARDED_DATA'), 6) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 6;

--Insert Tasks for create root org to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_PROPOSITION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_APPLICATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 2) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 2;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_SERVICE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 3) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 3;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_OAUTH_CLIENT', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 4) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 4;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('UPDATE_CLIENT_SCOPE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 5) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 5;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_VAULT_VALUES', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 6) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 6;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_ALL_POLICIES', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 7) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 7;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_SECURITY_QUESTIONS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'PARENT_ORG_SETUP'), 8) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 8;

--Insert Tasks for customer org setup to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_ORG', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_ROLES_AND_GROUPS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 2) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 2;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_PROPOSITION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 3) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 3;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_APPLICATION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 4) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 4;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_SERVICE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 5) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 5;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('ENABLE_SERVICE_TOOLS_FOR_CUSTOMER', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 6) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 6;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_OAUTH_CLIENT', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 7) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 7;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('UPDATE_CLIENT_SCOPE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 8) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 8;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_EMAIL_TEMPLATES', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 9) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 9;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_DEVICE_PROPISITION', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 10) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 10;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_GROUP_POLICY', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 11) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 11;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_VAULT', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 12) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 12;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('MANAGE_REDIS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 13) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 13;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_ALLOWED_ORG_ROCC', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 14) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 14;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('ROLES_AND_PERMISSION_FOR_CUSTOMERS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CUSTOMER_ORG_SETUP'), 15) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 16;


--Insert Tasks for cf customer setup job to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CF_CUSTOMER_SETUP'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CF_CUSTOMER_SETUP'), 2) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 2;
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_ORG_COMMUNICATION_PROFILE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'CF_CUSTOMER_SETUP'), 3) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 15;

--Insert Tasks for RBAC infrastructure setup job to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('SETUP_RBAC_PERMISSIONS', (SELECT id from rocc_overwatch.service_jobs where job_name = 'RBAC_INFRA_SETUP'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;

--Insert Tasks for Timed wait job to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('TIMED_WAIT', (SELECT id from rocc_overwatch.service_jobs where job_name = 'TIMED_WAIT'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;

--Insert Tasks for customer org setup to table service_tasks
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('COMPLETE', (SELECT id from rocc_overwatch.service_jobs where job_name = 'COMPLETE'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;

--Insert Tasks for enabling service tools in parent org
INSERT INTO rocc_overwatch.service_tasks(task_name, job_id, execution_order) VALUES('CREATE_SERVICE_TOOLS_POLICY', (SELECT id from rocc_overwatch.service_jobs where job_name = 'SETUP_SERVICE_TOOLS'), 1) ON CONFLICT (task_name, job_id) DO UPDATE SET execution_order = 1;
