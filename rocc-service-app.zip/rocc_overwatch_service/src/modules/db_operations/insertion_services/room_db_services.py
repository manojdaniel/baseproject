"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from dataclasses import dataclass
import json
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values

from src.constants.constants import INSERT, OBJECTS, ID, ROCC_MODALITY_TYPES, ROCC_SCANNER_RESOURCES, ROCC_TABLETS, ROCC_TRANSMITTERS, ROCC_TX_MAPPINGS, ROCC_ORGANIZATIONS, \
    SITE_ID, ROCC_KVM_CONFIGURATIONS, DEVICE_HSDP_UUID, ORG_HSDP_UUID, BOXILLA_IP, RECEIVER_IP, TRANSMITTER_IP, ORG_IDENTIFIER, \
    ROCC_COMMAND_CENTRE_SEATS, ROCC_CC_RECEIVER_MAPPINGS , ROCC_RECEIVERS, DATA
from src.constants.enums import ESummaryStates
from src.constants.headers import EXCEL_ROOM_IDENTIFIER, EXCEL_ROOM_QUALIFY_NCC_EDIT, EXCEL_ROOM_SCANNER_MANUFACTURER, EXCEL_ROOM_SCANNER_MODEL, EXCEL_ROOM_SCANNER_SERIAL_NUMBER, \
    EXCEL_ROOM_SCANNER_DICOM_AE_TITLE, EXCEL_ROOM_SCANNER_SOFTWARE_VERSION, EXCEL_ROOM_SCANNER_OS, EXCEL_ROOM_SCANNER_OS_VERSION, EXCEL_ROOM_SCANNER_NOTES, \
    EXCEL_ROOM_VIEW_CONNECTION, EXCEL_ROOM_EDIT_CONNECTION, EXCEL_ROOM_MODALITY, EXCEL_ROOM_FULL_NAME, EXCEL_ROOM_TRANSMITTER_IP, \
    EXCEL_ROOM_PHONE_NUMBER, EXCEL_ROOM_LOCATION, EXCEL_ROOM_TRANSMITTER_NAME
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present, check_if_field_is_present, extract_id_from_mutation_response, \
    extract_id_from_query_response, \
    extract_response_from_mutation_response, update_dicts_with_inserted_ids, extract_data_from_table, extract_data_items_from_result, extract_items_from_result
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.wrappers.graphql.mutations.mutations import insert_single_modality, insert_new_scanner_resources, insert_devices_for_existing_rooms, insert_tx_mappings_for_existing_rooms, \
    insert_transmitter
from src.wrappers.graphql.queries.queries import check_if_modality_present, check_if_scanner_resources_present, get_tablet_for_scanner, \
    check_if_scanner_transmitter_mapping_present, check_if_transmitter_is_present, get_scanner_details_by_site_and_org_id, query_check_if_scanner_exists, \
    query_get_org_id_by_uuid, query_get_kvm_configuration_id_by_org_db_id, query_get_scanner_details_by_scanner_identifier

LOG = create_logger("RoomDBServices")


def update_rooms_eligibility(client, rooms, org_db_id):
    number_of_devices_required = 0
    for _, room in rooms.items():
        modality_id = check_if_data_present_in_a_given_table(client, ROCC_MODALITY_TYPES, room[EXCEL_ROOM_MODALITY].upper())
        if not modality_id:
            modality_id = insert_modalities(client, room[EXCEL_ROOM_MODALITY].upper())
        room["modality_id"] = modality_id
        room_id = check_if_data_present_in_a_given_table(client, ROCC_SCANNER_RESOURCES, room[EXCEL_ROOM_IDENTIFIER], org_db_id)
        if room_id:
            room["resource_id"] = room_id
            room["eligibility"]["new_room"] = False
            device_id, number_of_devices_required, room = check_if_device_present(client, number_of_devices_required, room, room_id)
            edit_connection_id, view_connection_id, room = check_if_kvm_connections_present(client, room, room_id)
            if device_id and view_connection_id and edit_connection_id:
                room["eligibility"]["status"] = False
        else:
            number_of_devices_required = number_of_devices_required + 1
            room["resource_id"] = False
            room["device_id"] = False
            room["eligibility"] = {"status": True, "new_room": True, "new_device": True, "new_view": True, "new_edit": True}
    return rooms, number_of_devices_required


def check_if_device_present(client, number_of_devices_required, room, room_id):
    device_id = check_if_data_present_in_a_given_table(client, ROCC_TABLETS, room_id)
    if device_id:
        room["eligibility"]["new_device"] = False
        room["device_id"] = device_id
    else:
        room["eligibility"]["new_device"] = True
        room["device_id"] = False
        number_of_devices_required = number_of_devices_required + 1
    return device_id, number_of_devices_required, room


def check_if_kvm_connections_present(client, room, room_id):
    view_connection_id = check_if_data_present_in_a_given_table(client, ROCC_TX_MAPPINGS, room[EXCEL_ROOM_VIEW_CONNECTION], room_id)
    edit_connection_id = check_if_data_present_in_a_given_table(client, ROCC_TX_MAPPINGS, room[EXCEL_ROOM_EDIT_CONNECTION], room_id)
    room["eligibility"]["new_view"] = False if view_connection_id else True
    room["eligibility"]["new_edit"] = False if edit_connection_id else True
    return edit_connection_id, view_connection_id, room


def check_if_data_present_in_a_given_table(client, table_name, *args):
    try:
        if table_name == ROCC_MODALITY_TYPES:
            return check_if_id_is_present(client.execute(check_if_modality_present, variable_values={"modality": args[0]}),
                                          ROCC_MODALITY_TYPES)
        elif table_name == ROCC_SCANNER_RESOURCES:
            return check_if_id_is_present(client.execute(check_if_scanner_resources_present, variable_values={"identifier": args[0], "org_db_id": args[1]}),
                                          ROCC_SCANNER_RESOURCES)
        elif table_name == ROCC_TX_MAPPINGS:
            return check_if_id_is_present(client.execute(check_if_scanner_transmitter_mapping_present,
                                                         variable_values={"transmitter_connection_name": args[0], "scanner_resource_id": args[1]}),
                                          ROCC_TX_MAPPINGS)
        elif table_name == ROCC_TABLETS:
            return check_if_field_is_present(client.execute(get_tablet_for_scanner, variable_values={"scanner_resource_id": args[0]}),
                                             ROCC_TABLETS, "device_hsdp_uuid")
        else:
            return False

    except Exception as ex:
        LOG.exception(f"Problem in check_if_data_present_in_a_given_table for table: {table_name} with error: {ex}")
        return False


def check_if_communication_mappings_are_created_for_room(room):
    message = []
    if not room["instance_id"]:
        message.append("Instance identity mapping is not created.")

    if not room["communication_profile"]:
        message.append("Communication profile mapping is not created.")

    if not room["rbac_mapping"]:
        message.append("Rbac role mapping is not created.")

    if len(message) > 0:
        return False, message
    else:
        return True, message


def insert_room_data_in_db(client, rooms, user_uuid, kvm_config_id, transaction_data, scanner_data_support, org_db_id, additional_attributes_support):
    """
    ROCC_MODALITY_TYPES
    ROCC_SCANNER_RESOURCES
    ROCC_TX_MAPPINGS
    ROCC_TABLETS
    """
    try:

        existing_rooms = []
        new_rooms = []
        for key, room in rooms.items():
            is_eligible, message = check_if_communication_mappings_are_created_for_room(room)
            room["tx_id"] = check_and_insert_transmitter(client=client,
                                                         room_name=room[EXCEL_ROOM_FULL_NAME],
                                                         kvm_config_id=kvm_config_id,
                                                         transmitter_ip=room[EXCEL_ROOM_TRANSMITTER_IP],
                                                         transmitter_name=room[EXCEL_ROOM_TRANSMITTER_NAME],
                                                         user_uuid=user_uuid)
            if not room["eligibility"]["new_room"]:
                existing_rooms.append(room)
                LOG.info(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since it is not a new room")
                transaction_data = update_summary_for_entity(transaction_data, "rooms", key, ESummaryStates.EXISTING)
            elif not is_eligible:
                LOG.info(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since: {message} ")
                transaction_data = update_summary_for_entity(transaction_data, "rooms", key, ESummaryStates.INSERTION_FAILED)
            else:
                transaction_data = update_summary_for_entity(transaction_data, "rooms", key, ESummaryStates.NEW)
                LOG.info(f"Room: {room[EXCEL_ROOM_IDENTIFIER]} is eligible for insertion")
                room_dict = {
                    "identifier": room[EXCEL_ROOM_IDENTIFIER],
                    "name": room[EXCEL_ROOM_FULL_NAME],
                    "organization_id": org_db_id,
                    "modality_id": room["modality_id"],
                    "site_id": room["site_id"],
                    "modality_connection": json.loads(json.dumps(room["Modality_Connection"])),
                    "primary_phone": room[EXCEL_ROOM_PHONE_NUMBER],
                    "location":  room[EXCEL_ROOM_LOCATION],
                    "created_by": user_uuid,
                    "modified_by": user_uuid,
                    "rocc_tablets": {
                        "data": {
                            "device_hsdp_uuid": room["device_id"],
                            "device_azure_id": "",
                            "device_name": room[EXCEL_ROOM_IDENTIFIER],
                            "status": "Active",
                            "created_by": user_uuid,
                            "modified_by": user_uuid
                        }
                    },
                    "rocc_transmitter_mappings": {
                        "data": [
                            {
                                "transmitter_connection_name": room[EXCEL_ROOM_VIEW_CONNECTION],
                                "transmitter_connection_type": "view",
                                "created_by": user_uuid,
                                "modified_by": user_uuid,
                                "transmitter_id": room["tx_id"]
                            },
                            {
                                "transmitter_connection_name": room[EXCEL_ROOM_EDIT_CONNECTION],
                                "transmitter_connection_type": "full_control",
                                "created_by": user_uuid,
                                "modified_by":user_uuid,
                                "transmitter_id": room["tx_id"]
                            }
                        ]
                    }
                }
                if scanner_data_support:
                    room_dict = extend_with_scanner_details(room_dict, room)
                if additional_attributes_support:
                    room_dict = extend_with_additional_attributes(room_dict=room_dict, room=room)
                new_rooms.append(room_dict)
        if len(new_rooms) > 0:
            LOG.info(f"Inserting data for new rooms: {new_rooms}")
            db_result_rooms = client.execute(insert_new_scanner_resources, variable_values={OBJECTS: new_rooms})
            results = extract_response_from_mutation_response(db_result_rooms, f"{INSERT}{ROCC_SCANNER_RESOURCES}")
            rooms = update_dicts_with_inserted_ids(dicts=rooms,
                                                   results=results,
                                                   item_id_name="resource_id",
                                                   item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                                   result_unique_name="identifier")
        else:
            LOG.info("Skipping room data insertion, since there are no eligible rooms")
        rooms = handle_existing_rooms(client=client, rooms=rooms, existing_rooms=existing_rooms, user_uuid=user_uuid)
        return rooms, transaction_data
    except TypeError as ex:
        LOG.exception(ex)
        LOG.error(f"TypeError occurred while inserting rooms data: {ex}")
    except Exception as ex:
        LOG.exception(ex)
        LOG.error(f"An exception occurred while inserting rooms data: {ex}")
        return False


def extend_with_scanner_details(base_details_dict, room):
    try:
        scanner_support_dict = {
            "manufacturer": room[EXCEL_ROOM_SCANNER_MANUFACTURER],
            "model": room[EXCEL_ROOM_SCANNER_MODEL],
            "serial_number": room[EXCEL_ROOM_SCANNER_SERIAL_NUMBER],
            "dicom_ae_title": room[EXCEL_ROOM_SCANNER_DICOM_AE_TITLE],
            "scanner_software_version": str(room[EXCEL_ROOM_SCANNER_SOFTWARE_VERSION]),
            "scanner_os_type": room[EXCEL_ROOM_SCANNER_OS],
            "scanner_os_version": str(room[EXCEL_ROOM_SCANNER_OS_VERSION]),
            "notes": room[EXCEL_ROOM_SCANNER_NOTES],
        }
        base_details_dict.update(scanner_support_dict)
        return base_details_dict
    except KeyError as ex:
        LOG.error(f"KeyError occurred in fetching a scanner property: {ex}")
        return base_details_dict

def extend_with_additional_attributes(room_dict, room):
    try:
        additional_attributes = {}
        additional_attributes["ncc_edit"] = True if room[EXCEL_ROOM_QUALIFY_NCC_EDIT] == "Yes" else False
        """ TODO: add column for isPharmaEnabled in excel """
        additional_attributes["is_pharma_enabled"] = False
        additional_attributes_dict = {
            "additional_attributes": json.loads(json.dumps(additional_attributes))
        }
        room_dict.update(additional_attributes_dict)
        return room_dict
    except Exception as e_x:
        LOG.error(f"Error while fetching additional attributes Error: {e_x}")
        return room_dict

def check_and_insert_transmitter(client, room_name, transmitter_ip, transmitter_name, kvm_config_id, user_uuid):
    try:
        """
        - Query Tx for the details
            - If found return ID
            - Else create Tx and return ID
        """
        variable_values = {"transmitter_ip": transmitter_ip, "kvm_config_id": kvm_config_id, "transmitter_name": transmitter_name}
        query_response = client.execute(check_if_transmitter_is_present, variable_values=variable_values)
        if check_if_id_is_present(query_response, ROCC_TRANSMITTERS):
            tx_id = extract_id_from_query_response(query_response, ROCC_TRANSMITTERS)
        else:
            """ Add Tx """
            tx_object = {
                "kvm_configuration_id": kvm_config_id,
                "transmitter_name": transmitter_name,
                "transmitter_ip": transmitter_ip,
                "created_by": user_uuid,
                "modified_by": user_uuid
            }
            query_response = client.execute(insert_transmitter, variable_values={OBJECTS: tx_object})
            tx_id = extract_id_from_mutation_response(query_response, f"{INSERT}{ROCC_TRANSMITTERS}")
        return tx_id

    except Exception as ex:
        LOG.exception(f"Failed to add/modify transmitter details for room: {room_name} with error: {ex}")
        raise RoccException(status_code=500, payload="Failed to add/modify transmitter details") from ex


def insert_modalities(client, modality):
    LOG.info(f"Inserting modality: {modality}")
    try:
        db_result = client.execute(insert_single_modality, variable_values={"modality": modality.upper()})
        modality_id = extract_id_from_mutation_response(db_result, f"{INSERT}{ROCC_MODALITY_TYPES}")
        return modality_id
    except Exception as ex:
        LOG.error(f"An exception occurred while Inserting modality: {modality}, Exception: {ex}")
        return False


def handle_existing_rooms(client, rooms, existing_rooms, user_uuid):
    if len(existing_rooms) == 0:
        return rooms
    try:
        LOG.info("Handling existing room data insertion")
        device_rooms = []
        kvm_conn_rooms = []
        for e_room in existing_rooms:
            if e_room["eligibility"]["new_device"]:
                """  Handle device insertion """
                device_rooms.append({
                    "device_hsdp_uuid": e_room["device_id"],
                    "device_name": e_room[EXCEL_ROOM_IDENTIFIER],
                    "created_by": user_uuid,
                    "modified_by": user_uuid,
                    "scanner_resource_id": e_room["resource_id"]
                })
            if e_room["eligibility"]["new_view"]:
                """  Handle kvm view connection insertion """
                kvm_conn_rooms.append({
                    "created_by": user_uuid,
                    "modified_by": user_uuid,
                    "scanner_resource_id": e_room["resource_id"],
                    "number_of_monitors": 1,
                    "transmitter_connection_name": e_room[EXCEL_ROOM_VIEW_CONNECTION],
                    "transmitter_connection_type": "view",
                    "transmitter_id": e_room["tx_id"],
                })
            if e_room["eligibility"]["new_edit"]:
                """  Handle kvm edit connection insertion """
                kvm_conn_rooms.append({
                    "created_by": user_uuid,
                    "modified_by": user_uuid,
                    "scanner_resource_id": e_room["resource_id"],
                    "number_of_monitors": 1,
                    "transmitter_connection_name": e_room[EXCEL_ROOM_EDIT_CONNECTION],
                    "transmitter_connection_type": "full_control",
                    "transmitter_id": e_room["tx_id"],
                })
        handle_insertion_of_devices_for_existing_rooms(client, rooms, device_rooms)
        handle_insertion_of_kvm_connections_for_existing_rooms(client, rooms, kvm_conn_rooms)
    except Exception as ex:
        LOG.error(f"An exception occurred while handling data updates for existing rooms with error: {ex}")
    return rooms


def handle_insertion_of_devices_for_existing_rooms(client, rooms, device_rooms):
    if len(device_rooms) == 0:
        return rooms
    try:
        LOG.info("Handling existing room data insertion - devices")
        db_result = client.execute(insert_devices_for_existing_rooms,
                                   variable_values={"device_objects": device_rooms})
        device_details_results = extract_response_from_mutation_response(db_result, f"{INSERT}{ROCC_TABLETS}")
        rooms = update_dicts_with_inserted_ids(dicts=rooms,
                                               results=device_details_results,
                                               item_id_name="device_details_id",
                                               item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                               result_unique_name="device_name")
    except Exception as ex:
        LOG.error(f"An exception occurred while handling device data updates for existing rooms with error: {ex}")
    return rooms


def handle_insertion_of_kvm_connections_for_existing_rooms(client, rooms, kvm_conn_rooms):
    if len(kvm_conn_rooms) == 0:
        return rooms
    try:
        LOG.info("Handling existing room data insertion - kvm connections")
        db_result = client.execute(insert_tx_mappings_for_existing_rooms, variable_values={OBJECTS: kvm_conn_rooms})
        results = extract_response_from_mutation_response(db_result, f"{INSERT}{ROCC_TX_MAPPINGS}")
        for item in results:
            for _, room in rooms.items():
                if room[EXCEL_ROOM_IDENTIFIER] == item["scanner_resource_id"]:
                    if item["transmitter_connection_type"] == "view":
                        room["view_connection_id"] = item[ID]
                    else:
                        room["edit_connection_id"] = item[ID]
    except Exception as ex:
        LOG.error(f"An exception occurred while handling kvm connection data updates for existing rooms with error: {ex}")
    return rooms


def check_if_scanner_exists(client, identifier, site_id):
    response = client.execute(query_check_if_scanner_exists, variable_values={"identifier": identifier, SITE_ID: site_id})
    if check_if_id_is_present(response, ROCC_SCANNER_RESOURCES):
        LOG.info(f"Scanner {identifier} for site {site_id} exists.")
        raise RoccException(422, title="Scanner already present.", payload=f"Scanner: {identifier} already present at site {site_id}.")
    LOG.info(f"Scanner: {identifier} at site {site_id} does not exist in database.")


def get_org_db_id_by_uuid(client, org_infra_uuid):
    response = client.execute(query_get_org_id_by_uuid, variable_values={"org_hsdp_uuid": org_infra_uuid})
    org_db_id = check_if_id_is_present(response, ROCC_ORGANIZATIONS)
    if org_db_id:
        LOG.info(f"Organization {org_infra_uuid} exists.")
        return org_db_id
    LOG.error(f"Organization: {org_infra_uuid} does not exist in database.")
    raise RoccException(422, title="Organization not found.", payload=f"Organization: {org_infra_uuid} not found.")


def get_modality_id(client, modality):
    response = client.execute(check_if_modality_present, variable_values={"modality": modality})
    modality_id = check_if_id_is_present(response, ROCC_MODALITY_TYPES)
    if not modality_id:
        LOG.error(f"Modality {modality} not found.")
        raise RoccException(422, title="Modality not found.", payload=f"Modality: {modality} not found.")
    LOG.info(f"Modality: {modality} exists in database.")
    return modality_id


def get_scanner_details(client, identifier, org_infra_uuid, site_id):
    response = client.execute(get_scanner_details_by_site_and_org_id, variable_values={"resource_id": identifier, SITE_ID: site_id, "org_hsdp_uuid": org_infra_uuid})
    if check_if_id_is_present(response, ROCC_SCANNER_RESOURCES):
        LOG.info(f"Scanner {identifier} found in database.")
        data = extract_data_from_table(response, ROCC_SCANNER_RESOURCES)[0]
        transmitter_mappings = data["rocc_transmitter_mappings"][0]
        transmitter = transmitter_mappings["transmitter"]
        transmitter_obj = Transmitter(transmitter["kvm_configuration_id"], transmitter["transmitter_name"], transmitter["transmitter_ip"])
        transmitter_mappings_obj = TransmitterMappings(transmitter_mappings["transmitter_connection_name"], transmitter_mappings["transmitter_connection_type"],
                                                       transmitter_mappings["created_at"], transmitter_mappings["created_by"], transmitter_mappings["modified_at"],
                                                       transmitter_mappings["modified_by"],
                                                       transmitter_obj)
        return ScannerDetails(data["organization_id"], data["dicom_ae_title"], data["manufacturer"], data["model"], data["serial_number"], data["notes"], data["location"],
                              data["primary_phone"], data["secondary_phone"], data["scanner_os_type"], data["scanner_os_version"], data["scanner_software_version"],
                              data["additional_attributes"], data["modality_connection"],
                              transmitter_mappings_obj)

    LOG.info(f"Scanner: {identifier} does not exist in database.")
    raise RoccException(422, title="Scanner not found.", payload=f"Scanner: {identifier} not present.")


def get_kvm_configuration_id_by_org_db_id(client, org_db_id):
    response = client.execute(query_get_kvm_configuration_id_by_org_db_id, variable_values={"org_db_id": org_db_id})
    kvm_config_id = check_if_id_is_present(response, ROCC_KVM_CONFIGURATIONS)
    if kvm_config_id:
        LOG.info(f"KVM Configuration for organization: {org_db_id} exists. And value is {kvm_config_id}")
        return kvm_config_id
    LOG.error(f"KVM Configuration for organization: {org_db_id} does not exist in database.")
    raise RoccException(422, title="KVM Configuration not found.", payload=f"KVM Configuration for organization: {org_db_id} not found.")

def get_scanner_details_by_identifier(client,scanner_identifier):

    device_details = {}
    scanner_response = client.execute(query_get_scanner_details_by_scanner_identifier,variable_values={"identifier":scanner_identifier })
    if check_if_id_is_present(scanner_response, ROCC_SCANNER_RESOURCES):
        LOG.info(f"Scanner identifier {scanner_identifier} found in database.")
        scanner_data = extract_data_from_table(scanner_response,ROCC_SCANNER_RESOURCES)[0]
        scanner_id = scanner_data[ID]
        site_id =  scanner_data[SITE_ID]
        org_data = scanner_data[ROCC_ORGANIZATIONS]
        org_uuid = org_data[ORG_HSDP_UUID]
        org_identifier = org_data[ORG_IDENTIFIER]

        device_details[DEVICE_HSDP_UUID]  = scanner_data[ROCC_TABLETS][0][DEVICE_HSDP_UUID]
        device_details[TRANSMITTER_IP] = get_scanner_details(client,scanner_id,org_uuid,site_id).transmitter_mappings.transmitter.transmitter_ip

        reciever_mappings = extract_data_items_from_result(org_data, ROCC_COMMAND_CENTRE_SEATS,ROCC_CC_RECEIVER_MAPPINGS)
        recievers = extract_items_from_result({ROCC_CC_RECEIVER_MAPPINGS:reciever_mappings}, ROCC_CC_RECEIVER_MAPPINGS , ROCC_RECEIVERS)
        device_details[RECEIVER_IP] = extract_items_from_result({ROCC_RECEIVERS :recievers}, ROCC_RECEIVERS, RECEIVER_IP)

        if check_if_id_is_present(org_data, ROCC_KVM_CONFIGURATIONS):
            kvm_data = extract_data_from_table(org_data, ROCC_KVM_CONFIGURATIONS)[0]
            device_details[BOXILLA_IP] = kvm_data[BOXILLA_IP]

        vault_values = get_path_specific_vault_values(path_name=org_identifier)
        device_details["console_service_address"] = vault_values[DATA]["consoleIpAddressAndPort"]

        return device_details

    LOG.info(f"Device with identifier: {scanner_identifier} does not exist in database.")
    raise RoccException(422, title="Device not found.", payload=f"Device: {scanner_identifier} not present.")

@dataclass
class Transmitter:
    kvm_configuration_id: int
    transmitter_name: str
    transmitter_ip: str


@dataclass
class TransmitterMappings:
    transmitter_connection_name: str
    transmitter_connection_type: str
    created_at: str
    created_by: str
    modified_at: str
    modified_by: str
    transmitter: Transmitter


@dataclass
class ScannerDetails:
    organization_id: int
    dicom_ae_title: str
    manufacturer: str
    model: str
    serial_number: str
    notes: str
    location: str
    primary_phone: str
    secondary_phone: str
    scanner_os_type: str
    scanner_os_version: str
    scanner_software_version: str
    additional_attributes: json
    modality_connection: json
    transmitter_mappings: TransmitterMappings
