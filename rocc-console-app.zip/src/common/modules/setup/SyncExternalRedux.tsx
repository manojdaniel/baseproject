/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore } from "@rocc/rocc-client-services"
import React, { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import { SYNC_CALL_REDUCERS_CALL_DETAILS, SYNC_PARENT_REDUCERS } from "../../../redux/actions/types"
import globalStore from "../../../redux/store/globalStore"
import { APP_NAME, CALLING_APP, PARENT_STORE } from "../../constants/constants"

const SyncExternalRedux = () => {

    const gState = globalStore.GetGlobalState()
    const [parentStoreSubscribed, setParentStoreSubscribed] = useState(false)
    const [callingStoreSubscribed, setCallingStoreSubscribed] = useState(false)

    const dispatch = useDispatch()

    const syncParentStore = () => {
        if (!parentStoreSubscribed && gState[PARENT_STORE]) {
            updateUserInfo(gState[PARENT_STORE])
            globalStore.SubscribeToPartnerState(APP_NAME, PARENT_STORE, (changedState: any) => {
                updateUserInfo(changedState)
            })
            setParentStoreSubscribed(true)
        }

        if (!callingStoreSubscribed && gState[CALLING_APP]) {
            updateCallingInfo(gState[CALLING_APP])
            globalStore.SubscribeToPartnerState(APP_NAME, CALLING_APP, (changedState: any) => {
                updateCallingInfo(changedState)
            })
            setCallingStoreSubscribed(true)
        }
    }

    useEffect(() => {
        syncParentStore()
    }, [gState])

    const updateCallingInfo = (changedState: any) => {
        const payload = {
            videoCallStatus: [...changedState.callReducer.videoCallStatus],
            connectedCallDetails: {
                ...changedState.callReducer.callDetails.connectedCallDetails,
                participants: [...changedState.callReducer.callDetails.connectedCallDetails.participants]
            },
            onHoldCallDetails: changedState.callReducer.callDetails.onHoldCallDetails,
        }
        dispatch({ type: SYNC_CALL_REDUCERS_CALL_DETAILS, payload, })
    }

    const updateUserInfo = (changedState: IParentStore) => {
        /* Update if session of parent app is updated */
        const payload = {
            currentUser: changedState.userReducer.currentUser,
            permissions: changedState.userReducer.permissions,
            appState: changedState.userReducer.appState,
            notificationMessage: changedState.modalReducer.notificationMessage,
            notificationModal: changedState.modalReducer.notificationModal,
            rooms: changedState.customerReducer.rooms,
            featureFlags: changedState.featureFlagsReducer.featureFlags,
            activeTabIndex: changedState.appReducer.activeTabIndex,
            displayLeftSidePanel: changedState.appReducer.sideBar.displayLeftSidePanel,
            displayRightSidePanel: changedState.appReducer.sideBar.displayRightSidePanel,
            desktopFullScreen: changedState.appReducer.sideBar.desktopFullScreen,
            applicationConnectionState: changedState.clientStatusReducer.applicationConnectionState,
            forceCleanUp: changedState.userReducer.forceCleanUp,
            workflows: changedState.workflowReducer.workflows,
            appContext: changedState.appReducer.appContext,
        }
        dispatch({ type: SYNC_PARENT_REDUCERS, payload, })
    }
    return <></>
}

export default SyncExternalRedux
