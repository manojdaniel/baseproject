#!/bin/bash
set -e
set -x
cd ${WORKSPACE}/rocc-nginx
export no_proxy=artifactory-ehv.ta.philips.com
curl -H "X-JFrog-Art-Api:$ARTIFACTORY_EHV_REGISTRY_TOKEN"  -O "$ARTIFACTORY_EHV_URL/pdv-generic-release-local/nginx/1.18.0/LuaJIT-2.1.0-beta3.tar.gz"
curl -H "X-JFrog-Art-Api:$ARTIFACTORY_EHV_REGISTRY_TOKEN"  -O "$ARTIFACTORY_EHV_URL/pdv-generic-release-local/nginx/1.18.0/nginx_devel_kit.tar.gz"
curl -H "X-JFrog-Art-Api:$ARTIFACTORY_EHV_REGISTRY_TOKEN"  -O "$ARTIFACTORY_EHV_URL/pdv-generic-release-local/nginx/1.18.0/nginx_lua_module.tar.gz"
curl -H "X-JFrog-Art-Api:$ARTIFACTORY_EHV_REGISTRY_TOKEN"  -O "$ARTIFACTORY_EHV_URL/pdv-generic-release-local/nginx/1.18.0/openssl-1.1.1g.tar.gz"
curl -H "X-JFrog-Art-Api:$ARTIFACTORY_EHV_REGISTRY_TOKEN"  -O "$ARTIFACTORY_EHV_URL/pdv-generic-release-local/nginx/1.18.0/nginx-1.18.0.tar.gz"

