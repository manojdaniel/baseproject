/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const PHILIPS_API_URI = "/philips/rocc"
export const COMMUNICATION_TOKEN_EP = "/Token"
export const UI_SERVICE_API_URI = `${PHILIPS_API_URI}/ui/service`
export const SERVER_LOGGER = `${UI_SERVICE_API_URI}/roccWebAppLogger`
