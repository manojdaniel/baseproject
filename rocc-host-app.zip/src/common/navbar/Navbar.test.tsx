/*
 * Created on Mon Oct 12 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import { CALLING_REDUCER_DATA, CONSOLE_REDUCER_DATA } from "../../constants/constants"
import Navbar from "./Navbar"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { withHooks } from "jest-react-hooks-shallow"
import { ECallStatus } from "@rocc/rocc-client-services"
import { getHomepageLink } from "./NavBarHelper"
import { IDN_ROUTE } from "../../constants/routes"

const mockState = {
    ...CONSOLE_REDUCER_DATA,
    featureFlagsReducer: {
        featureFlags: {
            "rocc-cc-home": true
        }
    },
    userReducer: {
        currentUser: {
            onBoarded: true,
            allRoles: ["Admin", "Expert user"]
        }
    },
    appReducer: {
        fseData: {
        }
    },
    configReducer: {
        configs: {
            ROCC_HELPLINE: "",
            CUSTOMER_PRIVACY_POLICY_URL: "www.privacypolicyurl.com"
        },
        urls: {}
    }
}

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: () => jest.fn(),
}))

jest.mock("@rocc/rocc-global-components", () => ({
    ...jest.requireActual("@rocc/rocc-global-components")
}))

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_CALLING: CALLING_REDUCER_DATA,
        CC_CONSOLE: CONSOLE_REDUCER_DATA,
    }),
    CreateStore: jest.fn(),
    SubscribeToPartnerState: jest.fn().mockReturnValue(
        { ...CONSOLE_REDUCER_DATA, ...CALLING_REDUCER_DATA }
    ),
}))

jest.mock("../../utility/helpers/helpers", () => ({
    getCurrentUserData: jest.fn().mockReturnValue({
        id: "1", uuid: "1", clinicalRole: "Expert user", onBoarded: true, allRoles: ["Expert user"], accessToken: "token"
    }),
    getAppReducerData: jest.fn().mockReturnValue({ nfccUpgradeAvailable: false, fseData: {} }),
    getFullApplicationName: jest.fn().mockReturnValue("Philips ROCC"),
    hideNotificationModal: jest.fn(),
    getFeatureFlags: jest.fn().mockReturnValue({}),
    checkIfParticularSessionGoingOn: () => true,
    getConFigs: jest.fn().mockReturnValue({ ADMIN_MANUAL_PATH: "path1", USER_MANUAL_PATH: "path2" }),
    getUrls: jest.fn().mockReturnValue({ MANAGEMENT_SERVICE_URL: "url" }),
    getPreSignedUrls: jest.fn().mockReturnValue({ expertUserManual: "expert user manual", adminUserManual: "admin user manual" }),
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

describe("Navbar Component", () => {
    let wrapper: any
    beforeEach(() => {
        useSelectorMock(mockState)
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })

    it("should render NavBar component", () => {
        withHooks(() => {
            wrapper = shallow(<Navbar userName={"dummy user"} phoneIconCallBack={() => ""} aboutClick={() => ""} phoneCallStatus={ECallStatus.IDLE} videoCallStatus={[]} consoleSessions={[]} isTechAppDownloadAvailable={true} />)
            expect(wrapper.find("NavBar")).toHaveLength(1)
        })
    })


    it("should return expert user route", () => {
        expect(getHomepageLink()).toBe(IDN_ROUTE)
    })
})
