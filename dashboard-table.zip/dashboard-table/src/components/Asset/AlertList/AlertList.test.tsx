import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AlertList from "./AlertList";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});

jest.mock("antd/es/typography/Link", () => {
	return ({ children }: { children: React.ReactNode }) => {
		return <a href="#">{children}</a>;
	};
});
// Mock data for testing
describe("AlertList", () => {
	const data = [
		{
			TimeStamp: "2023-04-27T12:00:00.000Z",
			AlertId: 1,
			ModelStatus: "OK",
			AlertStatus: "Active",
			ModelName: "Model A",
			InfluencingSensor1: "Sensor 1",
			InfluencingSensor2: "Sensor 2",
			InfluencingSensor3: "Sensor 3",
			InfluencingSensor4: "Sensor 4",
			InfluencingSensor5: "Sensor 5",
			InfluencingSensor6: "Sensor 6",
			AssignedDepartment: "Department A",
			TaskAssignedTo: "User A",
			TakeAction: "Take Action",
		},
	];
	it("should render the component without errors", () => {
		render(<AlertList data={data} />);
	});
});
