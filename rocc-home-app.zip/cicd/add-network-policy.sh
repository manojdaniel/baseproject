#!/usr/bin/env sh
echo "";
echo "Creating network policies...";
echo "";

CF=$(which cf)

if [ -n "$CF" ]; then
    $CF add-network-policy rocc-cc-home-app-{target_env} --destination-app rocc-nginx-{target_env} --protocol tcp --port 8080
    $CF add-network-policy rocc-nginx-{target_env} --destination-app rocc-cc-home-app-{target_env} --protocol tcp --port 8080
else
    echo "Cannot find cf binary in your path, please install the latest cf cli tools."
fi

echo "";
echo "Network policy creation is done."
