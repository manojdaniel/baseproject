/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DisconnectConsoleSessionContext, ECallStatus, FeatureFlagHelper, IAppReducer, IAVCallDetails, ICallStatus, IConfigReducer, ICustomerReducer, IFeatureFlagsReducer, IParticipantInfo, MultiEditInitiateCallContext, MultiEditStartEditingContext, ParkAndInitiateCallContext, ParkAndResumeContext, ParkAndStartEditingContext, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { APP_REDUCER, CONFIG_REDUCER, CUSTOMER_REDUCER, FEATURE_FLAG_REDUCER, PARENT_STORE } from "../../constants/constants"
import { IConsole, IWorkflowInfo } from "../../redux/interfaces/types"
import { getGlobalStoreDetails } from "../../redux/store/externalAppStates"
import store from "../../redux/store/store"

export const checkIfMultiEditWithoutParkResumeFeatureEnabled = (featureFlags: any) => {
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME)
}

export const checkIfMultiEditWithParkResumeFeatureEnabled = (featureFlags: any) => {
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITH_PARK_AND_RESUME)
}

export const checkIfMultiEditEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return checkIfMultiEditWithoutParkResumeFeatureEnabled(featureFlags) || checkIfMultiEditWithParkResumeFeatureEnabled(featureFlags)
}

export const getCustomrReducerFromGlobalStore = (): ICustomerReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: CUSTOMER_REDUCER })
}

export const getConfigReducerFromGlobalStore = (): IConfigReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: CONFIG_REDUCER })
}
export const getFeatureFlagsReducerFromGlobalStore = (): IFeatureFlagsReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: FEATURE_FLAG_REDUCER })
}
export const getAppReducerFromGlobalStore = (): IAppReducer => {
    return getGlobalStoreDetails({ storeName: PARENT_STORE, reducerPath: APP_REDUCER })
}

export const isDev = () => {
    return !process.env.NODE_ENV || process.env.NODE_ENV === "development"
}

export const getRoomUuidsFromWorkflowContext = (workflowContext: IWorkflowInfo["state"]["context"]) => {
    const state = store.getState()
    const { activeConsoleSessions } = state.externalReducer.consoleDetails
    const { connectedCallDetails, onHoldCallDetails } = state.externalReducer.callingDetails

    const contactUuids: string[] = []

    if ("nextSessionDetails" in workflowContext) {
        const { prevSessionDetails, nextSessionDetails } = workflowContext as ParkAndInitiateCallContext | ParkAndStartEditingContext | ParkAndResumeContext | MultiEditInitiateCallContext | MultiEditStartEditingContext
        contactUuids.push(prevSessionDetails?.contactUuid, nextSessionDetails?.contactUuid)
    } else {
        if ("contactUuid" in workflowContext) {
            contactUuids.push((workflowContext as DisconnectConsoleSessionContext).contactUuid)
        } else if ("callContextId" in workflowContext) {
            const contactUuidFromConsole = activeConsoleSessions.find(
                (consoleSession: IConsole) => consoleSession.additionalData?.callContextId === workflowContext.callContextId
            )?.roomUuid
            if (contactUuidFromConsole) {
                contactUuids.push(contactUuidFromConsole)
            } else {
                const contactUuidsFromCall = [connectedCallDetails, ...onHoldCallDetails].find(
                    (callDetails: IAVCallDetails) => callDetails.contextId === workflowContext.callContextId
                )?.participants.map(
                    (participant: IParticipantInfo) => participant.uuid
                )

                if (contactUuidsFromCall?.length) {
                    contactUuids.push(...contactUuidsFromCall)
                }
            }
        }
    }

    return contactUuids
}

export const checkIfConnectedCallIsTransitioning = (avCallStatuses: ICallStatus[]) => {
    const callStatuses: ECallStatus[] = avCallStatuses.map((callStatus) => callStatus.callStatus)
    const { CALLING, CONNECTING, RINGING } = ECallStatus
    return callStatuses.some((callStatus) => [CALLING, CONNECTING, RINGING].includes(callStatus))
}

export const checkIfCallMessageDisplayed = (avCallStatuses: ICallStatus[]) => {
    const callStatuses: ECallStatus[] = avCallStatuses.map((callStatus) => callStatus.callStatus)
    const { CALLDECLINED, NOT_ANSWERED, DISCONNECTED, FAILED } = ECallStatus
    return callStatuses.some((callStatus) => [CALLDECLINED, NOT_ANSWERED, DISCONNECTED, FAILED].includes(callStatus))
}
