"""
 Created on Thu Oct 27 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from enum import Enum


class EDBRoles(str, Enum):
    TECHNOLOGISTROLE = "technologistrole"
    EXPERTUSERROLE = "expertuserrole"
    INCOGNITOROLE = "expertuserincognitorole"
    PROTOCOLMANAGERROLE = "protocolmanagerrole"
    FRONTDESKROLE = "front-desk"
    SCHEDULERROLE = "scheduler-registrar"
    ADMINROLE = "adminrole"
    RELEASEMANAGER = "releasemanager"
    CPPADMINROLE = "cppadminrole"
    FSEREMOTE = "fseremote"


class EExcelRoles(str, Enum):
    ADMIN = "Admin"
    EXPERTUSER = "Expert User"
    TECHNOLOGIST = "Technologist"
    PROTOCOLMANAGER = "Protocol Manager"
    INCOGNITO = "Incognito"


class ESummaryStates(str, Enum):
    NEW = "new"
    INSERTION_FAILED = "insertion-failed"
    VALIDATION_FAILED = "validation-failed"
    EXISTING = "existing"
    SKIPPED = "skipped"


class EConnectionMode(Enum):
    KVM = "KVM"
    VNC = "VNC"
    RDP = "RDP"
