import React, { useEffect, useRef, useState } from "react";
import { Table, Switch, Input, Button } from "antd";
import "../../assets/common/CommonTables.scss";
import "./plantshutdown.scss";
import moment from "moment";
import ReportCalendarPopup from "../DatePickerComponent/ReportCalendarPopup";
import iconCalendar from "../../assets/images/icon_calendar.svg";
import TextArea from "antd/es/input/TextArea";
import Link from "antd/es/typography/Link";
import useOnClickOutside from "../../hooks/useOnClickOutside";

interface Props {
	data: any[];
	handleUpdate;
}
const PlantShutdownTable = ({ data, handleUpdate }: Props) => {
	const ref = useRef(null);
	// Data Formate work :Start
	const [plantRolloutTableData, setPlantRolloutTableData] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	const [tableData, setTableData] = useState<any>();
	const [commonExceptionFromDateFormat, setcommonExceptionFromDateFormat] =
		useState<any>();
	const [commonExceptionFromDate, setcommonExceptionFromDate] = useState<any>();
	const [showPicker, setShowPicker] = useState(false);
	const [showPicker2, setShowPicker2] = useState(false);
	const [linkActiveIndex, setLinkActiveIndex] = useState<any>(-1);
	useOnClickOutside(ref, () => setShowPicker(false));
	useOnClickOutside(ref, () => setShowPicker2(false));
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any, index: any) {
			return {
				key: index,
				affiliate: item.affiliateName,
				plantId: item.plantId,
				plant: item.plantName,
				country: item.countryName,
				abbreviation: item.abbreviation,
				startDate: item.startDate,
				endDate: item.endDate,
				// longitude: item.longitude,
				// longitude: <Input  value={item.longitude} />,
				// lattitude: item.lattitude,
				// lattitude: <Input  value={item.lattitude} />,
				shutdown: item.shutdown,
				// shutdown: (
				// 	<Switch
				// 		onChange={() => handleClick(item.plant, item.shutdown)}
				// 		checkedChildren="Yes"
				// 		unCheckedChildren="No"
				// 		checked={item.shutdown}
				// 	/>
				// ),
				remarks: item.remarks,
				update: "Update",
			};
		});
		setPlantRolloutTableData(mydata);
		setTableData(mydata);
	}, [data]);
	// Data Formate work :End

	const handleClick = (rowId, isRollout) => {
		// alert('handleClick'+affiliateId+isRollout);
		// handleUpdate(plantID, !isRollout);
		const newData = [...tableData];
		newData[rowId]["shutdown"] = !isRollout;
		setTableData(newData);
	};
	// const handleClick = (plantID, isRollout) => {
	// 	// alert('handleClick'+affiliateId+isRollout);
	// 	handleUpdate(plantID, !isRollout);
	// };
	const onInputChange = (key, index) => (e) => {
		const newData = [...tableData];

		newData[index][key] = e.target.value;

		setTableData(newData);
	};
	const handleStartDate = (date: any, rowId: any) => {
		setcommonExceptionFromDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");

		setcommonExceptionFromDateFormat(upatedDate);
		const newData = [...tableData];
		newData[rowId]["startDate"] = upatedDate;

		setTableData(newData);
		setShowPicker(false);
	};
	const handleEndDate = (date: any, rowId: any) => {
		setcommonExceptionFromDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonExceptionFromDateFormat(upatedDate);
		const newData = [...tableData];
		newData[rowId]["endDate"] = upatedDate;
		setTableData(newData);
		setShowPicker2(false);
	};
	const reportFromDate =
		commonExceptionFromDateFormat !== undefined
			? commonExceptionFromDateFormat
			: "";

	const startDateFunc = (text, index) => {
		return (
			<ReportCalendarPopup
				commonReportFromDateFormat={commonExceptionFromDateFormat}
				rowId={index}
				// commonReportToDateFormat={commonExceptionToDateFormat}
				commonReportFromDate={commonExceptionFromDate}
				// commonReportToDate={commonExceptionToDate}
				handleReportFromDate={handleStartDate}
				// handleReportToDate={handleExceptionToDate}
			/>
		);
	};
	const endDateFunc = (text, index) => {
		return (
			<ReportCalendarPopup
				commonReportFromDateFormat={commonExceptionFromDateFormat}
				rowId={index}
				// commonReportToDateFormat={commonExceptionToDateFormat}
				commonReportFromDate={commonExceptionFromDate}
				// commonReportToDate={commonExceptionToDate}
				handleReportFromDate={handleEndDate}
				// handleReportToDate={handleExceptionToDate}
			/>
		);
	};

	const columns = [
		{
			title: "AFFILIATE",
			dataIndex: "affiliate",
			key: "affiliate",
			width: "12%",
		},
		{
			title: "PLANT",
			dataIndex: "plant",
			key: "plant",
			width: "12%",
		},
		{
			title: "COUNTRY",
			dataIndex: "country",
			key: "country",
			width: "12%",
		},
		{
			title: "ABBREVIATION",
			dataIndex: "abbreviation",
			key: "abbreviation",
			width: "10%",
		},
		{
			title: "SHUTDOWN",
			dataIndex: "shutdown",
			key: "shutdown",
			width: "8%",
			render: (text, record, index) => (
				<Switch
					onChange={() => handleClick(index, text)}
					checkedChildren="Yes"
					unCheckedChildren="No"
					checked={text}
				/>
			),
		},
		{
			title: "START DATE",
			dataIndex: "startDate",
			key: "startDate",
			width: "15%",
			render: (text, record, index) => (
				// <Input value={text} onChange={onInputChange('longitude', index)} onBlur={()=> alert(text)} />
				<>
					<div id="ReportCalendar" style={{ width: "130px" }}>
						<input type="text" value={text} style={{ float: "left" }} />
						<a
							className="mobile-calendar"
							onClick={() => {
								setShowPicker(!showPicker), setLinkActiveIndex(index);
							}}
						>
							<img
								src={iconCalendar}
								title="calendar"
								style={{ float: "left" }}
							/>
						</a>
						{showPicker
							? linkActiveIndex == index
								? startDateFunc(text, index)
								: null
							: null}
					</div>
				</>
			),
		},
		{
			title: "END DATE",
			dataIndex: "endDate",
			key: "endDate",
			width: "15%",
			render: (text, record, index) => (
				// <Input value={text} onChange={onInputChange('endDate', index)} onBlur={() => alert(text)} />
				<>
					<div id="ReportCalendar" style={{ width: "130px" }}>
						<input type="text" value={text} style={{ float: "left" }} />
						<a
							className="mobile-calendar"
							onClick={() => {
								setShowPicker2(!showPicker2), setLinkActiveIndex(index);
							}}
						>
							<img
								src={iconCalendar}
								title="calendar"
								style={{ float: "left" }}
							/>
						</a>
						{showPicker2
							? linkActiveIndex == index
								? endDateFunc(text, index)
								: null
							: null}
					</div>
				</>
			),
		},
		{
			title: "REMARKS",
			dataIndex: "remarks",
			key: "remarks",
			width: "20%",
			render: (text, record, index) => (
				<TextArea
					value={text}
					onChange={onInputChange("remarks", index)}
					rows={4}
				/>
			),
		},
		{
			title: "UPDATE",
			dataIndex: "update",
			key: "update",
			width: "10%",
			render: (text, record, index) => (
				<Link className="cust-link" onClick={() => console.log(record)}>
					{text}
				</Link>
			),
		},
	];

	const mobileColumns = [
		{
			title: "AFFILIATE",
			dataIndex: "affiliate",
			key: "affiliate",
			width: 100,
		},
		{
			title: "PLANT",
			dataIndex: "plant",
			key: "plant",
			width: 100,
		},
		{
			title: "COUNTRY",
			dataIndex: "country",
			key: "country",
			width: 100,
		},
		{
			title: "ABBREVIATION",
			dataIndex: "abbreviation",
			key: "abbreviation",
			width: 100,
		},
		{
			title: "LONGITUDE",
			dataIndex: "longitude",
			key: "longitude",
			width: 100,
		},
		{
			title: "LATTITUDE",
			dataIndex: "lattitude",
			key: "lattitude",
			width: 100,
		},
		{
			title: "ROLLOUT",
			dataIndex: "rollout",
			key: "rollout",
			width: 100,
		},
	];
	return (
		<div ref={ref}>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Table
							rowKey="id"
							columns={columns}
							dataSource={plantRolloutTableData}
							tableLayout="fixed"
							pagination={{ pageSize: 10 }}
						/>
					);
				} else {
					return (
						<Table
							columns={mobileColumns}
							tableLayout={undefined}
							dataSource={plantRolloutTableData}
							pagination={{ pageSize: 10 }}
							scroll={{ x: "700px", y: 300 }}
						/>
					);
				}
			})()}
		</div>
	);
};
export default PlantShutdownTable;
