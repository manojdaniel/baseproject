import { IRoomDetails } from "@rocc/rocc-client-services"
import { PARENT_STORE } from "../constants/constants"
import { EUserPresence } from "../redux/interfaces/enums"

export const locations = [
    {
        id: 5,
        name: "Platinum Healthcare - Cambridge",
        address: "2 Canal Park, Cambridge, MA  - 02141",
        shortName: "PHSCM01",
        modalityList: [
            {
                id: 2,
                modality: "CT"
            },
            {
                id: 1,
                modality: "MR"
            }
        ],
        roomsFetched: true,
        locationContacts: [
            {
                id: "fd16",
                name: "Psycology tower - 1",
                phoneNumber: "101234567890",
                clinicalRole: "Frontdesk"
            },
            {
                id: "fd17",
                name: "Neurology Dept",
                phoneNumber: "918789666081",
                clinicalRole: "Frontdesk"
            }
        ],
        totalRooms: 0
    },
    {
        id: 4,
        name: "Platinum Healthcare - Newjersey",
        address: "80 Sculptors Way Hamilton Township, Newjersey, NJ - 08619",
        shortName: "PHSNJ02",
        modalityList: [
            {
                id: 2,
                modality: "CT"
            },
            {
                id: 1,
                modality: "MR"
            }
        ],
        roomsFetched: true,
        locationContacts: [
            {
                id: "fd4441",
                name: "FD1",
                phoneNumber: "2255234232112",
                clinicalRole: "Frontdesk"
            },
            {
                id: "fd4442",
                name: "Front Desk one",
                phoneNumber: "+919701348574",
                clinicalRole: "Frontdesk"
            },
            {
                id: "fd4443",
                name: "randomtext_algo",
                phoneNumber: "+1234567890",
                clinicalRole: "Frontdesk"
            },
            {
                id: "sr4444",
                name: "Scheduler one",
                phoneNumber: "+919701348574",
                clinicalRole: "Scheduler"
            }
        ],
        totalRooms: 0
    }]

export const rooms: IRoomDetails[] = [
    {
        identity: {
            id: 37,
            name: "CT Analytics Scanner 04",
            uuid: "e404fb07-1e53-4183-ad8b-5e6a4827abe1",
            address: "Trauma Department"
        },
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        address: "Trauma Department",
        locationId: 4,
        modalityId: "2",
        modality: "CT",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isConnecting: false,
        isRoomStarred: true,
        monitorsCount: 3,
        loggedInTech: {
            techName: "",
            techUuid: ""
        }
    },
    {
        identity: {
            id: 25,
            name: "CT Analytics Scanner 05",
            uuid: "d751ffae-4e64-42e5-84a3-318414ad8fcd",
            address: "Trauma Department"
        },
        address: "Trauma Department",
        monitorsCount: 3,
        locationId: 4,
        modality: "CT",
        modalityId: "2",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isRoomStarred: false,
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        isConnecting: false,
        loggedInTech: {
            techName: "",
            techUuid: ""
        }
    },
    {
        identity: {
            id: 29,
            name: "CT Analytics Scanner 06",
            uuid: "4b095617-e3c0-491d-84fc-4a12b3eefccb",
            address: "Trauma Department"
        },
        address: "Trauma Department",
        monitorsCount: 3,
        locationId: 4,
        modality: "CT",
        modalityId: "2",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isRoomStarred: false,
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        isConnecting: false,
        loggedInTech: {
            techName: "",
            techUuid: ""
        }
    }
]

export const actualMock = jest.requireActual("redux-micro-frontend")

export const mockedFn = {
    Get: jest.fn().mockReturnValue({
        GetGlobalState: jest.fn().mockReturnValue({
            [PARENT_STORE]: {
                configReducer: { configs: { ROCC_DEV: "false" } },
                appReducer: { version: 'test-123' }
            }
        }),
        CreateStore: jest.fn().mockReturnValue({}),
    })
}

export const mockedGlobalStore = {
    ...actualMock,
    GlobalStore: { ...mockedFn }
}
