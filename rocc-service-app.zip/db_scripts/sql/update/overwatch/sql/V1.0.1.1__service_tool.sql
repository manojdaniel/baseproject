-- Table Overwatch Customers added created_by and modified_by 
ALTER TABLE rocc_overwatch.customers ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.customers ADD COLUMN IF NOT EXISTS modified_by text;
-- Table Overwatch Raw Upload Data added created_by and modified_by 
ALTER TABLE rocc_overwatch.raw_upload_data ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.raw_upload_data ADD COLUMN IF NOT EXISTS modified_by text;
-- Table Overwatch Infrastructure Configurations added created_by and modified_by 
ALTER TABLE rocc_overwatch.infrastructure_configurations ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.infrastructure_configurations ADD COLUMN IF NOT EXISTS modified_by text;
-- Table Overwatch Service Jobs added created_by and modified_by 
ALTER TABLE rocc_overwatch.service_jobs ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.service_jobs ADD COLUMN IF NOT EXISTS modified_by text;
-- Table Overwatch Service Tasks added created_by and modified_by 
ALTER TABLE rocc_overwatch.service_tasks ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.service_tasks ADD COLUMN IF NOT EXISTS modified_by text;
-- Table Overwatch Service Job Transactions added created_by and modified_by 
ALTER TABLE rocc_overwatch.service_job_transactions ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE rocc_overwatch.service_job_transactions ADD COLUMN IF NOT EXISTS modified_by text;

