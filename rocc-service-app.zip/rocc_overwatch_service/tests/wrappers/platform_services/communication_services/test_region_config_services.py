"""
 Created on Thu Sep 17 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest import mock
from src.constants.constants import PHILIPS_ROCC_URI
from src.wrappers.platform_services.communication_services.region_config_services import fetch_region_config_data, update_region_config, create_new_region_config
from tests.mocks.mock_requests import MockResponse


def mocked_requests(*args, **kwargs):
    comm_profile_response = {"twilioSid": "v1",
                             "twilioAuthToken": "v2", "orgName": "v3"}
    switcher = {
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation/get_org_id": MockResponse(comm_profile_response, 200),
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation": MockResponse({"orgIdentity": "org_id"}, 201),
        f"/url{PHILIPS_ROCC_URI}/twilio/Account/sub_acc_name/twilio_sid/$isValid": MockResponse(True, 200),
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation/del_org_id": MockResponse(None, 204)
    }
    mocked_response = switcher.get(args[0], MockResponse(None, 200))
    if len(kwargs):
        pass
    return mocked_response


class TestRegionServices(unittest.TestCase):

    @mock.patch("src.wrappers.platform_services.communication_services.region_config_services.requests.get", side_effect=mocked_requests)
    def test_fetch_region_config_data(self, mock_post):
        response = fetch_region_config_data("/url", "token", "get_org_id")
        print("response::: ", response)
        mock_post.assert_called()
        self.assertIsNone(response)

    @mock.patch("src.wrappers.platform_services.communication_services.region_config_services.requests.get", side_effect=mocked_requests)
    def test_update_region_config(self, mock_post):
        response = update_region_config("/url", "data", "id", "token")
        self.assertFalse(response, mock_post)

    @mock.patch("src.wrappers.platform_services.communication_services.region_config_services.requests.get", side_effect=mocked_requests)
    def test_create_new_region_config(self, mock_post):
        response = create_new_region_config("/url", "data", "token")
        self.assertFalse(response, mock_post)


suite = unittest.TestSuite()

suite.addTest(TestRegionServices("test_fetch_region_config_data"))
suite.addTest(TestRegionServices("test_update_region_config"))
suite.addTest(TestRegionServices("test_create_new_region_config"))

unittest.TextTestRunner(verbosity=0).run(suite)
