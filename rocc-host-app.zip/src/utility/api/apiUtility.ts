/*
 * Created on Tue Sept 14 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { AxiosHandler } from "@rocc/rocc-http-client"
import { checkAndRefreshToken } from "../../services/authentication/AuthenticationService"
import { infoLogger } from "@rocc/rocc-logging-module"

export let roccHttpClient = new AxiosHandler()

export const setupAxiosHandler = (sessionId: string, userToken: React.MutableRefObject<string>, authUrl: string, dispatch: any, httpClient: AxiosHandler) => {
    const refreshTokenFn = () => checkAndRefreshToken({ token: userToken.current, sessionId, authUrl, dispatch })
    httpClient.initialize({ refreshTokenFn })
    roccHttpClient = httpClient
    infoLogger(`Refresh logic is updated to http client.`)
    return roccHttpClient
}

export const postCall = (params: any) => {
    return roccHttpClient.postCall({ url: params.url, data: params.body, headers: params.headers })
}

export const putCall = (params: any) => {
    return roccHttpClient.putCall({ url: params.url, data: params.body, headers: params.headers })
}

export const deleteCall = (params: any) => {
    return roccHttpClient.deleteCall({ url: params.url, data: params.body, headers: params.headers })
}

export const getCall = (params: any) => {
    return roccHttpClient.getCall({ url: params.url, data: params.body, headers: params.headers })
}

export const postService = (params: any) => {
    return roccHttpClient.postService({ url: params.url, data: params.body, headers: params.headers })
}

export const putService = (params: any) => {
    return roccHttpClient.putService({ url: params.url, data: params.body, headers: params.headers })
}

export const deleteService = (params: any) => {
    return roccHttpClient.deleteService({ url: params.url, data: params.body, headers: params.headers })
}

export const getService = (params: any) => {
    return roccHttpClient.getService({ url: params.url, data: params.body, headers: params.headers })
}

export const refreshToken = () => {
    return roccHttpClient.refreshToken()
}

export const safeURL = (url: string, uri: string) => url.endsWith(uri) ? url : `${url}${uri}`
