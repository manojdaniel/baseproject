/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import EndForm from "./EndForm"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: {
            onBoarded: false,
        },
        urls: {},
        configs: { CUSTOMER_PRIVACY_POLICY_URL: "www.privacypolicyurl.com" }
    })
}))

describe("EndFormonent", () => {
    let wrapper: any
    const props: any = {
        onBoardingSuccessStatus: true,
        value: true,
        consentData: "",
        getAgree: jest.fn(),
        getPrevious: jest.fn()
    }
    beforeEach(() => {
        wrapper = shallow(<EndForm {...props} />)
    })

    it("should render header", () => {
        const welcomeHeader = wrapper.find("Header")
        expect(welcomeHeader).toHaveLength(1)
    })

    it("should render item content", () => {
        const divs = wrapper.find("ItemContent")
        expect(divs).toHaveLength(1)
    })

    it("should render grid and 2 grid row", () => {
        expect(wrapper.find("Grid")).toHaveLength(1)
        expect(wrapper.find("GridRow")).toHaveLength(2)
    })
})
