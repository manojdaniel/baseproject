# DB scripts for rocc-overwatch
Database scripts for ROCC Overwatch solution(Service tool)

## Steps to execute
There are 2 sets of excutions:
- Schema and tables setup
- Tracking the above tables and relationships on graphql

### I. Schema and tables setup 
Follow one of the below 2 approaches to setup schemas based on if you have access to postgres container
1. Schema and tables setup with postgres container access
    a. Download/copy **db_scripts/sql** to postgres container
    b. Run the commands
        > cd db_scripts/sql
        > bash install.sh
    
2. Schema and tables setup if postgres container is not accesible and graphql is available
    a. Download/copy **db_scripts/sql**
    b. Open GraphQl console on a browser
    c. Open SQL terminal from _Data_ tab
    d. Copy and paste the contents of sql file: **db_scripts/sql/overwatch_schema.sql** in SQL terminal
    e. Exceute the sql commands from terminal

### II. Track tables and relastionships
1. Download/copy **db_scripts** to a local location
2. Run the commands
    > cd db_scripts/graphql
3. Update grqphql.cfg with respective configurations
    > vi graphql.cfg
    * graphql_secret_key= # Input respective GRAPHQL_ADMIN_SECRET
    * graphql_role="admin"
    * graphql_api= # Input graphql url like: "https://platinum-rocc.cloud.pcftest.com/v1/query"
4. Run the script:
    > bash setup_overwatch_relations.sh
