"""
 Created on Wed Mar 30 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest

from src.utility.interceptor import check_protected_route

class CheckProtectedRouteTestCase(unittest.TestCase):
    def test_protected_route_false(self):
        request_url = "/philips/rocc-overwatch/invalid"
        response = check_protected_route(request_url=request_url)
        self.assertFalse(response)
    def test_protected_route_true(self):
        request_url = "/philips/rocc-overwatch/Customer"
        response = check_protected_route(request_url=request_url)
        self.assertTrue(response)
    