// import {modeltotalalstackbarTransformer} from './ModelPerformanceTransformers';
// import "@testing-library/jest-dom/extend-expect";
// import {
//     getmodeltotalalertstatusbyasset_byplantid,
//   } from "../../DataModel/ModelPerformance";
// const sampleData = [
//     { assetId: 1, state: 'Overdue', count: 3 },
//     { assetId: 1, state: 'Closed', count: 5 },
//     { assetId: 2, state: 'Under', count: 2 },
//     { assetId: 2, state: 'Closed', count: 7 },
//   ];
  
//   describe('modeltotalalstackbarTransformer', () => {
//     test('transforms the sample data correctly', () => {
//       const expectedOutput = [
//         { assetId: 1, overdue: 3, closed: 5, under: null },
//         { assetId: 2, overdue: null, closed: 7, under: 2 },
//       ];
//       const actualOutput = modeltotalalstackbarTransformer(sampleData);
//       expect(actualOutput).toEqual(expectedOutput);
//     });
  
//     test('returns an empty array if the input is empty', () => {
//       const emptyInput = [];
//       const actualOutput = modeltotalalstackbarTransformer(emptyInput);
//       expect(actualOutput).toEqual([]);
//     });
  
//     // Add more test cases here as needed.
//   });
import {modeltotalalstackbarTransformer} from './ModelPerformanceTransformers';
import {
    getmodeltotalalertstatusbyasset_byplantid,
  } from "../../DataModel/ModelPerformance";

describe("Model Performance Transformer:  ", () => {
    test("group or transform: asset by plant id  ", () => {
      const data =
        [
            { assetId: '2K-3101', overdue: 3, closed: 6, under: null },
            { assetId: '2K-3201', overdue: 4, closed: 5, under: null },
            { assetId: '2K-4101', overdue: 3, closed: 4, under: null },
            { assetId: '2K-4103', overdue: null, closed: 1, under: null },
            { assetId: '2Y-3013B', overdue: 1, closed: 1, under: null },
            { assetId: '2Y-3606', overdue: 9, closed: 17, under: null },
            { assetId: '2Y-3607', overdue: 7, closed: 10, under: null },
            { assetId: '2Y-3608', overdue: 7, closed: 8, under: null },
            { assetId: '2Y-4123A', overdue: null, closed: 2, under: null },
            { assetId: '2Y-4123B', overdue: 1, closed: 2, under: null }
          ];
      

     const transformedData = modeltotalalstackbarTransformer(
        getmodeltotalalertstatusbyasset_byplantid
      );

      // Array length test
        expect(transformedData.length).toBe(data.length);

      // Equality test   
        expect(transformedData).toEqual(data);

        

    })
})
