/*
 * Created on Mon July 27 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
 
import { shallow } from "enzyme"
import React from "react"
import About from "./About"
 
jest.mock("react-redux", () => ({
    useSelector: () => ({
        version: "",
    })
}))
 

describe("About component", () => {
    let wrapper: any
    let props: any
 
    beforeEach(() => {
        props = {
            isModalOpen: true,
            closeModal: jest.fn(),
            companyName: "Philips",
            applicationTitle: "ROCC",
        }
        wrapper = shallow(<About {...props} />)
    })
    it("should render Modal", () => {
        expect(wrapper.find("Modal")).toHaveLength(1)
    })
 
    it("should render footer images", () => {
        const footer = wrapper.find("#aboutFooter")
        expect(footer).toHaveLength(1)
        const footerIcon = footer.at(0).find("InlineSVG")
        expect(footerIcon.at(0).prop("src")).toBe("ifu.svg")
    })
    it("should render Logo", () => {
        const divElement = wrapper.find("#logo")
        const logoIcon = divElement.at(0).find("InlineSVG")
        expect(logoIcon.prop("src")).toBe("logo.svg")
    })
})