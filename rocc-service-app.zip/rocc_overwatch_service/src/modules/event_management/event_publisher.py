"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

from src.loggers.log import create_logger
from src.wrappers.rabbitmq.producer import Producer, ProducerConfig
from src.wrappers.cf.cf_utility import get_rabbitmq_credentials
from src.constants.constants import ROUTING_KEY, TARGET_QUEUE
from src.wrappers.rabbitmq.rabbitmq_utility import compute_rmq_exchange_name

LOG = create_logger("Events Publisher")


def publish_message(payload, delay_queue=False):
    try:
        cf_rabbitmq_host = get_rabbitmq_credentials()
        # TODO: Need to remove localhost
        rabbitmq_host = cf_rabbitmq_host if cf_rabbitmq_host else os.environ.get("RABBITMQ_HOST", "localhost")
        server = Producer(ProducerConfig(host=rabbitmq_host,
                                         queue=payload[TARGET_QUEUE],
                                         routing_key=payload[ROUTING_KEY],
                                         exchange=compute_rmq_exchange_name(),
                                         delay_queue=delay_queue))
        server.publish(payload)

    except Exception as ex:
        LOG.error("Failed to publish a message with error: {}".format(ex))
