

/*
 * Created on Fri March 11 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { ReactElement, useEffect, useState } from "react"
import { PageChangeEvent, ProgressBar, Viewer, Worker } from "@react-pdf-viewer/core"
import "@react-pdf-viewer/core/lib/styles/index.css"
import styles from "./PDFViewer.scss"
import cx from "classnames"
import { Loader } from "semantic-ui-react"
import { useSelector } from "react-redux"
import { defaultLayoutPlugin, ToolbarProps, ToolbarSlot } from "@react-pdf-viewer/default-layout"
import "@react-pdf-viewer/default-layout/lib/styles/index.css"
import { PDF_VIEWER_SERVICE_WORKER } from "../../constants/constants"
import { IParentStore, parseIntBase10 } from "@rocc/rocc-client-services"
import { EManualType } from "../../types/types"

interface IPDFViewer {

    manualType: string
}

const PDFViewer = ({ manualType }: IPDFViewer) => {
    const { preSignedUrls } = useSelector((state: IParentStore) => ({ preSignedUrls: state.configReducer.preSignedUrls }))

    const handlePageChange = (e: PageChangeEvent) => {
        localStorage.setItem(manualType, `${e.currentPage}`)
    }
    const [manualUrl, setManualUrl] = useState("")
    const getPage = localStorage.getItem(manualType)
    const initialPage = getPage ? parseIntBase10(getPage) : 0
    useEffect(() => {
        setManualUrl(manualType === EManualType.ADMIN_MANUAL ? preSignedUrls.adminUserManual.url : preSignedUrls.expertUserManual.url)
    }, [manualUrl, manualType])

    const renderToolbar = (Toolbar: (props: ToolbarProps) => ReactElement) => (
        <Toolbar>
            {(slots: ToolbarSlot) => {
                const {
                    CurrentPageInput,
                    GoToNextPage,
                    GoToPreviousPage,
                    GoToFirstPage,
                    GoToLastPage,
                    NumberOfPages,
                    ShowSearchPopover,
                    Zoom,
                    ZoomIn,
                    ZoomOut,
                } = slots
                return (
                    <div className={cx(styles.pdfToolBar)}  >
                        <div className={cx(styles.toolBarButton)}>
                            <ShowSearchPopover />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <GoToFirstPage />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <GoToPreviousPage />
                        </div>
                        <div className={cx(styles.currentPage)}>
                            <CurrentPageInput />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <NumberOfPages />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <GoToNextPage />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <GoToLastPage />
                        </div>
                        <div className={cx(styles.zoom)}>
                            <ZoomOut />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <Zoom levels={[0.5, 0.75, 1, 1.25, 1.5, 2]} />
                        </div>
                        <div className={cx(styles.toolBarButton)}>
                            <ZoomIn />
                        </div>

                    </div>
                )
            }}
        </Toolbar>
    )

    const defaultLayoutPluginInstance = defaultLayoutPlugin({
        renderToolbar,
        sidebarTabs: (defaultTabs) => [
            defaultTabs[1]
        ],
    })
    return (
        manualUrl.length === 0 ? <Loader active={true} inline={true} size="big" className={cx(styles.loader)} /> :

            <Worker workerUrl={PDF_VIEWER_SERVICE_WORKER}>
                <div className={cx(styles.page)}>
                    <Viewer
                        fileUrl={manualUrl}
                        initialPage={initialPage}
                        onPageChange={handlePageChange}
                        plugins={[defaultLayoutPluginInstance]}
                        defaultScale={1.2}
                        renderLoader={(percentages: number) => (
                            <div className={cx(styles.progressBar)}>
                                <ProgressBar progress={Math.round(percentages)} />
                            </div>)}
                    />
                </div>
            </Worker>

    )

}

export default PDFViewer
