# Changelog

## [1.0.15](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.14...1.0.15) (2022-11-28)


### Bug Fixes

* bug fix for icons disabled after edit connection is esablished for other rooms ([45fa5c4](https://github.com/philips-internal/rocc-cc-home-app/commit/45fa5c4847f81abba3df8c94de9b1abf9fe9d530))
* bug fix for icons disabled after edit connection is esablished for other rooms ([6e7c3ee](https://github.com/philips-internal/rocc-cc-home-app/commit/6e7c3eefc22d05eca3f00e4820199fad2b4a3f2a))
* cancel btton and updated locales ([e5ae496](https://github.com/philips-internal/rocc-cc-home-app/commit/e5ae4960710dc6bd20d3056a531d6d1c68128b9c))
* cancel button remove for edit ([1a6e2b0](https://github.com/philips-internal/rocc-cc-home-app/commit/1a6e2b0f43947155eb71d0f6faf67cff06440fae))
* updated room card file ([cfa915e](https://github.com/philips-internal/rocc-cc-home-app/commit/cfa915e90de9a72a44f9a1653594014e7e905c5f))

## [1.0.14](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.13...1.0.14) (2022-11-22)


### Bug Fixes

* cancel button implementation ([29f866d](https://github.com/philips-internal/rocc-cc-home-app/commit/29f866d469a2a01d185fbb95920f004158d0b8ca))
* refactored code and added cond for view auth ([29a2681](https://github.com/philips-internal/rocc-cc-home-app/commit/29a2681040ad9bb240e606ee82ecdf3e5a60d602))
* removed styles ([69a6949](https://github.com/philips-internal/rocc-cc-home-app/commit/69a694903bb9a124b2df009ef2bc779422482cb6))
* test case updated ([d37b16a](https://github.com/philips-internal/rocc-cc-home-app/commit/d37b16afd913a701ba30ec3451a9efc9cf89fac9))

## [1.0.13](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.12...1.0.13) (2022-11-19)


### Bug Fixes

* sample commit to release build to QA ([9de29fa](https://github.com/philips-internal/rocc-cc-home-app/commit/9de29fa57d29524fc18626e5877f14fa51e263f8))

## [1.0.12](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.11...1.0.12) (2022-11-10)


### Bug Fixes

* send logs to azure with additional tags and org id ([f50d05f](https://github.com/philips-internal/rocc-cc-home-app/commit/f50d05fbf86c0f4f4ddcc941f91b2ced3c6e82cd))

## [1.0.11](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.10...1.0.11) (2022-10-19)


### Bug Fixes

* added helper for disconnect call ([f7cfe21](https://github.com/philips-internal/rocc-cc-home-app/commit/f7cfe21a3dfe65ceb7979c91eeb29d253b28b322))
* us-135595 home app title responsive fix ([6c70d0f](https://github.com/philips-internal/rocc-cc-home-app/commit/6c70d0f2e6a90a881630b130ae5bd75b83c5783f))

## [1.0.10](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.9...1.0.10) (2022-10-11)


### Bug Fixes

* release new version for the PR 142 ([06cb15f](https://github.com/philips-internal/rocc-cc-home-app/commit/06cb15f6cff2a58a83befe01d0405cb1e943f3e1))

## [1.0.9](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.8...1.0.9) (2022-10-03)


### Bug Fixes

* sample commit for autorelease ([e2968a3](https://github.com/philips-internal/rocc-cc-home-app/commit/e2968a39ec2d853fe6fdc828da337d612578c2fa))

## [1.0.8](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.7...1.0.8) (2022-09-28)


### Bug Fixes

* sample commit to release new version ([7a9b7e7](https://github.com/philips-internal/rocc-cc-home-app/commit/7a9b7e76e66e92ee3651f42b1dcb23bab11a0e58))

## [1.0.7](https://github.com/philips-internal/rocc-cc-home-app/compare/1.0.6...1.0.7) (2022-09-27)


### Bug Fixes

* sample commit for SL ref branch ([d56fce5](https://github.com/philips-internal/rocc-cc-home-app/commit/d56fce589cd026c304f0ccc72a28466fc1e84853))

## [1.0.6](https://github.com/philips-internal/rocc-cc-home-app/compare/v1.0.5...1.0.6) (2022-09-12)


### Bug Fixes

* remove prefix v from version ([e51c75a](https://github.com/philips-internal/rocc-cc-home-app/commit/e51c75a161f37a5b24fbcfb908af7fecf4ff27f1))

## [1.0.5](https://github.com/philips-internal/rocc-cc-home-app/compare/v1.0.4...v1.0.5) (2022-09-07)


### Bug Fixes

* enable autoversioing ([3a23458](https://github.com/philips-internal/rocc-cc-home-app/commit/3a2345867a239292cf06ca03ba8e21f668b00651))

## [1.0.4](https://github.com/philips-internal/rocc-cc-home-app/compare/v1.0.3...v1.0.4) (2022-09-07)


### Bug Fixes

* enable autoversioning ([ec28e98](https://github.com/philips-internal/rocc-cc-home-app/commit/ec28e980e3b4c01bdbac4883009171aea47da460))

## [1.0.3](https://github.com/philips-internal/rocc-cc-home-app/compare/v1.0.2...v1.0.3) (2022-08-11)


### Bug Fixes

* enable autoversioning ([54097fa](https://github.com/philips-internal/rocc-cc-home-app/commit/54097fa45d537b550ce221059d4eafc2bbcb0c41))
* enable production debugging ([57e7136](https://github.com/philips-internal/rocc-cc-home-app/commit/57e7136ed52f24fcb2f6e2b9c848054bcb9751b6))
