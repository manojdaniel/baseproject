import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AssetModelConfigTable from "./index";
import { Table } from "antd";
import { debug } from "console";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});
describe("AssetModelConfigTable", () => {
	const data = [
		{
			title: "model 1",
			x: "4.6",
			y: "8.3",
		},
		{
			title: "model 2",
			x: "4.6",
			y: "8.3",
		},
		{
			title: "model 3",
			x: "4.6",
			y: "8.3",
		},
	];

	beforeEach(() => {
		render(<AssetModelConfigTable data={data} />);
	});
	it("should render the component without errors", () => {
		render(<AssetModelConfigTable data={data} />);
		expect(Table).toHaveBeenCalled(); // Verify that Antd Table was called
	});
	it("should render table columns", () => {
		render(<AssetModelConfigTable data={data} />);
		debug;
		expect(screen.getByText("NAME")).toBeInTheDocument();
		expect(screen.getByText("X CO-ORDINATE")).toBeInTheDocument();
		expect(screen.getByText("Y CO-ORDINATE")).toBeInTheDocument();
	});

	// it("should render table data", () => {
	//     expect(screen.getByText("model 1")).toBeInTheDocument();
	//     expect(screen.getByText("4.6")).toBeInTheDocument();
	//     expect(screen.getByText("8.3")).toBeInTheDocument();
	// });
});
