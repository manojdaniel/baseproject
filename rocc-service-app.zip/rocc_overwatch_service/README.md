# ROCC Customer Provisioning Portal backend service

Backend Service for serving ROCC Customer Provisioning Portal UI app

## Deployment of ROCC Customer Provisioning Portal backend Service on Cloud

1. - Set CF credentials to enable this deployment

    > export CF_DOCKER_PASSWORD=_MyPassword_
    
    > export CF_USERNAME_USR=_MyCFUsername_

2. Initiate the setup:


    > cd rocc_overwatch_service/docker

    > Update the configurations in the file: _vars.yaml_

    > bash starter.sh <DEPLOY_MODE> <DOCKER_REPO> <IMAGE_TAG> <CF_USERNAME_USR> <CF_DOCKER_PASSWORD>

    > Ex: **_bash starter.sh cloud docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips latest $CF_USERNAME_USR $CF_DOCKER_PASSWORD_**

## Deployment of ROCC Customer Provisioning Portal backend Service on local

1. Update relevant configurations in file: _docker-compose.yaml_

    > cd rocc_overwatch_service/docker

    > vi _docker-compose.yaml
    
    - Update following configs:
        - **services > rocc_overwatch_service > environment >  FLASK_RUN_PORT**
        - **services > rocc_overwatch_service > ports**

2. Initiate the setup:

    > cd rocc_overwatch_service/docker

    > bash starter.sh <DEPLOY_MODE> <DOCKER_REPO> <IMAGE_TAG> <CF_USERNAME_USR> <CF_DOCKER_PASSWORD>

    > Ex: **_bash starter.sh local docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips latest $CF_USERNAME_USR $CF_DOCKER_PASSWORD_**
    
