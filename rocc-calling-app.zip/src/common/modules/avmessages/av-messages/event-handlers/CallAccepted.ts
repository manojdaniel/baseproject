/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger, sendLogsToAzure, warningLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { HTTP_STATUS, TABID, TIMEOUT_10 } from "../../../../../constants/constants"
import { setCallRingStatus, setIncomingCallDetails, setOutgoingCallDetails, setVideoCallStatus, updateCallTimeout } from "../../../../../redux/actions/callActions"
import { DEFAULT_INCOMING_CALL_DEATILS, DEFAULT_OUTGOING_CALL_DEATILS } from "../../../../../redux/reducers/callReducer"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"
import store from "../../../../../redux/store/store"
import { filterCallStatusByContextId, filterCallStatusByContextIdAndStatus, upsertCallStatus } from "../../../../helpers/callUtility"
import { getCallerID, getContextDetails, getRequesterActualUUID, getUserVideoAcceptedTab } from "../../messageService"
import { onCallReject, storeCallDetailsInRedux } from "../MessageHelper"
import { TRACKING_VALUES } from "../types"

const { CALLING, CONNECTED, CONNECTING, RINGING } = ECallStatus

interface ICallAccepted {
    contextId: string
    dispatch: Dispatch<any>
}

export const callAccepted = async (props: ICallAccepted) => {
    const { videoCallStatus, currentUser, urls } = initialiseReduxValues()

    const { contextId, dispatch } = props
    dispatch(updateCallTimeout({ contextId, timeoutId: setTimeout(() => "", TIMEOUT_10) }, false))
    dispatch(setCallRingStatus(false))

    if (filterCallStatusByContextIdAndStatus(videoCallStatus, contextId, [CALLING, CONNECTING, RINGING], true).length) {
        const contextDetails = await getContextDetails(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL)
        if (contextDetails.status === HTTP_STATUS.OK) {
            handleCallForSpecificTab(contextDetails, props)
            dispatch(setIncomingCallDetails(DEFAULT_INCOMING_CALL_DEATILS))
            dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
        } else {
            errorLogger("Failed to Accept the call")
        }
    } else {
        warningLogger(`Unable to find provided contextId in video Call Status: ${JSON.stringify(videoCallStatus)}`)
        if (filterCallStatusByContextId(videoCallStatus, contextId, true).length > 1) {
            /** Send Call Reject message since call is already rejected by the user but other user accepted the call */
            onCallReject({ contextId: contextId, setState: true, dispatch })
        }
    }
}

const handleCallForSpecificTab = async (contextDetails: any, props: ICallAccepted) => {
    const { data } = contextDetails
    const { videoCallStatus, currentUser, incomingCallDetails } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES
    const { contextId, dispatch } = props
    const currentUserContextDetail = await getUserVideoAcceptedTab(data)
    if (currentUserContextDetail.sessionTabId === `${currentUser.sessionId}_${sessionStorage.getItem(TABID)}`) {
        infoLogger(`Started call with contextId: - ${contextId}`)
        /* Check if any other call is going on, if yes then disconnect that call. */
        data.contextId = contextId
        data.callAcceptedTime = new Date()
        data.numOfParticipants = -1
        storeCallDetailsInRedux(data, dispatch)
        const updatedCallStatus = filterCallStatusByContextId(upsertCallStatus(contextId, CONNECTED), "", false)
        dispatch(setVideoCallStatus(updatedCallStatus))
        if (incomingCallDetails && incomingCallDetails.contextId === contextId) {
            sendLogsToAzure({ contextData: { component, event: `${event} Call Accepted`, Call_From: getCallerID(data.requester, data.participants), Event_By: getRequesterActualUUID(data.requester), ContextId: contextId } })
        }
    } else {
        dispatch(setVideoCallStatus(filterCallStatusByContextId(videoCallStatus, contextId, false)))
    }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const urls = fetchGlobalURLs()
    const { videoCallStatus } = state.callReducer
    const incomingCallDetails = state.callReducer.callDetails.incomingCall
    const { currentUser } = state.externalReducer
    return { currentUser, urls, videoCallStatus, incomingCallDetails }
}
