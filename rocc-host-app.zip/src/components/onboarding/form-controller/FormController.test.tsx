/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, IUserInfo, OnBoardingServices, EROCC_CONTEXT } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import { EUserPresence } from "../../../types/types"
import FormController from "./FormController"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: {
            onBoarded: true,
            allRoles: ["Admin", "Expert user"],
            uuid: "uuid"
        },
        urls: {},
    }),
    useDispatch: () => void (0),
}))

describe("FormController component", () => {
    let wrapper: any
    let formControllerId: any
    let formInvoker: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        wrapper = shallow(<FormController />)
        formControllerId = wrapper.find("#OnboardingFormController")
        formInvoker = wrapper.find("FormInvoker")
    })
    it("should render with the correct id", () => {
        expect(formControllerId).toHaveLength(1)
    })

    it("should render form invoker", () => {
        expect(formInvoker).toHaveLength(1)
    })

    it("should render steps", () => {
        const steps = formInvoker.prop("steps")
        expect(steps).toBeDefined()
    })

    it("should render postSubmitActions", () => {
        const postSubmitActions = formInvoker.prop("postSubmitActions")
        expect(postSubmitActions()).toBeDefined()
    })

    describe("setOnboardingFlagForUserService API call", () => {
        const user: IUserInfo = {
            accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
            orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "",
            clinicalRole: EClinicalRole.EXPERTUSER, secondaryUUID: "", secondaryName: "", description: "",
        }
        const props = {
            currentUser: user,
            adminUrl: "",
            roccContext: EROCC_CONTEXT.DEFAULT
        }
        it("Should get api data", async () => {
            const spy = OnBoardingServices.setOnboardingFlagForUserService(props.currentUser, props.roccContext, props.adminUrl, "")
            expect(spy).toBeDefined()
        })
    })

    describe("createCommunicationProfileService API call", () => {
        it("Should get api data", async () => {
            const spy = OnBoardingServices.createCommunicationProfileService(1, "", "", "", "")
            expect(spy).toBeDefined()
        })
    })

    describe("Terms and Conditions API call", () => {
        it("Should get api data", async () => {
            const spy = OnBoardingServices.getTermsAndConditionsService(1, "en_US")
            expect(spy).toBeDefined()
        })
    })

})
