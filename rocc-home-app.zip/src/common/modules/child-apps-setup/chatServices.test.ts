/*
 * Created on Mon Oct 10 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse } from "@rocc/rocc-client-services"
import { HTTP_STATUS } from "../../../constants/constants"
import { fetchCommunicationTokenService } from "./chatServices"

jest.mock("../../helpers/apicall", () => ({
    postService: () => ({
        status: HTTP_STATUS.OK,
        data: {
            twillioAccessToken: "token",
            channelSid: "sid"
        }
    })
}))

describe("chatServices tests", () => {
    it("fetchCommunicationToken test", async () => {
        const response = await fetchCommunicationTokenService("", "", "")
        expect(response.status).toEqual(EResponse.SUCCESS)
    })
})
