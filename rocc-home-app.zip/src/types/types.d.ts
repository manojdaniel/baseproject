declare module "app2/homeApp"
declare module "enzyme"
