/*
 * Created on Fri Jun 26 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionStatus, EConnectionType, IConsoleSession } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { CONSOLE_REQUESTER_UUID, INIT_MEDIA_ROOM_DETAILS } from "../../common/constants/constants"
import { resetConsoleSession, updatePidMapping } from "../../redux/actions/consoleActions"
import { IStore } from "../../redux/interfaces/types"
import { getActiveConnections } from "../../services/consoleService"
import { subscribeToConsolePidChange } from "../command-center-locations-controller/CommandCenterLocationsControllerService"

const SyncConsoleSessions = () => {
    const { applicationConnectionState, currentUser, consoleSessions, contextPidMappings } = useSelector((state: IStore) => ({
        applicationConnectionState: state.externalReducer.applicationConnectionState,
        currentUser: state.externalReducer.currentUser,
        consoleSessions: state.consoleReducer.consoleSessions,
        contextPidMappings: state.consoleReducer.contextPidMappings
    }))
    const dispatch = useDispatch()

    const subscribeToEmeraldPidChange = () => {
        subscribeToConsolePidChange(currentUser.uuid).subscribe((response: any) => {
            if (response.error) {
                errorLogger(`Subscribing to PID change failed with: ${errorParser(response.error)}`)
            } else if (response.data) {
                if (response.data.rocc_kvm_receiver_transaction.length) {
                    dispatch(updatePidMapping(response.data.rocc_kvm_receiver_transaction, contextPidMappings))
                }
            }
        })
    }

    const getActiveSessions = async () => {
        try {
            const { accessToken, uuid } = currentUser
            const sessions = await getActiveConnections(accessToken, `${CONSOLE_REQUESTER_UUID}${uuid}`)
            sessions.forEach((session: any) => {
                const activeSession = consoleSessions.find(consoleSession => consoleSession.contextId === session.contextId)
                session.displayCameraToggle = (session.connectionType === EConnectionType.PROTOCOL_MANAGEMENT && activeSession?.displayCameraToggle) ? true : false
                session.multiCameraList = []
                if (activeSession) {
                    session.mediaRoomDetails = activeSession.mediaRoomDetails
                    session.consoleStartTime = activeSession.consoleStartTime
                } else {
                    session.mediaRoomDetails = INIT_MEDIA_ROOM_DETAILS
                }
            })
            return sessions
        } catch (error) {
            errorLogger(`Getting active console sessions failed with: ${errorParser(error)}`)
        }
        return false
    }

    const synchronizeSessions = async () => {
        const sessions: IConsoleSession[] | false = await getActiveSessions()
        if (sessions) {
            dispatch(resetConsoleSession({ consoleSessions: sessions }))
        }
        subscribeToEmeraldPidChange()
    }

    useEffect(() => {
        if (applicationConnectionState === EConnectionStatus.ONLINE && currentUser.uuid) {
            synchronizeSessions()
        }
    }, [applicationConnectionState, currentUser.uuid])

    return <div id={"SyncConsoleSessions"} />
}

export default SyncConsoleSessions
