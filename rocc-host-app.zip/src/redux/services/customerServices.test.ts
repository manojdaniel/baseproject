/*
 * Created on Thu Jan 5 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { fetchLocationInfoForCurrentUser } from "./customerServices"

jest.mock("@rocc/rocc-client-services", () => ({
    ...jest.requireActual("@rocc/rocc-client-services"),
    graphqlClient: {
        query: jest.fn().mockReturnValue({"data":{"resourcesInfo":[{"resource_id":4,"device_uuid":"b7557801-5b19-492b-90a6-8dc03ea981eb","resource_name":"CT Scanner-015","resource_phone":"+1 4252432344","org_id":1,"org_name":"Platinum Health Systems","org_uuid":"e9101b82-493c-40df-b539-d605732ffbb4","resource_location":"Research Department","resource_identifier":"PHSSA01CT015","modality":"2:CT","org_identifier":"platinum","site_contacts":"200278:1:Neurology Dept:+919663602455:front-desk~200279:1:Frontdesk12thFeb:9199009989899:front-desk~200280:1:Frontdesk:123456677:front-desk~200281:2:Tower C:1234567890:scheduler-registrar","sites":"4:PHSSA01:Platinum Healthcare - Seattle:22100 Bothell Everett Hwy, Seattle, WA - 98021","user_favourite":true,"device_status":"Active","additional_attributes":null}, {"resource_id":8,"device_uuid":"e404fb07-1e53-4183-ad8b-5e6a4827abe1","resource_name":"MRI Scanner-018","resource_phone":"+919741794114","org_id":1,"org_name":"Platinum Health Systems","org_uuid":"e9101b82-493c-40df-b539-d605732ffbb4","resource_location":"Oncology Department","resource_identifier":"PHSSA01MR018","modality":"1:MR","org_identifier":"platinum","site_contacts":"159095:1:Psycology tower - 1:101234567890:front-desk","sites":"5:PHSCM01:Platinum Healthcare - Cambridge:2 Canal Park, Cambridge, MA  - 02141","user_favourite":true,"device_status":"Active","additional_attributes":{"ncc_edit": false, "is_ncc_warning_displayed": true}}, {"resource_id":12,"device_uuid":"c1a40ce5-1a29-4b3e-b26b-04773ab5f54c","resource_name":"CT Scanner 006","resource_phone":"+1 4252432344","org_id":1,"org_name":"Platinum Health Systems","org_uuid":"e9101b82-493c-40df-b539-d605732ffbb4","resource_location":"Research Department","resource_identifier":"PHSNJ02MR06","modality":"2:CT","org_identifier":"platinum","site_contacts":"212497:1:hpxhjkybpy:+918999181774:front-desk~212498:1:Front Desk one:+919701348574","sites":"3:PHSNJ02:Platinum Healthcare - Newjersey:80 Sculptors Way Hamilton Township, Newjersey, NJ - 08619","user_favourite":true,"device_status":"Active","additional_attributes":{"ncc_edit": true, "is_ncc_warning_displayed": true}}]}})
    }
}))

describe("computeFeatureList tests", () => {
    it("should return computed feature list", () => {
        fetchLocationInfoForCurrentUser("uuid").then(response => {
            expect(response.locations.length).toBe(3)
        })
    })
})
