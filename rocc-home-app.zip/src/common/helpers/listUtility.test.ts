/*
 * Created on Tue Oct 18 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, EUserPresence } from "@rocc/rocc-client-services"
import * as externalAppStates from "../../redux/store/externalAppStates"
import { getSiteName, sortContacts } from "./listUtility"

describe("listUtility test cases", () => {
    describe("getSiteName tests", () => {
        jest.spyOn(externalAppStates, "fetchGlobalLocations").mockReturnValue([{
            id: 1,
            name: "location1",
            shortName: "location1",
            address: "",
            modalityList: [],
            locationContacts: [],
            totalRooms: 1,
            roomsFetched: true,
        }])
        it("should return site name", () => {
            expect(getSiteName("", ["1"])).toBe("location1")
        })
    })
    describe("sortContacts tests", () => {
        it("should able to sort by presence", () => {
            const contacts = [
                { ...DEFAULT_CONTACT_INFO, status: EUserPresence.OFFLINE, uuid: "uuid1", name: "name1" },
                { ...DEFAULT_CONTACT_INFO, status: EUserPresence.AVAILABLE, uuid: "uuid2", name: "name2" },
            ]
            expect(sortContacts(contacts)[0].name).toBe("name2")
        })
    })
})
