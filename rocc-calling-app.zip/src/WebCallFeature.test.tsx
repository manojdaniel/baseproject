/*
 * Created on Wed Oct 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { shallow } from "enzyme"
import WebCallFeature from "./WebCallFeature"
import { mockCongifData } from "./mocks/commonMocks"
import globalStore from "./redux/store/globalStore"

const webCallClientinitialization = jest.fn().mockReturnValue("initializeClient")

jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: jest.fn(),
}))

jest.mock("./redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("@rocc/rocc-chat-library", () => ({
    ChatHeader: () => <>{"This is web call client"}</>,
    RoccChatClient: () => jest.fn().mockImplementation(
        () => ({ initializeClient: webCallClientinitialization })
    )
}))

describe("WebCallFeature Component", () => {
    let webCalWrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(mockCongifData)
        webCalWrapper = shallow(<WebCallFeature contactUuid={""} modalityName={""} />)
    })

    it("CallFeatures Component should render PersistGate component", () => {
        expect(webCalWrapper.find("PersistGate")).toHaveLength(1)
    })
})
