/*
 * Created on Mon Sept 07 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore, IUrls } from "@rocc/rocc-client-services"
import { PARENT_STORE } from "../../common/constants/constants"
import globalStore from "./globalStore"

interface IGetGloalStoreDetails {
    storeName: string
    reducerPath: string
}
export const getGlobalStoreDetails = (props: IGetGloalStoreDetails) => {
    const { storeName, reducerPath } = props
    const gState = globalStore.GetGlobalState()
    if (gState[storeName] && gState[storeName][reducerPath]) {
        return gState[storeName][reducerPath]
    }
}

/* Global states */
export const fetchGlobalNfccUpgradeStatus = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.appReducer.nfccUpgradeAvailable
}

export const fetchGlobalNfccBundleInfo = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.preSignedUrls.nfccBundle
}

export const fetchGlobalURLs = (): IUrls => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.urls
}
export const fetchGlobalContacts = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.userReducer.contacts || []
}
export const fetchGlobalConfigs = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.configs
}
export const fetchGlobalFeatureFlags = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.featureFlagsReducer.featureFlags
}
export const fetchGlobalPermissions = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.userReducer.permissions
}
export const fetchGlobalOrgUUID = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.orgId
}
export const fetchMetaSiteId = () => {
    const gState = globalStore.GetGlobalState()
    return gState?.CC_HOST?.customerReducer?.metaData?.id || -1
}

export const fetchGlobalCurrentUser = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.userReducer.currentUser
}

export const fetchGlobalLocations = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.locations
}

export const fetchRooms = () => {
    const gState = globalStore.GetGlobalState()
    return gState?.CC_HOST?.customerReducer?.rooms || []
}

export const fetchLocations = () => {
    const parentStore: IParentStore = globalStore.GetGlobalState()?.CC_HOST
    return parentStore.customerReducer?.locations || []
}
export const fetchGlobalOrgName = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.name
}

export const dispatchToParentStore = (action: any) => {
    globalStore.DispatchAction(PARENT_STORE, action)
}
