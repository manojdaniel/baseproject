import { AlertIDDropdownTransformer, SensorDropdownTransformer, affiliateDropdownTransformer, assetDropdownTransformer, currentstageDropdownTransformer, longLeadActionDropdownTransformer, modelDropdownTransformer, modelSensorDropdownTransformer, modelStatusDropdownTransformer, plantDropdownTransformer, regionDropdownTransformer, statusDropdownTransformer } from './DropdownTransformer';
  import "@testing-library/jest-dom/extend-expect";
  

describe('regionDropdownTransformer', () => {
  it('transforms data into an array of objects with value and label properties', () => {
    const data = [      { regionId: 1, regionName: 'Region A' },      { regionId: 2, regionName: 'Region B' },      { regionId: 3, regionName: 'Region C' }    ];
    const expected = [      { value: 0, label: 'All' },      { value: 1, label: 'Region A' },      { value: 2, label: 'Region B' },      { value: 3, label: 'Region C' }    ];
    const result = regionDropdownTransformer(data);
    expect(result).toEqual(expected);
  });
});
    describe('affiliateDropdownTransformer', () => {
      it('should transform data correctly', () => {
        const data = [      { affiliateId: 1, name: 'Affiliate 1' },      { affiliateId: 2, name: 'Affiliate 2' },      { affiliateId: 3, name: 'Affiliate 3' },    ];
    
        const expected = [      { value: 1, label: 'Affiliate 1' },      { value: 2, label: 'Affiliate 2' },      { value: 3, label: 'Affiliate 3' },    ];
    
        const result = affiliateDropdownTransformer(data);
    
        expect(result).toEqual(expected);
    
    
  });
});
  describe('plantDropdownTransformer', () => {
    it('transforms plant data into dropdown options', () => {
      const data = [      { plantId: 1, name: 'Plant 1' },      { plantId: 2, name: 'Plant 2' },      { plantId: 3, name: 'Plant 3' },    ];
  
      const expectedOutput = [      { value: 1, label: 'Plant 1' },      { value: 2, label: 'Plant 2' },      { value: 3, label: 'Plant 3' },    ];
  
      const result = plantDropdownTransformer(data);
  
      expect(result).toEqual(expectedOutput);
    });
  });
  
  describe('assetDropdownTransformer', () => {
    it('transforms asset data into dropdown options', () => {
      const data = [      { assetId: 1 },      { assetId: 2 },      { assetId: 3 },    ];
  
      const expectedOutput = [      { value: 1, label: 1 },      { value: 2, label: 2 },      { value: 3, label: 3 },    ];
  
      const result = assetDropdownTransformer(data);
  
      expect(result).toEqual(expectedOutput);
    });
  });
      describe('modelDropdownTransformer', () => {
        it('transforms data correctly', () => {
          const input = [      { assetSapId: '123', sensorGroupName: 'Group 1' },      { assetSapId: '456', sensorGroupName: 'Group 2' },      { assetSapId: '789', sensorGroupName: 'Group 3' },    ];
          const expectedOutput = [      { value: '123', label: 'Group 1' },      { value: '456', label: 'Group 2' },      { value: '789', label: 'Group 3' },    ];
          expect(modelDropdownTransformer(input)).toEqual(expectedOutput);
        });
      });
      describe('modelSensorDropdownTransformer', () => {
        it('should transform data into expected format', () => {
          const data = [
            { sensorGroupId: 1, modelName: 'Model A' },
            { sensorGroupId: 2, modelName: 'Model B' },
            { sensorGroupId: 3, modelName: 'Model C' },
          ];
      
          const expectedResult = [
            { value: 1, label: 'Model A' },
            { value: 2, label: 'Model B' },
            { value: 3, label: 'Model C' },
          ];
      
          const result = modelSensorDropdownTransformer(data);
      
          expect(result).toEqual(expectedResult);
        });
      });
      
      describe('modelStatusDropdownTransformer', () => {
        it('transforms data correctly', () => {
          const input = [      { status: 'Active' },      { status: 'Inactive' },      { status: 'Offline' },    ];
          const expectedOutput = [      { value: 'Active', label: 'Active' },      { value: 'Inactive', label: 'Inactive' },      { value: 'Offline', label: 'Offline' },    ];
          expect(modelStatusDropdownTransformer(input)).toEqual(expectedOutput);
        });
      });
      
      describe('SensorDropdownTransformer', () => {
        it('transforms data correctly', () => {
          const input = [      { sensorID: '001', sensorName: 'Sensor 1' },      { sensorID: '002', sensorName: 'Sensor 2' },      { sensorID: '003', sensorName: 'Sensor 3' },    ];
          const expectedOutput = [      { value: '001', label: 'Sensor 1' },      { value: '002', label: 'Sensor 2' },      { value: '003', label: 'Sensor 3' },    ];
          expect(SensorDropdownTransformer(input)).toEqual(expectedOutput);
        });
      });
      
      describe('Dropdown transformers', () => {
        const testData = [    { alertID: 1 },    { alertID: 2 },    { alertID: 3 },    { currentstage: 'Stage 1' },    { currentstage: 'Stage 2' },    { longleadaction: 'Action 1' },    { longleadaction: 'Action 2' },    { status: 'Active' },    { status: 'Inactive' },  ];
      
        test('Alert ID dropdown transformer', () => {
          const expected = [      { value: 1, label: 1 },      { value: 2, label: 2 },      { value: 3, label: 3 },    ];
          const result = AlertIDDropdownTransformer(testData);
          expect(result).toEqual(expected);
        });
      
        test('Current stage dropdown transformer', () => {
          const expected = [      { value: 'Stage 1', label: 'Stage 1' },      { value: 'Stage 2', label: 'Stage 2' },    ];
          const result = currentstageDropdownTransformer(testData);
          expect(result).toEqual(expected);
        });
      
        test('Long lead action dropdown transformer', () => {
          const expected = [      { value: 'Action 1', label: 'Action 1' },      { value: 'Action 2', label: 'Action 2' },    ];
          const result = longLeadActionDropdownTransformer(testData);
          expect(result).toEqual(expected);
        });
      
        test('Status dropdown transformer', () => {
          const expected = [      { value: 'Active', label: 'Active' },      { value: 'Inactive', label: 'Inactive' },    ];
          const result = statusDropdownTransformer(testData);
          expect(result).toEqual(expected);
        });
      });
      
