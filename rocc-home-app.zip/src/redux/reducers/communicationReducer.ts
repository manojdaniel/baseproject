/*
 * Created on Thu Sep 29 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Reducer } from "redux"
import { RoccChatClient } from "@rocc/rocc-chat-library"
import { ICommunicationReducer } from "../interfaces/types"
import { GLOBAL_UPDATE_CHAT_CLIENT } from "../actions/types"

export const initialStatesForCommunicationReducer: ICommunicationReducer = {
    chatClient: {} as RoccChatClient,
}

const communicationReducer: Reducer = (state: ICommunicationReducer = initialStatesForCommunicationReducer, action: any) => {
    switch (action.type) {
        case GLOBAL_UPDATE_CHAT_CLIENT: {
            return { ...state, chatClient: action.payload }
        }
        default:
    }
    return { ...state }
}

export default communicationReducer
