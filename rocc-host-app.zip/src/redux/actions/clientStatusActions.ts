/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { Dispatch } from "redux"
import { SET_APPILICATION_CONNECTION_STATE, GLOBAL_UPDATE_CHAT_CLIENT_STATUS, VERIFY_CURRENT_USER_PRESENCE } from "./types"
import {EConnectionStatus} from "@rocc/rocc-client-services"

export const setChatClientStatus = (chatClientStatus: EConnectionStatus) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_UPDATE_CHAT_CLIENT_STATUS, payload: { chatClientStatus } })
}

export const checkInternetConnectionState = (status: EConnectionStatus) => (dispatch: Dispatch) => {
    dispatch({ type: SET_APPILICATION_CONNECTION_STATE, applicationConnectionState: status })
}

export const verifyCurrentUserPresence = (presenceStatus: EUserPresence) => (dispatch: Dispatch) => {
    dispatch({ type: VERIFY_CURRENT_USER_PRESENCE, presenceStatus })
}
