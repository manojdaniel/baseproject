import React, { useState } from "react";
import "./Alert-Status.scss";

import statusAlerts from "../../assets/images/status-alerts.svg";
import statusClosed from "../../assets/images/status-closed.svg";
import imageActive from "../../assets/images/icon_Active.svg";
import imageOverdue from "../../assets/images/icon_Overdue.svg";
import imageUnderInvestigate from "../../assets/images/icon_Under_Investigate.svg";

interface Props {
	data: any[];
	page: string;
	healthIndex: any[];
}

const AlertStatus = ({ data, page }: Props) => {
	return (
		<>
			{page === "ALERT" ? (
				<>
					{data && data.length > 0 ? (
						<div id="alert-status">
							<div className="common">
								<div>
									<div>
										<img src={statusAlerts} title="statusAlerts" />
									</div>
									<div>
										<span id="value">{data[0].alerts}</span>
										<span>ALERTS</span>
									</div>
								</div>
								<div>
									<div>
										<img src={imageActive} title="Active" />
									</div>
									<div>
										<span
											id="value2"
											style={{
												color: "red",
											}}
										>
											{data[0].active}
										</span>
										<span>ACTIVE</span>
									</div>
								</div>
								<div>
									<div>
										<img
											src={imageUnderInvestigate}
											title="Under_Investigate"
										/>
									</div>
									<div>
										<span id="value2" style={{ color: "red" }}>
											{" "}
											{data[0].underInvestigation}
											<i> </i>
										</span>
										<span>UNDER INVESTIGATION</span>
									</div>
								</div>
								<div>
									<div>
										<img src={statusClosed} title="statusClosed" />
									</div>
									<div>
										<span id="value2">{data[0].closed}</span>
										<span>CLOSED</span>
									</div>
								</div>
								<div>
									<div>
										<img src={imageOverdue} title="Overdue_Investigate" />
									</div>
									<div>
										<span id="value2">{data[0].overdueInvestigation}</span>
										<span>OVERDUE INVESTIGATION</span>
									</div>
								</div>
							</div>
						</div>
					) : null}
				</>
			) : null}
		</>
	);
};

export default AlertStatus;
