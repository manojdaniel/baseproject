"""
 Created on Mon Oct 19 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import re

from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import CUSTOMER_INFO_DICT, ERROR_DICT, TEMPLATE_DETAILS, EMP_DICT, EMAIL_ID, EMAIL_FORMAT_REGEX, PHONE_NO, PHONE_NO_FORMAT_REGEX, ROOMS_DICT, ROOM_PHONE_NO_WITH_COUNTRY_CODE, SITES_DICT, FRONT_DESK_CONTACT_NO_WITH_COUNTRY_CODE, SCHEDULER_CONTACT_NO_WITH_COUNTRY_CODE, CUSTOMER_IDENTIFIER_CUSTOMER_INFO_SHEET
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import check_if_customer_eligible_for_cleanup, cleanup_customer_data, cleanup_raw_data_record, \
    update_customer_status_by_record_id
from src.modules.db_operations.raw_data_insertion.raw_data_insertion_exec import insert_existing_customer_information
from src.modules.file_operations import file_reader
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.utility.semver import parse_version

LOG = create_logger("FileUpload Service")


class FileUploadService():

    def __init__(self, service_user_uuid):
        self._profile_configs = get_profile_data()
        self._parent_org_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
        self._parent_service_token = self.fetch_service_token()
        self._service_user_uuid = service_user_uuid
        self._client = get_client_connection(
            access_token=self._parent_service_token, org_infra_uuid=self._parent_org_uuid)
        self._customer_identifier = False
        self._file_content = False
        self._book = False

    def __exit__(self, exc_type, exc_val, exc_tb):
        file_reader.release_book_handle(self._book)

    def fetch_service_token(self):
        try:
            token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                    issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                    private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            return token

        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(
                status_code=500, payload="Internal server error") from ex

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._parent_org_uuid:
            try:
                prepare_and_post_audit(event_type="File Upload Customer", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._parent_org_uuid, token=self._parent_service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.warning(f"Audit logging failed with error: {ex}")

    def process_raw_data(self, file_content):
        validation_exceptions = []
        try:
            self._file_content = file_content
            self._book = file_reader.get_book_handle(
                file_content=self._file_content)
            template_version_from_excel = file_reader.get_excel_template_version(
                book=self._book)
            invalid_template_version = self.validate_excel_template_versions(
                template_version_from_excel)
            if invalid_template_version:
                raise RoccException(status_code=400,
                                    title=f"Invalid excel template version: {template_version_from_excel}",
                                    payload="Found invalid template version in excel sheet")

            data_dict, validation_exceptions = file_reader.read_excel(book=self._book,
                                                                      client=self._client,
                                                                      template_version=template_version_from_excel)
            data_dict = self.convert_site_dict_idn_to_small_case(
                data_dict, SITES_DICT)
            data_dict[TEMPLATE_DETAILS] = {
                "version": str(template_version_from_excel)}
            customer_info_dict = data_dict[CUSTOMER_INFO_DICT]
            self._customer_identifier = customer_info_dict[0]["customer_identifier"]
            if len(customer_info_dict) != 1:
                msg = "More than one customer(or no customer) is present in the provided excel sheet"
                LOG.error(msg)
                raise RoccException(status_code=400,
                                    title="Invalid number of customers",
                                    payload=msg)
            customer_users = data_dict[EMP_DICT]
            valid_email = True
            for customer_user_key in customer_users:
                email = customer_users[customer_user_key][EMAIL_ID]
                valid_email = self.validate_email(email)
                if not valid_email:
                    break
            if valid_email is False:
                raise RoccException(status_code=400,
                                    title="Invalid email address of customers",
                                    payload="Invalid email address:"+email)

            validation_error_message = self.validate_phone_no_in_excel_sheets(
                data_dict)
            if validation_error_message:
                raise RoccException(status_code=400,
                                    title="Invalid phone no format of customers",
                                    payload=validation_error_message)

            if len(data_dict[ERROR_DICT]) == 0:
                response = insert_existing_customer_information(customer_identifier=self._customer_identifier,
                                                                client=self._client,
                                                                template_version_from_excel=template_version_from_excel,
                                                                data_dict=data_dict,
                                                                service_user_uuid=self._service_user_uuid)
                if response:
                    self.safe_audit(event_subtype="Import Data", action="E",
                                    outcome=0, code="File Upload", value="Success")
                    return {"status": 201, "file_identifier": response, "customer_identifier": self._customer_identifier}
                self.safe_audit(event_subtype="Import Data", action="E",
                                outcome=8, code="File Upload", value="Failed")
                raise RoccException(status_code=400, title="Customer information insertion failed",
                                    payload="Customer data couldn't be inserted")

            termination_msg = f"Excel data validation Failed.\nErrors: {data_dict[ERROR_DICT]} \nValidationExceptions: {validation_exceptions}"
            LOG.error(termination_msg)
            raise RoccException(status_code=400,
                                title="Excel data validation failed",
                                payload="Validation failed for uploaded excel file",
                                additional_info=validation_exceptions if len(validation_exceptions) > 0 else None)

        except RoccException as ex:
            raise ex

        except Exception as ex:
            LOG.exception(f"Failed to parse the File upload with error: {ex}")
            raise RoccException(status_code=400, title="Invalid excel file",
                                payload="Excel file couldn't be validated due to the several errors",
                                additional_info=validation_exceptions) from ex

    def validate_excel_template_versions(self, template_version_from_excel):
        invalid_version = False
        eligible_versions = os.environ["EXCEL_SUPPORTED_VERSIONS"]
        eligible_versions = [parse_version(x.strip())
                             for x in eligible_versions.split(",")]
        if template_version_from_excel not in eligible_versions:
            msg = f"Found invalid template version in excel sheet: {template_version_from_excel}. It should be one of: {list(map(str, eligible_versions))}"
            LOG.error(msg)
            invalid_version = True
        return invalid_version

    def cleanup_all_customer_data(self, client, customer_id, record_id):
        LOG.info(
            f"Initiating cleanup of all customer data with ID {customer_id}")
        update_customer_status_by_record_id(
            client=client, record_id=record_id, status="CANCELLED")
        cleanup_response = cleanup_customer_data(
            client=client, customer_id=customer_id)
        if cleanup_response and cleanup_response == 204:
            self.safe_audit(event_subtype="Cleanup raw data record", action="C",
                            outcome=0, code="Cleanup raw data record", value="Success")
            return {"success": True,
                    "message": "Cleanup successfull",
                    "status": 204}
        else:
            self.safe_audit(event_subtype="Cleanup raw data record", action="C",
                            outcome=8, code="Cleanup raw data record", value="Failed")
            return {"success": False,
                    "message": "Failed to clean up File upload record, please contact administrator",
                    "status": 500}

    def cleanup_single_record_entry(self, client, record_id):
        LOG.info(f"Initiating single record ID {record_id}")
        response = cleanup_raw_data_record(client=client,
                                           record_id=record_id)
        if response and response == 204:
            self.safe_audit(event_subtype="Cleanup raw data record", action="C",
                            outcome=0, code="Cleanup raw data record", value="Success")
            return {"success": True,
                    "message": "Record deleted successfully",
                    "status": 204}
        if response and response == 400:
            self.safe_audit(event_subtype="Cleanup raw data record", action="C",
                            outcome=8, code="Cleanup raw data record", value="Failed")
            return {"success": False,
                    "message": "Record is in use",
                    "status": 400}
        return False

    def cleanup_record(self, record_id):
        """
        If customer does not exist in metasite table AND does not have any transactions, then
           1. Change the status of the customer to CANCELLED
           2. Delete ALL raw upload entries for that customer
           3. Delete the customer from customers table
        Else
           1. Delete only the record id passed in the API request
        """
        try:
            LOG.info(f"Initiating cleanup of raw record with id: {record_id}")
            customer_id = check_if_customer_eligible_for_cleanup(
                client=self._client, record_id=record_id)
            if customer_id:
                return self.cleanup_all_customer_data(client=self._client, customer_id=customer_id, record_id=record_id)
            else:
                return self.cleanup_single_record_entry(client=self._client, record_id=record_id)

        except Exception as ex:
            LOG.exception(
                f"Failed to clean up File upload record with error: {ex}")
            self.safe_audit(event_subtype="Cleanup raw data record", action="E",
                            outcome=8, code="Cleanup raw data record", value="Failed")
            return {"success": False,
                    "message": "Failed to clean up File upload record, please contact administrator",
                    "status": 500}

    def validate_email(self, mail_id):
        valid_reg = EMAIL_FORMAT_REGEX
        is_valid = False
        if re.search(valid_reg, mail_id):
            is_valid = True
        return is_valid

    def validate_phone_no_format(self, phone_no):
        valid_reg = PHONE_NO_FORMAT_REGEX
        is_valid = False
        if re.search(valid_reg, phone_no):
            is_valid = True
        return is_valid

    def validate_phone_no_in_excel_sheets(self, data_dict):
        validation_error_message = ""
        customer_users = data_dict[EMP_DICT]
        scanner_details = data_dict[ROOMS_DICT]
        customer_info = data_dict[SITES_DICT]
        validation_error_message = self.find_phone_no_by_column(
            customer_users, PHONE_NO)
        if not validation_error_message:
            validation_error_message = self.find_phone_no_by_column(
                scanner_details, ROOM_PHONE_NO_WITH_COUNTRY_CODE)
        if not validation_error_message:
            validation_error_message = self.find_phone_no_by_column(
                customer_info, FRONT_DESK_CONTACT_NO_WITH_COUNTRY_CODE)
        if not validation_error_message:
            validation_error_message = self.find_phone_no_by_column(
                customer_info, SCHEDULER_CONTACT_NO_WITH_COUNTRY_CODE)
        return validation_error_message

    def find_phone_no_by_column(self, data, column):
        validation_error_message = ""
        for data_key in data:
            ph_no = data[data_key][column]
            valid_phone_no = self.validate_phone_no_format(ph_no)
            if not valid_phone_no:
                validation_error_message = f"Invalid {column} column {ph_no}"
                break
        return validation_error_message

    def convert_site_dict_idn_to_small_case(self, data, dict_key):
        if data:
            site_data = data[dict_key]
            for site_data_key in site_data:
                site_idn_data_small = site_data[site_data_key][CUSTOMER_IDENTIFIER_CUSTOMER_INFO_SHEET].lower(
                )
                site_data[site_data_key][CUSTOMER_IDENTIFIER_CUSTOMER_INFO_SHEET] = site_idn_data_small
            data[dict_key] = site_data
        return data
