"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import unittest
from unittest import mock
from unittest.mock import patch
from tests.mocks.mock_requests import MockResponse
from src.constants.config_keys import VAULT_HSDP_IDM_URL
from src.constants.constants import APPLICATION_JSON, AUTHORIZATION, CONTENT_TYPE, ORG_CTXT_HEADER, PHILIPS_ROCC_URI

from src.services.fse_user_services import FseUserService


class TestUserServices(unittest.TestCase):
    @patch("src.services.fse_user_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({"HSDP_IAM_URL": "org_infra_uuid", "PARENT_ORG_ID": "test1", "PARENT_SERVICE_AUTH_ISSUER": "111", "PARENT_SERVICE_AUTH_PRIVATE_KEY": "xyz"})))
    @patch("src.services.fse_user_services.create_service_token_from_vault", side_effect=lambda iam_url, issuer, private_key:  None)
    @patch("src.services.fse_user_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid: None)
    def test_populate_service_token(self, m_profile, m_st, m_client):
        m_st.return_value = "abc"
        m_client.return_value = "ssss"
        fse_user_service = FseUserService(service_user_uuid="", service_user_token="")
        returned_val = fse_user_service.update_orgs_user_mapping(deleted_org_ids=[1234, 123], new_org_ids=[112, 12], fse_user_id="")
        self.assertEqual(returned_val, True)
        with self.assertRaises(Exception):
            fse_user_service.is_user_with_valid_permission(resource_name="FSE_USER", action_name="FSE_USER_ADD")
        with self.assertRaises(Exception):
            fse_user_service.is_user_part_of_fse_group()
        m_profile.assert_called()
        m_client.assert_called()
        m_st.assert_called()

    @patch("src.services.fse_user_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({"HSDP_IAM_URL": "org_infra_uuid", "PARENT_ORG_ID": "test1", "PARENT_SERVICE_AUTH_ISSUER": "111", "PARENT_SERVICE_AUTH_PRIVATE_KEY": "xyz"})))
    @patch("src.services.fse_user_services.create_service_token_from_vault", side_effect=lambda iam_url, issuer, private_key:  None)
    @patch("src.services.fse_user_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid: None)
    @patch("src.services.fse_user_services.check_if_user_exists", side_effect=lambda client, email_id: False)
    @patch("src.services.fse_user_services.fetch_user_details_from_hsdp", side_effect=lambda idm_url, token, email_id: False)
    def test_manual_fse_user_insert(self, m_profile, m_st, m_client, m_user, m_hsdp):
        m_st.return_value = "abc"
        m_client.return_value = "ssss"
        m_profile.return_value = 123
        m_user.return_value = False
        m_hsdp.return_value = False
        fse_user_service = FseUserService(service_user_uuid="", service_user_token="")
        returned_val = fse_user_service.manual_fse_user_insert(user={}, user_email_id="xyz@yopmail.com")
        with self.assertRaises(Exception):
            fse_user_service.is_user_with_read_permission_hsdp("xyz@yopmail.com")
        self.assertEqual(returned_val, None)

    @patch("src.services.fse_user_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({"HSDP_IAM_URL": "org_infra_uuid", "PARENT_ORG_ID": "test1", "PARENT_SERVICE_AUTH_ISSUER": "111", "PARENT_SERVICE_AUTH_PRIVATE_KEY": "xyz"})))
    @patch("src.services.fse_user_services.create_service_token_from_vault", side_effect=lambda iam_url, issuer, private_key:  None)
    @patch("src.services.fse_user_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid: None)
    @patch("src.services.fse_user_services.check_if_user_exists", side_effect=lambda client, email_id: False)
    @patch("src.services.fse_user_services.fetch_user_details_from_hsdp", side_effect=lambda idm_url, token, email_id: False)
    def test_manual_fse_user_invite_deactivate_reactive(self, m_profile, m_st, m_client, m_user, m_hsdp):
        m_st.return_value = "abc"
        m_client.return_value = "ssss"
        m_profile.return_value = 123
        m_user.return_value = False
        m_hsdp.return_value = False
        fse_user_service = FseUserService(service_user_uuid="", service_user_token="")
        url = f"{PHILIPS_ROCC_URI}/usermgmt/UserActions"
        req_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: "abcd123", ORG_CTXT_HEADER: str({"Org-Id": "1234"})}
        body = {"action": "Invite", "locale": "en-US", "userId": "123", "isfseUserCheck": True}
        response_data, response_code = fse_user_service.reinvite_fse_user(url, body, req_headers)
        fse_user_service.reactivate_fse_user(url, body, req_headers)
        fse_user_service.delete_fse_user(url, req_headers)
        self.assertEqual(response_data, False)
        self.assertEqual(response_code, 500)

    @patch("src.services.fse_user_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({"HSDP_IAM_URL": "org_infra_uuid", "PARENT_ORG_ID": "test1", "PARENT_SERVICE_AUTH_ISSUER": "111", "PARENT_SERVICE_AUTH_PRIVATE_KEY": "xyz", VAULT_HSDP_IDM_URL: ""})))
    @patch("src.services.fse_user_services.create_service_token_from_vault", side_effect=lambda iam_url, issuer, private_key:  None)
    @patch("src.services.fse_user_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid: None)
    @patch("src.services.fse_user_services.check_if_user_exists", side_effect=lambda client, email_id: False)
    @patch("src.services.fse_user_services.fetch_user_details_from_hsdp", side_effect=lambda idm_url, token, email_id: False)
    @mock.patch("src.services.fse_user_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"access_token": "mocked_access_token", "total": 0}, 200))
    @mock.patch("src.services.fse_user_services.requests.delete",
                side_effect=lambda *args, **kwargs: MockResponse({"access_token": "mocked_access_token", "total": 0}, 200))
    def test_is_role_name_valid(self, m_profile, m_st, m_client, m_user, m_hsdp, m_get, m_delete):
        m_st.return_value = "abc"
        m_client.return_value = "ssss"
        m_profile.return_value = 123
        m_user.return_value = False
        m_hsdp.return_value = False
        m_get.return_value = {"access_token": "mocked_access_token", "total": 0}
        m_delete.return_value = {"access_token": "mocked_access_token", "total": 0}
        fse_user_service = FseUserService(service_user_uuid="", service_user_token="")
        fse_roles_from_db = [{"role": "fse_view_role"}]
        value = fse_user_service.is_role_name_valid("fse_view_role", fse_roles_from_db)
        user = {"email_id": "testuser@yopmail.com", "first_name": "test", "last_name": "user", }
        fse_user_service.prepare_user_obj(user, "123", True)
        with self.assertRaises(Exception):
            fse_user_service.prepare_user_obj({}, "")
        with self.assertRaises(Exception):
            fse_user_service.fetch_user_id_from_db({})
        with self.assertRaises(Exception):
            fse_user_service.is_email_format_valid("abc.c.")
        fse_user_service.update_fse_user_roles(["fse_edit_role"], "uuid")
        fse_user_service.fetch_email_template_fse("token")
        fse_user_service.delete_fse_user("url", {})
        with self.assertRaises(Exception):
            fse_user_service.create_email_service_fse("token")
        self.assertEqual(value, True)

    def test_initialization_failed(self):
        with self.assertRaises(Exception):
            FseUserService(service_user_uuid="", service_user_token="")
