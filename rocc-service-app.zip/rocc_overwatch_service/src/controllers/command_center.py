"""
 Created on Tue Nov 16 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import re
from flask import request, g
from flask_restful import Resource, reqparse, inputs

from src.services.command_center_services import CommandCenterService
from src.constants.constants import API_VERSION, AUTHORIZATION,  HELP_MESSAGE
from src.utility.semver import parse_version
from src.loggers.log import create_logger
from src.utility.utility import construct_negative_response
from src.exceptions.RoccException import RoccException

LOG = create_logger("CommandCenterController")


class CommandCenter(Resource):
    cc_parser = reqparse.RequestParser()
    cc_parser.add_argument(
        "customer_id", type=int, required=True, help=HELP_MESSAGE)
    cc_parser.add_argument(
        "seat_name", type=inputs.regex("^[a-zA-Z0-9_-]{1,30}$"), required=True, help="Seat Name is invalid.")
    cc_parser.add_argument(
        "seat_info", type=inputs.regex("^[a-zA-Z0-9_ \n.,-]{1,100}$"), required=True, help="Seat Information is invalid.")
    cc_parser.add_argument(
        "receivers", type=list, location="json", required=True, help=HELP_MESSAGE)
    cc_parser.add_argument(
        "registered_count", type=int, location="json", required=False, default=0, help=HELP_MESSAGE)

    def valid_receiver(self, receiver):
        valid_string_regex = "^[a-zA-Z0-9_ -]{1,30}$"
        valid_ip_regex = "^(\d{1,3}\.){3}(\d{1,3})$"
        if re.match(valid_string_regex, receiver["receiver_connection_name"]) \
                and re.match(valid_string_regex, receiver["monitor_name"]) \
                and re.match(valid_ip_regex, receiver["receiver_ip"]):
            return True
        return False

    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        body = self.cc_parser.parse_args()

        # TODO: Add receiver validation to request parser
        try:
            for receiver in body["receivers"]:
                if not self.valid_receiver(receiver):
                    raise Exception(f"Invalid receiver object: {receiver}")
        except Exception as ex:
            LOG.exception(f"Exception while parsing receivers, error: {ex}")
            return {"message": "Field: 'receivers' does not have all the required keys"}, 400

        try:
            LOG.info(f"Onboarding Command Center for customer {body['customer_id']}")
            user_token = request.headers[AUTHORIZATION]
            cc_service = CommandCenterService(g.userdetails, body["customer_id"], user_token)
            response = cc_service.onboard_command_center(body["seat_name"], body["seat_info"], body["receivers"])
            return {
                "command_center": response,
                "message": "Command Center onboarded successfully."
            }, 201
        except RoccException as ex:
            LOG.exception(f"Failed to initiate new command center onboarding with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to initiate new command center onboarding with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to initiate new command center onboarding, please contact administrator"), 500

    def put(self, seat_id):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        body = self.cc_parser.parse_args()

        # TODO: Add receiver validation to request parser
        try:
            for receiver in body["receivers"]:
                if not self.valid_receiver(receiver):
                    raise Exception(f"Invalid receiver object: {receiver}")
        except Exception as ex:
            LOG.exception(f"Exception while parsing receivers, error: {ex}")
            return {"message": "Field: 'receivers' does not have all the required keys"}, 400

        try:
            LOG.info(f"Updating Command Center {seat_id}  for customer {body['customer_id']}")
            user_token = request.headers[AUTHORIZATION]
            cc_service = CommandCenterService(g.userdetails, body["customer_id"], user_token)
            response = cc_service.update_command_center(seat_id, body["seat_name"], body["seat_info"], body["receivers"], body["registered_count"])
            return {
                "command_center": response,
                "message": f"Command Center details updated successfully for seat id: {seat_id}."
            }, 200
        except RoccException as ex:
            LOG.exception(f"Failed to update command center: {seat_id} with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to update command center {seat_id} with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to update command center, please contact administrator"), 500

    def delete(self, seat_id, customer_id):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            LOG.info(f"Offboarding Command Center {seat_id}  for customer {customer_id}")
            user_token = request.headers[AUTHORIZATION]
            cc_service = CommandCenterService(g.userdetails, customer_id, user_token)
            cc_service.delete_command_center(seat_id)
            return {
                "message": f"Command Center {seat_id} offboarded successfully."
            }, 200
        except RoccException as ex:
            LOG.exception(f"Failed to offboard command center: {seat_id} with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to offboard command center {seat_id} with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to offboard command center, please contact administrator"), 500
