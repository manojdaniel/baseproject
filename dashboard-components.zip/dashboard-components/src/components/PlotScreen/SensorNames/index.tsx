import React from "react";

interface Props {
	data: any[];
	handleMore: any;
}
const SensorNames = ({ data, handleMore }: Props) => {

	return (
		<div id="sensor-plot-right">
			<div id="sensor-names">
				<div className="sensor-title-box">
					<div className="right-title">SENSORS</div>
					<a className="cust-button" onClick={handleMore}>More Data</a>
				</div>
				
				{/* <a href="#" className="sensor-calendar"><span>Date:</span> <span className="calen-date">{sensorFromDateFormat} {sensorToDateFormat}</span> <span className="calen-icon">
                    <img src={iconCalendar} title="calendar" onClick={() => setShowPicker(!showPicker)} /></span></a> */}
				
				<div className="sensor-plot-list">
					{data.length > 0
						? data.map((item, index) => (
							<div key={index}>
								<span style={{ background: item.color }}></span>
								<span>{item.label}</span>
							</div>
						))
						: null}
				</div>
			</div>
		</div >
	);
};

export default SensorNames;
