import { render, screen, fireEvent } from "@testing-library/react";
import React from "react";
//import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import DropdownMultiselect from "./index";

test("should call handleChange when an option is selected", () => {
	const handleChange = jest.fn();
	const options = [
		{ value: "option1", label: "Option 1" },
		{ value: "option2", label: "Option 2" },
		{ value: "option3", label: "Option 3" },
	];
	render(<DropdownMultiselect options={options} handleChange={handleChange} />);

	const select = screen.getByRole("combobox");
	fireEvent.mouseDown(select);

	const option1 = screen.getByLabelText("Option 1");
	fireEvent.click(option1);

	expect(handleChange).toHaveBeenCalledWith([
		{ value: "option1", label: "Option 1" },
	]);
});
