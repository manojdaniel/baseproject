import React from "react";
import ReactDOM from "react-dom";

const App = () => (
  <><div>
    <div>Dashboard Table Applications</div>
  </div></>
);
ReactDOM.render(<App />, document.getElementById("app"));