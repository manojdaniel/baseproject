/*
 * Created on Mon Aug 1 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType } from "@rocc/rocc-client-services"
import { convertConnectionModeFromString, convertConnectionTypeFromString } from "./stringUtility"

describe("string utility Tests", () => {
    it("should return vnc connection mode", () => {
        expect(convertConnectionModeFromString("VNC")).toBe(EConnectionMode.VNC)
    })

    it("should return emerald connection mode", () => {
        expect(convertConnectionModeFromString("EMERALD")).toBe(EConnectionMode.EMERALD)
    })

    it("should return vnc connection mode", () => {
        expect(convertConnectionModeFromString("COMMANDCENTER")).toBe(EConnectionMode.CC)
    })

    it("should return full control connection type", () => {
        expect(convertConnectionTypeFromString("FULL_CONTROL")).toBe(EConnectionType.FULL_CONTROL)
    })

    it("should return view connection type", () => {
        expect(convertConnectionTypeFromString("VIEW")).toBe(EConnectionType.VIEW)
    })

    it("should return incognito connection type", () => {
        expect(convertConnectionTypeFromString("INCOGNITO_VIEW")).toBe(EConnectionType.INCOGNITO_VIEW)
    })

    it("should return pm connection type", () => {
        expect(convertConnectionTypeFromString("PROTOCOL_MANAGEMENT")).toBe(EConnectionType.PROTOCOL_MANAGEMENT)
    })
})
