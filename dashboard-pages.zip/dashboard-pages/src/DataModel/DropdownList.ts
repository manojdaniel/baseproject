
export const regionDropdownList = [
    {
        "regionId": 2,
        "regionName": "Asia"
    },
    {
        "regionId": 3,
        "regionName": "Americas"
    },
    {
        "regionId": 5,
        "regionName": "Middle East Africa"
    },
    {
        "regionId": 6,
        "regionName": "EUROPE"
    },
    {
        "regionId": 7,
        "regionName": "region test"
    },
    {
        "regionId": 8,
        "regionName": "WonderLand"
    },
    {
        "regionId": 9,
        "regionName": "middle east asia"
    },
    {
        "regionId": 10,
        "regionName": "Middle East"
    },
    {
        "regionId": 11,
        "regionName": "test region"
    }
]

export const affiliateDropdownList = [
    {
        "affiliateId": 2,
        "name": "SAFCO"
    },
    {
        "affiliateId": 4,
        "name": "YANPET"
    },
    {
        "affiliateId": 5,
        "name": "PETROKEMYA"
    },
    {
        "affiliateId": 7,
        "name": "KEMYA"
    },
    {
        "affiliateId": 8,
        "name": "SHARQ"
    },
    {
        "affiliateId": 9,
        "name": "YANSAB"
    },
    {
        "affiliateId": 10,
        "name": "UNITED"
    },
    {
        "affiliateId": 15,
        "name": "petrokemya_test"
    },
    {
        "affiliateId": 19,
        "name": "SAUDI KAYAN"
    },
    {
        "affiliateId": 20,
        "name": "ARRAZI"
    },
    {
        "affiliateId": 21,
        "name": "IBN ZAHR"
    },
    {
        "affiliateId": 22,
        "name": "IBNSINA"
    },
    {
        "affiliateId": 29,
        "name": "SABIC Agri-Nutrients"
    },
    {
        "affiliateId": 41,
        "name": "YANSAB_Copy"
    },
    {
        "affiliateId": 47,
        "name": "UNITED_Copy"
    },
    {
        "affiliateId": 48,
        "name": "ARRAZI_Copy"
    }
]

export const plantDropdownList = [
    {
        "plantId": 1,
        "plantName": "AN4",
    },
    {
        "plantId": 13,
        "plantName": "LOW LINEAR DENSITY POLYETHYLENE",
    },
    {
        "plantId": 14,
        "plantName": "POLYPROPYLENE",
    },
    {
        "plantId": 16,
        "plantName": "LINEAR ALPHA OLEFINS",
    },
    {
        "plantId": 17,
        "plantName": "OLF4",
    },
    {
        "plantId": 18,
        "plantName": "POLY2",
    },
    {
        "plantId": 19,
        "plantName": "AN5",
    },
    {
        "plantId": 24,
        "plantName": "poly propylene 3",
    },
    {
        "plantId": 27,
        "plantName": "high-density polyethylene",
    },
    {
        "plantId": 32,
        "plantName": "LINEAR ALPHA OLEFINS",
    },
    {
        "plantId": 34,
        "plantName": "METHANOL",
    },
    {
        "plantId": 35,
        "plantName": "POLYPROPYLENE 2",
    },
    {
        "plantId": 37,
        "plantName": "POLYETHYLENE_1_2",
    },
    {
        "affiliateId": 8,
        "plantId": 38,
        "plantName": "POLYETHYLENE_3_4",
    },
    {

        "plantId": 41,
        "plantName": "EG2",
    },
    {
        "plantId": 42,
        "plantName": "EG1",

    },
    {
        "plantId": 45,
        "plantName": "ethylene glycol 2",

    },
    {
        "plantId": 48,
        "plantName": "AN3-AMMONIA",

    },
    {
        "plantId": 49,
        "plantName": "SAN-IBB",

    },
]

export const assetDropdownList = [
    {
        "assetId": "2K-3101",
        "assetName": "Cycle Gas Compressor 4"
    },
    {
        "assetId": "2K-3201",
        "assetName": "Cycle Gas Compressor 5"
    },
    {
        "assetId": "2K-4101",
        "assetName": "Cycle Gas Compressor 6"
    },
    {
        "assetId": "2K-4103",
        "assetName": "VRC"
    },
    {
        "assetId": "2Y-3001A",
        "assetName": "JSW N2 compressors"
    },
    {
        "assetId": "2Y-3001B",
        "assetName": "JSW N2 compressors"
    },
    {
        "assetId": "2Y-3003A",
        "assetName": "JSW C2 compressors"
    },
    {
        "assetId": "2Y-3003B",
        "assetName": "JSW C2 compressors"
    },
    {
        "assetId": "2Y-3013A",
        "assetName": "JSW H2 compressors"
    },
    {
        "assetId": "2Y-3013B",
        "assetName": "JSW H2 compressors"
    },
    {
        "assetId": "2Y-3223",
        "assetName": "Extruder 5"
    },
    {
        "assetId": "2Y-3601",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3602",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3603",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3604",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3605",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3606",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3607",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3608",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3609",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3630",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-4123A",
        "assetName": "Extruder 6"
    },
    {
        "assetId": "2Y-4123B",
        "assetName": "Extruder 7"
    },
    {
        "assetId": "2Y-3665",
        "assetName": "ORC"
    },
    {
        "assetId": "2Y-3123",
        "assetName": "Extruder 4"
    }

]
export const modelDropdownList = [
    {
        "modelName": "Motor Performance",
        "sensorGroupId": 1592,
        "modelId": "1592"
    },
    {
        "modelName": "Motor Journal Bearing",
        "sensorGroupId": 1593,
        "modelId": "1593"
    },
    {
        "modelName": "Compressor Performance",
        "sensorGroupId": 1594,
        "modelId": "1594"
    },
    {
        "modelName": "Compressor Journal Bearing",
        "sensorGroupId": 1595,
        "modelId": "1595"
    },
    {
        "modelName": "Compressor Seal Gas Performance",
        "sensorGroupId": 1596,
        "modelId": "1596"
    },
    {
        "modelName": "Compressor Thrust Bearing",
        "sensorGroupId": 1597,
        "modelId": "1597"
    },
    {
        "modelName": "Compressor Performance_FE",
        "sensorGroupId": 7689,
        "modelId": "7689"
    }
]
export const modelStatusDropdownList = [
    {
        "status": "Alert"
    },
    {
        "status": "Asset-ON"
    },
    {
        "status": "Normal"
    },
    {
        "status": "Pi Data Disconnection"
    },
    {
        "status": "Poor Data"
    }
]

export const sensorDropdownList = [
    { "sensorID": 9365, "sensorGroupId": 957, "sensorName": "Seal Gas Vent To Flare 231FI414", "piName": "YN.POLY2.231FI414" },
    { "sensorID": 9366, "sensorGroupId": 957, "sensorName": "CG Seal Gas DP 231PDI417", "piName": "YN.POLY2.231PDI417" },
    { "sensorID": 9367, "sensorGroupId": 957, "sensorName": "CG Suction Pressure 231PI495", "piName": "YN.POLY2.231PI495" },
    { "sensorID": 9368, "sensorGroupId": 957, "sensorName": "CG Discharge Pressure 231PI496", "piName": "YN.POLY2.231PI496" },
    { "sensorID": 9369, "sensorGroupId": 957, "sensorName": "Comp Shaft Axial Pos 231ZI472AA", "piName": "YN.POLY2.231ZI472AA" }
]
export const alertIDDropdownList = [
    {
        "alertId": "64035",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132749",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132863",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132887",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "133503",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "136970",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "136975",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "139164",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    }
]
export const GetAlertManagementAffiliatesDropdownJSON = [
    {
        "affiliateId": 4,
        "affiliateName": "YANPET"
    }
]
export const GetAlertManagementPlantListDropdownJSON = [
    {
        "plantId": 1,
        "plantName": "AN4",
    },
    {
        "plantId": 12,
        "plantName": "ETHYLENE GLYCOL"
    },
    {
        "plantId": 13,
        "plantName": "LOW LINEAR DENSITY POLYETHYLENE"
    },
    {
        "plantId": 14,
        "plantName": "POLYPROPYLENE"
    },
    {
        "plantId": 27,
        "plantName": "high-density polyethylene"
    },
    {
        "plantId": 53,
        "plantName": "OLEFINS"
    },
    {
        "plantId": 82,
        "plantName": "UTILITY AND OFFSITE"
    },
    {
        "plantId": 89,
        "plantName": "PET"
    }
]
export const GetAlertManagementAssetIdDropdownJSON = [
    {
        "assetId": "2K-3101",
        "assetName": "Cycle Gas Compressor 4"
    },
    {
        "assetId": "2K-3201",
        "assetName": "Cycle Gas Compressor 5"
    },
    {
        "assetId": "2K-4101",
        "assetName": "Cycle Gas Compressor 6"
    },
    {
        "assetId": "2K-4103",
        "assetName": "VRC"
    },
    {
        "assetId": "2Y-3001A",
        "assetName": "JSW N2 compressors"
    },
    {
        "assetId": "2Y-3001B",
        "assetName": "JSW N2 compressors"
    },
    {
        "assetId": "2Y-3003A",
        "assetName": "JSW C2 compressors"
    },
    {
        "assetId": "2Y-3003B",
        "assetName": "JSW C2 compressors"
    },
    {
        "assetId": "2Y-3013A",
        "assetName": "JSW H2 compressors"
    },
    {
        "assetId": "2Y-3013B",
        "assetName": "JSW H2 compressors"
    },
    {
        "assetId": "2Y-3223",
        "assetName": "Extruder 5"
    },
    {
        "assetId": "2Y-3601",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3602",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3603",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3604",
        "assetName": "Atlas Copco N2 Compressor"
    },
    {
        "assetId": "2Y-3605",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3606",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3607",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3608",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3609",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-3630",
        "assetName": "Atlas Copco Air Compressor"
    },
    {
        "assetId": "2Y-4123A",
        "assetName": "Extruder 6"
    },
    {
        "assetId": "2Y-4123B",
        "assetName": "Extruder 7"
    },
    {
        "assetId": "2Y-3665",
        "assetName": "ORC"
    },
    {
        "assetId": "2Y-3123",
        "assetName": "Extruder 4"
    }
]
export const GetAlertManagementAlertIdDropdownJSON = [
    {
        "alertId": "64035",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132749",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132863",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "132887",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "133503",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "136970",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "136975",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    },
    {
        "alertId": "139164",
        "assetId": "2Y-3606",
        "assetDescription": "Atlas Copco Air Compressor"
    }
]
export const currentstageDropdownList = [
    {
        "currentstage": 'Alert Assignment'
    },
    {
        "currentstage": 'Department Action'
    },
    {
        "currentstage": 'Closed'
    }
]
export const longLeadActionDropdownList = [
    {
        "longleadaction": "YES",
        "value": 1
    },
    {
        "longleadaction": "NO",
        "value": 0
    }
]
export const statusDropdownList = [
    {
        "status": "work in progress"
    },
    {
        "status": "overdue"
    },
    {
        "status": "closed"
    },
]
