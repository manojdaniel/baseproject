/*
 * Created on Thu Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import PresenceClient from "./PresenceClient"
import React from "react"
import { DEFAULT_CONTACT_INFO, EResponse } from "@rocc/rocc-client-services"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import * as presenceService from "./presenceService"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn()
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const testState = {
    userReducer: {
        currentUser: { ...DEFAULT_CONTACT_INFO, uuid: "uuid", accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US" }
    },
    configReducer: {
        urls: { COMMUNICATION_SERVICES_URL: "http://localhost:" }
    },
    clientStatusReducer: {
        applicationConnectionState: "ONLINE",
    }
}

describe("PresenceClient render tests", () => {
    beforeEach(() => {
        useSelectorMock(testState)
    })
    it("should render Fragment", () => {
        withHooks(() => {
            jest.spyOn(presenceService, "fetchCommunicationClientDetails").mockReturnValue(Promise.resolve({
                status: EResponse.SUCCESS,
                tokenDetails: { communicationToken: "communicationToken", channelSid: "channelSid" }
            }))
            const wrapper = shallow(<PresenceClient />)
            expect(wrapper.find("Fragment")).toBeDefined()
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
