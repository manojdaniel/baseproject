/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState, useCallback } from "react"
import { Grid } from "semantic-ui-react"
import { useDispatch, useSelector } from "react-redux"
import cx from "classnames"
import styles from "./ProtocolTransfer.scss"
import en from "../../resources/translations/en-US"
import LeaveProtocolTransferConfirmDlg from "./leave-protocol-transfer-confirm-dlg/LeaveProtocolTransferConfirmDlg"
import { EProtocolTransferSteps, IConfirmModal, IStore, IWizardStep } from "../../redux/interfaces/types"
import CarouselWizard from "../../common/modules/carousel-wizard/CarouselWizard"
import { dispatchToParentStore, fetchGlobalCurrentUser } from "../../redux/store/externalAppStates"
import { IRoomDetails, EResponse, getTrackingEvent, EConnectionType } from "@rocc/rocc-client-services"
import ProtocolTransferStepProvider from "./ProtocolTransferStepProvider"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { GLOBAL_SET_ACTIVE_TAB } from "../../redux/actions/types"
import { ProtocolTransferConfirmModal } from "@rocc/rocc-console-components"
import { setInitiationRoute, setProtocolTransferStep, updateDestinationScanners } from "../../redux/actions/protocolTransferActions"
import { initConfirmModal, initLeaveProtocolTransferDlgModel } from "../../common/constants/constants"
import { connectToConsole, disconnectFromActiveConsole } from "../../common/helpers/consoleHelpers"
import { displayErrorModal } from "../../common/helpers/helpers"

export const EXCLUDED_SRC_MSG = "is selected as source scanner for protocol transfer and it is excluded from the room card group based on the current protocol transfer step"

const componentName = "ProtocolTransfer"
const ProtocolTransfer = () => {
    const {
        currentStep, selectedSource, selectedDestination, completedDestinations, activeSessions
    } = useSelector((state: IStore) => ({
        currentStep: state.protocolTransferReducer.currentStep,
        selectedSource: state.protocolTransferReducer.selectedSource,
        selectedDestination: state.protocolTransferReducer.selectedDestination,
        completedDestinations: state.protocolTransferReducer.completedDestinations,
        activeSessions: state.consoleReducer.consoleSessions
    }))

    const currentUser = fetchGlobalCurrentUser()
    const fileName = "ProtocolTransfer.tsx:"
    const dispatch = useDispatch()
    const [confirmModal, setConfirmModal] = useState(initConfirmModal)
    const [leaveProtocolTransferDlg, setLeaveProtocolTransferDlg] = useState(initLeaveProtocolTransferDlgModel)
    const { intl } = getIntlProvider()

    const cleanUpOnBrowserClose = useCallback(() => {
        const perfEntries = performance.getEntriesByType("navigation")
        if (perfEntries && perfEntries.length && (perfEntries[perfEntries.length - 1] as any).type !== "reload") {
            cleanUp()
        }
    }, [])

    useEffect(() => {
        dispatch(setInitiationRoute(location.hash))
        return () => {
            cleanUp()
        }
    }, [])

    useEffect(() => {
        window.addEventListener("beforeunload", cleanUpOnBrowserClose)
        return () => {
            window.removeEventListener("beforeunload", cleanUpOnBrowserClose)
        }
    }, [])

    const cleanUp = () => {
        disconnectFromScannerConsole("", () => { "" }, EConnectionType.FULL_CONTROL_USB)
    }

    const onPrevClicked = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: `Protocol transfer previous step from step: ${currentStep}`, Event_By: currentUser.uuid } })
        switch (currentStep) {
            case EProtocolTransferSteps.ConnectToSourceScanner: {
                disconnectFromScannerConsole(intl.formatMessage({
                    id: "content.consoleMessages.consoleDisconnectionFailed",
                    defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
                }), () => {
                    dispatch(setProtocolTransferStep(EProtocolTransferSteps.SelectSourceScanner))
                },
                    EConnectionType.FULL_CONTROL_USB)
            }
                break
            case EProtocolTransferSteps.SelectDestinationScanner: {
                dispatch(setProtocolTransferStep(EProtocolTransferSteps.SelectSourceScanner))
            }
                break
            case EProtocolTransferSteps.ConnectToDestinationScanner: {
                disconnectFromScannerConsole(intl.formatMessage({
                    id: "content.consoleMessages.consoleDisconnectionFailed",
                    defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
                }), () => {
                    dispatch(setProtocolTransferStep(EProtocolTransferSteps.SelectDestinationScanner))
                },
                    EConnectionType.FULL_CONTROL_USB)
            }
        }
    }

    const onNextClicked = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: `Protocol transfer next step from step: ${currentStep}`, Event_By: currentUser.uuid } })
        switch (currentStep) {
            case EProtocolTransferSteps.SelectSourceScanner:
                showConnectToConsoleConfirmDlg(EConnectionType.FULL_CONTROL_USB, selectedSource)
                break
            case EProtocolTransferSteps.SelectDestinationScanner:
                showConnectToConsoleConfirmDlg(EConnectionType.FULL_CONTROL_USB, selectedDestination)
                break
            case EProtocolTransferSteps.ConnectToSourceScanner:
                disconnectFromScannerConsole(intl.formatMessage({
                    id: "content.consoleMessages.consoleDisconnectionFailed",
                    defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
                }), () => {
                    dispatch(setProtocolTransferStep(currentStep + 1))
                },
                    EConnectionType.FULL_CONTROL_USB)
                break
            case EProtocolTransferSteps.ConnectToDestinationScanner:
                transferCompleted()
                disconnectFromScannerConsole(intl.formatMessage({
                    id: "content.consoleMessages.consoleDisconnectionFailed",
                    defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
                }), () => {
                    dispatch(setProtocolTransferStep(currentStep + 1))
                },
                    EConnectionType.FULL_CONTROL_USB)
                break
        }
    }

    const showConnectToConsoleConfirmDlg = (connectionType: EConnectionType, selectedScanner: IRoomDetails) => {
        const confirmModalObject: IConfirmModal = {
            show: true,
            onConfirm: () => {
                connectToScannerConsole(selectedScanner.identity.uuid, connectionType, () => {
                    dispatch(setProtocolTransferStep(currentStep + 1))
                })
                setConfirmModal(initConfirmModal)
                sendLogsToAzure({ contextData: { component: componentName, event: `Start protocol transfer for room: ${selectedScanner.identity.uuid}`, Event_By: currentUser.uuid } })
            },
            onCancel: () => {
                setConfirmModal(initConfirmModal)
                sendLogsToAzure({ contextData: { component: componentName, event: "Cancel protocol transfer dialog", Event_By: currentUser.uuid } })
            }
        }
        setConfirmModal(confirmModalObject)
    }

    const transferCompleted = () => {
        dispatch(updateDestinationScanners(selectedDestination.identity.uuid))
    }

    const connectToScannerConsole = async (roomUuid: string, connectionType: EConnectionType, postConnectionAction: () => void) => {
        if (await disconnectFromScannerConsole(intl.formatMessage({ id: "content.consoleMessages.previousConsoleDisconnectionFailed", defaultMessage: en["content.consoleMessages.previousConsoleDisconnectionFailed"] }), () => { "" }) === EResponse.SUCCESS) {
            const connectionStatus = await connectToConsole(roomUuid, connectionType, dispatch)
            if (connectionStatus.status === EResponse.SUCCESS) {
                postConnectionAction()
                infoLogger(`${fileName} UUID:${currentUser.uuid} 
                        Successfully connected ${getTrackingEvent(connectionType)} 
                        Console Connection: ${connectionStatus.contextId}`)
            } else if (connectionStatus.status === EResponse.ERROR) {
                displayErrorModal(intl.formatMessage({
                    id: "content.consoleMessages.consoleConnectionFailed",
                    defaultMessage: en["content.consoleMessages.consoleConnectionFailed"]
                }))
                if (connectionStatus.error) {
                    infoLogger(`${fileName} UUID:${currentUser.uuid} Failed to connect to console : ${connectionStatus.error}`)
                }
            }
        }
    }

    const disconnectFromScannerConsole = async (disconnectErrorMsg: string, postDisconnectAction: () => void, connectionType?: EConnectionType) => {
        const disconnectStatus = await disconnectFromActiveConsole(dispatch, connectionType)
        if (disconnectStatus.status === EResponse.SUCCESS) {
            if (activeSessions.length === 0) { dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: 0 } }) }
            postDisconnectAction()
            infoLogger(`${fileName} UUID: ${currentUser.uuid} 
                        Successfully disconnected ${getTrackingEvent(disconnectStatus.connectionType)} 
                        Console Connection: ${disconnectStatus.contextId}`)
            sendLogsToAzure({ contextData: { component: componentName, event: `${getTrackingEvent(disconnectStatus.connectionType)} Console Stopped` } })
            if (currentStep === EProtocolTransferSteps.ConnectToSourceScanner) { infoLogger(`${selectedSource.identity.name} ${EXCLUDED_SRC_MSG} `) }
        } else {
            if (disconnectErrorMsg) {
                displayErrorModal(disconnectErrorMsg)
            }
            if (disconnectStatus.error) {
                infoLogger(`${fileName} UUID:${currentUser.uuid} Failed to disconnect from console : ${disconnectStatus.error}`)
            }
        }
        return disconnectStatus.status
    }

    const isStepCompleted = (): boolean => {
        let isStepCompleted = true
        switch (currentStep) {
            case EProtocolTransferSteps.SelectSourceScanner: {
                isStepCompleted = !!selectedSource.identity
                break
            }
            case EProtocolTransferSteps.SelectDestinationScanner: {
                isStepCompleted = !!selectedDestination.identity
                break
            }
        }
        return isStepCompleted
    }

    const canEnablePrevButton = (): boolean => {
        let canEnablePrevButton = true
        if (currentStep === EProtocolTransferSteps.SelectDestinationScanner && completedDestinations.length > 0) {
            // When the user is on the Select Destination Page by selecting 'Transfer to Another Destination', 
            // prev button should be disabled
            canEnablePrevButton = false
        }
        return canEnablePrevButton
    }

    const canEnableNextButton = (): boolean => {
        return isStepCompleted()
    }

    const getActiveStepDetails = (): IWizardStep => {
        return {
            stepNumber: currentStep,
            content: <ProtocolTransferStepProvider
                stepNumber={currentStep}
                setLeaveProtocolTransferDlg={setLeaveProtocolTransferDlg}
            />,
            isPrevEnabled: canEnablePrevButton(),
            isNextEnabled: canEnableNextButton()
        }
    }

    const { onConfirm, onCancel, show } = confirmModal

    return (
        <>
            <Grid className={cx(styles.protocolTransferGrid)}>
                <Grid.Row className={cx(styles.protocolTransferGridRow)}>
                    <CarouselWizard activeStep={getActiveStepDetails()}
                        numberOfSteps={EProtocolTransferSteps.CompletionStep}
                        onPrevClicked={onPrevClicked}
                        onNextClicked={onNextClicked}
                        hideControlsOnLastStep={true}
                    />
                </Grid.Row>
            </Grid>
            {show &&
                <ProtocolTransferConfirmModal onStartClick={onConfirm} onCancelClick={onCancel} />
            }
            {leaveProtocolTransferDlg.show &&
                <LeaveProtocolTransferConfirmDlg
                    show={leaveProtocolTransferDlg.show}
                    postConfirmCallback={leaveProtocolTransferDlg.postConfirmCallback}
                    onDialogClosed={leaveProtocolTransferDlg.onDialogClosed}
                />
            }
        </>
    )
}

export default ProtocolTransfer
