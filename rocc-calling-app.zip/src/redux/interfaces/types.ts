/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EAppStates, ECallStatus, EConnectionStatus, ICallDetails, ICallStatus, IContactInfo, ILoggedInTech, IMissedCallData, INotificationMessage, IParticipantInfo, IPresenceData, IUserInfo, IWorkflow } from "@rocc/rocc-client-services"

export interface IStore {
  callReducer: ICallReducer
  externalReducer: IExternalReducer
}

export interface IWebCallTrigger {
  contactUuid: string
  showTitle?: boolean
  background?: boolean
  modalityName: string
}

export interface IPhoneCallTrigger {
  contactUuid: string
  phoneNumbers: Array<any>
  showTitle?: boolean
  dimOnHover?: boolean
  background?: boolean
}

export interface IExternalReducer {
  currentUser: IUserInfo
  appState: EAppStates
  sideBar: ISideBar
  notificationMessage: INotificationMessage
  rooms: IRoomInfo[]
  featureFlags: any,
  forceCleanUp: boolean
  workflows: IWorkflowInfo[]
  applicationConnectionState: EConnectionStatus
  permissions: any
}

export type IWorkflowInfo = Pick<IWorkflow, "id" | "type" | "state">

export interface IRoomInfo {
  roomUuid: string
  roomName: string
  loggedInTech: ILoggedInTech
  presenceData: IPresenceData
}

export interface ICallReducer {
  phoneCallStatus: ECallStatus
  channelSid: string
  videoCallStatus: ICallStatus[]
  recipient: IParticipantInfo
  callMessage: ICallMessage
  audioSource: string
  videoSource: string
  audioOutput: string
  volume: number
  callDetails: ICallDetails
  missedCalls: IMissedCallData[]
  callTimeout: ICallTimeout[],
  callRingStatus: boolean,
  desktopCallWindowFullScreen: boolean
  recentMissedCall: IMissedCallData
  conversationClientStatus: EClientStatus
  initiateWebCall: IInitiateWebCall
  initiatePhoneCall: IInitiatePhoneCall
  communicationVendor: ICommunicationVendor
}

export interface ISideBar {
  activeRightPanel: string
  displayRightSidePanel: boolean
  activeLeftPanel: string
  displayLeftSidePanel: boolean
  desktopFullScreen: boolean
}

export interface ICallMessage {
  messageType: string
  message: string
  contact: IContactInfo
}

export interface ICallTimeout {
  contextId: string
  timeoutId: NodeJS.Timeout
}

export interface IInitiateWebCall {
  contactUuid: string
  componentName?: string,
  modalityName: string
}

export interface IInitiatePhoneCall {
  contactUuid: string
  phoneNumber: string
  contactInfo?: IContactInfo
  componentName?: string
}

export interface ICommunicationVendor {
  vendorId: string
  vendorName: string
}
/*---------------------------------------------------*/
export enum EClinicalRole {
  DEFAULT = "",
  FRONTDESK = "Frontdesk",
  SCHEDULER = "Scheduler",
  NURSE = "Nurse",
  EXPERTUSER = "Expert user",
  INCOGNITO_ROLE = "Incognito role",
  PROTOCOL_MANAGER = "Protocol Manager",
  RADIOLOGIST = "Radiologist",
  TECHNOLOGIST = "Technologist",
  TRANSPORT = "Transport",
  DEVICE = "device",
  ADMIN = "Admin",
}

export enum ETokenType {
  CHAT = "CHAT",
  ADD_MEMBER = "ADD_MEMBER",
  REMOVE_MEMBER = "REMOVE_MEMBER",
}

/* Enums */
export enum EAvSettingsType {
  AUDIO_INPUT = "audioSource",
  VIDEO_INPUT = "videoSource",
  AUDIO_OUTPUT = "audioOutput",
}

export enum EClientStatus {
  AVAILABLE = "AVAILABLE",
  ONLINE = "ONLINE",
  OFFLINE = "OFFLINE",
  FAILED = "FAILED",
}

export enum ETrackKind {
  VIDEO = "video",
  AUDIO = "audio",
}
