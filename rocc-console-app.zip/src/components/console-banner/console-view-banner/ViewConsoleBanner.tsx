/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionState, EConnectionType, EOperationStatus, EPosition, TransactionValue } from "@rocc/rocc-client-services"
import { RoomBannerCameraControls, RoomBannerUserDetails, SpokeNotificationComponent } from "@rocc/rocc-console-components"
import cx from "classnames"
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { initiateConsoleSwitchOperation, roomMonitoringMessage } from "../../../common/helpers/consoleUtility"
import { getSpokeMessage, hasActiveVidoCallWithRoom, isNonCommandCenterViewConnection, isQualifyCheckBoxChecked, isRoomMonitoringEnabledForCC } from "../../../common/helpers/helpers"
import MultiCameraController from "../../../common/modules/multi-camera/controller/MultiCameraController"
import ConsoleTrigger from "../../../ConsoleTrigger"
import { IActiveSessionWithMultiCamera, IStore } from "../../../redux/interfaces/types"
import styles from "./ViewConsoleBanner.scss"
import cameraStyles from "../../../common/modules/multi-camera/gallery-view/MultiCameraGalleryView.scss"

const WebCallFeature = React.lazy(() => import("roccCalling/WebCallFeature").catch(() => false))
const PhoneCallFeature = React.lazy(() => import("roccCalling/PhoneCallFeature").catch(() => false))

const ViewConsoleBanner = (props: IActiveSessionWithMultiCamera) => {
    const {
        rooms, featureFlags,
        initialized, connectedCallDetails, onHoldCallDetails, consoleOperation, receivers,
        displayLeftSidePanel, permissions
    } = useSelector((state: IStore) => ({
        rooms: state.externalReducer.rooms,
        featureFlags: state.externalReducer.featureFlags,
        initialized: state.consoleReducer.commandCenterDetails.initialised,
        connectedCallDetails: state.externalReducer.callDetails.connectedCallDetails,
        onHoldCallDetails: state.externalReducer.callDetails.onHoldCallDetails,
        consoleOperation: state.consoleReducer.consoleOperation,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        displayLeftSidePanel: state.externalReducer.displayLeftSidePanel,
        permissions: state.externalReducer.permissions
    }))

    const { currentSession, roomUuid, buttonTitle, technologistName, displayCameraState, showCameraSettings, showCameraControls, multiCameraDisabled, rightSidePanel, handleCameraSettingsClick, handleCameraSliderClick } = props
    const dispatch = useDispatch()
    useEffect(() => {
        if (currentSession.connectionStatus === EConnectionState.PARKED && !hasActiveVidoCallWithRoom(roomUuid) && consoleOperation.operationStatus === EOperationStatus.IDLE) {
            initiateConsoleSwitchOperation({
                newConnectionType: EConnectionType.VIEW,
                transactionState: TransactionValue.RESUMED,
                currentSession,
                dispatch,
            })
        }
    }, [connectedCallDetails, onHoldCallDetails])

    const getPhoneNumber = () => {
        const phoneNumbers = []
        const room = rooms.find(room => room.roomUuid === roomUuid)
        if (room) {
            phoneNumbers.push({ key: room.phoneNumber, text: room.phoneNumber, value: room.phoneNumber })
        }
        return phoneNumbers
    }

    const widthStyle = displayLeftSidePanel ? styles.narrowWidth : styles.maxWidth

    return (
        <div className={cx(styles.mainContainer, rightSidePanel && styles.sideBarOpenStyles)} id={"viewSessionContainer"}>
            {isNonCommandCenterViewConnection(currentSession, roomUuid) && isQualifyCheckBoxChecked(roomUuid) &&
                <SpokeNotificationComponent message={getSpokeMessage(permissions, initialized)} />}
            <div className={styles.roomBannerContainer} id="viewBannerContainer">
                <RoomBannerUserDetails name={technologistName} />
                {showCameraControls && <RoomBannerCameraControls
                    displayCamerasState={displayCameraState}
                    showCameraSettings={showCameraSettings}
                    isDisabled={multiCameraDisabled}
                    handleCameraSettingsClick={() => handleCameraSettingsClick()}
                    handleCameraSliderClick={() => handleCameraSliderClick()}
                />}
                <div className={styles.callButtons} id="bannerButtons">
                    <div className={styles.webCallIcon}>
                        <WebCallFeature contactUuid={roomUuid} isDisabled={false} background={true} showTitle={buttonTitle} />
                    </div>
                    <div className={styles.phoneCallIcon}>
                        <PhoneCallFeature contactUuid={roomUuid} phoneNumbers={getPhoneNumber()} isDisabled={false} showTitle={buttonTitle} background={true} />

                    </div>
                </div>
                <div className={styles.consoleButtons}>
                    {
                        currentSession.connectionStatus === EConnectionState.PARKED ?
                            <div>
                                <ConsoleTrigger
                                    connectionType={EConnectionType.VIEW}
                                    connectionState={EConnectionState.PARKED}
                                    roomUuid={roomUuid}
                                    showTitle={buttonTitle}
                                    iconPosition={EPosition.VERTICAL}
                                />
                            </div> :
                            <>
                                <div className={styles.viewButton}>
                                    <ConsoleTrigger
                                        connectionType={EConnectionType.VIEW}
                                        roomUuid={roomUuid}
                                        showTitle={buttonTitle}
                                        iconPosition={EPosition.VERTICAL}
                                    />
                                </div>
                                <div>
                                    <ConsoleTrigger
                                        connectionType={EConnectionType.FULL_CONTROL}
                                        roomUuid={roomUuid}
                                        showTitle={buttonTitle}
                                        iconPosition={EPosition.VERTICAL}
                                    />
                                </div>
                            </>
                    }

                </div>

            </div>
            {
                isRoomMonitoringEnabledForCC(featureFlags, currentSession) ?
                    receivers.length > 1 ? <div className={styles.cameraContainer}>{roomMonitoringMessage(widthStyle, cameraStyles)}</div>
                        : <></>
                    : <div className={styles.cameraContainer}><MultiCameraController consoleSession={currentSession} /></div>
            }
        </div >
    )
}

export default ViewConsoleBanner
