/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ICallStatus, IRoomDetails } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { checkIfMultiEditEnabled, getRoomUuidsFromWorkflowContext } from "../../common/helpers/helpers"
import { TRACKED_HOME_WORKFLOWS } from "../../constants/constants"
import { EConnectionType, IModalityInfo, IProtocolTranferProps, IRoomCard, IRoomCardFlags, IRoomCardFooter, IRoomConnectionProps, IUserNameComponentProps } from "../../lib/types"
import { IConsole, IWorkflowInfo } from "../../redux/interfaces/types"
import { fetchGlobalReceivers } from "../../redux/store/externalAppStates"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"

const { intl } = getIntlProvider()
const getUsernameProps = (loggedInTech: any) => {
    const userProps: IUserNameComponentProps = {
        techUserName: loggedInTech.techName,
        techUserId: loggedInTech.techUuid,
    }
    return userProps
}
export const checkIfRoomHasActiveSession = (uuid: string, activesessions: IConsole[]) => {
    const roomActive = activesessions.find((session) => session.roomUuid === uuid)
    return roomActive ? true : false
}

const getRoomCardFlags = (roomCardFlags: any, uuid: string, activeSessions: IConsole[]) => {
    const flags: IRoomCardFlags = {
        isMultiConsoleFlagEnabled: false,
        isRoomActiveSession: false,
        protocolTransferFlagEnabled: false,
        isStarredFlagEnabled: false
    }
    const permissions = store.getState().externalReducer.permissions
    flags.isMultiConsoleFlagEnabled = roomCardFlags["rocc-multi-console"] ? true : false
    flags.isRoomActiveSession = checkIfRoomHasActiveSession(uuid, activeSessions)
    flags.protocolTransferFlagEnabled = roomCardFlags["rocc-protocol-transfer"] ? true : false
    flags.isStarredFlagEnabled = !!permissions.RESOURCE_STARRED_ROOMS
    /*TODO: all other flags will be updted once we have the actual reducer */
    return flags
}

const isFooterDisabled = (uuid: string, activeSessions: IConsole[], phoneCallStatus: ECallStatus, videoCallStatus: ICallStatus[]) => {
    const isEditSessionGoingOn = checkIfEditSessionGoingOn(activeSessions, uuid)
    const isCallGoingOn = checkIfCallIsGoingOn(phoneCallStatus, videoCallStatus)
    return !checkIfMultiEditEnabled() && (isEditSessionGoingOn || isCallGoingOn)
}

const getFooterProps = (room: IRoomDetails, activeSessions: IConsole[], phoneCallStatus: ECallStatus, videoCallStatus: ICallStatus[], modalityName: string) => {
    const footerProps: IRoomCardFooter = {
        phoneNumbers: [{
            key: room.phoneNumber,
            value: room.phoneNumber,
            text: room.phoneNumber,
        }],
        roomUuid: room.identity.uuid,
        isDisabled: isFooterDisabled(room.identity.uuid, activeSessions, phoneCallStatus, videoCallStatus),
        modalityName: modalityName,
        roomName: room.identity.name,
        presence: room.presenceData.presence,
    }
    return footerProps
}

const getModalityProps = (modality: any) => {
    const modalityProps: IModalityInfo = {
        modalityName: "",
        modalityStyles: "modalityStyles"
    }
    modalityProps.modalityName = modality
    return modalityProps
}

export const checkIfEditSessionGoingOn = (activeSessions: IConsole[], uuid: string) => {
    const { FULL_CONTROL, PROTOCOL_MANAGEMENT, INCOGNITO_VIEW } = EConnectionType
    // TODO: Check If we need to disable More option for all type of console session or not
    const allEditConnectionType = [FULL_CONTROL, PROTOCOL_MANAGEMENT, INCOGNITO_VIEW]
    return !!activeSessions.find(session => allEditConnectionType.includes(session.connectionType) && session.roomUuid === uuid)
}

const checkIfCallIsGoingOn = (phoneCallStatus: ECallStatus, videoCallStatus: ICallStatus[]) => {
    const { CALLING, CONNECTED, CONNECTING, RINGING } = ECallStatus
    return videoCallStatus.some((videoCall) => [CALLING, CONNECTING, CONNECTED, RINGING].includes(videoCall.callStatus))
        || phoneCallStatus.includes(CALLING)
}

const getConnectionProps = (uuid: string, activeSessions: IConsole[]) => {
    const connectionProps: IRoomConnectionProps = {
        connectionType: "",
        connectionMode: ""
    }
    const activeRoom = activeSessions.find((session) => session.roomUuid == uuid)
    if (activeRoom) {
        connectionProps.connectionType = activeRoom?.connectionType
        connectionProps.connectionMode = activeRoom?.connectionMode
    }
    return connectionProps
}

export const getProtocolTransferProps = (protocolTransferStatus: boolean, isProtocolTransferCompleted: boolean) => {
    const protocolTransferReducerPropsProps: IProtocolTranferProps = {
        protocolTransferStatus: false,
        completedDestinations: false
    }
    protocolTransferReducerPropsProps.protocolTransferStatus = protocolTransferStatus
    protocolTransferReducerPropsProps.completedDestinations = isProtocolTransferCompleted
    return protocolTransferReducerPropsProps
}

export const getConnectionMode = (mode: string, flags: IRoomCardFlags, connectionProps: IRoomConnectionProps) => {
    return flags.isRoomActiveSession && connectionProps.connectionType === mode
}
const getMonitorName = (activeSessions: IConsole[], roomUuid: string) => {
    const session = getActiveConsoleSession(activeSessions, roomUuid)
    const receiverName = session?.receiverName
    const receivers = fetchGlobalReceivers()
    const receiver = receivers && receivers.find((receiver: any) => receiver.receiverName === receiverName)
    return receiver ? receiver.monitorName : ""
}

interface IRoomCardProps {
    rooms: IRoomDetails[]
    flags: any
    activeSessions: IConsole[]
    protocolTransferStatus: boolean
    ptCompletedDestinations: any
    phoneCallStatus: ECallStatus
    videoCallStatus: ICallStatus[]
}

export const getRoomCardProps = (props: IRoomCardProps) => {
    const { rooms, flags, activeSessions, protocolTransferStatus, ptCompletedDestinations, phoneCallStatus, videoCallStatus } = props
    const roomsList: IRoomCard[] = []
    rooms.forEach((room: any) => {
        const { modality, isRoomStarred, identity, loggedInTech, roomStatus } = room
        const { uuid } = identity
        const isProtocolTransferCompleted = ptCompletedDestinations && ptCompletedDestinations.length > 0 && ptCompletedDestinations[0] === uuid ? true : false
        const modalityName = getModalityProps(modality).modalityName
        const roomCardProps: IRoomCard = {
            roomIdentity: identity,
            isStarred: isRoomStarred,
            roomStatus,
            modalityProps: getModalityProps(modality),
            userNameProps: getUsernameProps(loggedInTech),
            flags: getRoomCardFlags(flags, uuid, activeSessions),
            connectionProps: getConnectionProps(uuid, activeSessions),
            protocolTransferReducerProps: getProtocolTransferProps(protocolTransferStatus, isProtocolTransferCompleted),
            monitorName: getMonitorName(activeSessions, uuid),
            footerProps: getFooterProps(room, activeSessions, phoneCallStatus, videoCallStatus, modalityName)
        }
        roomsList.push(roomCardProps)
    })
    return roomsList
}


export const getStarRoomErrorHeader = (isRoomStarred: any) => {
    return (
        isRoomStarred ? intl.formatMessage({ id: "content.room.unstarRoomErrorHeader", defaultMessage: en["content.room.unstarRoomErrorHeader"] })
            : intl.formatMessage({ id: "content.room.starRoomErrorHeader", defaultMessage: en["content.room.starRoomErrorHeader"] })
    )
}

export const getStarRoomErrorMessage = () => {
    return (
        `${intl.formatMessage({ id: "content.room.starRoomErrorMessage1", defaultMessage: en["content.room.starRoomErrorMessage1"] })}`
    )
}

export const getActiveConsoleSession = (consoleSession: IConsole[], roomUuid: string) => {
    if (consoleSession.length) {
        return consoleSession.find(session => session.roomUuid === roomUuid)
    }
    return
}

export const getConnectionType = (roomUuid: string, activeSessions: IConsole[]) => {
    const activeRoom = activeSessions.find((session: IConsole) => session.roomUuid === roomUuid)
    return activeRoom?.connectionType
}

export const checkActiveWorkflowForRoom = (workflows: IWorkflowInfo[], roomUuid: string) => {
    return !!workflows.find(workflow => {
        return TRACKED_HOME_WORKFLOWS.includes(workflow.type)
            && (getRoomUuidsFromWorkflowContext(workflow.state.context).includes(roomUuid))
    })
}
