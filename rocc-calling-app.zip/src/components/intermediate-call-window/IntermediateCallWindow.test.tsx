/*
 * Created on Mon Sep 13 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import IntermediateCallWindow from "./IntermediateCallWindow"

describe("IntermediateCallWindow tests", () => {
    let wrapper: any
    const props = {
        displayName: "dummy user",
        metaData: EClinicalRole.EXPERTUSER,
        description: "location",
        callMessage: "Connecting",
        callWindowFullscreen: true,
        remoteMediaRef: "",
        remoteVideoStatus: true,
        weakSignalMessageStyle: true,
        customStyle: "style",
        additionalComponent: () => <div>button</div>,
    }
    beforeEach(() => {
        wrapper = shallow(<IntermediateCallWindow {...props} />)
    })
    it("should render IntermediateCallWindow", () => {
        expect(wrapper.find("#intermediateCallWindow")).toHaveLength(1)
    })
})
