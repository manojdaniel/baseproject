/*
 * Created on Tue Nov 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {fetchCommandCenterService }from "./CommandCenterLocationsService"

jest.mock("@rocc/rocc-client-services", () => ({
    ...jest.requireActual("@rocc/rocc-client-services"),
    parseIntBase10: jest.fn().mockReturnValueOnce(0),
    graphqlClient : {
        query : jest.fn().mockReturnValueOnce({data : { command_center_seats : []}})
    }
}))

describe("Command center location service ", () => {

    it("should fetch command centers", () => {
        expect(fetchCommandCenterService(1)).toBeDefined()
    })
})
