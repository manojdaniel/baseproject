// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import Status from "components/Status";
import InfoTable from "table/InfoTable";
import './Info.scss';
import { useDispatch, useSelector } from "react-redux";
import {
    getGlobalTopBarSummary, // same Home Page Top status if you do changes it will effect Home Page also.
} from "../redux/reducers/CommonReducer";
const Info = () => {
    const InfoTableData = [
        // {
        //     "FileName": "DOC Document",
        //     "DownloadBtn": "Download",
        //     "FileType": "doc",
        //     "FileLink": ""
        // },
        // {
        //     "FileName": "JPG Document",
        //     "DownloadBtn": "Download",
        //     "FileType": "jpg",
        //     "FileLink": ""
        // },
        {
            "FileName": "End User Document",
            "DownloadBtn": "Download",
            "FileType": "pdf",
            "FileLink": `${process.env.End_User_Document}`
        },
        // {
        //     "FileName": "JS Document",
        //     "DownloadBtn": "Download",
        //     "FileType": "js",
        //     "FileLink": ""
        // },
        // {
        //     "FileName": "ZIP Document",
        //     "DownloadBtn": "Download",
        //     "FileType": "zip",
        //     "FileLink": ""
        // },
    ];

    let dispatch = useDispatch();
    const userId = 1;

    const {
        globalTopBarSummary, loggedInUserDetails
    } = useSelector((state: any) => ({
        globalTopBarSummary: state.Common.globalTopBarSummary,
        loggedInUserDetails: state.Common.loggedInUserDetails,
    }));

    useEffect(() => {
        const getAPIPassingData = { "userId": userId, "jwtToken": loggedInUserDetails.result.jwtToken }
        dispatch(getGlobalTopBarSummary(getAPIPassingData)); //{userId}
    }, []);
    return (
        <div id="info-box">
            <Status
                data={globalTopBarSummary}
                page={"HOME"}
                healthIndexToolTip={[]}
            />
            <div className="common-box-inner">
                <div className="title">INFO</div>
                <div className="asset-name">View the documents</div>
                <div className="common-box-content">
                    <InfoTable data={InfoTableData} />
                </div>
            </div>
        </div>
    )
}
export default Info;