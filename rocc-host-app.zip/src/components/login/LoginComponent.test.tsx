/*
 * Created on Tue Aug 3 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EAppStates, EIdlePermissionState } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import LoginComponent from "./LoginComponent"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        appState: EAppStates.LOGIN_FAILED,
        currentUser: {},
        idlePermissionState: EIdlePermissionState.DENIED,
        userState: "",
        urls: {},
        fseData: {},
        orgInfraUuid: "",
        authConfigs: {
            authState: "DEFAULT"
        }
    }),
    useDispatch: () => jest.fn(),
}))
jest.mock("react-router", () => ({
    useHistory: () => jest.fn(),
    useLocation: () => jest.fn(),
}))

describe("LoginComponent", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }

    it("should render UserNamePasswordLogin component", () => {
        withHooks(() => {
            useEffect = jest.spyOn(React, "useEffect")
            const mockUseEffect = () => {
                useEffect.mockImplementationOnce(f => f())
            }
            mockUseEffect()
            wrapper = shallow(<LoginComponent />)
            const userNamePasswordLogin = wrapper.find("UserNamePasswordLogin")
            expect(userNamePasswordLogin).toHaveLength(1)
            const loginHandler = userNamePasswordLogin.prop("loginHandler")
            expect(loginHandler()).toBeDefined()
        })
    })
})
