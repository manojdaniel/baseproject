// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import "./SpareParts.scss";
import Dropdown from "components/Dropdown";
import StockGraphicalOverview from "charts/StockGraphicalOverview";
import Sap from "./SAP";
import SensorGroup from "./SensorGroup";
import { Switch, Space } from 'antd';
import { encryptRSAData } from "../../../utility/rsa";
import {
    getGraphicalImageByAssetId, getAssetDropdownList, getGlobalSelecetedAsset, getAnomalyModelbyAssetId,
} from "../../../redux/reducers/CommonReducer";

import { useDispatch, useSelector } from "react-redux";

interface Props {
    data: [];
}

// spare parts
const SpareParts = () => {

    const DATA = [
        { id: 1, value: "SAP" },
        { id: 2, value: "SENSOR GROUP" },
    ];

    const [selectedAssetId, setSelectedAssetId] = useState<any>();
    const [sensorGroupId, setSensorGroupId] = useState<any>();
    const [selectedAssetIdLabel, setSelectedAssetIdLabel] = useState<any>();
    const [elements, setElements] = useState(DATA);
    const [selectedID, setSelectedID] = useState(1);
    const [showMyToggle, setMyToggle] = useState<any>(true);

    let dispatch = useDispatch();

    const { AnomalyModelbyAssetId, GraphicalImageByAssetId,
        globalSelecetedAsset, assetDropdownList, globalSelecetedPlant } = useSelector((state: any) => ({
            AnomalyModelbyAssetId: state.Common.AnomalyModelbyAssetId,
            GraphicalImageByAssetId: state.Common.GraphicalImageByAssetId,
            globalSelecetedAsset: state.Common.globalSelecetedAsset,
            assetDropdownList: state.Common.assetDropdownList,
            globalSelecetedPlant: state.Common.globalSelecetedPlant,

        }));




    const handleAssetDropDown = (e: any) => {
        setSelectedAssetId(e)
        setSelectedAssetIdLabel(e.value);
        dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
    };


    useEffect(() => {
        if (Object.keys(globalSelecetedAsset).length > 0) {
            dispatch(
                getAssetDropdownList(
                    encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
                )
            ); //{plantId}/{userId}
            setSelectedAssetId(globalSelecetedAsset);
            setSelectedAssetIdLabel(globalSelecetedAsset.value);
        }
    }, []);


    useEffect(() => {
        if (selectedAssetIdLabel !== "") {
            dispatch(
                getAnomalyModelbyAssetId(
                    encryptRSAData(
                        `plantId=${globalSelecetedPlant.value}&assetId=${selectedAssetIdLabel}`
                    )
                )
            );
            dispatch(
                getGraphicalImageByAssetId(
                    encryptRSAData(
                        `plantId=${globalSelecetedPlant.value}&assetId=${selectedAssetIdLabel}`
                    )
                )
            );
        }
    }, [selectedAssetIdLabel]);

    const handleMenuClick = (id: any) => {
        setSelectedID(id);
    }
    const getToggleStock = () => {
        setMyToggle(!showMyToggle);
    }

    const getSelectedclassName = (id: any) => selectedID === id ? "active" : "notselected";
    const getSelectedToggleClass = () => showMyToggle === true ? "fullScreen" : "";

    return (
        <div>
            <div id="spare-model">
                {showMyToggle === false ?
                    <div id="spare-model-left">
                        <div className="common-box-inner">
                            <div className="spare-parts-filter">
                                <div className="title">STOCK GRAPHICAL OVERVIEW</div>
                                <div id="new-filter" className="mt10">
                                    <div className="nf-left">
                                        <div className="asset-name">{selectedAssetIdLabel}</div>
                                    </div>
                                </div>
                                <div className="spare-plot-graph">
                                    <StockGraphicalOverview
                                        GraphicalImageByAssetId={GraphicalImageByAssetId}
                                        mysensorGroupId={sensorGroupId}
                                        AnomalyModelbyAssetId={AnomalyModelbyAssetId}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    : ""

                }


                {/* spare-parts-right */}
                <div id="spare-model-right" className={`${getSelectedToggleClass()}`}>
                    <div className="spare-model-right-inner">
                        <div className="spare-switch"><Switch checkedChildren="GRAPHICAL OVERVIEW" unCheckedChildren="GRAPHICAL OVERVIEW" onClick={() => getToggleStock()} /></div>
                        <div className="title">STOCK DETAILS </div>

                        <div id="new-filter" className="mt10">
                            <div className="nf-left">
                                <div className="asset-name">{selectedAssetIdLabel}</div>
                            </div>
                            <div className="nf-right">
                                <div>
                                    <label className="cus-label">Asset ID</label>
                                    <Dropdown
                                        name={"Asset ID"}
                                        handleChange={handleAssetDropDown}
                                        options={assetDropdownList}
                                        value={selectedAssetId}
                                        defaultValue={""}
                                    />
                                </div>
                            </div>
                        </div>

                        <div id="spare-name">
                            {elements.map((el) => (
                                <a
                                    key={el.id}
                                    className={`top-container-conten ${getSelectedclassName(el.id)}`}
                                    onClick={() => handleMenuClick(el.id)}
                                >
                                    {el.value}
                                </a>
                            ))}
                        </div>
                        {selectedID === 2 ?
                            <SensorGroup />
                            :
                            <Sap />

                        }
                    </div>
                </div>

            </div>
        </div>
    );
};
export default SpareParts;