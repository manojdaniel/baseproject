"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from graphql import GraphQLError

from src.constants.constants import CREATED_BY, JOB_NAME_COLUMN, MODIFIED_BY, OBJECTS, ROCC_OVERWATCH_RAW_UPLOAD_DATA, TASK_NAME_COLUMN, OPERATION_TYPE_COLUMN, \
    CURRENT_JOB_ID_COLUMN, CURRENT_TASK_ID_COLUMN, UPLOAD_RECORD_ID_COLUMN, \
    ENTITY_ID_COLUMN, ENTITY_TYPE_COLUMN, TRANSACTION_DATA_COLUMN, STATUS_COLUMN, RETURNING, ID, INIT, ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS, TRANSACTION_ID, STATUS_VARIABLE, \
    JOB_ID, ROCC_OVERWATCH_SERVICE_TASKS, NOT_STARTED, TRANSACTION_DATA, TASK_ID, INSERT, ROCC_OVERWATCH_CUSTOMERS, ROCC_OVERWATCH_INFRASTRUCTURE_CONFIGS
from src.constants.enums import ESummaryStates
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_overwatch_customer_id_from_name, fetch_org_db_id_from_identifier
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present, extract_data_from_table, extract_id_and_field_from_response, \
    extract_response_from_mutation_response, extract_id_from_mutation_response
from src.modules.event_management.event_enums import EJobs, ETasks
from src.wrappers.graphql.mutations.mutations import insert_rocc_overwatch_service_job_transactions, upsert_customers, cleanup_raw_data_with_record_id, \
    update_status_service_job_transactions_to_init, update_job_and_task_for_transaction, update_transaction_details, upsert_customer_configurations, \
    update_customer_status_from_raw_upload_record_id, cleanup_rocc_overwatch_customer_data
from src.wrappers.graphql.queries.queries import check_if_job_exists_in_db, check_if_task_exists_in_db, get_transaction_details_by_tx_id_from_db_query, fetch_tasks_for_jobid, \
    fetch_infra_configs, fetch_task_id_and_order_by_name, fetch_active_transactions_for_customer, fetch_customer_id_from_raw_upload, fetch_all_transactions_for_customer

LOG = create_logger("ManagementDataInsertion")

DEFAULT_SUMMARY_OBJECT = {
    ESummaryStates.NEW: [],
    ESummaryStates.EXISTING: [],
    ESummaryStates.INSERTION_FAILED: [],
    ESummaryStates.VALIDATION_FAILED: []
}


def fetch_job_id_from_name(job_name, client):
    variables = {JOB_NAME_COLUMN: job_name}
    try:
        response = client.execute(
            check_if_job_exists_in_db, variable_values=variables)
        if len(response["job"]):
            LOG.info(f"Job: {job_name} exists in database.")
            return response["job"][0][ID]

        LOG.error(f"Job {job_name} not found")
        raise RoccException(404, f"Job: {job_name} not found")

    except RoccException as ex:
        LOG.error(f"Exception while checking job  DB: {ex}")
        raise RoccException(ex.status_code, str(ex.payload)) from ex


def fetch_task_id_from_name(task_name, client):
    variables = {TASK_NAME_COLUMN: task_name}
    try:
        response = client.execute(
            check_if_task_exists_in_db, variable_values=variables)
        if len(response["task"]):
            LOG.info(f"Task: {task_name} exists in database.")
            return response["task"][0][ID]

        LOG.error(f"Task {task_name} not found")
        raise RoccException(404, f"Task: {task_name} not found")

    except RoccException as ex:
        LOG.error(f"Exception while checking task in DB: {ex}")
        raise RoccException(ex.response.status_code, str(ex.payload)) from ex


def fetch_task_id_and_order_from_task_name(task_name, job_name, client):
    variables = {TASK_NAME_COLUMN: task_name, "job_name": job_name}
    try:
        response = client.execute(
            fetch_task_id_and_order_by_name, variable_values=variables)
        if len(response["task"]):
            LOG.info(f"Task: {task_name} exists in database.")
            return response["task"][0][ID], response["task"][0]["execution_order"]

        LOG.error(f"Task {task_name} not found")
        raise RoccException(404, f"Task: {task_name} not found")

    except RoccException as ex:
        LOG.error(f"Exception while checking task in DB: {ex}")
        raise RoccException(ex.response.status_code, str(ex.payload)) from ex


def create_update_existing_customer_transaction_data(client):
    transaction_data = {
        "jobs": [
            {
                "index": 1,
                "name": EJobs.CUSTOMER_DATA_INSERTION.value,
                "job_id": fetch_job_id_from_name(EJobs.CUSTOMER_DATA_INSERTION.value, client),
                "status": NOT_STARTED,
                "tasks": [
                    {"index": 1, "name": ETasks.SITE_DATA_INSERTION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.SITE_DATA_INSERTION.value, client)},
                    {"index": 2, "name": ETasks.CC_DATA_INSERTION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.CC_DATA_INSERTION.value, client)},
                    {"index": 3, "name": ETasks.MANAGE_ROOMS.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.MANAGE_ROOMS.value, client)},
                    {"index": 4, "name": ETasks.MANAGE_USERS.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.MANAGE_USERS.value, client)}
                ]
            }, {
                "index": 2,
                "name": EJobs.VALIDATE_ONBOARDED_DATA.value,
                "job_id": fetch_job_id_from_name(EJobs.VALIDATE_ONBOARDED_DATA.value, client),
                "status": NOT_STARTED,
                "tasks": [
                    {"index": 1, "name": ETasks.SITE_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.SITE_DATA_VALIDATION.value, client)},
                    {"index": 2, "name": ETasks.CC_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.CC_DATA_VALIDATION.value, client)},
                    {"index": 3, "name": ETasks.ROOMS_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.ROOMS_DATA_VALIDATION.value, client)},
                    {"index": 4, "name": ETasks.USERS_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.USERS_DATA_VALIDATION.value, client)},
                    {"index": 5, "name": ETasks.EULA_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.EULA_DATA_VALIDATION.value, client)},
                    {"index": 6, "name": ETasks.KVM_CONFIGURATION_DATA_VALIDATION.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.KVM_CONFIGURATION_DATA_VALIDATION.value, client)}
                ]
            },
            {
                "index": 3,
                "name": EJobs.COMPLETE.value,
                "job_id": fetch_job_id_from_name(EJobs.COMPLETE.value, client),
                "status": NOT_STARTED,
                "tasks": [
                    {"index": 1, "name": ETasks.COMPLETE.value, "status": NOT_STARTED,
                        TASK_ID: fetch_task_id_from_name(ETasks.COMPLETE.value, client)},
                ]
            }
        ],
        "summary": {
            "sites": DEFAULT_SUMMARY_OBJECT,
            "cc": DEFAULT_SUMMARY_OBJECT,
            "rooms": DEFAULT_SUMMARY_OBJECT,
            "users": DEFAULT_SUMMARY_OBJECT,
            "kvm": DEFAULT_SUMMARY_OBJECT
        }
    }
    return transaction_data


def insert_job_transaction_object(operation_type, job_id, task_id, entity_id, entity_type, file_identifier, transaction_data, user_uuid, client):
    # TODOS: Need to populate proper Job, task names and transaction data
    try:
        job_transaction_object = {
            OPERATION_TYPE_COLUMN: operation_type,
            CURRENT_JOB_ID_COLUMN: job_id,
            CURRENT_TASK_ID_COLUMN: task_id,
            UPLOAD_RECORD_ID_COLUMN: file_identifier,
            ENTITY_ID_COLUMN: entity_id,
            ENTITY_TYPE_COLUMN: entity_type,
            TRANSACTION_DATA_COLUMN: transaction_data,
            STATUS_COLUMN: INIT,
            CREATED_BY: user_uuid,
            MODIFIED_BY: user_uuid

        }
        variables = {OBJECTS: job_transaction_object}
        response = client.execute(
            insert_rocc_overwatch_service_job_transactions, variable_values=variables)
        return response["transactions"][RETURNING][0][ID]
    except RoccException as ex:
        LOG.error(f"RoccException while adding transaction in DB: {ex}")
        raise RoccException(ex.response.status_code, str(ex.payload)) from ex
    except Exception as ex:
        LOG.error(f"Exception while adding transaction in DB: {ex}")
        raise RoccException(ex.response.status_code, str(ex.payload)) from ex


def get_service_job_transactions_details(transaction_id, client):
    try:
        graphql_response = client.execute(get_transaction_details_by_tx_id_from_db_query,
                                          variable_values={TRANSACTION_ID: str(transaction_id)})
        transaction_details = extract_data_from_table(
            data=graphql_response, table_name=ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS)
        return transaction_details
    except Exception as ex:
        LOG.error(
            f"Failed to fetch service job transactions details with error: {ex}")
        LOG.error(traceback.print_exc())
        raise ex


def update_service_job_transaction_status(transaction_id, status, client):
    try:
        graphql_response = client.execute(update_status_service_job_transactions_to_init,
                                          variable_values={TRANSACTION_ID: str(transaction_id), STATUS_VARIABLE: status})
        update_status = extract_data_from_table(
            data=graphql_response, table_name=f"update_{ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS}")
        return update_status
    except Exception as ex:
        LOG.error(
            f"Failed to update service job transactions details with error: {ex}")
        LOG.error(traceback.print_exc())
        raise ex


def fetch_tasks_for_job(job_id, client):
    try:
        graphql_response = client.execute(
            fetch_tasks_for_jobid, variable_values={JOB_ID: job_id})
        tasks_list = extract_data_from_table(
            graphql_response, ROCC_OVERWATCH_SERVICE_TASKS)
        return tasks_list
    except Exception as ex:
        LOG.error(f"Failed to fetch tasks for job: {job_id} with error: {ex}")
        LOG.error(traceback.print_exc())
        raise ex


def update_tasks_for_transaction(transaction_id, job_id, task_id, transaction_data_object, status, client, reason="", job_status_update=False):
    transaction_data_object = update_transaction_data_object(
        transaction_data_object, job_id, task_id, status, reason, job_status_update)
    variables = {TRANSACTION_ID: transaction_id, JOB_ID: job_id,
                 TASK_ID: task_id, TRANSACTION_DATA: transaction_data_object}
    try:
        result = client.execute(
            update_job_and_task_for_transaction, variable_values=variables)
        response = extract_response_from_mutation_response(
            result, "update_rocc_overwatch_service_job_transactions")
        if response[0][TRANSACTION_DATA]:
            LOG.info(
                f"Successfully updated the transaction with ID {transaction_id}")
        return response[0][TRANSACTION_DATA]
    except Exception:
        LOG.error(f"Failed to update transaction with ID {transaction_id}")
        LOG.error(traceback.print_exc())


def update_transaction_data_object(transaction_data_object, job_id, task_id, status, reason, job_status_update=False):
    for job in transaction_data_object["jobs"]:
        if job["job_id"] == job_id:
            if job_status_update:
                job["status"] = status
            for task in job["tasks"]:
                if task["task_id"] == task_id:
                    task["status"] = status
                    task["reason"] = reason
                    break
    return transaction_data_object


def update_transaction_object_in_db(job_id, task_id, client, transaction_id):
    try:
        response = client.execute(update_transaction_details, variable_values={
                                  "transaction_id": transaction_id, "job_id": job_id, "task_id": task_id})
        return extract_response_from_mutation_response(response, "update_rocc_overwatch_service_job_transactions")
    except GraphQLError as gq_err:
        LOG.error(
            f"Failed to update transaction data for id: {transaction_id} with error: {gq_err}")
        LOG.error(traceback.print_exc())
    except Exception as ex:
        LOG.error(
            f"Failed to update transaction data for id: {transaction_id} with error: {ex}")
        LOG.error(traceback.print_exc())


def update_customers_table(client, name, status="NEW"):
    try:
        response = client.execute(upsert_customers, variable_values={
                                  "name": name, "status": status})
        return extract_id_from_mutation_response(data=response,
                                                 table_name=f"{INSERT}{ROCC_OVERWATCH_CUSTOMERS}")
    except GraphQLError as gq_err:
        LOG.error(
            f"Failed to update customer record in table: customers with error: {gq_err}")
        LOG.error(traceback.print_exc())
    except Exception as ex:
        LOG.error(
            f"Failed to update customer record in table: customers with error: {ex}")
        LOG.error(traceback.print_exc())


def update_customer_configurations(client, infra_configs, **kwargs):
    try:
        for key, value in kwargs.items():
            infra_configs["infra_configs"][key] = value
        upsert_customer_configurations_service(client, infra_configs)
    except KeyError as ex:
        LOG.error(
            f"Key Error: Failed to update infra configurations for {kwargs} with error: {ex}")
    except Exception as ex:
        LOG.error(
            f"Failed to update infra configurations for {kwargs} with error: {ex}")


def upsert_customer_configurations_service(client, infra_configs_ob):
    try:
        response = client.execute(upsert_customer_configurations, variable_values={
                                  "object": infra_configs_ob})
        return extract_id_from_mutation_response(data=response,
                                                 table_name=f"{INSERT}{ROCC_OVERWATCH_INFRASTRUCTURE_CONFIGS}")
    except GraphQLError as gq_err:
        LOG.error(
            f"Failed to update customer configurations record in table: customers with error: {gq_err}")
        LOG.error(traceback.print_exc())
    except Exception as ex:
        LOG.error(
            f"Failed to update customer configurations record in table: customers with error: {ex}")
        LOG.error(traceback.print_exc())


def update_summary_for_entity(transaction_data, entity_type, entity_key, summary_state):
    transaction_data["summary"][entity_type][summary_state].append(entity_key)
    return transaction_data


def get_infra_configs(client, customer_id):
    try:
        graphql_response = client.execute(fetch_infra_configs,
                                          variable_values={"customer_id": customer_id})
        infra_configs_for_customer = extract_data_from_table(
            data=graphql_response, table_name=ROCC_OVERWATCH_INFRASTRUCTURE_CONFIGS)
        return infra_configs_for_customer
    except Exception as ex:
        LOG.error(
            f"Failed to fetch infrastructure configurations for customer_id: {customer_id} with error: {ex}")
        LOG.error(traceback.print_exc())
        raise ex


def check_for_parallel_transactions_and_update_customer_status(customer_name, status, client):
    try:
        overwatch_customer_id = fetch_overwatch_customer_id_from_name(
            customer_name=customer_name, client=client)
        graphql_response = client.execute(fetch_active_transactions_for_customer, variable_values={
                                          "customer_id": overwatch_customer_id})
        active_transactions = extract_data_from_table(
            data=graphql_response, table_name=ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS)
        if not len(active_transactions) > 0:
            LOG.info(
                f"No parallel transactions for customer {customer_name}. Updating status to {status} ")
            update_customers_table(
                client=client, name=customer_name, status=status)
        else:
            LOG.info(
                f"There are parallel transactions going on for customer {customer_name}. Hence not updating status")
    except Exception as ex:
        LOG.error(f"Error while updating the customer status {ex}")


def cleanup_raw_data_record(client, record_id):
    try:
        graphql_response = client.execute(
            cleanup_raw_data_with_record_id, variable_values={"record_id": record_id})
        res = extract_data_from_table(
            data=graphql_response, table_name=f"delete_{ROCC_OVERWATCH_RAW_UPLOAD_DATA}")
        if res["returning"] and res["returning"][0] and res["returning"][0]["id"] and res["returning"][0]["id"] == record_id:
            return 204
        else:
            return 500
    except Exception as ex:
        LOG.error(traceback.print_exc())
        if "constraint-violation" in str(ex):
            LOG.error(
                f"Not cleaning up the raw data record: {record_id}, since it is in use. {ex}")
            return 400
        LOG.error(
            f"Failed to clean up raw data record - {record_id} with general error: {ex}")
    return 500


def update_customer_status_by_record_id(client, record_id, status):
    try:
        graphql_response = client.execute(update_customer_status_from_raw_upload_record_id, variable_values={
                                          "record_id": record_id, "status": status})
        res = extract_data_from_table(
            data=graphql_response, table_name=f"update_{ROCC_OVERWATCH_CUSTOMERS}")
        if res["returning"] and res["returning"][0] and res["returning"][0]["id"]:
            LOG.info(
                f"Successfully updated the status for customer with record id {record_id}")
            return 200
        elif res["returning"] and (len(res["returning"]) == 0):
            LOG.info(
                f"Skipping updation since could not find customer with record id {record_id}")
            return 404
        else:
            LOG.error(
                f"Error while updating customer status. Error: {graphql_response}")
            return 500
    except Exception as ex:
        LOG.error(traceback.print_exc())
        LOG.error(
            f"Failed to update customer status with {record_id} with general error: {ex}")
    return 500


def check_if_customer_eligible_for_cleanup(client, record_id):
    try:
        response = client.execute(fetch_customer_id_from_raw_upload, variable_values={
                                  "record_id": record_id})
        customer_id, customer_identifier = extract_id_and_field_from_response(
            response, ROCC_OVERWATCH_CUSTOMERS, "name")
        if customer_id and customer_identifier:
            LOG.info(
                f"Found customer {customer_identifier} in raw upload table.")
            LOG.info(
                f"Checking if customer {customer_identifier} exists in metasites table.")
            org_db_id = fetch_org_db_id_from_identifier(
                client=client, customer_identifier=customer_identifier)
            if not org_db_id:
                LOG.info(
                    f"Customer {customer_identifier} does not exist in metasite")
                LOG.info(
                    f"Checking if customer {customer_identifier} has any transactions")
                transaction_response = client.execute(
                    fetch_all_transactions_for_customer, variable_values={"customer_id": customer_id})
                transaction_id = check_if_id_is_present(
                    transaction_response, ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS)
                if not transaction_id:
                    LOG.info(
                        f"No transactions present for customer {customer_identifier}.")
                    return customer_id
                else:
                    LOG.info(
                        f"Transactions are present for customer {customer_identifier}. Transaction ID: {transaction_id}.")
            else:
                LOG.info(
                    f"Customer {customer_identifier} exists in the metasite table.")
        else:
            LOG.info(f"No customer found for record_id {record_id}")
    except Exception as ex:
        LOG.exception(
            f"Exception occured while checking if customer is eligible for cleanup. {ex}")
    return False


def cleanup_customer_data(client, customer_id):
    try:
        graphql_response = client.execute(
            cleanup_rocc_overwatch_customer_data, variable_values={"customer_id": customer_id})
        res = extract_data_from_table(
            data=graphql_response, table_name=f"delete_{ROCC_OVERWATCH_CUSTOMERS}")
        if res["returning"] and res["returning"][0] and res["returning"][0]["id"] and res["returning"][0]["id"] == customer_id:
            LOG.info(
                f"Successfully cleaned up the customer with ID {customer_id}")
            return 204
        else:
            LOG.error(f"Failed to cleanup the customer with ID {customer_id}")
    except Exception as ex:
        LOG.exception(
            f"Exception while cleanup up customer data for ID {customer_id}.  {ex}")
    return 500
