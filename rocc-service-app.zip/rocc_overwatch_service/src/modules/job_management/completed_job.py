"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import traceback

from src.constants.constants import CURRENT_JOB, HSDP_ORGANIZATION_ID, JOB_LIST, COMPLETED, JOB_NAME, OPERATION, STATUS, ENTITY_ID, HSDP_IAM_URL, DATA, SERVICE_AUTH_ISSUER, \
    SERVICE_AUTH_PRIVATE_KEY, TRANSACTION_DATA, TRANSACTION_ID, ID, PARTIALLY_COMPLETE, PROCESS_COMPLETE
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import check_for_parallel_transactions_and_update_customer_status, \
    get_service_job_transactions_details, update_service_job_transaction_status, update_tasks_for_transaction, fetch_job_id_from_name, fetch_tasks_for_job
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.job_management.job_handler import JobHandler
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values

LOG = create_logger("CompletionJob")


class CompletionJob(JobHandler):
    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            self._transaction_id = self._payload[TRANSACTION_ID]
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            current_record = list(filter(
                lambda item: item[JOB_NAME] == EJobs.COMPLETE.value, self._payload[JOB_LIST]))[0]
            if current_record[STATUS] == COMPLETED:
                # Ignore this event, since it is completed
                LOG.debug(
                    f"Operation: {self._payload[OPERATION]} is completed. !!")
                return None
            else:
                self._payload = payload
                organization_vault_values = get_path_specific_vault_values(
                    path_name=self._payload[ENTITY_ID])
                self._customer_service_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                                               issuer=organization_vault_values[
                                                                                   DATA][SERVICE_AUTH_ISSUER],
                                                                               private_key=organization_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
                self._org_infra_uuid = organization_vault_values[DATA][HSDP_ORGANIZATION_ID]
                self._client = get_client_connection(
                    self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
                job_transaction_details = self.fetch_transaction_from_db(
                    transaction_id=self._payload[TRANSACTION_ID])
                self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
                self._job_id = fetch_job_id_from_name(
                    EJobs.COMPLETE.value, self._client)
                self.fetch_all_tasks()
                if self._payload[PROCESS_COMPLETE]:
                    LOG.debug("Initiating completion Job. !!")
                    self.update_transaction_in_db_wrt_job(status=COMPLETED,
                                                          task_name=ETasks.COMPLETE.value,
                                                          job_status_update=True,
                                                          update_record_status=True)
                else:
                    LOG.info(
                        f"Process of Transaction, {self._transaction_id} is partially complete ..!!")
                    self.update_transaction_in_db_wrt_job(status=PARTIALLY_COMPLETE,
                                                          task_name=ETasks.COMPLETE.value,
                                                          job_status_update=True,
                                                          update_record_status=True)
            check_for_parallel_transactions_and_update_customer_status(
                customer_name=self._payload[ENTITY_ID], status="IDLE", client=self._client)
            LOG.info(
                f"Finished Job: {self._payload[CURRENT_JOB]} for operation: {self._payload[OPERATION]}")
        except Exception as ex:
            LOG.exception(f"Encountered error in completion job: {ex}")
            LOG.error(traceback.print_exc())

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(
            job_id=self._job_id, client=self._client)
        LOG.info(
            f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def fetch_transaction_from_db(self, transaction_id):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(
            transaction_id, client=self._client)
        LOG.info(
            f"Fetch job details for transaction_id, {transaction_id} is successful")
        return transaction_details

    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        """Update corresponding transaction from transaction table"""
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._transaction_id,
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[
                                                                  ID],
                                                              transaction_data_object=self._transaction_data,
                                                              status=status,
                                                              client=self._client,
                                                              job_status_update=job_status_update,
                                                              reason=error_reason)
        if update_record_status:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self._client)
        LOG.info(
            f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")

    def execute_tasks(self, tasks):
        """
        Initiate execution of tasks in order
        """

    def post_message(self, payload):
        """
        1. After completion of all tasks in the Job send a RabbitMQ message
        """

    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """
