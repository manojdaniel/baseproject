import { ECameraStreamAvailable, EConnectionType, IConsoleSession, ILoggedInTech, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import isEmpty from "lodash.isempty"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { IActiveConsoleSessionFeature } from "./ActiveConsoleSessionFeature"
import { ACCESS_TOKEN, CCTV_WINDOW, CONSOLE_MEDIA_ROOM_UPDATE, CONSOLE_SESSIONS, MULTI_CAMERA_SETTINGS_SIDEBAR, ROOMS, UPDATE_ROOM_CAMERA_AVAILABILITY, TIME, UPDATE_DISPLAY_CAMERA_TOGGLE } from "./common/constants/constants"
import { checkFeatureToggleAndCameraStreamAvailable, filterWithoutIncognitoSession } from "./common/helpers/consoleUtility"
import { fetchCCTVProps, fetchConsoleSession, getCurrentRoom, isRoomMonitoringEnabled } from "./common/helpers/helpers"
import { toggleDisplayCamera } from "./common/modules/multi-camera/MultiCameraHelper"
import ActiveConsoleTabHeader from "./components/console-banner/console-banner-header/ActiveConsoleTabHeader"
import EditConsoleBanner from "./components/console-banner/console-edit-banner/EditConsoleBanner"
import IncognitoConsoleBanner from "./components/console-banner/console-incognito-banner/IncognitoConsoleBanner"
import ProtocolManagerBanner from "./components/console-banner/console-protocol-manager-banner/ProtocolManagerConsoleBanner"
import ViewConsoleBanner from "./components/console-banner/console-view-banner/ViewConsoleBanner"
import RoomMonitoringStreamView from "./components/room-monitoring/room-monitoring-stream-view/RoomMonitoringStreamView"
import { updateConsoleSession, updateRoomCameraAvailability } from "./redux/actions/consoleActions"
import { GLOBAL_LEFTSIDE_PANEL } from "./redux/actions/types"
import { ESessionContentType, IStore } from "./redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalConfigs } from "./redux/store/externalAppStates"
import syncSessions from "./redux/store/syncSessions"
import en from "./resources/translations/en-US"
import styles from "./components/console-banner/console-view-banner/ViewConsoleBanner.scss"
import cx from "classnames"
import { setDisplayCamera } from "./common/helpers/multiCameraUtility"

const componentName = "InitiateSessionWithBanner.tsx"

const InitiateSessionWithBanner = (props: IActiveConsoleSessionFeature) => {

    const { consoleSessions, currentUser, leftSidePanel, rightSidePanel, rooms, featureFlags, receivers } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        currentUser: state.externalReducer.currentUser,
        leftSidePanel: state.externalReducer.displayLeftSidePanel,
        rightSidePanel: state.externalReducer.displayRightSidePanel,
        rooms: state.externalReducer.rooms,
        featureFlags: state.externalReducer.featureFlags,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
    }))

    const { VIEW, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL } = EConnectionType
    const { contextId, contentType, roomUuid } = props
    const [title, setTitle] = useState(true)
    const [activeSession, setActiveSession] = useState({} as IConsoleSession)
    const rightSidePanelRef = useRef(rightSidePanel)
    const { intl } = getIntlProvider()
    const guest = intl.formatMessage({ id: "content.room.guest", defaultMessage: en["content.room.guest"] })
    const [technologistName, setTechnologistName] = useState(guest)
    const [multiCameraDisabled, setMultiCameraDisabled] = useState(false)
    const activeRoomDetail = getCurrentRoom(roomUuid, rooms)
    const dispatch = useDispatch()
    const loggerInitialMessage = `${componentName}: For user: ${currentUser.uuid} - Console session ${contextId}`

    const resizeWindow = () => {
        rightSidePanelRef.current ? setTitle(false) : setTitle(window.innerWidth > 1680)
    }

    const getTechnologistName = async (loggedInTech: ILoggedInTech) => {
        if (loggedInTech.techUuid !== "") {
            setTechnologistName(loggedInTech.techName)
        } else {
            setTechnologistName(guest)
        }
    }

    useEffect(() => {
        window.addEventListener("resize", resizeWindow)
        return () => window.removeEventListener("resize", resizeWindow)
    }, [])

    useEffect(() => {
        if (activeRoomDetail) {
            const { loggedInTech } = activeRoomDetail
            getTechnologistName(loggedInTech)
        }
        syncSessions.postMessage({ type: ROOMS, rooms: rooms })
    }, [rooms])

    useEffect(() => {
        activeSession.mediaRoomDetails && activeSession.mediaRoomDetails.cameraStreamAvailable === ECameraStreamAvailable.MEDIA_ROOM_FAILED ? setMultiCameraDisabled(true) : setMultiCameraDisabled(false)
    }, [activeSession])

    useEffect(() => {
        rightSidePanelRef.current = rightSidePanel
        resizeWindow()
    }, [rightSidePanel])

    useEffect(() => {
        const session = fetchConsoleSession(contextId, consoleSessions)
        if (session) {
            setActiveSession({ ...session })
        }
    }, [consoleSessions, contextId])

    useEffect(() => {
        const sessions = filterWithoutIncognitoSession(consoleSessions)
        syncSessions.postMessage({ type: CONSOLE_SESSIONS, sessions: sessions })
    }, [consoleSessions])

    useEffect(() => {
        if (isRoomMonitoringEnabled(featureFlags)) {
            syncSessions.postMessage({ type: ACCESS_TOKEN, accessToken: currentUser.accessToken })
            infoLogger(`${loggerInitialMessage} - Pushing new token to CCTV app for user: ${currentUser.uuid} with sessionId: ${currentUser.sessionId}`)
        }
    }, [currentUser.accessToken])

    useEffect(() => {
        syncSessions.onmessage = function (msg: any) {
            const { consoleSessions, currentUser, rooms } = fetchCCTVProps()
            if (msg.data.type === CCTV_WINDOW) {
                const sessions = filterWithoutIncognitoSession(consoleSessions)
                sessions.forEach((session: IConsoleSession) => {
                    if (session.mediaRoomDetails && session.mediaRoomDetails.cameraStreamAvailable === ECameraStreamAvailable.INITIATED) {
                        session.mediaRoomDetails.cameraStreamAvailable = ECameraStreamAvailable.CAMERA_STREAM_DISCONNECTED
                    }
                })
                syncSessions.postMessage({ type: CONSOLE_SESSIONS, sessions: sessions })
                syncSessions.postMessage({ type: ACCESS_TOKEN, accessToken: currentUser.accessToken })
                syncSessions.postMessage({ type: ROOMS, rooms: rooms })
                syncSessions.postMessage({ type: TIME, time: new Date() })
            } else if (msg.data.type === CONSOLE_MEDIA_ROOM_UPDATE) {
                const { contextId, mediaRoomDetails } = msg.data.cameraStreamStatus
                const activeSession = consoleSessions.find(session => session.contextId === contextId)
                if (activeSession) {
                    activeSession.mediaRoomDetails = { ...mediaRoomDetails }
                    activeSession.multiCameraList = []
                    dispatch(updateConsoleSession(activeSession, true, false))
                }
            } else if (msg.data.type === UPDATE_ROOM_CAMERA_AVAILABILITY) {
                const { roomUuid, cameraAvailable } = msg.data.roomData
                dispatch(updateRoomCameraAvailability(roomUuid, cameraAvailable))
            } else if (msg.data.type === UPDATE_DISPLAY_CAMERA_TOGGLE) {
                const { contextId, cameraState } = msg.data.sessionDetails
                const activeSession = consoleSessions.find(session => session.contextId === contextId)
                if (activeSession) {
                    setDisplayCamera(activeSession, cameraState, dispatch)
                }
            }
        }
    }, [syncSessions])

    const configs = fetchGlobalConfigs()
    const maxSupportedDeviceUSBCameras = configs.MAX_SUPPORTED_DEVICE_USB_CAMERAS
    const deviceUSBCameraLimit = configs.DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING
    const currentSession = consoleSessions.find(session => session.contextId === contextId)
    const isCameraStreamAvailable = currentSession ? currentSession.mediaRoomDetails.cameraStreamAvailable !== ECameraStreamAvailable.NOT_AVAILABLE : false
    const displayCameraState = currentSession ? currentSession.displayCameraToggle : false
    const showCameraControls = currentSession ? checkFeatureToggleAndCameraStreamAvailable(featureFlags, ROCC_FEATURES.MULTI_CAMERA, maxSupportedDeviceUSBCameras, deviceUSBCameraLimit, isCameraStreamAvailable, currentSession) : false

    const getActiveConsoleTab = () => {
        const { TAB_HEADER, TAB_CONTENT } = ESessionContentType
        switch (contentType) {
            case (TAB_HEADER): return <ActiveConsoleTabHeader activeSession={activeSession} />
            case (TAB_CONTENT): return getTabContent()
            default: return <></>
        }
    }

    const handleCameraSliderClick = () => {
        sendLogsToAzure({ contextData: { component: "Multi Camera: DisplayCamerasControl", event: `Camera ${displayCameraState ? "off" : "on"}`, Event_By: currentUser.uuid } })
        currentSession && toggleDisplayCamera(currentSession, dispatch)
        dispatchToParentStore({
            type: GLOBAL_LEFTSIDE_PANEL,
            payload: {
                displayLeftSidePanel: false,
                activeLeftPanel: "",
                desktopFullScreen: false,
            }
        })
    }

    const handleCameraSettingsClick = () => {
        sendLogsToAzure({ contextData: { component: "Multi Camera: Settings control", event: `Camera settings ${leftSidePanel ? "off" : "on"}`, Event_By: currentUser.uuid } })
        leftSidePanel ? dispatchToParentStore({
            type: GLOBAL_LEFTSIDE_PANEL,
            payload: {
                displayLeftSidePanel: false,
                activeLeftPanel: "",
                desktopFullScreen: false,
            }
        })
            : dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: true,
                    activeLeftPanel: MULTI_CAMERA_SETTINGS_SIDEBAR,
                    desktopFullScreen: false,
                }
            })
    }

    const checkForMultipleCameraStreams = () => {
        return !!(activeSession && activeSession.displayCameraToggle && activeSession.multiCameraList.length > 1)
    }

    const getConsoleBanner = (displayCameraToggle: boolean, connectionType: EConnectionType) => {
        switch (connectionType) {
            case VIEW:
                return <ViewConsoleBanner
                    currentSession={activeSession}
                    contextId={contextId}
                    roomUuid={roomUuid}
                    buttonTitle={title}
                    technologistName={technologistName}
                    displayCameraState={displayCameraToggle}
                    showCameraControls={showCameraControls}
                    multiCameraDisabled={multiCameraDisabled}
                    rightSidePanel={rightSidePanel}
                    showCameraSettings={checkForMultipleCameraStreams()}
                    handleCameraSliderClick={handleCameraSliderClick}
                    handleCameraSettingsClick={handleCameraSettingsClick}
                />
            case INCOGNITO_VIEW:
                return <IncognitoConsoleBanner
                    currentSession={activeSession}
                    contextId={contextId}
                    roomUuid={roomUuid}
                    buttonTitle={title}
                    technologistName={technologistName}
                    rightSidePanel={rightSidePanel}
                />
            case PROTOCOL_MANAGEMENT:
                return <ProtocolManagerBanner
                    currentSession={activeSession}
                    contextId={contextId}
                    roomUuid={roomUuid}
                    buttonTitle={title}
                    displayCameraState={displayCameraToggle}
                    showCameraControls={showCameraControls}
                    multiCameraDisabled={multiCameraDisabled}
                    rightSidePanel={rightSidePanel}
                    showCameraSettings={checkForMultipleCameraStreams()}
                    handleCameraSliderClick={handleCameraSliderClick}
                    handleCameraSettingsClick={handleCameraSettingsClick}
                    technologistName={technologistName}
                />
            case FULL_CONTROL:
                return <EditConsoleBanner
                    currentSession={activeSession}
                    contextId={contextId}
                    roomUuid={roomUuid}
                    technologistName={technologistName}
                    buttonTitle={title}
                    displayCameraState={displayCameraToggle}
                    showCameraControls={showCameraControls}
                    multiCameraDisabled={multiCameraDisabled}
                    rightSidePanel={rightSidePanel}
                    showCameraSettings={checkForMultipleCameraStreams()}
                    handleCameraSliderClick={handleCameraSliderClick}
                    handleCameraSettingsClick={handleCameraSettingsClick} />

            default: return <></>
        }
    }

    const getTabContent = () => {
        if (!isEmpty(activeSession)) {
            const { displayCameraToggle, connectionType } = activeSession
            return <>
                {getConsoleBanner(displayCameraToggle, connectionType)}
                {
                    isRoomMonitoringEnabled(featureFlags) && receivers.length === 1 && connectionType !== INCOGNITO_VIEW ? <div
                        className={cx(connectionType === VIEW ? styles.roomMonitorView : styles.roomMonitorEdit, rightSidePanel && styles.sideBarOpenStyles)}
                    >
                        <RoomMonitoringStreamView
                            singleRecieverView={true}
                            consoleSession={activeSession}
                            consoleSessions={consoleSessions}
                            currentUserUuid={currentUser.uuid}
                            accessToken={currentUser.accessToken}
                            roomCameraAvailable={activeRoomDetail.cameraAvailable}
                            rightSidePanel={rightSidePanel}
                        />
                    </div>
                        : <></>
                }
            </>
        } else {
            return <></>
        }

    }
    return (
        <>
            {activeSession.contextId ? getActiveConsoleTab() : <></>}
        </>
    )
}

export default InitiateSessionWithBanner
