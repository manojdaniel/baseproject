/*
 * Created on Mon Apr 18 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore, IWorkflow, WorkflowEvent } from "@rocc/rocc-client-services"
import isEqual from "lodash.isequal"
import { Dispatch, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { interpret, State } from "xstate"
import { removeWorkflowEvent, setServiceInstance, setWorkflows, setWorkflowState } from "../../redux/actions/workflowActions"
import { getMappedDependency } from "../../utility/helpers/helpers"

export const initializeWorkflow = (workflow: IWorkflow, dispatch: Dispatch<any>) => {
    const stateMachine = workflow.workflow

    // TODO: Throw if service creation failed
    const service = interpret(stateMachine).onTransition((state) => {
        dispatch(setWorkflowState(workflow.id, state as unknown as IWorkflow["state"]))
    }).start(State.create(stateMachine.initialState))

    return service
}

export const applyEvent = (workflow: IWorkflow, event: WorkflowEvent) => {
    if (workflow.service) {
        workflow.service.send(event)
    }
}

export const useWorkflowExecutor = () => {
    const { workflows } = useSelector((state: IParentStore) => ({
        workflows: state.workflowReducer.workflows
    }))

    const dispatch = useDispatch()

    // Initialize uninitialized workflows
    useEffect(() => {
        workflows.forEach((workflow: IWorkflow) => {
            if (!workflow.service) {
                try {
                    const service = initializeWorkflow(workflow, dispatch)
                    dispatch(setServiceInstance(workflow.id, service as unknown as IWorkflow["service"]))
                } catch (ex) {
                    // TODO: Log Exception
                    // TODO: Push the workflow out of reducer if invalid
                    // handleInvalidWorkflow()
                }
            }
        })

        return () => {
            // TODO: Stop services on component unmount only
            // workflows.forEach((workflow: IWorkflow) => {
            //     if (workflow.service) {
            //         workflow.service.stop()
            //     }
            //     dispatch(setServiceInstance(workflow.id, undefined))
            // })
        }
    }, [getMappedDependency(workflows, "workflow")])

    // Processing workflow events
    useEffect(() => {
        workflows.forEach(
            (workflow: IWorkflow) => {
                workflow.eventQueue.forEach((event: WorkflowEvent) => {
                    applyEvent(workflow, event)
                    dispatch(removeWorkflowEvent(workflow.id, event))
                })
            }
        )


        return () => {
            // TODO: Set workflows empty on component unmount only
            // dispatch(setWorkflows([]))
        }
    }, [getMappedDependency(workflows, "eventQueue")])

    // Clearing finished workflows
    useEffect(() => {
        const updatedWorkflows = workflows.filter((workflow: IWorkflow) => !workflow.state.done)

        if (!isEqual(workflows, updatedWorkflows)) {
            dispatch(setWorkflows(updatedWorkflows))
        }
    }, [getMappedDependency(workflows, "state")])
}
