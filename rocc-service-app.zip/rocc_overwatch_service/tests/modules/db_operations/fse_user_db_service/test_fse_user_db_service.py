import unittest
from unittest.mock import Mock, patch
from src.modules.db_operations.fse_user_db_service.fse_user_db_service import get_roles_identifiers_for_fse_roles, check_if_user_exists, get_all_customers, insert_fse_user_into_db


class RawDataInsertionExecTest(unittest.TestCase):
    mock_client = Mock()

    def test_insert_existing_customer_information(self):
        self.mock_client.execute.return_value = {
            "data": {
                "rocc_overwatch_customers": [
                    {"id": 100}
                ]
            }
        }
        return_data = get_roles_identifiers_for_fse_roles(self.mock_client)
        self.assertEqual(return_data, False)

    def test_check_if_user_exists(self):
        self.mock_client.execute.return_value = {
            "data": {
            }
        }
        return_data = check_if_user_exists(self.mock_client, "test@xyz.com")
        self.assertEqual(return_data, False)


class InsertFseUserIntoDb(unittest.TestCase):

    def insert_fse_user_into_db_succss(self):
        mock_client = Mock()
        mock_client.execute.return_value = "insert_rocc_users"
        response = insert_fse_user_into_db(client=mock_client, new_user_details={"role_ids": ["1"]}, current_user_uuid="current_user_uuid")
        self.assertEqual(response, "insert_rocc_users", "it inserts customers")

    def insert_fse_user_into_db_client_error(self):
        mock_client = Mock()
        mock_client.execute.return_value = "insert_rocc_users"
        response = insert_fse_user_into_db(client=mock_client, new_user_details=[], current_user_uuid="")
        self.assertEqual(response, "insert_rocc_users", "it inserts customers")


class GetAllCustomersTest(unittest.TestCase):

    def test_get_all_customers(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"data": True}
        response = get_all_customers(client=mock_client)
        self.assertEqual(response['data'], True, "it returns all customers")

    def test_get_all_customers_fail(self):
        return_data = get_all_customers({})
        self.assertEqual(return_data, False)

    @patch("src.modules.db_operations.fse_user_db_service.fse_user_db_service.extract_id_from_mutation_response", side_effect=lambda data, table, :  {})
    def test_insert_fse_user_into_db_pass(self, fn_extract):
        fn_extract.return_value = True
        mock_client = Mock()
        mock_client.execute.return_value = {"data": True}
        new_user_details = {"role_ids": ["123"], "id": "id", "preferredLanguage": "en-US",
                            "emailAddress": "testUser.email.com",
                            "name": {"given": "testgiven", "family": "testfamily",
                                     }}
        data_inserted = insert_fse_user_into_db(mock_client, new_user_details, "current_user_uuid")
        self.assertEqual(data_inserted, {})
