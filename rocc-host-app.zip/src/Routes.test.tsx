/*
 * Created on Wed Nov 10 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import Routes from "./Routes"
import * as helper from "./utility/helpers/helpers"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        featureFlags: { "rocc-radconnect": true },
        currentUser: {
            onBoarded: true,
            allRoles: ["Admin", "ExpertUser", "Radiologist", "Technologist"],
            clinicalRole: "Expert user"
        },
    }),
    useDispatch: () => void (0),
}))

jest.mock("./redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {
                onBoarded: true,
                allRoles: ["Admin", "ExpertUser", "Radiologist", "Technologist"],
                clinicalRole: "Expert user"
            }
        },
        featureFlagsReducer: { featureFlags: { "rocc-radconnect": true } },
    })
}))

describe("Routes Component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<Routes />)
    })

    it("Routes should contain Hash Router", () => {
        expect(wrapper.find("HashRouter")).toHaveLength(1)
    })

    it("Routes should route to a page", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/login")
        const page = wrapper.find("Route[path='/']")
        expect(page).toHaveLength(1)
        const render = page.prop("render")
        expect(render()).toBeDefined()
    })

    it("Routes should contain support route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/support")
        const support = wrapper.find("Route[path='/support']")
        expect(support).toHaveLength(1)
        const render = support.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain login route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/login")
        const login = wrapper.find("Route[path='/login']")
        expect(login).toHaveLength(1)
        const component = login.prop("component")
        expect(component()).toBeDefined()
    })
    it("Routes should contain forgotpassword route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/forgotpassword")
        const forgotpassword = wrapper.find("Route[path='/forgotpassword']")
        expect(forgotpassword).toHaveLength(1)
        const component = forgotpassword.prop("component")
        expect(component()).toBeDefined()
    })
    it("Routes should contain register route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/register")
        const register = wrapper.find("Route[path='/register']")
        expect(register).toHaveLength(1)
        const component = register.prop("component")
        expect(component()).toBeDefined()
    })
    it("Routes should contain setpassword route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/setpassword")
        const setpassword = wrapper.find("Route[path='/setpassword']")
        expect(setpassword).toHaveLength(1)
        const render = setpassword.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain resetpassword route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/resetpassword")
        const resetpassword = wrapper.find("Route[path='/resetpassword']")
        expect(resetpassword).toHaveLength(1)
        const render = resetpassword.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain sessionexpired route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/sessionexpired")
        const sessionexpired = wrapper.find("Route[path='/sessionexpired']")
        expect(sessionexpired).toHaveLength(1)
        const render = sessionexpired.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain settings route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/settings")
        const settings = wrapper.find("Route[path='/settings']")
        expect(settings).toHaveLength(1)
        const render = settings.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain consults route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/consults")
        const consults = wrapper.find("Route[path='/consults']")
        expect(consults).toHaveLength(1)
        const render = consults.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain logout route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/logout")
        const logout = wrapper.find("Route[path='/logout']")
        expect(logout).toHaveLength(1)
        const render = logout.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain idn route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/idn")
        const idn = wrapper.find("Route[path='/idn']")
        expect(idn).toHaveLength(1)
        const render = idn.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain admin route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/admin")
        const admin = wrapper.find("Route[path='/admin']")
        expect(admin).toHaveLength(1)
        const render = admin.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain scheduler route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/scheduler")
        const scheduler = wrapper.find("Route[path='/scheduler']")
        expect(scheduler).toHaveLength(1)
        const render = scheduler.prop("render")
        expect(render()).toBeDefined()
    })
    it("Routes should contain room monitoring route", () => {
        jest.spyOn(helper, "fetchRenderPage").mockReturnValue("/cctv")
        const cctv = wrapper.find("Route[path='/cctv']")
        expect(cctv).toHaveLength(1)
        const render = cctv.prop("render")
        expect(render()).toBeDefined()
    })
})
