/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import TabLayout from "./TabLayout"
import { shallow } from "enzyme"


describe("TabLayout Component", () => {
    let wrapper: any
    const props = {
        className: "right-sidebar-panel",
        tabBodyContent: <div>Tab Content</div>,
        tabActionContent: <div>Tab action</div>
    }
    beforeEach(() => {
        wrapper = shallow(<TabLayout {...props} />)
    })

    it("should render TabLayout component", () => {
        expect(wrapper.find("#tabLayout")).toHaveLength(1)
    })
})
