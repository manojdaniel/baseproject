/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import globalStore from "./globalStore"
import { dispatchToParentStore, fetchGlobalConfigs, fetchGlobalCurrentUser, fetchGlobalFeatureFlags, fetchGlobalLocations, fetchMetaSiteId, fetchGlobalOrgUUID, fetchGlobalURLs, getGlobalStoreDetails, fetchGlobalContacts, fetchGlobalNfccUpgradeStatus, fetchGlobalNfccBundleInfo, fetchGlobalPermissions, fetchGlobalOrgName, fetchRooms, fetchLocations } from "./externalAppStates"
import { USER_REDUCER } from "../../common/constants/constants"

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    DispatchAction: jest.fn(),
}))

describe("getGlobalStoreDetails tests", () => {
    it("get specific reducer value", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    currentUser: {
                        name: "Dummy user",
                        uuid: "uuid"
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(getGlobalStoreDetails({ storeName: "CC_HOST", reducerPath: USER_REDUCER }).currentUser.uuid).toBe("uuid")
    })

    it("should fetch global URLS", () => {
        const url = "https://platinum-rocc.cloud.pcftest.com/philips/rocc"
        const storeData = {
            CC_HOST: {
                configReducer: {
                    urls: {
                        IAM_SERVICES_URL: url,
                        COMMUNICATION_SERVICES_URL: url,
                        CONSOLE_SERVICES_URL: "https://INGBTCPIC6VL128.code1.emi.philips.com:8498/philips/rocc",
                        PROXY_URL: "https://platinum-rocc.cloud.pcftest.com",
                        MANAGEMENT_SERVICE_URL: url,
                        GRAPHQL_API_HSDP_URI: "https://platinum-rocc.cloud.pcftest.com/v1/graphql",
                        GRAPHQL_API_HSDP_WS_URI: "wss://platinum-rocc.cloud.pcftest.com:4443/v1/graphql",
                        RBAC_SERVICE_URL: url

                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalURLs()).toBe(storeData.CC_HOST.configReducer.urls)
    })

    it("should fetch global feature flags", () => {
        const storeData = {
            CC_HOST: {
                featureFlagsReducer: {
                    featureFlags: {
                        "rocc-emerald": false,
                        "rocc-emerald-edit": true,
                        "rocc-emerald-view": true,
                        "rocc-multi-camera": false,
                        "rocc-multi-console": false,
                        "rocc-patient-details-visibility": true,
                        "rocc-protocol-transfer": true,
                        "rocc-radconnect": true,
                        "rocc-scheduler": false,
                        "rocc-self-service": false,
                        "rocc-vnc": false
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalFeatureFlags()).toBe(storeData.CC_HOST.featureFlagsReducer.featureFlags)
    })

    it("should fetch global Org Id", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    metaData: {
                        id: -1,
                        displayName: "",
                        name: "",
                        orgId: "e9101b82-493c-40df-b539-d605732ffbb4",
                        contacts: []


                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalOrgUUID()).toBe(storeData.CC_HOST.customerReducer.metaData.orgId)
    })

    it("should fetch global configs", () => {
        const storeData = {
            CC_HOST: {
                configReducer: {
                    configs: {
                        ROCC_DEV: "true"
                    },
                    preSignedUrls: { nfccBundle: {} }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalConfigs()).toBe(storeData.CC_HOST.configReducer.configs)
        expect(fetchGlobalNfccBundleInfo()).toBe(storeData.CC_HOST.configReducer.preSignedUrls.nfccBundle)
    })

    it("should fetch metasite id", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    metaData: {
                        id: 4
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchMetaSiteId()).toBe(storeData.CC_HOST.customerReducer.metaData.id)
    })

    it("should dispatch Global Action", () => {
        dispatchToParentStore({})
    })

    it("should fetch fetchGlobalCurrentUser", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    currentUser: {
                        name: "",
                        uuid: "",
                        accessToken: ""
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalCurrentUser()).toBe(storeData.CC_HOST.userReducer.currentUser)
    })

    it("should fetch fetchGlobalLocations", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    locations: []
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalLocations()).toBe(storeData.CC_HOST.customerReducer.locations)
        expect(fetchLocations()).toBe(storeData.CC_HOST.customerReducer.locations)
    })

    it("should fetch global contacts", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    contacts: []
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalContacts()).toEqual(storeData.CC_HOST.userReducer.contacts)
    })

    it("should fetch global nfccupgrade status", () => {
        const storeData = {
            CC_HOST: {
                appReducer: {
                    nfccUpgradeAvailable: true
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalNfccUpgradeStatus()).toBeTruthy()
    })

    it("should fetch global permissions", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    permissions: {}
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalPermissions()).toBe(storeData.CC_HOST.userReducer.permissions)
    })

    it("should fetch global org name", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    metaData: { name: "" }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalOrgName()).toBe(storeData.CC_HOST.customerReducer.metaData.name)
    })

    it("should fetch global rooms", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    rooms: []
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchRooms()).toBe(storeData.CC_HOST.customerReducer.rooms)
    })
})
