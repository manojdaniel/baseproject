/*
 * Created on Tue Nov 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, EPosition, getRoomDetailFromUuid } from "@rocc/rocc-client-services"
import { IncognitoComponent } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { connectionUtility, getConnectionAdapter } from "../../common/helpers/connection"
import { onReceiverUseConfirmation } from "../../common/helpers/consoleUtility"
import { checkIfEmeraldEnabled, checkIfIncognitoConsoleEnabled, checkIfMultiRoomIsDisabled, isNFCCAllowed, isRoomMonitoringEnabled } from "../../common/helpers/helpers"
import { GLOBAL_LEFTSIDE_PANEL } from "../../redux/actions/types"
import { IReceiverSelectionModal, IStore } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchRooms } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import NfccDropdown from "../nfcc-dropdown/NfccDropdown"

interface IIncognitoConsole {
    roomUuid: string
    showTitle?: boolean
    iconPosition?: EPosition
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    component?: string
}

const componentName = "Incognito Console"

const IncognitoConsole = (props: IIncognitoConsole) => {

    const { roomUuid, showTitle, iconPosition, setReceiverSelectionModal } = props

    const {
        featureFlags,
        consoleSessions,
        commandCenterDetails,
        receivers,
        consoleOperation,
        protocolTransferStatus,
        currentUser,
        permissions
    } = useSelector((state: IStore) => ({
        featureFlags: state.externalReducer.featureFlags,
        consoleSessions: state.consoleReducer.consoleSessions,
        commandCenterDetails: state.consoleReducer.commandCenterDetails,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        consoleOperation: state.consoleReducer.consoleOperation,
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        currentUser: state.externalReducer.currentUser,
        permissions: state.externalReducer.permissions
    }))

    const { intl } = getIntlProvider()

    const [loading, setLoading] = useState(false)
    const [disabled, setDisabled] = useState(false)
    const [connectionState, setConnectionState] = useState(false)
    const [preferredConnection, setPreferredConnection] = useState(null)
    const consoleSessionsRef = useRef(consoleSessions)
    const showMenu = (!!permissions.CONSOLE_VIEW_INCOGNITO && isNFCCAllowed())
    const { INCOGNITO_VIEW } = EConnectionType

    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    useEffect(()=>{
        const availableConnections = connectionUtility.createConnectionList(getRoomDetailFromUuid(fetchRooms(), roomUuid),{
            username : currentUser.kvmUsername,
            seatname: commandCenterDetails.commandCenterSeat.seatName
        })
        if (availableConnections.length == 0){
            return
        }
        const preferredConnectionSource = getConnectionAdapter().getPreferredConnection(availableConnections, EConnectionType.INCOGNITO_VIEW)
        if (!preferredConnectionSource){
            return
        }
        if(preferredConnectionSource.connectionMode == EModalityConnectionMode.KVM){
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.EMERALD)){
                // Check Emerald App Permissions and Configs
                const emeraldIncognitoEnabled = checkIfEmeraldEnabled(!!permissions.CONSOLE_VIEW_INCOGNITO, currentUser.kvmUsername)
                const isEmeraldEnabled = isRoomMonitoringEnabled(featureFlags) ?
                    emeraldIncognitoEnabled && receivers.length === 0 :
                    emeraldIncognitoEnabled
                if(!isEmeraldEnabled || !showMenu){
                    preferredConnectionSource.subConnectionMode.filter((subConnection)=>subConnection!==EModalitySubConnectionMode.EMERALD)
                }
            }
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.CC)){
                const status = !checkIfIncognitoConsoleEnabled(permissions, receivers)
                if(status){
                    preferredConnectionSource.subConnectionMode.filter((subConnection)=>subConnection!==EModalitySubConnectionMode.CC)
                }
            }
        }
        setPreferredConnection(preferredConnectionSource as any)
    },[commandCenterDetails])

    useEffect(() => {
        const { connectionState, loading, disabled } = getConnectionAdapter().getViewOrPMConsoleStatus({
            consoleOperation, consoleSessions: consoleSessionsRef.current, roomUuid, connectionType: INCOGNITO_VIEW, protocolTransferStatus
        })
        setLoading(loading)
        setDisabled(disabled)
        setConnectionState(connectionState)
    }, [consoleOperation, consoleSessionsRef.current, protocolTransferStatus])

    const handleOnclick = (connectionMode: EModalityConnectionMode, subConnectionMode : EModalitySubConnectionMode| null) => {

        const props = {
            connectionMode,
            subConnectionMode,
            roomUuid,
            connectionType: INCOGNITO_VIEW,
            receivers,
            consoleSessions: consoleSessionsRef.current,
            onReceiverSelectionRequired: ()=> setReceiverSelectionModal({ showReceiverModal: true, connectionType: INCOGNITO_VIEW }),
            onReceiverUseConfirmation : (props: any)=> onReceiverUseConfirmation({...props, setReceiverSelectionModal}),
            featureFlags,
            componentName
        }

        if (subConnectionMode === EModalitySubConnectionMode.CC) {
            checkIfMultiRoomIsDisabled(featureFlags, receivers) ? getConnectionAdapter().connect(props)
                : setReceiverSelectionModal({ showReceiverModal: true, connectionType: INCOGNITO_VIEW })
        } else {
            getConnectionAdapter().connect(props)
        }
    }

    const performConsoleDisconnectionOps = () => {
        const { status }= getConnectionAdapter().disconnect({ roomUuid, connectionType: INCOGNITO_VIEW })
        if(status){
            dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: false,
                    activeLeftPanel: "",
                    desktopFullScreen: false,
                }
            })
        }
    }

    if (connectionState || loading) {
        return <IncognitoComponent
            loading={loading}
            disabled={disabled}
            connectionState={connectionState}
            onClickHandler={performConsoleDisconnectionOps}
            iconPosition={iconPosition ? iconPosition : EPosition.HORIZONTAL}
            showTitle={showTitle ?? false}
        />
    }
    

    return (
        <>
            <NfccDropdown
                text={intl.formatMessage({ id: "content.mode.incognitoMode", defaultMessage: en["content.mode.incognitoMode"] })}
                showMenu={showMenu}
                commandCenterDetails={preferredConnection}
                featureFlags={featureFlags}
                handleClick={handleOnclick}
            />
        </>
    )
}

export default IncognitoConsole
