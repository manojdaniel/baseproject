/*
 * Created on Wed Sept 22 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import AvSetting from "./AvSettingComponent"

const videoRef: any = {}

const props = {
    active: true,
    customLoader: false,
    audioCameraAccessError: false,
    audioInputOptions: [{ value: "AudioInput", text: "AudioInput" }],
    audioOutputOptions: [{ value: "AudioOutput", text: "AudioOutput" }],
    videoInputOptions: [{ value: "VideoInput", text: "VideoInput" }],
    handleSettings: jest.fn(),
    handleVolume: jest.fn(),
    videoRef: videoRef,
    webCamAvailable: true,
}

jest.mock("react-redux", () => ({
    useSelector: jest.fn().mockReturnValue({
        audioSource: "audioSource",
        videoSource: "videoSource",
        audioOutput: "audioOutput",
        volume: 100,
        currentUser: {
            clinicalRole: "device",
        },
        videoCallStatus: [{ contextId: "contextId", callStatus: "connected" }],
        desktopCallWindowFullScreen: false,
        connectedCallDetails: {
            numOfParticipants: -1
        }
    })
}))

describe("AvSetting tests", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<AvSetting {...props} />)
    })

    it("should display audio error", () => {
        props.audioCameraAccessError = true
        props.webCamAvailable = false
        wrapper = shallow(<AvSetting {...props} />)
        expect(wrapper.find("img")).toBeDefined()
    })
})
