import React, { useEffect, useState } from "react";
import { Table,Layout } from "antd";
import "../../../assets/common/CommonTables.scss";
import moment from "moment";

interface Props {
	data: any[];
}
const AssetCard = ({ data }: Props) => {
	const [assetCardlist, setAssetCardlist] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				timeStamp: moment(new Date(`${item.timeStamp}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				description: item.description,
				status: item.status,
			};
		});
		setAssetCardlist(mydata);
	}, [data]);

	const columns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: '30%',
		},

		{
			title: "ALERT DESCRIPTION",
			dataIndex: "description",
			key: "description",
			width: '40%',
		},
		{
			title: "ALERT STATUS",
			dataIndex: "status",
			key: "status",
			width: '30%',

			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
	];

	const columns2 = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: '30%',
		},

		{
			title: "ALERT DESCRIPTION",
			dataIndex: "description",
			key: "description",
			width: '40%',
		},
		{
			title: "ALERT STATUS",
			dataIndex: "status",
			key: "status",
			width: '30%',

			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
	];

	return (
		<>
		{(() => {
			if (currentScreenWidth > 2000) {
				return (
					<Table
						columns={columns}
						dataSource={assetCardlist}
						tableLayout={undefined}
						pagination={false}
						scroll={{ x: true, y: 100 }}
					/>
				);
			} else {
				return (
					<Table
						columns={columns2}
						tableLayout={undefined}
						dataSource={assetCardlist}
						pagination={false}
						scroll={{ x: true, y: 100 }}
					/>
				);
			}
		})()}
		</>
	);
};

export default AssetCard;
