/*
 * Created on Thu Aug 26 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, EClinicalRole, EUserPresence, ICallStatus, IContactInfo, IUserInfo } from "@rocc/rocc-client-services"
import { checkIfCallIsAlreadyActive, checkIfNewCallInitiated, createICallStatusObject, disconnectAllCallStatus, enableBrowserToPhoneCall, filterCallStatus, filterCallStatusByContextId, filterCallStatusByContextIdAndStatus, getCallStatusFromICallStatus, upsertCallStatus } from "./callUtility"

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        callReducer: {
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    callAcceptedTime: new Date(),
                    participants: [{ uuid: "uuid" }]
                }
            },
            videoCallStatus: [{ contextId: "contextId", callStatus: "connected" }]
        },
        externalReducer: {
            featureFlags: {},
        }
    })
}))
const { IDLE } = ECallStatus
let callStatuses: ICallStatus[] = []
const contactInfo: IContactInfo = {
    id: "string",
    uuid: "string",
    siteId: [],
    orgId: "string",
    status: EUserPresence.AVAILABLE,
    name: "string",
    phoneNumber: "string",
    clinicalRole: EClinicalRole.EXPERTUSER,
    email: "string",
    roomName: "string",
    allRoles: [],
    secondaryUUID: "string",
    secondaryName: "string",
    modalities: [],
    description: "string"
}
const currentUser: IUserInfo = {
    accessToken: "string",
    accessTokenExpiryTime: "",
    onBoarded: true,
    sessionId: "string",
    locale: "string",
    id: "",
    uuid: "",
    siteId: [],
    orgId: "",
    status: EUserPresence.AVAILABLE,
    name: "",
    phoneNumber: "",
    clinicalRole: EClinicalRole.DEFAULT,
    email: "",
    roomName: "",
    allRoles: [],
    secondaryUUID: "",
    secondaryName: "",
    modalities: [],
    description: ""
}
beforeEach(() => {
    callStatuses = [{ contextId: "contextId", callStatus: IDLE }]
})

describe("filterCallStatus test", () => {
    it("test when include status is true", () => {
        expect(filterCallStatus(callStatuses, IDLE, true).length).toBe(1)
    })

    it("test when include status is false", () => {
        expect(filterCallStatus(callStatuses, IDLE, false).length).toBe(0)
    })
})

describe("filterCallStatus by contextId test", () => {
    it("test when include status is true", () => {
        expect(filterCallStatusByContextId(callStatuses, "contextId", true).length).toBe(1)
    })

    it("test when include status is false", () => {
        expect(filterCallStatusByContextId(callStatuses, "contextId", false).length).toBe(0)
    })
})

describe("filterCallStatusByContextIdAndStatus test", () => {
    it("test when include status is true", () => {
        expect(filterCallStatusByContextIdAndStatus(callStatuses, "contextId", [IDLE], true).length).toBe(1)
    })

    it("test when include status is false", () => {
        expect(filterCallStatusByContextIdAndStatus(callStatuses, "contextId", [IDLE], false).length).toBe(0)
    })
})

describe("CreateICallStatusObject test", () => {
    it("check if callStatus object is present", () => {
        expect(createICallStatusObject("contextId", IDLE).contextId).toBe("contextId")
    })
})

describe("getCallStatusFromICallStatus test", () => {
    it("test get call status", () => {
        expect(getCallStatusFromICallStatus(callStatuses)[0]).toBe(IDLE)
    })
})

describe("enableBrowserToPhoneCall", () => {
    it("enableBrowserToPhoneCall", () => {
        const contactInfo = {} as IContactInfo
        const currentUser = { accessToken: "123" } as IUserInfo
        const setPhoneCallStatusMock = jest.fn()
        const toggleRightSidebarPanelActionMock = jest.fn()
        enableBrowserToPhoneCall(contactInfo, currentUser, setPhoneCallStatusMock, toggleRightSidebarPanelActionMock)
        expect(toggleRightSidebarPanelActionMock).toHaveBeenCalled()
    })
})
describe("getCallStatusFromICallStatus test", () => {
    it("test get call status", () => {
        expect(enableBrowserToPhoneCall(contactInfo, currentUser, () => void (0), () => void (0))).toBeUndefined()
    })
})

describe("upsertCallStatus test", () => {
    it("test get upsertCallStatus ", () => {
        expect(upsertCallStatus).toHaveLength(2)
    })
})

describe("disconnectAllCallStatus test", () => {
    it("test to disconnectAllCallStatus ", () => {
        expect(disconnectAllCallStatus).toHaveLength(0)
    })
})

describe("checkIfCallIsAlreadyActive test", () => {
    it("test to checkIfCallIsAlreadyActive ", () => {
        expect(checkIfCallIsAlreadyActive("")).toBe(false)
    })
})

describe("checkIfNewCallInitiated test", () => {
    it("test to checkIfNewCallInitiated ", () => {
        expect(checkIfNewCallInitiated).toHaveLength(0)
    })
})
