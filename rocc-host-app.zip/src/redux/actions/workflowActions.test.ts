/*
 * Created on Mon Apr 18 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ADD_WORKFLOW_EVENT, EPresignedStatus, ERoccWorkflow, IPresignedWorkflow, IWorkflow, IWorkflowConfig, IWorkflowReducer, REGISTER_WORKFLOW } from "@rocc/rocc-client-services"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { initialStatesForWorkflowReducer } from "../reducers/workflowReducer"
import { ADD_PRESIGNED_WORKFLOW, SET_WORKFLOWS, UPDATE_PRESIGNED_WORKFLOW, UPDATE_PRESIGNED_WORKFLOW_STATUS, UPDATE_WORKFLOW_SERVICE } from "./types"
import { addPresignedWorkflow, registerRawWorkflow, registerWorkflow, sendWorkflowEvent, setServiceInstance, setWorkflows, updatePresignedWorkflow, updatePresignedWorkflowStatus } from "./workflowActions"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

const singleWorkflowState: IWorkflowReducer = {
    workflows: [
        {
            id: "selector",
            type: ERoccWorkflow.PARK_AND_INITIATE_CALL,
            workflow: {} as IWorkflow["workflow"],
            state: {} as IWorkflow["state"],
            eventQueue: []
        }
    ],
    presignedWorkflows: [
        {
            id: "",
            resourceId: "",
            startTime: "",
            expiryTime: "",
            hashCode: "",
            subject: "CONSOLE",
            status: EPresignedStatus.NOT_STARTED_YET,
            additionalAttributes: {}
        }
    ]
}

const mockDispatch = jest.fn()
jest.mock("react-redux", () => ({
    useDispatch: () => mockDispatch
}))

const mockWorkflow = {
    id: "",
    type: ERoccWorkflow.PARK_AND_INITIATE_CALL,
    state: {} as IWorkflow["state"],
    workflow: {} as IWorkflow["workflow"],
    eventQueue: [],
} as IWorkflow

const mockPresignedWorkflow: IPresignedWorkflow = {
    id: "id", resourceId: "resourceId", hashCode: "", startTime: "", expiryTime: "", status: EPresignedStatus.NOT_STARTED_YET, additionalAttributes: {}, subject: "CONSOLE"
}

const mockService = {} as IWorkflow["service"]

describe("Workflow actions", () => {
    const store = mockStore(initialStatesForWorkflowReducer)
    const populatedStore = mockStore(singleWorkflowState)
    beforeEach(() => {
        store.clearActions()
        populatedStore.clearActions()
    })
    afterEach(() => {
        store.clearActions()
        populatedStore.clearActions()
    })

    it("define setWorkflows and dispatch SET_WORKFLOWS action", () => {
        store.dispatch(setWorkflows([mockWorkflow]) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(SET_WORKFLOWS)
    })

    it("define registerRawWorkflow and dispatch REGISTER_WORKFLOW action", () => {
        store.dispatch(registerRawWorkflow({} as unknown as IWorkflowConfig) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(REGISTER_WORKFLOW)
    })

    it("define registerWorkflow and dispatch REGISTER_WORKFLOW action", () => {
        store.dispatch(registerWorkflow(ERoccWorkflow.PARK_AND_INITIATE_CALL) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(REGISTER_WORKFLOW)
    })

    it("define setServiceInstance and dispatch UPDATE_WORKFLOW_SERVICE action", () => {
        populatedStore.dispatch(setServiceInstance(singleWorkflowState.workflows[0].id, mockService) as any)
        expect(String(populatedStore.getActions())).toBeDefined()
        expect(String(populatedStore.getActions()[0].type)).toBe(UPDATE_WORKFLOW_SERVICE)
    })

    it("define sendWorkflowEvent and dispatch ADD_WORKFLOW_EVENT action", () => {
        populatedStore.dispatch(sendWorkflowEvent(singleWorkflowState.workflows[0].id, "") as any)
        expect(String(populatedStore.getActions())).toBeDefined()
        expect(String(populatedStore.getActions()[0].type)).toBe(ADD_WORKFLOW_EVENT)
    })

    it("define addPresignedWorkflow and dispatch ADD_PRESIGNED_WORKFLOW action", () => {
        store.dispatch(addPresignedWorkflow(mockPresignedWorkflow) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(ADD_PRESIGNED_WORKFLOW)
    })

    it("define updatePresignedWorkflow and dispatch UPDATE_PRESIGNED_WORKFLOW action", () => {
        store.dispatch(updatePresignedWorkflow("id", mockPresignedWorkflow) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(UPDATE_PRESIGNED_WORKFLOW)
    })

    it("define updatePresignedWorkflowStatus and dispatch UPDATE_PRESIGNED_WORKFLOW_STATUS action", () => {
        store.dispatch(updatePresignedWorkflowStatus("id", EPresignedStatus.VALID) as any)
        expect(String(store.getActions())).toBeDefined()
        expect(String(store.getActions()[0].type)).toBe(UPDATE_PRESIGNED_WORKFLOW_STATUS)
    })
})
