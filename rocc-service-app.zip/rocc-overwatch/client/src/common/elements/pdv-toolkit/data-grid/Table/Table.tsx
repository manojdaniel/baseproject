import React from "react"
import { Table } from "semantic-ui-react"
import { ITable, ITableColumn } from "../types"
import PDVTableHead from "../TableHead/TableHead"
import PDVTableHeader from "../TableHeader/TableHeader"
import PDVTableBody from "../TableBody/TableBody"
import "./Table.scss"

const PDVTable: React.FC<ITable> = ({
    loading, title, data, columns, initialPageSize, sortColumn, selectedRowIndex, currentRow, multiSelect,
    onSort, onRowClick, onDrillDown, tableHeadButton, searchBox, noRecords }) => {
    const getDisplayColumns = () => {
        return columns.filter((column: ITableColumn) => {
            return column.display === true
        })
    }
    return (
        <>
            {title &&
                <PDVTableHead
                    title={title}
                    actions={
                        <>
                            {tableHeadButton && tableHeadButton()}
                            {searchBox && searchBox()}
                        </>
                    }
                />}
            {noRecords ?
                <Table className={"noRecords"}>
                    {"No Records found"}
                </Table>
                :
                <Table selectable={false} sortable={true} singleLine={true} fixed={true} className="table-scrolling">
                    <PDVTableHeader
                        columns={getDisplayColumns()}
                        sortColumn={sortColumn}
                        onSort={onSort}
                        multiSelect={multiSelect}
                    />
                    <PDVTableBody
                        loading={loading}
                        data={data}
                        columns={columns}
                        initialPageSize={initialPageSize}
                        selectedRowIndex={selectedRowIndex}
                        multiSelect={multiSelect}
                        onRowClick={onRowClick}
                        onDrillDown={onDrillDown}
                        currentRow={currentRow}
                    />
                </Table>
            }
        </>
    )
}

export default PDVTable