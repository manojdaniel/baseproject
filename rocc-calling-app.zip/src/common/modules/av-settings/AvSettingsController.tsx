/*
 * Created on Wed Sept 22 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { errorLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { MutableRefObject, useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { AUDIO_INPUT, AUDIO_OUTPUT, DEFAULT, VIDEO_INPUT } from "../../../constants/constants"
import { setAVCallVolume, settingsVideoAudioCallStatus } from "../../../redux/actions/callActions"
import { EAvSettingsType, IStore } from "../../../redux/interfaces/types"
import { filterCallStatus } from "../../helpers/callUtility"
import AvSettingComponent from "./AvSettingComponent"

export interface IAvSettingsProps {
    active: boolean
    component: string
}

export interface MediaOptions {
    value: string
    text: string
}

const AvSettingController = (props: IAvSettingsProps) => {
    const { active, component } = props
    const [audioCameraAccessError, setAudioCameraAccessError] = useState(false)
    const [webCamAvailable, setWebCamAvailable] = useState(false)
    const [audioInputOptions, setAudioInputOptions] = useState([] as MediaOptions[])
    const [audioOutputOptions, setAudioOutputOptions] = useState([] as MediaOptions[])
    const [videoInputOptions, setVideoInputOptions] = useState([] as MediaOptions[])

    const {
        videoSource, videoCallStatus, numOfParticipants,
    } = useSelector((state: IStore) => ({
        videoSource: state.callReducer.videoSource,
        videoCallStatus: state.callReducer.videoCallStatus,
        numOfParticipants: state.callReducer.callDetails.connectedCallDetails.numOfParticipants,
    }))

    const videoRef: MutableRefObject<any> = useRef()

    const dispatch = useDispatch()

    const stopMediaTracks = () => {
        if (videoRef.current && videoRef.current.srcObject) {
            videoRef.current.srcObject.getVideoTracks().forEach((track: MediaStreamTrack) => {
                track.stop()
                track.enabled = false
            })
            videoRef.current.srcObject = null
        }
    }

    const checkCameraAccess = async () => {
        try {
            const userMediaStream = await navigator.mediaDevices.getUserMedia({ video: true })
            userMediaStream.getTracks().forEach((track) => track.stop())
            return true
        } catch (error) {
            errorLogger(`Failed to access web camera, please check if permission is granted`)
            return false
        }
    }

    const checkMicrophoneAccess = async () => {
        try {
            const userMediaStream = await navigator.mediaDevices.getUserMedia({ audio: true })
            userMediaStream.getTracks().forEach((track) => track.stop())
            return true
        } catch (error) {
            errorLogger(`Failed to access web camera, please check if permission is granted`)
            return false
        }
    }

    const audioCameraAccess = async () => {
        // Check that the browser supports getUserMedia.
        const mediaDeviceAccess = await Promise.all([checkCameraAccess(), checkMicrophoneAccess()])
        setWebCamAvailable(mediaDeviceAccess[0])
        const hasMicrophone = mediaDeviceAccess[1]
        if (!hasMicrophone) {
            audioCameraAccessErrorCallback(new Error(`Failed to fetch getUserMedia response`))
        } else {
            audioCameraAccessSuccessCallback()
        }
    }

    const audioCameraAccessSuccessCallback = () => {
        navigator.mediaDevices.enumerateDevices().then((deviceInfos) => {
            const audioInputOptions = []
            const audioOutputOptions = []
            const videoInputOptions = []
            for (let i = 0; i !== deviceInfos.length; ++i) {
                const deviceInfo = deviceInfos[i]
                const deviceId = deviceInfo.deviceId
                const devicelabel = deviceInfo.label
                if (deviceInfo.kind === AUDIO_INPUT) {
                    audioInputOptions.push({ value: deviceId, text: devicelabel })
                } else if (deviceInfo.kind === AUDIO_OUTPUT) {
                    audioOutputOptions.push({ value: deviceId, text: devicelabel })
                } else if (deviceInfo.kind === VIDEO_INPUT) {
                    videoInputOptions.push({ value: deviceId, text: devicelabel })
                }
            }
            setAudioInputOptions(audioInputOptions)
            setAudioOutputOptions(audioOutputOptions)
            setVideoInputOptions(videoInputOptions)
            setAudioCameraAccessError(false)
        }).catch(handleError)
    }

    const audioCameraAccessErrorCallback = (error: any) => {
        errorLogger(`avSettingsController.tsx: The following error occurred when trying to use getUserMedia: ${error}`)
        setAudioCameraAccessError(true)
    }

    const handleError = (error: Error) => {
        errorLogger(`avSettingsController.tsx: Navigator.MediaDevices.getUserMedia error: ${error.message} : ${error.name}`)
        setAudioCameraAccessError(true)
    }

    const handleSettings = (avSettingType: EAvSettingsType, data: any) => {
        const selectedOption = { sourceLabel: "", sourceValue: "" }
        if (avSettingType === EAvSettingsType.VIDEO_INPUT) {
            data.options.filter((AVOptions: MediaOptions) => {
                if (AVOptions.value === data.value) {
                    selectedOption.sourceLabel = AVOptions.text
                    selectedOption.sourceValue = AVOptions.value
                }
            })
            sendLogsToAzure({ contextData: { component, event: `${"Video Source is "} ${selectedOption}` } })
        }
        const selectedValue = data.value
        dispatch(settingsVideoAudioCallStatus(avSettingType, selectedValue))
        if (avSettingType === EAvSettingsType.VIDEO_INPUT) {
            useUserMedia(selectedValue)
        }
    }

    const useUserMedia = async (selectedVideoSource: string) => {
        try {
            stopMediaTracks()
            const deviceId = selectedVideoSource ? selectedVideoSource : DEFAULT
            const constraint = { audio: false, video: { deviceId } }
            const mediaStream = await navigator.mediaDevices.getUserMedia(constraint)
            if (mediaStream && videoRef.current) {
                videoRef.current.srcObject = mediaStream
                if (!selectedVideoSource && mediaStream.getVideoTracks().length) {
                    const videoDeviceId = mediaStream.getVideoTracks()[0].getSettings().deviceId
                    dispatch(settingsVideoAudioCallStatus(EAvSettingsType.VIDEO_INPUT, videoDeviceId ? videoDeviceId : ""))
                }
            }
        } catch (err) {
            errorLogger(`Failed to initiate camera feed : ${JSON.stringify(err)}`)
        }
    }

    const handleVolume = (data: any) => {
        const selectedValue = data.value
        dispatch(setAVCallVolume(selectedValue))
    }

    useEffect(() => {
        if (filterCallStatus(videoCallStatus, ECallStatus.CONNECTED, true).length) {
            if (numOfParticipants > 1 || !active) {
                stopMediaTracks()
            } else if (active && webCamAvailable) {
                useUserMedia(videoSource)
            }
        } else if (active && webCamAvailable) {
            useUserMedia(videoSource)
        } else {
            stopMediaTracks()
        }
    }, [active, videoCallStatus, numOfParticipants, webCamAvailable])

    useEffect(() => {
        audioCameraAccess()
        return (() => {
            stopMediaTracks()
        })
    }, [])

    return (
        <AvSettingComponent
            active={active}
            handleSettings={handleSettings}
            handleVolume={handleVolume}
            audioCameraAccessError={audioCameraAccessError}
            audioInputOptions={audioInputOptions}
            audioOutputOptions={audioOutputOptions}
            videoInputOptions={videoInputOptions}
            customLoader={true}
            videoRef={videoRef}
            webCamAvailable={webCamAvailable}
        />
    )
}

export default AvSettingController
