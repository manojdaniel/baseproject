import moment from 'moment'


export const getSensorIdList = (data: any) => {
    let result: any[] = []
    data.forEach((item: any) => {
        result.push(item.value.toString())
    })
    return result
}

export const getSensorTodateAdded = (date: any) => {
    let value = moment(date).add(30, 'days').format("YYYY-MM-DD")
    return value
}


export const getSensorTodaySubtractedDate = (date: any) => {
    let value = moment(date).subtract(30, 'days').format("YYYY-MM-DD")
    return value
}

export const getDateUtcFormat = (date: any) => {
    let value = moment.utc(date).format()
    return value
}

export const getTimeZone = () => {
    let date = new Date();
    let dateAsString: any
    dateAsString = date.toString();
    let value = dateAsString.match(/\(([^\)]+)\)$/)[1];
   
    return value
}

export const getDateTimeFormatted = (value) => {
    var formattedDateTimeStr = value.replace('T', ' ');
    return formattedDateTimeStr
}

export const getDeviationTransformer = (data: any) => {
    let result: any[] = []
    // data.forEach((item: any) => {
    //     var newDate = new Date(item.localTime);
    //     var dat1 = new Date(item.localTime).getTime()

    //     result.push({
    //         localTime: dat1,
    //         distance: item.distance,
    //         alertThreshold: item.alertThreshold,
    //         warningThreshold: item.warningThreshold,
    //         status: item.status,
    //         time: "Time " + newDate.getHours() + ":" + newDate.getMinutes().toString(),

    //     })
    // })

    // var updatedData = data.map(function (item) {
    //     var date = new Date(item.localTime);
    //     var unixTimeMilliseconds = date.getTime();
    //     return { ...item, localTime: unixTimeMilliseconds, time: "12" }; // Create a new object with all the same properties, but replace 'localTime'
    // });

    // data.forEach(function (item, index) {
    //     var date = getDateTimeFormatted(item.localTime);
    //     var unixTimeMilliseconds = new Date(date).getTime();
    
    // });

  



    var updatedData1 = data.map(function (item) {
        var dateStr = item.localTime;
        if (!dateStr.endsWith('Z')) {
            dateStr += 'Z';  // Assume the time is in UTC if no time zone information is included
        }
        var date = new Date(dateStr);
        var unixTimeMilliseconds = date.getTime();

        var dateTohours = new Date(unixTimeMilliseconds);

        // Get hours and minutes. The getUTCHours() and getUTCMinutes() methods return
        // the hours and minutes (respectively) in UTC.
        var hours = dateTohours.getUTCHours();
        var minutes = dateTohours.getUTCMinutes();

        // Format the hours and minutes as 2-digit strings.
        var hoursStr = hours.toString().padStart(2, '0');
        var minutesStr = minutes.toString().padStart(2, '0');

        var timeStr = hoursStr + ':' + minutesStr;
        

        // Return a new object with the original properties and the new 'unixTime' property
        return { ...item, localTime: getDateTimeFormatted(item.localTime), localTime1: unixTimeMilliseconds, time: timeStr };
    });



   
    return updatedData1
}








// const date = new Date();
// let dateAsString: any
// dateAsString = date.toString();
// const timezone = dateAsString.match(/\(([^\)]+)\)$/)[1];

// var matches = timezone.match(/\b(\w)/g);
// var abbreviations = matches.join('');
