/*
 * Created on Thu Apr 07 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, ERoccWorkflow, IParentStore, IWorkflow, LogoutContext } from "@rocc/rocc-client-services"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { DISCONNECT_CALL, DISCONNECT_CONSOLE_SESSION, FINISHED, HOST_LOGGED_OUT, LOGOUT, MULTI_EDIT_INITIATE_CALL, MULTI_EDIT_START_EDITING, PARK_AND_INITIATE_CALL, PARK_AND_RESUME, PARK_AND_START_EDITING, TRACKED_WORKFLOWS } from "../../constants/constants"
import { TRACK } from "../../constants/tracking"
import { logout } from "../../redux/actions/userAction"
import { sendWorkflowEvent } from "../../redux/actions/workflowActions"
import { getCurrentUserData, getMappedDependency, trackEvent } from "../../utility/helpers/helpers"
import { getDurationInFormat } from "../../utility/math/mathUtility"

export const useWorkflowController = () => {
    const {
        workflows,
        loginClick
    } = useSelector((state: IParentStore) => ({
        workflows: state.workflowReducer.workflows.filter(
            (workflow: IWorkflow) => TRACKED_WORKFLOWS.includes(workflow.type)
        ),
        loginClick: state.appReducer.loadTimes.loginClick
    }))

    const dispatch = useDispatch()

    useEffect(() => {
        workflows.forEach((workflow: IWorkflow) => processWorkflow(workflow.type, workflow))
    }, [getMappedDependency(workflows, "state")])

    const processWorkflow = (workflowType: ERoccWorkflow, workflow: IWorkflow) => {
        switch (workflowType) {
            case PARK_AND_INITIATE_CALL:
            case PARK_AND_START_EDITING:
            case PARK_AND_RESUME:
            case MULTI_EDIT_INITIATE_CALL:
            case MULTI_EDIT_START_EDITING:
            case DISCONNECT_CALL:
            case DISCONNECT_CONSOLE_SESSION:
            case LOGOUT:
                return handleStateFlow(workflow)
            default:
        }
    }

    const handleStateFlow = (workflow: IWorkflow) => {
        // TODO: Convert string to more appropriate typing
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const taskActions: Record<string, (workflow: IWorkflow) => void> = {
            LOGGING_OUT_HOST: handleHostLogout,
            LOGOUT_FAILED: handleLogoutFailed,
            FAILED: handleFailed,
        }

        const stateValue: string = Object.keys(taskActions).find(
            (stateValue: string) => workflow.state.matches(stateValue)
        ) ?? ""

        return taskActions[stateValue]?.(workflow)
    }

    const handleHostLogout = (workflow: IWorkflow) => {
        const { component, event: { expertUser, admin } } = TRACK.LOGOUT
        const loginClickTime: Date = new Date(loginClick)
        const currentTime = new Date()
        const sessionTime = getDurationInFormat(currentTime, loginClickTime)

        if (getCurrentUserData().clinicalRole === EClinicalRole.EXPERTUSER) {
            trackEvent(component, expertUser, { entireSessionDuration: sessionTime })
        } else {
            trackEvent(component, admin, { entireSessionDuration: sessionTime })
        }
        const { postLogoutRoute } = workflow.state.context as LogoutContext
        dispatch(logout(() => dispatch(sendWorkflowEvent(workflow.id, HOST_LOGGED_OUT)), postLogoutRoute))

    }

    const handleLogoutFailed = (workflow: IWorkflow) => {
        dispatch(sendWorkflowEvent(workflow.id, FINISHED))
    }

    const handleFailed = (workflow: IWorkflow) => {
        dispatch(sendWorkflowEvent(workflow.id, FINISHED))
    }
}
