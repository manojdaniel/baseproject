/*
 * Created on Tue Oct 26 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { mount } from "enzyme"
import { PrototypeBanner } from "./PrototypeBanner"

describe("Prototype Banner test", () => {
    it("It should render prototype warning text", () => {
        const wrapper = mount(<PrototypeBanner warningText="test" />)
        expect(wrapper).toBeDefined()
        expect(wrapper.text().includes("test")).toBeTruthy()
    })
})
