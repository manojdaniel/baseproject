/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import consoleReducer, { initialStatesForConsole } from "./consoleReducer"
import externalReducer, { initialStateForExternalReducer } from "./externalReducer"
import protocolTransferReducer, { initialStatesForProtocolTransfer } from "./protocolTransferReducer"
import { combineReducers } from "redux"

const rootReducer = (state: any, action: any) => combineReducers({
    consoleReducer,
    externalReducer,
    protocolTransferReducer
})(state, action)

export const initialStateForAllReducers = {
    consoleReducer: initialStatesForConsole,
    externalReducer: initialStateForExternalReducer,
    protocolTransferReducer: initialStatesForProtocolTransfer
}

export default rootReducer
