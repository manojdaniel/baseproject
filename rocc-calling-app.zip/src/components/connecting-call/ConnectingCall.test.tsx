/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ConnectingCall from "./ConnectingCall"
import { shallow } from "enzyme"
import { DEFAULT_CONTACT_INFO } from "@rocc/rocc-client-services"

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            customerReducer : {
                locations: [{
                    id: 1,
                    name: "location1",
                    shortName: "location1",
                    address: "",
                    modalityList: [],
                    locationContacts: [],
                    totalRooms: 1,
                    roomsFetched: true,
                }]
            }
        }
    }),
    CreateStore: jest.fn(),
}))

jest.mock("@rocc/rocc-global-components")

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
}))

describe("ConnectingCall component", () => {
    let wrapper: any
    const props = {
        callMessage: "Connecting ...",
        participant: DEFAULT_CONTACT_INFO,
        callWindowFullscreen: false,
    }
    beforeEach(() => {
        wrapper = shallow(<ConnectingCall {...props} />)
    })
    it("should render IntermediateCallWindow component", () => {
        expect(wrapper.find("IntermediateCallWindow")).toHaveLength(1)
    })
})
