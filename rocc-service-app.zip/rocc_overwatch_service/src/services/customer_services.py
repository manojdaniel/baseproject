"""
 Created on Thu Apr 18 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
from cloudfoundry_client.client import CloudFoundryClient
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_HSDP_IDM_URL, VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_ROCC_GLOBAL_PATH
from src.constants.constants import CF_TARGET_ENDPOINT, DATA, ROCC_PROXY_URL, ROCC_SUFFIX, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, TWILIO_APP_NAME
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.wrappers.cf.cf_utility import fetch_data_from_vcap_app
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.cf.cloudfoundry_services import delete_route, delete_service_and_bindings
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_org_services import delete_org_service, get_org_details_from_org_id_service
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data, update_customer_map_in_vault_global_path
from src.wrappers.graphql.mutations.mutations import upsert_customers
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.communication_services.communication_profile_services import delete_org_comm_profile_service, fetch_org_comm_profile_service, validate_twilio_sub_account_integrity
from src.wrappers.platform_services.management_service.manage_redis_services import delete_org_related_redis_values

LOG = create_logger("CustomerServices")


class CustomerService():
    def __init__(self, service_user_uuid, customer_identifer, customer_org_infra_uuid, token, force_clean):
        self._customer_name = customer_identifer
        self._service_user_uuid = service_user_uuid
        self._org_infra_uuid = customer_org_infra_uuid
        self._service_user_token = token
        self._force_clean = force_clean
        self._parent_service_token = None
        self._profile_configs = get_profile_data()
        self.populate_service_tokens()
        self._parent_org_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
        self._client = get_client_connection(access_token=self._parent_service_token, org_infra_uuid=self._parent_org_uuid)
        self._target_endpoint = fetch_data_from_vcap_app(key=CF_TARGET_ENDPOINT, default_value="https://api.cloud.pcftest.com")
        proxy = dict(http=os.environ.get("HTTP_PROXY", ""), https=os.environ.get("HTTPS_PROXY", ""))
        self._cf_client = CloudFoundryClient(self._target_endpoint, proxy=proxy, verify=False)
        self._cf_client.init_with_user_credentials(self._profile_configs["CF_USERNAME"], self._profile_configs["CF_PASSWORD"])
        self._twilio_app_name = os.environ[TWILIO_APP_NAME]

    def populate_service_tokens(self):
        try:
            self._parent_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                         issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                         private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!") from ex

    def fetch_customer_service_token(self):
        try:
            customer_vault_values = get_path_specific_vault_values(path_name=self._customer_name)
            return create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                   issuer=customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                   private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
        except Exception as ex:
            LOG.error(f"Customer service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!") from ex

    def offboard_customer(self, hard_delete=False):
        """
        - Fetch HSDP customer name from customer_org_id using HSDP API
        - Validate if customer_org_id is valid
        - Offboard tasks
            - Remove twilio service bindings
            - Delete customer org from HSDP
            - Update Vault's AuthCredentials > customerMap to remove customer_identifer
            - Remove Redis values for customer and customer_org_id
            - Delete Org communication profile
            - In schema: rocc_overwatch > table: customers - update status: deleted
            - AllowedOrg mapping cleanup - (TODO: Need to create an API in IAM service if it is not present)
            - Remove customer route
            - if hard_delete is True:
                TODO: Write a mutation query to delete all the records matching customer_identifier
        """
        try:
            org_uuid_matched = self.task_validate_customer_org_id_with_name()
            self.task_offboard_customer(hard_delete, org_uuid_matched)
            self.safe_audit(event_subtype="Offboard Customer", action="D",
                            outcome=0, code="Offboard Customer", value="Success")
        except RoccException as ex:
            raise ex
        except Exception as ex:
            LOG.exception(f"Offboarding customer with error: {ex}")
            self.safe_audit(event_subtype="Offboard Customer", action="D",
                            outcome=0, code="Offboard Customer", value="Error")
            raise RoccException(status_code=500, title="Customer cleanup failed", payload="Customer data deletion failed during cleanup") from ex

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Command Center", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_infra_uuid, token=self._service_user_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def task_validate_customer_org_id_with_name(self):
        try:
            org_details = get_org_details_from_org_id_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                              org_id=self._org_infra_uuid,
                                                              token=self._parent_service_token)
            if org_details["name"].lower() == self._customer_name:
                return True
        except Exception as ex:
            LOG.exception(f"Validation of customer org id and customer's name failed with error: {ex}")
            if self._force_clean:
                return False
            raise RoccException(status_code=500, title="Customer data validation failed", payload="Customer data validation failed during cleanup") from ex
        raise RoccException(status_code=400, title="Customer data validation failed", payload="Provided customer org id and customer identifier did not match")

    def task_offboard_customer(self, hard_delete, org_uuid_matched):
        """
        - Delete customer org from HSDP
        - Update Vault's AuthCredentials > customerMap to remove customer_identifer
        - In schema: rocc_overwatch > table: customers - update status: deleted
        - if hard_delete is True:
            TODO: Write a mutation query to delete all the records matching customer_identifier
        """
        try:
            if org_uuid_matched:
                self.task_delete_twilio_service_bindings()
                self.task_delete_org_from_hsdp()
            self.task_delete_org_communication_profile()
            self.task_update_customer_map_in_vault()
            self.task_delete_redis_values_for_customer()
            self.task_update_customer_status_in_db()
            self.task_delete_routes()
            if hard_delete:
                """ TODO: Need to clean up DB data, if it is ok """
        except RoccException as ex:
            raise ex
        except Exception as ex:
            LOG.exception(f"Offboarding customer with error: {ex}")
            raise RoccException(status_code=500, title="Customer cleanup failed", payload="Customer data deletion failed during cleanup") from ex

    def task_delete_org_from_hsdp(self):
        try:
            status = delete_org_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                        org_id=self._org_infra_uuid,
                                        token=self._parent_service_token)
            if not status:
                raise RoccException(status_code=500, title="Customer org deletion failed", payload="Customer org deletion failed during cleanup")
        except Exception as ex:
            LOG.exception(f"Customer org deletion failed during cleanup with error: {ex}")
            raise RoccException(status_code=500, title="Customer org deletion failed", payload="Customer org deletion failed during cleanup") from ex

    def task_update_customer_map_in_vault(self):
        try:
            global_vault_values = get_path_specific_vault_values(path_name=self._profile_configs[VAULT_ROCC_GLOBAL_PATH])[DATA]
            customer_map = global_vault_values["customerMap"]
            if customer_map[self._customer_name]:
                LOG.info(f"Deleting Customer: {self._customer_name} from vault - customerMap")
                del customer_map[self._customer_name]
                update_customer_map_in_vault_global_path(customer_name=self._customer_name,
                                                         org_id=self._org_infra_uuid,
                                                         updated_customer_map=customer_map)
            else:
                LOG.info(f"Customer: {self._customer_name} was not present in vault - customerMap")
        except KeyError as ex:
            LOG.exception(f"Customer map in vault does not have customer name: {self._customer_name}, error: {ex}")
            """ Not raising an exception, since customer data is not present in customerMap """
        except Exception as ex:
            LOG.exception(f"Customer map updation in vault failed during cleanup with error: {ex}")
            raise RoccException(status_code=500, title="Vault update failed", payload="Customer map updation in vault failed during cleanup") from ex

    def task_delete_redis_values_for_customer(self):
        try:
            delete_org_related_redis_values(url=os.environ[ROCC_PROXY_URL],
                                            token=self._parent_service_token,
                                            customer_name=self._customer_name,
                                            org_id=self._org_infra_uuid)
        except Exception as ex:
            LOG.exception(f"Deletion of customer values in REDIS failed during cleanup with error: {ex}")
            raise RoccException(status_code=500, title="Redis cleanup failed", payload="Deletion of customer values in REDIS failed") from ex

    def task_update_customer_status_in_db(self):
        try:
            self._client.execute(upsert_customers, variable_values={"name": self._customer_name, "status": "Deleted"})
        except Exception as ex:
            LOG.exception(f"Customer status updation in DB failed during cleanup with error: {ex}")
            raise RoccException(status_code=500, title="Customer status update failed", payload="Customer status updation in DB failed during cleanup") from ex

    def task_delete_org_communication_profile(self):
        LOG.info("Starting task Delete org communication profile")
        response = delete_org_comm_profile_service(url=os.environ[ROCC_PROXY_URL],
                                                   token=self._parent_service_token,
                                                   org_id=self._org_infra_uuid)
        if response:
            LOG.info("Task Delete org communication profile was successfull")
        else:
            LOG.error("Task Failed: Delete org communication profile")

    def task_delete_routes(self):
        LOG.info("Starting task Delete Routes.")
        route_name = f"{self._customer_name}{ROCC_SUFFIX}"
        delete_route(route_name,
                     target_endpoint=self._target_endpoint,
                     client=self._cf_client)

    def task_delete_twilio_service_bindings(self):
        LOG.info("Starting task Delete service bindings.")
        service_instance_name = f"{self._twilio_app_name}-{self._customer_name}"
        response = fetch_org_comm_profile_service(url=os.environ[ROCC_PROXY_URL],
                                                  token=self._parent_service_token,
                                                  org_id=self._org_infra_uuid)
        customer_service_token = self.fetch_customer_service_token()
        is_valid = validate_twilio_sub_account_integrity(url=os.environ[ROCC_PROXY_URL],
                                                         token=customer_service_token,
                                                         sub_acc_name=service_instance_name,
                                                         twilio_sid=response.get("twilioSid"),
                                                         org_id=self._org_infra_uuid)
        if is_valid:
            delete_service_and_bindings(service_instance_name=service_instance_name,
                                        target_endpoint=self._target_endpoint,
                                        client=self._cf_client,
                                        delete_instance=True)
        else:
            LOG.error(f"Customer: {self._customer_name}'s twilio pool binding is not consistent with cf service name. Please manually delete the service with twilio_sid: {response.get('twilioSid')}")
