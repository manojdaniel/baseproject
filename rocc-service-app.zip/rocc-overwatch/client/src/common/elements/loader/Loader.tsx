/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { Component } from "react"
import { Dimmer, Loader } from "semantic-ui-react"

interface ICustomLoader {
    content: string
    inverted: boolean
    customStyle: any
}

class CustomLoader extends Component<ICustomLoader> {
    public render() {
        const {
            content,
            inverted,
            customStyle,
        } = this.props
        return (
            <Dimmer active={true} inverted={inverted} id={"customLoader"}>
                <Loader
                    content={content}
                    inverted={inverted}
                    style={customStyle}
                />
            </Dimmer>)
    }
}

export default CustomLoader
