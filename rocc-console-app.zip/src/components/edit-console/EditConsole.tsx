/*
 * Created on Thu Nov 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType, EOperationStatus, EPosition, ETransactionStatus, getRoomDetailFromUuid } from "@rocc/rocc-client-services"
import { ConsoleOperations, EIconType } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { connectionUtility, getConnectionAdapter } from "../../common/helpers/connection"
import { ccEditConnectionHandler, checkForActiveEditWorkflow, onReceiverUseConfirmation } from "../../common/helpers/consoleUtility"
import { checkIfEditConsoleEnabled, checkIfEmeraldEditEnabled, displayEditToViewSwitchMessage, fetchActiveTransactionIndex, fetchConsoleSessionByRoomUuid, hasActiveVidoCallWithRoom, hasActivTransactionForRoom, isRoomMonitoringEnabled } from "../../common/helpers/helpers"
import { setConsoleOperations } from "../../redux/actions/consoleActions"
import { GLOBAL_LEFTSIDE_PANEL } from "../../redux/actions/types"
import { IReceiverSelectionModal, IStore } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchRooms } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"

interface IEditConsole {
    roomUuid: string
    showTitle?: boolean
    iconPosition?: EPosition
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    component?: string
    callPanelEvent?: boolean
    secondary?: boolean
}

const componentName = "Edit Console"

const EditConsole = ({ roomUuid, showTitle, iconPosition, setReceiverSelectionModal, secondary }: IEditConsole) => {
    const {
        featureFlags,
        permissions,
        consoleSessions,
        commandCenterSeat,
        consoleOperation,
        receivers,
        currentUser,
        protocolTransferStatus,
        connectedCallDetails,
        onHoldCallDetails,
        initialized,
        workflows,
    } = useSelector((state: IStore) => ({
        featureFlags: state.externalReducer.featureFlags,
        permissions: state.externalReducer.permissions,
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        commandCenterSeat: state.consoleReducer.commandCenterDetails.commandCenterSeat,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        currentUser: state.externalReducer.currentUser,
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        connectedCallDetails: state.externalReducer.callDetails.connectedCallDetails,
        onHoldCallDetails: state.externalReducer.callDetails.onHoldCallDetails,
        initialized: state.consoleReducer.commandCenterDetails.initialised,
        workflows: state.externalReducer.workflows,
    }))


    const { intl } = getIntlProvider()
    const dispatch = useDispatch()

    const [dropdownOptions, setDropdownOptions] = useState([] as any)
    const [loading, setLoading] = useState(false)
    const [disabled, setDisabled] = useState(false)
    const [connectionState, setConnectionState] = useState(false)
    const [requestCancelState, setRequestCancelState] = useState(false)
    const consoleOperationRef = useRef(consoleOperation)
    const consoleSessionsRef = useRef(consoleSessions)
    const roomDetailsRef = useRef(getRoomDetailFromUuid(fetchRooms(), roomUuid))
    const { FULL_CONTROL } = EConnectionType
    const { CC } = EConnectionMode
    useEffect(() => {
        if (connectionState && !hasActiveVidoCallWithRoom(roomUuid) && !hasActivTransactionForRoom(roomUuid) && consoleOperationRef.current.operationStatus === EOperationStatus.IDLE) {
            performConsoleDisconnectionOps()
        }
        /* TODO: Create CONOSLE_CLEANUP workflow, trigger on calling app on any call detail change, handler check on console app for transaction and operation idle */
    }, [connectedCallDetails, onHoldCallDetails])

    useEffect(() => {
        consoleOperationRef.current = consoleOperation
        consoleSessionsRef.current = consoleSessions
        const { connectionState, loading, disabled, requestCancelState } = getConnectionAdapter().getEditConsoleStatus({
            consoleOperation, consoleSessions, roomDetails: roomDetailsRef.current,
            connectionType: FULL_CONTROL, protocolTransferStatus
        })
        setLoading(checkForActiveEditWorkflow(workflows, roomDetailsRef.current.uuid) || loading)
        setDisabled(disabled)
        setConnectionState(connectionState)
        setRequestCancelState(requestCancelState)
    }, [consoleOperation, consoleSessions, protocolTransferStatus, initialized, workflows])

    const performConsoleDisconnectionOps = () => {
        if (requestCancelState) {
            handleRequestCancelling()
        } else {
            const { status, isConsoleSwitching } = getConnectionAdapter().disconnect({ roomUuid, connectionType: FULL_CONTROL })
            if (status) {
                if (isConsoleSwitching) {
                    displayEditToViewSwitchMessage()
                }
                dispatchToParentStore({
                    type: GLOBAL_LEFTSIDE_PANEL,
                    payload: {
                        displayLeftSidePanel: false,
                        activeLeftPanel: "",
                        desktopFullScreen: false,
                    }
                })
            }
        }
    }

    useEffect(() => {
        const getEditingOptions = []
        const props = {
            roomUuid,
            connectionType: FULL_CONTROL,
            receivers,
            consoleSessions: consoleSessionsRef.current,
            dispatch,
            setReceiverSelectionModal,
            featureFlags,
            componentName,
            onReceiverSelectionRequired: ()=> setReceiverSelectionModal({ showReceiverModal: true, connectionType: FULL_CONTROL }),
            onReceiverUseConfirmation : (props: any)=> onReceiverUseConfirmation({...props, setReceiverSelectionModal}),
        }
        const availableConnections = connectionUtility.createConnectionList(getRoomDetailFromUuid(fetchRooms(), roomUuid),{
            username : currentUser.kvmUsername,
            seatname: commandCenterSeat.seatName
        })
        if (availableConnections.length == 0){
            return
        }
        const preferredConnectionSource = getConnectionAdapter().getPreferredConnection(availableConnections, EConnectionType.INCOGNITO_VIEW)
        if (!preferredConnectionSource){
            return
        }
        const activeConsoleConnectionMode = fetchConsoleSessionByRoomUuid(consoleSessions, roomUuid)?.connectionMode
        if(preferredConnectionSource.connectionMode == EModalityConnectionMode.KVM){
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.EMERALD)){
                const emeraldEditEnabled = checkIfEmeraldEditEnabled(permissions, currentUser.kvmUsername, activeConsoleConnectionMode)
                const isEmeraldEnabled = isRoomMonitoringEnabled(featureFlags) ?
                    emeraldEditEnabled && receivers.length === 0 :
                    emeraldEditEnabled
                if (isEmeraldEnabled) {
                    getEditingOptions.push({
                        key: getEditingOptions.length,
                        value: intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] }),
                        className: "LinkExternal",
                        handlerFunction: () => {
                            getConnectionAdapter().connect({
                                ...props,
                                connectionMode : preferredConnectionSource.connectionMode,
                                subConnectionMode : EModalitySubConnectionMode.EMERALD,
                            })
                        }
                    })
                }
            }
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.CC)){
                if (checkIfEditConsoleEnabled(permissions, receivers, activeConsoleConnectionMode)) {
                    getEditingOptions.push({
                        key: getEditingOptions.length,
                        value: intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] }),
                        className: "About",
                        handlerFunction: () => {
                            ccEditConnectionHandler({ ...props, connectionMode: CC })    ///// Look here
                        }
                    })
                }

            }
        }else{
            getEditingOptions.push({
                key: getEditingOptions.length,
                value: intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] }),
                className: "LinkExternal",
                handlerFunction: () => {
                    getConnectionAdapter().connect({
                        ...props,
                        connectionMode : preferredConnectionSource.connectionMode,
                        subConnectionMode : null,
                    })
                }
            })
        }
        setDropdownOptions(getEditingOptions)
    }, [featureFlags, commandCenterSeat, consoleSessions])

    const handleRequestCancelling = () => {
        /**
         * Update the Active transaction state to Cancelled
         * Check if contextId exists, If yes then initiate cancel request 
         * if no, then wait for Authorization request call to finish and update the context Id
         */
        const activeTransactionIndex = fetchActiveTransactionIndex(consoleOperation.transactions)
        if (activeTransactionIndex > -1) {
            consoleOperation.operationStatus = EOperationStatus.CANCELLED
            consoleOperation.transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.CANCELLED
            dispatch(setConsoleOperations({ ...consoleOperation }))
        }
    }

    const getTooltipMessage = () => {
        if (requestCancelState) {
            return intl.formatMessage({ id: "content.consoleMessages.cancelConsoleRequest", defaultMessage: en["content.consoleMessages.cancelConsoleRequest"] })
        }
        return ""
    }
    const startEditing = intl.formatMessage({ id: "content.startEditing.btn", defaultMessage: en["content.startEditing.btn"] })
    const stopEditing = intl.formatMessage({ id: "content.stopEditing.btn", defaultMessage: en["content.stopEditing.btn"] })

    return (
        permissions?.CONSOLE_EDIT ? <ConsoleOperations
            consoleOperationProps={{
                "start": {
                    "title": startEditing,
                    "type": FULL_CONTROL,
                    "icon": EIconType.EDIT_START_ICON,
                },
                "stop": {
                    "title": stopEditing,
                    "type": FULL_CONTROL,
                    "icon": EIconType.EDIT_STOP_ICON,
                }
            }}
            loading={loading}
            disabled={disabled}
            connectionState={connectionState}
            dropdownOptions={dropdownOptions}
            iconPosition={iconPosition ? iconPosition : EPosition.HORIZONTAL}
            showTitle={showTitle ?? false}
            stopConsoleOperationHandler={performConsoleDisconnectionOps}
            showToolTip={false}
            requestCancelState={requestCancelState}
            tooltipMessage={getTooltipMessage()}
            secondary={secondary} /> : <></>

    )
}

export default EditConsole
