"""
 Created on Thu Sep 17 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
import xmlrunner


def runner(output="python_tests_xml"):
    return xmlrunner.XMLTestRunner(
        output=output
    )


def find_tests():
    return unittest.TestLoader().discover("tests")


if __name__ == "__main__":
    runner().run(find_tests())
