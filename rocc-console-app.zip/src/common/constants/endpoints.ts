/*
 * Created on Thu Oct 22 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const PHILIPS_API_URI = "/philips/rocc"
export const LOGGER_END_POINT = "/roccWebAppLogger"
export const UI_SERVICE_API_URI = "/ui/service"
export const SERVER_LOGGER = `${UI_SERVICE_API_URI}/${LOGGER_END_POINT}`
export const COMMUNICATION_TOKEN_EP = "/Token"
export const COMMUNICATION_SERVICE_MESSAGE_URI = "/Message/"
export const COMMUNICATION_SERVICE_MEDIA_ROOM_URI = "/MediaRoom"

export const CONSOLE_SESSION_EP = "/console/ConsoleSession"
export const CONSOLE_SESSION_EDIT = "/$edit"
export const CONSOLE_SESSION_AUTHORIZATION_EP = "/console/ConsoleSessionAuthorization"
export const CONSOLE_CONNECTION = "/console/Connection"
export const CONSOLE_CONTROL_CONNECTION = "/console/authorize/Connection"
export const CONSOLE_AUTHORIZATION = "/console/Authorize"

export const EMERALD_CONNECTION = "/console/AssociateConnection"
export const EMERALD_DISCONNECTION = "/console/DisassociateConnection"
export const KVM_CONNECTION_MAPPING = "/console/UserConnectionMapping"

export const CONSOLE_ACTIVE_SESSIONS = "/console/ActiveConsoleSession"

export const MANAGE_GRAPHQL_CONSOLE_MUTATIONS_EP = "/data/Graphql/Console"
export const MANAGE_GRAPHQL_MUTATION_EP = "/data/Graphql"
export const MANAGE_GRAPHQL_IN_APP_MUTATIONS_EP = `${MANAGE_GRAPHQL_MUTATION_EP}/inAppMutations`
export const RESOURCE_ADDITIOINAL_ATTRIBUTE = `${MANAGE_GRAPHQL_MUTATION_EP}/Scanner/`

export const CONSOLE_TRANSACTION = "/console/transaction/"
