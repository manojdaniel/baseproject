export const affiliateRolloutData = [
  {
    "affiliate": 3,
    "affiliateName": "MTVERNON",
    "country": 2,
    "countryName": "United States of America",
    "abbreviation": "MTV",
    "lattitude": 37.9044779361799,
    "longitude": -87.9295981286949,
    "rollout": false
  },
  {
    "affiliate": 2,
    "affiliateName": "SAFCO",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "SF",
    "lattitude": 27.07291,
    "longitude": 49.5764,
    "rollout": true
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "YA",
    "lattitude": 23.9881926855686,
    "longitude": 38.2225902968736,
    "rollout": true
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PK",
    "lattitude": 49.605039,
    "longitude": 27.032672,
    "rollout": false
  },
  {
    "affiliate": 7,
    "affiliateName": "KEMYA",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "KY",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "SQ",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "YS",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UN",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 15,
    "affiliateName": "petrokemya_test",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PK",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "SK",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 20,
    "affiliateName": "ARRAZI",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "AR",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 21,
    "affiliateName": "IBN ZAHR",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "IZ",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 22,
    "affiliateName": "IBNSINA",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "IS",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 29,
    "affiliateName": "SABIC Agri-Nutrients",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "SAN",
    "lattitude": 27.0723958379614,
    "longitude": 49.5772227637431,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "YS_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UN_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 48,
    "affiliateName": "ARRAZI_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "AR_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 11,
    "affiliateName": "GELEEN",
    "country": 6,
    "countryName": "Netherland",
    "abbreviation": "GL",
    "lattitude": 50.9679425,
    "longitude": 5.7992227,
    "rollout": false
  },
  {
    "affiliate": 14,
    "affiliateName": "affiliate test",
    "country": 7,
    "countryName": "test country",
    "abbreviation": "afft_test",
    "lattitude": 27.5443838,
    "longitude": -32.967433,
    "rollout": false
  },
  {
    "affiliate": 17,
    "affiliateName": "aff test",
    "country": 7,
    "countryName": "test country",
    "abbreviation": "a_test",
    "lattitude": 27.06888,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 16,
    "affiliateName": "ibn zahr",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "iz",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 18,
    "affiliateName": "yansab",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "ys",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 27,
    "affiliateName": "sharq",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "sq",
    "lattitude": 27.053402,
    "longitude": 49.585833,
    "rollout": false
  },
  {
    "affiliate": 28,
    "affiliateName": "sharqtemp",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "sqtemp",
    "lattitude": 27.062036,
    "longitude": 49.579442,
    "rollout": false
  },
  {
    "affiliate": 42,
    "affiliateName": "yansab_Copy",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "ys_Copy",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 50,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 51,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 52,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 53,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 54,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 55,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 56,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 58,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 65,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 70,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 72,
    "affiliateName": null,
    "country": null,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 23,
    "affiliateName": "petrokemya_test",
    "country": 10,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PK",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 25,
    "affiliateName": "Petrohow",
    "country": 10,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PH",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 30,
    "affiliateName": "Petrokemya",
    "country": 10,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PK",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 60,
    "affiliateName": null,
    "country": null,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 63,
    "affiliateName": null,
    "country": null,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 64,
    "affiliateName": null,
    "country": null,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 71,
    "affiliateName": null,
    "country": null,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 24,
    "affiliateName": "test_affiliate",
    "country": 11,
    "countryName": "test country 1234",
    "abbreviation": "ts",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 57,
    "affiliateName": null,
    "country": null,
    "countryName": "saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 59,
    "affiliateName": null,
    "country": null,
    "countryName": "netherlands",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 61,
    "affiliateName": null,
    "country": null,
    "countryName": "united state of america",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 62,
    "affiliateName": null,
    "country": null,
    "countryName": "spain",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 66,
    "affiliateName": null,
    "country": null,
    "countryName": "saudi arabia",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 67,
    "affiliateName": null,
    "country": null,
    "countryName": "germany",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 68,
    "affiliateName": null,
    "country": null,
    "countryName": "belgium",
    "abbreviation": null,
    "lattitude": null,
    "longitude": null,
    "rollout": false
  }
];

export const plantRolloutData = [
  {
    "affiliate": 29,
    "affiliateName": "SABIC Agri-Nutrients",
    "plant": 1,
    "plantName": "AN4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "AN4",
    "lattitude": 27.07291,
    "longitude": 49.5764,
    "rollout": true
  },
  {
    "affiliate": 3,
    "affiliateName": "MTVERNON",
    "plant": 2,
    "plantName": "BRN",
    "country": 2,
    "countryName": "United States of America",
    "abbreviation": "Brine",
    "lattitude": 37.906364,
    "longitude": -87.925853,
    "rollout": false
  },
  {
    "affiliate": 3,
    "affiliateName": "MTVERNON",
    "plant": 3,
    "plantName": "COG",
    "country": 2,
    "countryName": "United States of America",
    "abbreviation": "Cogeneration",
    "lattitude": 37.91053,
    "longitude": -87.930442,
    "rollout": false
  },
  {
    "affiliate": 3,
    "affiliateName": "MTVERNON",
    "plant": 4,
    "plantName": "LEXR",
    "country": 2,
    "countryName": "United States of America",
    "abbreviation": "LexanResin",
    "lattitude": 37.907777,
    "longitude": -87.927992,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 5,
    "plantName": "OLF1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF1",
    "lattitude": 23.9881926855686,
    "longitude": 38.2225902968736,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 6,
    "plantName": "OLF2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF2",
    "lattitude": 23.988359,
    "longitude": 38.222344,
    "rollout": false
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "plant": 7,
    "plantName": "Polyethylene",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE",
    "lattitude": 49.605039,
    "longitude": 27.032672,
    "rollout": false
  },
  {
    "affiliate": 7,
    "affiliateName": "KEMYA",
    "plant": 9,
    "plantName": "LOW LINEAR DENSITY POLYETHYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LLDPE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 10,
    "plantName": "POLYETHYLENE_1_2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE_1_2",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 11,
    "plantName": "POLYETHYLENE_3_4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE_3_4",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 12,
    "plantName": "ETHYLENE GLYCOL",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 13,
    "plantName": "LOW LINEAR DENSITY POLYETHYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LLDPE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 14,
    "plantName": "POLYPROPYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 15,
    "plantName": "ETHYLENE GLYCOL 2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 16,
    "plantName": "LINEAR ALPHA OLEFINS",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LAO",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 11,
    "affiliateName": "GELEEN",
    "plant": 17,
    "plantName": "OLF4",
    "country": 6,
    "countryName": "Netherland",
    "abbreviation": "Olefins 4",
    "lattitude": 50.9679425,
    "longitude": 5.7992227,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 18,
    "plantName": "POLY2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "POLY2",
    "lattitude": 23.988359,
    "longitude": 38.222344,
    "rollout": true
  },
  {
    "affiliate": 29,
    "affiliateName": "SABIC Agri-Nutrients",
    "plant": 19,
    "plantName": "AN5",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "AN5",
    "lattitude": 27.0723866363653,
    "longitude": 49.5773349157097,
    "rollout": false
  },
  {
    "affiliate": 14,
    "affiliateName": "affiliate test",
    "plant": 22,
    "plantName": "quas-1 plant test",
    "country": 7,
    "countryName": "test country",
    "abbreviation": "Q-1_TEST",
    "lattitude": 27.5443838,
    "longitude": -32.967433,
    "rollout": false
  },
  {
    "affiliate": 21,
    "affiliateName": "IBN ZAHR",
    "plant": 24,
    "plantName": "poly propylene 3",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP-3",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 17,
    "affiliateName": "aff test",
    "plant": 25,
    "plantName": "quas-222 plant test",
    "country": 7,
    "countryName": "test country",
    "abbreviation": "Q-2_TEST",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 26,
    "plantName": "POLY1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "Polymer1",
    "lattitude": 23.9881926855686,
    "longitude": 38.2225902968736,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 27,
    "plantName": "high-density polyethylene",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "HDPE",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 28,
    "plantName": "HIGH DENSITY POLYETHYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "HDPE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 29,
    "plantName": "POLYPROPYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 31,
    "plantName": "ETHYLENE GLYCOL 2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 32,
    "plantName": "LINEAR ALPHA OLEFINS",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LAO",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 7,
    "affiliateName": "KEMYA",
    "plant": 33,
    "plantName": "LOW LINEAR DENSITY POLYETHYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LLDPE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 20,
    "affiliateName": "ARRAZI",
    "plant": 34,
    "plantName": "METHANOL",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "MEOH",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 21,
    "affiliateName": "IBN ZAHR",
    "plant": 35,
    "plantName": "POLYPROPYLENE 2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP2",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 22,
    "affiliateName": "IBNSINA",
    "plant": 36,
    "plantName": "METHYL TERTIARY-BUTYL ETHER",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "MTBE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 37,
    "plantName": "POLYETHYLENE_1_2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE_1_2",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 38,
    "plantName": "POLYETHYLENE_3_4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE_3_4",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 24,
    "affiliateName": "test_affiliate",
    "plant": 39,
    "plantName": "plant test 1234",
    "country": 11,
    "countryName": "test country 1234",
    "abbreviation": "P-TEST-12",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 25,
    "affiliateName": "Petrohow",
    "plant": 40,
    "plantName": "olefin1",
    "country": 10,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLEF1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 41,
    "plantName": "EG2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2",
    "lattitude": 23.98558,
    "longitude": 38.22675,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 42,
    "plantName": "EG1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG1",
    "lattitude": 23.982282,
    "longitude": 38.221644,
    "rollout": false
  },
  {
    "affiliate": 27,
    "affiliateName": "sharq",
    "plant": 43,
    "plantName": "ethylene gluycol 4",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "EG-4",
    "lattitude": 27.058037,
    "longitude": 49.576501,
    "rollout": false
  },
  {
    "affiliate": 27,
    "affiliateName": "sharq",
    "plant": 44,
    "plantName": "ethylene glycol 1",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "EG1",
    "lattitude": 27.053402,
    "longitude": 49.585833,
    "rollout": false
  },
  {
    "affiliate": 27,
    "affiliateName": "sharq",
    "plant": 45,
    "plantName": "ethylene glycol 2",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "EG2",
    "lattitude": 27.05551,
    "longitude": 49.583643,
    "rollout": false
  },
  {
    "affiliate": 28,
    "affiliateName": "sharqtemp",
    "plant": 46,
    "plantName": "ethylene glycol 4temp",
    "country": 9,
    "countryName": "kingdom of saudi arabia",
    "abbreviation": "EG-4TEMP",
    "lattitude": 27.058037,
    "longitude": 49.576501,
    "rollout": false
  },
  {
    "affiliate": 21,
    "affiliateName": "IBN ZAHR",
    "plant": 47,
    "plantName": "poly propylene 3_test0",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP-3_test0",
    "lattitude": 27.06888,
    "longitude": 49.58072,
    "rollout": false
  },
  {
    "affiliate": 29,
    "affiliateName": "SABIC Agri-Nutrients",
    "plant": 48,
    "plantName": "AN3-AMMONIA",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "AN3",
    "lattitude": 27.0723958379614,
    "longitude": 49.5772227637431,
    "rollout": false
  },
  {
    "affiliate": 29,
    "affiliateName": "SABIC Agri-Nutrients",
    "plant": 49,
    "plantName": "SAN-IBB",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "IBB",
    "lattitude": 27.0744208394282,
    "longitude": 49.5619837767159,
    "rollout": false
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "plant": 50,
    "plantName": "PK-OLE-1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF-1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 30,
    "affiliateName": "Petrokemya",
    "plant": 51,
    "plantName": "PK-OLE-1",
    "country": 10,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF-1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 52,
    "plantName": "ETHYLENE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "ETHYLENE",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 53,
    "plantName": "OLEFINS",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 10,
    "affiliateName": "UNITED",
    "plant": 54,
    "plantName": "EG1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "plant": 69,
    "plantName": "ETHYLENE GLYCOL_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "plant": 70,
    "plantName": "LOW LINEAR DENSITY POLYETHYLENE_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LLDPE_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "plant": 71,
    "plantName": "POLYPROPYLENE_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PP_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "plant": 72,
    "plantName": "high-density polyethylene_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "HDPE_Copy",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 41,
    "affiliateName": "YANSAB_Copy",
    "plant": 73,
    "plantName": "OLEFINS_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF_Copy",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 74,
    "plantName": "ETHYLENE GLYCOL 2_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 75,
    "plantName": "LINEAR ALPHA OLEFINS_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LAO_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 76,
    "plantName": "ETHYLENE GLYCOL 2_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 77,
    "plantName": "LINEAR ALPHA OLEFINS_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LAO_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 78,
    "plantName": "ETHYLENE_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EY_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 47,
    "affiliateName": "UNITED_Copy",
    "plant": 79,
    "plantName": "EG1_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG1_Copy",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 48,
    "affiliateName": "ARRAZI_Copy",
    "plant": 80,
    "plantName": "METHANOL_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "MEOH_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 48,
    "affiliateName": "ARRAZI_Copy",
    "plant": 81,
    "plantName": "METHANOL_Copy",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "MEOH_Copy",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 82,
    "plantName": "UTILITY AND OFFSITE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "U&O",
    "lattitude": 27.04608942,
    "longitude": 49.55082767,
    "rollout": false
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "plant": 83,
    "plantName": "UTILITY",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UTILITY",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "plant": 84,
    "plantName": "Methyl Tert-butyl Ether",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "MTBE",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 5,
    "affiliateName": "PETROKEMYA",
    "plant": 85,
    "plantName": "Utilities Distribution Department",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UDD",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 86,
    "plantName": "EGDMC",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EGDMC",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 87,
    "plantName": "LDPE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "LDPE",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 88,
    "plantName": "PC",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PC",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 9,
    "affiliateName": "YANSAB",
    "plant": 89,
    "plantName": "PET",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PET",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 4,
    "affiliateName": "YANPET",
    "plant": 90,
    "plantName": "UTILITY AND OFFSITE",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "U&O",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 91,
    "plantName": "Ethylene Glycol - 1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 92,
    "plantName": "Ethylene Glycol - 2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG2",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 93,
    "plantName": "Ethylene Glycol - 3",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG3",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 94,
    "plantName": "Ethylene Glycol - 4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG4",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 95,
    "plantName": "Ethylene Glycol - Common",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "EG COMMON",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 96,
    "plantName": "Polyethylene - 1",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE1",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 97,
    "plantName": "Polyethylene - 2",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE2",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 98,
    "plantName": "Polyethylene - 3",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE3",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 99,
    "plantName": "Polyethylene - 4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PE14",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 100,
    "plantName": "Utility-1-2-3",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UTL123",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 101,
    "plantName": "Utility-4",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UTL4",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 102,
    "plantName": "Utility Common",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "UTL COMMON",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 103,
    "plantName": "Product Packaging System",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "PPS",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 104,
    "plantName": "SHARQ overall",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "COMMON",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 105,
    "plantName": "Olefins",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF PLANT",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 106,
    "plantName": "OLF COMMON",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF COMMON",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 107,
    "plantName": "POLYMER COMMON (PE-1-2-3-4)",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "POLYMER COMMON",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 8,
    "affiliateName": "SHARQ",
    "plant": 108,
    "plantName": "OLEFIN",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLF",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 7,
    "affiliateName": "KEMYA",
    "plant": 109,
    "plantName": "KOP",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "KOP",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  },
  {
    "affiliate": 19,
    "affiliateName": "SAUDI KAYAN",
    "plant": 110,
    "plantName": "OLEFINS",
    "country": 3,
    "countryName": "Kingdom of Saudi Arabia",
    "abbreviation": "OLEFINS",
    "lattitude": null,
    "longitude": null,
    "rollout": false
  }
];

export const userRoleMappingData = [
  {
    "name": "Ali",
    "affiliate": "SAFCO",
    "plant": "BRN",
  },
  {
    "name": "Sadiq",
    "affiliate": "SAFCO",
    "plant": "BRN",
  },
  {
    "name": "Vijay",
    "affiliate": "SAFCO",
    "plant": "BRN",
  },
  {
    "name": "Amit",
    "affiliate": "SAFCO",
    "plant": "BRN",
  },
  {
    "name": "Manoj",
    "affiliate": "SAFCO",
    "plant": "BRN",
  },
];

export const roleListData = [
  {
    "roleId": 1,
    "roleName": "Super Admin"
  },
  {
    "roleId": 2,
    "roleName": "Plant Admin"
  },
  {
    "roleId": 3,
    "roleName": "Plant User"
  }
];

export const roleMappingPlantListData = [
  {
    "plantId": 2,
    "plantName": "BRN"
  },
  {
    "plantId": 3,
    "plantName": "COG"
  },
  {
    "plantId": 4,
    "plantName": "LEXR"
  }
];

export const roleMappingAffiliateListData = [
  {
    "affiliateId": 2,
    "affiliateName": "SAFCO"
  },
  {
    "affiliateId": 3,
    "affiliateName": "MTVERNON"
  },
  {
    "affiliateId": 4,
    "affiliateName": "YANPET"
  },
  {
    "affiliateId": 5,
    "affiliateName": "PETROKEMYA"
  },
  {
    "affiliateId": 7,
    "affiliateName": "KEMYA"
  },
  {
    "affiliateId": 8,
    "affiliateName": "SHARQ"
  },
  {
    "affiliateId": 9,
    "affiliateName": "YANSAB"
  },
  {
    "affiliateId": 10,
    "affiliateName": "UNITED"
  },
  {
    "affiliateId": 11,
    "affiliateName": "GELEEN"
  },
  {
    "affiliateId": 14,
    "affiliateName": "affiliate test"
  },
  {
    "affiliateId": 15,
    "affiliateName": "petrokemya_test"
  },
  {
    "affiliateId": 16,
    "affiliateName": "ibn zahr"
  },
  {
    "affiliateId": 17,
    "affiliateName": "aff test"
  },
  {
    "affiliateId": 18,
    "affiliateName": "yansab"
  },
  {
    "affiliateId": 19,
    "affiliateName": "SAUDI KAYAN"
  },
  {
    "affiliateId": 20,
    "affiliateName": "ARRAZI"
  },
  {
    "affiliateId": 21,
    "affiliateName": "IBN ZAHR"
  },
  {
    "affiliateId": 22,
    "affiliateName": "IBNSINA"
  },
  {
    "affiliateId": 23,
    "affiliateName": "petrokemya_test"
  },
  {
    "affiliateId": 24,
    "affiliateName": "test_affiliate"
  },
  {
    "affiliateId": 25,
    "affiliateName": "Petrohow"
  },
  {
    "affiliateId": 27,
    "affiliateName": "sharq"
  },
  {
    "affiliateId": 28,
    "affiliateName": "sharqtemp"
  },
  {
    "affiliateId": 29,
    "affiliateName": "SABIC Agri-Nutrients"
  },
  {
    "affiliateId": 30,
    "affiliateName": "Petrokemya"
  },
  {
    "affiliateId": 41,
    "affiliateName": "YANSAB_Copy"
  },
  {
    "affiliateId": 42,
    "affiliateName": "yansab_Copy"
  },
  {
    "affiliateId": 47,
    "affiliateName": "UNITED_Copy"
  },
  {
    "affiliateId": 48,
    "affiliateName": "ARRAZI_Copy"
  }
];

export const assetModelConfigTableData = [
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 34,
    "xCoordinate": 57.9
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 34,
    "xCoordinate": 62.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 34,
    "xCoordinate": 41.8
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 34,
    "xCoordinate": 50
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 74.1,
    "xCoordinate": 5.3
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1586,
    "modelName": "Motor Performance",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1587,
    "modelName": "Motor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1588,
    "modelName": "Compressor Performance",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1589,
    "modelName": "Compressor Journal Bearing",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1590,
    "modelName": "Compressor Seal Gas Performance",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 1591,
    "modelName": "Compressor Thrust Bearing",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  },
  {
    "assetId": "2K-3101",
    "sensorGroupId": 7688,
    "modelName": "Compressor Performance_FE",
    "yCoordinate": 34,
    "xCoordinate": 32.5
  }
]

export const assetModelConfigTableStatus = [
  {
    message: "success",
  },

];

export const exceptionLogsData = [
  {
    "logId": 1,
    "exceptionMsg": "Could not find stored procedure 'GlobalSearch'.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalSearchList(String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 82\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalSearchList(String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 53\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 34",
    "userId": 0,
    "logDate": "2023-04-12T12:00:19"
  },
  {
    "logId": 2,
    "exceptionMsg": "API exception",
    "exceptionType": "Exception",
    "exceptionSource": "AHCWebGlobalMicroservice",
    "stackTrace": "   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalSearchList(String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 70\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalSearchList(String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 53\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.InvokeInnerFilterAsync()\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 34",
    "userId": 0,
    "logDate": "2023-04-12T12:06:03"
  },
  {
    "logId": 4,
    "exceptionMsg": "The required column 'CountryId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode1\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebGlobalMicroservice.Repositories.AffiliateService.GetAffiliateDetailsByRegionId(Int32 regionId, String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\AffiliateService.cs:line 107\r\n   at AHCWebGlobalMicroservice.Controllers.AffiliateController.GetAffiliateDetailsByRegionId(Int32 regionId, String userId) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\AffiliateController.cs:line 53\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 34",
    "userId": 0,
    "logDate": "2023-04-12T16:41:02"
  },
  {
    "logId": 5,
    "exceptionMsg": "The required column 'CountryId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\2023-04-17\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 84\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 41\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 31",
    "userId": 0,
    "logDate": "2023-04-19T12:44:17.893"
  },
  {
    "logId": 6,
    "exceptionMsg": "Unable to cast object of type 'System.Double' to type 'System.Single'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Single()\r\n   at lambda_method101(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\2023-04-17\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 84\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 41\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 31",
    "userId": 0,
    "logDate": "2023-04-19T12:45:34.303"
  },
  {
    "logId": 7,
    "exceptionMsg": "Unable to cast object of type 'System.Double' to type 'System.Single'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Single()\r\n   at lambda_method101(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\2023-04-17\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 84\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 41\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 31",
    "userId": 0,
    "logDate": "2023-04-19T12:45:41.053"
  },
  {
    "logId": 8,
    "exceptionMsg": "The required column 'AlertTrend' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\2023-04-17\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalTopBarSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 116\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalTopBarSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 53\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 31",
    "userId": 0,
    "logDate": "2023-04-19T13:27:51.773"
  },
  {
    "logId": 9,
    "exceptionMsg": "Unable to cast object of type 'System.Double' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method258(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter parameter) in C:\\TFSCode1\\2023-04-17\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 39\r\n   at AHCWebGlobalMicroservice.Repositories.GlobalService.GetGlobalRegionMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Repositories\\GlobalService.cs:line 149\r\n   at AHCWebGlobalMicroservice.Controllers.GlobalController.GetGlobalRegionMapSummaryByUserId(String userId) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Controllers\\GlobalController.cs:line 65\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebGlobalMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode1\\2023-04-17\\API\\API\\AHCWebGlobalMicroservice\\Middleware\\ExceptionMiddleware.cs:line 31",
    "userId": 0,
    "logDate": "2023-04-19T13:48:25.763"
  },
  {
    "logId": 10,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T09:54:26.683"
  },
  {
    "logId": 11,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:32:24.287"
  },
  {
    "logId": 12,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:32:54.697"
  },
  {
    "logId": 13,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:33:15.327"
  },
  {
    "logId": 14,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:33:19.4"
  },
  {
    "logId": 15,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:35:01.257"
  },
  {
    "logId": 16,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:35:32.817"
  },
  {
    "logId": 18,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:40:16.737"
  },
  {
    "logId": 19,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:50:53.623"
  },
  {
    "logId": 20,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:58:50.587"
  },
  {
    "logId": 21,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:58:58.61"
  },
  {
    "logId": 22,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T10:59:03.55"
  },
  {
    "logId": 23,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T12:06:16.8"
  },
  {
    "logId": 24,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T12:07:00.527"
  },
  {
    "logId": 27,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\react\\24042023\\BE\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\react\\24042023\\BE\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-26T12:41:18.8"
  },
  {
    "logId": 41,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T09:40:07.067"
  },
  {
    "logId": 44,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T10:06:34.547"
  },
  {
    "logId": 47,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T10:15:50.927"
  },
  {
    "logId": 52,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T11:23:00.567"
  },
  {
    "logId": 54,
    "exceptionMsg": "Unable to cast object of type 'System.String' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method213(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 105\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 29\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T12:28:25.733"
  },
  {
    "logId": 55,
    "exceptionMsg": "Unable to cast object of type 'System.String' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method213(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 105\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 29\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T12:28:57.8"
  },
  {
    "logId": 56,
    "exceptionMsg": "Unable to cast object of type 'System.String' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method213(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 105\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 29\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T12:31:28.07"
  },
  {
    "logId": 57,
    "exceptionMsg": "Unable to cast object of type 'System.String' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method213(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 105\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 29\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T12:31:52.94"
  },
  {
    "logId": 58,
    "exceptionMsg": "Unable to cast object of type 'System.String' to type 'System.Int32'.",
    "exceptionType": "InvalidCastException",
    "exceptionSource": "System.Private.CoreLib",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlBuffer.get_Int32()\r\n   at lambda_method213(Closure , QueryContext , DbDataReader , Int32[] )\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 105\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 29\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T12:41:22.403"
  },
  {
    "logId": 59,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T13:23:43.507"
  },
  {
    "logId": 62,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Awaited|12_0(ControllerActionInvoker invoker, ValueTask`1 actionResultValueTask)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T15:10:58.85"
  },
  {
    "logId": 63,
    "exceptionMsg": "The required column 'AssetId' was not present in the results of a 'FromSql' operation.",
    "exceptionType": "InvalidOperationException",
    "exceptionSource": "Microsoft.EntityFrameworkCore.Relational",
    "stackTrace": "   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.BuildIndexMap(IReadOnlyList`1 columnNames, DbDataReader dataReader)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.ReferenceService.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\ReferenceService.cs:line 98\r\n   at AHCWebModelMicroservice.Controllers.ReferenceTableController.GetOfflineConditionByAssetId(String assetId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\ReferenceTableController.cs:line 44\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Awaited|12_0(ControllerActionInvoker invoker, ValueTask`1 actionResultValueTask)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-27T15:11:32.097"
  },
  {
    "logId": 66,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:43:29.877"
  },
  {
    "logId": 67,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:43:35.07"
  },
  {
    "logId": 68,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:43:47.037"
  },
  {
    "logId": 69,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:43:51.74"
  },
  {
    "logId": 70,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:45:53.353"
  },
  {
    "logId": 71,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:46:39.73"
  },
  {
    "logId": 72,
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "   at Microsoft.Data.SqlClient.SqlCommand.<>c.<ExecuteDbDataReaderAsync>b__208_0(Task`1 result)\r\n   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()\r\n   at System.Threading.Tasks.Task.<>c.<.cctor>b__272_0(Object obj)\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n--- End of stack trace from previous location ---\r\n   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)\r\n   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task& currentTaskSlot, Thread threadPoolThread)\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)\r\n   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in C:\\TFSCode\\Backend\\24042023\\API\\AHCWebRepository\\GenericRepository\\GenericRepository.cs:line 50\r\n   at AHCWebModelMicroservice.Repositories.LiveTrackingService.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Repositories\\LiveTrackingService.cs:line 143\r\n   at AHCWebModelMicroservice.Controllers.LiveTrackingController.GetLiveTrackingModelStatusByModelId(String modelId, String userId) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Controllers\\LiveTrackingController.cs:line 43\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeInnerFilterAsync>g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\TFSCode\\Backend\\24042023\\API\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-04-28T09:47:16.45"
  },
  {
    "logId": 189,
    "exceptionMsg": "No such host is known. (pi-vision.sabic.com:443)",
    "exceptionType": "WebException",
    "exceptionSource": "System.Net.Requests",
    "stackTrace": "   at System.Net.HttpWebRequest.GetResponse()\r\n   at AHCWebModelMicroservice.Repositories.PlotsService.GetPlotSensorGraphBySensorGroupId(GetPlotSensorGraphBySensorGroupId sesensorData) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Repositories\\PlotsService.cs:line 274\r\n   at AHCWebModelMicroservice.Controllers.PlotsController.String(GetPlotSensorGraphBySensorGroupId sensorData) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Controllers\\PlotsController.cs:line 104\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Awaited|12_0(ControllerActionInvoker invoker, ValueTask`1 actionResultValueTask)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.InvokeInnerFilterAsync()\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-05-04T11:44:45.903"
  },
  {
    "logId": 190,
    "exceptionMsg": "No such host is known. (pi-vision.sabic.com:443)",
    "exceptionType": "WebException",
    "exceptionSource": "System.Net.Requests",
    "stackTrace": "   at System.Net.HttpWebRequest.GetResponse()\r\n   at AHCWebModelMicroservice.Repositories.PlotsService.GetPlotSensorGraphBySensorGroupId(GetPlotSensorGraphBySensorGroupId sesensorData) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Repositories\\PlotsService.cs:line 274\r\n   at AHCWebModelMicroservice.Controllers.PlotsController.GetPlotSensorGraphBySensorGroupId(GetPlotSensorGraphBySensorGroupId sensorData) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Controllers\\PlotsController.cs:line 104\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Awaited|12_0(ControllerActionInvoker invoker, ValueTask`1 actionResultValueTask)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeNextActionFilterAsync>g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State& next, Scope& scope, Object& state, Boolean& isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.InvokeInnerFilterAsync()\r\n--- End of stack trace from previous location ---\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeFilterPipelineAsync>g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.<InvokeAsync>g__Logged|17_1(ResourceInvoker invoker)\r\n   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)\r\n   at Microsoft.AspNetCore.Authorization.AuthorizationMiddleware.Invoke(HttpContext context)\r\n   at AHCWebModelMicroservice.ExceptionMiddleware.InvokeAsync(HttpContext httpContext, IUnitOfWork`1 unitOfWork) in C:\\Users\\40025277\\source\\repos\\MFGAHCWebDashboardAPI-dev\\API\\AHCWebModelMicroservice\\Middleware\\ExceptionMiddleware.cs:line 33",
    "userId": 0,
    "logDate": "2023-05-04T20:42:17.43"
  }
];
export const addUserRollmapDataAPIResponse = [
  {
    "retVal": 1,
    "retMsg": "User Mapping Added Successfully"
  }
];

export const updateUserRollmapDataAPIResponse = [
  {
    "retVal": 1,
    "retMsg": "User Mapping Update Successful"
  }
];

export const userRoleMappingWorklist = [
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Dandu, Suneel",
    "userId": "30757064",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "DanduS@SABIC.com"
  },
  {
    "affilliateId": "6",
    "plantId": "13",
    "name": "svcappscan3",
    "userId": "svcappscan3",
    "affiliate": "IBN ZAHR",
    "plant": "Polypropylene-1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "svcappscan3@sabic.com"
  },
  {
    "affilliateId": "6",
    "plantId": "13",
    "name": "svcappscan3",
    "userId": "40000003",
    "affiliate": "IBN ZAHR",
    "plant": "Polypropylene-1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "svcappscan3@sabic.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Appscan Service account 2",
    "userId": "svcappscan2",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "svcappscan2@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Gawali, Adinath Manik",
    "userId": "gawalia",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "gawalia@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Bais, Tarun Singh",
    "userId": "30767368",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "BaisT@SABIC.com"
  },
  {
    "affilliateId": "8,17",
    "plantId": "109,65",
    "name": "Shah, Amit",
    "userId": "301003991",
    "affiliate": "PETROKEMYA,GELEEN",
    "plant": "olefins 4,OLF4",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "amit.shah@sabic.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Abrar, Saaim",
    "userId": "30756251",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "AbrarS@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "AlDiabat, Ahmad Mohammad",
    "userId": "aldiabata",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "aldiabata@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Sanih, Hammad",
    "userId": "30761649",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "SanihHa@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Moinuddin, Khaja",
    "userId": "30750983",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "MOINUDDINKHA@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Ali, Irteza",
    "userId": "30751268",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "AliIr@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Dhinesh Ram, Manivakkam Raja",
    "userId": "30759367",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "DhineshRamM@SABIC.com"
  },
  {
    "affilliateId": "8,13",
    "plantId": "22,55",
    "name": "Baqshi-Al, Hassan Ali",
    "userId": "35567",
    "affiliate": "PETROKEMYA,YANPET",
    "plant": "OLEFINS1,POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "Baqshiha@SABIC.com"
  },
  {
    "affilliateId": "8",
    "plantId": "22",
    "name": "Eskandarani, Mohammad Muneer",
    "userId": "88302",
    "affiliate": "PETROKEMYA",
    "plant": "OLEFINS1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "EskandaraniMM@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kumar, Upendra",
    "userId": "30763785",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kumarU@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Singh, Jitendra",
    "userId": "30753357",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "SinghJi@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Reddy, Saiesh",
    "userId": "30756138",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "Saiesh.Reddy@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Hiremath, Amaresh",
    "userId": "30763546",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "HiremathA@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kumar, Chitrala Sravan",
    "userId": "kumarcs",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kumarcs@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Vav, Soundharrajan",
    "userId": "30764867",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "VavS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Sunitha, Mahendrasinh",
    "userId": "30760843",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "SunithaM@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kak, Ashwini",
    "userId": "30757927",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kakA@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Mahalekshmi, Sabareesh",
    "userId": "30764585",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "MahalekshmiS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Kumar, Amit",
    "userId": "30764251",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "KumarAm@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Daniel, Manoj",
    "userId": "30764252",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "DanielM@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Chincholi, Ashwini",
    "userId": "30763545",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "ChincholiA@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kharadi, Imran Mohammed",
    "userId": "kharadii",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kharadii@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Ma, Harsha",
    "userId": "30757062",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "MaH@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Rayan Khalid Khaleel",
    "userId": "49857",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "Khaleelrk@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Hake, Trupti",
    "userId": "30764253",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "HakeT@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Davis, Linda",
    "userId": "30757058",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "DavisL@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Vijay, Sriramadas",
    "userId": "30763547",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "VijayS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Bhanu, Madeti",
    "userId": "30757061",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "BhanuM@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Shah, Abhay",
    "userId": "30761933",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "ShahAb@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Dandu, Suneel",
    "userId": "30757064",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "DanduS@SABIC.com"
  },
  {
    "affilliateId": "6",
    "plantId": "13",
    "name": "svcappscan3",
    "userId": "svcappscan3",
    "affiliate": "IBN ZAHR",
    "plant": "Polypropylene-1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "svcappscan3@sabic.com"
  },
  {
    "affilliateId": "6",
    "plantId": "13",
    "name": "svcappscan3",
    "userId": "40000003",
    "affiliate": "IBN ZAHR",
    "plant": "Polypropylene-1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "svcappscan3@sabic.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Appscan Service account 2",
    "userId": "svcappscan2",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "svcappscan2@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Gawali, Adinath Manik",
    "userId": "gawalia",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "gawalia@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Bais, Tarun Singh",
    "userId": "30767368",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "BaisT@SABIC.com"
  },
  {
    "affilliateId": "8,17",
    "plantId": "109,65",
    "name": "Shah, Amit",
    "userId": "301003991",
    "affiliate": "PETROKEMYA,GELEEN",
    "plant": "olefins 4,OLF4",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "amit.shah@sabic.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Abrar, Saaim",
    "userId": "30756251",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "AbrarS@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "AlDiabat, Ahmad Mohammad",
    "userId": "aldiabata",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "aldiabata@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Sanih, Hammad",
    "userId": "30761649",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "SanihHa@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Moinuddin, Khaja",
    "userId": "30750983",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "MOINUDDINKHA@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Ali, Irteza",
    "userId": "30751268",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "AliIr@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Dhinesh Ram, Manivakkam Raja",
    "userId": "30759367",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "DhineshRamM@SABIC.com"
  },
  {
    "affilliateId": "8,13",
    "plantId": "22,55",
    "name": "Baqshi-Al, Hassan Ali",
    "userId": "35567",
    "affiliate": "PETROKEMYA,YANPET",
    "plant": "OLEFINS1,POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "Baqshiha@SABIC.com"
  },
  {
    "affilliateId": "8",
    "plantId": "22",
    "name": "Eskandarani, Mohammad Muneer",
    "userId": "88302",
    "affiliate": "PETROKEMYA",
    "plant": "OLEFINS1",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "EskandaraniMM@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kumar, Upendra",
    "userId": "30763785",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kumarU@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Singh, Jitendra",
    "userId": "30753357",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "SinghJi@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Reddy, Saiesh",
    "userId": "30756138",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "Saiesh.Reddy@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Hiremath, Amaresh",
    "userId": "30763546",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "HiremathA@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kumar, Chitrala Sravan",
    "userId": "kumarcs",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kumarcs@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Vav, Soundharrajan",
    "userId": "30764867",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "VavS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Sunitha, Mahendrasinh",
    "userId": "30760843",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "SunithaM@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kak, Ashwini",
    "userId": "30757927",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kakA@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Mahalekshmi, Sabareesh",
    "userId": "30764585",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "MahalekshmiS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Kumar, Amit",
    "userId": "30764251",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "KumarAm@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Daniel, Manoj",
    "userId": "30764252",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "DanielM@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Chincholi, Ashwini",
    "userId": "30763545",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "ChincholiA@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Kharadi, Imran Mohammed",
    "userId": "kharadii",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 3,
    "mappingType": "plant",
    "roleMasterName": "Plant User",
    "emailId": "kharadii@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Ma, Harsha",
    "userId": "30757062",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "MaH@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Rayan Khalid Khaleel",
    "userId": "49857",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "Khaleelrk@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Hake, Trupti",
    "userId": "30764253",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "plant",
    "roleMasterName": "Super Admin",
    "emailId": "HakeT@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Davis, Linda",
    "userId": "30757058",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "DavisL@SABIC.com"
  },
  {
    "affilliateId": "13",
    "plantId": "55",
    "name": "Vijay, Sriramadas",
    "userId": "30763547",
    "affiliate": "YANPET",
    "plant": "POLY2",
    "roleId": 2,
    "mappingType": "plant",
    "roleMasterName": "Plant Admin",
    "emailId": "VijayS@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Bhanu, Madeti",
    "userId": "30757061",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "BhanuM@SABIC.com"
  },
  {
    "affilliateId": "0",
    "plantId": "0",
    "name": "Shah, Abhay",
    "userId": "30761933",
    "affiliate": "All",
    "plant": "All",
    "roleId": 1,
    "mappingType": "",
    "roleMasterName": "Super Admin",
    "emailId": "ShahAb@SABIC.com"
  }
];

export const employeeDataList = [
  {
    "employeeID": "123456",
    "employeeName": "Ali",
    "employeeEmail": "ali@sabic.com",
    "department": "Technology",
    "isMapped": false,
    "contactNo": "+919173666431",
    "location": "Jubail",
    "photo": null
  },
  {
    "employeeID": "123457",
    "employeeName": "Saim",
    "employeeEmail": "saim@sabic.com",
    "department": "Technology",
    "isMapped": false,
    "contactNo": "+919173666431",
    "location": "Jubail",
    "photo": null
  },
  {
    "employeeID": "123458",
    "employeeName": "Abhay",
    "employeeEmail": "abhay@sabic.com",
    "department": "Technology",
    "isMapped": false,
    "contactNo": "+919173666431",
    "location": "Jubail",
    "photo": null
  },
  {
    "employeeID": "123459",
    "employeeName": "Raza",
    "employeeEmail": "raza@sabic.com",
    "department": "Technology",
    "isMapped": false,
    "contactNo": "+919173666431",
    "location": "Jubail",
    "photo": null
  },
];

export const exceptionLogJSON = [
  {
    "logId": "aafc707a-ce7f-46ac-85a1-1a522b375096",
    "exceptionMsg": "Error converting data type nvarchar to int.",
    "exceptionType": "Microsoft.Data.SqlClient.SqlException",
    "exceptionSource": "Core Microsoft SqlClient Data Provider",
    "stackTrace": "<error\r\n  application=\"AHCWebModelMicroservice\"\r\n  host=\"DC1DWBDAPS003\"\r\n  type=\"Microsoft.Data.SqlClient.SqlException\"\r\n  message=\"Error converting data type nvarchar to int.\"\r\n  source=\"Core Microsoft SqlClient Data Provider\"\r\n  detail=\"# caller: @C:\\Sources\\ElmahCore\\ElmahCore\\ElmahCore\\Internal$\\CallerInfo.cs:9&#xD;&#xA;Microsoft.Data.SqlClient.SqlException (0x80131904): Error converting data type nvarchar to int.&#xD;&#xA;   at Microsoft.Data.SqlClient.SqlCommand.&lt;&gt;c.&lt;ExecuteDbDataReaderAsync&gt;b__208_0(Task`1 result)&#xD;&#xA;   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()&#xD;&#xA;   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task&amp; currentTaskSlot, Thread threadPoolThread)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()&#xD;&#xA;   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync[TSource](IQueryable`1 source, CancellationToken cancellationToken)&#xD;&#xA;   at AHCWebRepository.GenericRepository.GenericRepository`1.GetEntityData(String sqlQuery, SqlParameter[] parameters) in /opt/AzureDevOps/myagent/_work/2/s/AHCWebRepository/GenericRepository/GenericRepository.cs:line 78&#xD;&#xA;   at AHCWebModelMicroservice.Repositories.AssetModelService.GetAssetKpiByAssetId(String assetId, String userId) in /opt/AzureDevOps/myagent/_work/2/s/API/AHCWebModelMicroservice/Repositories/AssetModelService.cs:line 106&#xD;&#xA;   at AHCWebModelMicroservice.Controllers.AssetModelController.GetAssetKPIByAssetId(String assetId, String userId) in /opt/AzureDevOps/myagent/_work/2/s/API/AHCWebModelMicroservice/Controllers/AssetModelController.cs:line 41&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.TaskOfIActionResultExecutor.Execute(IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.&lt;InvokeActionMethodAsync&gt;g__Awaited|12_0(ControllerActionInvoker invoker, ValueTask`1 actionResultValueTask)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.&lt;InvokeNextActionFilterAsync&gt;g__Awaited|10_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Rethrow(ActionExecutedContextSealed context)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.Next(State&amp; next, Scope&amp; scope, Object&amp; state, Boolean&amp; isCompleted)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.&lt;InvokeInnerFilterAsync&gt;g__Awaited|13_0(ControllerActionInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.&lt;InvokeFilterPipelineAsync&gt;g__Awaited|20_0(ResourceInvoker invoker, Task lastTask, State next, Scope scope, Object state, Boolean isCompleted)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.&lt;InvokeAsync&gt;g__Awaited|17_0(ResourceInvoker invoker, Task task, IDisposable scope)&#xD;&#xA;   at Microsoft.AspNetCore.Mvc.Infrastructure.ResourceInvoker.&lt;InvokeAsync&gt;g__Awaited|17_0(ResourceInvoker invoker, Task task, IDisposable scope)&#xD;&#xA;   at Microsoft.AspNetCore.Routing.EndpointMiddleware.&lt;Invoke&gt;g__AwaitRequestTask|6_0(Endpoint endpoint, Task requestTask, ILogger logger)&#xD;&#xA;   at ElmahCore.Mvc.ErrorLogMiddleware.InvokeAsync(HttpContext context)&#xD;&#xA;ClientConnectionId:067285ab-641a-4308-97c5-5544f405cad7&#xD;&#xA;Error Number:8114,State:5,Class:16\"\r\n  time=\"2023-06-28T05:42:39.5538723Z\"\r\n  statusCode=\"500\">\r\n  <serverVariables>\r\n    <item\r\n      name=\"HttpVersion\">\r\n      <value\r\n        string=\"1.1\" />\r\n    </item>\r\n    <item\r\n      name=\"Scheme\">\r\n      <value\r\n        string=\"https\" />\r\n    </item>\r\n    <item\r\n      name=\"Method\">\r\n      <value\r\n        string=\"GET\" />\r\n    </item>\r\n    <item\r\n      name=\"PathBase\">\r\n      <value\r\n        string=\"/AHCWebAPIModel\" />\r\n    </item>\r\n    <item\r\n      name=\"Path\">\r\n      <value\r\n        string=\"/api/v1/AssetModel/getassetkpi_byassetid/2K-3201/18\" />\r\n    </item>\r\n    <item\r\n      name=\"QueryString\">\r\n      <value\r\n        string=\"\" />\r\n    </item>\r\n    <item\r\n      name=\"RawTarget\">\r\n      <value\r\n        string=\"/AHCWebAPIModel/api/v1/AssetModel/getassetkpi_byassetid/2K-3201/18\" />\r\n    </item>\r\n    <item\r\n      name=\"HasResponseStarted\">\r\n      <value\r\n        string=\"False\" />\r\n    </item>\r\n    <item\r\n      name=\"RemotePort\">\r\n      <value\r\n        string=\"0\" />\r\n    </item>\r\n    <item\r\n      name=\"LocalIpAddress\">\r\n      <value\r\n        string=\"10.33.21.58\" />\r\n    </item>\r\n    <item\r\n      name=\"LocalPort\">\r\n      <value\r\n        string=\"443\" />\r\n    </item>\r\n    <item\r\n      name=\"TraceIdentifier\">\r\n      <value\r\n        string=\"4001b78b-0001-ec00-b63f-84710c7967bb\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Accept\">\r\n      <value\r\n        string=\"application/json, text/plain, */*\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Accept-Encoding\">\r\n      <value\r\n        string=\"gzip, deflate, br\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Accept-Language\">\r\n      <value\r\n        string=\"en-US,en;q=0.9\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Authorization\">\r\n      <value\r\n        string=\"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI1NjU1OTkyOC03YmZiLTRhOWYtYTM1Zi1kNDBjMWRmZWIxZDciLCJJZCI6IjMwNzYxOTMzIiwiVXNlcm5hbWUiOiJTaGFoLCBBYmhheSIsIkVtYWlsSWQiOiJTaGFoQWJAU0FCSUMuY29tXlNoYWgsIEFiaGF5IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiU3VwZXIgQWRtaW4iLCJleHAiOjE2ODc5MzIxNDAsImlzcyI6IkFIQ1dlYkRhc2hib2FyZCIsImF1ZCI6IkFIQ1dlYkRhc2hib2FyZCJ9.5979Vk8WKeM9v1rDXDxa_8srfAO5yTV2zakA6fb0TpI\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Connection\">\r\n      <value\r\n        string=\"keep-alive\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Host\">\r\n      <value\r\n        string=\"dsappsdev.sabic.com\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Referer\">\r\n      <value\r\n        string=\"http://localhost:3000/\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_User-Agent\">\r\n      <value\r\n        string=\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.51\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_sec-ch-ua\">\r\n      <value\r\n        string=\"&quot;Not.A/Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;114&quot;, &quot;Microsoft Edge&quot;;v=&quot;114&quot;\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_sec-ch-ua-mobile\">\r\n      <value\r\n        string=\"?0\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_sec-ch-ua-platform\">\r\n      <value\r\n        string=\"&quot;Windows&quot;\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Origin\">\r\n      <value\r\n        string=\"http://localhost:3000\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Sec-Fetch-Site\">\r\n      <value\r\n        string=\"cross-site\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Sec-Fetch-Mode\">\r\n      <value\r\n        string=\"cors\" />\r\n    </item>\r\n    <item\r\n      name=\"Header_Sec-Fetch-Dest\">\r\n      <value\r\n        string=\"empty\" />\r\n    </item>\r\n    <item\r\n      name=\"MaxRequestBodySize\">\r\n      <value\r\n        string=\"30000000\" />\r\n    </item>\r\n    <item\r\n      name=\"StatusCode\">\r\n      <value\r\n        string=\"200\" />\r\n    </item>\r\n    <item\r\n      name=\"Connection_Id\">\r\n      <value\r\n        string=\"17005592198051379063\" />\r\n    </item>\r\n    <item\r\n      name=\"Connection_RemoteIpAddress\">\r\n      <value\r\n        string=\"10.37.14.25\" />\r\n    </item>\r\n    <item\r\n      name=\"Connection_RemotePort\">\r\n      <value\r\n        string=\"59063\" />\r\n    </item>\r\n    <item\r\n      name=\"Connection_LocalIpAddress\">\r\n      <value\r\n        string=\"10.33.21.58\" />\r\n    </item>\r\n    <item\r\n      name=\"Connection_LocalPort\">\r\n      <value\r\n        string=\"443\" />\r\n    </item>\r\n    <item\r\n      name=\"HttpStatusCode\">\r\n      <value\r\n        string=\"500\" />\r\n    </item>\r\n  </serverVariables>\r\n  <messageLog>\r\n    <message\r\n      level=\"Error\"\r\n      time-stamp=\"2023-06-28T05:42:39.5450531Z\"\r\n      message=\"Failed executing DbCommand (3ms) [Parameters=[@assetId='?' (Size = 7), @userId='?' (Size = 8)], CommandType='Text', CommandTimeout='150000']&#xD;&#xA;EXEC GetAssetKPIByAssetId @assetId, @userId\" />\r\n    <message\r\n      level=\"Error\"\r\n      exception=\"Microsoft.Data.SqlClient.SqlException (0x80131904): Error converting data type nvarchar to int.&#xD;&#xA;   at Microsoft.Data.SqlClient.SqlCommand.&lt;&gt;c.&lt;ExecuteDbDataReaderAsync&gt;b__208_0(Task`1 result)&#xD;&#xA;   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()&#xD;&#xA;   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task&amp; currentTaskSlot, Thread threadPoolThread)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()&#xD;&#xA;ClientConnectionId:067285ab-641a-4308-97c5-5544f405cad7&#xD;&#xA;Error Number:8114,State:5,Class:16\"\r\n      time-stamp=\"2023-06-28T05:42:39.5497983Z\"\r\n      message=\"An exception occurred while iterating over the results of a query for context type 'AHCWebRepository.DBContext.UnifiedWebDashboardDbContext'.&#xD;&#xA;Microsoft.Data.SqlClient.SqlException (0x80131904): Error converting data type nvarchar to int.&#xD;&#xA;   at Microsoft.Data.SqlClient.SqlCommand.&lt;&gt;c.&lt;ExecuteDbDataReaderAsync&gt;b__208_0(Task`1 result)&#xD;&#xA;   at System.Threading.Tasks.ContinuationResultTaskFromResultTask`2.InnerInvoke()&#xD;&#xA;   at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at System.Threading.Tasks.Task.ExecuteWithThreadLocal(Task&amp; currentTaskSlot, Thread threadPoolThread)&#xD;&#xA;--- End of stack trace from previous location ---&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Storage.RelationalCommand.ExecuteReaderAsync(RelationalCommandParameterObject parameterObject, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.InitializeReaderAsync(AsyncEnumerator enumerator, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal.SqlServerExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)&#xD;&#xA;   at Microsoft.EntityFrameworkCore.Query.Internal.FromSqlQueryingEnumerable`1.AsyncEnumerator.MoveNextAsync()&#xD;&#xA;ClientConnectionId:067285ab-641a-4308-97c5-5544f405cad7&#xD;&#xA;Error Number:8114,State:5,Class:16\" />\r\n  </messageLog>\r\n</error>",
    "userId": "",
    "logDate": "2023-06-28T05:42:39.553"
  }
];


