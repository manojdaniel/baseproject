// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import Status from "components/Status";
import GlobalPreviewMap from "components/GlobalPreviewMap";
import RegionPreviewMap from "components/RegionPreviewMap";
import { healthindexTooltip } from "../DataModel/HomePageList";
import "./Home.scss";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import {
	getGlobalTopBarSummary,
	getGlobalMapSummaryByUserId,
	getGlobalRegionMapSummaryByUserId,
	getBreadCrumbDate,
	getGlobalSearch,
	getGlobalSelecetedAffiliate,
	getGlobalSelecetedPlant
} from "../redux/reducers/CommonReducer";
import {
	getGlobalSelecetedRegion,
	getLoggedInUserDetails,
} from "../redux/reducers/CommonReducer";
import { useNavigate } from "react-router-dom";
import globalmap from "../assets/images/global_map.svg";
import newmap from "../assets/images/newmap.svg";
import regionmiddleeast from "../assets/images/region_middle_east.svg";
import regionamerica from "../assets/images/region_america.svg";
import regioneurope from "../assets/images/region_europe.svg";
import regionasia from "../assets/images/region_asia.svg";
import tooltipActive from "../assets/images/tooltip-active.svg";
import tooltipHeart from "../assets/images/tooltip-heart.svg";
import tooltipPmcompliance from "../assets/images/tooltip-pmcompliance.svg";
import tooltipSearch from "../assets/images/tooltip-search.svg";
import tooltipSparesAvailability from "../assets/images/tooltip-spares-availability.svg";
import tooltipTime from "../assets/images/tooltip-time.svg";
import tooltipUparrow from "../assets/images/tooltip-uparrow.svg";
import Loader from "components/Loader";

const Home = () => {
	const [getSelectedRegion, setGetSelectedRegion] = useState<any>(null);
	const [getTog, setTog] = useState<any>(true);
	const [getSelectedAllCountry, setSelectedAllCountry] = useState<any>([]);

	// Americas

	const [getUsa, setgetUsa] = useState<any>([]);
	const [getBrazil, setgetBrazil] = useState<any>([]);
	const [getArgentina, setgetArgentina] = useState<any>([]);

	// Europe

	const [getTheUk, setgetTheUk] = useState<any>([]);
	const [getNetherLands, setgetNetherLands] = useState<any>([]);
	const [getGermani, setgetGermani] = useState<any>([]);
	const [getSpain, setgetSpain] = useState<any>([]);

	// MiddleEast

	const [getJubail, setgetJubail] = useState<any>([]);
	const [getYanbu, setgetYanbu] = useState<any>([]);

	// Asia

	const [getShangahi, setgetShangahi] = useState<any>([]);
	const [getSingapore, setgetSingapore] = useState<any>([]);


	let navigate = useNavigate();
	let dispatch = useDispatch();

	const {
		globalTopBarSummary,
		globalMapSummaryByUserId,
		globalRegionMapSummaryByUserId,
		loadingGlobalRegionMapSummaryByUserId,
		commonFromDateFormat,
		commonToDateFormat,
		selectedBreadCrumbDate,
		breadCrumbDateFormated,
		breadCrumbDate,
		commonToDate,
		commonFromDate,
		loggedInUserDetails,
		onePlantUser,
		onePlantUserData,
		loadingGlobalTopBarSummary,
		oneAffiliateUser
	} = useSelector((state: any) => ({
		globalTopBarSummary: state.Common.globalTopBarSummary,
		globalMapSummaryByUserId: state.Common.globalMapSummaryByUserId,
		globalRegionMapSummaryByUserId: state.Common.globalRegionMapSummaryByUserId,
		loadingGlobalRegionMapSummaryByUserId: state.Common.loadingGlobalRegionMapSummaryByUserId,
		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		commonToDate: state.Common.commonToDate,
		commonFromDate: state.Common.commonFromDate,
		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
		breadCrumbDate: state.Common.breadCrumbDate,
		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,
		loggedInUserDetails: state.Common.loggedInUserDetails,
		onePlantUser: state.Common.onePlantUser,
		oneAffiliateUser: state.Common.oneAffiliateUser,
		onePlantUserData: state.Common.onePlantUserData,

		loadingGlobalTopBarSummary: state.Common.loadingGlobalTopBarSummary,
	}));

	const userId = 1;

	useEffect(() => {
		if (Object.keys(loggedInUserDetails).length > 0) {
			try {
				const currentdate = new Date();
				let updatedDate: any;
				updatedDate = new Date(currentdate.setMonth(currentdate.getMonth() - 1));
				dispatch(getBreadCrumbDate({ id: "1M", updatedDate: updatedDate }));
			} catch (error) { }
			if (onePlantUser === 1) {
				dispatch(getGlobalSelecetedRegion({ value: onePlantUserData.regionId, label: onePlantUserData.regionName, }));
				dispatch(getGlobalSelecetedAffiliate({ value: onePlantUserData.affiliateId, label: onePlantUserData.affiliateName, }));
				dispatch(getGlobalSelecetedPlant({ value: onePlantUserData.plantId, label: onePlantUserData.plantName }));
				dispatch(getGlobalSearch(""));
				navigate(`/plant/pmt`,)
			} else if (oneAffiliateUser === 1) {
				dispatch(getGlobalSelecetedRegion({ value: onePlantUserData.regionId, label: onePlantUserData.regionName, }));
				dispatch(getGlobalSelecetedAffiliate({ value: onePlantUserData.affiliateId, label: onePlantUserData.affiliateName, }));
				dispatch(getGlobalSearch(""));
				navigate(`/allPlants`,)
			}
			else {
				//const getAPIPassingData = { "userId": userId, "jwtToken": loggedInUserDetails.result.jwtToken }
				let timer1 = setTimeout(() => {
					dispatch(getGlobalTopBarSummary("")); //{userId}
					dispatch(getGlobalMapSummaryByUserId("")); //{userId}
					dispatch(getGlobalRegionMapSummaryByUserId("")); //{userId}
					dispatch(getGlobalSearch(""));
				}, 100);
				return () => {
					clearTimeout(timer1);
				};
			}
		}

	}, [loggedInUserDetails, onePlantUser]);

	useEffect(() => {
		setTog(!getTog);
	}, [getSelectedRegion]);

	const handleNavigation = (item: any) => {
		dispatch(getGlobalSelecetedRegion(item));
		navigate("/affiliates");
	};

	const onClickAffiliates = (key: any, data: any) => {
		handleNavigation({ value: data.regionId, label: data.regionName });
	};

	// Global Preview Start===========

	// Region Abrv List

	let AmericasAbrv = "AMR";

	let EuropeAbrv = "EUR";

	let MiddleEastAbrv = "ME";

	let AsiaAbrv = "AS";

	const Americas = globalMapSummaryByUserId.filter(
		(item: any) => item.abrv.toString().toUpperCase() === `${AmericasAbrv}`
	);

	const Europe = globalMapSummaryByUserId.filter(
		(item: any) => item.abrv.toString().toUpperCase() === `${EuropeAbrv}`
	);

	const MiddleEast = globalMapSummaryByUserId.filter(
		(item: any) => item.abrv.toString().toUpperCase() === `${MiddleEastAbrv}`
	);

	const Asia = globalMapSummaryByUserId.filter(
		(item: any) => item.abrv.toString().toUpperCase() === `${AsiaAbrv}`
	);

	const onClickRegionPreview = (data: any) => {
		setGetSelectedRegion(data.toUpperCase());

		const getRegionAffiliates = globalRegionMapSummaryByUserId.filter(
			({ regionAbrv }) => regionAbrv === data
		);

		setSelectedAllCountry(getRegionAffiliates);

		// Americas

		const getUsa1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "USA"
		);

		setgetUsa(getUsa1);

		const getBrazil1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "BR"
		);

		setgetBrazil(getBrazil1);

		const getArgentina1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "ARG"
		);

		setgetArgentina(getArgentina1);

		// Europe

		const getTheUk1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "BE"
		);

		setgetTheUk(getTheUk1);

		const getNetherLands1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "NL"
		);

		setgetNetherLands(getNetherLands1);

		const getGermani1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "GER"
		);

		setgetGermani(getGermani1);

		const getSpain1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "SP"
		);

		setgetSpain(getSpain1);

		// MiddleEast

		const getJubail1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "KSA"
		);

		setgetJubail(getJubail1);

		const getYanbu1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "YAN"
		);

		setgetYanbu(getYanbu1);

		// Asia

		const getShangahi1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "SHA"
		);

		setgetShangahi(getShangahi1);

		const getSingapore1 = getRegionAffiliates.filter(
			(item: any) => item.abrv.toString().toUpperCase() === "SIN"
		);

		setgetSingapore(getSingapore1);
	};

	return (
		<>
			{loadingGlobalTopBarSummary ? (
				<Loader />
			) : (
				<Status
					data={globalTopBarSummary}
					page={"HOME"}
					healthIndexToolTip={healthindexTooltip}
				/>
			)}
			<div id="global-map">
				{/* Global Preview : Start================================================== */}

				<div id="global-map-left">
					<div className="common-box-inner cust-home-align">
						<div className="top-fl-box">
							<div className="common-box-filter">
								<div className="title">GLOBAL MAP</div>
							</div>

							<div className="common-box-asset-name">
								<div className="asset-name">
									Click on the region to get more details
								</div>
							</div>
						</div>

						<div className="map-box">
							{Americas.length !== 0 && Americas[0].abrv !== null ? (
								// <div
								// 	className={`region-1 ${
								// 		getSelectedRegion === `${AmericasAbrv}` ? "active" : ""
								// 	}`}
								// 	onClick={() => onClickRegionPreview(Americas[0].abrv)}
								// >
								// 	<span className="region-tooltip">
								// 		{Americas[0].name.toUpperCase()}
								// 	</span>

								// 	<span>
								// 		<i>{Americas[0].affiliateCount}</i>
								// 	</span>
								// </div>
								<div className={`region-1 ${getSelectedRegion === `${AmericasAbrv}` ? "active" : ""}`} onClick={() => onClickRegionPreview(Americas[0].abrv)}>
									<span className="region-tooltip">{Americas[0].name.toUpperCase()}</span>
									<i>
										{Americas[0].affiliateCount}
										{
											Americas[0].affiliateCount < 10 ? <b style={{ borderWidth: (`${Americas[0].affiliateCount}` * 3), width: '40px', height: '40px' }}></b> :
												<b style={{ borderWidth: (`${Americas[0].affiliateCount}` * 3), width: '50px', height: '50px' }}></b>
										}
									</i></div>
							) : null}

							{Europe.length !== 0 && Europe[0].abrv !== null ? (
								<div className={`region-2 ${getSelectedRegion === `${EuropeAbrv}` ? "active" : ""}`} onClick={() => onClickRegionPreview(Europe[0].abrv)}>
									<span className="region-tooltip">{Europe[0].name.toUpperCase()}{" "}</span>
									<i>
										{Europe[0].affiliateCount}
										{
											Europe[0].affiliateCount < 10 ? <b style={{ borderWidth: (`${Europe[0].affiliateCount}` * 3), width: '40px', height: '40px' }}></b> :
												<b style={{ borderWidth: (`${Europe[0].affiliateCount}` * 3), width: '50px', height: '50px' }}></b>
										}
									</i>
								</div>
							) : null}

							{MiddleEast.length !== 0 && MiddleEast[0].abrv !== null ? (
								<div className={`region-3 ${getSelectedRegion === `${MiddleEastAbrv}` ? "active" : ""}`} onClick={() => onClickRegionPreview(MiddleEast[0].abrv)}>
									<span className="region-tooltip">{MiddleEast[0].name.toUpperCase()}</span>
									<i>
										{MiddleEast[0].affiliateCount}
										{
											MiddleEast[0].affiliateCount < 10 ? <b style={{ borderWidth: (`${MiddleEast[0].affiliateCount}` * 3), width: '40px', height: '40px' }}></b> :
												<b style={{ borderWidth: (`${MiddleEast[0].affiliateCount}` * 3), width: '50px', height: '50px' }}></b>
										}
									</i>
								</div>
							) : null}

							{Asia.length !== 0 && Asia[0].abrv !== null ? (
								<div className={`region-4 ${getSelectedRegion === `${AsiaAbrv}` ? "active" : ""}`} onClick={() => onClickRegionPreview(Asia[0].abrv)}>
									<span className="region-tooltip">{Asia[0].name.toUpperCase()}</span>
									<i>
										{Asia[0].affiliateCount}
										{
											Asia[0].affiliateCount < 10 ? <b style={{ borderWidth: (`${Asia[0].affiliateCount}` * 5), width: '40px', height: '40px' }}></b> :
												<b style={{ borderWidth: (`${Asia[0].affiliateCount}` * 3), width: '50px', height: '50px' }}></b>
										}
									</i>
								</div>
							) : null}

							<img src={newmap} />
						</div>
					</div>
				</div>

				{/* Global Preview : End======================================================= */}

				<div id="global-map-right">
					{/* Region Preview MIDDLE EAST ASIA MAP : Start=================================*/}

					{getSelectedRegion === `${MiddleEastAbrv}` ? (
						<div className="common-box-inner">
							<div className="common-box-filter">
								<div className="title">MIDDLE EAST ASIA MAP</div>
							</div>

							<div className="common-box-asset-name">
								<div className="asset-name">
									Click on the region to get more details
								</div>
							</div>
							{loadingGlobalRegionMapSummaryByUserId ? (
								<Loader />
							) : (

								<div className="country-map mea">
									{getJubail.length !== 0 ? (
										<div
											className="country-jubail"
											onClick={() =>
												onClickAffiliates("affiliates", getJubail[0])
											}
										>
											<span>
												{/* // map tooltip  */}

												<AlertMapPop alertmapPopData={getJubail} />

												<i>{getJubail[0].affiliateCount}</i>
											</span>
										</div>
									) : null}

									{getYanbu.length !== 0 ? (
										<div
											className="country-yanbu"
											onClick={() => onClickAffiliates("affiliates", getYanbu[0])}
										>
											<span>
												{/* // map tooltip  */}

												<AlertMapPop alertmapPopData={getYanbu} />

												<i>{getYanbu[0].affiliateCount}</i>
											</span>
										</div>
									) : null}

									<img src={regionmiddleeast} />
								</div>
							)}
						</div>
					) : (
						<>
							{/*Region Preview MIDDLE EAST ASIA MAP : End========================*/}

							{/* Region Preview Asia MAP : Start=================================*/}

							{getSelectedRegion === `${AsiaAbrv}` ? (
								<div className="common-box-inner">
									<div className="common-box-filter">
										<div className="title">ASIA MAP</div>
									</div>

									<div className="common-box-asset-name">
										<div className="asset-name">
											Click on the region to get more details
										</div>
									</div>
									{loadingGlobalRegionMapSummaryByUserId ? (
										<Loader />
									) : (
										<div className="country-map asia">
											{getShangahi.length !== 0 ? (
												<div
													className="country-shangahi"
													onClick={() =>
														onClickAffiliates("affiliates", getShangahi[0])
													}
												>
													<span>
														{/* // map tooltip  */}

														<AlertMapPop alertmapPopData={getShangahi} />

														<i>{getShangahi[0].affiliateCount}</i>
													</span>
												</div>
											) : null}

											{getSingapore.length !== 0 ? (
												<div
													className="country-singapore"
													onClick={() =>
														onClickAffiliates("affiliates", getSingapore[0])
													}
												>
													<span>
														{/* // map tooltip  */}

														<AlertMapPop alertmapPopData={getSingapore} />

														<i>{getSingapore[0].affiliateCount}</i>
													</span>
												</div>
											) : null}

											<img src={regionasia} />
										</div>
									)}
								</div>
							) : (
								<>
									{/* Region Preview Asia MAP : End=================================*/}

									{/* Region Preview Americas MAP : Start=================================*/}

									{getSelectedRegion === `${AmericasAbrv}` ? (
										<>
											{/* AMERICA DIV */}

											<div className="common-box-inner">
												<div className="common-box-filter">
													<div className="title">AMERICA MAP</div>
												</div>

												<div className="common-box-asset-name">
													<div className="asset-name">
														Click on the region to get more details
													</div>
												</div>
												{loadingGlobalRegionMapSummaryByUserId ? (
													<Loader />
												) : (
													<div className="country-map america">
														{getUsa.length !== 0 ? (
															<div
																className="country-usa"
																onClick={() =>
																	onClickAffiliates("affiliates", getUsa[0])
																}
															>
																<span>
																	{/* // map tooltip  */}

																	<AlertMapPop alertmapPopData={getUsa} />

																	<i>{getUsa[0].affiliateCount}</i>
																</span>
															</div>
														) : null}

														{getBrazil.length !== 0 ? (
															<div
																className="country-brazil"
																onClick={() =>
																	onClickAffiliates("affiliates", getUsa[0])
																}
															>
																<span>
																	{/* // map tooltip  */}

																	<AlertMapPop alertmapPopData={getBrazil} />

																	<i>{getBrazil[0].affiliateCount}</i>
																</span>
															</div>
														) : null}

														{getArgentina.length !== 0 ? (
															<div
																className="country-argentina"
																onClick={() =>
																	onClickAffiliates("affiliates", getUsa[0])
																}
															>
																<span>
																	{/* // map tooltip  */}

																	<AlertMapPop alertmapPopData={getArgentina} />

																	<i>{getArgentina[0].affiliateCount}</i>
																</span>
															</div>
														) : null}

														<img src={regionamerica} />
													</div>
												)}
											</div>
										</>
									) : (
										<>
											{/* Region Preview Americas MAP : End=================================*/}

											{/* Region Preview Europe MAP : Start=================================*/}

											{getSelectedRegion === `${EuropeAbrv}` ? (
												<>
													{/* EUROPE DIV */}

													<div className="common-box-inner">
														<div className="common-box-filter">
															<div className="title">EUROPE MAP</div>
														</div>

														<div className="common-box-asset-name">
															<div className="asset-name">
																Click on the region to get more details
															</div>
														</div>
														{loadingGlobalRegionMapSummaryByUserId ? (
															<Loader />
														) : (
															<div className="country-map europe">
																{getSpain.length !== 0 ? (
																	<div
																		className="country-spain"
																		onClick={() =>
																			onClickAffiliates("affiliates", getSpain[0])
																		}
																	>
																		<span>
																			{/* // map tooltip  */}

																			<AlertMapPop alertmapPopData={getSpain} />

																			<i>{getSpain[0].affiliateCount}</i>
																		</span>
																	</div>
																) : null}

																{getNetherLands.length !== 0 ? (
																	<div
																		className="country-netherlands"
																		onClick={() =>
																			onClickAffiliates(
																				"affiliates",

																				getNetherLands[0]
																			)
																		}
																	>
																		<span>
																			{/* // map tooltip  */}

																			<AlertMapPop
																				alertmapPopData={getNetherLands}
																			/>

																			<i>{getNetherLands[0].affiliateCount}</i>
																		</span>
																	</div>
																) : null}

																{getGermani.length !== 0 ? (
																	<div
																		className="country-germany"
																		onClick={() =>
																			onClickAffiliates(
																				"affiliates",

																				getGermani[0]
																			)
																		}
																	>
																		<span>
																			{/* // map tooltip  */}

																			<AlertMapPop alertmapPopData={getGermani} />

																			<i>{getGermani[0].affiliateCount}</i>
																		</span>
																	</div>
																) : null}

																{getTheUk.length !== 0 ? (
																	<div
																		className="country-uk"
																		onClick={() =>
																			onClickAffiliates("affiliates", getTheUk[0])
																		}
																	>
																		<span>
																			{/* // map tooltip  */}

																			<AlertMapPop alertmapPopData={getTheUk} />

																			<i>{getTheUk[0].affiliateCount}</i>
																		</span>
																	</div>
																) : null}

																<img src={regioneurope} />
															</div>
														)}
													</div>
												</>
											) : (
												<div className="common-box-inner">
													<div className="common-box-filter">
														<div className="title">SELECTED REGION</div>
													</div>

													<div className="common-box-asset-name">
														<div className="asset-name">
															Details will appear after selection
														</div>
													</div>
												</div>
											)}

											{/* Region Preview Europe MAP : End=================================*/}
										</>
									)}
								</>
							)}
						</>
					)}
				</div>
			</div>
		</>
	);
};

//Tooltip Component Start

interface Props {
	alertmapPopData: any;
}

const AlertMapPop = ({ alertmapPopData }: Props) => {

	return (
		<div className="map-tooltip">
			<h3>OVERALL {alertmapPopData[0].name.toUpperCase()}</h3>

			<div className="map-content">
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipHeart} />
					</div>

					<div className="map-tooltip-content">
						<span>
							{alertmapPopData[0].healthIndex}%
							<i>
								<img src={tooltipUparrow} />
							</i>
						</span>

						<span>HEALTH INDEX</span>
					</div>
				</div>

				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipActive} />
					</div>

					<div className="map-tooltip-content">
						<span>{alertmapPopData[0].active}</span>

						<span>ACTIVE</span>
					</div>
				</div>

				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipTime} />
					</div>

					<div className="map-tooltip-content">
						<span>
							{alertmapPopData[0].overDue}

							<i>
								<img src={tooltipUparrow} />
							</i>
						</span>

						<span>OVERDUE INVESTIGATION</span>
					</div>
				</div>

				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipPmcompliance} />
					</div>

					<div className="map-tooltip-content">
						<span>{alertmapPopData[0].pmCompliance}%</span>

						<span>PM COMPLIANCE</span>
					</div>
				</div>

				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipSearch} />
					</div>

					<div className="map-tooltip-content">
						<span>{alertmapPopData[0].underInvestigation}</span>

						<span>UNDER INVESTIGATION</span>
					</div>
				</div>

				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipSparesAvailability} />
					</div>

					<div className="map-tooltip-content">
						<span>{alertmapPopData[0].sparesAvailability}</span>

						<span>SPARES AVAILABILITY</span>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Home;

export { AlertMapPop };
