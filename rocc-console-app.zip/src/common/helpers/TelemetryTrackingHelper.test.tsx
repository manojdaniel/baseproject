/*
 * Created on Thu Dec 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType } from "@rocc/rocc-client-services"
import * as RoccLoggingModule from "@rocc/rocc-logging-module"
import * as RoccClientServices from "@rocc/rocc-client-services"
import { trackConsoleDisconnection, transformSessionTypeForAnalytics } from "./TelemetryTrackingHelper"

describe("Telemetry Tracking", () => {
    it("should track console disconnection", () => {
        const sendLogsToAzureMock = jest.spyOn(RoccLoggingModule, "sendLogsToAzure")
        jest.spyOn(RoccClientServices, "getTrackingEvent").mockReturnValue("tracking value")
        trackConsoleDisconnection({} as any)
        expect(sendLogsToAzureMock).toBeCalled()
    })
    it("should transform session type for analytics", () => {
        let res: string
        res = transformSessionTypeForAnalytics(EConnectionMode.CC)
        expect(res).toBe("Fixed command center connection")
        res = transformSessionTypeForAnalytics(EConnectionMode.EMERALD)
        expect(res).toBe("Non fixed command center connection")
        res = transformSessionTypeForAnalytics(EConnectionType.FULL_CONTROL_USB)
        expect(res).toBe("Edit Console With USB Redirection Enabled As A Private Connection")
        res = transformSessionTypeForAnalytics(EConnectionType.PROTOCOL_MANAGEMENT)
        expect(res).toBe("Protocol Management Console")
        res = transformSessionTypeForAnalytics(EConnectionType.INCOGNITO_VIEW)
        expect(res).toBe("Incognito-View Console")
        res = transformSessionTypeForAnalytics(EConnectionType.FULL_CONTROL)
        expect(res).toBe("Edit Console")
        res = transformSessionTypeForAnalytics(EConnectionType.VIEW)
        expect(res).toBe("View Console")
        res = transformSessionTypeForAnalytics(EConnectionType.DEFAULT)
        expect(res).toBe("Console")
    })
})
