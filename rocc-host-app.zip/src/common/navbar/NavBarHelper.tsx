/*
 * Created on Tue Mar 22 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, DownloadUtility, EAppStates, EButtonDirection, EClinicalRole, ERoccWorkflow, FeatureFlagHelper, IMessage, IParentStore, IPresignedUrl, launchAppUri, NFCC_BUNDLE, parseIntBase10, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import FileSaver from "file-saver"
import React, { Dispatch } from "react"
import SVG from "react-inlinesvg"
import { Button, Icon, Label, Popup } from "semantic-ui-react"
import protocolTransferIcon from "../../assets/images/ProtocolTransferNew.svg"
import support from "../../assets/images/support.svg"
import { CONSOLE_APP_STORE, DROPDOWN_TYPE, MENU_TYPE } from "../../constants/constants"
import { ADMIN_ROUTE, ADMIN_USER_MANUAL_ROUTE, CONSULTS_ROUTE, EXPERT_USER_MANUAL_ROUTE, IDN_ROUTE, LOGOUT_ROUTE, REGISTER_ROUTE, ROOM_MONITORING_ROUTE, SETTINGS_ROUTE, SUPPORT_ROUTE } from "../../constants/routes"
import { TRACK } from "../../constants/tracking"
import { setRoomMonitoringWindow } from "../../redux/actions/appActions"
import { updatePresignedUrls } from "../../redux/actions/configActions"
import {
    EXPERTUSER_LOGOUT_INIT, GLOBAL_CLEAR_DESTINATIONS, GLOBAL_SET_DESTINATION_SCANNER, GLOBAL_SET_INITIATION_ROUTE,
    GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, GLOBAL_SET_PROTOCOL_TRANSFER_STEP, GLOBAL_SET_SOURCE_SCANNER, GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_NOTIFICATION_MODAL
} from "../../redux/actions/types"
import { setCurrentAppState } from "../../redux/actions/userAction"
import { registerWorkflow } from "../../redux/actions/workflowActions"
import globalStore from "../../redux/store/globalStore"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"
import { dispatchToGlobalStore } from "../../strore/ExternalAppStates"
import { EManualType, EPhoneIconColor, GLOBAL_SET_INITIATE_PHONE_CALL, IGetIconMenuItems, IGetInitialNavConfig } from "../../types/types"
import { roccHttpClient } from "../../utility/api/apiUtility"
import { checkPreSignedUrlExpired } from "../../utility/helpers/dateTimeUtility"
import { constructAppUriForBundleUpgrade, getAppReducerData, getConFigs, getCurrentUserData, getFeatureFlags, getFullApplicationName, getPreSignedUrls, getUrls, hideNotificationModal, openLiveWindow, trackEvent } from "../../utility/helpers/helpers"
import styles from "./NavBar.scss"

const { EXPERTUSER, ADMIN, RADIOLOGIST, TECHNOLOGIST } = EClinicalRole

export const getInitialNavConfig = (props: IGetInitialNavConfig) => {
    const { phoneIconColor, logoutText, protocolTransferStatus, count, dispatch, showNfccDownload, aboutClick, phoneIconCallBack, isAdminOnly, isTechAppDownloadAvailable, cctvWindow } = props
    return {
        appTitleMenuItems: [{
            items: [{ text: getFullApplicationName(), onClick: () => handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(getHomepageLink())) }],
            label: "AppName",
            type: MENU_TYPE
        }],
        iconMenuItems: getIconMenuItems({ phoneIconColor, protocolTransferStatus, dispatch, count, showNfccDownload, phoneIconCallBack, aboutClick, isAdminOnly, isTechAppDownloadAvailable, cctvWindow }),
        primaryMenuItems: getPrimaryMenuItems(protocolTransferStatus, dispatch),
        secondaryMenuItems: [{
            items: [{ text: logoutText, onClick: () => { handleProtocolTransferExit(protocolTransferStatus, dispatch, () => handleApplicationLogout(dispatch)) } }],
            label: "username",
            type: DROPDOWN_TYPE
        }]
    }
}

export const getInitialNavConfigForPreSignedContext = (props: IGetInitialNavConfig) => {
    const { phoneIconColor, logoutText, protocolTransferStatus, count, dispatch, phoneIconCallBack, isAdminOnly } = props
    return {
        appTitleMenuItems: [{
            items: [{ text: getFullApplicationName(), onClick: () => handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(getHomepageLink())) }],
            label: "AppName",
            type: MENU_TYPE
        }],
        iconMenuItems: [{ items: [phoneIcon(phoneIconColor, count, phoneIconCallBack, isAdminOnly)], label: "", type: MENU_TYPE }],
        primaryMenuItems: [],
        secondaryMenuItems: [{
            items: [{ text: logoutText, onClick: () => { handleProtocolTransferExit(protocolTransferStatus, dispatch, () => handleApplicationLogout(dispatch)) } }],
            label: "username",
            type: DROPDOWN_TYPE
        }]
    }
}

export const handleProtocolTransferExit = (protocolTransferStatus: boolean, dispatch: any, action = () => { "" }) => {
    if (protocolTransferStatus) {
        dispatch({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: leaveProtocolTransferConfirmDlg(dispatch, action) } })
    } else {
        action()
    }
}

const leaveProtocolTransferConfirmDlg = (dispatch: any, action = () => { "" }) => {
    const { intl } = getIntlProvider()
    const notificationModal = {
        showModal: true,
        modalContent: intl.formatMessage({ id: "content.protocolTransfer.protocolManagerExitMessage", defaultMessage: en["content.protocolTransfer.protocolManagerExitMessage"] }),
        showCloseIcon: false,
        actionButton1Text: intl.formatMessage({ id: "content.admin.closeUserModal.secondaryBtn", defaultMessage: en["content.admin.closeUserModal.secondaryBtn"] }),
        actionButton2Text: intl.formatMessage({ id: "content.admin.closeUserModal.primaryBtn", defaultMessage: en["content.admin.closeUserModal.primaryBtn"] }),
        actionButton1Onclick: () => onConfirm(dispatch, action),
        actionButton2Onclick: () => onCancel(dispatch),
        modalStyles: "ptLeaveModal",
    }
    return notificationModal
}
const { component, event: { stay, leave } } = TRACK.PROTOCOL

const onCancel = (dispatch: any) => {
    dispatch({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: { showModal: false } } })
    trackEvent(component, stay, { event_by: getCurrentUserData().uuid })
}

const onConfirm = (dispatch: any, action = () => { "" }) => {
    trackEvent(component, leave, { event_by: getCurrentUserData().uuid })

    resetStates()
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, payload: { protocolTransferStatus: false }
    })
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_INITIATION_ROUTE, payload: { initiationRoute: "" }
    })
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, payload: { protocolTransferExit: true }
    })
    dispatch({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: { showModal: false } } })
    action()
}

const resetStates = () => {
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_PROTOCOL_TRANSFER_STEP, payload: { currentStep: 1 }
    })
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_SOURCE_SCANNER, payload: { selectedSource: {} }
    })
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_SET_DESTINATION_SCANNER, payload: { selectedDestination: {} }
    })
    globalStore.DispatchAction(CONSOLE_APP_STORE, {
        type: GLOBAL_CLEAR_DESTINATIONS, payload: { completedDestinations: [] }
    })
}

export const secondaryTopMenuLink = (link: any) => {
    window.location.hash = link
}

export const getHomepageLink = () => {
    let route = "/"
    if (!getCurrentUserData().onBoarded) {
        route = REGISTER_ROUTE
    } else {
        switch (getCurrentUserData().clinicalRole) {
            case EXPERTUSER:
                route = IDN_ROUTE
                break
            case ADMIN:
                route = ADMIN_ROUTE
                break
            default:
        }
    }
    return checkAndUpdateRadconnectRoutes() ? CONSULTS_ROUTE : route
}

const checkAndUpdateRadconnectRoutes = () => {
    /* If Radconnect feature flag is enabled */
    const roles = getCurrentUserData().allRoles
    return FeatureFlagHelper.isFeatureEnabled(getFeatureFlags(), ROCC_FEATURES.FLAG_RADCONNECT) && (roles.includes(TECHNOLOGIST) || roles.includes(RADIOLOGIST))
}

const cctvIconClick = (dispatch: Dispatch<any>) => {
    dispatch(setRoomMonitoringWindow(true))
    openLiveWindow(ROOM_MONITORING_ROUTE)
    const { component, event: { cctv } } = TRACK.NAV_BAR
    trackEvent(component, cctv)
}

export const cctvIcon = (cctvWindow: Boolean, dispatch: Dispatch<any>) => {
    const { intl } = getIntlProvider()
    return {
        component: <Popup
            trigger={
                <Button
                    active={!!cctvWindow}
                    onClick={() => cctvIconClick(dispatch)}
                >
                    <Icon className={"icon ConnectionCameraConnected"} />
                </Button>
            }
            content={intl.formatMessage({ id: "content.room.launchLiveWindow", defaultMessage: en["content.room.launchLiveWindow"] })}
            position={"bottom right"}
            inverted={true}
            className={"protocolTransferToolTip"}
        />
    }
}

export const getIconMenuItems = (props: IGetIconMenuItems) => {
    const { cctvWindow, phoneIconColor, protocolTransferStatus, dispatch, count, showNfccDownload, phoneIconCallBack, aboutClick, isAdminOnly, isTechAppDownloadAvailable } = props
    return getCurrentUserData().onBoarded ? [
        { items: [cctvIcon(cctvWindow, dispatch)], label: "", type: MENU_TYPE },
        { items: [protocolTransfrIcon(false, protocolTransferStatus, dispatch)], label: "", type: MENU_TYPE },
        { items: [phoneIcon(phoneIconColor, count, phoneIconCallBack, isAdminOnly)], label: "", type: MENU_TYPE },
        { items: [settingsIcon(protocolTransferStatus, dispatch, isAdminOnly, isTechAppDownloadAvailable)], label: "", type: MENU_TYPE },
        { items: [supportIcon(protocolTransferStatus, dispatch)], label: "", type: MENU_TYPE },
        {
            items: getHelpDropDownOptions(protocolTransferStatus, aboutClick, getCurrentUserData().allRoles, showNfccDownload, dispatch),
            icon: <Icon className={`QuestionmarkCircleOutline iconBadge`}>
                {getAppReducerData().nfccUpgradeAvailable && <span className="badgeContent">{1}</span>}
            </Icon> as any,
            label: "",
            type: DROPDOWN_TYPE
        }
    ] : []
}

export const protocolTransfrIcon = (disabled: boolean, protocolTransferStatus: boolean, dispatch: any) => {
    const { intl } = getIntlProvider()
    return {
        component: <Popup
            trigger={
                <Button
                    active={protocolTransferStatus}
                    onClick={() => !disabled && toggleProtocolTransfer(protocolTransferStatus, dispatch)}
                    className={cx(styles.triggerButton, disabled && styles.disableProtocolTransferButton)}
                >
                    <SVG src={protocolTransferIcon} cacheRequests={true} />
                </Button>
            }
            content={intl.formatMessage({ id: "content.protocolTransfer.disabledTooltipMessage", defaultMessage: en["content.protocolTransfer.disabledTooltipMessage"] })}
            position={"bottom right"}
            disabled={!disabled}
            inverted={true}
            className={"protocolTransferToolTip"}
        />
    }
}

const toggleProtocolTransfer = (protocolTransferStatus: boolean, dispatch: any) => {
    handleProtocolTransferExit(protocolTransferStatus, dispatch, () => {
        secondaryTopMenuLink(getHomepageLink())
        const protocolTransferStateChange = protocolTransferStatus ? "disable" : "enable"
        globalStore.DispatchAction(CONSOLE_APP_STORE, {
            type: "GLOBAL_SET_PROTOCOL_TRANSFER_STATUS", payload: { protocolTransferStatus: !protocolTransferStatus }
        })
        sendLogsForProtocolTransfer(protocolTransferStateChange)
        globalStore.DispatchAction(CONSOLE_APP_STORE, {
            type: "GLOBAL_SET_INITIATION_ROUTE", payload: { initiationRoute: location.pathname }
        })
    })
}

const sendLogsForProtocolTransfer = (status: string) => {
    const { component, event: { protocol } } = TRACK.NAV_BAR
    trackEvent(component, `${protocol} ${status}`, { event_by: getCurrentUserData().uuid })
}

export const phoneIcon = (phoneIconColor: EPhoneIconColor, count: number, phoneIconCallBack: () => void, isAdminOnly: boolean) => ({
    component: !isAdminOnly && <Icon className={`phone iconBadge ${phoneIconColor}`} onClick={phoneIconCallBack} >
        {count !== 0 && <span className="badgeContent">{count}</span>}
    </Icon>
})

export const settingsIcon = (protocolTransferStatus: boolean, dispatch: any, isAdminOnly: boolean, isTechAppDownloadAvailable: boolean) => ({
    component: ((isAdminOnly && isTechAppDownloadAvailable) || !isAdminOnly) && <Icon className={"Settings"} onClick={() => { handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(SETTINGS_ROUTE)) }}></Icon>
})

export const supportIcon = (protocolTransferStatus: boolean, dispatch: any) => ({
    component: <Icon className={"icon Support"} onClick={() => handleProtocolTransferExit(protocolTransferStatus, dispatch, () => {
        const { component, event: { support } } = TRACK.NAV_BAR
        trackEvent(component, support, { event_by: getCurrentUserData().uuid })
        return secondaryTopMenuLink(SUPPORT_ROUTE)
    })}></Icon>
})

export const getHelpDropDownOptions = (protocolTransferStatus: boolean, aboutClick: () => void, allRoles: EClinicalRole[], showNfccDownload: boolean, dispatch: any) => {
    const { intl } = getIntlProvider()
    const isAdmin = allRoles.includes(ADMIN)
    const isExpert = allRoles.includes(EXPERTUSER)
    const helpDropDown: any[] = [{
        text: intl.formatMessage({ id: "content.about.list", defaultMessage: en["content.about.list"] }),
        /**TODO: Add about page component */
        onClick: () => aboutClick()
    }]
    const fseData = getAppReducerData().fseData
    const urls = getUrls()
    const preSignedUrls = getPreSignedUrls()
    const configs = getConFigs()
    if ((isExpert || (fseData && fseData.isFse))) {
        helpDropDown.push({
            text: userManualMessage(),
            onClick: async () => {
                await fetchUserManual(urls.MANAGEMENT_SERVICE_URL, EManualType.USER_MANUAL, preSignedUrls.expertUserManual)
                handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(EXPERT_USER_MANUAL_ROUTE))
                const { component, event: { userManual } } = TRACK.NAV_BAR
                trackEvent(component, userManual)
            }
        })
    }
    if (isAdmin) {
        helpDropDown.push({
            text: intl.formatMessage({ id: "content.adminManual.list", defaultMessage: en["content.adminManual.list"] }),
            onClick: async () => {
                await fetchUserManual(urls.MANAGEMENT_SERVICE_URL, EManualType.ADMIN_MANUAL, preSignedUrls.adminUserManual)
                handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(ADMIN_USER_MANUAL_ROUTE))

                const { component, event: { adminManual } } = TRACK.NAV_BAR
                trackEvent(component, adminManual)
            }
        })
    }
    if (configs.CUSTOMER_PRIVACY_POLICY_URL && (isExpert || isAdmin)) {
        helpDropDown.push({
            text: <a href={configs.CUSTOMER_PRIVACY_POLICY_URL} target="_blank" rel="noopener noreferrer">
                {intl.formatMessage({ id: "content.onboarding.termsAction.privacyPolicy", defaultMessage: en["content.onboarding.termsAction.privacyPolicy"] })}
            </a>
        })
    }
    if (isAdmin || isExpert) {
        helpDropDown.push({
            text: intl.formatMessage({ id: "content.contactUs.list", defaultMessage: en["content.contactUs.list"] }),
            onClick: () => handleContactUs(dispatch)
        })
    }
    if (showNfccDownload) {
        const nfccUpgradeAvailable = getAppReducerData().nfccUpgradeAvailable
        helpDropDown.push({
            text: <>{nfccUpgradeAvailable ? intl.formatMessage({ id: "content.upgrade.nfccInstaller.title", defaultMessage: en["content.upgrade.nfccInstaller.title"] })
                : intl.formatMessage({ id: "content.download.nfccInstaller.title", defaultMessage: en["content.download.nfccInstaller.title"] })}
                {nfccUpgradeAvailable && <Label color="red" circular={true} size="mini" className={styles.notificationNewLabel}>
                    {intl.formatMessage({ id: "content.helpDropDown.notification.labelName", defaultMessage: en["content.helpDropDown.notification.labelName"] })}
                </Label>}</>,
            onClick: async () => {
                dispatch(setCurrentAppState(EAppStates.LOADING))
                const configs = getConFigs()
                if (!preSignedUrls.nfccBundle.url || checkPreSignedUrlExpired(preSignedUrls.nfccBundle.createdAt, parseIntBase10(configs.PRESIGNED_URL_EXPIRY_MINUTES) - Number(5))) {
                    const fileInfo = await DownloadUtility.getPresignedUrl(roccHttpClient, getCurrentUserData().accessToken, urls.MANAGEMENT_SERVICE_URL, NFCC_BUNDLE)
                    preSignedUrls.nfccBundle.createdAt = new Date()
                    preSignedUrls.nfccBundle.url = fileInfo.url
                    preSignedUrls.nfccBundle.version = fileInfo.version
                    updatePresignedUrls(getPreSignedUrls())
                }
                if (nfccUpgradeAvailable) {
                    const { version, url } = preSignedUrls.nfccBundle
                    launchAppUri(constructAppUriForBundleUpgrade(NFCC_BUNDLE, version, url))
                    displayNotificationMessageForNFCCUpgrade(intl)
                    const { component, event: { NFCC_upgrade } } = TRACK.NAV_BAR
                    trackEvent(component, NFCC_upgrade)
                }
                else {
                    FileSaver.saveAs(preSignedUrls.nfccBundle.url)
                    const { component, event: { NFCC_dwonload } } = TRACK.NAV_BAR
                    trackEvent(component, NFCC_dwonload)
                }
                dispatch(setCurrentAppState(EAppStates.READY))
            }
        })
    }
    return helpDropDown
}

const displayNotificationMessageForNFCCUpgrade = (intl: any) => {
    const customStyle = { top: "3rem", right: "1rem", width: "29.25rem" }
    const message = [{
        header: intl.formatMessage({ id: "content.upgrade.nfccInstaller.title", defaultMessage: en["content.upgrade.nfccInstaller.title"] }),
        content: intl.formatMessage({ id: "content.notificationMessage.upgradeNFCCMessage", defaultMessage: en["content.notificationMessage.upgradeNFCCMessage"] })
    }]
    displayNotificationMessage(message, customStyle, false, true, false, false)
}


export const displayNotificationMessage = (message: IMessage[], customStyle: any, isWarning?: boolean, isNotification?: boolean, isSuccess?: boolean, hideIcon?: boolean) => {
    const notificationMessage = {
        show: true,
        hideIcon: !hideIcon && !true,
        closeMessage: {},
        isSuccess: isSuccess || false,
        isWarning: isWarning || false,
        isNotification: isNotification || false,
        fixed: false,
        timeOut: 3000,
        showNotification: true,
        message: message,
        customStyle: customStyle
    }
    dispatchToGlobalStore({ type: GLOBAL_UPDATE_NOTIFICATION_MESSAGE, payload: { notificationMessage: notificationMessage } })
}

const handleContactUs = (dispatch: any) => {
    const { intl } = getIntlProvider()
    const notificationModal = {
        showModal: true,
        header: intl.formatMessage({ id: "content.contactUs.list", defaultMessage: en["content.contactUs.list"] }),
        modalContent: getContactUsModalContent(),
        actionButton1Text: getContactusButtonText(),
        buttonDirection: EButtonDirection.LEFT,
        actionButton1Onclick: () => { handleContactUsButtonClick(dispatch) },
        modalStyles: "contactUsModal",
        showCloseIcon: true,
        closeIcon: true,
        onClose: () => hideNotificationModal(dispatch)
    }
    dispatch({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })

    const { component, event: { contactUs } } = TRACK.NAV_BAR
    trackEvent(component, contactUs)

}

const getContactUsModalContent = () => {
    const { intl } = getIntlProvider()
    return (
        <div className={styles.modalMessage}>
            {intl.formatMessage({ id: "content.contactUs.messageLine1", defaultMessage: en["content.contactUs.messageLine1"] })}
            <br />
            {intl.formatMessage({ id: "content.contactUs.messageLine2", defaultMessage: en["content.contactUs.messageLine2"] })}
        </div>
    )
}

const getContactusButtonText = () => {
    const config = getConFigs()
    const contactUsPhoneNumber = config.ROCC_HELPLINE
    return (<div className={styles.contactUsButton}>
        <SVG src={support} cacheRequests={true} />
        <span>{contactUsPhoneNumber}</span>
    </div>)
}

const handleContactUsButtonClick = (dispatch: Dispatch<any>) => {
    const { intl } = getIntlProvider()
    const state: IParentStore = store.getState()
    const { ROCC_HELPLINE } = state.configReducer.configs
    const roccHelplineName = intl.formatMessage({ id: "content.rocc.helpline", defaultMessage: en["content.rocc.helpline"] })
    const contactInfo = { ...DEFAULT_CONTACT_INFO, name: roccHelplineName, phoneNumber: ROCC_HELPLINE, uuid: "roccHelpline" }
    const { component, event: { roccHelplineNo } } = TRACK.CONTACT_US
    sendLogsToAzure({
        contextData: {
            component: component,
            event: roccHelplineNo,
            Event_By: state.userReducer.currentUser.uuid
        }
    })
    dispatchToGlobalStore({
        type: GLOBAL_SET_INITIATE_PHONE_CALL, payload: {
            initiatePhoneCall: { contactUuid: "", contactInfo, phoneNumber: ROCC_HELPLINE, componentName: component },
        }
    })
    trackEvent(component, roccHelplineNo)
    hideNotificationModal(dispatch)
}

const getPrimaryMenuItems = (protocolTransferStatus: boolean, dispatch: any) => {
    const { intl } = getIntlProvider()
    return getCurrentUserData().onBoarded ? [{
        items: [{ text: intl.formatMessage({ id: "content.link.home", defaultMessage: en["content.link.home"] }), onclick: () => handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(getHomepageLink())) }],
        label: "primaryMenuItems",
        type: MENU_TYPE
    }] : []
}

export const handleApplicationLogout = (dispatch: any, postLogoutRoute: string = LOGOUT_ROUTE) => {
    dispatch({ type: EXPERTUSER_LOGOUT_INIT })
    dispatch(registerWorkflow(ERoccWorkflow.LOGOUT, { context: { postLogoutRoute, electionList: [] } }))
}

const fetchUserManual = async (url: string, manualType: EManualType, preSignedUrl: IPresignedUrl) => {
    const configs = getConFigs()
    if (!preSignedUrl.url || checkPreSignedUrlExpired(preSignedUrl.createdAt, parseIntBase10(configs.PRESIGNED_URL_EXPIRY_MINUTES))) {
        const fileInfo = await DownloadUtility.getPresignedUrl(roccHttpClient, getCurrentUserData().accessToken, url, manualType)
        preSignedUrl.createdAt = new Date()
        preSignedUrl.url = fileInfo.url
        updatePresignedUrls(getPreSignedUrls())
    }
}

const userManualMessage = () => {
    const { intl } = getIntlProvider()
    return <div>
        {intl.formatMessage({ id: "content.userManual.technologist", defaultMessage: en["content.userManual.technologist"] })}
        <span className={cx(styles.dropDownManualMarginLeft, styles.dropDownManualMarginRight)}>
            &
        </span>
        {intl.formatMessage({ id: "content.userManual.expert", defaultMessage: en["content.userManual.expert"] })}
        <span className={cx(styles.dropDownManualMarginLeft)}></span>
        {intl.formatMessage({ id: "content.userManual.list", defaultMessage: en["content.userManual.list"] })}

    </div>
}
