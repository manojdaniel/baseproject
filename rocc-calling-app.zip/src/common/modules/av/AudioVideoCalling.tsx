/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IAVCallDetails } from "@rocc/rocc-client-services"
import React from "react"
import { IConnectedCallProps } from "../../../types/types"
import AudioVideoRoom from "./AudioVideoRoom"

export interface IAudioVideoCallingProps {
    activeCall: IAVCallDetails
    connectedCallProps?: IConnectedCallProps
}

const AudioVideoCalling = (props: IAudioVideoCallingProps) => {
    const videoRenderDimensions = {
        high: { height: 1080, width: 1920 },
        standard: { height: 720, width: 1280 },
        low: { height: 93, width: 150 },
    }
    return (
        <AudioVideoRoom renderDimensions={videoRenderDimensions} {...props} />
    )
}

export default AudioVideoCalling
