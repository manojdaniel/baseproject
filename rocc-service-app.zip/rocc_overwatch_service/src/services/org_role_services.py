"""
 Created on Wed Feb 23 2022
 Copyright (c) 2022 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os

from src.constants.config_keys import VAULT_HSDP_IAM_URL
from src.constants.constants import CF_DOMAIN, HSDP_ORGANIZATION_ID, ROCC_PROXY_URL, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.rbac_services.rbac_services import get_roles_for_organization, update_roles_for_organization

LOG = create_logger("OrgRoleService")


class OrgRoleService():

    def __init__(self, service_user_uuid, org_name):
        """ Use parent org_id, since update can happen for both Customer and Global configurations """
        self._customer_configs = get_path_specific_vault_values(
            org_name).get("data")
        self._profile_configs = get_profile_data()
        self._org_uuid = self._customer_configs[HSDP_ORGANIZATION_ID]
        self._customer_service_token = None
        self.populate_service_token()
        self._org_name = org_name
        self._service_user_uuid = service_user_uuid
        self._client = get_client_connection(
            access_token=self._customer_service_token, org_infra_uuid=self._org_uuid)

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_uuid:
            try:
                prepare_and_post_audit(event_type="Customer Roles", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_uuid, token=self._customer_service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def populate_service_token(self):
        try:
            LOG.info(self._customer_configs)
            self._customer_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                    issuer=self._customer_configs[SERVICE_AUTH_ISSUER],
                                                                           private_key=self._customer_configs[SERVICE_AUTH_PRIVATE_KEY])

        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!") from ex

    def fetch_org_roles(self):
        try:
            url_domain = f"{self._org_name}-rocc.{os.environ[CF_DOMAIN]}"
            role_list = get_roles_for_organization(
                url=url_domain, token=self._customer_service_token)
            if role_list:
                return {"data": role_list}, 200
            else:
                raise Exception
        except Exception as ex:
            LOG.exception(
                f"Failed to fetch roles for Org: {self._org_uuid} with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload=f"Failed to fetch roles for Org: {self._org_uuid}") from ex

    def update_org_roles(self, added_org_roles, deleted_org_roles):
        try:
            response = update_roles_for_organization(url=os.environ[ROCC_PROXY_URL],
                                                     added_roles=added_org_roles, deleted_roles=deleted_org_roles,
                                                     org_id=self._org_uuid, token=self._customer_service_token, client=self._client, user_uuid=self._service_user_uuid)
            self.safe_audit(event_subtype="Update Customer Role", action="U",
                            outcome=0, code="Update Customer Role", value="Success")
            return response
        except Exception as ex:
            LOG.exception(
                f"Failed to update roles for org: {self._org_uuid} with error: {ex}")
            self.safe_audit(event_subtype="Update Customer Role", action="U",
                            outcome=4, code="Update Customer Role", value="Error")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload=f"Failed to update roles for org: {self._org_uuid}") from ex
