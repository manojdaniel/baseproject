"""
 Created on Thu Oct 30 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import KVM_CONFIGURATION_DICT, CUSTOMER_INFO_DICT
from src.constants.enums import ESummaryStates
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_org_db_id_from_identifier
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.validation_service.kvm_data_validation_service import check_if_data_exists
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("KvmConfigDataValidation")


class KvmConfigDataValidation():

    def __init__(self, service_token, org_infra_uuid):
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)

    def validate_kvm_config_data_exists(self):
        new_kvm = self._transaction_data["summary"]["kvm"]["new"]
        org_db_id = fetch_org_db_id_from_identifier(client=self._client, customer_identifier=self._customer_name)
        for key, kvm_data in self._kvm_dict.items():
            if key in new_kvm:
                LOG.info(f"Validating kvm data for {key}")
                kvm_data_exists = check_if_data_exists(self._client, kvm_details=kvm_data, org_db_id=org_db_id)
                if not kvm_data_exists:
                    LOG.info(f"Kvm data does not exists for {key}")
                    self._transaction_data = update_summary_for_entity(self._transaction_data, "sites", key, ESummaryStates.VALIDATION_FAILED)
            else:
                LOG.info(f"This kvm {key} is not a new kvm config, skipping validation ..!")

    def initiate_data_validation(self, data_dict, transaction_data):
        LOG.info("Initiating kvm configuration data validation ..!!")
        self._data_dict = data_dict
        self._kvm_dict = data_dict[KVM_CONFIGURATION_DICT]
        self._transaction_data = transaction_data
        self._customer_name = data_dict[CUSTOMER_INFO_DICT][0]["customer_identifier"].lower()
        self.validate_kvm_config_data_exists()
        LOG.info("Validation of kvm data completed ..!!")
        return self._data_dict, self._transaction_data
