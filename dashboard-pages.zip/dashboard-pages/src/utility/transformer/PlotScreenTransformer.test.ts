import { getDateUtcFormat, getDeviationTransformer, getSensorIdList, getSensorTodateAdded, getSensorTodaySubtractedDate, getTimeZone } from './PlotScreenTransformer';
import "@testing-library/jest-dom/extend-expect";


describe('getSensorIdList', () => {
  test('transforms data correctly', () => {
    const data = [{ value: 1 }, { value: 2 }, { value: 3 }];
    const result = getSensorIdList(data);
    expect(result).toEqual(['1', '2', '3']);
  });

  test('returns empty array for empty input', () => {
    const data = [];
    const result = getSensorIdList(data);
    expect(result).toEqual([]);
  });
});

describe('getSensorTodateAdded', () => {
  test('adds 30 days to input date', () => {
    const date = '2022-01-01';
    const result = getSensorTodateAdded(date);
    expect(result).toEqual('31-01-2022');
  });

  test('handles invalid input date', () => {
    const date = 'invalid date';
    const result = getSensorTodateAdded(date);
    expect(result).toEqual('Invalid date');
  });
});
describe('transformers', () => {
    describe('getSensorTodaySubtractedDate', () => {
      it('should subtract 30 days from given date and return in format "DD-MM-YYYY"', () => {
        const inputDate = '2022-04-21';
        const expectedOutput = '22-03-2022';
  
        const output = getSensorTodaySubtractedDate(inputDate);
  
        expect(output).toBe(expectedOutput);
      });
    });
  
    describe('getDateUtcFormat', () => {
      it('should return date in UTC format', () => {
        const inputDate = '2022-04-21T10:00:00+05:30';
        const expectedOutput = '2022-04-21T04:30:00Z';
  
        const output = getDateUtcFormat(inputDate);
  
        expect(output).toBe(expectedOutput);
      });
    });
  
    describe('getTimeZone', () => {
      it('should return the timezone of the current system', () => {
        const expectedOutput = new Date().toString().match(/\(([^\)]+)\)$/)[1];
  
        const output = getTimeZone();
  
        expect(output).toBe(expectedOutput);
      });
    });
  });
  
describe('getDeviationTransformer', () => {
  const data = [
    {
      localTime: '2022-01-01T00:00:00',
      distance: 10,
      alertThreshold: 5,
      warningThreshold: 8,
      status: 'OK',
    },
    {
      localTime: '2022-01-02T12:00:00',
      distance: 15,
      alertThreshold: 5,
      warningThreshold: 8,
      status: 'WARNING',
    },
    {
      localTime: '2022-01-03T23:59:59',
      distance: 20,
      alertThreshold: 5,
      warningThreshold: 8,
      status: 'ALERT',
    },
  ];

  test('transforms data correctly', () => {
    const result = getDeviationTransformer(data);
    expect(result).toEqual([
      {
        localTime: '2022-01-01T00:00:00',
        distance: 10,
        alertThreshold: 5,
        warningThreshold: 8,
        status: 'OK',
        time: 'Time 0:0',
      },
      {
        localTime: '2022-01-02T12:00:00',
        distance: 15,
        alertThreshold: 5,
        warningThreshold: 8,
        status: 'WARNING',
        time: 'Time 12:0',
      },
      {
        localTime: '2022-01-03T23:59:59',
        distance: 20,
        alertThreshold: 5,
        warningThreshold: 8,
        status: 'ALERT',
        time: 'Time 23:59',
      },
    ]);
  });
});
