"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import unittest
from unittest.mock import patch
from src.constants.config_keys import VAULT_PARENT_ORG_ID
from src.services.config_services import ConfigService


class TestConfigServices(unittest.TestCase):
    @patch("src.services.config_services.get_profile_data", side_effect=lambda: json.loads(json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2"})))
    @patch("src.services.config_services.ConfigService.fetch_service_token")
    def test_config_fetch_service_token(self,m_profile, m_st):
        scanner_service = ConfigService(vault_path="", service_user_uuid="")
        scanner_service._org_db_id="abc"
        scanner_service.fetch_service_token("")
        m_st.assert_called()
        m_profile.assert_called()

    @patch("src.services.config_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2"})))
    @patch("src.services.config_services.ConfigService.fetch_service_token")
    def test_config_fetch_service_token_case2(self, m_profile, m_st):
        os.environ["VAULT_PROFILE"] = "dummy"
        scanner_service = ConfigService(vault_path="", service_user_uuid="")
        documents = scanner_service.fetch_service_token("fr-FR")
        m_st.assert_called()
        m_profile.assert_called()
        self.assertIsNotNone(documents)
