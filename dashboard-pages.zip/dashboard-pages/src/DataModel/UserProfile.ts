// export const getLoggedInUserDetailsJSON = {
//   "statusCode": 200,
//   "message": "User Found",
//   "result": {
//     "userId": "30763547",
//     "userName": "Vijay, Sriramadas",
//     "loginId": "SABICCORP\\30763547",
//     //"roleName": "Plant User",
//     "roleName": "Super Admin",
//     "userLocation": "Jubail",
//     "photo": null,
//     "phoneNumber": "+917386424444",
//     "emailId": "VijayS@SABIC.com",
//     "jwtToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJhMzIxYjIzOS00ZWIyLTQ4OWItOTMxOC05OTA3NWQwZTMxYzciLCJJZCI6IjMwNzYxOTMzIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZWlkZW50aWZpZXIiOiJTaGFoLCBBYmhheSIsIkVtYWlsSWQiOiJTaGFoQWJAU0FCSUMuY29tXlNoYWgsIEFiaGF5IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiU3VwZXIgQWRtaW4iLCJleHAiOjE2ODkzMjg0OTksImlzcyI6IkFIQ1dlYkRhc2hib2FyZCIsImF1ZCI6IkFIQ1dlYkRhc2hib2FyZCJ9.Etp_Nzz042ajFyC203WbQ5wY_TC4CBI-5PB0aB3aMfI",
//     "alertCount": 0,
//     "regionId": 5,
//     "regionName": "Middle East Africa",
//     "affiliateId": 4,
//     "affiliateName": "YANPET",
//     "plantId": 18,
//     "plantName": "POLY2",
//     "onePlantUser": 0
//   }
// }

export const getLoggedInUserDetailsJSON = {
  "statusCode": 200,
  "message": "User Found",
  "result": {
    "jwtToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI2NDgzOGE3ZC1mM2Y2LTRmNWEtODEzMy1mYzFmMTk4MDcwYzciLCJJZCI6IlcrUHp6VE9ERGI1cEF6bHJwRUl0VGc9PSIsIlVzZXJuYW1lIjoieUx2UzhabXFGYmhXYzcyWUVtSWtVdz09IiwiRW1haWxJZCI6ImJWK0JSTU1aL01CZGc3djVSYXhweXJnNElIbWpJbEwwZXZIbHZ2SThTUFU9IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiU3VwZXIgQWRtaW4iLCJJUEFkZHJlc3MiOiJ3dFpHNmJtd2M1eGRuRERjOVlhS1d3PT0iLCJleHAiOjE2OTA5NTc1NjUsImlzcyI6IkFIQ1dlYkRhc2hib2FyZCIsImF1ZCI6IkFIQ1dlYkRhc2hib2FyZCJ9.h-jm-yu3xni9S0TiCBPSDbwkB6t0EGdehpVjTLGubdg",
    "alertCount": 10,
    "regionId": 5,
    "regionName": "Middle East Africa",
    "affiliateId": 4,
    "affiliateName": "YANPET",
    "plantId": 18,
    "plantName": "POLY2",
    "onePlantUser": 0,
    "oneAffiliateUser": 0
  }
}


// {
//   "statusCode": 200,
//     "message": "User Found",
//       "result": {
//     "jwtToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI1NDEwYmMyNi04OTZmLTQ1ZTMtYWZiZC1lNjVhZDllYWI5Y2IiLCJJZCI6IjMwNzYzNTQ2IiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZWlkZW50aWZpZXIiOiJIaXJlbWF0aCwgQW1hcmVzaCIsIkVtYWlsSWQiOiJIaXJlbWF0aEFAU0FCSUMuY29tIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiUGxhbnQgVXNlciIsImV4cCI6MTY4OTIzMDk4OCwiaXNzIjoiQUhDV2ViRGFzaGJvYXJkIiwiYXVkIjoiQUhDV2ViRGFzaGJvYXJkIn0.JTWjzoUAJ6t_j6-3XxIoyOFcyDkb4zrBVMMFgrMpEe4",
//       "alertCount": 0,
//         "regionId": 0,
// "regionId": 5,
//   "regionName": "Middle East Africa",
//     "affiliateId": 4,
//       "affiliateName": "YANPET",
//         "plantId": 18,
//           "plantName": "POLY2",
//             "onePlantUser": 0
//   }
// }
