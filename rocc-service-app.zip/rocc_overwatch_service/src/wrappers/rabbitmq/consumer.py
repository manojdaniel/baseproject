"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import pika

from tenacity import retry
from tenacity.retry import retry_if_exception_type
from tenacity.stop import stop_after_attempt
from tenacity.wait import wait_fixed, wait_random
from pika.exceptions import AMQPConnectionError, AMQPChannelError, ConnectionClosedByBroker, StreamLostError

from src.constants.constants import RABBIT_RETRY_DELAY, RABBIT_RETRY_MAX_JITTER, RABBIT_RETRY_MAX_TRIES
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.utility.retry import get_retrying_options
from src.wrappers.rabbitmq.rabbitmq_utility import RABBITMQ_CONNECTION_ATTEMPT, RABBITMQ_CONNECTION_HEARTBEAT, check_if_queue_should_auto_delete

"""
Usage:
    server = Consumer(ConsumerConfig(host="localhost", queue=BULK_UPLOAD_QUEUE))
    server.listener()
"""

LOG = create_logger("Consumer")


class ConsumerConfig():
    """
    :param host: RabbitMq hostname/IP
    :param queue: queue name
    :param callback: Function reference to be called on getting message
    :return None
    """

    def __init__(self, host, queue, exchange, routing_key, callback):
        self.host = host
        self.queue = queue
        self.exchange = exchange
        self.routing_key = routing_key
        self.callback = callback


class Consumer():
    _max_tries, _delay, _max_jitter = get_retrying_options([RABBIT_RETRY_MAX_TRIES, RABBIT_RETRY_DELAY, RABBIT_RETRY_MAX_JITTER])

    def __init__(self, configs):
        self.configs = configs
        self._connection = None
        self._channel = None

    def initialize_channel(self):
        try:
            LOG.info("Initializing RabbitMQ connections setup")
            params = f"{self.configs.host}?connection_attempts={RABBITMQ_CONNECTION_ATTEMPT}&heartbeat={RABBITMQ_CONNECTION_HEARTBEAT}"
            self._connection = pika.BlockingConnection(pika.URLParameters(params))
            self._channel = self._connection.channel()
            self._channel.exchange_declare(exchange=self.configs.exchange,
                                           exchange_type="direct",
                                           auto_delete=check_if_queue_should_auto_delete(),
                                           durable=True)
            self._channel.queue_declare(queue=self.configs.queue,
                                        auto_delete=check_if_queue_should_auto_delete())
            self._channel.queue_bind(queue=self.configs.queue,
                                     exchange=self.configs.exchange,
                                     routing_key=self.configs.routing_key)
        except Exception as ex:
            LOG.exception(f"RabbitMQ setup failed while declaring queue with: {ex}")
            raise RoccException(title="RabbitMQ setup failed", payload="Exception occurred while setting up RabbitMQ connection") from ex

    @retry(retry=retry_if_exception_type(AMQPConnectionError), stop=stop_after_attempt(_max_tries), wait=wait_fixed(_delay) + wait_random(0, _max_jitter))
    def listener(self, attempt=0):
        try:
            self.initialize_channel()
            LOG.info("Started consuming message over channel.")
            self._channel.basic_consume(queue=self.configs.queue,
                                        auto_ack=True,
                                        on_message_callback=self.configs.callback)

            LOG.info(f" [*] Consumer started & listening on Queue: {self.configs.queue}")
            LOG.info(" [*] Waiting for messages ...")
            self._channel.start_consuming()
            return None
        except ConnectionClosedByBroker as ex:
            LOG.exception(f"RabbitMQ connection dropped - ConnectionClosedByBroker - Consumer connection threw an error: {ex}")
            return self.retry_listener(attempt)
        except StreamLostError as ex:
            LOG.exception(f"RabbitMQ connection dropped - StreamLostError - Consumer connection threw an error: {ex}")
            return self.retry_listener(attempt)
        except AMQPChannelError as ex:
            LOG.exception(f"RabbitMQ connection dropped - AMQPChannelError - Consumer connection threw an error: {ex}")
            raise RoccException(title="RabbitMQ connection dropped", payload="Exception occurred in RabbitMQ channel") from ex
        except AMQPConnectionError as ex:
            LOG.exception(f"RabbitMQ connection dropped - AMQPConnectionError - Consumer connection threw an error: {ex}")
            LOG.info(f"""Consumer connection failed. Retrying. (Attempt #{self.listener.retry.statistics["attempt_number"]} of {self._max_tries})""")
            raise ex
        except Exception as ex:
            LOG.exception(f"RabbitMQ connection dropped - Consumer threw an error while consuming: {ex}")
            return self.retry_listener(attempt)

    def retry_listener(self, attempt):
        if attempt <= self._max_tries:
            attempt += 1
            self.close_connection()
            LOG.warn(f"Retrying to establish RabbitMQ connection; attempt number: {attempt}")
            return self.listener(attempt)
        else:
            LOG.error(f"Establishing of RabbitMQ connection failed continously for {self._max_tries} attempts")
            return None

    def check_and_attach_if_consumers_are_not_bound(self):
        if self.check_if_consumers_are_not_bound_to_channel():
            LOG.error("Since, RabbitMQ connection was not there, re-attaching")
            self.listener()

    def close_connection(self):
        if self._connection is not None:
            LOG.warn("Closing existing RabbitMQ connection")
            self._connection.close()
            self._connection = None
            self._channel = None

    def check_if_consumers_are_not_bound_to_channel(self):
        return len(self._channel.consumer_tags) == 0 if self._channel is not None else 0
