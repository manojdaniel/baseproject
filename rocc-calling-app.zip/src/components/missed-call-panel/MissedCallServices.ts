/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo } from "@rocc/rocc-client-services"
import { getService, postService, putService } from "../../common/helpers/apiUtility"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { API_VERSION, APPLICATION_JSON, CONTENT_TYPE, DEFAULT_API_VERSION } from "../../constants/constants"
import { MISSED_CALL_EP } from "../../constants/endpoints"

export const getMissedCallsService = async (url: string, userId: string, accessToken: string) => {
    try {
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
            Authorization: accessToken,
            [API_VERSION]: DEFAULT_API_VERSION,
        }
        const response = await getService({ headers, url: `${url}${MISSED_CALL_EP}${userId}` })
        return response.data
    } catch (error) {
        errorLogger(`Failed while fetching missed calls for user: ${userId} with error: ${errorParser(error)}`)
    }
    return undefined
}

export const postMissedCallService =
    async (currentUser: IUserInfo, url: string, callContextId: string, callee: string, caller: string, seen: boolean = false) => {
        try {
            const { accessToken, uuid } = currentUser
            const headers = {
                [CONTENT_TYPE]: APPLICATION_JSON,
                Authorization: accessToken,
                [API_VERSION]: DEFAULT_API_VERSION,
            }
            const data = {
                callContextId, callee, caller, seen, isCaller: caller === uuid,
            }
            await postService({ data, headers, url: `${url}${MISSED_CALL_EP}` })
            infoLogger(`${callee} missed a call from ${caller}`)
        } catch (error) {
            errorLogger(`Failed to post missed call between caller: ${caller} & callee: ${callee} with error: ${errorParser(error)}`)
        }
    }

export const clearBadgeCountService = async (callContextId: string[], userId: string, accessToken: string, seen: boolean, url: string) => {
    try {
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
            Authorization: accessToken,
            [API_VERSION]: DEFAULT_API_VERSION,
        }
        const data = {
            callContextId, seen, userId,
        }
        const response = await putService({ url: `${url}${MISSED_CALL_EP}`, data, headers })
        return response && response.status === 200
    } catch (error) {
        errorLogger(`Failed to update missed call count for user: ${userId} with error: ${errorParser(error)}`)
        return false
    }
}
