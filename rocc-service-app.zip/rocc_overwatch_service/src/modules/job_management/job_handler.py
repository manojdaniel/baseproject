"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from abc import ABC, abstractmethod


class JobHandler(ABC):
    @abstractmethod
    def start_job(self, payload):
        """ 
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
            a. Task 1
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps
            b. Task 2
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps
            .
            .
            n. Task n
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps

        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        pass

    @abstractmethod
    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        pass

    @abstractmethod
    def fetch_transaction_from_db(self):
        """Fetch corresponding transaction from transaction table"""
        pass

    @abstractmethod
    def update_transaction_in_db_wrt_job(self):
        """Update corresponding transaction from transaction table"""
        pass

    @abstractmethod
    def execute_tasks(self, tasks):
        """
        Initiate execution of tasks in order
            a. Task 1
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps
            b. Task 2
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps
            .
            .
            n. Task n
                If Complete -> Update Transaction table with right status
                If Failure  -> Update Transaction table with right status
                            -> Trigger Failure handling steps
        """
        pass

    @abstractmethod
    def post_message(self, payload):
        """
        1. After completion of all tasks in the Job send a RabbitMQ message
        """
        pass

    @abstractmethod
    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """
        pass
