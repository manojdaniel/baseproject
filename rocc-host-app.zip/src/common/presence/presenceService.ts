/*
 * Created on Thu Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { EIdlePermissionState, EResponse, IUserInfo } from "@rocc/rocc-client-services"
import { errorParser } from "@rocc/rocc-logging-module"
import { APPLICATION_JSON, CONTENT_TYPE, AUTHORIZATION, HTTP_STATUS, ACCEPT, DEFAULT_API_VERSION, CHAT, subscriptionErrorMessages, API_VERSION, TABID, DEFAULT_SIGNALING_REGION, DEFAULT_EDGE_LOCATION, API_VERSION_1_1_0, USER_AWAY_TIMEOUT } from "../../constants/constants"
import { COMMUNICATION_PRESENCE__STATUS_EP, COMMUNICATION_TOKEN_EP, REGION_CONFIG_URI } from "../../constants/endpoints"
import { getService, postService, putService } from "../../utility/api/apiUtility"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import { getSubscriptionsTransformer } from "./transformer"
import { IPresenceMap } from "./types"
import { Dispatch } from "redux"
import { updateCurrentUserPresence } from "../../redux/actions/userAction"

export const fetchCommunicationClientDetails = async (url: string, token: string, userId: string) => {
    let tokenDetails = { communicationToken: "", channelSid: "" }
    let status = EResponse.ERROR
    try {
        const params = {
            url: `${url}${COMMUNICATION_TOKEN_EP}`,
            headers: {
                [ACCEPT]: APPLICATION_JSON,
                [CONTENT_TYPE]: APPLICATION_JSON,
                [AUTHORIZATION]: token,
                [API_VERSION]: DEFAULT_API_VERSION
            },
            body: {
                userId,
                tokenType: CHAT
            }
        }
        const response = await postService(params)
        if (HTTP_STATUS.OK === response.status) {
            tokenDetails = {
                communicationToken: response.data.twillioAccessToken,
                channelSid: response.data.channelSid,
            }
            status = EResponse.SUCCESS
            return { status, tokenDetails }
        }
    } catch (error) {
        errorLogger(`Twilio token failed with error: ${errorParser(error)}`)
    }
    return { status, tokenDetails }
}

export const updatePresenceService = async (currentUser: IUserInfo, presenceType: EUserPresence, communicationServerUrl: string, userId: string, loggedInLocation: string | undefined, isInit: boolean = false, isLoggedInLocationUpdated: boolean = false) => {
    try {
        const { accessToken, sessionId, status, uuid } = currentUser
        if (status !== presenceType || isInit || uuid !== userId || isLoggedInLocationUpdated) {

            const headers = getHeaders(accessToken, API_VERSION_1_1_0)
            const presenceSessionId = `${sessionId}_${sessionStorage.getItem(TABID)}`
            const body = { presenceType, userId, loggedInLocation, sessionId: presenceSessionId }
            const response = await postService({ headers, body, url: `${communicationServerUrl}${COMMUNICATION_PRESENCE__STATUS_EP}` })
            if (response && HTTP_STATUS.OK === response.status) {
                infoLogger(`${userId}'s presence updated to ${presenceType}`)
            }
        } else {
            infoLogger(`Skipping duplicate presence update for user: ${uuid} with presence: ${presenceType}`)
        }
    } catch (error) {
        errorLogger(`Failed to update ${userId} 's presence with error: ${errorParser(error)}`)
    }
}

export const getSubscriptionsService = async (accessToken: string, uuid: string, subPresenceUrl: string) => {
    const params = {
        headers: getHeaders(accessToken),
        url: `${subPresenceUrl}/${uuid}`,
    }
    let subscriptionsMap: IPresenceMap[] = []
    try {
        const response = await getService(params)
        subscriptionsMap = getSubscriptionsTransformer(response)
    } catch (error) {
        errorLogger(`Error while fetching presence subscriptions: ${errorParser(error)}`)
    }
    return subscriptionsMap
}

export const updateSubscriptionsService = async (accessToken: string, uuid: string, subscribeUUID: string[], unSubscribeUUID: string[], subPresenceUrl: string) => {
    const body = {
        add_identities: subscribeUUID,
        remove_identities: unSubscribeUUID,
    }
    const params = {
        headers: getHeaders(accessToken),
        url: `${subPresenceUrl}/${uuid}`,
        body,
    }
    let subscriptionsMap: IPresenceMap[] = []
    let failedSubscriptions: string[] = []
    try {
        const response = await putService(params)
        subscriptionsMap = getSubscriptionsTransformer(response)
    } catch (error: any) {
        if (error.response.status === HTTP_STATUS.FORBIDDEN && error.response.data.defaultMessage === subscriptionErrorMessages.orgMismatchErrorMessage) {
            failedSubscriptions = subscribeUUID
        }
        errorLogger(`Error while updating presence subscriptions: ${errorParser(error)}`)
    }
    return { subscriptionsMap, failedSubscriptions }
}

export const fetchCommunicationConfig = async (countryIsoCode: string, region: string, communicationUrl: string, accessToken: string) => {
    try {
        const params = {
            url: `${communicationUrl}${REGION_CONFIG_URI}?countryIsoCode=${countryIsoCode}&region=${region}`,
            headers: getHeaders(accessToken)
        }
        const response = await getService(params)
        if (response.status === 200 && response.data instanceof Array && response.data.length) {
            const { signalingRegion, edgeLocation } = response.data[0]
            return { signalingRegion, edgeLocation }
        }
    } catch (error) {
        errorLogger(`Exception occurred while fetching communication service configurations : ${error}`)
    }
    return { signalingRegion: DEFAULT_SIGNALING_REGION, edgeLocation: DEFAULT_EDGE_LOCATION }
}

const getHeaders = (accessToken: string, apiVersion?: string) => {
    return {
        [CONTENT_TYPE]: APPLICATION_JSON,
        [AUTHORIZATION]: accessToken,
        [API_VERSION]: apiVersion ?? DEFAULT_API_VERSION
    }
}

const handlePresence = (dispatch: Dispatch<any>, presence: EUserPresence) => {
    dispatch(updateCurrentUserPresence(presence))
}

export const presenceAvailable = async (state: string, dispatch: Dispatch<any>) => {
    // Need to request permission first.
    if (state === EIdlePermissionState.GRANTED) {
        let controller = null
        let userState = null
        let screenState = null
        try {
            controller = new AbortController()
            const signal = controller.signal
            const idleDetector = new (window as any).IdleDetector()
            idleDetector.addEventListener("change", () => {
                userState = idleDetector.userState
                screenState = idleDetector.screenState
                dispatchingUserPresence(userState, screenState, dispatch)
            })
            await idleDetector.start({
                threshold: USER_AWAY_TIMEOUT,
                signal,
            })
        } catch (err) {
            controller?.abort()
        }
    }
}

const dispatchingUserPresence = (userState: any, screenState: any, dispatch: Dispatch<any>) => {
    if (userState === "idle" && screenState === "unlocked") {
        handlePresence(dispatch, EUserPresence.AWAY)
    } else if (userState === "idle" && screenState === "locked") {
        handlePresence(dispatch, EUserPresence.OFFLINE)
    } else if (userState === "active" && screenState === "locked") {
        handlePresence(dispatch, EUserPresence.OFFLINE)
    } else if (userState === "active" && screenState === "unlocked") {
        handlePresence(dispatch, EUserPresence.AVAILABLE)
    }
}
