/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ECallType, EOutGoingCallStatus, getDetailsByUUID, IContactInfo, IOutgoingCallDetails } from "@rocc/rocc-client-services"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { TIMEOUT_30000 } from "../../../../../constants/constants"
import { setCallMessage, setCallRingStatus, setOutgoingCallDetails, setVideoCallStatus, updateCallTimeout } from "../../../../../redux/actions/callActions"
import { DEFAULT_CALL_MESSAGE } from "../../../../../redux/reducers/callReducer"
import { upsertCallStatus } from "../../../../helpers/callUtility"
import { getCustomrReducerFromGlobalStore, getUserReducerFromGlobalStore } from "../../../../helpers/helpers"
import { onCallTimeout } from "../MessageHelper"
import { TRACKING_VALUES } from "../types"

const { CALLING } = ECallStatus

interface IOutgoingCall {
    contextDetails: any
    participant: IContactInfo
    dispatch: Dispatch<any>
}

export const outgoingCall = async (props: IOutgoingCall) => {
    const { contextDetails, dispatch, participant } = props
    const { currentUser, rooms, contacts } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES
    dispatch(setCallMessage(DEFAULT_CALL_MESSAGE))
    const { data } = contextDetails
    const { contextId } = data
    dispatch(setCallRingStatus(true))
    dispatch(setVideoCallStatus(upsertCallStatus(contextId, CALLING).filter(callStatus => callStatus.contextId !== "")))
    if (data.participants.length) {
        let callee = participant
        if (!callee || callee.uuid === "") {
            callee = await getDetailsByUUID(data.participants[0].primaryUuid, contacts, rooms)
        }
        const outgoingCall: IOutgoingCallDetails = { callType: ECallType.WEB_TO_WEB, contextId, participant: callee, status: EOutGoingCallStatus.CALLING, requester: data.requester }
        dispatch(setOutgoingCallDetails(outgoingCall))
        sendLogsToAzure({ contextData: { component, event: `${event} Outgoing Call`, Call_From: currentUser.uuid, Call_to: callee.uuid, contextId } })
        const callTimeoutID = setTimeout(() => onCallTimeout({
            isCallee: false, caller: currentUser, callee,
            lastCallStatus: CALLING, contextId, dispatch,
        }), TIMEOUT_30000)
        dispatch(updateCallTimeout({ contextId, timeoutId: callTimeoutID }, true))
        return true
    }
    return false
}

const initialiseReduxValues = () => {
    const { contacts, currentUser } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    return { contacts, rooms, currentUser }
}
