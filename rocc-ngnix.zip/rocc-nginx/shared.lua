local cjson = require "cjson"
local vcap_services = cjson.decode(os.getenv("VCAP_SERVICES"))
local redis_credentials = vcap_services["hsdp-redis-db"][1].credentials;
local redis_hostname = redis_credentials.hostname
local redis_sentinel_port = redis_credentials.sentinel_port
local redis_port = redis_credentials.port
local redis_master = redis_credentials.master_name
local redis_password = redis_credentials.password
local red

if redis_master == nil then
	local redis = require "resty.redis"
	red = redis:new()
	red:set_timeouts(1000, 1000, 1000) -- 1 sec
	local ok, err = red:connect(redis_hostname, redis_port)
		if not ok then
		ngx.say("failed to connect: ", err)
        return
		end

	local res, err = red:auth(redis_password)
else
	local rc = require("resty.redis.connector").new({
    	connect_timeout = 1000,
    	send_timeout = 1000,
    	read_timeout = 1000,
	})
		red, err = rc:connect({
    	url = "sentinel://" .. redis_master .. ":2",
    	sentinels = {
        	{ host = redis_hostname, port = redis_sentinel_port },
    	},
    	password = redis_password,
    	sentinel_password = redis_password,
	})
	if not red then
		ngx.say("failed to connect: ", err)
       	return
	end
end

local org_ctx_header=ngx.req.get_headers()["org_ctxt_header"]
if org_ctx_header == nil then
	local url=ngx.var.http_host
	local org_name=string.match(url, "(.-)-")
	local nginx_url = string.match(url, "(.*)-")
	local res, err = red:get(org_name)
    if not res then
    	ngx.say("failed to get orgDetails: ", err)
        return
    end
    
	if res == ngx.null then
			if string.find(url, "rocc%-nginx") then
				ngx.req.set_header("org_ctxt_header", "")
			else
        		ngx.say("OrgDetails not found.", err)
        		return
        	end
	else
		ngx.req.set_header("org_ctxt_header", "{\"Org-Id\":".. "\"" .. res .. "\"}")
        end
end