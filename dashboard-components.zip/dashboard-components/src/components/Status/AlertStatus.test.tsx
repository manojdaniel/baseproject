import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import AlertStatus from "./AlertStatus";

const dataObject = [
	{
		affiliateCount: 16,
		assetCount: 405,
		healthIndex: "32% ",
		pmCompliance: "1% ",
		sparesAvailability: "NA",
		active: 1057,
		overdueInvestigation: 997,
		underInvestigation: 60,
	},
];
const healthIndexObject = [
	{
		AssetSapId: 310059910,
		AssetHealthIndex: 0,
		AssetTrend: 0,
		PlantHealth: 28,
		PlantTrend: 1,
		AssetId: "2K-3101",
		PlantId: 18,
		AssetName: "Cycle Gas Compressor 4",
	},
];
it("Alert Status component should render the correct no. of images", () => {
	render(
		<AlertStatus
			data={dataObject}
			page="ALERT"
			healthIndex={healthIndexObject}
		/>
	);
	expect(screen.queryAllByRole("img")).toHaveLength(6);
});

it("should render the correct tile names", () => {
	render(
		<AlertStatus
			data={dataObject}
			page="ALERT"
			healthIndex={healthIndexObject}
		/>
	);
	// const linkElement = ;
	expect(screen.queryByText(/CLOSED/i)).toBeInTheDocument();
});

it("Alert Status component should not render in case of diffrent page", () => {
	render(
		<AlertStatus
			data={dataObject}
			page="PLANT"
			healthIndex={healthIndexObject}
		/>
	);
	expect(screen.queryByText(/CLOSED/i)).toBeNull();
});

it("component should not render in case of no data", () => {
	render(
		<AlertStatus data={[]} page="ALERT" healthIndex={healthIndexObject} />
	);
	expect(screen.queryByText(/CLOSED/i)).toBeNull();
});
