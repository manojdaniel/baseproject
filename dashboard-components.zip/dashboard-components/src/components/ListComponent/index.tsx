import React from "react";
import tableUparrowBlue from "../../assets/images/table-uparrow-blue.svg";
import tableUparrowRed from "../../assets/images/table-uparrow-red.svg";
import "./ListComponent.scss";
import tableDownArrowBlue from "../../assets/images/table-downarrow_blue.svg";
import tableDownArrowRed from "../../assets/images/table-downarrow_red.svg";

interface Props {
	handleOnClick: any;
	item: any;
	title: string;
	navigateActiveUIOIAllPlant?: any
	navigatePMCompliance?: any
}

const ListComponent = ({ handleOnClick, item, title, navigateActiveUIOIAllPlant, navigatePMCompliance }: Props) => {
	return (
		<>
			<div className="allaffiliate-row" onClick={() => handleOnClick(item)}>
				{title === "AFFILIATE" ?
					<>
						{item.image !== null ?
							<div className="all-plantimg">
								<img src={item.image} />
							</div>
							:
							<div className="all-plantname">{item.name}</div>
						}
					</>

					: (
						<div className="all-plantname">{item.name}</div>
					)}

				<div>
					<span>HEALTH INDEX</span>
					<span>
						<i>
							<img
								src={
									item.healthIndexTrend === true
										? tableUparrowBlue
										: tableDownArrowBlue
								}
							/>
						</i>
						<b>{item.healthIndex}%</b>
					</span>
				</div>
				<div onClick={(e) => title === "AFFILIATE" ? "" : navigatePMCompliance(item, e)}>
					<span>PM COMPLIANCE</span>
					<span>{item.pmCompliance}%</span>
				</div>
				<div onClick={(e) => title === "AFFILIATE" ? "" : navigateActiveUIOIAllPlant("Active", item, e)}>
					<span>ACTIVE ALERTS</span>
					<span className="redcolor">{item.active}</span>
				</div>
				<div onClick={(e) => title === "AFFILIATE" ? "" : navigateActiveUIOIAllPlant("Work in Progress", item, e)}>
					<span>UNDER INVESTIGATION</span>
					<span>{item.underInvestigation}</span>
				</div>
				<div onClick={(e) => title === "AFFILIATE" ? "" : navigateActiveUIOIAllPlant("Overdue", item, e)}>
					<span>OVERDUE INVESTIGATION</span>
					<span>
						<i>
							<img
								src={
									item.overdueTrend === 1 ? tableUparrowRed : tableDownArrowRed
								}
							/>
						</i>
						<b className="redcolor">{item.overdue}</b>
					</span>
				</div>
			</div>
		</>
	);
};

export default ListComponent;
