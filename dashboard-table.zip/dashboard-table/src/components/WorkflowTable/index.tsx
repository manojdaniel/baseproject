import React from "react";
import { Table } from "antd";

interface Props {
	data: any[];
	handleUpdate: any;
	radio: boolean;
	loading?: any;
}

const WorkflowTable = ({ data, handleUpdate, radio, loading }: Props) => {
	const rowSelection = {
		onChange: (selectedRowKeys, selectedRows) => {
			let selectedRowData = selectedRows[0];
			handleUpdate(selectedRowData);
			//   alert(selectedRowData.employeeID+'////'+ selectedRowData.employeeName+'////'+ selectedRowData.employeeEmail)
		},
	};

	const columns = [
		{
			title: "Employee ID",
			dataIndex: "empID",
			key: "empID",
			width: "20%",
		},
		{
			title: "Employee Name",
			dataIndex: "userFullName",
			key: "userFullName",
			width: "20%",
		},
		{
			title: "Job Title",
			dataIndex: "jobTitle",
			key: "jobTitle",
			width: "20%",
		},
		{
			title: "Email Id",
			dataIndex: "userEmail",
			key: "userEmail",
			width: "20%",
		},
		{
			title: "Department",
			dataIndex: "deptFullDesc",
			key: "deptFullDesc",
			width: "20%",
		},
	];

	return (
		<div>
			<Table
				loading={loading}
				columns={columns}
				dataSource={data}
				pagination={false}
				rowSelection={
					radio
						? {
								type: "radio",
								...rowSelection,
						  }
						: undefined
				}
				scroll={{ x: true, y: 200 }}
				rowKey="UserID"
			/>
		</div>
	);
};

export default WorkflowTable;
