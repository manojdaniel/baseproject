"""
 Created on Mon Sep 21 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask_restful import Resource, reqparse
from flask import request

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION


LOG = create_logger("Site controller")


class Site(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("identifier", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("customer_identifier", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("site_name", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("address", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("city", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("state", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("postal_code", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("frontdesk", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("scheduler", type=str, required=True, help="This field cannot be left blank!")

    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for Site onboarding is: {api_version}")
            """ TODO: Need to evaluate the token """
        except KeyError:
            return {"message": f"{API_VERSION} header is needed to process this request"}, 400
        body = Site.parser.parse_args()
        LOG.info(f"Hospital/DIC - Site: {body} onboarding initiated")
        """ TODO: Add new site process initiation """
        return {"message": "New site is added"}, 201
        
    
class SiteOffboard(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("site_identifier", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("customer_identifier", type=str, required=True, help="This field cannot be left blank!")

    def delete(self):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for Site offboarding is: {api_version}")
            """ TODO: Need to evaluate the token """
        except KeyError:
            return {"message": f"'{API_VERSION}' header is needed to process this request"}, 400
        body = SiteOffboard.parser.parse_args()
        LOG.info(f"Hospital/DIC - Site: {body} offboarding initiated")
        """ TODO: Site offboarding process initiation """
        return {"message": "Site offboarding is initiated", "job_identifier": "1234"}, 202