/*
 * Created on Thu Sept 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { AccordionCallList, AddParticipant } from "@rocc/rocc-calling-components"
import { FeatureFlagHelper, IContactInfo, IParentStore, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider, SearchBar } from "@rocc/rocc-global-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { convertContactToDisplayList, getSiteName, getRoleName, isRenderableComponent, checkIfMultiEditWithoutParkResumeFeatureEnabled } from "../../common/helpers/helpers"
import { IAudioVideoCallingProps } from "../../common/modules/av/AudioVideoCalling"
import { APP_NAME, DEVICE, PARENT_STORE, RINGING } from "../../constants/constants"
import { IStore } from "../../redux/interfaces/types"
import globalStore from "../../redux/store/globalStore"
import en from "../../resources/translations/en-US"
import { addUserToCall } from "../../services/callServices"
import styles from "./CallParticipants.scss"

const CallParticipants = (props: IAudioVideoCallingProps) => {

    const { activeCall, connectedCallProps } = props
    const { currentUser, featureFlags, permissions } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser,
        featureFlags: state.externalReducer.featureFlags,
        permissions: state.externalReducer.permissions,
    }))

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const [contacts, setContacts] = useState([] as IContactInfo[])
    const [activeIndex, setActiveIndex] = useState(0)
    const [participants, setParticipants] = useState([] as any[])
    const [availableContacts, setAvailableContacts] = useState([] as any[])
    const [isMpcEnabled, setIsMpcEnabled] = useState(true)
    const [searchValue, setSearchValue] = useState("")
    const activeCallRef = useRef(activeCall)
    const maxParticipantActionsValue = useRef({ length: 0, index: 0 })
    const maxContactActionsValue = useRef({ length: 0, index: 0 })

    useEffect(() => { activeCallRef.current = activeCall }, [activeCall])
    useEffect(() => {
        const subscribeToParentStore = () => {
            const gState = globalStore.GetGlobalState()
            if (gState[PARENT_STORE]) {
                /** Fetch Initial State */
                setContacts(gState[PARENT_STORE].userReducer.contacts)
                globalStore.SubscribeToPartnerState(APP_NAME, PARENT_STORE, (changedState: IParentStore) => {
                    setContacts(changedState.userReducer.contacts)
                })
            }
        }
        subscribeToParentStore()

    }, [])

    const currentlyInTheCallActions = (contact: IContactInfo, isCurrentUser: boolean, index: number) => {
        const actions = []
        if (!isCurrentUser) {
            if (contact.callStatus === RINGING) {
                const callingMessage = <span key={1}>
                    {intl.formatMessage({ id: "content.participant.calling", defaultMessage: en["content.participant.calling"] })}
                </span>
                actions.push(callingMessage)
            } else {
                if (connectedCallProps?.participantCards) {
                    connectedCallProps.participantCards.components.forEach(component => {
                        const participantAction = component(contact.uuid)
                        if (isRenderableComponent(participantAction)) {
                            actions.push(participantAction)
                        } else {
                            infoLogger("Participant Action is not JSX Element")
                        }
                    })
                }
            }
        }

        if (!actions.length) {
            actions.push(<></>)
        }
        if (maxParticipantActionsValue.current.length < actions.length) {
            maxParticipantActionsValue.current = { length: actions.length, index }
        }
        return actions
    }

    const onAddParticipantClick = (contact: IContactInfo) => {
        addUserToCall(activeCallRef.current, contact, dispatch)
        sendLogsToAzure({ contextData: { component: "CallParticipants", event: `Add : user in call`, Event_by: currentUser.uuid } })
    }

    const checkAddParticipantAction = (contact: IContactInfo) => {
        return ((FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.MPC) && permissions.CALL_ADD_PARTICIPANT) ?
            <AddParticipant key={"addParticipant"} onClick={() => onAddParticipantClick(contact)} iconSize={"small"} /> : <></>
        )
    }

    const addParticipantCallAction = (contact: IContactInfo, index: number) => {
        const actions = [checkAddParticipantAction(contact)]
        if (connectedCallProps?.contactCards) {
            connectedCallProps.contactCards.components.forEach(component => {
                const participantAction = component(contact.uuid)
                if (isRenderableComponent(participantAction)) {
                    actions.push(participantAction)
                }
            })
        }
        if (maxContactActionsValue.current.length < actions.length) {
            maxContactActionsValue.current = { length: actions.length, index }
        }
        return actions
    }

    const handleAccordionClick = (newIndexValue: number) => {
        const newIndex = activeIndex === newIndexValue ? -1 : newIndexValue
        setActiveIndex(newIndex)
    }

    const handleSearch = (event: any) => {
        setActiveIndex(1)
        setSearchValue(event.target.value.toLowerCase())
        sendLogsToAzure({ contextData: { component: "CallParticipants", event: `Search : user search`, Event_by: currentUser.uuid } })
    }

    const handleClear = () => {
        setSearchValue("")
        sendLogsToAzure({ contextData: { component: "CallParticipants", event: `Search : clear search`, Event_by: currentUser.uuid } })
    }

    useEffect(() => {
        setIsMpcEnabled(!checkIfMultiEditWithoutParkResumeFeatureEnabled())
    }, [featureFlags])

    useEffect(() => {
        const callParticipants = activeCall.participants
        const { id, uuid, name, secondaryUUID, secondaryName, clinicalRole, description, siteId } = currentUser
        const restContacts: any = []
        let usersInCall: any[] = [
            {
                id: id,
                uuid: secondaryUUID || uuid,
                title: secondaryName || name,
                metaData: getRoleName(clinicalRole),
                description: currentUser.loggedInLocation || getSiteName(description, siteId),
                userActions: () => currentlyInTheCallActions(currentUser, true, 0),
                presence: currentUser.status,
                isCurrentUser: true
            }
        ]

        usersInCall = usersInCall.concat(callParticipants.map((callParticipant, index) => {
            if (callParticipant.clinicalRole == DEVICE && !callParticipant.loggedInLocation) {
                callParticipant.loggedInLocation = getSiteName("", callParticipant.siteId)
            }
            return convertContactToDisplayList(callParticipant, () => currentlyInTheCallActions(callParticipant, false, index + 1))
        }))
        if (isMpcEnabled && Array.isArray(contacts)) {
            contacts.forEach((contact, index) => {
                if (callParticipants.filter(participant => [participant.uuid, participant.secondaryUUID].includes(contact.uuid)).length === 0) {
                    restContacts.push(convertContactToDisplayList(contact, () => addParticipantCallAction(contact, index)))
                }
            })
        }
        setParticipants(usersInCall)
        setAvailableContacts(restContacts)
    }, [contacts, activeCall, currentUser])

    const searchedParticipant = availableContacts.filter(contact => contact.title && contact.title.toLowerCase().includes(searchValue.toLowerCase()))
    return (
        <div className={styles.callParticipantsPanel} id={"callParticipantsPanel"}>
            {isMpcEnabled && <div className="ui form">
                <div id="contactListSearch" className={styles.searchBarContainer}>
                    <SearchBar
                        clearButton={true}
                        handleClear={handleClear}
                        handleSearch={(e) => { handleSearch(e) }}
                        placeholder={intl.formatMessage({ id: "content.placeholder.addParticipant", defaultMessage: en["content.placeholder.addParticipant"] })}
                        searchValue={searchValue}
                        showNoResults={false}
                    />
                </div>
            </div>}
            <AccordionCallList
                participants={participants}
                activeStatus={activeIndex === 0}
                title={intl.formatMessage({ id: "content.message.currentlyInTheCall", defaultMessage: en["content.message.currentlyInTheCall"] })}
                handleAccordionClick={() => handleAccordionClick(0)}
                configIndex={maxParticipantActionsValue.current.index}
            />
            {isMpcEnabled && <AccordionCallList
                participants={searchedParticipant}
                activeStatus={activeIndex === 1}
                title={intl.formatMessage({ id: "content.participant.contacts", defaultMessage: en["content.participant.contacts"] })}
                handleAccordionClick={() => handleAccordionClick(1)}
                configIndex={maxContactActionsValue.current.index}
            />}
        </div >
    )
}

export default CallParticipants
