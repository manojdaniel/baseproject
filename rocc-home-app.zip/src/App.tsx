/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect } from "react"
import "@dls-pdv/semantic-ui-foundation/dist/semantic.css"
import { Provider } from "react-redux"
import store, { persistor } from "./redux/store/store"
import { PersistGate } from "redux-persist/integration/react"
import { setupLogger } from "@rocc/rocc-logging-module"
import { defineMessages, IntlProvider } from "react-intl"
import messages from "./resources/translations/messages"
import RoomsLayout from "./components/RoomsLayout"
import { isDev } from "./common/helpers/helpers"
import { EN_LANGUAGE, EN_LOCALE } from "./constants/constants"
import RoomStatusController from "./common/setup/room-status/RoomStatus"

const App = () => {
  const locale = sessionStorage.getItem("locale")
  const language = sessionStorage.getItem("language")
  useEffect(() => {
    setupLogger({ isDev: isDev() })
  }, [])
  const defaultLocale = language || EN_LOCALE
  const defaultMessage = (locale: string) => defineMessages(messages[locale])
  return <>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <IntlProvider
          defaultLocale={defaultLocale}
          locale={defaultLocale}
          messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
        >
          <>
            <RoomStatusController />
            <RoomsLayout />
          </>
        </IntlProvider>
      </PersistGate>
    </Provider>
  </>
}
export default App
