/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import { IConsoleSession } from "@rocc/rocc-client-services"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch } from "react-redux"
import { LocalTrack, Room } from "twilio-video"
import { COLLAPSED, EXPANDED, ROOM_MONITORING_TRACKING } from "../../../common/constants/constants"
import { getCurrentConsoleSession } from "../../../common/helpers/consoleUtility"
import { leaveMediaRoom } from "../../../common/modules/multi-camera/MultiCameraHelper"
import { ILeaveRoom, IMultiCamVideoTrack } from "../../../common/modules/multi-camera/MultiCameraTypes"
import MultiCameraParticipant from "../../../common/modules/multi-camera/participant/MultiCameraParticipant"
import UseCameraController from "../../../common/modules/use-camera-controller/UseCameraController"
import RoomMonitoringCameraView from "../room-monitoring-camera-view/RoomMonitoringCameraView"
import RoomMonitoringFullscreen from "../room-monitoring-fullscreen/RoomMonitoringFullscreen"

interface IRoomMonitoringCameraView {
    maxSupportedCameras: number
    singleRecieverView: boolean
    consoleSession: IConsoleSession
    consoleSessions: IConsoleSession[]
    currentUserUuid: string
    accessToken: string
    isSwitchingConsoleSession: boolean
    setIsSwitchingConsoleSession: (state: boolean) => void
    setShowModal: (state: boolean) => void
    rightSidePanel?: boolean
}

const FILENAME = "RoomMonitoringCameraController.tsx : "

const RoomMonitoringCameraController = ({
    maxSupportedCameras, singleRecieverView, consoleSession, currentUserUuid, accessToken, rightSidePanel, isSwitchingConsoleSession,
    consoleSessions, setIsSwitchingConsoleSession, setShowModal
}: IRoomMonitoringCameraView) => {

    const [activeRoom, setActiveRoom] = useState(undefined as unknown as Room)
    const [previewTracks, setPreviewTracks] = useState([] as LocalTrack[])
    const [videoTracks, setVideoTracks] = useState([] as IMultiCamVideoTrack[])
    const previewTracksRef = useRef(previewTracks)
    const activeRoomRef = useRef(activeRoom)
    const videoTracksRef = useRef(videoTracks)
    const dispatch = useDispatch()
    const [fullscreenState, setFullscreenState] = useState(false)
    let startStream = false
    const [videoStarted, setVideoStarted] = useState(false)
    const { mediaRoomDetails } = consoleSession
    const loggerInitialMessage = `${FILENAME}: For user: ${currentUserUuid} - Console session ${consoleSession.contextId}`

    const { initialiseRoom, initialiseMediaRoom } = UseCameraController({
        previewTracks,
        consoleSession,
        filename: FILENAME,
        accessToken,
        currentUserUuid: currentUserUuid,
        dispatch,
        previewTracksRef,
        setVideoTracks,
        setPreviewTracks,
        setActiveRoom,
        isSyncSession: !singleRecieverView,
        setShowModal,
    })

    const handlefullscreenClick = (trackName: string) => {
        const index = videoTracks.findIndex((videoTrackItem: IMultiCamVideoTrack) => videoTrackItem.videoTrack.name.replace(":", "") === trackName)
        if (index !== -1) {
            infoLogger(`${loggerInitialMessage} - Handling fullscreen for track ${trackName}`)
            videoTracks[index].fullScreen = !fullscreenState
            setVideoTracks([...videoTracks])
            setFullscreenState(!fullscreenState)
            sendLogsToAzure({ contextData: { component: `${ROOM_MONITORING_TRACKING}`, event: `${trackName} ${fullscreenState ? COLLAPSED : EXPANDED}`, Event_by: currentUserUuid } })
        }
    }

    const getFullscreentrack = () => {
        return videoTracks.find((videoTrackItem: IMultiCamVideoTrack) => videoTrackItem.fullScreen)
    }

    useEffect(() => {
        if (videoTracks) {
            videoTracksRef.current = videoTracks
        }
    }, [videoTracks])

    useEffect(() => {
        activeRoomRef.current = activeRoom
    }, [activeRoom])

    useEffect(() => {
        previewTracksRef.current = previewTracks
    }, [previewTracks])

    useEffect(() => {
        return (() => {
            if (activeRoomRef.current && getCurrentConsoleSession(consoleSessions, consoleSession.contextId)) {
                infoLogger(`${loggerInitialMessage} - Disconnecting twillio media room due to component unmount`)
                disconnectMediaRoom()
            }
            startStream = false
        })
    }, [])

    useEffect(() => {
        const { mediaRoomId } = mediaRoomDetails
        if (!activeRoomRef.current && mediaRoomId && !initialiseRoom && !startStream) {
            initialiseMediaRoom()
            startStream = true
        }
    }, [mediaRoomDetails.cameraStreamAvailable, mediaRoomDetails.mediaRoomId, mediaRoomDetails.mediaRoomToken])

    const disconnectMediaRoom = () => {
        const leaveMediaRoomProps: ILeaveRoom = {
            room: activeRoomRef.current,
            dispatch,
            consoleSession,
            setVideoTracks,
            videoTracksRef,
            isSyncConsoleSession: !singleRecieverView,
        }
        leaveMediaRoom(leaveMediaRoomProps)
    }

    useEffect(() => {
        sendLogsToAzure({
            contextData: {
                component: ROOM_MONITORING_TRACKING,
                event: `Started with ${singleRecieverView ? "Single Reciever" : "Multi Reciever"}: ${consoleSession.receiverName}`
            }
        })
    }, [])

    return <>
        {fullscreenState ? <RoomMonitoringFullscreen
            rightSidePanel={rightSidePanel}
            consoleSession={consoleSession}
            videoTrackItem={getFullscreentrack()}
            handlefullscreenClick={handlefullscreenClick}
        />
            : <RoomMonitoringCameraView
                singleRecieverView={singleRecieverView}
                maxSupportedCameras={maxSupportedCameras}
                videoTracks={videoTracks}
                videoStarted={videoStarted}
                setVideoStarted={setVideoStarted}
                handlefullscreenClick={handlefullscreenClick}
                isSwitchingConsoleSession={isSwitchingConsoleSession}
                setIsSwitchingConsoleSession={setIsSwitchingConsoleSession}
                consoleSession={consoleSession}
            />
        }
        <MultiCameraParticipant
            consoleSession={consoleSession}
            activeRoom={activeRoomRef.current}
            setVideoTracks={setVideoTracks}
            videoTracksRef={videoTracksRef}
            onDevice={false}
            setFullscreenState={setFullscreenState}
            isSyncConsoleSession={!singleRecieverView}
        />
    </>
}

export default RoomMonitoringCameraController
