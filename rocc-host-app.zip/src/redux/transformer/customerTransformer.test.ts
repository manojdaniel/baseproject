/*
 * Created on Mon Oct 11 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, ERoomStatus } from "@rocc/rocc-client-services"
import { DEFAULT_CUSTOMER_NAME } from "../../constants/constants"
import { EUserPresence } from "../../types/types"
import { addressHelper, convertContact, fetchCustomerDetailsForAdminTransformer, fetchLocationInfoForCurrentUserTransformer, fetchRoomDetailsForDeviceTransformer, getRoomRelevantForCurrentUserTransformer } from "./customerTransformer"

describe("Unit tests for customer transformer", () => {

    it("should convert front desk contact", () => {
        const dbContactType = "front-desk"
        const contactId = "51622"
        const expectedResult = {
            clinicalRole: EClinicalRole.FRONTDESK, contact_id: "fd51622"
        }
        expect(convertContact(dbContactType, contactId)).toEqual(expectedResult)
    })

    it("should convert scheduler contact", () => {
        const dbContactType = "scheduler-registrar"
        const contactId = "51622"
        const expectedResult = {
            clinicalRole: EClinicalRole.SCHEDULER, contact_id: "sr51622"
        }
        expect(convertContact(dbContactType, contactId)).toEqual(expectedResult)
    })

    it("should convert patient trasnport contact", () => {
        const dbContactType = "patient-transport"
        const contactId = "51622"
        const expectedResult = {
            clinicalRole: EClinicalRole.TRANSPORT, contact_id: "pt51622"
        }
        expect(convertContact(dbContactType, contactId)).toEqual(expectedResult)
    })

    it("fetchCustomerDetailsForAdminTransformer should transform values", () => {
        const data = {
            metasites: [{
                id: 1,
                name: "name",
                metasite: "metasite"
            }]
        }
        expect(fetchCustomerDetailsForAdminTransformer(data).customerMetaData.displayName).toEqual("name")
    })

    it("fetchCustomerDetailsForAdminTransformer should return default values on error", () => {
        const data = {
            metasites: {}
        }
        expect(fetchCustomerDetailsForAdminTransformer(data).customerMetaData.displayName).toEqual(DEFAULT_CUSTOMER_NAME)
    })
    it("address helper should be defined", () => {
        const address = "2 Canal Park, Cambridge, MA - 02141"
        const city = "Cambridge"
        const state = "MA"
        const postal = "02141"
        expect(addressHelper(address, city, state, postal)).toBeDefined()
    })
    it("should fetchRoomDetailsForDeviceTransformer", () => {
        const data = {
            roomsData: [
                {
                    identity: { id: 1, name: "a", uuid: "a" }, locationId: 1, address: "a",
                    modality: "CT", modalityId: "a", favourite: false, phoneNumber: "a", disabled: false, isRoomStarred: true,
                    presenceData: { presence: EUserPresence.AWAY, mapId: "" }, isConnecting: false, loggedInTech: { techUuid: "3", techName: "a" },
                    monitorsCount: 1, roomStatus: ERoomStatus.UNKNOWN,
                },
                {
                    identity: { id: 2, name: "b", uuid: "b" }, locationId: 1, address: "b",
                    modality: "CT", modalityId: "a", favourite: false, phoneNumber: "", disabled: false, isRoomStarred: false,
                    presenceData: { presence: EUserPresence.AVAILABLE, mapId: "" }, isConnecting: false, loggedInTech: { techUuid: "2", techName: "b" },
                    monitorsCount: 1, roomStatus: ERoomStatus.UNKNOWN,
                }
            ]
        }
        const prevRooms = [{
            identity: { id: 3, name: "c", uuid: "c" }, locationId: 1, address: "c",
            modality: "MR", modalityId: "a", favourite: false, phoneNumber: "", disabled: false, isRoomStarred: false,
            presenceData: { presence: EUserPresence.AVAILABLE, mapId: "" }, isConnecting: false, loggedInTech: { techUuid: "1", techName: "c" },
            monitorsCount: 1, roomStatus: ERoomStatus.UNKNOWN,
        }]
        const expectedResult = [
            {
                identity: {
                    id: undefined,
                    name: undefined,
                    uuid: undefined,
                    address: undefined
                },
                locationId: undefined,
                address: undefined,
                modality: "CT",
                modalityId: undefined,
                favourite: false,
                phoneNumber: undefined,
                disabled: false,
                isRoomStarred: false,
                presenceData: { presence: "OFFLINE", mapId: "" },
                isConnecting: false,
                loggedInTech: { techUuid: "", techName: "" },
                monitorsCount: 1,
                roomStatus: ERoomStatus.UNKNOWN,
            },
            {
                identity: {
                    id: undefined,
                    name: undefined,
                    uuid: undefined,
                    address: undefined
                },
                locationId: undefined,
                address: undefined,
                modality: "CT",
                modalityId: undefined,
                favourite: false,
                phoneNumber: undefined,
                disabled: false,
                isRoomStarred: false,
                presenceData: { presence: "OFFLINE", mapId: "" },
                isConnecting: false,
                loggedInTech: { techUuid: "", techName: "" },
                monitorsCount: 1,
                roomStatus: ERoomStatus.UNKNOWN,
            }
        ]

        const res = fetchRoomDetailsForDeviceTransformer(data, prevRooms)
        expect(res).toEqual(expectedResult)
    })

    it("should getRoomRelevantForCurrentUserTransformer", () => {
        const data = {
            deviceDetails: [
                {
                    sites: "abc:1~def:2",
                    modality: "ct:1,mr:2",
                    resource_id: "a",
                    resource_name: "",
                    device_uuid: "",
                    resource_location: "",
                    resource_primary_phone: "",
                    monitorsCount: ""
                }
            ]
        }
        const res = getRoomRelevantForCurrentUserTransformer(data)
        const expectedResult = {
            identity: { id: "a", name: "", uuid: "" },
            locationId: NaN,
            address: "",
            modality: "1",
            modalityId: "ct",
            favourite: false,
            phoneNumber: "",
            disabled: false,
            isRoomStarred: false,
            presenceData: { presence: "OFFLINE", mapId: "" },
            isConnecting: false,
            loggedInTech: { techUuid: "", techName: "" },
            monitorsCount: "",
            roomStatus: ERoomStatus.UNKNOWN,
        }
        expect(res).toEqual(expectedResult)

    })

    it("should fetchLocationInfoForCurrentUserTransformer", () => {
        const data = {
            resourcesInfo: [
                {
                    additional_attributes: null,
                    device_status: "Active",
                    device_uuid: "b7557801-5b19-492b-90a6-8dc03ea981eb",
                    modality: "2:CT",
                    org_id: 1,
                    org_identifier: "platinum",
                    modality_connection: [],
                    org_name: "Platinum Health Systems",
                    org_uuid: "e9101b82-493c-40df-b539-d605732ffbb4",
                    resource_id: 4,
                    resource_identifier: "PHSSA01CT015",
                    resource_location: "Research Department",
                    resource_name: "CT Scanner-015",
                    resource_phone: "+1 4252432344",
                    site_contacts: "200278:1:Neurology Dept:+919663602455:front-desk~200279:1:Frontdesk12thFeb:9199009989899:front-desk~200280:1:Frontdesk:123456677:front-desk~200281:2:Tower C:1234567890:scheduler-registrar",
                    sites: "4:PHSSA01:Platinum Healthcare - Seattle:22100 Bothell Everett Hwy, Seattle, WA - 98021",
                    user_favourite: true,
                    __typename: "rocc_get_all_site_resources_function_table",
                }
            ]
        }
        const res = fetchLocationInfoForCurrentUserTransformer(data)
        const expectedResult = {
            customerMetaData: {
                id: 1,
                displayName: 'Platinum Health Systems',
                name: 'platinum',
                orgId: 'e9101b82-493c-40df-b539-d605732ffbb4',
                contacts: []
            },
            locations: [
                {
                    id: 4,
                    name: 'Platinum Healthcare - Seattle',
                    address: '22100 Bothell Everett Hwy, Seattle, WA - 98021',
                    shortName: 'PHSSA01',
                    modalityList: [{ id: 2, modality: 'CT' }],
                    roomsFetched: true,
                    locationContacts: [{
                        id: 'fd200278',
                        name: 'Neurology Dept',
                        phoneNumber: '+919663602455',
                        clinicalRole: 'Frontdesk'
                    },
                    {
                        id: 'fd200279',
                        name: 'Frontdesk12thFeb',
                        phoneNumber: '9199009989899',
                        clinicalRole: 'Frontdesk'
                    },
                    {
                        id: 'fd200280',
                        name: 'Frontdesk',
                        phoneNumber: '123456677',
                        clinicalRole: 'Frontdesk'
                    },
                    {
                        id: 'sr200281',
                        name: 'Tower C',
                        phoneNumber: '1234567890',
                        clinicalRole: 'Scheduler'
                    }],
                    totalRooms: 0
                }
            ],
            rooms: [
                {
                    identity: {
                        id: 4,
                        name: 'CT Scanner-015',
                        uuid: 'b7557801-5b19-492b-90a6-8dc03ea981eb',
                        address: 'Research Department'
                    },
                    locationId: 4,
                    address: 'Research Department',
                    modality: 'CT',
                    modalityConnection: [],
                    modalityId: '2',
                    favourite: false,
                    phoneNumber: '+1 4252432344',
                    disabled: false,
                    isRoomStarred: true,
                    presenceData: { presence: 'OFFLINE', mapId: '' },
                    isConnecting: false,
                    loggedInTech: { techName: '', techUuid: '' },
                    monitorsCount: undefined,
                    additionalAttributes: null,
                    roomStatus: ERoomStatus.UNKNOWN,
                }
            ]
        }
        expect(res).toEqual(expectedResult)

    })
})
