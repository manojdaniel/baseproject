/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EPdType } from "@rocc/rocc-client-services"
import { ErrorBoundary, System } from "@rocc/rocc-global-components"
import React from "react"
import {
    HashRouter,
    Route,
    Switch,
    Redirect,
} from "react-router-dom"
import { Header } from "semantic-ui-react"
import AppLayout from "./common/layouts/app-layout/AppLayout"
import DemoEnvConsoleVideo from "./components/demo-env-console-video/DemoEnvConsoleVideo"
import PDFViewer from "./components/ifu-manual/PDFViewer"
import LoginComponent from "./components/login/LoginComponent"
import {
    ROCC_ADMIN_APP,
    ROCC_ADMIN_APP_REMOTE_ENTRY, ROCC_PHARMA_APP, ROCC_PHARMA_APP_REMOTE_ENTRY, ROCC_SCHEDULER_APP, ROCC_SCHEDULER_APP_REMOTE_ENTRY, SELF_SERVICE_HOME_APP, SELF_SERVICE_HOME_APP_REMOTE_ENTRY
} from "./constants/constants"
import { ADMIN_ROUTE, ADMIN_USER_MANUAL_ROUTE, CONSULTS_ROUTE, DEMO_ENV_CONSOLE_ROUTE, EXPERT_USER_MANUAL_ROUTE, FORGOT_PD_ROUTE, IDN_ROUTE, LOGIN_ROUTE, LOGOUT_ROUTE, REGISTER_ROUTE, RESET_PD_ROUTE, SCHEDULING_ROUTE, SESSION_EXPIRED, SETTINGS_ROUTE, SET_PD_ROUTE, SUPPORT_ROUTE, ROOM_MONITORING_ROUTE, PHARMA_ROUTE } from "./constants/routes"
import { EManualType } from "./types/types"
import { fetchConsultRoutes, fetchRenderPage, validateStore } from "./utility/helpers/helpers"
import RoomMonitoring from "./components/room-monitoring/RoomMonitoring"

const HomeComponent = React.lazy(() => import("./components/home/HomeComponent"))
const Settings = React.lazy(() => import("./common/pages/settings/Settings"))
const SessionExpiredComponent = React.lazy(() => import("./components/session-expired/SessionExpiredComponent"))
const ForgotPasswordComponent = React.lazy(() => import("./components/forgot-password/ForgotPasswordComponent"))
const OnBoarding = React.lazy(() => import("./components/onboarding/OnBoarding"))
const SetPasswordComponent = React.lazy(() => import("./components/set-password/SetPasswordComponent"))
const cache: any = {}

const Routes = () => {

    const privateRoute = (ComponentToLoad: any, dynamicRoute?: string) => {
        let renderIfTrue
        if (dynamicRoute) {
            if (!cache[dynamicRoute]) {
                cache[dynamicRoute] = ComponentToLoad
            } else {
                /* sonar issue fix */
            }
            renderIfTrue = <AppLayout ComponentToLoad={cache[dynamicRoute]} />
        } else {
            renderIfTrue = <AppLayout ComponentToLoad={ComponentToLoad} />
        }
        const renderIfFalse = <Redirect to={{ pathname: LOGIN_ROUTE, state: { referer: dynamicRoute } }} />
        return validateStore() ? renderIfTrue : renderIfFalse
    }

    const checkRenderPage = () => {
        const navigateTo = fetchRenderPage()
        return <Redirect to={navigateTo} />
    }

    const renderConsults = () => {
        let renderContent = <Header>{"You do not have access to view this page. Please contact your administrator!"}</Header>
        const consultDetails = fetchConsultRoutes()
        if (consultDetails) {
            const { url, module, scope, props } = consultDetails
            renderContent = <System system={{ url, scope, module, props }} />
        }
        return <React.Suspense fallback={"Loading consults"}>
            {renderContent}
        </React.Suspense>
    }

    return (
        <HashRouter>

            <Switch>
                <Route
                    path={LOGIN_ROUTE}
                    component={() => <LoginComponent />}
                    exact={true}
                />
                <Route
                    path="/"
                    exact={true}
                    render={checkRenderPage}
                />
                <Route
                    path={FORGOT_PD_ROUTE}
                    component={() => <ErrorBoundary><React.Suspense fallback=""><ForgotPasswordComponent /></React.Suspense></ErrorBoundary>}
                    exact={true}
                />
                <Route
                    path={REGISTER_ROUTE}
                    component={() => privateRoute(<ErrorBoundary><React.Suspense fallback=""><OnBoarding /></React.Suspense></ErrorBoundary>)}
                    exact={true}
                />
                <Route
                    path={SET_PD_ROUTE}
                    render={() => <ErrorBoundary><React.Suspense fallback=""><SetPasswordComponent type={EPdType.SET_PD} /></React.Suspense></ErrorBoundary>}
                    exact={true}
                />
                <Route
                    path={RESET_PD_ROUTE}
                    render={() => <ErrorBoundary><React.Suspense fallback=""><SetPasswordComponent type={EPdType.RESET_PD} /></React.Suspense></ErrorBoundary>}
                    exact={true}
                />
                <Route
                    path={SESSION_EXPIRED}
                    render={() => <ErrorBoundary><React.Suspense fallback=""><SessionExpiredComponent /></React.Suspense></ErrorBoundary>}
                    exact={true}
                />
                <Route
                    path={SETTINGS_ROUTE}
                    render={() => privateRoute(<ErrorBoundary><React.Suspense fallback=""><Settings /></React.Suspense></ErrorBoundary>)}
                    exact={true}
                />
                <Route
                    path={CONSULTS_ROUTE}
                    render={() => privateRoute(<ErrorBoundary>
                        {renderConsults()}
                    </ErrorBoundary>)}
                    exact={true}
                />
                <Route
                    path={PHARMA_ROUTE}
                    exact={true}
                    render={() => privateRoute(<ErrorBoundary>
                        <System system={{
                            url: ROCC_PHARMA_APP_REMOTE_ENTRY,
                            scope: ROCC_PHARMA_APP,
                            module: "./App"
                        }} />
                    </ErrorBoundary>, PHARMA_ROUTE)}
                />
                <Route
                    path={LOGOUT_ROUTE}
                    exact={true}
                    render={() => {
                        return <Redirect to={LOGIN_ROUTE} />
                    }}
                />
                <Route
                    path={IDN_ROUTE}
                    render={() => privateRoute(<ErrorBoundary><React.Suspense fallback=""><HomeComponent /></React.Suspense></ErrorBoundary>)}
                    exact={true}
                />
                <Route
                    path={ADMIN_ROUTE}
                    render={() => privateRoute(<ErrorBoundary>
                        <System system={{
                            url: ROCC_ADMIN_APP_REMOTE_ENTRY,
                            scope: ROCC_ADMIN_APP,
                            module: "./App"
                        }} />
                    </ErrorBoundary>, ADMIN_ROUTE)}
                    exact={true}
                />
                <Route
                    path={EXPERT_USER_MANUAL_ROUTE}
                    render={() => privateRoute(
                        <ErrorBoundary>
                            <PDFViewer manualType={EManualType.USER_MANUAL} />
                        </ErrorBoundary>, EXPERT_USER_MANUAL_ROUTE)
                    }
                />
                <Route
                    path={ADMIN_USER_MANUAL_ROUTE}
                    render={() => privateRoute(
                        <ErrorBoundary>
                            <PDFViewer manualType={EManualType.ADMIN_MANUAL} />
                        </ErrorBoundary>, ADMIN_USER_MANUAL_ROUTE)
                    }
                />
                <Route
                    path={SUPPORT_ROUTE}
                    render={() => privateRoute(<ErrorBoundary>
                        <System system={{
                            url: SELF_SERVICE_HOME_APP_REMOTE_ENTRY,
                            scope: SELF_SERVICE_HOME_APP,
                            module: "./homeApp",
                        }} />
                    </ErrorBoundary>, SUPPORT_ROUTE)}
                    exact={true}
                />
                <Route
                    path={SCHEDULING_ROUTE}
                    render={() => privateRoute(<ErrorBoundary>
                        <System system={{
                            url: ROCC_SCHEDULER_APP_REMOTE_ENTRY,
                            scope: ROCC_SCHEDULER_APP,
                            module: "./App",
                        }} />
                    </ErrorBoundary>, SCHEDULING_ROUTE)}
                    exact={true}
                />
                <Route
                    path={`${DEMO_ENV_CONSOLE_ROUTE}/:roomName/:connectionType`}
                    exact={true}
                    render={() => <ErrorBoundary><React.Suspense fallback="\"><DemoEnvConsoleVideo /></React.Suspense></ErrorBoundary>}
                />
                <Route
                    path={`${ROOM_MONITORING_ROUTE}`}
                    exact={true}
                    render={() => <ErrorBoundary><React.Suspense fallback="\"><RoomMonitoring /></React.Suspense></ErrorBoundary>}
                />
            </Switch>
        </HashRouter>
    )
}

export default Routes
