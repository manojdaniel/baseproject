/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore } from "@rocc/rocc-client-services"
import React, { useEffect, useState } from "react"
import { CALLING_STORE, CONSOLE_STORE, CURRENT_APP_NAME, PARENT_STORE } from "../../../constants/constants"
import { SYNC_CALLING_STORE, SYNC_CONSOLE_STORE, SYNC_PARENT_REDUCERS, SYNC_PROTOCOL_TRANSFER_STORE } from "../../../redux/actions/types"
import globalStore from "../../../redux/store/globalStore"

const SyncExternalRedux = () => {

    const gState = globalStore.GetGlobalState()
    const [parentStoreSubscribed, setParentStoreSubscribed] = useState(false)
    const [consoleStoreSubscribed, setConsoleStoreSubscribed] = useState(false)
    const [callingStoreSubscribed, setCallingStoreSubscribed] = useState(false)

    useEffect(() => {
        syncExternalStore()
    }, [gState])

    const syncExternalStore = () => {
        const gState = globalStore.GetGlobalState()
        if (!parentStoreSubscribed && gState[PARENT_STORE]) {
            updateUserInfo(gState[PARENT_STORE])

            globalStore.SubscribeToPartnerState(CURRENT_APP_NAME, PARENT_STORE, (changedState: any) => {
                updateUserInfo(changedState)
            })
            setParentStoreSubscribed(true)
        }

        /** Sync Console reducer and Protocol transfer reducer */
        if (!consoleStoreSubscribed && gState[CONSOLE_STORE]) {
            updateConsoleInfo(gState[CONSOLE_STORE])
            updateProtocolTransferInfo(gState[CONSOLE_STORE])
            globalStore.SubscribeToPartnerState(CURRENT_APP_NAME, CONSOLE_STORE, (changedState: any) => {
                updateConsoleInfo(changedState)
                updateProtocolTransferInfo(changedState)
            })
            setConsoleStoreSubscribed(true)
        }

        if (!callingStoreSubscribed && gState[CALLING_STORE]) {
            updateCallingInfo(gState[CALLING_STORE])
            globalStore.SubscribeToPartnerState(CURRENT_APP_NAME, CALLING_STORE, (changedState: any) => {
                updateCallingInfo(changedState)
            })
            setCallingStoreSubscribed(true)
        }
    }

    const updateCallingInfo = (changedState: any) => {
        const phoneCallStatus = changedState?.callReducer?.phoneCallStatus
        const videoCallStatus = changedState?.callReducer?.videoCallStatus
        const connectedCallDetails = changedState?.callReducer?.callDetails?.connectedCallDetails
        const onHoldCallDetails = changedState?.callReducer?.callDetails?.onHoldCallDetails
        globalStore.DispatchAction(CURRENT_APP_NAME, {
            type: SYNC_CALLING_STORE, payload: { phoneCallStatus, videoCallStatus, connectedCallDetails, onHoldCallDetails }
        })
    }

    const updateConsoleInfo = (changedState: any) => {
        const activeConsoleTransactions = changedState?.consoleReducer?.consoleOperation?.transactions || []
        let activeConsoleSessions = []
        if (changedState?.consoleReducer?.consoleSessions) {
            activeConsoleSessions = changedState.consoleReducer.consoleSessions.map((session: any) => ({
                contextId: session.contextId, roomUuid: session.roomUuid, connectionMode: session.connectionMode,
                connectionType: session.connectionType, receiverName: session.receiverName, connectionStatus: session.connectionStatus
            }))
        }

        globalStore.DispatchAction(CURRENT_APP_NAME, {
            type: SYNC_CONSOLE_STORE, payload: { activeConsoleTransactions, activeConsoleSessions }
        })
    }

    const updateProtocolTransferInfo = (changedState: any) => {
        const protocolTransferStatus = changedState?.protocolTransferReducer?.protocolTransferStatus
        const selectedSource = changedState?.protocolTransferReducer?.selectedSource
        const selectedDestination = changedState?.protocolTransferReducer?.selectedDestination
        const currentStep = changedState?.protocolTransferReducer?.currentStep
        const completedDestinations = changedState?.protocolTransferReducer?.completedDestinations ?? []

        globalStore.DispatchAction(CURRENT_APP_NAME, {
            type: SYNC_PROTOCOL_TRANSFER_STORE, payload: { protocolTransferStatus, selectedSource, selectedDestination, currentStep, completedDestinations }
        })
    }

    const updateUserInfo = (changedState: IParentStore) => {
        /* Update if session of parent app is updated */

        const payload = {
            currentUser: changedState.userReducer.currentUser,
            notificationMessage: changedState.modalReducer.notificationMessage,
            rooms: changedState.customerReducer.rooms,
            initRoomsFetched: changedState.customerReducer.initRoomsFetched,
            locations: changedState.customerReducer.locations,
            activeLocationId: changedState.customerReducer.activeLocationId,
            featureFlags: changedState.featureFlagsReducer.featureFlags,
            sideBar: changedState.appReducer.sideBar,
            workflows: changedState.workflowReducer.workflows,
            permissions: changedState.userReducer.permissions,
            forceCleanUp: changedState.userReducer.forceCleanUp,
            applicationConnectionState: changedState.clientStatusReducer.applicationConnectionState,
            focusedCallAndConsole: changedState.appReducer.focusedCallAndConsole
        }
        globalStore.DispatchAction(CURRENT_APP_NAME, {
            type: SYNC_PARENT_REDUCERS, payload,
        })
    }
    return <></>
}

export default SyncExternalRedux
