/*
 * Created on Fri Sep 03 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import callReducer, { initialStatesForCall } from "./callReducer"

describe("App Component", () => {
  it("should handle call reducer action", () => {
    const value = callReducer(initialStatesForCall, {type: "SET_AV_CALL_VOLUME", volume: 50})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {

    const value = callReducer({initialStatesForCall},{type: ""})
    expect(value).toBeDefined()
  })
})
