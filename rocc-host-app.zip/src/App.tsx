/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import { defineMessages, IntlProvider } from "react-intl"
import "@dls-pdv/semantic-ui-foundation/dist/semantic.min.css"
import { setupLogger } from "@rocc/rocc-logging-module"
import { isDev } from "./utility/storage/storageUtility"
import { persistor } from "./redux/store/store"
import { PersistGate } from "redux-persist/integration/react"
import { HttpClientProvider } from "@rocc/rocc-http-client"
import { roccHttpClient } from "./utility/api/apiUtility"
import messages from "./resources/translations/messages"
import { getApplicationDefaultConfig, getLoggedSessionTime, sendActiveConsoleEndLog, trackEvent } from "./utility/helpers/helpers"
import { INIT_CONFIG_DATA, UNLOAD } from "./constants/constants"
import { useDispatch } from "react-redux"
import { TRACK } from "./constants/tracking"
import Routes from "./Routes"
import { getAuthConfigs } from "./redux/services/appServices"

const App = () => {
  const [configData, setConfigData] = useState(INIT_CONFIG_DATA)
  const dispatch = useDispatch()

  useEffect(() => {
    setupLogger({ isDev: isDev() })
    getApplicationDefaultConfig(dispatch).then((config: any) => {
      setConfigData(config)
    })
    getAuthConfigs(dispatch)
    window.addEventListener(UNLOAD, () => {
      const { component, event: { sessionClosed } } = TRACK.SESSION
      const sessionTime = getLoggedSessionTime()
      trackEvent(component, sessionClosed, { duration: sessionTime })
      sendActiveConsoleEndLog()
    })
  }, [])

  const { preferredLocale, language } = configData
  return <>
    <PersistGate loading={null} persistor={persistor}>
      <HttpClientProvider client={roccHttpClient}>
        <IntlProvider
          defaultLocale={preferredLocale}
          locale={language}
          messages={defineMessages(messages[language])}
        >
          <Routes />
        </IntlProvider>
      </HttpClientProvider>
    </PersistGate>
  </>
}

export default App
