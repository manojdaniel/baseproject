/*
 * Created on Mon Apr 25 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import TechAppDownload from "./TechAppDownload"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: {
            accessToken: "123"
        },
        urls: { MANAGEMENT_SERVICE_URL: "http://test" }
    }),
    useDispatch: () => jest.fn(),
}))

describe("TechAppDownload component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<TechAppDownload />)
    })

    it("should find button", () => {
        const button = wrapper.find("Button")
        expect(button).toHaveLength(1)
        const onClick = button.prop("onClick")
        expect(onClick()).toBeDefined()
    })
})
