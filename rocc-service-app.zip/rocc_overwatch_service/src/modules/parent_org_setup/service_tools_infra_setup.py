"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_HSDP_IAM_URL, VAULT_ROOT_SERVICE_AUTH_ISSUER, VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY, \
    VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import ROCC_ORGANIZATIONS, SEP, COMPLETED
from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs, ETasks
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.policy_services.manage_policy_services import create_service_tools_policy, delete_policy, get_policy_by_name
from src.wrappers.infrastructure_services.roles_permissions_services.manage_roles_groups import create_service_group_and_roles_for_suborg, get_service_details
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.exceptions.RoccException import RoccException
from src.wrappers.graphql.queries.queries import fetch_all_customers
from src.wrappers.graphql.mutations.mutations import upsert_customers_in_bulk
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.iam_service.authorization_services import create_allowed_org_mapping

LOG = create_logger("ServiceToolsSetup")


class ServiceToolsInfraSetup:

    def start_job(self, vault_cred_path, vault_credentials_response, rocc_proxy_url, user_details, profile_configs=None):
        LOG.info(f"Starting Job: {EJobs.SETUP_SERVICE_TOOLS.value}")
        self.load_vault_configs(profile_configs)
        self._user_uuid = user_details["userId"]
        self._user_org = user_details["orgId"]
        self._token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                      issuer=self._profile_configs[VAULT_ROOT_SERVICE_AUTH_ISSUER],
                                                      private_key=self._profile_configs[VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY])
        self._parent_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                             issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                             private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
        self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
        self._vault_data = get_path_specific_vault_values(path_name=vault_cred_path,
                                                          vault_credentials_response=vault_credentials_response)["data"]
        self._client = get_client_connection(self._parent_token, org_infra_uuid=self._parent_org_id, url=rocc_proxy_url)
        if "customerMap" in self._vault_data:
            self._customer_map = self._vault_data["customerMap"]

        self.execute_tasks(vault_credentials_response=vault_credentials_response, rocc_proxy_url=rocc_proxy_url)
        prepare_and_post_audit(event_type="Service tool infra setup", event_subtype=EJobs.SETUP_SERVICE_TOOLS.value, action="E", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id,
                               token=self._parent_token,
                               **{"SETUP_SERVICE_TOOLS": COMPLETED},
                               **{"User Org Details": self._user_org})
        LOG.info(f"Finished Job: {EJobs.SETUP_SERVICE_TOOLS.value}")

    def load_vault_configs(self, profile_configs=None):
        """Fetch vault configs from the profile path"""
        try:
            self._profile_configs = profile_configs if profile_configs else get_profile_data()
        except Exception as ex:

            LOG.error(f"Failed to retrieve vault profile configs with error: {ex}")
            raise RoccException(500, f"Failed to retrieve vault profile configs with error: {ex}")

    def execute_tasks(self, vault_credentials_response, rocc_proxy_url):
        try:
            self.task_create_service_group_for_parent_org()
            self.task_create_service_tools_policy()
            self.task_create_allowed_org_mapping(url=rocc_proxy_url)
            self.task_enable_service_tools_for_all_existing_suborgs(vault_credentials_response=vault_credentials_response)
        except Exception as e:
            LOG.error(f"Job {EJobs.SETUP_SERVICE_TOOLS.value} failed with error: {e}")

    def task_create_service_tools_policy(self, token=None, profile_configs=None):
        if token is None:
            token = self._token
        if profile_configs is None:
            profile_configs = self._profile_configs
        LOG.info(f"Starting task {ETasks.CREATE_SERVICE_TOOLS_POLICY.value}")
        existing_policy = get_policy_by_name(
            token=token, organization_id=profile_configs["PARENT_ORG_ID"], policy_name="service-tools-policy", profile_configs=profile_configs)
        if len(existing_policy["entry"]) > 0:

            existing_policy_id = existing_policy["entry"][0]["id"]
            LOG.info(f"Found existing policy with ID: {existing_policy_id}. Deleting this policy and creating a new one")
            delete_response = delete_policy(token=token, policy_id=existing_policy_id, profile_configs=profile_configs)
            if delete_response:
                LOG.info("Creating new policy 'service-tools-policy'. ")
                response = create_service_tools_policy(token=token, profile_configs=profile_configs)
                if not response:
                    LOG.error(f"Task: {ETasks.CREATE_SERVICE_TOOLS_POLICY.value} failed for parent org: {profile_configs[VAULT_PARENT_ORG_ID]}")
                    raise RoccException(status_code=500, payload=str("Failed to create service tools policy"))
        else:
            LOG.info("Existing policy not found. Creating new policy 'service-tools-policy'")
            response = create_service_tools_policy(token=token, profile_configs=profile_configs)
            if not response:
                LOG.error(f"Task: {ETasks.CREATE_SERVICE_TOOLS_POLICY.value} failed for parent org: {profile_configs[VAULT_PARENT_ORG_ID]}")
                raise RoccException(status_code=500, payload=str("Failed to create service tools policy"))
        LOG.info(f"Finished task: {ETasks.CREATE_SERVICE_TOOLS_POLICY.value}")

    def prepare_object(self, customers_response_list):
        """
        1. Get the list of Customers
        2. Parse the response and prepare the insert object according to customer table
        3. Return the insert_object
        """
        insert_object = []
        active_customers = []
        for customer_data in customers_response_list[ROCC_ORGANIZATIONS]:
            active_customers.append(customer_data["org_identifier"])
            insert_object.append({"name": customer_data["org_identifier"], "status": "IDLE"})
        return insert_object, active_customers

    def task_enable_service_tools_for_all_existing_suborgs(self, vault_credentials_response):
        LOG.info(f"Enabling service tools for existing suborgs")
        customers_response_list = self._client.execute(fetch_all_customers)
        insert_object, active_customers = self.prepare_object(customers_response_list=customers_response_list)
        self.upsert_customers(insert_object)
        for org_name, org_id in self._customer_map.items():
            try:
                if org_name in active_customers:
                    LOG.info(SEP)
                    LOG.info(f"Creating service group and roles for org: {org_name} ")
                    organization_vault_values = get_path_specific_vault_values(path_name=org_name, vault_credentials_response=vault_credentials_response)
                    service_issuer_id = organization_vault_values["data"]["serviceAuthIssuer"]
                    service_id = get_service_details(access_token=self._token, service_issuer_id=service_issuer_id, profile_configs=self._profile_configs)["entry"][0]["id"]
                    create_service_group_and_roles_for_suborg(token=self._token, org_id=org_id,  service_id=service_id, profile_configs=self._profile_configs)
            except Exception as e:
                LOG.error(f"Failed to create service group and roles for {org_name} with error: {e}")

    def task_create_allowed_org_mapping(self, url):
        root_org_id = self._profile_configs["ROOT_ORG_ID"]
        response = create_allowed_org_mapping(token=self._token, url=url, org_id=root_org_id)
        if not response:
            LOG.error(f"Failed to create allowed org mapping")
            raise RoccException(500, "Failed to create allowed org mapping")

    def upsert_customers(self, insert_objects):
        variables = {"objects": insert_objects}
        if len(insert_objects) > 0:
            self._client.execute(upsert_customers_in_bulk, variables)
            LOG.info(f"Successfully added following metasites to service schema: {insert_objects} ")

    def task_create_service_group_for_parent_org(self):
        try:
            service_issuer_id = self._vault_data["serviceAuthIssuer"]
            service_id = get_service_details(access_token=self._token, service_issuer_id=service_issuer_id, profile_configs=self._profile_configs)["entry"][0]["id"]
            create_service_group_and_roles_for_suborg(
                token=self._token, org_id=self._profile_configs[VAULT_PARENT_ORG_ID],  service_id=service_id, profile_configs=self._profile_configs)
        except Exception as e:
            LOG.error(f"Exception while creating service group for parent org. Error: {e}")
