/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, EROCC_CONTEXT, ECallStatus } from "@rocc/rocc-client-services"
import React from "react"
import { shallow } from "enzyme"
import IncomingCall from "./IncomingCall"
import * as redux from "react-redux"
import { DEFAULT_INCOMING_CALL_DEATILS } from "../../redux/reducers/callReducer"
import { withHooks } from "jest-react-hooks-shallow"

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            customerReducer: {
                locations: [{
                    id: 1,
                    name: "location1",
                    shortName: "location1",
                    address: "",
                    modalityList: [],
                    locationContacts: [],
                    totalRooms: 1,
                    roomsFetched: true,
                }]
            }
        }
    }),
    CreateStore: jest.fn(),
}))

describe("IncomingCall tests", () => {
    it("should render IncomingCallModal", () => {
        jest.spyOn(redux, "useSelector").mockReturnValue({
            incomingCallDetails: {
                contextId: "contextId",
                participant: {
                    name: "participant",
                    clinicalRole: EClinicalRole.EXPERTUSER,
                    description: "",
                    siteId: ["1"]
                }
            },
            videoCallStatus: [{
                contextId: "contextId", callStatus: ECallStatus.RINGING
            }]
        })
        jest.spyOn(redux, "useDispatch").mockImplementation(jest.fn())
        withHooks(() => {
            const wrapper = shallow(<IncomingCall deviceType={EROCC_CONTEXT.DESKTOP} />)
            expect(wrapper.find("IncomingCallModal")).toHaveLength(1)
        })
    })

    it("should render IncomingCallWindow", () => {
        jest.spyOn(redux, "useSelector").mockReturnValue({
            incomingCallDetails: {
                contextId: "contextId",
                participant: {
                    name: "participant",
                    clinicalRole: EClinicalRole.EXPERTUSER,
                    description: "",
                    siteId: ["1"]
                }
            },
            videoCallStatus: [{
                contextId: "contextId", callStatus: ECallStatus.RINGING
            }]
        })
        jest.spyOn(redux, "useDispatch").mockImplementation(jest.fn())
        withHooks(() => {
            const wrapper = shallow(<IncomingCall deviceType={EROCC_CONTEXT.TABLET} />)
            expect(wrapper.find("IncomingCallWindow")).toHaveLength(1)
        })
    })

    it("should render Empty fragment", () => {
        jest.spyOn(redux, "useSelector").mockReturnValue({
            incomingCallDetails: { ...DEFAULT_INCOMING_CALL_DEATILS },
            videoCallStatus: [{
                contextId: "contextId", callStatus: ECallStatus.IDLE
            }]
        })
        jest.spyOn(redux, "useDispatch").mockImplementation(jest.fn())
        withHooks(() => {
            const wrapper = shallow(<IncomingCall deviceType={EROCC_CONTEXT.TABLET} />)
            expect(wrapper.find("IncomingCallModal")).toHaveLength(0)
        })
    })
})
