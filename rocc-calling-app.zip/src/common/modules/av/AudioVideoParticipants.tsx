/*
 * Created on Fri July 15 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoccVideoCall, RemoteTrackEvents, RoccAvRoom, RoccAVTrack, RoccRemoteParticipant } from "@rocc/rocc-av-communication-sdk"
import { getDetailsByUUID, IAVCallDetails, IParticipantInfo } from "@rocc/rocc-client-services"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { MutableRefObject, useEffect, useRef } from "react"
import { useDispatch, useSelector } from "react-redux"
import { CALL_ACCEPT, DEFAULT } from "../../../constants/constants"
import { ETrackKind, IStore } from "../../../redux/interfaces/types"
import { fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import { getCustomrReducerFromGlobalStore, getUserReducerFromGlobalStore } from "../../helpers/helpers"
import { MPC_TO_P2P_EVENT, P2P_TO_MPC_EVENT } from "../../helpers/TelemetryTrackingHelper"
import { getContextDetails } from "../avmessages/messageService"
import { fetchCallContextByContextId, getAVEventType, updateCallDetails } from "./AudioVideoHelper"
import { IParticipantObject } from "./types"
import { RemoteParticipantEvents, RoccTracks, RoccAvRemoteTrack, RoccParticipant } from "@rocc/rocc-av-communication-sdk"
interface IAudioVideoParticipantProps {
    activeRoom: RoccAvRoom
    activeCall: IAVCallDetails
    remoteMediaRef: MutableRefObject<any>
    setRemoteUserVideoStatus: (status: boolean) => void
    dominantSpeaker: IParticipantInfo
    setDominantSpeaker: (participant: IParticipantInfo) => void
    updateRemoteAudioTrackStatus: (status: boolean, participant: RoccParticipant) => void
    vendorService: IRoccVideoCall
}
const AudioVideoParticipants = (props: IAudioVideoParticipantProps) => {

    const { currentUser, audioOutput, rooms } = useSelector((state: IStore) => ({
        audioOutput: state.callReducer.audioOutput,
        currentUser: state.externalReducer.currentUser,
        rooms: state.externalReducer.rooms,
    }))

    const { activeRoom, activeCall, dominantSpeaker, vendorService } = props
    const urls = fetchGlobalURLs()
    const { contacts } = getUserReducerFromGlobalStore()
    const dominantSpeakerRef = useRef(dominantSpeaker)
    const activeCallDetailsRef = useRef(activeCall)
    const audioOutputRef = useRef(audioOutput)
    const currentUserRef = useRef(currentUser)
    const activeRoomRef = useRef(activeRoom)
    useEffect(() => {
        dominantSpeakerRef.current = dominantSpeaker
        activeCallDetailsRef.current = activeCall
        audioOutputRef.current = audioOutput
        currentUserRef.current = currentUser
    }, [dominantSpeaker, activeCall, audioOutput, currentUser])

    useEffect(() => {
        updateParticipantLoggedInTechInfo()
    }, [rooms])

    const dispatch = useDispatch()

    const component = "Audio Video Participants"
    useEffect(() => {
        if (activeRoom) {
            activeRoomRef.current = activeRoom
            vendorService.initializeParticipants(activeRoom, getRemoteParticipantsEvents())
        }
    }, [activeRoom])

    const getRemoteParticipantsEvents = () => {
        const { EVENT_PARTICIPANT_CONNECTED, EVENT_PARTICIPANT_DISCONNECTED, EVENT_DOMINANT_SPEAKER_CHANGED,
            EVENT_TRACK_DISABLED, EVENT_TRACK_ENABLED, EVENT_TRACK_UNPUBLISHED,
            EVENT_TRACK_UNSUBSCRIBED, EVENT_TRACK_SUBSCRIBED } = RemoteParticipantEvents

        const participantConnectedgEventType = getAVEventType(EVENT_PARTICIPANT_CONNECTED, participantConnected)
        const participantDisconnectedgEventType = getAVEventType(EVENT_PARTICIPANT_DISCONNECTED, participantDisconnected)
        const trackSubscribedEventType = getAVEventType(EVENT_TRACK_SUBSCRIBED, trackSubscribed)
        const trackUnsubscribedEventType = getAVEventType(EVENT_TRACK_UNSUBSCRIBED, trackUnsubscribed)
        const trackEnabledEventType = getAVEventType(EVENT_TRACK_ENABLED, trackEnabled)
        const trackDisabledEventType = getAVEventType(EVENT_TRACK_DISABLED, trackDisabled)
        const trackUnpublishedEventType = getAVEventType(EVENT_TRACK_UNPUBLISHED, trackUnpublished)
        const dominantSpeakerChangedEventType = getAVEventType(EVENT_DOMINANT_SPEAKER_CHANGED, dominantSpeakerChanged)

        return [participantConnectedgEventType, participantDisconnectedgEventType, trackSubscribedEventType,
            trackUnsubscribedEventType, trackEnabledEventType, trackDisabledEventType, trackUnpublishedEventType,
            dominantSpeakerChangedEventType]
    }

    const getRemoteTracksEvents = () => {
        const { EVENT_TRACK_STARTED } = RemoteTrackEvents
        const trackStartedEventType = getAVEventType(EVENT_TRACK_STARTED, onTrackStarted)
        return [trackStartedEventType]
    }
    const updateParticipantLoggedInTechInfo = async () => {
        const callDetails = fetchCallContextByContextId(activeCall.contextId)
        if (!callDetails) {
            return
        }
        const participants = await Promise.all(callDetails.participants.map(async (participant: any) => {
            const callingRoom = rooms.find((room) => room.roomUuid === participant.uuid)
            let participantDetails = { ...participant }
            if (callingRoom) {
                if (callingRoom.loggedInTech.techUuid) {
                    const { techUuid, techName } = callingRoom.loggedInTech
                    participantDetails = { ...participantDetails, secondaryName: techName, secondaryUUID: techUuid, status: callingRoom.presenceData.presence }
                } else {
                    participantDetails = { ...participantDetails, secondaryName: "", secondaryUUID: "", status: callingRoom.presenceData.presence }
                }
            }
            if (dominantSpeakerRef.current && participantDetails.uuid === dominantSpeakerRef.current.uuid) {
                props.setDominantSpeaker(participantDetails)
            }
            return participantDetails
        }))
        Promise.resolve([])
        callDetails.participants = [...participants]
        updateCallDetails(callDetails, dispatch, true)
    }

    const dominantSpeakerChanged = async (participant: RoccRemoteParticipant) => {
        const participantIdentity = vendorService.getParticipantIdentity(participant)
        infoLogger(`AudioVideoParticipants.tsx: dominantSpeakerChanged participant Identity ${participantIdentity}
        with contextId: ${activeCallDetailsRef.current.contextId}`)
        if (participant && participantIdentity !== currentUser.uuid) {
            const participantDetails = activeCallDetailsRef.current.participants.find(
                (callParticipant: any) => participantIdentity === callParticipant.uuid)
            if (participantDetails) {
                props.setDominantSpeaker(participantDetails)
            }
        }

    }

    const onTrackStarted = async (roccTracks: RoccAvRemoteTrack) => {
        if (roccTracks.kind === ETrackKind.VIDEO) {
            props.setRemoteUserVideoStatus(true)
        }

    }

    const trackUnpublished = (roccTracks: RoccTracks, participant: RoccRemoteParticipant) => {
        if (roccTracks.kind === ETrackKind.VIDEO) {
            infoLogger(`AudioVideoParticipants.tsx: Participant ${vendorService.getParticipantIdentity(participant)} disabled the video track 
            for the call with contextId: ${activeCallDetailsRef.current.contextId}`)
            props.setRemoteUserVideoStatus(false)
        }
    }

    const trackEnabled = (roccTracks: RoccTracks, participant: RoccRemoteParticipant) => {
        if (roccTracks.kind === ETrackKind.AUDIO) {
            props.updateRemoteAudioTrackStatus(true, participant)
        }
    }

    const trackDisabled = (roccTracks: RoccTracks, participant: RoccRemoteParticipant) => {
        if (roccTracks.kind === ETrackKind.AUDIO) {
            props.updateRemoteAudioTrackStatus(false, participant)
        } else if (roccTracks.kind === ETrackKind.VIDEO) {
            props.setRemoteUserVideoStatus(false)
        }
    }

    const trackSubscribed = (roccTracks: RoccTracks, participant: RoccParticipant) => {
        const newUserPreviewContainer = props.remoteMediaRef.current
        const deviceId = audioOutputRef.current ? audioOutputRef.current : DEFAULT
        if (newUserPreviewContainer) {
            if (roccTracks.kind === ETrackKind.AUDIO) {
                vendorService.attachContainer(participant, newUserPreviewContainer, deviceId)
            } else {
                vendorService.attachContainer(participant, newUserPreviewContainer)
            }
        }
        if (roccTracks.kind === ETrackKind.VIDEO) {
            vendorService.initializeTracks(roccTracks, getRemoteTracksEvents())
        }

    }

    const trackUnsubscribed = (track: RoccAVTrack, participant: RoccParticipant) => {
        infoLogger(`AudioVideoParticipants.tsx: Participant ${vendorService.getParticipantIdentity(participant)} unsubscribed the track for User ${currentUser.uuid} 
        with contextId: ${activeCallDetailsRef.current.contextId}`)
        vendorService.detachAVTrack([track])
    }

    const participantConnected = async (participant: RoccRemoteParticipant) => {
        const contextDetails = await getContextDetails(activeCallDetailsRef.current.contextId, currentUserRef.current, urls.COMMUNICATION_SERVICES_URL)
        let secondaryUUID = ""
        contextDetails.data.participants.forEach((contextParticipant: IParticipantObject) => {
            if (contextParticipant.primaryUuid === participant.identity && contextParticipant.secondaryUUID) {
                secondaryUUID = contextParticipant.secondaryUUID.length ? contextParticipant.secondaryUUID[0] : ""
            }
        })

        const participantIdentity = vendorService.getParticipantIdentity(participant)

        const newParticipantIndex = activeCallDetailsRef.current.participants.findIndex(
            (addedParticipant: any) => addedParticipant.uuid === participantIdentity)

        if (newParticipantIndex >= 0) {
            activeCallDetailsRef.current.participants[newParticipantIndex].callStatus = CALL_ACCEPT
            infoLogger(`AudioVideoParticipants.tsx : Participant ${participant.identity} joined the call 
            for contextId: ${activeCallDetailsRef.current.contextId}`)
        } else {
            const roomDetails = getCustomrReducerFromGlobalStore().rooms
            const details = await getDetailsByUUID(participant.identity, contacts, roomDetails)
            if (secondaryUUID !== "") {
                const techDetails = await getDetailsByUUID(secondaryUUID)
                details.secondaryUUID = techDetails.uuid
                details.secondaryName = techDetails.name
            }
            details.callStatus = CALL_ACCEPT
            activeCallDetailsRef.current.participants.push(details)
        }
        if (activeCallDetailsRef.current.participants.length === 2) {
            activeCallDetailsRef.current.isFirstParticipant = true
        }

        if (secondaryUUID !== "") {
            const newParticipantList = activeCallDetailsRef.current.participants.filter((callParticipant: any) => callParticipant.uuid !== secondaryUUID)
            activeCallDetailsRef.current.participants = newParticipantList
        }
        const newCallDetails = { ...activeCallDetailsRef.current, numOfParticipants: activeCallDetailsRef.current.participants.length }
        updateCallDetails(newCallDetails, dispatch, true)

        if (activeCallDetailsRef.current.isDeafened) {
            vendorService.detachRemoteParticipantTracks(participant, ["audio"])
        } else {
            vendorService.attachRemoteParticipantTrackKinds(participant, props.remoteMediaRef.current, ["audio"])
        }

        if (newCallDetails.participants.length > 1) {
            sendLogsToAzure({ contextData: { component, event: P2P_TO_MPC_EVENT } })
        }
    }

    const participantDisconnected = (participant: RoccRemoteParticipant) => {
        vendorService.detachLocalParticipant(activeRoomRef.current)

        const participantIdentity = vendorService.getParticipantIdentity(participant)

        const newParticipantList = activeCallDetailsRef.current.participants.filter((callParticipant: any) => callParticipant.uuid !== participantIdentity)
        activeCallDetailsRef.current.participants = [...newParticipantList]
        activeCallDetailsRef.current.numOfParticipants = newParticipantList.length
        infoLogger(`AudioVideoParticipants.tsx : Participant ${participantIdentity} leave the call
        with contextId: ${activeCallDetailsRef.current.contextId}`)

        updateCallDetails(activeCallDetailsRef.current, dispatch, true)
        if (newParticipantList.length === 1) {
            sendLogsToAzure({ contextData: { component, event: `MPC: Web to Web Call: Call Disconnected: ${MPC_TO_P2P_EVENT}`, Event_By: `${participantIdentity}` } })
        } else if (newParticipantList.length > 1) {
            sendLogsToAzure({ contextData: { component, event: "MPC: Web to Web Call: Call Disconnected", Event_By: `${participantIdentity}` } })
        } else if (newParticipantList.length === 0) {
            sendLogsToAzure({ contextData: { component, event: "P2P: Web to Web Call: Call Disconnected", Event_By: `${participantIdentity}` } })
        }
        if (dominantSpeakerRef.current.uuid === participantIdentity && activeCallDetailsRef.current.participants.length) {
            props.setDominantSpeaker(activeCallDetailsRef.current.participants[0])
        }
    }

    return <></>
}

export default AudioVideoParticipants
