import React, { useRef, useEffect, useState } from "react";
import howtousesystem from "../../../../assets/images/how-to-use-system.png";
import whatisassethealthcare from "../../../../assets/images/what-is-asset-health-care.png";
import HowToUseThisSystemIllustration from "../../../../assets/images/HowToUseThisSystemIllustration.svg";
import whatIsTheAssetHealthCareIllustration from "../../../../assets/images/whatIsTheAssetHealthCareIllustration.svg";
const AmpHome = () => {
	return (
		<div id="asset-management">
			<div className="common-box-inner custgap">
				<div className="title"> What is ASSET HEALTHCARE ?</div>
				<div className="howsystem1">
					<div>
						<p>
							Asset Healthcare initiative is built on the latest advancement in
							Artificial intelligence (AI) and Machine Learning (ML) in a way
							that leverages historical data available in SABIC’s Manufacturing
							Big Data Platform.
						</p>
						<p>
							It aims to predict potential equipment failures ahead of time. It
							complements existing manufacturing excellence systems in order to
							improve asset reliability, reduce unplanned outages and increase
							asset useful life.{" "}
						</p>
					</div>
					<img src={HowToUseThisSystemIllustration} />
				</div>
			</div>
			<div className="common-box-inner howsystem1">
				<div className="title">HOW TO USE THIS SYSTEM?</div>
				<div className="howsystem">
					<p>
						You can easily use this platform to provide feedback about AHC
						alerts where Digitalization Champion will review the alert and
						either provide feedback himself or forward the alert to another
						department for their feedback.
					</p>
					<img src={whatIsTheAssetHealthCareIllustration} />
				</div>
			</div>
		</div>
	);
};
export default AmpHome;
