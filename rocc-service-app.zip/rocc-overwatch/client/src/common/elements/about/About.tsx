/**
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner. 
 * 
 **/

import React from "react"
import { Modal } from "semantic-ui-react"
import Caution from "assets/images/caution.svg"
import FactoryFilled from "assets/images/factoryFilled.svg"
import IFU from "assets/images/ifu.svg"
import Logo from "assets/images/logo.svg"
import SVG from "react-inlinesvg"
import { useSelector } from "react-redux"
import "./About.scss"
import { IStore } from "redux/interfaces/types"

interface IAboutProps {
  isModalOpen: boolean
  closeModal: () => void
  companyName: string
  applicationTitle: string
}

const About = (props: IAboutProps) => {
  const { companyName, isModalOpen, closeModal, applicationTitle } = props
  const { version } = useSelector((state: IStore) => ({
    version: state.appReducer.configs.APP_VERSION,
  }))

  return (
    <>
      <Modal className={"aboutModal"} open={isModalOpen} onClose={closeModal} closeIcon={"Cross huge"} >
        <div className={"container"}>
          <div id={"logo"} className={"logo"}>
            <SVG src={Logo} />
          </div>

          <div className={"appName"}>
            {companyName} <br />
            {applicationTitle}
          </div>
          <div className={"version"}>

            {"Version"}{" "}{version}
          </div>

          <div className={"copyright"}>
            {"© Koninklijke Philips N.V. 2021. All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means, electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner."}
            <br />
            {"Copyrights and all other proprietary rights in any software and related documentation (“Software”) made available to you rest exclusively with Philips or its licensors. No title or ownership in the Software is conferred to you. Use of the Software is subject to the end user license conditions as are available on request."}
            <br />
            {"To the maximum extent permitted by law, you shall not decompile and/or reverse engineer the software or any part thereof."}
            <br />
            {"Not for diagnostic, monitoring or therapeutic purposes or in any other manner for regular medical practice."}
          </div>

          <br /> <br />

          <div className={"addressContainer"}>
            <SVG src={FactoryFilled} />
            <div className={"address"}>
              <span>
                {"Philips North America LLC"}
              </span>
              <span>
                {"Cambridge Crossing"}
              </span>
              <span>
                {"222 Jacobs Street"}
              </span>
              <span>
                {"Cambridge MA 02141"}
              </span>
            </div>
          </div>

          <div id={"aboutFooter"} className={"footer"} >
            <SVG className={"ifuIcon"} src={IFU} />
            <SVG className={"cautionIcon"} src={Caution} />
          </div>
        </div>
      </Modal>
    </>
  )
}

export default About
