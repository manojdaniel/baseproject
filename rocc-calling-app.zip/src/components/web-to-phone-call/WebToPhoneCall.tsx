/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useRef, useState } from "react"
import en from "../../resources/translations/en-US"
import { useDispatch, useSelector } from "react-redux"
import { Device, Connection } from "twilio-client"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { CALL_FAILED } from "../../constants/constants"
import { setCallMessage, setPhoneCallStatus } from "../../redux/actions/callActions"
import { IStore } from "../../redux/interfaces/types"
import { fetchGlobalConfigs, fetchGlobalURLs } from "../../redux/store/externalAppStates"
import { audioCallService } from "../../services/callServices"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { CallEnd } from "@rocc/rocc-calling-components"
import IntermediateCallWindow from "../intermediate-call-window/IntermediateCallWindow"
import { EClinicalRole, ECallStatus } from "@rocc/rocc-client-services"
import { getRoleName, getTranslatedCallType } from "../../common/helpers/helpers"

const WebToPhoneCall = () => {

    const [device] = useState(new Device())
    const contextIdRef = useRef("")

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const [callMsg, setCallMsg] = useState(intl.formatMessage({ id: "content.outgoingCall.calling", defaultMessage: en["content.outgoingCall.calling"] }))

    const { callStatus, recipient, currentUser } = useSelector((state: IStore) => ({
        callStatus: state.callReducer.phoneCallStatus,
        recipient: state.callReducer.recipient,
        currentUser: state.externalReducer.currentUser,
    }))

    const phoneNumber = recipient.selectedPhoneNumber || recipient.phoneNumber

    const initiatePhoneCall = async () => {
        const urls = fetchGlobalURLs()
        const params = {
            accessToken: currentUser.accessToken, currentUserUuid: currentUser.uuid,
            phoneNumber,
            communicationServiceUrl: urls.COMMUNICATION_SERVICES_URL,
        }
        const response = await audioCallService(params)
        if (response.success) {
            const { capabilityToken, contextId } = response.data
            contextIdRef.current = contextId
            setupDevice(capabilityToken)
        } else {
            handleFailedCall()
        }
    }

    useEffect(() => {
        if (callStatus === ECallStatus.CALLING && recipient.uuid) {
            initiatePhoneCall()
        }
    }, [callStatus])

    useEffect(() => {
        return (() => {
            disconnectCall()
        })
    }, [])

    const disconnectCall = async () => {
        contextIdRef.current = ""
        if (device) {
            if (device.audio) {
                device.audio.unsetInputDevice()
            }
            if (device.isInitialized) { device.disconnectAll() }
        }
        dispatch(setPhoneCallStatus(ECallStatus.IDLE))
    }

    const handleFailedCall = () => {
        dispatch(setCallMessage({
            messageType: getTranslatedCallType(CALL_FAILED),
            message: intl.formatMessage({ id: "content.callMessage.callFailed", defaultMessage: en["content.callMessage.callFailed"] }),
            contact: recipient
        }))
        disconnectCall()
    }

    const setupDevice = async (token: string) => {
        try {
            const config = fetchGlobalConfigs()
            if (device) {
                device.setup(token, {
                    enableRingingState: true,
                    enableIceRestart: true,
                    codecPreferences: [Connection.Codec.Opus, Connection.Codec.PCMU],
                    edge: config.EDGE_LOCATION,
                })
                if (device.audio) {
                    device.audio.setAudioConstraints({
                        echoCancellation: true,
                    })

                }

                device.once("ready", establishCall)
                device.on("cancel", disconnectCall)
                device.on("error", (error: Error) => {
                    errorLogger(`Error occured while setting input device: ${errorParser(error)}`)
                    disconnectCall()
                })
                device.on("disconnect", disconnectCall)
            }
        } catch (error) {
            errorLogger(`Exception occured while setting device for Audio call: ${errorParser(error)}`)
            handleFailedCall()
        }
    }

    const establishCall = () => {
        try {
            setCallMsg("")
            const connection = device.connect({ contextId: contextIdRef.current })
            connection.once("disconnect", (connection: Connection) => {
                connection.disconnect()
            })
            dispatch(setPhoneCallStatus(ECallStatus.CONNECTED, recipient))
        } catch (error) {
            errorLogger(`Exception occurred while establishing WebToPhone call : ${errorParser(error)}`)
            handleFailedCall()
        }
    }

    const isSecondaryUser = !!recipient.secondaryName

    return (
        <IntermediateCallWindow
            displayName={isSecondaryUser ? recipient.secondaryName : recipient.name}
            metaData={isSecondaryUser ? getRoleName(EClinicalRole.TECHNOLOGIST) : getRoleName(recipient.clinicalRole)}
            description={callStatus === ECallStatus.CALLING ? recipient.description : phoneNumber}
            callMessage={callMsg}
            callWindowFullscreen={false}
            additionalComponent={() => <CallEnd onClick={disconnectCall} />}
        />
    )
}

export default WebToPhoneCall
