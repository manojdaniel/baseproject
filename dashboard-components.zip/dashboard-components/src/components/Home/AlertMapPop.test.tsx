import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AlertMapPop from "./AlertMapPop";

describe("AlertMapPop component", () => {
	const alertmapPopData = {
		Name: "test",
		HealthIndex: 75,
		Active: 10,
		OverDue: 5,
		PmCompliance: 90,
		UnderInvestigation: 2,
	};

	it("renders the component with the correct props", () => {
		const { getByText } = render(
			<AlertMapPop alertmapPopData={alertmapPopData} />
		);

		expect(
			getByText(`OVERALL ${alertmapPopData.Name.toUpperCase()}`)
		).toBeInTheDocument();
		expect(getByText(`${alertmapPopData.HealthIndex}%`)).toBeInTheDocument();
		expect(getByText("HEALTH INDEX")).toBeInTheDocument();
		expect(getByText(`${alertmapPopData.Active}`)).toBeInTheDocument();
		expect(getByText("ACTIVE")).toBeInTheDocument();
		expect(getByText(`${alertmapPopData.OverDue}`)).toBeInTheDocument();
		expect(getByText("OVERDUE INVESTIGATION")).toBeInTheDocument();
		expect(getByText(`${alertmapPopData.PmCompliance}`)).toBeInTheDocument();
		expect(getByText("PM COMPLIANCE")).toBeInTheDocument();
		expect(
			getByText(`${alertmapPopData.UnderInvestigation}`)
		).toBeInTheDocument();
		expect(getByText("UNDER INVESTIGATION")).toBeInTheDocument();
		expect(getByText("4")).toBeInTheDocument();
		expect(getByText("SPARES AVAILABILITY")).toBeInTheDocument();
	});
});
