/*
 * Created on Mon Nov 29 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, EConnectionMode, EConnectionState, EOperationStatus, ETransactionStatus, TransactionValue } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { resetConsoleSession, setConsoleOperations, updateConsoleSession } from "../../../redux/actions/consoleActions"
import { IConsoleTransaction, IStore } from "../../../redux/interfaces/types"
import { MEDIA_ROOM_FAILED } from "../../constants/constants"
import { checkIfPresignedJwtFeatureEnabled, fetchBackwardTransition, getEditSessionRevokedMessage, handleAppUri } from "../../helpers/consoleUtility"
import { checkIfCleanUpTaskInProgress, displayEditToViewSwitchMessage, fetchActiveTransactionIndex, fetchAllEditConsoleType, generateUniqueId } from "../../helpers/helpers"
import { validateAuthToken } from "../../helpers/jwtUtility"
import { trackConsoleDisconnection, transformSessionTypeForAnalytics } from "../../helpers/TelemetryTrackingHelper"

interface IConsoleMessageHandler {
    contextId: string
    consoleConnectionStatus: string
    userId: string
    // TODO: [MARKER] Remove optional modifier before merge
    jwtToken?: string
}

const ConsoleMessageHandler = (props: IConsoleMessageHandler) => {

    const { consoleOperation, currentUser, consoleSessions } = useSelector((state: IStore) => ({
        consoleOperation: state.consoleReducer.consoleOperation,
        currentUser: state.externalReducer.currentUser,
        consoleSessions: state.consoleReducer.consoleSessions,
    }))
    const componentName = "Console Message Handler"
    const dispatch = useDispatch()

    const { APPROVED, REJECTED, FAILED, CONSOLE_CLOSE, ASSOCIATE_COMPLETED, FORCE_CONSOLE_CLOSE, FORCE_EDIT_CONSOLE_CLOSE } = EConnectionState

    // TODO: [MARKER] Remove optional modifier after merge to master 
    const handleApprovedState = async (jwtToken?: string) => {
        // Fetch currently active transaction and check if contextId is same or not
        // If contextId matches, then update the transaction status to finished
        // If Rejected, then update the transaction status to rejected 
        const { operationStatus, transactions, operationId } = consoleOperation
        const { contextId } = props
        if (operationStatus === EOperationStatus.RUNNING) {
            const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
            if (activeTransactionIndex > -1 && transactions[activeTransactionIndex].contextId === contextId) {
                const activeTransaction = transactions[activeTransactionIndex]
                const { roomUuid, connectionMode } = activeTransaction

                // TODO: [MARKER] Remove feature flag check and jwtToken default to empty string (should be handleable at runtime) on merge to master
                if (checkIfPresignedJwtFeatureEnabled() && !validateAuthToken(jwtToken ?? "", roomUuid)) {
                    // NOTE: [MARKER] Check if failing at this step needs some other UI side-effects
                    sendLogsToAzure({
                        contextData: {
                            component: `${componentName}: Received request coming in from technologisy could not be validated`,
                            event: `Failed: ${roomUuid}`, source: transformSessionTypeForAnalytics(connectionMode), Call_From: currentUser.uuid, Call_To: roomUuid
                        }
                    })
                    errorLogger(`Auth token validation failed.`)

                    transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FAILED
                    dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))

                    // TODO: [MARKER] Insert a modal UI for showing that attempt has failed and needs to be tried again

                    return
                }

                sendLogsToAzure({
                    contextData: {
                        component: `${componentName}: Control console request approved by technologist`,
                        event: `Approved: ${roomUuid}`, source: transformSessionTypeForAnalytics(connectionMode), Call_From: currentUser.uuid, Call_To: roomUuid
                    }
                })
                infoLogger(`Console connection request for contextId ${props.contextId} is approved for operationId ${operationId}  for user ${currentUser.uuid}`)
                transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
                dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
            } else {
                errorLogger(`Failed to find any active operation for contextId ${props.contextId} for user ${currentUser.uuid}`)
            }
        }
    }

    const handleRejectedState = () => {
        const { operationStatus, transactions, operationId } = consoleOperation
        const { contextId } = props
        if (operationStatus === EOperationStatus.RUNNING) {
            const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
            if (activeTransactionIndex > -1 && transactions[activeTransactionIndex].contextId === contextId) {
                infoLogger(`Console connection request for contextId ${props.contextId} is cancelled for operationId ${operationId}  for user ${currentUser.uuid}`)
                transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
                dispatch(setConsoleOperations({ ...consoleOperation, operationStatus: EOperationStatus.REJECTED, transactions: [...transactions] }))
            } else {
                errorLogger(`Failed to find any active operation for contextId: ${props.contextId} for user ${currentUser.uuid}`)
            }
        }
    }

    const handleFailedState = () => {
        // Check in console transaction and console session if there is any session and update the status accordingly
        const { operationStatus, transactions, operationId } = consoleOperation
        const { contextId } = props
        if (operationStatus === EOperationStatus.RUNNING) {
            const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
            if (activeTransactionIndex > -1 && transactions[activeTransactionIndex].contextId === contextId) {
                infoLogger(`OperationId ${operationId} failed for user ${currentUser.uuid}`)
                transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FAILED
                dispatch(setConsoleOperations({ ...consoleOperation, operationStatus: EOperationStatus.FAILED, transactions: [...transactions] }))
            }
        } else {
            // Check if console session is present for the contextId
            const activeSessions = consoleSessions.filter(session => session.contextId !== contextId)
            dispatch(resetConsoleSession({ consoleSessions: activeSessions, isFailed: true }))
        }
    }

    const handleDisconnectedConsoleAccess = async (forceRevoke?: boolean) => {
        const { contextId, userId } = props
        const transaction = consoleOperation.transactions.find(transaction => transaction.contextId === contextId)
        if (!(checkIfCleanUpTaskInProgress(consoleOperation) || transaction)) {
            const activeSessionsToDisconnectIndex = consoleSessions.findIndex(session =>
                session.contextId === contextId && fetchAllEditConsoleType().includes(session.connectionType))
            if (activeSessionsToDisconnectIndex > -1) {
                const activeSessionsToDisconnect = consoleSessions[activeSessionsToDisconnectIndex]
                const { roomUuid, connectionType, connectionMode, consoleStartTime } = activeSessionsToDisconnect
                if (userId !== currentUser.uuid) {
                    await getEditSessionRevokedMessage(userId || roomUuid)
                    const trackParam = { connectionType, connectionMode, roomUuid, consoleStartTime, requester: currentUser.uuid, componentName: componentName, isRevoked: true }
                    trackConsoleDisconnection(trackParam)
                }
                const transactions: IConsoleTransaction[] = []
                const isConsoleSwitching = fetchBackwardTransition(activeSessionsToDisconnect, transactions)
                if (isConsoleSwitching) { displayEditToViewSwitchMessage() }

                if (transactions.length) {
                    if (connectionMode === EConnectionMode.EMERALD) {
                        transactions.unshift({
                            transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType, connectionMode,
                            connectionStatus: TransactionValue.STOP_EMERALD_APP, receiverName: "", contextId, transactionId: generateUniqueId(), groupId: generateUniqueId(),
                        })
                    }
                    activeSessionsToDisconnect.connectionStatus = EConnectionState.IN_TRANSITION_STATE
                    dispatch(updateConsoleSession(activeSessionsToDisconnect, true))
                    dispatch(setConsoleOperations({ operationId: generateUniqueId(), operationStatus: EOperationStatus.RUNNING, transactions }))
                    return
                }
                if (connectionMode === EConnectionMode.EMERALD) {
                    handleAppUri({
                        roomUuid, connectionState: TransactionValue.STOP_EMERALD_APP, contextId,
                        consoleSessions, accessToken: currentUser.accessToken
                    })
                }
                dispatch(updateConsoleSession(activeSessionsToDisconnect, false))
            }
        } else if (forceRevoke && transaction) {
            await getEditSessionRevokedMessage(userId)
            infoLogger(`Revoke modal shown for session already ended with ${userId}`)
            sendLogsToAzure({
                contextData: {
                    component: componentName, event: `revoke modal shown`,
                    Call_To: userId, Call_From: currentUser.uuid, Event_By: currentUser.uuid
                }
            })
        }
    }

    const handleMediaRoomFailure = () => {
        const { contextId } = props
        const consoleSession = consoleSessions.find(session => session.contextId === contextId)
        if (consoleSession) {
            infoLogger(`Updating media room creation status for console sesion ${consoleSession.contextId}`)
            const { cameraStreamAvailable } = consoleSession.mediaRoomDetails
            if (cameraStreamAvailable === ECameraStreamAvailable.NOT_AVAILABLE) {
                consoleSession.mediaRoomDetails.cameraStreamAvailable = ECameraStreamAvailable.MEDIA_ROOM_FAILED
                dispatch(updateConsoleSession(consoleSession, true))
            }
        }
    }

    const handleMessageChange = () => {
        switch (props.consoleConnectionStatus) {
            case ASSOCIATE_COMPLETED:
            case APPROVED:
                handleApprovedState(props.jwtToken)
                break
            case REJECTED:
                handleRejectedState()
                break
            case FAILED:
                handleFailedState()
                break
            case CONSOLE_CLOSE:
                handleDisconnectedConsoleAccess(false)
                break
            case FORCE_CONSOLE_CLOSE:
            case FORCE_EDIT_CONSOLE_CLOSE:
                handleDisconnectedConsoleAccess(true)
                break
            case MEDIA_ROOM_FAILED:
                handleMediaRoomFailure()
                break
            default:
        }
    }

    useEffect(() => {
        handleMessageChange()
    }, [props.contextId, props.consoleConnectionStatus, props.jwtToken])

    return (<></>)
}

export default ConsoleMessageHandler
