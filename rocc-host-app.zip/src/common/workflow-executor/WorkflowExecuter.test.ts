/*
 * Created on Thu Jun 16 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoccWorkflow, IWorkflow, WorkflowEvent } from "@rocc/rocc-client-services"
import { applyEvent } from "./WorkflowExecutor"


const mockWorkflow = {
    id: "selector",
    type: ERoccWorkflow.PARK_AND_INITIATE_CALL,
    workflow: {} as IWorkflow["workflow"],
    state: {} as IWorkflow["state"],
    eventQueue: [],
}

jest.mock("react-redux", () => ({
    useSelector: () => ({
        workflows: [
            {
                id: "selector",
                type: ERoccWorkflow.PARK_AND_INITIATE_CALL,
                workflow: {} as IWorkflow["workflow"],
                state: {} as IWorkflow["state"],
                eventQueue: []
            }
        ]
    }),
    useDispatch: () => void (0),
}))

jest.mock("../../utility/helpers/helpers", () => ({
    getMappedDependency: () => jest.fn(),
}))
jest.mock("react", () => ({
    useEffect: () => jest.fn(),
}))

describe("Unit tests for NavbarHelpers ", () => {
    it("should call function handleProtocolTransferExit with props as true", () => {
        expect(applyEvent(mockWorkflow, {} as WorkflowEvent)).toBeUndefined()
    })
})
