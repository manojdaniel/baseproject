/*
 * Created on Thu Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { DEFAULT_CONTACT_INFO, DEFAULT_ROOM_DETAILS, EClinicalRole } from "@rocc/rocc-client-services"
import { SubscribeToPresence } from "./SubscribeToPresence"


const testState = {
    userReducer: {
        currentUser: { ...DEFAULT_CONTACT_INFO, uuid: "uuid", accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US" },
        contacts: [{ ...DEFAULT_CONTACT_INFO, uuid: "uuid" }],
        contactsFetched: true,
    },
    customerReducer: {
        rooms: [{ ...DEFAULT_ROOM_DETAILS, identity: { uuid: "uuid" } }]
    },
    configReducer: {
        configs: {}
    },
    clientStatusReducer: {
        applicationConnectionState: "ONLINE",
    }
}

jest.mock("react-redux", () => ({
    useDispatch: jest.fn().mockReturnValue(jest.fn),
    useSelector: jest.fn(),
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const syncClient: any = {
    map: jest.fn().mockReturnValue({
        on: jest.fn(),
        get: jest.fn().mockReturnValue({
            descriptor: {
                data: {
                    presence: EUserPresence.OFFLINE,
                    loggedInTech: ""
                }
            }
        })
    })
}

const props = {
    subjects: [{
        uuid: "uuid",
        syncMapId: "syncMapId",
        subscribed: false,
        type: EClinicalRole.DEVICE
    }, {
        uuid: "uuid",
        syncMapId: "syncMapId",
        subscribed: false,
        type: EClinicalRole.EXPERTUSER
    }],
    updateSubscribedState: jest.fn(),
    syncClient

}

describe("should render SubscribeToPresence component", () => {
    beforeEach(() => {
        useSelectorMock(testState)
    })

    it("should render Fragment", () => {
        withHooks(() => {
            const wrapper = shallow(<SubscribeToPresence {...props} />)
            expect(wrapper.find("Fragment")).toBeDefined()
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
