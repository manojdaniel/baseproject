import React from "react";
import { Table } from "antd";
import "../../assets/common/CommonTables.scss";

interface Props {
    data: any[];
}
const UserRoleMappingTable = ({ data }: Props) => {
    const columns = [
        {
            title: "NAME",
            dataIndex: "name",
            key: "name",
            width: '20%'
        },
        {
            title: "AFFILIATE",
            dataIndex: "affiliate",
            key: "affiliate",
            width: '20%'
        },
        {
            title: "PLANT",
            dataIndex: "plant",
            key: "plant",
            width: '20%'
        },
        {
            title: "EDIT",
            dataIndex: "edit",
            key: "edit",
            width: '10%'
        }
    ];

    return (
        <>
            <Table
                columns={columns}
                dataSource={data}
                pagination={{ pageSize: 10, showSizeChanger: false }}
                scroll={{ x: true }}
            />

        </>
    );
}
export default UserRoleMappingTable;
