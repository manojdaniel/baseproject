"""
 Created on Fri Apr 29 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest import mock

from src.wrappers.infrastructure_services.policy_services.manage_policy_services import create_policy, create_scope_policy
from tests.mocks.mock_requests import MOCK_URL, MockResponse


def mocked_requests(*args, **kwargs):
    policy_create_response = {"id": "v1", "data": "v2"}
    switcher = {
        f"{MOCK_URL}/authorize/access/Policy": MockResponse(policy_create_response, 201),
        f"{MOCK_URL}_409/authorize/access/Policy": MockResponse(None, 409),
        f"{MOCK_URL}_422/authorize/access/Policy": MockResponse(None, 422)
    }
    mocked_response = switcher.get(args[0], MockResponse(None, 200))
    if len(kwargs):
        pass
    return mocked_response


class TestPolicyServices(unittest.TestCase):
    @mock.patch("src.wrappers.infrastructure_services.policy_services.manage_policy_services.requests.post", side_effect=mocked_requests)
    def test_create_policy(self, m_post):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="", VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_policy(token="", profile_configs=profile_configs)
        self.assertEqual("v1", actual)
        m_post.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.policy_services.manage_policy_services.requests.post", side_effect=mocked_requests)
    def test_create_policy_409(self, m_post):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="", VAULT_EVAL_APP_ID="", HSDP_IDM_URL=f"{MOCK_URL}_409")
        actual = create_policy(token="", profile_configs=profile_configs)
        self.assertIsNone(actual)
        m_post.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.policy_services.manage_policy_services.requests.post", side_effect=mocked_requests)
    def test_create_policy_422(self, m_post):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="", VAULT_EVAL_APP_ID="", HSDP_IDM_URL=f"{MOCK_URL}_422")
        actual = create_policy(token="", profile_configs=profile_configs)
        self.assertFalse(actual)
        m_post.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.policy_services.manage_policy_services.requests.post",
                side_effect=mocked_requests)
    def test_create_scope_policy(self, m_post):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="", VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_scope_policy(token="", profile_configs=profile_configs)
        self.assertEqual("v1", actual)
        m_post.assert_called()


suite = unittest.TestSuite()

suite.addTest(TestPolicyServices("test_create_policy"))
suite.addTest(TestPolicyServices("test_create_policy_409"))
suite.addTest(TestPolicyServices("test_create_policy_422"))
suite.addTest(TestPolicyServices("test_create_scope_policy"))

unittest.TextTestRunner(verbosity=0).run(suite)
