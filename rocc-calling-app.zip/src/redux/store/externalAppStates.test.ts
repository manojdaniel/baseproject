/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { USER_REDUCER } from "../../constants/constants"
import globalStore from "./globalStore"
import { fetchGlobalConfigs, fetchGlobalFeatureFlags, fetchGlobalOrgUUID, fetchGlobalURLs, getGlobalStoreDetails } from "./externalAppStates"

jest.mock("../../redux/store/globalStore", () => ({ GetGlobalState: jest.fn() }))

describe("getGlobalStoreDetails tests", () => {
    it("get specific reducer value", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    currentUser: {
                        name: "Dummy user",
                        uuid: "uuid"
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(getGlobalStoreDetails({ storeName: "CC_HOST", reducerPath: USER_REDUCER }).currentUser.uuid).toBe("uuid")
    })

    it("should fetch global URLS", () => {
        const storeData = {
            CC_HOST: {
                configReducer: {
                    urls: {
                        IAM_SERVICES_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        COMMUNICATION_SERVICES_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        CONSOLE_SERVICES_URL: "https://INGBTCPIC6VL128.code1.emi.philips.com:8498/philips/rocc",
                        PROXY_URL: "https://platinum-rocc.cloud.pcftest.com",
                        MANAGEMENT_SERVICE_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        GRAPHQL_API_HSDP_URI: "https://platinum-rocc.cloud.pcftest.com/v1/graphql",
                        GRAPHQL_API_HSDP_WS_URI: "wss://platinum-rocc.cloud.pcftest.com:4443/v1/graphql",
                        RBAC_SERVICE_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc"

                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalURLs()).toBe(storeData.CC_HOST.configReducer.urls)
    })

    it("should fetch global feature flags", () => {
        const storeData = {
            CC_HOST: {
                featureFlagsReducer: {
                    featureFlags: {
                        "rocc-emerald": false,
                        "rocc-emerald-edit": true,
                        "rocc-emerald-view": true,
                        "rocc-multi-camera": false,
                        "rocc-multi-console": false,
                        "rocc-patient-details-visibility": true,
                        "rocc-protocol-transfer": true,
                        "rocc-radconnect": true,
                        "rocc-scheduler": false,
                        "rocc-self-service": false,
                        "rocc-vnc": false
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalFeatureFlags()).toBe(storeData.CC_HOST.featureFlagsReducer.featureFlags)
    })

    it("should fetch global Org Id", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    metaData: {
                        id: -1,
                        displayName: "",
                        name: "",
                        orgId: "e9101b82-493c-40df-b539-d605732ffbb4",
                        contacts: []


                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalOrgUUID()).toBe(storeData.CC_HOST.customerReducer.metaData.orgId)
    })

    it("should fetch global configs", () => {
        const storeData = {
            CC_HOST: {
                configReducer: {
                    configs: {
                        ROCC_DEV: "true"
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalConfigs()).toBe(storeData.CC_HOST.configReducer.configs)
    })

})
