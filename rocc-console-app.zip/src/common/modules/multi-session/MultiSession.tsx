/*
 * Created on Fri May 20 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, EConnectionState, EConnectionType, getDetailsByUUID, getLocationDetailsForId, getRoomDetailFromUuid, IAVCallDetails, IConsoleSession, parseIntBase10 } from "@rocc/rocc-client-services"
import { EMultiCallWithEditStatus, EMultiSessionModalNextAction, IOngoingSessionDetails, MultiEditSessionModal, ParkEditSessionModal } from "@rocc/rocc-console-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { IStore } from "../../../redux/interfaces/types"
import { fetchGlobalContacts, fetchGlobalCurrentUser, fetchGlobalLocations, fetchRooms } from "../../../redux/store/externalAppStates"
import { DEFAULT_ONGOING_CALL_DETAILS, EDIT_STATUS, VIEW_STATUS } from "../../constants/constants"
import { checkIfMultiAudioFeatureEnabled, checkIfMultiEditWithoutParkResumeFeatureEnabled, registerToggleCallControlWorkflow } from "../../helpers/consoleUtility"
import { checkIfParticipantPartOfCall, fetchAllEditConsoleType, fetchCallDetailsByContextId, getCallContextByContactUuid } from "../../helpers/helpers"
import omit from "lodash.omit"

const COMPONENT_NAME = "Switch Session"

export interface IMultiSessionProps {
    show: boolean,
    nextAction: EMultiSessionModalNextAction,
    contactUuid: string,
    receiverName: string,
    onConfirm: () => void,
    onCancel: () => void,
    setSelfProps: (content: IMultiSessionProps) => void
}

export type IOngoingSessionDetailsWithUuid = IOngoingSessionDetails & { roomUuid: string }

const MultiSession = (props: IMultiSessionProps) => {
    const { show, nextAction, contactUuid, receiverName, onConfirm, onCancel, setSelfProps } = props

    const { consoleSessions, receivers, callDetails } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        callDetails: state.externalReducer.callDetails,
    }))

    const [ongoingSessionDetails, setOnGoingSessionDetails] = useState([] as IOngoingSessionDetails[])

    const dispatch = useDispatch()

    const { ACTIVE, HOLD, PARKED, NOT_STARTED } = EMultiCallWithEditStatus
    const { INITIATE_CALL, INITIATE_SESSION, RESUME_SESSION, DISCONNECT_SESSION, DISCONNECT_CALL } = EMultiSessionModalNextAction

    const multiAudioFeature = checkIfMultiAudioFeatureEnabled()
    const multiEditWithoutParkAndResume = checkIfMultiEditWithoutParkResumeFeatureEnabled()

    const closeModal = () => {
        infoLogger(`Close park session modal by ${fetchGlobalCurrentUser().uuid}`)
        sendLogsToAzure({ contextData: { component: COMPONENT_NAME, event: "Park edit session : Cancel park modal", Event_By: fetchGlobalCurrentUser().uuid } })
        if (onCancel) {
            onCancel()
        }
        dispatch(setSelfProps({ ...props, show: false }))
    }

    const nextStateFor = (currentState: IOngoingSessionDetailsWithUuid) => {
        let callStatus: EMultiCallWithEditStatus
        let viewStatus: EMultiCallWithEditStatus
        let editStatus: EMultiCallWithEditStatus
        switch (nextAction) {
            case INITIATE_CALL:
                [callStatus, viewStatus, editStatus] = [ACTIVE, (VIEW_STATUS in currentState) ? currentState.viewStatus : NOT_STARTED, (EDIT_STATUS in currentState) ? currentState.editStatus : NOT_STARTED]
                break
            case INITIATE_SESSION:
            case RESUME_SESSION:
                [callStatus, viewStatus, editStatus] = [ACTIVE, ACTIVE, ACTIVE]
                break
            case DISCONNECT_SESSION:
                [callStatus, viewStatus, editStatus] = [ACTIVE, NOT_STARTED, NOT_STARTED]
                break
            case DISCONNECT_CALL:
                [callStatus, viewStatus, editStatus] = [NOT_STARTED, NOT_STARTED, NOT_STARTED]
                break
            default:
                [callStatus, viewStatus, editStatus] = [NOT_STARTED, NOT_STARTED, NOT_STARTED]
                break
        }

        return {
            ...currentState,
            callStatus,
            ...(VIEW_STATUS in currentState && { viewStatus }),
            ...(EDIT_STATUS in currentState && { editStatus }),
        }
    }

    const constructCallSessionObject = async (callDetails: IAVCallDetails) => {
        const room = await getDetailsByUUID(callDetails.participants[0]?.uuid || "", fetchGlobalContacts(), fetchRooms())
        return {
            current: false,
            enableCallControls: multiAudioFeature,
            callStatus: multiAudioFeature ? ACTIVE : HOLD,
            isMuted: callDetails.isMuted,
            isDeafened: callDetails.isDeafened,
            roomName: room.name,
            roomAddress: room.clinicalRole,
            location: room.siteId.length ? getLocationDetailsForId(fetchGlobalLocations(), parseIntBase10(room.siteId[0])).name : "",
            modality: room.modalities[0] || "",
            onMicrophoneClick: () => {
                registerToggleCallControlWorkflow({ callContextId: callDetails.contextId, componentName: COMPONENT_NAME, roomUuid: room.uuid, toggles: { muteStatus: !callDetails.isMuted } })
            },
            onSpeakerClick: () => {
                registerToggleCallControlWorkflow({ callContextId: callDetails.contextId, componentName: COMPONENT_NAME, roomUuid: room.uuid, toggles: { deafenStatus: !callDetails.isDeafened } })
            },
        }
    }

    const getEditStatusByConnectionType = (connectionType: EConnectionType, connectionStatus: EConnectionState) => {
        if (fetchAllEditConsoleType().includes(connectionType)) {
            return checkIfMultiEditWithoutParkResumeFeatureEnabled() ? ACTIVE : PARKED
        } else if (connectionStatus === EConnectionState.PARKED) {
            return PARKED
        }
        return NOT_STARTED
    }

    const constructOnGoingSessionObject = async (consoleSession: IConsoleSession, callDetails: IAVCallDetails) => {
        const { roomUuid, connectionType, connectionStatus } = consoleSession
        const room = getRoomDetailFromUuid(fetchRooms(), roomUuid)
        let callAndConsoleSessionObject = {
            roomUuid, roomName: room.identity.name, roomAddress: room.address, location: getLocationDetailsForId(fetchGlobalLocations(), room.locationId).name,
            modality: room.modality, receiverName: consoleSession.receiverName, viewStatus: ACTIVE,
            editStatus: getEditStatusByConnectionType(connectionType, connectionStatus),
            enableCallControls: false, callStatus: NOT_STARTED, isMuted: false, isDeafened: false, onMicrophoneClick: () => { "" }, onSpeakerClick: () => { "" },
        }
        if (callDetails.contextId) {
            callAndConsoleSessionObject = {
                ...callAndConsoleSessionObject,
                enableCallControls: multiAudioFeature,
                callStatus: multiAudioFeature ? ACTIVE : HOLD, isMuted: callDetails.isMuted, isDeafened: callDetails.isDeafened,
                onMicrophoneClick: () => {
                    registerToggleCallControlWorkflow({ callContextId: callDetails.contextId, componentName: COMPONENT_NAME, roomUuid: room.identity.uuid, toggles: { muteStatus: !callDetails.isMuted } })
                },
                onSpeakerClick: () => {
                    registerToggleCallControlWorkflow({ callContextId: callDetails.contextId, componentName: COMPONENT_NAME, roomUuid: room.identity.uuid, toggles: { deafenStatus: !callDetails.isDeafened } })
                },
            }
        }
        return callAndConsoleSessionObject
    }

    const getCallDetails = (consoleSession: IConsoleSession) => {
        const { connectionType, roomUuid, additionalData } = consoleSession
        const { VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT, INCOGNITO_VIEW } = EConnectionType
        let callDetails = DEFAULT_ONGOING_CALL_DETAILS
        switch (connectionType) {
            case VIEW:
            case PROTOCOL_MANAGEMENT:
            case INCOGNITO_VIEW:
                callDetails = getCallContextByContactUuid(roomUuid) || callDetails
                break
            case FULL_CONTROL:
                callDetails = fetchCallDetailsByContextId(additionalData?.callContextId) || callDetails
                break
            default:
        }
        return callDetails
    }

    const fetchOngoingSessionDetails = async () => {
        const { connectedCallDetails, onHoldCallDetails } = callDetails
        const { CALLDECLINED, CALLREJECT, DISCONNECTED, FAILED, NOT_ANSWERED, NOT_READY } = ECallStatus
        
        let activeCallDetails = [...onHoldCallDetails, connectedCallDetails].filter((callDetails: IAVCallDetails) => ![CALLDECLINED, CALLREJECT, DISCONNECTED, FAILED, NOT_ANSWERED, NOT_READY].includes(callDetails.callStatus))
        let ongoingSessionDetails: IOngoingSessionDetailsWithUuid[] = []

        let isSessionAvailable = false

        await Promise.all(consoleSessions.map(async session => {
            const callDetailForConsoleSession = getCallDetails(session)
            let onGoingSessionObject: any = await constructOnGoingSessionObject(session, callDetailForConsoleSession)
            if (session.roomUuid === contactUuid) {
                isSessionAvailable = true
                onGoingSessionObject.current = true
                onGoingSessionObject = nextStateFor(onGoingSessionObject)

                if (nextAction === EMultiSessionModalNextAction.DISCONNECT_SESSION) {
                    if (session.additionalData?.prevSessionDetails?.connectionType) {
                        onGoingSessionObject.viewStatus = ACTIVE
                    } else {
                        onGoingSessionObject = omit(onGoingSessionObject, ["receiverName", "viewStatus", "editStatus"])
                    }
                }
            }
            if (callDetailForConsoleSession.contextId) {
                activeCallDetails = activeCallDetails.filter((callDetails: IAVCallDetails) => callDetails.contextId !== callDetailForConsoleSession.contextId)
            }
            ongoingSessionDetails.push(onGoingSessionObject)
        }))
        Promise.resolve([])
        if (multiEditWithoutParkAndResume) {
            await Promise.all(activeCallDetails.map(async call => {
                if (call.contextId) {
                    let onGoingSessionObject: any = await constructCallSessionObject(call)
                    if (!checkIfParticipantPartOfCall(call, contactUuid)) {
                        ongoingSessionDetails.push(onGoingSessionObject)
                        return
                    }
                    isSessionAvailable = true
                    onGoingSessionObject.current = true
                    if (nextAction === EMultiSessionModalNextAction.INITIATE_SESSION) {
                        onGoingSessionObject = {
                            ...onGoingSessionObject,
                            receiverName, editStatus: ACTIVE, viewStatus: ACTIVE
                        }
                        ongoingSessionDetails = ongoingSessionDetails.map((session: any) => {
                            if (session.receiverName === receiverName) {
                                return omit(session, ["receiverName", "viewStatus", "editStatus"])
                            }
                            return session
                        }).concat(onGoingSessionObject)
                    } else {
                        ongoingSessionDetails.push(nextStateFor(onGoingSessionObject))
                    }
                }
            }))
            Promise.resolve([])
        }

        if (!isSessionAvailable) {
            const room = await getDetailsByUUID(contactUuid, fetchGlobalContacts(), fetchRooms())
            const nextSessionTemplate = {
                roomUuid: contactUuid,
                roomName: room.name,
                roomAddress: room.clinicalRole,
                location: room.siteId.length ? getLocationDetailsForId(fetchGlobalLocations(), parseIntBase10(room.siteId[0])).name : "",
                modality: room.modalities[0],
                current: true,
                enableCallControls: false,
                isMuted: connectedCallDetails.isMuted,
                isDeafened: connectedCallDetails.isDeafened,
                onMicrophoneClick: () => undefined,
                onSpeakerClick: () => undefined,
                callStatus: ACTIVE,
                ...(nextAction === EMultiSessionModalNextAction.INITIATE_SESSION && {
                    receiverName,
                    editStatus: ACTIVE,
                    viewStatus: ACTIVE,
                })
            }

            const nextSessionDetails = nextStateFor(nextSessionTemplate)
            if (nextAction === EMultiSessionModalNextAction.INITIATE_SESSION) {
                ongoingSessionDetails = ongoingSessionDetails.map((session: any) => {
                    if (session.receiverName === receiverName) {
                        return omit(session, ["receiverName", "viewStatus", "editStatus"])
                    }
                    return session
                }).concat(nextSessionDetails)
            } else {
                ongoingSessionDetails.push(nextSessionDetails)
            }
        }

        setOnGoingSessionDetails(ongoingSessionDetails)
    }

    useEffect(() => {
        fetchOngoingSessionDetails()
    }, [callDetails.connectedCallDetails, callDetails.onHoldCallDetails])

    return (
        multiEditWithoutParkAndResume ?
            <MultiEditSessionModal
                showModal={show}
                enableAudioControls={multiAudioFeature}
                ongoingSessionDetails={ongoingSessionDetails}
                receivers={receivers}
                closeModal={closeModal}
                handleContinue={onConfirm}
                showMultipleAudioWarning={checkIfMultiAudioFeatureEnabled()}
                nextAction={nextAction}
            /> : <ParkEditSessionModal
                showModal={show}
                enableAudioControls={multiAudioFeature}
                ongoingCallDetails={ongoingSessionDetails as any}
                closeModal={closeModal}
                handleContinue={onConfirm}
                showMultipleAudioWarning={nextAction === EMultiSessionModalNextAction.RESUME_SESSION ? false : ongoingSessionDetails.length > 1}
            />
    )
}

export default MultiSession
