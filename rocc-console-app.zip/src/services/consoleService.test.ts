/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as apiUtility from "../common/helpers/apiUtility"
import { EConnectionMode, EConnectionState, EConnectionType } from "@rocc/rocc-client-services"
import { consoleSwitchService, disconnectConsoleService, getActiveConnections, getCommandLineArgs, handleDisconnectFailure, initiateCCConsoleService, requestAuthorizationService, spokeNotQualifiedService, updateConsoleAuthorizationService } from "./consoleService"

jest.mock("@rocc/rocc-client-services", () => ({
    ...jest.requireActual("@rocc/rocc-client-services"),
    FeatureFlagHelper: {
        isFeatureEnabled: jest.fn().mockReturnValueOnce(true).mockReturnValue(false)
    }
}))

jest.mock("../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        CONSOLE_SERVICES_URL: "http://localhost",
        MANAGEMENT_SERVICE_URL: "http://localhost"
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        CONSOLE_DISCONNECT_DELAY: 3000,
    }),
    fetchGlobalCurrentUser: jest.fn().mockReturnValue({
        accessToken: "token",
    }),
    fetchGlobalFeatureFlags: jest.fn().mockReturnValue({
        "rocc-multi-kvm-vendor": "true"
    })
}))

jest.mock("../common/helpers/helpers", () => ({
}))

const getAxiosResponse = (data: any, responseCode: number = 200) => {
    return {
        data: { data },
        status: responseCode,
        statusText: "OK",
        headers: {},
        config: {}
    }
}

describe("initiateCCConsoleService tests", () => {
    const props = {
        connectionType: EConnectionType.VIEW,
        requester: "requester",
        roomUuid: "roomUuid",
        seatName: "PHSEAT01",
        accessToken: "accessToken",
        receiverName: "AH1",
        orgId: 1,
        connectionMode: EConnectionMode.CC
    }
    it("should able to make initiate console service call", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        initiateCCConsoleService(props)
        expect(spy).toHaveBeenCalled()
    })

    it("should throw exception", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.reject(new Error()))
        initiateCCConsoleService(props)
        expect(spy).toHaveBeenCalled()
    })
})

describe("disconnectConsoleService tests", () => {
    const props = {
        contextId: "contextId",
        connectionMode: EConnectionMode.CC,
        accessToken: "accessToken",
        shouldUpdateForceDelete: true
    }
    it("should able to disconnect console session", () => {
        const spy = jest.spyOn(apiUtility, "deleteService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        disconnectConsoleService(props)
        expect(spy).toHaveBeenCalled()
    })

    it("should able to disconnect emerald console session", () => {
        props.connectionMode = EConnectionMode.EMERALD
        const spy = jest.spyOn(apiUtility, "deleteService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        disconnectConsoleService(props)
        expect(spy).toHaveBeenCalled()
    })

    it("should able to handle vnc connection", () => {
        props.connectionMode = EConnectionMode.VNC
        disconnectConsoleService(props).then(response => expect(response === undefined))
    })
})

describe("handleDisconnectFailure tests", () => {
    const props = {
        contextId: "contextId",
        connectionMode: EConnectionMode.CC,
        accessToken: "accessToken",
        shouldUpdateForceDelete: true
    }
    it("should able to handle disconnect failure scenario", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        handleDisconnectFailure(props)
        expect(spy).toHaveBeenCalled()
    })
})

describe("spokeNotQualifiedService tests", () => {
    const roomDetails: any = {
        identity: { id: "id" }
    }

    it("should able to handle disconnect failure scenario", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(getAxiosResponse({})))
        spokeNotQualifiedService(roomDetails, true).then(response => expect(response).toBe(true))
        expect(spy).toHaveBeenCalled()
    })

    it("should able to handle disconnect failure scenario", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.reject(new Error()))
        spokeNotQualifiedService(roomDetails, true).then(response => expect(response).toBe(false))
        expect(spy).toHaveBeenCalled()
    })
})

describe("requestAuthorizationService tests", () => {
    it("should able to make fcc console request", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextid: "contextId" }, 201)))
        requestAuthorizationService({
            auth: false,
            connectionType: EConnectionType.FULL_CONTROL, connectionMode: EConnectionMode.CC,
            requester: "requester", roomUuid: "roomUuid", seatName: "PHSEAT01", accessToken: "accessToken",
            receiverName: "receiverName", callContextId: "callContextId", orgId: 1
        })
        expect(spy).toHaveBeenCalled()
    })

    it("should not able to make nfcc console request", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.reject(new Error()))
        requestAuthorizationService({
            auth: false,
            connectionType: EConnectionType.FULL_CONTROL, connectionMode: EConnectionMode.EMERALD,
            requester: "requester", roomUuid: "roomUuid", seatName: "PHSEAT01", accessToken: "accessToken",
            receiverName: "receiverName", callContextId: "callContextId", orgId: 1
        })
        expect(spy).toHaveBeenCalled()
    })

    it("should not make vnc console request", () => {
        requestAuthorizationService({
            auth: false,
            connectionType: EConnectionType.FULL_CONTROL, connectionMode: EConnectionMode.VNC,
            requester: "requester", roomUuid: "roomUuid", seatName: "PHSEAT01", accessToken: "accessToken",
            receiverName: "receiverName", callContextId: "callContextId", orgId: 1
        }).then(response => expect(response).toBeUndefined)
    })
})

describe("getActiveConnections tests", () => {
    it("should able to fetch ActiveConnections", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextid: "contextId" }, 201)))
        getActiveConnections("accessToken", "customParam")
        expect(spy).toHaveBeenCalled()
    })

    it("should throw exception while fetching ActiveConnections", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.reject(new Error()))
        getActiveConnections("accessToken", "customParam")
        expect(spy).toHaveBeenCalled()
    })
})

describe("updateConsoleAuthorizationService tests", () => {
    const props = {
        contextId: "contextId",
        token: "accessToken",
        consoleStatus: "APPROVED",
    }
    it("should able to updateConsoleAuthorizationService", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        updateConsoleAuthorizationService(props)
        expect(spy).toHaveBeenCalled()
    })

    it("should able to handle exception", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.reject(new Error()))
        updateConsoleAuthorizationService(props)
        expect(spy).toHaveBeenCalled()
    })
})

describe("consoleSwitchService tests", () => {
    const props = {
        contextId: "contextId",
        accessToken: "accessToken",
        connectionType: EConnectionType.VIEW,
        connectionStatus: EConnectionState.PARKED,
    }
    it("should able to switch console connection", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(getAxiosResponse({ contextId: "contextId" })))
        consoleSwitchService(props)
        expect(spy).toHaveBeenCalled()
    })
    it("should able to handle exception of switch api", () => {
        const spy = jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.reject(new Error()))
        consoleSwitchService(props)
        expect(spy).toHaveBeenCalled()
    })
})

describe("getCommandLineArgs tests", () => {
    const params = {
        accessToken: "accessToken",
        consoleUrl: "url",
        customParams: ""
    }
    it("should able to fetch ActiveConnections", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(getAxiosResponse({ "appNamePath": "path", "cliArgs": [{ "contextId": "terst", "appArguments": ["/b:127.0.0.1", "/c:CT", "5cC1e+i0IQEhgwQ"] }] }, 201)))
        getCommandLineArgs(params)
        expect(spy).toHaveBeenCalled()
    })

    it("should throw exception while fetching ActiveConnections", () => {
        const spy = jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.reject(new Error()))
        getCommandLineArgs(params)
        expect(spy).toHaveBeenCalled()
    })
})
