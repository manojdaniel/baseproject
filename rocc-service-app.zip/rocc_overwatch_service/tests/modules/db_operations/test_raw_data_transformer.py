import unittest
from unittest.mock import Mock
from src.exceptions.RoccException import RoccException
from src.modules.db_operations.db_utility.raw_data_transformer import fetch_dict_from_transaction_id

class RawDataTransformerTest(unittest.TestCase):
    def test_fetch_dict_from_transaction_id_success(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "raw_data": [
                {"id": 100, "data": "Test"}
            ]
        }
        data, data_id = fetch_dict_from_transaction_id(1, mock_client)
        self.assertEqual(data, "Test")
        self.assertEqual(data_id, 100)
    def test_fetch_dict_from_transaction_id_failure_empty(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        self.assertRaises(RoccException, fetch_dict_from_transaction_id, 1, mock_client)
