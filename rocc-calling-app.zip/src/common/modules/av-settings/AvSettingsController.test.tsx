/*
 * Created on Wed Sept 29 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import thunk from "redux-thunk"
import * as Redux from "react-redux"
import React from "react"
import AvSettingsController from "./AvSettingsController"
import configureMockStore from "redux-mock-store"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn()
}))

let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const props = {
    active: true,
    component: "component",
    handleSettings: jest.fn(),
    handleVolume: jest.fn(),
    customLoader: false,
    audioCameraAccessError: false,
    audioInputOptions: [{ value: "AudioInput", text: "AudioInput" }],
    audioOutputOptions: [{ value: "AudioOutput", text: "AudioOutput" }],
    videoInputOptions: [{ value: "VideoInput", text: "VideoInput" }],
    videoRef: {},
    webCamAvailable: false,
}
const mockAppState = {
    callReducer: {
        videoSource: "videoSource",
        videoCallStatus: [{ contextId: "contextId", callStatus: "connected" }],
        callDetails: {
            connectedCallDetails: {
                numOfParticipants: 1,
            }
        }
    }
}
const avSettingText = "AvSetting"
const avSettingComponentName = "<AvSetting />"
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}
const getShallowWrapper = (props: any) => { return shallow(<AvSettingsController {...props} />) }
const emptyVideoCallStatus = [{ contextId: "", callStatus: "" }]

Object.defineProperty(navigator, "mediaDevices", {
    value: {
        getUserMedia: jest.fn(() => {
            Promise.resolve({
                getTracks: jest.fn(() => [{ stop: jest.fn() }])
            })
        }),
    },
    writable: true,
})

describe("AvSettingsController tests when number of pariticipants is 1 and active", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })

    it("should render AvSetting component when number of pariticipants is 1 and active", () => {
        withHooks(() => {
            wrapper = getShallowWrapper(props)
            expect(wrapper.find(avSettingText).text()).toBe(avSettingComponentName)
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("AvSettingsController tests when number of pariticipants is more than 1 and not active", () => {
    beforeEach(() => {
        mockAppState.callReducer.callDetails.connectedCallDetails.numOfParticipants = 2
        useSelectorMock(mockAppState)
    })

    it("should render AvSetting component when number of pariticipants is more than 1 and not active", () => {
        withHooks(() => {
            props.active = false
            wrapper = getShallowWrapper(props)
            expect(wrapper.find(avSettingText).text()).toBe(avSettingComponentName)
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("AvSettingsController tests when video call status is not connected and webcamera available", () => {
    beforeEach(() => {
        mockAppState.callReducer.videoCallStatus = emptyVideoCallStatus
        useSelectorMock(mockAppState)
    })

    it("should render AvSetting component when video call status is not connected and webcamera available", () => {
        withHooks(() => {
            props.webCamAvailable = true
            wrapper = getShallowWrapper(props)
            expect(wrapper.find(avSettingText).text()).toBe(avSettingComponentName)
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("AvSettingsController tests when microphone status is false", () => {
    beforeEach(() => {
        mockAppState.callReducer.videoCallStatus = emptyVideoCallStatus
        useSelectorMock(mockAppState)
    })

    it("should render AvSetting component when microphone status is false", () => {
        withHooks(() => {
            props.webCamAvailable = false
            wrapper = getShallowWrapper(props)
            expect(wrapper.find(avSettingText).text()).toBe(avSettingComponentName)
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
