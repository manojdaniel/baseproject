/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType, getTrackingEvent } from "@rocc/rocc-client-services"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { getDurationInFormat } from "./dateTimeUtility"

interface IConsoleDisconnectTrack {
    connectionType: EConnectionType,
    connectionMode: EConnectionMode,
    roomUuid: string,
    requester: string,
    consoleStartTime: any
    componentName: string
    isRevoked?: boolean
}
export const trackConsoleDisconnection = (props: IConsoleDisconnectTrack) => {
    const { connectionType, roomUuid, requester, consoleStartTime, connectionMode, isRevoked } = props
    infoLogger(`${getTrackingEvent(connectionType).toLowerCase()} console stopped event performed for roomId: ${roomUuid}`)
    const action = isRevoked ? "revoked" : "stopped"
    sendLogsToAzure({
        contextData: {
            component: "Console service", event: `${transformSessionTypeForAnalytics(connectionType)} ${action}`,
            source: transformSessionTypeForAnalytics(connectionMode), Call_To: roomUuid, Call_From: requester,
            Event_By: requester, duration: getDurationInFormat(new Date(), new Date(consoleStartTime))
        }
    })
}

interface IConsoleSwitchTrack {
    prevConnectionType: EConnectionType
    newConnectionType: EConnectionType
    connectionMode: EConnectionMode
    requester: string
    roomUuid: string
}

export const trackConsoleSwitching = (props: IConsoleSwitchTrack) => {
    const { prevConnectionType, newConnectionType, requester, roomUuid, connectionMode } = props
    infoLogger(`Console switching is performed from conection type 
    ${getTrackingEvent(prevConnectionType).toLowerCase()} to ${getTrackingEvent(newConnectionType).toLowerCase()} for roomId: ${roomUuid}`)
    sendLogsToAzure({
        contextData: {
            component: "Console Service",
            event: `Console Switch from ${transformSessionTypeForAnalytics(prevConnectionType)} to ${transformSessionTypeForAnalytics(newConnectionType)}`,
            source: transformSessionTypeForAnalytics(connectionMode), Call_From: requester, Call_To: roomUuid,
        }
    })
}

export const transformSessionTypeForAnalytics = (sessionType: EConnectionType | EConnectionMode) => {
    const { FULL_CONTROL, FULL_CONTROL_USB, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, VIEW } = EConnectionType
    const { EMERALD, CC } = EConnectionMode
    switch (sessionType) {
        case VIEW:
            return "View Console"
        case FULL_CONTROL:
            return "Edit Console"
        case INCOGNITO_VIEW:
            return "Incognito-View Console"
        case PROTOCOL_MANAGEMENT:
            return "Protocol Management Console"
        case FULL_CONTROL_USB:
            return "Edit Console With USB Redirection Enabled As A Private Connection"
        case EMERALD:
            return "Non fixed command center connection"
        case CC:
            return "Fixed command center connection"
        default:
            return "Console"
    }
}
