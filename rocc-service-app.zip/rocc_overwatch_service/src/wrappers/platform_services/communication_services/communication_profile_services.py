"""
 Created on Wed Sep 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION, CONTENT_TYPE, APPLICATION_JSON, ORG_CTXT_HEADER, PHILIPS_ROCC_URI, AUTHORIZATION

LOG = create_logger("CommunicationProfileservices")


def create_org_comm_profile_service(url, org_name, token, org_id, country_iso_code, sub_acc_name):
    error_reasn = ""
    org_identity = ""
    try:
        headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token,
                   ORG_CTXT_HEADER: str({"Org-Id": org_id}), API_VERSION: "1.1.0"}
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/admin/Organisation",
                                 data=json.dumps({"orgIdentityId": org_id,
                                                  "orgName": org_name,
                                                  "orgInstanceId": org_id,
                                                  "countryIsoCode": country_iso_code,
                                                  "subAccountName": sub_acc_name}),
                                 headers=headers)
        if response.status_code == 201:
            LOG.info("Communication org profile created successfully")
            org_identity = response.json()["orgIdentity"]
        else:
            LOG.error(
                f"Communication org profile creation failed with {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        error_reasn = f"Communication org creation failed with Error:{repr(ex.args)}"
        LOG.exception(f"Communication org creation failed with {ex}")
    return org_identity, error_reasn


def create_communication_profile_for_device_api(url, device_id, device_token, org_ctxt_header):
    try:
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: device_token,
            ORG_CTXT_HEADER: str(org_ctxt_header)
        }
        response = requests.post(f"{url}/{PHILIPS_ROCC_URI}/CommunicationProfile",
                                 data=json.dumps(
                                     {"userInstanceIdentity": device_id}),
                                 headers=headers)
        api_response = json.loads(response.text)
        if response.status_code in [200, 201]:
            return api_response["userIdentity"], "Communication profile created successfully"
        elif response.status_code in [400] and "Already exist" in api_response["defaultMessage"]:
            """ TODO: Check if this block is needed """
            LOG.warning(api_response["defaultMessage"])
            return None
        else:
            LOG.error(api_response["defaultMessage"])
            return None
    except requests.exceptions.Timeout as ex:
        LOG.exception(
            f"Timeout Exception occured while creating communication profile for devices : {ex}")
    except requests.exceptions.TooManyRedirects as ex:
        LOG.exception(
            f"TooManyRedirects Exception occured while creating communication profile for devices : {ex}")
    except requests.exceptions.RequestException as ex:
        LOG.exception(
            f"Exception occured while creating communication profile for devices : {ex}")
    return None


def delete_org_comm_profile_service(url, token, org_id):
    try:
        headers = {AUTHORIZATION: token}
        response = requests.delete(f"{url}{PHILIPS_ROCC_URI}/admin/Organisation/{org_id}",
                                   headers=headers)
        LOG.info(f"Communication profile deletion response: {response}")
        if response.status_code == 204:
            LOG.info("Communication org profile deleted successfully")
            return True
        else:
            LOG.error(
                f"Communication org profile deletion failed with {response.json()}")
            return False
    except Exception as ex:
        LOG.exception(
            f"Failed to delete communication org profile for customer: {org_id} with error: {ex}")
        return False


def fetch_org_comm_profile_service(url, token, org_id):
    try:
        headers = {AUTHORIZATION: token}
        response = requests.get(f"{url}{PHILIPS_ROCC_URI}/admin/Organisation/{org_id}",
                                headers=headers)
        LOG.info(
            f"Fetching of communication profile details response: {response}")
        if response.status_code == 200:
            LOG.info("Communication org profile details fetched successfully")
            return dict(twilioSid=response.json()["twilioSid"],
                        twilioAuthToken=response.json()["twilioAuthToken"],
                        customer=response.json()["orgName"])
        else:
            LOG.error(
                f"Failed to fetch communication org profile details with error: {response.json()}")
            return False
    except Exception as ex:
        LOG.exception(
            f"Failed to fetch communication org profile details with exception: {ex}")
        return False


def validate_twilio_sub_account_integrity(url, token, sub_acc_name, twilio_sid, org_id):
    try:
        headers = {AUTHORIZATION: token, ORG_CTXT_HEADER: str(
            {"Org-Id": org_id}), API_VERSION: "1.0.0"}
        response = requests.get(f"{url}{PHILIPS_ROCC_URI}/twilio/Account/{sub_acc_name}/{twilio_sid}/$isValid",
                                headers=headers)
        LOG.info(f"Twilio sub account integrity response: {response}")
        if response.status_code == 200:
            return response.json()
        else:
            LOG.error(
                f"Failed to check Twilio sub account integrity with error: {response.json()}")
            return False
    except Exception as ex:
        LOG.exception(
            f"Failed to check Twilio sub account integrity with exception: {ex}")
        return False
