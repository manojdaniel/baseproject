import { ECameraStreamAvailable, IConsoleSession } from "@rocc/rocc-client-services"
import { Dispatch } from "redux"
import { LocalTrack, Room } from "twilio-video"

export interface IMultiCameraController {
    consoleSession: IConsoleSession
}

export interface ILeaveRoom {
    room: Room
    dispatch: Dispatch<any>
    setVideoTracks?: any
    videoTracksRef?: any
    setRemoteVideoStatus?: any
    disconnectState?: ECameraStreamAvailable
    consoleSession?: IConsoleSession
    isDevice?: boolean
    isSyncConsoleSession?: boolean
}

export interface IMediaRoomConnectOptions {
    roomName: string
    roomType: ERoomType
    renderDimensions: any
    localTracks: LocalTrack[]
    region: any
    videoStatus: boolean
}

export enum ERoomType {
    PEER_TO_PEER = "PEER_TO_PEER",
    GROUP = "GROUP",
    GROUP_SMALL = "GROUP_SMALL",
}

export interface IUpdateMediaRoomForConsole {
    isSyncSession: boolean
    contextId: string
    mediaRoomId: string,
    mediaRoomToken: string,
    cameraStreamAvailable: ECameraStreamAvailable
    dispatch: Dispatch<any>,
}

export interface ICloseMediaRoom {
    room: Room,
    previewTracksRef: React.MutableRefObject<LocalTrack[]>
    setPreviewTracks: (value: React.SetStateAction<LocalTrack[]>) => void
    setActiveRoom: (value: React.SetStateAction<Room>) => void
}

export interface IHandleUnloadEventHandler extends ICloseMediaRoom {
    addHandler: boolean
}

export interface IAddLocalTracks {
    isDevice: boolean
    cameraTrackName?: string
    componentName?: string
    currentUserUuid?: string
    maxSupportedCameras?: string
}

export interface IMultiCamVideoTrack {
    fullScreen: boolean
    videoTrack?: any
}

export interface IUpdateCurrentSession {
    consoleSession: IConsoleSession
    dispatch: Dispatch<any>
    isSyncConsoleSession?: boolean
    disconnectState?: ECameraStreamAvailable
    multiCameraFeature?: boolean
}
