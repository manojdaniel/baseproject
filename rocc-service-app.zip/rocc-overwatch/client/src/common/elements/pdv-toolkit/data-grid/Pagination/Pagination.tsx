/*	
 * Created on Thu Sep 10 2020	
 *	
 * Copyright (c) 2019 Philips	
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.	
 * Reproduction or transmission in whole or in part, in any form or by any	
 * means, electronic, mechanical or otherwise, is prohibited without the prior	
 * written consent of the copyright owner.	
 */
import React from "react"
import { Dropdown, Menu, Icon, Label, Table } from "semantic-ui-react"
import _ from "lodash"
import { INTEGER_RADIX_TEN } from "constants/constants"

interface LooseObject {
    [key: string]: any
}

interface IPagination {
    itemsCount: number
    initialPageSize: number
    pageSize: number
    currentPage: number
    onPageChange(page: number): void
    updateEntriesPerPage(perPage: number): void
}

const Pagination = (props: IPagination) => {
    const { itemsCount, initialPageSize, pageSize, onPageChange, currentPage, updateEntriesPerPage } = props
    const pagesCount = Math.ceil(itemsCount / pageSize)
    const startingNumber = pageSize * (currentPage - 1) + 1
    const endingNumber = Math.min(pageSize * currentPage, itemsCount)

    // TODO: so the entries per page those numbers for dropdown, shouldnt need state,
    // they wont be changing once they're set, so a standard property will work just fine

    const getEntriesPerPage = () => {
        const step = itemsCount < initialPageSize ? itemsCount : initialPageSize
        const pageCount = _.ceil(itemsCount / step)
        const pageRange = _.range(0, (step * pageCount) + 1, step)
        let entriesOptions = [{ key: itemsCount, value: itemsCount, text: itemsCount }]
        if (pageRange) {
            pageRange.shift()
            entriesOptions = pageRange.map((value: number, index: number) => {
                return { key: value, value: value, text: value }
            })
        }
        return entriesOptions
    }

    const canNavigateBack = () => currentPage > 1

    const canNavigateForward = () => currentPage < pagesCount

    const navigateBack = () => onPageChange(currentPage - 1)

    const navigateForward = () => onPageChange(currentPage + 1)

    const handleEntriesOnChange = (event: React.FormEvent, data: LooseObject) => {
        updateEntriesPerPage(parseInt(data.value, INTEGER_RADIX_TEN))
    }

    return (
        <Table basic attached="bottom">
            <Table.Footer fullWidth>
                <Table.Row>
                    <Table.HeaderCell>
                        <div className={"pagination"}>
                            <div>
                                <Label className="descriptor quiet tiny">Entries per page</Label>
                                <Dropdown
                                    // FIXME: Dropdown shows blank on mount. Default value not rendering correctly.  
                                    defaultValue={initialPageSize}
                                    options={getEntriesPerPage()}   // TODO: access the standard property
                                    onChange={handleEntriesOnChange}
                                />
                            </div>
                            <div>
                                <Label className="descriptor quiet tiny">
                                    Showing {startingNumber}-{endingNumber} of {itemsCount}
                                </Label>
                                <Menu pagination secondary fitted={"true"} className="small">
                                    {/* TODO: optimize this */}
                                    <Menu.Item as="a" icon onClick={canNavigateBack() ? navigateBack : () => { }} className={!canNavigateBack() ? "disabled" : ""}>
                                        <Icon name="chevron left" />
                                    </Menu.Item>
                                    <Menu.Item as="a" icon onClick={canNavigateForward() ? navigateForward : () => { }} className={!canNavigateForward() ? "disabled" : ""}>
                                        <Icon name="chevron right" />
                                    </Menu.Item>
                                </Menu>
                            </div>
                        </div>
                    </Table.HeaderCell>
                </Table.Row>
            </Table.Footer>
        </Table>
    )
}
export default Pagination
