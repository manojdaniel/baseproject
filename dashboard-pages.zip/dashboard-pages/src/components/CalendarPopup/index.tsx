import React, { useState } from "react";
import DatePickerComponent from "../DatePickerComponent";
import { useDispatch, useSelector } from "react-redux";
import {
	getCommonFromDate,
	getCommonToDate,
	getBreadCrumbDate,
	getTodayDate,
} from "../../redux/reducers/CommonReducer";
import moment from "moment";

interface Props {
	title: string;
}

const CalendarPopup = ({ title }: Props) => {
	let dispatch = useDispatch();

	const [labelFrom, setLabelFrom] = useState(true);
	const [labelTo, setLabelTo] = useState(false);

	const {
		commonFromDate,
		commonToDate,
		commonFromDateFormat,
		commonToDateFormat,
	} = useSelector((state: any) => ({
		commonFromDate: state.Common.commonFromDate,
		commonToDate: state.Common.commonToDate,
		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
	}));

	const handleFromDateChanged = (date: any) => {
		switch (title) {
			case "common":
				console.log("from date-->" + date)
				dispatch(getCommonFromDate(date));
				break;
		}
	};
	const handleToDateChanged = (date: any) => {
		switch (title) {
			case "common":
				console.log("to date-->" + date)
				dispatch(getCommonToDate(date));
				break;
		}
		dispatch(getBreadCrumbDate({ id: "", updatedDate: "" }));
		dispatch(getTodayDate(""));
	};

	return (
		<>
			<div id="calendar-popup" className="cal-show">
				<div className="calendar-filter">
					<div className="cf-left">
						<span>From</span>
						<label
							onClick={() => {
								setLabelFrom(true);
								setLabelTo(false);
							}}
						>
							{title === "common" ? commonFromDateFormat : null}
						</label>
					</div>
					<div className="cf-right">
						<span>To</span>
						<label
							onClick={() => {
								setLabelTo(true);
								setLabelFrom(false);
							}}
						>
							{title === "common" ? commonToDateFormat : null}
						</label>
					</div>
				</div>

				<div className="calendar-box">
					<div style={{ marginLeft: "0px" }}>
						{labelFrom ? (
							<DatePickerComponent
								selectedDate={
									commonFromDate !== ""
										? moment(commonFromDate).toDate()
										: commonFromDate
								}
								handleDateChange={handleFromDateChanged}
							/>
						) : null}
						{labelTo ? (
							<DatePickerComponent
								selectedDate={
									commonToDate !== ""
										? moment(commonToDate).toDate()
										: commonToDate
								}
								handleDateChange={handleToDateChanged}
							/>
						) : null}
					</div>
				</div>
			</div>
		</>
	);
};

export default CalendarPopup;
