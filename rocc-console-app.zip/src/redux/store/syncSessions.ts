const syncSessions = new BroadcastChannel("syncSessions")

export default syncSessions
