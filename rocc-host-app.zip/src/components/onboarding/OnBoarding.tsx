/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import FormController from "./form-controller/FormController"
import React from "react"
import { IUserInfo, IParentStore } from "@rocc/rocc-client-services"
import { useSelector } from "react-redux"
import styles from "./OnBoarding.scss"

const OnBoarding = () => {
    const currentUser: IUserInfo = useSelector((state: IParentStore) => (state.userReducer.currentUser))
    return (
        <>
            <div className={styles.onBoarding}>
                {currentUser.onBoarded === false ? <FormController /> : <></>}
            </div>

        </>
    )
}

export default OnBoarding
