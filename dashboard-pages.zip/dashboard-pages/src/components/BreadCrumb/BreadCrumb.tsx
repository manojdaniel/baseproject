import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import "./BreadCrumb.scss";
import useBreadcrumbs from "use-react-router-breadcrumbs";
import { useSelector } from "react-redux";

const BreadCrumb = () => {
  const {
    globalSelecetedRegion,
    globalSelecetedAffiliate,
    globalSelecetedPlant,
    globalSelecetedAsset,
    onePlantUser
  } = useSelector((state: any) => ({
    globalSelecetedRegion: state.Common.globalSelecetedRegion,
    globalSelecetedAffiliate: state.Common.globalSelecetedAffiliate,
    globalSelecetedPlant: state.Common.globalSelecetedPlant,
    globalSelecetedAsset: state.Common.globalSelecetedAsset,

    onePlantUser: state.Common.onePlantUser,
  }));
  //  const [oneplantUser, setOnePlantUser] = useState(true)
  const AffiliatePropsBreadcrumb = () => (

    <React.Fragment>
      {Object.keys(globalSelecetedRegion).length > 0 ? (
        <React.Fragment>
          <a className="active">{globalSelecetedRegion.label === "All" ? "All Affiliates" : capitalizeFirstLetterInEachWord(globalSelecetedRegion.label)}</a>
        </React.Fragment>
      ) : (
        <React.Fragment>
          <a className="active">All Affiliates</a>
        </React.Fragment>
      )}
    </React.Fragment>
  );

  const AllPlantsPropsBreadcrumb = () => (
    <React.Fragment>
      {Object.keys(globalSelecetedAffiliate).length > 0 ? (
        <React.Fragment>
          <Link to="affiliates">{globalSelecetedRegion.label === "All" ? "All Affiliates" : capitalizeFirstLetterInEachWord(globalSelecetedRegion.label)}</Link>
          <span className="b-divider">|</span>
          <a className="active">{capitalizeFirstLetterInEachWord(globalSelecetedAffiliate.label)}</a>
        </React.Fragment>
      ) : (
        <React.Fragment>
          <a className="active">All Plants</a>
        </React.Fragment>
      )}
    </React.Fragment>
  );

  const PlantPropsBreadcrumb = () => (
    <React.Fragment>
      <Link to="affiliates">{globalSelecetedRegion.label === "All" ? "All Affiliates" : capitalizeFirstLetterInEachWord(globalSelecetedRegion.label)}</Link>
      <span className="b-divider">|</span>
      <Link to="allPlants">{capitalizeFirstLetterInEachWord(globalSelecetedAffiliate.label)}</Link>
      <span className="b-divider">|</span>
      <a>{capitalizeFirstLetterInEachWord(globalSelecetedPlant.label)}</a>
    </React.Fragment>
  );

  const OnePlantUserBreadcrumbs = () => (
    <React.Fragment>
      <div >{globalSelecetedRegion.label === "All" ? "All Affiliates" : capitalizeFirstLetterInEachWord(globalSelecetedRegion.label)}</div>
      <span className="b-divider">|</span>
      <div>{capitalizeFirstLetterInEachWord(globalSelecetedAffiliate.label)}</div>
      <span className="b-divider">|</span>
      <div>{capitalizeFirstLetterInEachWord(globalSelecetedPlant.label)}</div>
    </React.Fragment>
  );

  const AssetPropsBreadcrumb = () => (
    <React.Fragment>
      <Link to="affiliates">{capitalizeFirstLetterInEachWord(globalSelecetedRegion.label)}</Link>
      <span className="b-divider">|</span>
      <Link to="allPlants">{capitalizeFirstLetterInEachWord(globalSelecetedAffiliate.label)}</Link>
      <span className="b-divider">|</span>
      <Link to="plant">
        <a>{capitalizeFirstLetterInEachWord(globalSelecetedPlant.label)}</a>
      </Link>
      <span className="b-divider">|</span>
      <a>{capitalizeFirstLetterInEachWord(globalSelecetedAsset.label)}</a>
    </React.Fragment>
  );



  function capitalizeName(string: any) {
    try {
      return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
    } catch (error) {
      return ""
    }
  }

  function capitalizeFirstLetterInEachWord(sentence: any) {
    return sentence.split(' ').map(function (word: any) {
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join(' ');
  }


  const routes = [
    { path: "/home", breadcrumb: " " },
    { path: "/affiliates", breadcrumb: AffiliatePropsBreadcrumb },
    { path: "/allPlants", breadcrumb: AllPlantsPropsBreadcrumb },
    { path: "/plant", breadcrumb: onePlantUser === 1 ? OnePlantUserBreadcrumbs : PlantPropsBreadcrumb },
    {
      path: "/assets",
      breadcrumb: AssetPropsBreadcrumb,
      // props: { someProp: "Hi" },
    },
    {
      path: "/plant/pmt",
      breadcrumb: "PMT",
      // props: { someProp: "Hi" },
    },
    {
      path: "plant/pmCompliance", breadcrumb: "PM Compliance",
    },

    {
      path: "plant/alertManagementPage/ampMyTask", breadcrumb: "My Task",

    },
    {
      path: "ampMyTask", breadcrumb: "My Task",

    },
    {
      path: "/plant/alertManagementPage/ampHome", breadcrumb: "Home",

    },
    {
      path: "plant/alertManagementPage/ampReports", breadcrumb: "Reports",

    },
    {
      path: "plant/alertManagementPage/ampUtilizationReport", breadcrumb: "Utilization Reports",

    },
    {
      path: "plant/alertManagementPage/ampMasterReport", breadcrumb: "Master Data Report",

    },
    {

      path: "plant/modelperformance", breadcrumb: "Model Performance",

    },

    {

      path: "plant/alertManagementPage", breadcrumb: "Alert Management",

    },

    {

      path: "plant/alertSatistics", breadcrumb: "Alert Statistics",

    },
    {

      path: "assets/assetModel", breadcrumb: "Asset Model",

    },
    {

      path: "assets/liveTracking", breadcrumb: "Live Tracking",

    },
    {

      path: "assets/assetTimeLine", breadcrumb: "Asset Timeline",

    },
    {

      path: "assets/alertList", breadcrumb: "Alert List",

    },
    {

      path: "assets/referenceTable", breadcrumb: "Reference Table",

    },
    {

      path: "assets/spareparts", breadcrumb: "Spare Parts",

    },
    {

      path: "plant/alertSatistics/alertDashboard", breadcrumb: "Alert Dashboard",

    },

    {

      path: "plant/modelPerformance/performanceDashboard", breadcrumb: "Performance Dashboard",

    },

    {

      path: "plant/alertSatistics/alertList", breadcrumb: "Alert List",

    },

    {

      path: "plant/alertSatistics/plantTimeline", breadcrumb: "Plant Timeline"

    },

    {

      path: "plant/modelPerformance/plantMonthWise", breadcrumb: "Plant Monthwise",

    },
    {
      path: "admin", breadcrumb: "Admin Configuration",

    },

    {

      path: "admin/plantRollout", breadcrumb: "Rollout New Plant",

    },

    {

      path: "admin/affiliateRollout", breadcrumb: "Rollout New Affiliate",

    },

    {

      path: "admin/assetModelConfig", breadcrumb: "Asset Model Config",

    },

    {

      path: "admin/userRoleMapping", breadcrumb: "User Role Mapping",

    },

    {

      path: "admin/exceptionMonitoring", breadcrumb: "Exception Monitoring",

    },
  ];

  const breadcrumbs = useBreadcrumbs(routes);

  return (
    <div className="breadcrumb-left">
      {breadcrumbs.map(({ match, breadcrumb }, index) => (
        <NavLink key={match.pathname} to={match.pathname}>
          {match.pathname !== "/home" && index !== 0 ? (
            <span className="b-divider">|</span>
          ) : null}
          {breadcrumb}
        </NavLink>
      ))}

    </div>
  );
};

export default BreadCrumb;

{
  /* // <div className="breadcrumb-left"><a href="#">Home</a><span>|</span><a href="#">Yanpet</a><span>|</span><a href="#" className="active">Poly 2</a></div> */
}

{
  /* {breadcrumbs.map(({ breadcrumb }) => <div>
        <span>|</span>
        <a>{breadcrumb}</a>
      </div>)} */
}
