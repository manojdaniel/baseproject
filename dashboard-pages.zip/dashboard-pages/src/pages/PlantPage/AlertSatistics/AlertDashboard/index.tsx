import React, { useRef, useEffect, useState } from "react";
import AlertStatusAsset from "charts/AlertStatusAsset";
import PerformanceTrend from "charts/PerformanceTrend";
import StackedBarAsset from "charts/StackedBarAsset";
import StackedBarDepartment from "charts/StackedBarDepartment";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
	getAssetPieChart,
	getAssetStackedBar,
	getDepartementStackedBar,
	getPerformaceChart,
	getAlertStatisticsAlertListByPlantId,
	getPlantAlertStatus,
	getPlantDepartmentStatus,
} from "../../../../redux/reducers/CommonReducer";
import {
	stackedBarAssetTransformer,
	stackedBarDepartmentTransformer,
} from "../../../../utility/transformer/AlertDashboardTransformers";
import "./AlertDashboard.scss";
import Loader from "components/Loader";
import NoData from "components/NoData";
import { encryptRSAData } from "../../../../utility/rsa";

const Alertdashboard = () => {
	let dispatch = useDispatch();
	const navigate = useNavigate();
	const [assetBarData, setAssetBarData] = useState<any>([]);
	const [departmentBarData, setDepartmentBarData] = useState<any>([]);

	const {
		assetPieChart,
		assetStackedBar,
		departementStackedBar,
		performaceChart,
		globalSelecetedPlant,
		loadingAssetPieChart,
		loadingAssetStackedBar,
		loadingDepartementStackedBar,
		loadingPerformaceChart,
	} = useSelector((state: any) => ({
		assetPieChart: state.Common.assetPieChart,
		assetStackedBar: state.Common.assetStackedBar,
		departementStackedBar: state.Common.departementStackedBar,
		performaceChart: state.Common.performaceChart,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,

		loadingAssetPieChart: state.Common.loadingAssetPieChart,
		loadingAssetStackedBar: state.Common.loadingAssetStackedBar,
		loadingDepartementStackedBar: state.Common.loadingDepartementStackedBar,
		loadingPerformaceChart: state.Common.loadingPerformaceChart,
	}));

	useEffect(() => {
		if (Object.keys(globalSelecetedPlant).length > 0) {
			dispatch(
				getAssetPieChart(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Pie Chart//{plantId}/{userid}
			dispatch(
				getAssetStackedBar(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Stacked Asset Bar//{plantId}/{userid}
			dispatch(
				getDepartementStackedBar(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Stacked  Department Bar //{plantId}/{userid}
			dispatch(
				getPerformaceChart(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Performance Trend//{plantId}/{userid}
		}
	}, []);

	useEffect(() => {
		if (assetStackedBar.length > 0) {
			let transformer: any[];
			transformer = stackedBarAssetTransformer(assetStackedBar);

			setAssetBarData(transformer);
		}
	}, [assetStackedBar]);

	useEffect(() => {
		if (departementStackedBar.length > 0) {
			let transformer: any[];
			transformer = stackedBarDepartmentTransformer(departementStackedBar);

			setDepartmentBarData(transformer);
		}
	}, [departementStackedBar]);

	const handleClick = (alertState, department) => {
		if (alertState === null) {
			dispatch(
				getAlertStatisticsAlertListByPlantId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&state=0&department=${department}&assetId=0`
					)
				)
			);
			dispatch(getPlantAlertStatus({ value: 0, label: "All" }));
			dispatch(
				getPlantDepartmentStatus({ value: department, label: department })
			);
		} else if (department === null) {
			if (alertState === "Overdue Investigation") {
				dispatch(
					getAlertStatisticsAlertListByPlantId(
						encryptRSAData(
							`plantId=${
								globalSelecetedPlant.value
							}&state=${"Overdue"}&department=0&assetId=0`
						)
					)
				);
				dispatch(getPlantAlertStatus({ value: "Overdue", label: "Overdue" }));
				dispatch(getPlantDepartmentStatus({ value: 0, label: "All" }));
			} else if (alertState === "Under Investigation") {
				dispatch(
					getAlertStatisticsAlertListByPlantId(
						encryptRSAData(
							`plantId=${
								globalSelecetedPlant.value
							}&state=${"Work in Progress"}&department=0&assetId=0`
						)
					)
				);
				dispatch(
					getPlantAlertStatus({
						value: "Work in Progress",
						label: "Work in Progress",
					})
				);
				dispatch(getPlantDepartmentStatus({ value: 0, label: "All" }));
			} else {
				dispatch(
					getAlertStatisticsAlertListByPlantId(
						encryptRSAData(
							`plantId=${globalSelecetedPlant.value}&state=${alertState}&department=0&assetId=0`
						)
					)
				);
				dispatch(getPlantAlertStatus({ value: alertState, label: alertState }));
				dispatch(getPlantDepartmentStatus({ value: 0, label: "All" }));
			}
		}
		navigate("/plant/alertSatistics/alertList");
	};

	return (
		<>
			<div id="alert-dashboard">
				<div className="common-box-inner">
					<div className="common-box-filter">
						<div className="title">ALERT STATUS BY ASSET</div>
					</div>
					<div className="common-box-content twocharts">
						{loadingAssetPieChart ? (
							<div className="tc-loader1"><Loader /></div>
						) : assetPieChart.length === 0 ? (
							<div className="tc-loader1"><NoData /></div>
						) : (
							<AlertStatusAsset
								data={assetPieChart}
								handleClick={handleClick}
							/>
						)}

						{loadingAssetPieChart ? (
							<div className="tc-loader2"><Loader /></div>
						) : assetBarData.length === 0 ? (
							<div className="tc-loader2"><NoData /></div>
						) : (
							<StackedBarAsset data={assetBarData} />
						)}
					</div>
				</div>
			</div>
			<div id="alert-dashboard">
				<div id="alert-dashboard-left">
					<div className="common-box-inner">
						<div className="common-box-filter">
							<div className="title">ALERT STATUS BY DEPARTMENT</div>
						</div>
						<div className="common-box-content">
							{loadingDepartementStackedBar ? (
								<div className="departmentloader"><Loader /></div>
							) : departmentBarData.length === 0 ? (
								<div className="departmentloader"><NoData /></div>
							) : (
								<StackedBarDepartment
									data={departmentBarData}
									handleClick={handleClick}
								/>
							)}
						</div>
					</div>
				</div>
				<div id="alert-dashboard-right">
					<div className="common-box-inner">
						<div className="common-box-filter">
							<div className="title">PERFORMANCE TREND</div>
						</div>
						<div className="common-box-content">
							{loadingPerformaceChart ? (
								<div className="departmentloader"><Loader /></div>
							) : performaceChart.length === 0 ? (
								<div className="departmentloader"><NoData /></div>
							) : (
								<PerformanceTrend data={performaceChart} />
							)}
						</div>
					</div>
				</div>
			</div>
		</>
	);
};
export default Alertdashboard;
