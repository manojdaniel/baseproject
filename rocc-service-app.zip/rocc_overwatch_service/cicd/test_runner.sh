#!/bin/bash
set -e
SEP="====================================="
echo $SEP
echo "Beginning execution of unit tests for project: rocc_cpp_service"
echo $SEP
export APPINSIGHTS_CONNECTION_STRING="InstrumentationKey=eaed9e49-405b-4dbd-8886-9feaf2ea867e;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/"

if [ $# -eq 0 ]; then
    # echo "Installing virtual environment"
    # python -m pip install virtualenv
    
    # echo "Creating virtual env"
    # python -m virtualenv venv
    # source venv/bin/activate

    echo "Installing pip packages before test case executions inside virtual environment"
    pip install -r requires.txt

    echo "Running test cases"
    python3 -m coverage run --source="src/,cli_utility/" --omit */resources/* test.py
    python3 -m coverage xml

    # echo "Deactivating virtual envirnoment"
    # deactivate
else
    echo "Running test cases in local environment"
    cd ..
    python -m unittest discover -s "./tests" -p "test_*.py"
    python -m coverage run --source="src/,cli_utility/" --omit */resources/* test.py
    python -m coverage html
fi

echo $SEP
echo "End of unit tests execution!"
echo $SEP
