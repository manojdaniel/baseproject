"""
 Created on Thu Oct 29 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json

import requests

from src.constants.config_keys import VAULT_IAM_GROUP_NAME, INFRA_CFG_DEFAULT_ROLE_NAME, VAULT_HSDP_IDM_URL, VAULT_ADMIN_USER_ID, VAULT_DEVICE_PROVISION_NAME, VAULT_PARENT_ORG_ID
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, API_VERSION, ACCEPT, APPLICATION_FORM_URLENCODED, X_TOKEN
from src.loggers.log import create_logger

LOG = create_logger("ManageHSDPRolePermissionsServices")


def create_roles_and_groups_services(token, org_id, infra_configs, profile_configs):
    """ Group creation """
    group_id = 0
    role_id = 0
    error_reasn = ""
    group_id, group_error_reasn = create_group(
        token, org_id, profile_configs[VAULT_IAM_GROUP_NAME], "Admin Group", profile_configs)
    LOG.info(f"group_id::::::{json.dumps((group_id))}\n")

    """ Role creation """
    role_id, role_error_reasn = create_role(
        token, org_id, infra_configs[INFRA_CFG_DEFAULT_ROLE_NAME], profile_configs)
    LOG.info(f"role_id::::::{json.dumps((role_id))}\n")
    error_reasn = group_error_reasn if not group_error_reasn else role_error_reasn

    if role_id:
        add_permissions_to_role(token, role_id, profile_configs)
        add_mdm_permissions_to_role(token, role_id, profile_configs)
    if group_id and role_id:
        add_role_to_group(token, group_id, role_id, profile_configs)
        add_user_to_group(token, group_id, profile_configs,
                          reference_user_uuid=profile_configs[VAULT_ADMIN_USER_ID])
    return group_id, role_id, error_reasn


def create_group(token, organization_id, name, description, profile_configs):
    LOG.info(f"Creating group: {name}")
    group_id = 0
    group_error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    group_data = {"name": name,
                  "description": description,
                  "managingOrganization": organization_id}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group",
                                 data=json.dumps(group_data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info(f"Successfully created group: {name}")
            group_id = response.json()["id"]
        elif response.status_code == 409:
            LOG.warning(
                f"ALREADY EXISTS! Group {name} for organization {organization_id} already exists ")
            group_error_reasn = f"ALREADY EXISTS! Group {name} for organization {organization_id} already exists "
        else:
            LOG.error(
                f"Group Creation failed with: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Group Creation failed with: {ex}")
        group_error_reasn = f"Group Creation failed with: Exception {repr(ex.args)}"
    return group_id, group_error_reasn


def create_role(token, organization_id, role_name, profile_configs):
    LOG.info(f"Creating role: {role_name}")
    role_id = 0
    role_error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    role_data = {"name": role_name, "managingOrganization": organization_id}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Role",
                                 data=json.dumps(role_data),
                                 headers=iam_headers)
        if response.status_code == 201:
            role_id = response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning("Role identity is already present, hence not creating")
            role_error_reasn = "Role identity is already present, hence not creating"
        else:
            LOG.error(
                f"Role Creation failed with: {json.dumps(response.json())}")
            role_error_reasn = f"Role Creation failed with: {json.dumps(response.json())}"
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Role Creation failed with: {ex}")
        role_error_reasn = f"Role Creation failed with Exception:{repr(ex.args)}"
    return role_id, role_error_reasn


def add_permissions_to_role(token, role_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    permission_data = [
        {"permissions": ["EMAILTEMPLATE.DELETE", "EMAILTEMPLATE.READ", "EMAILTEMPLATE.WRITE", "PROPOSITION.READ",
                         "PROPOSITION.WRITE", "APPLICATION.WRITE", "DEVICE.WRITE", "LOG.READ", "USER.READ",
                         "SCOPE.WRITE"]},
        {"permissions": ["USER.WRITE", "USER.DELETE", "ADMIN.READ",
                         "ADMIN.WRITE", "GROUP.READ", "GROUP.WRITE", "CLIENT.WRITE", 'ROLE.READ',
                         "ROLE.WRITE",
                         "SERVICE.READ",
                         "SERVICE.WRITE",
                         "APPLICATION.READ",
                         "APPLICATION.WRITE",
                         "CLIENT.READ", 'HSDP_IAM_MFA_POLICY.CREATE', 'HSDP_IAM_MFA_POLICY.READ',
                     'HSDP_IAM_MFA_POLICY.UPDATE', 'HSDP_IAM_MFA_POLICY.DELETE', 'CLIENT.SCOPES']}
    ]
    try:
        for permission in permission_data:
            response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Role/{role_id}/$assign-permission",
                                     data=json.dumps(permission),
                                     headers=iam_headers)
            if response.status_code in (200, 207):
                LOG.info("Permissions Added Successfully")
            else:
                LOG.error(
                    f"Error While Adding Permissions to Role: {json.dumps(response.json())}")
                response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While Adding Permissions to Role: {ex}")


def add_mdm_permissions_to_role(token, role_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    permission_data = {"permissions": ["MDM-PROPOSITION.CREATE", "MDM-PROPOSITION.UPDATE", "MDM-APPLICATION.CREATE",
                                       "MDM-OAUTHCLIENT.CREATE", "MDM-OAUTHCLIENT.READ",
                                       "MDM-DEVICEGROUP.CREATE", "MDM-DEVICEGROUP.DELETE", "MDM-DEVICEGROUP.READ", "MDM-DEVICEGROUP.UPDATE",
                                       "MDM-DEVICETYPE.CREATE", "MDM-DEVICETYPE.DELETE", "MDM-DEVICETYPE.READ", "MDM-DEVICETYPE.UPDATE",
                                       "SERVICE.WRITE"]}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Role/{role_id}/$assign-permission",
                                 data=json.dumps(permission_data),
                                 headers=iam_headers)
        if response.status_code in (200, 207):
            LOG.info("MDM Permissions Added Successfully")
        else:
            LOG.error(
                f"Error while Adding MDM permissions to Role: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while Adding MDM permissions to Role: {ex}")


def add_role_to_group(token, group_id, role_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"roles": [role_id]}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group/{group_id}/$assign-role",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 200:
            LOG.info("Role added to group Successfully")
        else:
            LOG.error(
                f"Error While adding Role to Group: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While adding Role to Group: {ex}")


def add_user_to_group(token, group_id, profile_configs, reference_user_uuid, prov_uuid_check=True):
    try:
        iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
        connect_prov_uuid = get_service_connect_prov_user(
            token, profile_configs)
        if prov_uuid_check and connect_prov_uuid is not None:
            data = {"resourceType": "Parameters",
                    "parameter": [{
                        "name": "UserIDCollection",
                        "references": [{"reference": reference_user_uuid},
                                       {"reference": connect_prov_uuid}]
                    }]}
        else:
            data = {"resourceType": "Parameters",
                    "parameter": [{
                        "name": "UserIDCollection",
                        "references": [{"reference": reference_user_uuid}]
                    }]}

        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group/{group_id}/$add-members",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 200:
            LOG.info("User added to Group successfully")
            return True
        else:
            LOG.error(
                f"Error while adding User to group: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while adding User to group: {ex}")
    return False


def get_service_connect_prov_user(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_FORM_URLENCODED,
                   X_TOKEN: token, API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    iam_headers = {"Content-Type": "application/x-www-form-urlencoded",
                   "X-Token": token,
                   "api-version": "1",
                   "Accept": "application/json"}
    try:
        response = requests.get(f"{profile_configs[VAULT_HSDP_IDM_URL]}/security/users?loginId={profile_configs[VAULT_DEVICE_PROVISION_NAME]}",
                                headers=iam_headers)
        if response.status_code == 200:
            return response.json()["exchange"]["users"][0]["userUUID"]
        else:
            LOG.error(
                f"Error while adding service connection to provision User to group: {json.dumps(response.json())}")
            response.raise_for_status()

    except Exception as ex:
        LOG.error(
            f"Error while adding service connection to provision User to group: {ex}")


def create_service_group_and_roles_for_suborg(token, org_id, service_id, profile_configs):
    """ Group creation """
    group_id, group_error_reasn = create_group(
        token, org_id, "ServiceGroup", "Group to enable service token operations", profile_configs)
    if group_id:
        LOG.info(f"group_id::::::{json.dumps((group_id))}\n")
        e_tag_value = get_group_details(
            token, group_id, profile_configs=profile_configs)["ETag"]
        """ Role creation """
        role_id, role_error_reasn = create_role(
            token, org_id, "SERVICEROLE", profile_configs)
        LOG.info(f"role_id::::::{json.dumps((role_id))}\n")
        LOG.info(f"role_error_reasn::::::{role_error_reasn}\n")

        if role_id is not None:
            add_permissions_to_role(token, role_id, profile_configs)
            add_mdm_permissions_to_role(token, role_id, profile_configs)
            add_role_to_group(token, group_id, role_id, profile_configs)
            add_service_to_group(token, group_id=group_id, service_id=service_id,
                                 e_tag_value=e_tag_value, profile_configs=profile_configs)
    return group_id, group_error_reasn


def add_service_to_group(token, group_id, service_id, e_tag_value, profile_configs):
    LOG.info("Adding service to group")
    iam_headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {token}", "api-version": "1", "If-Match": e_tag_value}
    data = {
        "memberType": "SERVICE",
        "value": [
            service_id
        ]
    }
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group/{group_id}/$assign",
                                 data=json.dumps(data),
                                 headers=iam_headers,
                                 verify=False)
        LOG.info(json.dumps(response.json()))
        if response.status_code == 200:
            LOG.info("Service added Successfully to Group")
        else:
            LOG.error(
                f"Error while adding service to group: {response.json()}")
            response.raise_for_status()

    except Exception as ex:
        LOG.error(ex)


def get_group_details(access_token, group_id, profile_configs):
    LOG.info(f"Fetching group details for id: {group_id}")
    iam_headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {access_token}", "api-version": "1"}

    try:
        response = requests.get(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group/{group_id}",
                                headers=iam_headers, verify=False)
        if response.status_code == 200:
            LOG.info("Fetched group details successfully")
            return response.headers
        else:
            LOG.error(
                f"Error while fetching group details: {response.json(())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(ex)


def get_group_details_by_name(token, group_name, profile_configs):
    LOG.info(f"Fetching group details for group_name: {group_name}")
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.get(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Group?organizationId={profile_configs[VAULT_PARENT_ORG_ID]}&name={group_name}",
                                headers=iam_headers,
                                verify=False)
        if response.status_code == 200:
            LOG.info("Fetched group details successfully")
            group_id = response.json()["entry"][0]["resource"]["_id"]
            return group_id
        else:
            LOG.error(
                f"Failed to fetch group details for name: {group_name} with error: {response.json()}")
    except Exception:
        LOG.exception(
            f"Failed to fetch group details for name: {group_name} with error: {response.json()}")
    return None


def get_service_details(access_token, service_issuer_id, profile_configs):
    iam_headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {access_token}", "api-version": "1"}
    try:
        response = requests.get(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/Service?serviceId={service_issuer_id}",
                                headers=iam_headers,
                                verify=False)
        if response.status_code == 200:
            return response.json()
        else:
            LOG.error(
                f"Error while getting service details: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(ex)
