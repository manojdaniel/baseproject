/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { RoccChatClient } from "@rocc/rocc-chat-library"
import { ECallStatus, EConnectionStatus, EResponse } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import isEmpty from "lodash.isempty"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { CALL_TYPE, INIT_AV_MESSAGE } from "../../../constants/constants"
import { setConversationClientStatus, setVideoCallStatus } from "../../../redux/actions/callActions"
import { GLOBAL_FORCE_CLEAN_UP } from "../../../redux/actions/types"
import { EClientStatus, IStore } from "../../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import { upsertCallStatus } from "../../helpers/callUtility"
import MessageHandler from "./av-messages/MessageHandler"
import { fetchCommunicationClientDetails } from "./messageService"

const FILE_NAME = "AVCallMessageWrapper"

enum ETwilioEvents {
    TOKEN_ABOUT_TO_EXPIRE = "tokenAboutToExpire",
    TOKEN_EXPIRED = "tokenExpired",
    MESSAGE_ADDED = "messageAdded",
    CONNECTION_STATE_CHANGED = "connectionStateChanged",
    CONNECTION_ERROR = "connectionError",
    DEFAULT = "default",
}

const CallMessageWrapper = () => {
    /**
     * fetch conversation token
     * create conversation client
     * subscribe for conversation event
     */

    const [chatClient, setChatClient] = useState({} as RoccChatClient)
    const [componentMounted, setComponentMounted] = useState(false)
    const [avMessages, setAvMessages] = useState(INIT_AV_MESSAGE)
    const dispatch = useDispatch()

    const { currentUser, forceCleanUp, applicationConnectionState } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser,
        forceCleanUp: state.externalReducer.forceCleanUp,
        applicationConnectionState: state.externalReducer.applicationConnectionState,
    }))

    const chatClientRef = useRef(chatClient)
    const userTokenRef = useRef(currentUser.accessToken)

    const createRoccChatClient = async (userToken?: string) => {
        /* Fetch communication & crypt tokens */
        const urls = fetchGlobalURLs()

        const { status, tokenDetails } = await fetchCommunicationClientDetails(
            urls.COMMUNICATION_SERVICES_URL, userToken ?? currentUser.accessToken, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            /* Fetch Chat client */
            const roccChatClient = new RoccChatClient({ communicationToken: tokenDetails.communicationToken })
            await roccChatClient.initializeClient()
            setChatClient(roccChatClient)
            setupConversationEventListeners(roccChatClient)
        } else {
            errorLogger(`Failed to create conversation client in caling app for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
            dispatchToParentStore({ type: GLOBAL_FORCE_CLEAN_UP, payload: { forceCleanUp: true } })
        }
        if (!componentMounted) {
            setComponentMounted(true)
        }
    }

    const cleanUpTasks = () => {
        if (!isEmpty(chatClientRef.current)) {
            infoLogger(`Initiating cleanup of conversation client in calling app for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
            chatClientRef.current.communicationShutdown()
            setChatClient({} as RoccChatClient)
        } else {
            infoLogger(`Couldn't close converation client for call application since it is already closed for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
        }
    }

    useEffect(() => {
        return () => {
            cleanUpTasks()
        }
    }, [])

    useEffect(() => { chatClientRef.current = chatClient }, [chatClient])
    useEffect(() => {
        userTokenRef.current = currentUser.accessToken
        if (currentUser.accessToken && isEmpty(chatClient)) {
            infoLogger(`Initializing Conversation client for calling application for user ${currentUser.uuid} and session: ${currentUser.sessionId}`)
            createRoccChatClient(currentUser.accessToken)
        }
    }, [currentUser.accessToken])

    useEffect(() => {
        if (!forceCleanUp && applicationConnectionState === EConnectionStatus.ONLINE && !isEmpty(chatClient)) {
            infoLogger(`Updating Conversation client in calling application for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
            updateToken(ETwilioEvents.DEFAULT)
        }
    }, [forceCleanUp, applicationConnectionState])

    const setupConversationEventListeners = (chatClient: RoccChatClient, initVideoCallStatus: boolean = false) => {
        if (initVideoCallStatus) {
            dispatch(setVideoCallStatus(upsertCallStatus("", ECallStatus.IDLE)))
        }
        dispatch(setConversationClientStatus(EClientStatus.ONLINE))
        chatClient.communicationOnEvent(ETwilioEvents.MESSAGE_ADDED, messageAdded)
        chatClient.communicationOnEvent(ETwilioEvents.TOKEN_ABOUT_TO_EXPIRE, () => updateToken(ETwilioEvents.TOKEN_ABOUT_TO_EXPIRE))
        chatClient.communicationOnEvent(ETwilioEvents.TOKEN_EXPIRED, () => updateToken(ETwilioEvents.TOKEN_EXPIRED))
        chatClient.communicationOnEvent(ETwilioEvents.CONNECTION_STATE_CHANGED, connectionStateChanged)
        chatClient.communicationOnEvent(ETwilioEvents.CONNECTION_ERROR, handleConnectionError)
        infoLogger(`Conversation client creation in calling app is successful...`)
    }

    const messageAdded = (message: any) => {
        if (message.state.body && message.state.body.trim().length > 0) {
            const messageBody = JSON.parse(message.state.body)
            if (messageBody[CALL_TYPE] !== undefined) {
                infoLogger(`${FILE_NAME} Receive AV call message for contextId ${messageBody.contextId} for event ${messageBody[CALL_TYPE]}`)
                setAvMessages({ contextId: messageBody.contextId, eventType: messageBody[CALL_TYPE], participant: messageBody.participant })
            }
        }
    }

    const updateToken = async (event: ETwilioEvents) => {
        infoLogger(`${FILE_NAME} Updating ChatClient`)
        const urls = fetchGlobalURLs()
        const { status, tokenDetails } = await fetchCommunicationClientDetails(urls.COMMUNICATION_SERVICES_URL, userTokenRef.current, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            if (!isEmpty(chatClientRef.current)) {
                infoLogger(`Existing Communication client is updated with new token by event: ${event}`)
                chatClientRef.current.communicationUpdateToken(tokenDetails.communicationToken)
            } else {
                infoLogger(`Communication client is re-created by event: ${event}`)
                createRoccChatClient(userTokenRef.current)
            }
        } else {
            dispatchToParentStore({ type: GLOBAL_FORCE_CLEAN_UP, payload: { forceCleanUp: true } })
        }
    }

    const connectionStateChanged = (message: any) => {
        if (componentMounted) {
            const { OFFLINE, ONLINE, FAILED } = EClientStatus
            switch (message.toLowerCase()) {
                case "disconnecting":
                    dispatch(setConversationClientStatus(OFFLINE))
                    infoLogger(`ChatClient is disconnecting for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    break
                case "connected":
                    dispatch(setConversationClientStatus(ONLINE))
                    infoLogger(`ChatClient is connected for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    break
                case "denied":
                case "error":
                    /** ChatClient creation failed trying to recreate chatClient */
                    errorLogger(`ChatClient is disconnected, trying to reconnect for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    dispatch(setConversationClientStatus(FAILED))
                    updateToken(ETwilioEvents.DEFAULT)
                    break
                default:
            }
        }
    }

    const handleConnectionError = (errorMessage: any) => {
        const { terminal, message, errorCode, httpStatusCode } = errorMessage
        errorLogger(`For User: ${currentUser.uuid}, encountered connection error in calling application with message: ${message}, terminal: ${terminal}, errorCode: ${errorCode}, httpStatusCode: ${httpStatusCode}`)
    }

    return (
        <MessageHandler
            eventType={avMessages.eventType}
            contextId={avMessages.contextId}
            participant={avMessages.participant} />
    )
}

export default CallMessageWrapper
