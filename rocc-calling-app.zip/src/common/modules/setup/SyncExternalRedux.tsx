/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore } from "@rocc/rocc-client-services"
import React, { useEffect } from "react"
import { APP_NAME, PARENT_STORE } from "../../../constants/constants"
import { SYNC_PARENT_REDUCERS } from "../../../redux/actions/types"
import globalStore from "../../../redux/store/globalStore"
import store from "../../../redux/store/store"

const SyncExternalRedux = () => {
    const syncParentStore = () => {
        const gState = globalStore.GetGlobalState()
        if (gState[PARENT_STORE]) {
            updateUserInfo(gState[PARENT_STORE])
            globalStore.SubscribeToPartnerState(APP_NAME, PARENT_STORE, (changedState: any) => {
                updateUserInfo(changedState)
            })
        }
    }

    useEffect(() => {
        syncParentStore()
    }, [globalStore])

    const updateUserInfo = (changedState: IParentStore) => {
        /* Update if session of parent app is updated */
        const payload = {
            currentUser: changedState.userReducer.currentUser,
            appState: changedState.userReducer.appState,
            sideBar: changedState.appReducer.sideBar,
            notificationMessage: changedState.modalReducer.notificationMessage,
            rooms: changedState.customerReducer.rooms,
            forceCleanUp: changedState.userReducer.forceCleanUp,
            featureFlags: changedState.featureFlagsReducer.featureFlags,
            permissions: changedState.userReducer.permissions,
            workflows: changedState.workflowReducer.workflows,
            applicationConnectionState: changedState.clientStatusReducer.applicationConnectionState,
        }
        store.dispatch({ type: SYNC_PARENT_REDUCERS, payload })
    }
    return <></>
}

export default SyncExternalRedux
