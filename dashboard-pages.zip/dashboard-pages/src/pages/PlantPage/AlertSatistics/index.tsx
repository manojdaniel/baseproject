import React, { useRef, useEffect, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import "./AlertDashboard/AlertDashboard.scss";
import average_response_time from "../../../assets/images/average_response_time.svg";
import utilization from "../../../assets/images/utilization.svg";
import { useDispatch, useSelector } from "react-redux";
import {
	getPlantUtilizationTime,
	getPlantAlertStatus,
} from "../../../redux/reducers/CommonReducer";
import { useLocation } from "react-router-dom";
import { encryptRSAData } from "../../../utility/rsa";

const AlertSatistics = () => {
	let navigate = useNavigate();
	let dispatch = useDispatch();
	const location = useLocation();

	const DATA = [
		{ id: "alertDashboard", value: "Alert dashboard" },
		{ id: "alertList", value: "Alert List" },
		{ id: "plantTimeline", value: "Plant TIMELINE" },
	];

	const [elements, setElements] = useState(DATA);
	const [selectedID, setSelectedID] = useState(1); // you could set a default id as well
	const [mouseHoverTooltip, setMouseHoverTooltip] = useState<any>(false);

	const [utilizationTime, setUtilizationTime] = useState(1);

	const { plantUtilizationTime, globalSelecetedPlant } = useSelector(
		(state: any) => ({
			plantUtilizationTime: state.Common.plantUtilizationTime,
			globalSelecetedPlant: state.Common.globalSelecetedPlant,
		})
	);
	// useEffect(() => {
	//     handleMenuClick(1)
	// }, []);

	const handleMenuClick = (id: any) => {
		setSelectedID(id);
		switch (id) {
			case "alertDashboard":
				navigate("/plant/alertSatistics/alertDashboard");
				break;
			case "alertList":
				dispatch(getPlantAlertStatus(""));
				navigate("/plant/alertSatistics/alertList");
				break;
			case "plantTimeline":
				navigate("/plant/alertSatistics/plantTimeline");
				break;

			default:
				break;
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	useEffect(() => {
		if (Object.keys(globalSelecetedPlant).length > 0) {
			dispatch(
				getPlantUtilizationTime(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Pie Chart//{plantId}/{userid}
		}
	}, []);

	useEffect(() => {
		if (plantUtilizationTime.length > 0) {
			setUtilizationTime(plantUtilizationTime[0].utilization);
		}
	}, [plantUtilizationTime]);

	const onMouseEnterHandler = () => {
		setMouseHoverTooltip(true);
	};
	const onMouseLeaveHandler = () => {
		setMouseHoverTooltip(false);
	};

	let currentPathname =
		location.pathname.split("/")[3] !== undefined
			? location.pathname.split("/")[3]
			: location.pathname.split("/")[2];

	const TopContainer = () => {
		return (
			<div id="alert-statistics-menu">
				<div className="alert-stats-menu-one">
					{elements.map((el) => (
						<a
							key={el.id}
							className={`top-container-conten ${
								currentPathname === el.id ? "active" : ""
							}`}
							onClick={() => handleMenuClick(el.id)}
						>
							{el.value}
						</a>
					))}
				</div>
				<div
					onMouseEnter={onMouseEnterHandler}
					onMouseLeave={onMouseLeaveHandler}
					className="alert-stats-menu-two"
				>
					<div className="asm-inner">
						<div>
							<img src={utilization} />
						</div>
						<div>
							<span>{utilizationTime}%</span>
							<span>UTILIZATION</span>
						</div>
					</div>
					{mouseHoverTooltip === true ? (
						<div className="status-tooltip">
							<div className="status-tooltip-head">
								<span className="status-title">What is Utilization</span>
							</div>
							<div className="status-tooltip-box">
								<div className="status-tooltiprow">
									Measures the utilization of the AHC solution by attending
									anomaly alerts through classifying them and conduct required
									investigation by SME. It is a calculated value based on the
									number of solution anomaly alerts.
								</div>
							</div>
						</div>
					) : (
						""
					)}
				</div>
				{/* <div className="alert-stats-menu-three">
                    <div className="asm-inner">
                        <div><img src={average_response_time} /></div>
                        <div>
                            <span>33D</span>
                            <span>AVERAGE RESPONSE TIME</span>
                        </div>
                    </div>
                </div> */}
			</div>
		);
	};

	return (
		<div id="alert-dashboard-box">
			<TopContainer />
			{/* AlertSatistics */}
			<Outlet />
		</div>
	);
};
export default AlertSatistics;
