"""
 Created on Thu Jul 20 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import json
from src.constants.headers import REGION_CONFIG_FILE_PATH
from src.wrappers.platform_services.communication_services.region_config_services import create_new_region_config, fetch_region_config_data, update_region_config
import traceback
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_PARENT_ORG_ID

from src.constants.constants import ROCC_PROXY_URL, COMPLETED
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit

LOG = create_logger("RegionConfigSetup")


class RegionConfigSetup:
    def __init__(self):
        self._success = False

    def start_job(self, profile_configs, rocc_proxy_url, user_details):
        try:
            LOG.info(f"Starting Job: {EJobs.REGION_CONFIG_SETUP.value}")
            self.load_proxy_url(rocc_proxy_url=rocc_proxy_url)
            self.load_vault_configs(profile_configs)
            self._user_uuid = user_details["userId"]
            self._user_org = user_details["orgId"]
            self._token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                          issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                          private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self.extract_configs()
            self.task_manage_region_config()
            prepare_and_post_audit(event_type=EJobs.REGION_CONFIG_SETUP.value, event_subtype=EJobs.REGION_CONFIG_SETUP.value, action="E", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=self._profile_configs[VAULT_PARENT_ORG_ID],
                                   token=self._token,
                                   **{EJobs.REGION_CONFIG_SETUP.value: COMPLETED},
                                   **{"User Org Details": self._user_org})
            LOG.info(f"Finished Job: {EJobs.REGION_CONFIG_SETUP.value}")
        except RoccException as e:
            LOG.error("Exception {e}")
            raise RoccException(e.status_code, str(e.payload))
        except Exception as e:
            LOG.error(f"General exception occured during RBAC infra setup {e}")
            LOG.error(traceback.print_exc())
        return self._success

    def load_vault_configs(self, profile_configs):
        """Fetch vault configs from the profile path"""
        try:
            self._profile_configs = profile_configs if profile_configs else get_profile_data()
            LOG.info("Profile configs loaded")
        except Exception as ex:
            LOG.error(f"Failed to retrieve vault profile configs with error: {ex}")
            self._success = False
            raise RoccException(500, f"Failed to retrieve vault profile configs with error: {ex}")

    def extract_configs(self):
        """Extract configs"""
        try:
            LOG.info(f"Reading vault configurations from file: {REGION_CONFIG_FILE_PATH}")
            with open(REGION_CONFIG_FILE_PATH) as f:
                self._configs = json.load(f)
        except Exception as ex:
            LOG.error(f"Failed to extract Rbac configurations with error: {ex}")
            self._success = False
            raise RoccException(500, f"Failed to load region configs with error: {ex}")

    def load_proxy_url(self, rocc_proxy_url=None):
        """Fetch proxy url"""
        try:
            self._rocc_proxy_url = rocc_proxy_url if rocc_proxy_url else os.environ[ROCC_PROXY_URL]
        except Exception as ex:
            LOG.error(f"Failed to retrieve proxy url with error: {ex}")
            self._success = False
            raise RoccException(500, f"Failed to retrieve proxy url with error: {ex}")

    def roll_back_on_failure(self):
        """ Roll-back, if there is a failed task """
        pass

    def task_manage_region_config(self):
        """
        Loop through region config
        Update communication service with region value
        """
        region_configs = self._configs["REGION_CONFIGS"]
        org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
        response = True
        for region in region_configs:
            create_response = False
            update_response = False
            try:
                existing_config = fetch_region_config_data(url=self._rocc_proxy_url,
                                                           token=self._token,
                                                           country_code=region["countryIsoCode"])
                if not existing_config:
                    create_response = create_new_region_config(url=self._rocc_proxy_url,
                                                               token=self._token,
                                                               data=region)
                elif not self.check_if_region_config_equal(existing_config, region):
                    update_response = update_region_config(url=self._rocc_proxy_url,
                                                           data=region,
                                                           id=existing_config["id"],
                                                           token=self._token)

                prepare_and_post_audit(event_type="Parent org Region config setup", event_subtype="Setup region config", action="C", outcome=0,
                                       user_detail=self._user_uuid,
                                       org_id=org_id,
                                       token=self._token,
                                       **{"Setup regio config": COMPLETED},
                                       **{"User Org Details": self._user_org})
                if response:
                    response = create_response or update_response

            except Exception as e:
                response = False
                LOG.error(f"Exception occurred while region config {region} creation.")

        self._success = True if response else False

    def check_if_region_config_equal(self, existing_config, new_config):
        return self.sorting(existing_config) == self.sorting(new_config)

    def sorting(self, item):
        if isinstance(item, dict):
            return sorted((key, self.sorting(values)) for key, values in item.items())
        if isinstance(item, list):
            return sorted(self.sorting(x) for x in item)
        else:
            return item
