/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoccVideoCall, RoccAvLocalTrack, RoccAvRoom, RoccParticipant } from "@rocc/rocc-av-communication-sdk"
import { IUserInfo, ECallStatus, IParticipantInfo } from "@rocc/rocc-client-services"
import { MutableRefObject, ReactFragment } from "react"
import { ECommunicationRoomType } from "../../../types/types"
import { IAudioVideoCallingProps } from "./AudioVideoCalling"

export interface IInitiateVideoCallFunction {
    currentUser: IUserInfo
    contactUuid: string
    communicationServiceUrl: string
    mediaType: string[]
    communicationRoomType: ECommunicationRoomType
}

export interface IParticipantObject {
    primaryUuid: string
    callStatus: ECallStatus
    secondaryUUID: string[]
}

export interface IEndCallProps {
    currentUser: IUserInfo
    communicationServiceUrl: string
    contextId: string
}

export enum ECallOptions {
    SETTINGS,
    ADD_PARTICIPANT,
    NONE,
}

export enum EMPCOptions {
    SHOW_PARTICIPANT,
    ADD_PARTICIPANT,
}

export interface IAudioVideoCallWindowProps extends IAudioVideoCallingProps {
    activeRoom: RoccAvRoom
    remoteMediaRef: MutableRefObject<any>
    dominantSpeaker: IParticipantInfo
    setDominantSpeaker: (participant: IParticipantInfo) => void
    updateRemoteAudioTrackStatus: (status: boolean, participant: RoccParticipant) => void
    setRemoteUserVideoStatus: (status: boolean) => void
    localMediaRef: MutableRefObject<any>
    signalStrength: number
    remoteUserVideoStatus: boolean
    remoteAudioTrackStatus: boolean
    previewTracks: RoccAvLocalTrack[]
    videoStatus: boolean
    setVideoStatus: (videoStatus: boolean) => void
    callDuration: ReactFragment
    vendorService: IRoccVideoCall
}

export interface IAVSourcesStatus {
    volumeStatus: boolean
    videoStatus: boolean
    microphoneStatus: boolean
}

export interface ICommunicationViewProps extends ICallControls {
    partnerRole: string
    selectedCallOption: ECallOptions
    renderLocalMedia: any
    renderRemoteMedia: any
    signalStrength?: number
    displayName: string
    remoteUserVideoStatus: boolean
    callDuration: ReactFragment
    viewingAndCallingDifferentRoom: boolean
    userName: string
    remoteAudioTrackStatus: boolean
    dominantSpeaker: IParticipantInfo
}

export interface ICallControls {
    showSettings: boolean
    audioStatus: boolean
    volumeStatus: boolean
    videoStatus: boolean
    numOfParticipant: number | undefined
    activeRoom: RoccAvRoom
    showSettingOptions: () => void
    toggleLocalAudio: () => void
    toggleVolume: () => void
    toggleLocalVideo: () => void
    handleConsoleClick: () => void
    displayCallOptions: (callOptions: ECallOptions) => void
}

export enum EComponentStatus {
    INITIATION = "INITIATION",
    LOADING = "LOADING",
    COMPLETED = "COMPLETED",
    CANCELLED = "CANCELLED",
}
