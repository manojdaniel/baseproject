import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AssetCard from "./AssetCard";

jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});

describe("AssetCard", () => {
	const data = [
		{
			timeStamp: "2023-04-26T19:15:00.000Z",
			description: "Alert 1",
			status: "Active",
		},
		{
			timeStamp: "2023-04-25T18:30:00.000Z",
			description: "Alert 2",
			status: "Resolved",
		},
	];

	it("should render the component without errors", () => {
		render(<AssetCard data={data} />);
	});
});
//   it("displays data correctly", () => {
//     const { getByText } = render(<AssetCard data={data} />);

//     expect(getByText("26/04/2023 07:15:00 PM")).toBeInTheDocument();
//     expect(getByText("Alert 1")).toBeInTheDocument();
//     expect(getByText("Active")).toHaveStyle("color: red");

//     expect(getByText("25/04/2023 06:30:00 PM")).toBeInTheDocument();
//     expect(getByText("Alert 2")).toBeInTheDocument();
//     expect(getByText("Resolved")).toHaveStyle("color: inherit");
//   });

//   it("formats the timestamps correctly", () => {
//     const { getByText } = render(<AssetCard data={data} />);

//     expect(getByText("26/04/2023 07:15:00 PM")).toBeInTheDocument();
//     expect(getByText("25/04/2023 06:30:00 PM")).toBeInTheDocument();
//   });
// });
