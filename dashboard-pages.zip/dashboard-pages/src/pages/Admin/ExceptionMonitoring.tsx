import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ExceptionMonitoringTable from "table/ExceptionMonitoringTable";
import {
	getExceptionLog,
	getExceptionLogById,
} from "../../redux/reducers/CommonReducer";
import ReportCalendarPopup from "../../components/ReportCalendarPopup/ReportCalendarPopup";
import useOnClickOutside from "../../hooks/useOnClickOutside";
import iconCalendar from "../../assets/images/icon_calendar.svg";
import moment from "moment";
import "../Admin/Admin.scss";
import Loader from "components/Loader";
import { Modal } from "antd";
import { encryptRSAData } from "../../utility/rsa";

const ExceptionMonitoring = () => {
	// From Date To Date Start
	const [commonExceptionFromDateFormat, setcommonExceptionFromDateFormat] =
		useState<any>();
	const [commonExceptionToDateFormat, setcommonExceptionToDateFormat] =
		useState<any>();
	const [commonExceptionFromDate, setcommonExceptionFromDate] = useState<any>();
	const [commonExceptionToDate, setcommonExceptionToDate] = useState<any>();
	const [showPicker, setShowPicker] = useState(false);
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	const ref = useRef(null);
	useOnClickOutside(ref, () => setShowPicker(false));

	const [showSearch, setShowSearch] = useState(false);
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [exceptionData, setExceptionData] = useState<any>({
		logId: "",
		logDate: "",
		exceptionMsg: "",
		exceptionType: "",
		exceptionSource: "",
		stackTrace: "",
	});
	// From Date To Date End
	let dispatch = useDispatch();

	const {
		exceptionLogData,
		loadingExceptionLogs,
		exceptionLog,
		loadingExceptionLog,
	} = useSelector((state: any) => ({
		exceptionLogData: state.Common.exceptionLogs,
		loadingExceptionLogs: state.Common.loadingExceptionLogs,

		exceptionLog: state.Common.exceptionLog,
		loadingExceptionLog: state.Common.loadingExceptionLog,
	}));
	useEffect(() => {
		if (exceptionLogData.length > 0) {
			setParentData(exceptionLogData);
			setData(exceptionLogData);
		}
	}, [exceptionLogData]);

	useEffect(() => {
		if (Object.keys(exceptionLog).length > 0) {
			setExceptionData((data) => ({
				...data,
				logId: exceptionLog[0].logId,
				logDate: exceptionLog[0].logDate,
				exceptionMsg: exceptionLog[0].exceptionMsg,
				exceptionType: exceptionLog[0].exceptionType,
				exceptionSource: exceptionLog[0].exceptionSource,
				stackTrace: exceptionLog[0].stackTrace,
			}));
		}
		setCurrentScreenWidth(window.innerWidth);
		// dispatch(getExceptionLogById('18'));
	}, [exceptionLog]);
	// useEffect(() => {
	//     dispatch(getExceptionLog(`${commonExceptionFromDateFormat}/${commonExceptionToDateFormat}`));
	// }, [commonExceptionFromDateFormat,commonExceptionToDateFormat]);

	const showExceptionMonitoringTable = () => {
		dispatch(
			getExceptionLog(
				encryptRSAData(
					`fromDate=${commonExceptionFromDateFormat}&toDate=${commonExceptionToDateFormat}`
				)
			)
		);
		setShowSearch(true);
	};
	// Report Date Start======================

	const handleExceptionFromDate = (date: any) => {
		setcommonExceptionFromDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonExceptionFromDateFormat(upatedDate);
	};

	const handleExceptionToDate = (date: any) => {
		setcommonExceptionToDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonExceptionToDateFormat(upatedDate);
	};
	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.logId !== null &&
				item.logId
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.exceptionMsg !== null &&
				item.exceptionMsg
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.exceptionType !== null &&
				item.exceptionType
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.exceptionSource !== null &&
				item.exceptionSource
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.stackTrace !== null &&
				item.stackTrace
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.logDate !== null &&
				item.logDate
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};

	const exceptionHandle = (logId) => {
		dispatch(getExceptionLogById(encryptRSAData(`logId=${logId}`)));
		setIsModalOpen(true);
	};
	const handleCancel = () => {
		setIsModalOpen(false);
	};
	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9- ]+$/i.test(keyValue)) event.preventDefault();
	};
	// Report Date End======================
	const reportFromDate =
		commonExceptionFromDateFormat !== undefined
			? commonExceptionFromDateFormat
			: "";
	const reportToDate =
		commonExceptionToDateFormat !== undefined
			? commonExceptionToDateFormat
			: "";
	return (
		<div id="exceptionmonitoring">
			<div id="new-filter" className="pb0">
				<div className="nf-left">
					<div className="title">EXCEPTION MONITORING</div>
				</div>
				<div className="nf-right">
					<div>
						<div id="ReportCalendar" ref={ref}>
							<input
								type="text"
								value={`${reportFromDate} ${reportToDate}`}
								style={{ float: "left" }}
							/>
							<a
								className="mobile-calendar"
								onClick={() => setShowPicker(!showPicker)}
							>
								<img
									src={iconCalendar}
									title="calendar"
									style={{ float: "left" }}
								/>
							</a>
							{showPicker ? (
								<ReportCalendarPopup
									commonReportFromDateFormat={commonExceptionFromDateFormat}
									commonReportToDateFormat={commonExceptionToDateFormat}
									commonReportFromDate={commonExceptionFromDate}
									commonReportToDate={commonExceptionToDate}
									handleReportFromDate={handleExceptionFromDate}
									handleReportToDate={handleExceptionToDate}
								/>
							) : null}
						</div>
						<button
							onClick={showExceptionMonitoringTable}
							className="em-search"
						>
							SUBMIT{" "}
						</button>
					</div>
					<div className="rightsearch">
						<input
							type="search"
							value={query}
							onChange={handleChange}
							placeholder="Search..."
							disabled={!showSearch}
							onKeyPress={handleKeyPress}
							onPaste={handleKeyPress}
						/>
					</div>
				</div>
			</div>
			{/* <div className="common-box-filter em-filter-box">
                    <div className="title">EXCEPTION MONITORING</div>
                    <div className="common-options exceptionmonitoring-filter">
                            <div id="ReportCalendar" style={{width:"200px"}} ref={ref}>
                                    <input type="text" value= { `${reportFromDate} ${reportToDate}`} style={{float:"left"}}/>
                                    <a className="mobile-calendar" onClick={() => setShowPicker(!showPicker)}><img src={iconCalendar} title="calendar" style={{float:"left"}}/></a>
                                    {showPicker ? <ReportCalendarPopup  
                                        commonReportFromDateFormat={commonExceptionFromDateFormat}
                                        commonReportToDateFormat={commonExceptionToDateFormat}
                                        commonReportFromDate={commonExceptionFromDate}
                                        commonReportToDate={commonExceptionToDate}
                                        handleReportFromDate={handleExceptionFromDate}
                                        handleReportToDate={handleExceptionToDate}
                                    /> : null}
                            </div>
                    </div>
                <div>
                    <button onClick={showExceptionMonitoringTable} className="em-search">SUBMIT </button>
                </div>
                </div> */}

			<div className="common-box-content">
				{loadingExceptionLogs ? (
					<div className="tc-loaderpd"><Loader /></div>
				) : (
					// <ExceptionMonitoringTable
					// 	data={data}
					// 	exceptionHandle={exceptionHandle}
					// />
					<div className="tc-loaderpd"><Loader /></div>
				)}
			</div>
			{currentScreenWidth > 3000 ? (
				<Modal
					title="Exception Details"
					open={isModalOpen}
					onCancel={handleCancel}
					bodyStyle={{ height: 600, overflowY: "scroll" }}
					onOk={handleCancel}
					cancelButtonProps={{ style: { display: "none" } }}
					width={"70%"}
				>
					{loadingExceptionLog ? (
						<Loader />
					) : (
						<>
							<div>Log ID</div>
							<div>{exceptionData.logId}</div>
							<div>Log Date</div>
							<div>{exceptionData.logDate}</div>
							<div>Exception Message</div>
							<div>{exceptionData.exceptionMsg}</div>
							<div>Exception Type</div>
							<div>{exceptionData.exceptionType}</div>
							<div>Exception Source</div>
							<div>{exceptionData.exceptionSource}</div>
							<div>Stack Trace</div>
							<div>{exceptionData.stackTrace}</div>
						</>
					)}
				</Modal>
			) : currentScreenWidth < 1500 ? (
				<Modal
					title="Exception Details"
					open={isModalOpen}
					onCancel={handleCancel}
					bodyStyle={{ height: 400, overflowY: "scroll" }}
					onOk={handleCancel}
					cancelButtonProps={{ style: { display: "none" } }}
					width={"70%"}
				>
					{loadingExceptionLog ? (
						<Loader />
					) : (
						<>
							<div>Log ID</div>
							<div>{exceptionData.logId}</div>
							<div>Log Date</div>
							<div>{exceptionData.logDate}</div>
							<div>Exception Message</div>
							<div>{exceptionData.exceptionMsg}</div>
							<div>Exception Type</div>
							<div>{exceptionData.exceptionType}</div>
							<div>Exception Source</div>
							<div>{exceptionData.exceptionSource}</div>
							<div>Stack Trace</div>
							<div>{exceptionData.stackTrace}</div>
						</>
					)}
				</Modal>
			) : (
				<Modal
					title="Exception Details"
					open={isModalOpen}
					onCancel={handleCancel}
					bodyStyle={{ height: 500, overflowY: "scroll" }}
					style={{ width: 1000 }}
					onOk={handleCancel}
					cancelButtonProps={{ style: { display: "none" } }}
					width={"70%"}
				>
					{loadingExceptionLog ? (
						<Loader />
					) : (
						<>
							<div>Log ID</div>
							<div>{exceptionData.logId}</div>
							<div>Log Date</div>
							<div>{exceptionData.logDate}</div>
							<div>Exception Message</div>
							<div>{exceptionData.exceptionMsg}</div>
							<div>Exception Type</div>
							<div>{exceptionData.exceptionType}</div>
							<div>Exception Source</div>
							<div>{exceptionData.exceptionSource}</div>
							<div>Stack Trace</div>
							<div>{exceptionData.stackTrace}</div>
						</>
					)}
				</Modal>
			)}
		</div>
	);
};
export default ExceptionMonitoring;
