/*
 * Created on Wed Nov 09 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import SidebarContent from "./SidebarContent"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        sideBar: "",
        currentUser: {},
    }),
}))

jest.mock("@virgilsecurity/e3kit-browser", () => ({
    EThree: jest.fn()
}))
describe("SidebarContent test cases", () => {

    it("SidebarContent should be rendered with id", () => {
        const wrapper = shallow(<SidebarContent contacts={[]} />)
        expect(wrapper.find("div").get(0).props.id).toEqual("SidebarContent")
    })
})
