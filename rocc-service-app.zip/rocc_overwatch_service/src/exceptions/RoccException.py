"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.utility.utility import construct_negative_response


class RoccException(Exception):
    """Base RoccException Class"""
    status_code = 500

    def __init__(self, status_code=None, title=None, payload=None, additional_info=None):
        Exception.__init__(self)
        if status_code is not None:
            self.status_code = status_code
        self.title = title
        self.payload = payload
        self.additional_info = additional_info

    def to_dict(self):
        return construct_negative_response(self.status_code, self.title, self.payload, self.additional_info)
