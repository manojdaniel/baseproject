/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import RenderRemoteMedia from "./RenderRemoteMedia"
import * as Redux from "react-redux"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import { DEFAULT_CONTACT_INFO } from "@rocc/rocc-client-services"
import { withHooks } from "jest-react-hooks-shallow"
import { ACTIVE_CALL_MESSAGE } from "../../../constants/constants"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn(),
}))

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const mockAppState: any = {
    callReducer: {
        callMessage: {
            messageType: "", message: "", content: DEFAULT_CONTACT_INFO,
        },
    }
}

let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")

const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const getShallowWrapper = (props: any) => { return shallow(<RenderRemoteMedia {...props} />) }
const findElement = (props: any) => {
    wrapper = getShallowWrapper(props)
    const callWindowBody = wrapper.find("CallWindowBody")
    expect(callWindowBody).toHaveLength(1)
}
const props: any = {
    remoteMediaRef: null,
    remoteUserVideoStatus: true,
    dominantSpeaker: {
        name: "Test Name",
    },
    isDevice: false,
    cssStyleClass: { active: true },
    signalStrength: -1,
    callDuration: null,
    isDesktopFullScreen: false,
    activeCall: {
        numOfParticipants: -1,
    }
}

describe("RenderRemoteMedia component with waiting for other participant", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })
    it("should render div with callWindowBody", () => {
        withHooks(() => {
            findElement(props)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("RenderRemoteMedia component with participant left the call", () => {
    beforeEach(() => {
        mockAppState.callReducer.numOfParticipants = 0
        useSelectorMock(mockAppState)
    })
    it("should render div with callWindowBody", () => {
        withHooks(() => {
            findElement(props)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("RenderRemoteMedia component with active call message", () => {
    beforeEach(() => {
        mockAppState.callReducer.numOfParticipants = 1
        useSelectorMock(mockAppState)
    })
    it("should render div with callWindowBody with signalStrength 0", () => {
        withHooks(() => {
            props.signalStrength = 0
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 1", () => {
        withHooks(() => {
            props.signalStrength = 1
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 2", () => {
        withHooks(() => {
            props.signalStrength = 2
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 3", () => {
        withHooks(() => {
            props.signalStrength = 3
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 4", () => {
        withHooks(() => {
            props.signalStrength = 4
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 5", () => {
        withHooks(() => {
            props.signalStrength = 5
            findElement(props)
        })
    })
    it("should render div with callWindowBody with signalStrength 6", () => {
        withHooks(() => {
            props.signalStrength = 6
            findElement(props)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("RenderRemoteMedia component with waiting for other participant", () => {
    beforeEach(() => {
        mockAppState.callReducer.callMessage = { messageType: ACTIVE_CALL_MESSAGE, message: "" }
        useSelectorMock(mockAppState)
    })
    it("should render div with callWindowBody", () => {
        withHooks(() => {
            findElement(props)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
