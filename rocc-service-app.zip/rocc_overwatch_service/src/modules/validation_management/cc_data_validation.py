"""
 Created on Fri Oct 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import COMMAND_CENTERS_DICT, TEMPLATE_VERSION_1_0_0, TEMPLATE_DETAILS
from src.constants.enums import ESummaryStates
from src.constants.headers import EXCEL_CC_SEAT_INFO, EXCEL_CC_IP, EXCEL_CC_SEAT_NAME, EXCEL_RECEIVER_SEAT_NAME
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_site_id_from_db_with_site_short_name
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.validation_service.cc_data_validation_service import fetch_cc_data
from src.utility.semver import parse_version
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("CcDataValidation")


class CcDataValidation():

    def __init__(self, service_token, org_infra_uuid):
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)

    def verify_cc_data_exists(self, cc_data_dict):
        new_cc = self._transaction_data["summary"]["cc"]["new"]
        for cc, cc_detail in cc_data_dict.items():
            if cc in new_cc:
                rc_name_key = EXCEL_CC_SEAT_NAME if parse_version(self._template_version) == parse_version(TEMPLATE_VERSION_1_0_0) else EXCEL_RECEIVER_SEAT_NAME
                seat_name_key = EXCEL_CC_SEAT_NAME
                cc_present = fetch_cc_data(client=self._client,
                                           rx_ip=cc_detail[EXCEL_CC_IP],
                                           seat_name=cc_detail[seat_name_key],
                                           rx_name=cc_detail[rc_name_key],
                                           seat_info=cc_detail[EXCEL_CC_SEAT_INFO])
                self.update_summary_object(cc, cc_detail, cc_present)
            else:
                LOG.info(f"This cc {cc} is not a new command center, skipping validation ..!")
        return cc_data_dict, self._transaction_data

    def update_summary_object(self, cc, cc_detail, cc_present):
        if not cc_present:
            self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", cc, ESummaryStates.VALIDATION_FAILED)
            LOG.info(f"CC Data for receiver: {cc_detail[EXCEL_CC_IP]} not found.")
            cc_detail["isPresent"] = False
        else:
            LOG.info(f"CC Data for receiver: {cc_detail[EXCEL_CC_IP]} is inserted correctly !")
            cc_detail["isPresent"] = True

    def initiate_data_validation(self, data_dict, transaction_data):
        """
        1. with data_dict. Iterate and see if all records are present in DB
        2. Make a separate dict(summanry_dict) with invalid records
        3. Return the dict back to job
        """
        self._cc_data = data_dict[COMMAND_CENTERS_DICT]
        self._template_version = data_dict[TEMPLATE_DETAILS]["version"]
        self._transaction_data = transaction_data
        self._cc_data, self._transaction_data = self.verify_cc_data_exists(cc_data_dict=self._cc_data)
        LOG.info("Command Center data validation is complete ..!!")
        return data_dict, self._transaction_data
