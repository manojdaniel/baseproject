// Import the required dependencies for testing React components
import React from "react";
import { render, screen } from "@testing-library/react";

// Import the component that needs to be tested
import BreadCrumb from "./BreadCrumb";

// Import the required testing library and extend its expectations
import "@testing-library/jest-dom/extend-expect";

// Describe a test suite for the BreadCrumb component
describe("BreadCrumb", () => {
	// Test to check if the breadcrumb renders correctly
	it("renders the breadcrumb correctly", () => {
		// Render the BreadCrumb component
		render(<BreadCrumb />);

		// Find the Home, Yanpet and Poly 2 links by their role and name attributes
		const homeLink = screen.getByRole("link", { name: /home/i });
		const yanpetLink = screen.getByRole("link", { name: /yanpet/i });
		const polyLink = screen.getByRole("link", { name: /poly 2/i });

		// Expect the Home link to have an href attribute with a value of #
		expect(homeLink).toHaveAttribute("href", "#");

		// Expect the Yanpet link to have an href attribute with a value of #
		expect(yanpetLink).toHaveAttribute("href", "#");

		// Expect the Poly 2 link to have a class attribute with a value of "active"
		expect(polyLink).toHaveClass("active");
	});
});
