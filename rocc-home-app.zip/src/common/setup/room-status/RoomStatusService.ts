/*
 * Created on Tue Jun 29 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { graphqlClient } from "@rocc/rocc-client-services"
import { FETCH_ROOMS_STATUS } from "../../../graphql/queries/queries"

export const fetchRoomsStatus = (roomIds: number[]) => {
    return graphqlClient.subscribe({
        query: FETCH_ROOMS_STATUS,
        variables: { roomIds },
    })
}

interface IRoomStatus {
    resourceId: number
    cameraEvent: string
}

export const getRoomStatusForRoomIdTransformer = (data: any) => {
    const roomsStatus = data?.rocc_camera_status
    const result: IRoomStatus[] = []
    roomsStatus.forEach((roomStatus: any) => {
        const {resourceId, cameraEvent} = roomStatus
        result.push({resourceId, cameraEvent: cameraEvent.toUpperCase()})
    })
    return result
}
