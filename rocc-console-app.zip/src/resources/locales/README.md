# rocc-localise-strings

Repository to centrally manage all the localization strings for ROCC solution

## Guidelines to use rocc-localise-strings repo as github submodule in other repos

* To Add reference to rocc-localise-strings repo as submodule
    * Remove the local folder
    * Commit to local branch
        ```
        git submodule add <repo_url> folder path
        # ex: git submodule add https://github.com/philips-internal/rocc-localise-strings.git client/src/resources/locales
        ```

* Git clone Application repo with all the submodules
   ```
   git clone --recursive <repo_url>
   #ex: git clone --recursive https://github.com/philips-internal/rocc-tech-main-app.git
   ```
   
* Update submodule reference
     ```
     git submodule init
     git submodule update
     ```
     
* To check status of submodule
    ```
    git submodule status
    ```


## How to add new keys to this repo from your repo

* Go to submodule folder path in your project that links to the submodule and goto the locales dir
    ```
    cd client/src/resources/locales
    ```
    
* From the locales dir in your terminal, Checkout master or pull latest changed from master
    ```
    git pull
    ```
    
* Create a child branch
    ```
    git checkout -B Task-12345-updateUsStrings
    ```
    
* Update/add new key strings to english locale file ONLY
    ```
    git add -p
    ```
    
* Commit this changes to rocc-localize-strings
    ```
    git commit -m "updated local strings"
    git push
    ```
    
* Create PR and Merge changes
    * Add screenshot of the UI showing new strings to the PR description.

## How to get latest changes from this repo to your repo

* Go to parent folder(one level above locales)
    ```
    cd ..
    ```
    
* Add locales folder
    ```
    git add -p
    ```
    
* Commit on parent folder 
    ```
    git commit -m "update the references for locales"
    ```
    
* Push changes to remote branch
    ```
    git push
    ```
    
