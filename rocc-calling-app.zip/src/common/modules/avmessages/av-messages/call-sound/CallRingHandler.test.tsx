/*
 * Created on Wed Sep 15 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import { AUDIO } from "../../../../../constants/constants"
import CallRing from "./CallRingHandler"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        audioOutputSource: "source 1",
        callRingStatus: true,
    }),
}))

describe("CallRing component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    it("should render MessageHandler component", () => {
        withHooks(() => {
            useEffect = jest.spyOn(React, "useEffect")
            const mockUseEffect = () => {
              useEffect.mockImplementationOnce(f => f())
            }
            const audio = AUDIO
            React.useState = jest.fn().mockReturnValue([audio, "audio"])
            mockUseEffect()
            mockUseEffect()
            mockUseEffect()
            wrapper = shallow(<CallRing />)
            expect(wrapper).toHaveLength(1)
        })
    })
})
