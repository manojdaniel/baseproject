/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Grid } from "semantic-ui-react"
import styles from "./DotConnectorComponent.scss"
import cx from "classnames"
import { EProtocolTransferSteps, IStore } from "../../../redux/interfaces/types"
import { useSelector } from "react-redux"

const DotConnectorComponent = () => {
    const { currentStep } = useSelector((state: IStore) => ({
        currentStep: state.protocolTransferReducer.currentStep
    }))

    const showConnectordots = () => {
        const dotRow = []
        for (let i = 0; i < 10; i++) {
            dotRow.push(<span className={cx(styles.connectorDot,
                (currentStep === EProtocolTransferSteps.ConnectToSourceScanner || currentStep === EProtocolTransferSteps.ConnectToDestinationScanner ? styles.edit : (currentStep === EProtocolTransferSteps.CompletionStep ? styles.complete : "")))} key={i} />)
        }
        return dotRow
    }
    return <Grid.Row id="dotConnector">{showConnectordots()}</Grid.Row>
}

export default DotConnectorComponent
