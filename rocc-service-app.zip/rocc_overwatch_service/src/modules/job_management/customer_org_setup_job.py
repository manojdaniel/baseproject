"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

from src.constants.config_keys import INFRA_CFG_ORG_APP_NAME, INFRA_CFG_ORG_AUTH_SERVICE_NAME, \
    INFRA_CFG_ORG_OAUTH_CLIENT_ID, INFRA_CFG_ORG_OAUTH_NAME, \
    INFRA_CFG_ORG_OAUTH_PASSWORD, INFRA_CFG_ORG_PROPOSITION_NAME, VAULT_PARENT_APP_NAME, VAULT_PARENT_AUTH_SERVICE_NAME, \
    VAULT_PARENT_PROPOSITION_NAME, VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, \
    VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_HSDP_IAM_URL, VAULT_ROOT_SERVICE_AUTH_ISSUER, \
    VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import USER_UUID

from src.constants.constants import ENTITY_ID, FAILED_AT, JOB_LIST, CURRENT_JOB, ROCC_PROXY_URL, TRANSACTION_ID, INIT, COMPLETED, JOB_NAME, INDEX, STATUS, \
    HSDP_IAM_URL, ID, TRANSACTION_DATA, FAILED
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import get_infra_configs, update_service_job_transaction_status, \
    get_service_job_transactions_details, fetch_tasks_for_job, update_tasks_for_transaction
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.job_management.job_handler import JobHandler
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.device_mdm_services.device_mdm_services import cleanup_device_group, cleanup_device_type, \
    manage_device_proposition_service
from src.wrappers.infrastructure_services.email_templates_services.manage_email_templates_services import create_email_templates_service
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import create_application_service, create_oauth_client_service, \
    create_proposition_service, create_service_identity, update_client_scope_service
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_org_services import create_org_service, delete_org_service
from src.wrappers.infrastructure_services.policy_services.manage_policy_services import create_group_policy_service
from src.wrappers.infrastructure_services.roles_permissions_services.manage_roles_groups import create_roles_and_groups_services, \
    create_service_group_and_roles_for_suborg
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import create_customer_specific_vault_values, get_profile_data, \
    update_customer_map_in_vault_global_path
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.iam_service.rocc_iam_infra_setup import create_allowed_org_rocc
from src.wrappers.platform_services.management_service.manage_redis_services import delete_org_related_redis_values, store_values_in_redis
from src.wrappers.platform_services.rbac_services.rbac_services import setup_roles_for_org_service

LOG = create_logger("CustomerOrgSetupJob")


class CustomerOrgSetupJob(JobHandler):

    def __init__(self):
        self._is_redis_created = False
        self._device_group_id = False
        self._device_type_id = False
        self._success = False

    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            self._user_uuid = self._payload[USER_UUID]
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            self._transaction_id = self._payload[TRANSACTION_ID]
            self.load_vault_configs()
            self._root_service_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                                       issuer=self._profile_configs[
                                                                           VAULT_ROOT_SERVICE_AUTH_ISSUER],
                                                                       private_key=self._profile_configs[VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY])

            self._parent_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                         issuer=self._profile_configs[
                                                                             VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                         private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._client = get_client_connection(
                access_token=self._parent_service_token, org_infra_uuid=self._parent_org_id)
            job_transaction_details = self.fetch_transaction_from_db()
            self._db_customer_id = job_transaction_details[0]["entity_id"]
            self.load_infra_configs(customer_id=self._db_customer_id)
            self._job_id = job_transaction_details[0]["current_job_id"]
            self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
            if len(job_transaction_details) != 0:
                self.fetch_all_tasks()
                self.update_transaction_in_db_wrt_job(
                    status=INIT, task_name=ETasks.CREATE_ORG.value, job_status_update=True, update_record_status=True)
                self.execute_tasks()
                prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=EJobs.CUSTOMER_ORG_SETUP.value, action="E", outcome=0,
                                       user_detail=self._user_uuid,
                                       org_id=self._parent_org_id, token=self._parent_service_token,
                                       **{EJobs.CUSTOMER_ORG_SETUP.value: COMPLETED},
                                       **{TRANSACTION_ID: self._transaction_id})
            else:
                LOG.info(
                    f"{self._payload[CURRENT_JOB]} Job is completed and transaction details are, {self._transaction_id}")

            self.post_message(payload=self._payload)
            LOG.info(f"Finished Job: {EJobs.CUSTOMER_ORG_SETUP.value}")
        except RoccException as ex:
            LOG.error(f"Failed to setup org with RoccException: {ex}")
            self.post_message(payload=self._payload, error_message=str(
                "" if ex.payload is None else ex.payload))
            raise RoccException(ex.status_code, str(ex.payload)) from ex
        except Exception as ex:
            LOG.error(f"Failed to setup org with general error: {ex}")
            self.post_message(payload=self._payload,
                              error_message=repr(ex.args))
            raise RoccException(ex.status_code, str(ex.payload)) from ex

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(
            job_id=self._job_id, client=self._client)
        LOG.info(
            f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def load_infra_configs(self, customer_id):
        """Fetch corresponding infra configs from infrastructure_configurations table"""
        response = get_infra_configs(self._client, customer_id)
        if response and len(response) > 0:
            self._infra_configs = response[0]
        else:
            LOG.error(
                f"Could not retrieve infrastructure configs for customer_id: {customer_id} with transaction: {self._payload[TRANSACTION_ID]}")
            raise RoccException(status_code=500,
                                payload=f"Could not retrieve infrastructure configs for customer_id: {customer_id} with transaction: {self._payload[TRANSACTION_ID]}")

    def load_vault_configs(self):
        """Fetch vault data from corresponding vault profile"""
        try:
            self._profile_configs = get_profile_data()
        except Exception as ex:
            LOG.error(
                f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}, with error: {ex}")
            raise RoccException(
                status_code=500, payload=f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}") from ex

    def fetch_transaction_from_db(self):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(
            self._transaction_id, client=self._client)
        LOG.info(
            f"Fetch job details for transaction_id, {self._transaction_id} is successful")
        return transaction_details

    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        if update_record_status:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self._client)
            LOG.info(
                f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._payload[TRANSACTION_ID],
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[
            ID],
            transaction_data_object=self._transaction_data,
            status=status,
            client=self._client,
            job_status_update=job_status_update,
            reason=error_reason)

    def post_message(self, payload, error_message=""):
        """
        1. Post message to RabbitMQ with Payload
        """
        try:
            if self._success:
                LOG.info(
                    f"Publishing a rabbitMQ message after completing current Job: {self._payload[CURRENT_JOB]}")
                current_record = list(filter(
                    lambda item: item[JOB_NAME] == EJobs.CUSTOMER_ORG_SETUP.value, payload[JOB_LIST]))[0]
                for job in payload[JOB_LIST]:
                    if job[JOB_NAME] == EJobs.CUSTOMER_ORG_SETUP.value:
                        job[STATUS] = COMPLETED
                    if job[INDEX] == current_record[INDEX] + 1:
                        payload[CURRENT_JOB] = job[JOB_NAME]
                        job[STATUS] = INIT
            else:
                self.update_transaction_in_db_wrt_job(
                    FAILED, ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, job_status_update=True, error_reason=error_message)
                payload[CURRENT_JOB] = EJobs.FAILED.value
                payload[FAILED_AT] = EJobs.CUSTOMER_ORG_SETUP.value
                LOG.warn(
                    f"Publishing FAILED rabbitMQ message, since the current job: {EJobs.CUSTOMER_ORG_SETUP.value} is failed")
            publish_message(payload=payload)
        except Exception as ex:
            LOG.error(f"Failed to post message with error: {ex}")

    def roll_back_on_failure(self):
        """ Roll-back, if there is a failed task """
        LOG.warn(
            f"Initiating rollback for customer: {self._payload[ENTITY_ID]}")
        if self._org_id:
            self.rb_task_clean_up_device_mdm()
            self.rb_task_clean_up_redis_data()
            self.rb_task_clean_up_vault_data()
            self.rb_task_delete_org()

    def execute_tasks(self):
        """
        Tasks:
        - CREATE_ORG
        - CREATE_ROLES_AND_GROUPS
        - CREATE_PROPOSITION
        - CREATE_APPLICATION
        - CREATE_SERVICE
        - ENABLE_SERVICE_TOOLS_FOR_CUSTOMER
        - CREATE_OAUTH_CLIENT
        - UPDATE_CLIENT_SCOPE
        - CREATE_EMAIL_TEMPLATES
        - MANAGE_DEVICE_PROPISITION
        - CREATE_GROUP_POLICY
        - MANAGE_VAULT
        - MANAGE_REDIS
        - CREATE_ALLOWED_ORG_ROCC
        - CREATE_ORG_COMMUNICATION_PROFILE
        - ROLES_AND_PERMISSION_FOR_CUSTOMERS
        """
        LOG.info(
            f"Transaction: {self._transaction_id} - Executing tasks under job: {EJobs.CUSTOMER_ORG_SETUP.value}")
        try:
            self._org_id = self.task_create_org()
            group_id = self.task_create_roles_and_groups()
            proposition_id = self.task_create_proposition()
            application_id = self.task_create_application(proposition_id)
            service_identity_response = self.task_create_service(
                application_id)
            self._sub_org_token = self.task_setup_service_tools_in_created_org(
                service_identity_response)
            oauth_client_id = self.task_create_oauth_client(application_id)
            self.task_update_client_scope(oauth_client_id)
            self.task_create_email_templates()
            device_bootstrap_client_id, device_bootstrap_client_secret = self.task_manage_device_proposition()
            self.task_create_group_policy(group_id)
            self.task_update_customer_specific_vault_values(
                device_bootstrap_client_id, device_bootstrap_client_secret, service_identity_response)
            self.task_update_values_in_redis()
            self.task_update_allowed_org()
            self.task_setup_roles_for_org()
            LOG.info(
                f"Transaction: {self._transaction_id} - All tasks under job: {EJobs.CUSTOMER_ORG_SETUP.value} is completed")
            self.update_transaction_in_db_wrt_job(
                status=COMPLETED, task_name=ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, job_status_update=True)
            self._success = True

        except RoccException as ex:
            LOG.error(
                f"Job: {EJobs.CUSTOMER_ORG_SETUP.value} failed during execution with ROCC exception, hence initiating roll-back, error: {ex}")
            self.roll_back_on_failure()
        except Exception as ex:
            LOG.error(
                f"Job: {EJobs.CUSTOMER_ORG_SETUP.value} failed during execution with general exception, hence initiating roll-back, error: {ex}")
            self.roll_back_on_failure()

    def task_setup_roles_for_org(self):
        response, error_reasn = setup_roles_for_org_service(url=os.environ[ROCC_PROXY_URL],
                                                            token=self._sub_org_token,
                                                            org_id=self._org_id,
                                                            client=self._client,
                                                            user_uuid=self._user_uuid,
                                                            infra_configs=self._infra_configs["infra_configs"],)
        prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, action="C", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id, token=self._parent_service_token,
                               **{ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value: COMPLETED},
                               **{TRANSACTION_ID: self._transaction_id})
        if not response:
            LOG.error(
                f"Task: {ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value} failed for customer: {self._payload[ENTITY_ID]}")
            prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id, token=self._parent_service_token,
                                   **{ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value: FAILED},
                                   **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to setup roles for org"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value)

    def task_update_allowed_org(self):
        response, error_reasn = create_allowed_org_rocc(url=os.environ[ROCC_PROXY_URL],
                                                        token=self._root_service_token,
                                                        org_id=self._org_id)
        if not response:
            LOG.error(
                f"Task: {ETasks.CREATE_ALLOWED_ORG_ROCC.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_ALLOWED_ORG_ROCC.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to update allowed_org"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_ALLOWED_ORG_ROCC.value)

    def task_update_values_in_redis(self):
        error_reasn = ""
        redis_global_response, redis_global_error_reasn = store_values_in_redis(url=os.environ[ROCC_PROXY_URL],
                                                                                token=self._root_service_token)
        redis_customer_response, redis_customer_error_reasn = store_values_in_redis(url=os.environ[ROCC_PROXY_URL],
                                                                                    token=self._root_service_token,
                                                                                    customer_name=self._payload[ENTITY_ID],
                                                                                    org_id=self._org_id)
        error_reasn = redis_global_error_reasn if redis_global_error_reasn else redis_customer_error_reasn
        prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.MANAGE_REDIS.value, action="C", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id, token=self._parent_service_token,
                               **{ETasks.MANAGE_REDIS.value: COMPLETED}, **{"Customer Org Id": self._org_id},
                               **{"Update Customer org redis values": COMPLETED}, **{TRANSACTION_ID: self._transaction_id})
        if not (redis_global_response and redis_customer_response):
            LOG.error(
                f"Task: {ETasks.MANAGE_REDIS.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.MANAGE_REDIS.value, error_reason=error_reasn)
            prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.MANAGE_REDIS.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id, token=self._parent_service_token,
                                   **{ETasks.MANAGE_REDIS.value: FAILED}, **{"Customer Org Id": self._org_id},
                                   **{"Update Customer org redis values": FAILED}, **{TRANSACTION_ID: self._transaction_id})
            raise RoccException(status_code=500, payload=str(
                "Failed to create redis values"))
        self._is_redis_created = True
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.MANAGE_REDIS.value)

    def task_update_customer_specific_vault_values(self, device_bootstrap_client_id, device_bootstrap_client_secret, service_identity_response):
        vault_response, error_reasn = create_customer_specific_vault_values(service_response=service_identity_response,
                                                                            device_bootstrap_client_id=device_bootstrap_client_id,
                                                                            device_bootstrap_client_secret=device_bootstrap_client_secret,
                                                                            org_id=self._org_id,
                                                                            customer_name=self._payload[ENTITY_ID],
                                                                            infra_configs=self._infra_configs["infra_configs"])
        vault_map_response, vault_map_error_reasn = update_customer_map_in_vault_global_path(customer_name=self._payload[ENTITY_ID],
                                                                                             org_id=self._org_id)
        if not error_reasn:
            error_reasn = vault_map_error_reasn
        prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.MANAGE_VAULT.value, action="C", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id, token=self._parent_service_token,
                               **{ETasks.MANAGE_VAULT.value: COMPLETED}, **{"Customer Org Id": self._org_id},
                               **{"Update Customer org vault values": COMPLETED}, **{TRANSACTION_ID: self._transaction_id})
        if not (vault_response and vault_map_response):
            LOG.error(
                f"Task: {ETasks.MANAGE_VAULT.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.MANAGE_VAULT.value, error_reason=error_reasn)
            prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.MANAGE_VAULT.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id, token=self._parent_service_token,
                                   **{ETasks.MANAGE_VAULT.value: FAILED}, **{"Customer Org Id": self._org_id},
                                   **{"Update Customer org vault values": FAILED}, **{TRANSACTION_ID: self._transaction_id})
            raise RoccException(status_code=500, payload=str(
                "Failed to create vault values"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.MANAGE_VAULT.value)

    def task_create_group_policy(self, group_id):
        group_policy_response, error_reasn = create_group_policy_service(token=self._root_service_token,
                                                                         org_id=self._org_id,
                                                                         group_id=group_id,
                                                                         profile_configs=self._profile_configs)
        if not group_policy_response:
            LOG.error(
                f"Task: {ETasks.CREATE_GROUP_POLICY.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_GROUP_POLICY.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create group_policy"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_GROUP_POLICY.value)

    def task_manage_device_proposition(self):
        response = manage_device_proposition_service(root_org_token=self._root_service_token,
                                                     sub_org_token=self._sub_org_token,
                                                     org_id=self._org_id,
                                                     infra_configs=self._infra_configs["infra_configs"],
                                                     client=self._client)
        if not response["status"]:
            LOG.error(
                f"Task: {ETasks.MANAGE_DEVICE_PROPISITION.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.MANAGE_DEVICE_PROPISITION.value, error_reason=response["error_reasn"])
            raise RoccException(status_code=500, payload=str(
                "Failed to create device proposition"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.MANAGE_DEVICE_PROPISITION.value)
        self._device_type_id = response["device_type_id"]
        self._device_group_id = response["device_group_id"]
        return response["device_bootstrap_client_id"], response["device_bootstrap_client_secret"]

    def task_update_client_scope(self, oauth_client_id):
        update_client_scope_response, error_reasn = update_client_scope_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                                                token=self._root_service_token,
                                                                                oauth_client_id=oauth_client_id)
        if not update_client_scope_response:
            LOG.error(
                f"Task: {ETasks.UPDATE_CLIENT_SCOPE.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.UPDATE_CLIENT_SCOPE.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to update client_scope"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.UPDATE_CLIENT_SCOPE.value)

    def task_create_email_templates(self):
        response, error_reasn = create_email_templates_service(token=self._root_service_token,
                                                               org_id=self._org_id,
                                                               infra_configs=self._infra_configs["infra_configs"])
        if not response:
            LOG.error(
                f"Task: {ETasks.CREATE_EMAIL_TEMPLATES.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_EMAIL_TEMPLATES.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create email templates"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_EMAIL_TEMPLATES.value)

    def task_create_oauth_client(self, application_id):
        oauth_client_id, error_reasn = create_oauth_client_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                                   token=self._root_service_token,
                                                                   application_id=application_id,
                                                                   name=self._infra_configs["infra_configs"][
                                                                       INFRA_CFG_ORG_OAUTH_NAME],
                                                                   description=self._infra_configs[
                                                                       "infra_configs"][INFRA_CFG_ORG_OAUTH_NAME],
                                                                   client_id=self._infra_configs["infra_configs"][
                                                                       INFRA_CFG_ORG_OAUTH_CLIENT_ID],
                                                                   password=self._infra_configs["infra_configs"][INFRA_CFG_ORG_OAUTH_PASSWORD],
                                                                   org_name=self._payload[ENTITY_ID])
        if not oauth_client_id:
            LOG.error(
                f"Task: {ETasks.CREATE_OAUTH_CLIENT.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_OAUTH_CLIENT.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create oauth_client"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_OAUTH_CLIENT.value)
        return oauth_client_id

    def task_create_service(self, application_id):
        service_identity_response, error_reasn = create_service_identity(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                                         token=self._root_service_token,
                                                                         application_id=application_id,
                                                                         name=self._infra_configs["infra_configs"][
                                                                             INFRA_CFG_ORG_AUTH_SERVICE_NAME],
                                                                         description=self._profile_configs[VAULT_PARENT_AUTH_SERVICE_NAME])
        if not service_identity_response:
            LOG.error(
                f"Task: {ETasks.CREATE_SERVICE.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_SERVICE.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create service_identity"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_SERVICE.value)
        return service_identity_response

    def task_create_application(self, proposition_id):
        application_id, error_resn = create_application_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                                token=self._root_service_token,
                                                                proposition_id=proposition_id,
                                                                name=self._infra_configs["infra_configs"][INFRA_CFG_ORG_APP_NAME],
                                                                description=self._profile_configs[VAULT_PARENT_APP_NAME])
        if not application_id:
            LOG.error(
                f"Task: {ETasks.CREATE_APPLICATION.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_APPLICATION.value, error_reason=error_resn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create application"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_APPLICATION.value)
        return application_id

    def task_create_proposition(self):
        proposition_id, error_reasn = create_proposition_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                                 token=self._root_service_token,
                                                                 org_id=self._org_id,
                                                                 name=self._infra_configs["infra_configs"][
                                                                     INFRA_CFG_ORG_PROPOSITION_NAME],
                                                                 description=self._profile_configs[VAULT_PARENT_PROPOSITION_NAME])
        if not proposition_id:
            LOG.error(
                f"Task: {ETasks.CREATE_PROPOSITION.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_PROPOSITION.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to create proposition"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_PROPOSITION.value)
        return proposition_id

    def task_create_roles_and_groups(self):
        group_id, role_id, error_reasn = create_roles_and_groups_services(token=self._root_service_token,
                                                                          org_id=self._org_id,
                                                                          infra_configs=self._infra_configs[
                                                                              "infra_configs"],
                                                                          profile_configs=self._profile_configs)
        prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.CREATE_ROLES_AND_GROUPS.value, action="C", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id, token=self._parent_service_token,
                               **{ETasks.CREATE_ROLES_AND_GROUPS.value: COMPLETED}, **{"Group ID": group_id}, **{"Role ID": role_id},
                               **{TRANSACTION_ID: self._transaction_id})
        if not group_id:
            LOG.error(
                f"Task: {ETasks.CREATE_ROLES_AND_GROUPS.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_ROLES_AND_GROUPS.value, error_reason=error_reasn)
            prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.CREATE_ROLES_AND_GROUPS.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id, token=self._parent_service_token,
                                   **{ETasks.CREATE_ROLES_AND_GROUPS.value: FAILED},
                                   **{TRANSACTION_ID: self._transaction_id})
            raise RoccException(status_code=500, payload=str(
                "Failed to create roles_and_groups"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_ROLES_AND_GROUPS.value)
        return group_id

    def task_create_org(self):
        org_id, error_reasn = create_org_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                                 parent_org_id=self._profile_configs["PARENT_ORG_ID"],
                                                 token=self._root_service_token,
                                                 customer_name=self._payload[ENTITY_ID])
        prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.CREATE_ORG.value, action="C", outcome=0,
                               user_detail=self._user_uuid,
                               org_id=self._parent_org_id, token=self._parent_service_token,
                               **{ETasks.CREATE_ORG.value: COMPLETED}, **{"Customer Org Id": org_id},
                               **{TRANSACTION_ID: self._transaction_id})
        if not org_id:
            LOG.error(
                f"Task: {ETasks.CREATE_ORG.value} failed for customer: {self._payload[ENTITY_ID]}")
            prepare_and_post_audit(event_type="Customer Org Setup", event_subtype=ETasks.CREATE_ORG.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id, token=self._parent_service_token,
                                   **{ETasks.CREATE_ORG.value: FAILED}, **{"Parent Org Id": self._profile_configs["PARENT_ORG_ID"]},
                                   **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.CREATE_ORG.value, error_reason=error_reasn)
            raise RoccException(
                status_code=500, payload=str("Failed to create org"))
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CREATE_ORG.value)
        return org_id

    def task_setup_service_tools_in_created_org(self, service_identity_response):
        group_id, group_error_reasn = create_service_group_and_roles_for_suborg(token=self._root_service_token,
                                                                                org_id=self._org_id,
                                                                                service_id=service_identity_response["id"],
                                                                                profile_configs=self._profile_configs)
        if not group_id:
            LOG.error(
                f"Task: {ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value, error_reason=group_error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to enable service tools for new Org"))

        try:
            LOG.info("Creating sub org service token")
            sub_org_pkey = service_identity_response["privateKey"].replace(
                "-----BEGIN RSA PRIVATE KEY-----", "").replace("-----END RSA PRIVATE KEY-----", "")
            sub_org_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                            issuer=service_identity_response["serviceId"],
                                                            private_key=sub_org_pkey)
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value)
            return sub_org_token
        except Exception as ex:
            error_reasn = f"Creating sub org service token failed with: Exception {repr(ex.args)}"
            LOG.error(
                f"Task: {ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value} failed for customer: {self._payload[ENTITY_ID]}")
            self.update_transaction_in_db_wrt_job(
                FAILED, ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value, error_reason=error_reasn)
            raise RoccException(status_code=500, payload=str(
                "Failed to enable service tools for new Org")) from ex

    def rb_task_delete_org(self, org_id=None):
        if org_id is None:
            org_id = self._org_id
        LOG.warn(f"Initiating deletion of org: {org_id}")
        response = delete_org_service(idm_url=self._profile_configs["HSDP_IDM_URL"],
                                      org_id=org_id,
                                      token=self._root_service_token)
        if response:
            LOG.info(f"Deleted the org: {org_id}")
        else:
            LOG.error(f"Org deletion of org: {org_id} failed!")

    def rb_task_clean_up_vault_data(self):
        # TODO: clean-up vault values for org
        pass

    def rb_task_clean_up_redis_data(self):
        if self._is_redis_created:
            delete_org_related_redis_values(url=os.environ[ROCC_PROXY_URL],
                                            token=self._sub_org_token,
                                            customer_name=self._payload[ENTITY_ID],
                                            org_id=self._org_id)

    def rb_task_clean_up_device_mdm(self):
        if self._device_type_id:
            cleanup_device_type(token=self._sub_org_token,
                                type_id=self._device_type_id,
                                profile_configs=self._profile_configs)

        if self._device_group_id:
            cleanup_device_group(token=self._sub_org_token,
                                 group_id=self._device_group_id,
                                 profile_configs=self._profile_configs)
