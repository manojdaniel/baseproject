export const getPMComplianceDetail =[
    {
      "assetTag": "2Y-3003A",
      "assetSapNumber": "310060752",
      "plannedDate": "20231019",
      "completionDate": "00000000",
      "workOrder": "009305416142",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3013A",
      "assetSapNumber": "310060764",
      "plannedDate": "20221106",
      "completionDate": "00000000",
      "workOrder": "009304871329",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3013B",
      "assetSapNumber": "310060771",
      "plannedDate": "20230822",
      "completionDate": "00000000",
      "workOrder": "009305372940",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3602",
      "assetSapNumber": "310061172",
      "plannedDate": "20230920",
      "completionDate": "00000000",
      "workOrder": "009305373361",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3601",
      "assetSapNumber": "310061164",
      "plannedDate": "20230613",
      "completionDate": "00000000",
      "workOrder": "009305309570",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3608",
      "assetSapNumber": "310061211",
      "plannedDate": "20230723",
      "completionDate": "00000000",
      "workOrder": "009305372948",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3609",
      "assetSapNumber": "310061217",
      "plannedDate": "20230723",
      "completionDate": "00000000",
      "workOrder": "009305373026",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2K-4103",
      "assetSapNumber": "310059948",
      "plannedDate": "20230705",
      "completionDate": "00000000",
      "workOrder": "009305331509",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3003A",
      "assetSapNumber": "310060752",
      "plannedDate": "20221208",
      "completionDate": "00000000",
      "workOrder": "009304903387",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3003A",
      "assetSapNumber": "310060752",
      "plannedDate": "20231207",
      "completionDate": "00000000",
      "workOrder": "009305416015",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3602",
      "assetSapNumber": "310061172",
      "plannedDate": "20231125",
      "completionDate": "00000000",
      "workOrder": "009304764095",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3602",
      "assetSapNumber": "310061172",
      "plannedDate": "20230809",
      "completionDate": "00000000",
      "workOrder": "009305372957",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3602",
      "assetSapNumber": "310061172",
      "plannedDate": "20230410",
      "completionDate": "00000000",
      "workOrder": "009304406391",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3603",
      "assetSapNumber": "310061180",
      "plannedDate": "20230410",
      "completionDate": "00000000",
      "workOrder": "009304406392",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3601",
      "assetSapNumber": "310061164",
      "plannedDate": "20201225",
      "completionDate": "00000000",
      "workOrder": "009302843705",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3601",
      "assetSapNumber": "310061164",
      "plannedDate": "20230725",
      "completionDate": "00000000",
      "workOrder": "009305331600",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3601",
      "assetSapNumber": "310061164",
      "plannedDate": "20230802",
      "completionDate": "00000000",
      "workOrder": "009305331587",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3603",
      "assetSapNumber": "310061180",
      "plannedDate": "20221027",
      "completionDate": "00000000",
      "workOrder": "009304929809",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3603",
      "assetSapNumber": "310061180",
      "plannedDate": "20231026",
      "completionDate": "00000000",
      "workOrder": "009305434555",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3604",
      "assetSapNumber": "310061188",
      "plannedDate": "20230517",
      "completionDate": "00000000",
      "workOrder": "009305309564",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3605",
      "assetSapNumber": "310061193",
      "plannedDate": "20230503",
      "completionDate": "00000000",
      "workOrder": "009305309569",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3606",
      "assetSapNumber": "310061199",
      "plannedDate": "20230822",
      "completionDate": "00000000",
      "workOrder": "009305373024",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3607",
      "assetSapNumber": "310061205",
      "plannedDate": "20230316",
      "completionDate": "00000000",
      "workOrder": "009305285159",
      "compliance": "NOT COMPLIED"
    },
    {
      "assetTag": "2Y-3602",
      "assetSapNumber": "310061172",
      "plannedDate": "20230802",
      "completionDate": "00000000",
      "workOrder": "009305331588",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3603",
      "assetSapNumber": "310061180",
      "plannedDate": "20230802",
      "completionDate": "00000000",
      "workOrder": "009305331589",
      "compliance": "COMPLIED"
    },
    {
      "assetTag": "2Y-3604",
      "assetSapNumber": "310061188",
      "plannedDate": "20230802",
      "completionDate": "00000000",
      "workOrder": "009305331590",
      "compliance": "COMPLIED"
    }
  ]