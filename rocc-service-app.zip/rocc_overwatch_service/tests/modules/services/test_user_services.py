
import unittest
from unittest.mock import patch
from tests.mocks.random import random
from src.services.user_services import update_user_details_to_map_kvm_role



class UserManagementServiceTestCase(unittest.TestCase):

    def test_empty_user_db_id(self):
        self.assertRaises(TypeError, update_user_details_to_map_kvm_role, "")

    @patch("package.file.random")
    def test_empty_kvm_user_name(self):

        self.assertRaises(TypeError, update_user_details_to_map_kvm_role, random.randint, "")

    def test_invalid_user_db_id(self):
        self.assertRaises((KeyError, AttributeError), update_user_details_to_map_kvm_role, "")

    @patch("package.file.random")
    def test_invalid_summary_state(self):
        self.assertRaises((KeyError, AttributeError), update_user_details_to_map_kvm_role, random.randint, "")
