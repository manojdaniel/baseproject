http_status_string_registry = {
    400: "400 Bad Request",
    404: "404 Not Found",
    500: "500 Internal Server Error",
    403: "403 Insufficient Permission",
    206: "206 Partially Completed",
    409: "409 Conflict Request",
    401: "401 Invalid Authentication"
}
