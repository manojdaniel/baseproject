// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import pucurve from "../../../assets/images/img_PFCurve_RUL.svg";
import Heatmap from "../../../assets/images/image_Heatmap.svg";
import ImgGraphYellow from "../../../assets/images/img_graph_yellow_circle.svg";
import ImgGraphGreen from "../../../assets/images/img_graph_green_circle.svg";
import ImgGraphRed from "../../../assets/images/img_graph_red_circle.svg";
import asset_model_accordian_minus from "../../../assets/images/asset_model_accordian_minus.svg";
import asset_model_accordian_plus from "../../../assets/images/asset_model_accordian_plus.svg";
import pf_left_arrow from "../../../assets/images/pf-left-arrow.svg";
import pf_right_arrow from "../../../assets/images/pf-right-arrow.svg";
import Dropdown from "../../Dropdown/Dropdown";
import { useNavigate } from "react-router-dom"

interface Props {
    loadinggetAnomalyModelbyAssetId: any;
    AnomalyModelbyAssetId: any[];
    setSensorGroupId: any;
    selectedAssetIdGlobal: any;
    assetData: any;
    popupFuncClose: any;
}

const LiveModel = ({ AnomalyModelbyAssetId, setSensorGroupId, selectedAssetIdGlobal, assetData, popupFuncClose, loadinggetAnomalyModelbyAssetId }: Props) => {
    const [showPopup, setShowPopup] = useState<any>(false);
    const [showPopupData, setShowPopupData] = useState<any>();
    const [showToggle, setToggle] = useState<any>(false);
    const [selectedsensorGroupId, setSelectedsensorGroupId] = useState<any>("");
    const [selectedModel, setSelectedModel] = useState<any>();

    const navigate = useNavigate();

    const openAssetPopup = (data: any) => {
        setShowPopup(true);
        setSelectedModel(data);
        setShowPopupData(data);
    }

    const closeAssetPopup = (data: any) => {
        setShowPopup(data);
        popupFuncClose(data);
    }

    const openFailureDictionPopupDropdown = (data: any) => {
        setShowPopup(true);
        setSelectedModel(data);
        setShowPopupData(data);
    }

    const getFunctionAnomalyid = (data: any) => {
        setSelectedsensorGroupId(data);
        showToggle === false ? setSensorGroupId(data) : setSensorGroupId("");
    }

    useEffect(() => {
        if (assetData !== null && assetData !== undefined && Object.keys(assetData).length > 0) {
            setShowPopup(true);
            const newData = {
                value: assetData.modelId,
                rul: assetData.rul,
                label: assetData.modelName
            }
            setShowPopupData(newData);
            setSelectedModel(newData);
        }
    }, [assetData]);

    useEffect(() => {
        setToggle(false);
    }, [selectedAssetIdGlobal]);

    const getSelectedclassName = (id: any) => showToggle === true ? selectedsensorGroupId === id ? "getactive" : "setactive" : "";
    
    useEffect(() => {
        const accordionTitles = document.querySelectorAll(".accordionTitle");
        accordionTitles.forEach((accordionTitle) => {
            accordionTitle.addEventListener("click", () => {
                if (accordionTitle.classList.contains("is-open")) {
                    accordionTitle.classList.remove("is-open");
                } else {
                    const accordionTitlesWithIsOpen = document.querySelectorAll(".is-open");
                    accordionTitlesWithIsOpen.forEach((accordionTitleWithIsOpen) => {
                        accordionTitleWithIsOpen.classList.remove("is-open");
                    });
                    accordionTitle.classList.add("is-open");
                }
            });
        });
    }, []);

    //==================Globalfailureprediction filter data ======
    let Globalfailureprediction = []
    AnomalyModelbyAssetId.forEach((device: any, index: any) => {
        Globalfailureprediction[index] = { ...device }
    })


    let getfailureprediction = [];
    for (var i = 0; i < Globalfailureprediction.length; i++) {
        if (Globalfailureprediction[i].rul !== -999) {
            let localdata = {
                label: Globalfailureprediction[i].modelName, value: Globalfailureprediction[i].modelId, rul: Globalfailureprediction[i].rul, confidenceFactor: Globalfailureprediction[i].confidenceFactor

            };
            getfailureprediction.push(localdata);

        };
    }
    //======================END===============================================================


    const getTopPosition = (data: any) => {
        if (data >= 0 && data <= 30) {
            return 70 + (data * 5);
        } else if (data === 31 || data === 32 || data === 31) {
            return 60;
        } else if (data === 34 || data === 35 || data === 36) {
            return 50;
        } else if (data === 37 || data === 38 || data === 39) {
            return 40;
        } else if (data === 40 || data === 41 || data === 42) {
            return 30;
        } else if (data === 43 || data === 44 || data === 45) {
            return 25;
        } else if (data === 46 || data === 47 || data === 48) {
            return 20;
        } else if (data === 49 || data === 50 || data === 51 || data === 52 || data === 53 || data === 54 || data === 55) {
            return 10;
        } else if (data === 56 || data === 60 || data === 61 || data === 62 || data === 63 || data === 64 || data === 65 || data === 66) {
            return 0;
        } else {
            return 0;
        }
    }

    const navigationFunc = async (key: any, data: any, data2: any, data3: any) => {
        // await delay(200);
        navigate(`/${key}`, { state: { data: data, data2: data2, data3: data3 } });
    }

    return (
        <div>
            <div className="right-title">LIVE MODELS</div>
            <div id="new-filter">
                <div className="nf-left">
                    <div className="asset-name">{selectedAssetIdGlobal}</div>
                </div>
            </div>
            <div className="right-asset-name"></div>
            <div className="accordian-title accordionTitle">Anomaly Model <span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>

            <div className="accordian-body">
                <div className="asset-model-health-index">
                    <div className="amhi-row-title">
                        <div>Model Name</div>
                        <div>Health Index %</div>
                    </div>
                    {AnomalyModelbyAssetId.map((item: any) => (
                        <>

                            <div id={item.sensorGroupId} className={`amhi-row  ${getSelectedclassName(item.sensorGroupId)} hovermeyaar-ahmi`} onClick={() => { getFunctionAnomalyid(item.sensorGroupId); setToggle(!showToggle) }}>

                                {/* tooltip Anomaly model */}
                                <div id="AnomalymodelToolip" className="asset-ahmi-tooltip" style={{ right: "25%" , top: "auto", width: "40%", textAlign: "left"}}>
                                    <div className="asset-tooltip-text">
                                        <div>
                                            <div>
                                                {/* <div>{item.sensorGroup}</div> */}
                                                <button id="AlertList" class="toolbtt" type="button" onClick={()=>navigationFunc('assets/alertList', item.assetId, item.modelId, item.modelName)}>Go to Alert List</button>
                                                <br />
                                                <button id="PlotList" class="toolbtt" type="button" onClick={()=>navigationFunc('assets/plots', item.assetId, item.sensorGroupId, item.modelName)}>Go to Plot</button>
                                                <br />
                                                {item.rul !== -999 ? 
                                                 <button id="FailurePredicationButton" class="toolbtt" type="button" onClick={() => openAssetPopup({ value: item.modelId, rul: item.rul, label: item.modelName, confidenceFactor: item.confidenceFactor})}>Go to Failure Prediction</button>
                                                 :
                                                 ""
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="amtname">{item.sensorGroup}</div>
                                {item.healthIndex === null ?
                                    <div className="amtslider">
                                        <span style={{ marginLeft: "45%" }}>{item.status}</span>
                                    </div> :
                                    <div className="amtslider"><span className={item.healthIndexTrend === true ? "uparrow greeny" : "downarrow redy"}></span> <span className="amhi-slider">
                                        {item.healthIndex > 30 ?
                                            <i className="abefore" style={{ left: `calc(${item.healthIndex}% - 45px)` }}>{item.healthIndex}%</i>
                                            :
                                            <i className="aafter" style={{ left: `${item.healthIndex}%` }}>{item.healthIndex}%</i>
                                        }
                                    </span></div>
                                }

                            </div>
                        </>
                    ))}
                </div>
            </div>
            <div className="accordian-title accordionTitle">Failure Prediction <span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>

            <div className="accordian-body">
                <div className="asset-model-failure-prediction">
                    <div className="amfp-row-title">
                        <div>Model Name</div>
                        <div>RUL</div>
                        <div>Confidence Factor</div>
                    </div>
                    {getfailureprediction.map((item: any) => (
                        <>
                            <div className="amfp-row" onClick={() => openAssetPopup(item)}>
                                <div>{item.label}</div>
                                <div>{item.rul}</div>
                                <div>{item.confidenceFactor}</div>
                            </div>
                        </>
                    ))}
                </div>

            </div>
            {showPopup === true && showPopupData !== null ?
                <div id="asset-popup">
                    <div id="ap-content">
                        <span className="ap-closePopup" onClick={() => closeAssetPopup(false)}>x</span>
                        <div className="ap-filter">
                            <div className="ap-title">P-F-CURVE</div>
                            <div id="ap-dropdown" style={{ display: "flex" }}>
                                {/* <select
                                        onChange={(e) => openFailureDictionPopupDropdown(e.target.value)}
                                    >
                                        <option value={showPopupData.modelId}>{showPopupData.modelName}</option>

                                        {getfailureprediction.map((item: any) => (
                                            <option value={item.modelId}>{item.modelName}</option>
                                        ))}
                                    </select> */}

                                <label className="cus-label">Model Name</label>
                                <Dropdown
                                    name={"Model Name"}
                                    options={getfailureprediction}
                                    handleChange={openFailureDictionPopupDropdown}
                                    defaultValue={""}
                                    value={selectedModel}
                                    loading={loadinggetAnomalyModelbyAssetId}
                                />

                            </div>
                        </div>
                        <div className="ap-asset-name">{showPopupData.label}</div>
                        <div id="ap-heatmap">
                            <span className="ap-heatmap-label"><img src={pucurve} /></span>
                            <span className="ap-heatmap-img"><img src={Heatmap} className="ahmi" />

                                <span className="position" style={{ top: `${getTopPosition(showPopupData.rul * 10)}px`, right: `${showPopupData.rul * 10}%` }}><img src={ImgGraphYellow} /></span>
                                <span className="max-position"><img src={ImgGraphGreen} /></span>
                                <span className="min-position"><img src={ImgGraphRed} /></span>
                                <span className="line-horizontal" style={{ width: `${(showPopupData.rul * 10) - 5}%` }}>
                                    <span className="line-inner">
                                        <i className="leftpfarrw"><img src={pf_left_arrow} /></i>
                                        <i className="rightpfarrw"><img src={pf_right_arrow} /></i>
                                        <i className="valuearrw">{showPopupData.rul}</i>
                                    </span>
                                </span>
                            </span>
                        </div>

                    </div>
                </div> : ""
            }
        </div>

    );
};

export default LiveModel;