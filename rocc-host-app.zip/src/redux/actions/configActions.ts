/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import { Dispatch } from "redux"
import { IConfig, IConfigsDataType, IUrls } from "@rocc/rocc-client-services"
import { SET_LOCALE, UPDATE_CONFIGS, UPDATE_PRESIGNED_URLS, UPDATE_URLS } from "./types"
import { IPresignedUrls } from "@rocc/rocc-client-services"

export const setUrls = (urls: IUrls, isProxy: string = "false") => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_URLS, urls, isProxy: isProxy === "true" })
}

export const setConfigs = (configs: IConfig) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_CONFIGS, configs })
}

export const updateLocale = (locale: IConfigsDataType) => (dispatch: Dispatch) => {
    dispatch({ type: SET_LOCALE, configData: locale })
}

export const updatePresignedUrls = (preSignedUrls: IPresignedUrls) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_PRESIGNED_URLS, preSignedUrls })
}
