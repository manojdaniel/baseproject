import React, { useRef, useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
	getPlotDeviationData,
	getPlotSensorData,
	getAssetDropdownList,
	getModelDropdownList,
	getSensorDropdownList,
	getModelSensorDropdownList,
	getPlotDeviationModel,
	getGlobalSelecetedAsset,
} from "../../../redux/reducers/CommonReducer";
import "./PlotScreen.scss";
import SensorChart from "charts/SensorChart";
import SensorNames from "components/SensorNames";
import DeviationChart from "charts/DeviationChart";
import DeviationNames from "components/DeviationNames";
import Dropdown from "components/Dropdown";
import moment from "moment";
import NoData from "components/NoData";
import DropdownMultiselect from "components/DropdownMultiselect";
import {
	getSensorIdList,
	getSensorTodateAdded,
	getSensorTodaySubtractedDate,
	getDateUtcFormat,
	getTimeZone,
	getDeviationTransformer,
} from "../../../utility/transformer/PlotScreenTransformer";
import axios from "axios";
import Loader from "components/Loader";
import { Api } from "../../../utility/api";
import { encryptRSAData } from "../../../utility/rsa";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const colorList = [
	"#E35205",
	"#3BB44A",
	"#929292",
	"#4E79A7",
	"#F28E2B",
	"#FFCD00",
	"#009FDF",
	"#E14A8E",
	"#9D268F",
	"#58595B",
];

const Plot = () => {
	let dispatch = useDispatch();
	const location = useLocation();
	const [deviationData, setDeviationData] = useState<any>("");

	const [selectedAsset, setSelectedAsset] = useState<any>("");
	const [selectedModel, setSelectedModel] = useState<any>("");
	const [selectedSensor, setSelectedSensor] = useState<any>([]);

	const [loading, setLoading] = useState<any>(false);
	const [sensorChart, setSensorChart] = useState<any>([]);

	const [modelDropdownChanged, setModelDropdownChanged] =
		useState<boolean>(false);

	const {
		plotDeviationData,
		commonFromDateFormat,
		commonToDateFormat,
		breadCrumbDateFormated,
		commonToDate,
		commonFromDate,
		plotDeviationModel,
		plotSensorData,
		assetDropdownList,
		modelDropdownList,
		sensorDropdownList,
		globalSelecetedAsset,
		globalSelecetedPlant,
		modelSensorDropdownList,
		modelSensorUnTransformedList,
		loadingPlotDeviationData,
		loadingAssetDropdownList,
		loadingModelSensorDropdownList,
		loadingSensorDropdownList,
		loadingPlotSensorData,
	} = useSelector((state: any) => ({
		plotDeviationData: state.Common.plotDeviationData,
		plotStatusData: state.Common.plotStatusData,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		commonToDate: state.Common.commonToDate,
		commonFromDate: state.Common.commonFromDate,

		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,

		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,

		plotDeviationModel: state.Common.plotDeviationModel,
		loadingPlotDeviationData: state.Common.loadingPlotDeviationData,

		plotSensorData: state.Common.plotSensorData,
		loadingPlotSensorData: state.Common.loadingPlotSensorData,

		assetDropdownList: state.Common.assetDropdownList,
		modelDropdownList: state.Common.modelDropdownList,
		modelSensorDropdownList: state.Common.modelSensorDropdownList,
		modelSensorUnTransformedList: state.Common.modelSensorUnTransformedList,
		sensorDropdownList: state.Common.sensorDropdownList,

		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,

		loadingAssetDropdownList: state.Common.loadingAssetDropdownList,
		loadingModelSensorDropdownList: state.Common.loadingModelSensorDropdownList,
		loadingSensorDropdownList: state.Common.loadingSensorDropdownList,
	}));

	useEffect(() => {
		if (
			Object.keys(globalSelecetedPlant).length > 0 &&
			Object.keys(globalSelecetedAsset).length > 0
		) {
			if (location.state) {
				if (location.state.data === undefined) {
					setSelectedAsset(globalSelecetedAsset);
				} else {
					setSelectedAsset({
						value: location.state.data,
						label: location.state.data,
					});
				}
			} else {
				setSelectedAsset(globalSelecetedAsset);
			}
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
			dispatch(
				getModelSensorDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			); //{assetId}/{userId
		}
	}, []);

	useEffect(() => {
		if (modelSensorDropdownList.length > 0) {
			let data: any;
			if (location.state) {
				if (
					location.state.data2 !== undefined &&
					modelDropdownChanged === false
				) {
					data = { value: location.state.data2, label: location.state.data3 };
				} else {
					data = modelSensorDropdownList[0];
				}
			} else {
				data = modelSensorDropdownList[0];
			}
			// alert(JSON.stringify(modelSensorDropdownList))
			setSelectedModel(data);
			// dispatch(getPlotDeviationModel(`${modelDropdownList[0].value}/18`));
			dispatch(
				getSensorDropdownList(encryptRSAData(`sensorGroupId=${data.value}`))
			);
		}
	}, [modelSensorDropdownList]);

	useEffect(() => {
		if (sensorDropdownList.length > 0) {
			let list = [
				{
					value: sensorDropdownList[0].value,
					label: sensorDropdownList[0].label,
					color: "#E35205",
				},
			];
			if (location.state) {
				if (
					location.state.data4 !== undefined &&
					modelDropdownChanged === false
				) {
					try {
						let addedData = handleAddPiName(location.state.data4);
						setSelectedSensor(addedData);
					} catch (error) {}
				} else {
					setSelectedSensor(list);
				}
			} else {
				setSelectedSensor(list);
			}
		}
	}, [sensorDropdownList]);

	useEffect(() => {
		if (plotDeviationData.length > 0) {
			let transformer: any[];
			transformer = getDeviationTransformer(plotDeviationData);

			setDeviationData(transformer);
		} else {
			setDeviationData([]);
		}
	}, [plotDeviationData]);

	useEffect(() => {
		/**
		 *   Custom date Deviation
		 */
		if (
			selectedModel !== "" &&
			commonToDateFormat !== "" &&
			commonFromDateFormat !== "Invalid date"
		) {
			let data = modelSensorUnTransformedList.filter(
				(item: any) => item.sensorGroupId === selectedModel.value
			);
			//alert(JSON.stringify(data))

			if (data.length > 0) {
				dispatch(
					getPlotDeviationData(
						encryptRSAData(
							`modelId=${data[0].modelId}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
						)
					)
				); //{modelId}/{userId}/{fromDate}/{toDate}
				dispatch(
					getPlotDeviationModel(encryptRSAData(`modelId=${data[0].modelId}`))
				);
			}
		}
	}, [commonToDateFormat, selectedModel]);

	useEffect(() => {
		/**
		 *   Breadcrumb date Deviation
		 */
		let today = moment(new Date()).format("YYYY-MM-DD");
		if (
			selectedModel !== "" &&
			breadCrumbDateFormated !== "" &&
			breadCrumbDateFormated !== "Invalid date"
		) {
			let data = modelSensorUnTransformedList.filter(
				(item: any) => item.sensorGroupId === selectedModel.value
			);
			// alert(JSON.stringify(data))
			if (data.length > 0) {
				dispatch(
					getPlotDeviationData(
						encryptRSAData(
							`modelId=${data[0].modelId}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
						)
					)
				); //{assetId}/{userId}/{fromDate}/{toDate}
				dispatch(
					getPlotDeviationModel(encryptRSAData(`modelId=${data[0].modelId}`))
				);
			}
			//dispatch(getPlotDeviationData("17744/1/2022-09-02/2022-11-27")); //{assetId}/{userId}/{fromDate}/{toDate}
		}
	}, [breadCrumbDateFormated, selectedModel]);

	useEffect(() => {
		/**
		 *   Custom date Sensor Api
		 */
		let today: any;
		if (commonToDate !== "") {
			today = getSensorTodateAdded(commonFromDate);
		}
		const currentdate = new Date();
		let todayDate = moment(new Date()).format("YYYY-MM-DD");
		let minusthirtyDays = new Date(
			currentdate.setMonth(currentdate.getMonth() - 1)
		);
		if (
			selectedSensor.length > 0 &&
			commonToDate !== "" &&
			commonFromDateFormat !== "Invalid date"
		) {
			let sensorId = getSensorIdList(selectedSensor);
			let data = {
				sensorGroupId: sensorId,
				fromDate: getDateUtcFormat(minusthirtyDays),
				toDate: getDateUtcFormat(todayDate),
				timeZone: getTimeZone(),
			};

			dispatch(getPlotSensorData(data));
			// handleApiCall(data)
		}
	}, [commonToDate, selectedSensor]);

	useEffect(() => {
		/**
		 *   BreadCrumb date Sensor Api
		 */
		//  let today = getSensorTodateAdded(breadCrumbDateFormated)
		const currentdate = new Date();
		let todayDate = moment(new Date()).format("YYYY-MM-DD");
		let minusthirtyDays = new Date(
			currentdate.setMonth(currentdate.getMonth() - 1)
		);
		if (
			selectedSensor.length > 0 &&
			breadCrumbDateFormated !== "" &&
			breadCrumbDateFormated !== "Invalid date"
		) {
			let sensorId = getSensorIdList(selectedSensor);
			let data = {
				sensorGroupId: sensorId,
				fromDate: getDateUtcFormat(minusthirtyDays),
				toDate: getDateUtcFormat(todayDate),
				timeZone: getTimeZone(),
			};

			dispatch(getPlotSensorData(data));
			// handleApiCall(data)
		}
	}, [breadCrumbDateFormated, selectedSensor]);

	const handlePlotAssetIdDropDown = (e: any) => {
		setSelectedAsset(e);

		setModelDropdownChanged(true);
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
		dispatch(
			getModelSensorDropdownList(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`
				)
			)
		); //{assetId}/{userId
	};

	const handlePlotModeldDropDown = (e: any) => {
		setSelectedModel(e);
		setModelDropdownChanged(true);
		dispatch(getSensorDropdownList(encryptRSAData(`sensorGroupId=${e.value}`)));
	};

	const handlePlotSensorDropDown = (e: any) => {
		let value = e.map((item: any, index: any) => ({
			...item,
			color: colorList[index],
		}));

		setSelectedSensor(value);
	};

	const handleApiCall = (data: any) => {
		setSensorChart([]);
		setLoading(true);
		axios({
			method: "post",
			url: Api.getplotSensor_data,
			headers: {
				"Content-Type": "application/json",
			},
			data: data,
		})
			.then((response) => {
				setSensorChart(response.data);
				setLoading(false);
			})
			.catch((error) => {
				setLoading(false);
			});
	};

	const getDateTimeFormatted = (value) => {
		const date = new Date(value);

		const options = {
			year: "numeric",
			month: "2-digit",
			day: "2-digit",
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hours12: true,
		};
		// @ts-ignore: Unreachable code error
		const formattedTimestamp = date.toLocaleString("en-US", options);
		return formattedTimestamp;
	};

	/**
	 * This Function will add piName to sensor Dropwon when navigating from Alert List
	 */
	const handleAddPiName = (data: any) => {
		let val = data.map((obj1) => {
			sensorDropdownList.forEach((obj2) => {
				if (obj1.label === obj2.label) {
					obj1.value = obj2.value;
				}
			});
			return obj1;
		});
		return val;
	};

	const handleMore = () => {
		let base_url: any;
		if (
			commonToDateFormat !== "" &&
			commonFromDateFormat !== "Invalid date" &&
			commonToDateFormat !== undefined
		) {
			base_url = `https://pi-vision.sabic.com/PIVision/#/Displays/AdHoc?starttime=${commonFromDateFormat}&endtime=${commonToDateFormat}&DataItems=`;
		} else {
			let today = moment(new Date()).format("YYYY-MM-DD");
			base_url = `https://pi-vision.sabic.com/PIVision/#/Displays/AdHoc?starttime=${breadCrumbDateFormated}&endtime=${today}&DataItems=`;
		}

		let result: any = [];
		selectedSensor.forEach((element) => {
			result.push(`\\\\PI-DA.sabic.com\\${element.value}`);
		});
		let newUrl = "";
		newUrl = base_url + result.toString();

		window.open(newUrl, "_blank", "noreferrer");
	};

	return (
		<div>
			<div id="sensor">
				<div id="sensor-plot-left">
					<div id="sensor-plot">
						<div id="new-filter-plot">
							<div className="nf-left-plot">
								<div className="title">SENSOR PLOT</div>
								<div className="subtext-name">{selectedAsset.value}</div>
							</div>
							<div className="nf-right-plot">
								<div className="nfs-time">
									{plotDeviationModel.length > 0 ? (
										<>
											<div className="nfs-stamp">
												<span className="cus-label">Time Stamp</span>
												<span className="cus-value">
													{getDateTimeFormatted(
														plotDeviationModel[0].timeStamp
													)}
												</span>
											</div>
											<div className="nfs-deviation">
												<span className="cus-label">Model Deviation</span>
												<span className="cus-value">
													{plotDeviationModel[0].deviation}
												</span>
											</div>
										</>
									) : null}
								</div>
								<div className="nfs-options">
									<div>
										<label className="cus-label">Asset ID</label>
										<Dropdown
											name={"Asset Id"}
											options={assetDropdownList}
											handleChange={handlePlotAssetIdDropDown}
											defaultValue={""}
											value={selectedAsset}
											loading={loadingAssetDropdownList}
										/>
									</div>
									<div>
										<label className="cus-label">Model Name</label>
										<Dropdown
											name={"Model"}
											options={modelSensorDropdownList}
											handleChange={handlePlotModeldDropDown}
											defaultValue={""}
											value={selectedModel}
											loading={loadingModelSensorDropdownList}
										/>
									</div>
									<div className="mulsel">
										<label className="cus-label">Sensor Name</label>
										<DropdownMultiselect
											name={"Sensor"}
											options={sensorDropdownList}
											handleChange={handlePlotSensorDropDown}
											defaultValue={""}
											value={selectedSensor}
											loading={loadingSensorDropdownList}
										/>
									</div>
								</div>
							</div>
						</div>
						{loadingPlotSensorData ? (
							<div className="tc-loaderpd-200"><Loader /></div>
						) : plotSensorData.length === 0 ? (
							<div className="tc-loaderpd-200"><NoData /></div>
						) : (
							<SensorChart
								data={plotSensorData}
								selectedSensor={selectedSensor}
							/>							
						)}
					</div>
				</div>
				<SensorNames data={selectedSensor} handleMore={handleMore} />
			</div>
			<div id="sensor" className="pb25">
				{loadingPlotDeviationData ? (
					<div id="sensor-plot-left"><div className="tc-loaderpd-200"><Loader /></div></div>
				) : deviationData.length === 0 ? (
					<div id="sensor-plot-left"><div className="tc-loaderpd-200"><NoData /></div></div>
				) : (
					<DeviationChart
						plotData={deviationData}
						assetName={selectedAsset.value}
					/>
				)}
				<DeviationNames />
			</div>
		</div>
	);
};

export default Plot;

// dispatch(getPlotSensorDropDown("18/18")); //{sensorGroupId}/{userId}
// dispatch(getPlotDeviationData("18/18/06-03-2023/06-03-2023")); //{assetId}/{userId}/{fromDate}/{toDate}

// useEffect(() => {
//     dispatch(getPlotSensorDropDown("18/18"));
//     dispatch(getPlotSensorData("18/18"));
//     dispatch(getPlotAssetDropDown("18/18"));    //{plantId}/{userId}
//     dispatch(getPlotModelDropDown("18/18"));
//     dispatch(getPlotDeviationModel("18/18"));
//     // dispatch(getPlotStatusData("18/18/06-03-2023/06-03-2023")); //{assetId}/{userId}/{fromDate}/{toDate}
// }, []);

// useEffect(() => {
//     /**
//      *   Custom date Sensor Api
//     */
//     let today: any
//     if (commonToDate !== "") {
//         today = getSensorTodateAdded(commonFromDate)
//     }
//     if (selectedSensor.length > 0 && commonToDate !== "" && commonFromDateFormat !== "Invalid date") {
//         let sensorId = getSensorIdList(selectedSensor)
//         let data = {
//             "userId": 18,
//             "sensorGroupId": sensorId,
//             "fromDate": getDateUtcFormat(commonFromDateFormat),
//             "toDate": getDateUtcFormat(today),
//             "timezone": getTimeZone()
//         }

//         // dispatch(getPlotSensorData(data));
//         handleApiCall(data)
//     }
// }, [commonToDate, selectedSensor]);

// useEffect(() => {
//     /**
//      *   BreadCrumb date Sensor Api
//     */
//     let today = getSensorTodateAdded(breadCrumbDateFormated)
//     let todayDate = moment(new Date()).format("YYYY-MM-DD");
//     //  updatedDate = new Date(currentdate.setMonth(currentdate.getMonth() - 1));
//     if (selectedSensor.length > 0 && breadCrumbDateFormated !== "" && breadCrumbDateFormated !== "Invalid date") {
//         let sensorId = getSensorIdList(selectedSensor)
//         let data = {
//             "userId": 18,
//             "sensorGroupId": sensorId,
//             "fromDate": getDateUtcFormat(breadCrumbDateFormated),
//             "toDate": getDateUtcFormat(today),
//             "timezone": getTimeZone()
//         }

//         // dispatch(getPlotSensorData(data));
//         handleApiCall(data)
//     }
// }, [breadCrumbDateFormated, selectedSensor]);

{
	/* <div className="sensor-filter">
                            <div className="title">SENSOR PLOT</div>
                            <div className="sensor-time">
                                {plotDeviationModel.length > 0 ?
                                    <>
                                        <div className="sensor-stamp"> <span>Time Stamp</span> <span>{plotDeviationModel[0].timeStamp}</span></div>
                                        <div className="sensor-deviation"><span>Model Deviation</span> <span>{plotDeviationModel[0].deviation}</span> </div>
                                    </>
                                    : null
                                }
                            </div>
                            <div className="sensor-options">
                                <div><Dropdown
                                    name={"Asset Id"}
                                    options={assetDropdownList}
                                    handleChange={handlePlotAssetIdDropDown}
                                    defaultValue={""}
                                    value={selectedAsset}
                                /></div>
                                <div><Dropdown
                                    name={"Model"}
                                    options={modelSensorDropdownList}
                                    handleChange={handlePlotModeldDropDown}
                                    defaultValue={""}
                                    value={selectedModel}
                                /></div>
                                <div><DropdownMultiselect
                                    name={"Sensor"}
                                    options={sensorDropdownList}
                                    handleChange={handlePlotSensorDropDown}
                                    defaultValue={""}
                                    value={selectedSensor}
                                /></div>
                            </div>
                        </div>
                        <div className="common-box-asset-name"><div className="asset-name">{selectedAsset.value}</div>
                        </div> */
}
