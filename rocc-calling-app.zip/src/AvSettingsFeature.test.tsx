/*
 * Created on Tue Nov 02 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import AVSettingsFeature from "./AvSettingsFeature"
import { mockCongifData } from "./mocks/commonMocks"
import globalStore from "./redux/store/globalStore"

jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: jest.fn(),
}))

const avSettingsClientinitialization = jest.fn().mockReturnValue("initializeClient")
jest.mock("./redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("@rocc/rocc-chat-library", () => ({
    ChatHeader: () => <>{"This is avSettings client"}</>,
    RoccChatClient: () => jest.fn().mockImplementation(
        () => ({ initializeClient: avSettingsClientinitialization })
    )
}))

describe("AVSettingsFeature Component", () => {
    let avSettingsWrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(mockCongifData) 
        avSettingsWrapper = shallow(<AVSettingsFeature active={true} component="" />)
    })

    it("should render PersistGate component", () => {
        expect(avSettingsWrapper.find("PersistGate")).toHaveLength(1)
    })
})
