/*
 * Created on Thu Nov 04 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useState } from "react"
import HomeComponent from "./HomeComponent"
import { shallow } from "enzyme"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { withHooks } from "jest-react-hooks-shallow"
import { isArray } from "lodash"

const testState = {
    appReducer: {
        activeTabIndex: 1,
        focusedCallAndConsole: { callContextId: "", consoleContextId: "" }
    },
    customerReducer: {
        rooms: [{
            identity: { id: 1, name: "MR", uuid: "123" },
            locationId: 1, address: "", modality: "MR", modalityId: 1, favourite: true, phoneNumber: "+1234",
            presenceData: { presence: "OFFLINE", mapId: "" },
        }],
        locations: []
    },
    userReducer: {
        currentUser: {}
    },
    featureFlagsReducer: {
        featureFlags: {
            "rocc_room_monitoring": false
        }
    }
}

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: () => jest.fn(),
}))

jest.mock("../../redux/store/globalStore", () => ({
    CreateStore: jest.fn(),
    GetGlobalState: jest.fn().mockReturnValue({
        CC_CONSOLE: {
            protocolTransferReducer: {
                protocolTransferStatus: false
            },
            consoleReducer: {
                consoleSessions: [{
                    roomUuid: "123",
                    connectionType: "PROTOCOL_MANAGEMENT",
                }],
                consoleOperation: {
                    transactions: []
                },
                commandCenterDetails: {
                    commandCenterSeat: {
                        receivers: []
                    }
                }
            }
        },
        CC_CALLING: {
            callReducer: {
                phoneCallStatus: "connected",
                videoCallStatus: [],
                missedCalls: []
            }
        }
    }),
    SubscribeToPartnerState: jest.fn(),
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

describe("HomeComponent", () => {
    let wrapper: any
    let e: any
    const data = { activeIndex: 1, panes: [{}, { pane: { key: 1 } }] }
    const actualUseState = useState
    const useStateSpy = jest.spyOn(React, "useState") as unknown as jest.SpyInstance<[any, React.Dispatch<any>]>

    beforeEach(() => {
        useStateSpy.mockImplementation((defaultState: any) => {
            if (isArray(defaultState) && Object.keys(defaultState[0] ?? {}).some((value: string) => ["title", "contextId", "menuItem", "pane"].includes(value))) {
                return [[{ contextId: "" }, { contextId: "context-id" },], jest.fn()] as [any, React.Dispatch<any>]
            }
            return actualUseState(defaultState)
        })
        useSelectorMock(testState)
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
    it("should render Tab and its properties", () => {
        withHooks(() => {
            wrapper = shallow(<HomeComponent />)
            expect(wrapper.find("Tab")).toHaveLength(1)
            const onTabChange = wrapper.find("Tab").prop("onTabChange")
            onTabChange(e, data)
            expect(wrapper.find("Tab").prop("activeIndex")).toEqual(1)
        })
    })
})
