"""
 Created on Tue Sep 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import sys
import logging
from opencensus.trace import config_integration
from src.loggers.kibana_logger import make_log_ingester
from opencensus.ext.azure.log_exporter import AzureLogHandler

connection_string = os.environ["APPINSIGHTS_CONNECTION_STRING"]
log_format = "%(asctime)s %(name)s %(levelname)-8s %(message)s"


def set_log_level():
    env_log_level = os.environ.get("LOG_LEVEL", "INFO")
    app_log_level = logging.INFO
    try:
        if env_log_level == "DEBUG":
            app_log_level = logging.DEBUG
        elif env_log_level == "ERROR":
            app_log_level = logging.ERROR
        return app_log_level
    except Exception as ex:
        print("Error while setting up logger level: {}".format(ex))


def callback_function(envelope):
    vcap_application = json.loads(os.environ["VCAP_APPLICATION"])
    envelope.tags['ai.cloud.role'] = vcap_application["name"]


def default_logger(name):
    logger = logging.getLogger(name)
    log_level = set_log_level()
    try:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(log_format))
        handler.setLevel(log_level)
        logger.addHandler(handler)
        azure_handler = build_azure_handler()
        azure_handler.setLevel(log_level)
        logger.addHandler(azure_handler)
    except Exception as ex:
        print("Error while setting up logger: {}".format(ex))
    logger.setLevel(log_level)
    return logger


class create_logger:
    def __init__(self, file_name, transaction_id=None):
        self._file_name = file_name
        self._log = default_logger(self._file_name)
        self._transaction_id = transaction_id

    def info(self, message):
        self._log.info(message)
        make_log_ingester(message=message, severity="INFO", component=self._file_name, transaction_id=self._transaction_id)

    def error(self, message):
        self._log.error(message)
        make_log_ingester(message=message, severity="ERROR", component=self._file_name, transaction_id=self._transaction_id)

    def exception(self, message):
        self._log.exception(message)
        make_log_ingester(message=message, severity="ERROR", component=self._file_name, transaction_id=self._transaction_id)

    def warn(self, message):
        self._log.warn(message)
        make_log_ingester(message=message, severity="WARNING", component=self._file_name, transaction_id=self._transaction_id)

    def warning(self, message):
        self._log.warn(message)
        make_log_ingester(message=message, severity="WARNING", component=self._file_name, transaction_id=self._transaction_id)

    def debug(self, message):
        self._log.debug(message)
        make_log_ingester(message=message, severity="DEBUG", component=self._file_name, transaction_id=self._transaction_id)


def build_azure_handler():
    config_integration.trace_integrations(['requests', 'logging'])
    log_dfmt = '%Y-%m-%d %H:%M:%S'
    formatter = logging.Formatter(log_format, log_dfmt)
    handler = AzureLogHandler(connection_string=connection_string)
    handler.add_telemetry_processor(callback_function)
    handler.setFormatter(formatter)
    return handler

