"""
 Created on Thu Sep 17 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest import mock
from src.constants.constants import PHILIPS_ROCC_URI

from src.wrappers.platform_services.communication_services.communication_profile_services import delete_org_comm_profile_service, fetch_org_comm_profile_service, validate_twilio_sub_account_integrity, create_org_comm_profile_service, create_communication_profile_for_device_api
from tests.mocks.mock_requests import MockResponse


def mocked_requests(*args, **kwargs):
    org_comm_profile_response = {"twilioSid": "v1", "twilioAuthToken": "v2", "orgName": "v3"}
    comm_profile_response = {"userIdentity": "dummy"}
    switcher = {
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation/get_org_id": MockResponse(org_comm_profile_response, 200),
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation": MockResponse({"orgIdentity": "org_id"}, 201),
        f"/url{PHILIPS_ROCC_URI}/twilio/Account/sub_acc_name/twilio_sid/$isValid": MockResponse(True, 200),
        f"/url{PHILIPS_ROCC_URI}/admin/Organisation/del_org_id": MockResponse(None, 204),
        f"/url/{PHILIPS_ROCC_URI}/CommunicationProfile": MockResponse(comm_profile_response, 201),
    }
    mocked_response = switcher.get(args[0], MockResponse(None, 200))
    if len(kwargs):
        pass
    return mocked_response


class TestCommunicationServices(unittest.TestCase):

    @mock.patch("src.wrappers.platform_services.communication_services.communication_profile_services.requests.get", side_effect=mocked_requests)
    def test_fetch_org_comm_profile_service(self, mock_post):
        response = fetch_org_comm_profile_service("/url", "token", "get_org_id")
        mock_post.assert_called()
        self.assertEqual(response.get("twilioSid"), "v1")

    @mock.patch("src.wrappers.platform_services.communication_services.communication_profile_services.requests.get", side_effect=mocked_requests)
    def test_validate_twilio_sub_account_integrity(self, mock_post):
        response = validate_twilio_sub_account_integrity("/url", "token", "sub_acc_name", "twilio_sid", "org_id")
        mock_post.assert_called()
        self.assertTrue(response)

    @mock.patch("src.wrappers.platform_services.communication_services.communication_profile_services.requests.delete", side_effect=mocked_requests)
    def test_delete_org_comm_profile_service(self, mock_post):
        response = delete_org_comm_profile_service("/url", "token", "del_org_id")
        mock_post.assert_called()
        self.assertTrue(response)

    @mock.patch("src.wrappers.platform_services.communication_services.communication_profile_services.requests.post", side_effect=mocked_requests)
    def test_create_org_comm_profile_service(self, mock_post):
        response, error_reasn = create_org_comm_profile_service("/url", "org_name", "token", "org_id", "country_iso_code", "sub_acc_name")
        mock_post.assert_called()
        self.assertEqual(response, "org_id")
        self.assertEqual(error_reasn, "")

    @mock.patch("src.wrappers.platform_services.communication_services.communication_profile_services.requests.post", side_effect=mocked_requests)
    def test_create_communication_profile_for_device_api(self, mock_post):
        response, error_reasn = create_communication_profile_for_device_api("/url", "device_name", "device_token", "org_ctxt_header")
        mock_post.assert_called()
        self.assertEqual(error_reasn, "Communication profile created successfully")
        self.assertEqual(response, "dummy")


suite = unittest.TestSuite()

suite.addTest(TestCommunicationServices("test_fetch_org_comm_profile_service"))
suite.addTest(TestCommunicationServices("test_validate_twilio_sub_account_integrity"))
suite.addTest(TestCommunicationServices("test_delete_org_comm_profile_service"))
suite.addTest(TestCommunicationServices("test_create_org_comm_profile_service"))
suite.addTest(TestCommunicationServices("test_create_communication_profile_for_device_api"))

unittest.TextTestRunner(verbosity=0).run(suite)
