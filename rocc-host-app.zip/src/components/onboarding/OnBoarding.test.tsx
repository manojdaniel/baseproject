/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import OnBoarding from "./OnBoarding"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: {
            onBoarded: false,
        },
        urls: {},
    })
}))

describe("OnBoarding component", () => {
    let wrapper: any
    let onBoarding: any
    beforeEach(() => {
        wrapper = shallow(<OnBoarding />)
        expect(wrapper).not.toBeNull()
        onBoarding = wrapper.find("Fragment")
    })

    it("should render form controller", () => {
        expect(onBoarding).toHaveLength(1)
    })

})
