/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Button, Grid, Header, Item } from "semantic-ui-react"
import iframeBg from "../../../assets/images/welcomescreenvideoBg.png"
import { ONBOARDING_WELCOME_VIDEO } from "../../../constants/constants"
import en from "../../../resources/translations/en-US"
import styles from "./WelcomeForm.scss"
import { getIntlProvider } from "@rocc/rocc-global-components"

interface IWelcomeForm {
    username: string
    getStarted: () => void
}

const WelcomeForm = (props: IWelcomeForm) => {
    const { getStarted } = props
    const { intl } = getIntlProvider()
    return (
        <div className={styles.welcomeForm} id="welcomeForm">
            <Header textAlign={"left"}>
                <Item className={styles.welcomeContent}>
                    <Item.Header className={styles.welcomeHeaderTitle}>
                        {intl.formatMessage({ id: "content.onboarding.welcomeHeaderTitle", defaultMessage: en["content.onboarding.welcomeHeaderTitle"] })}
                    </Item.Header>
                    <Item.Content className={styles.welcomeSubContent}>
                        {intl.formatMessage({ id: "content.onboarding.welcomeSubContent1", defaultMessage: en["content.onboarding.welcomeSubContent1"] })}
                    </Item.Content>

                    <Item.Header className={styles.welcomeSubTitle}>
                        {intl.formatMessage({ id: "content.onboarding.welcomeSubTitle", defaultMessage: en["content.onboarding.welcomeSubTitle"] })}
                    </Item.Header>
                    <Item.Content className={styles.welcomeSubContent}>
                        {intl.formatMessage({ id: "content.onboarding.welcomeSubContent2", defaultMessage: en["content.onboarding.welcomeSubContent2"] })}
                    </Item.Content>
                    <Grid className={styles.iframeContainer}>
                        <video poster={iframeBg} controls={true} className={styles.iframePlayer}>
                            <source src={ONBOARDING_WELCOME_VIDEO} type="video/mp4" />
                            {intl.formatMessage({ id: "content.onboarding.welcomeVideoTag", defaultMessage: en["content.onboarding.welcomeVideoTag"] })}
                        </video>
                    </Grid>
                </Item>
            </Header>

            <Button id="next" primary={true} onClick={getStarted} className={styles.getStarted}>
                {intl.formatMessage({ id: "content.next.btn", defaultMessage: en["content.next.btn"] })}
            </Button>
        </div>
    )
}

export default WelcomeForm
