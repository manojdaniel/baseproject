/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EOperationStatus } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { CONSOLE_OPERATIONS, DECREMENT_KVM_SESSIONS, INCREMENT_KVM_SESSIONS, RESET_KVM_SESSION, SET_ACTIVE_SEAT, SET_NFCC_APP_PATH, UPDATE_CONTEXT_PID_MAPPINGS } from "../actions/types"
import { ECommandCenterAccessMode, ICommandCenterDetails, ICommandCenterSeat, IConsoleReducer } from "../interfaces/types"

export const INIT_COMMAND_CENTER_SEAT: ICommandCenterSeat = { seatName: "", organizationId: 0, receivers: [] }
export const INIT_WITHOUT_HARDWARE_COMMAND_CENTER_DETAILS: ICommandCenterDetails = { commandCenterSeat: INIT_COMMAND_CENTER_SEAT, initialised: ECommandCenterAccessMode.WITHOUT_HARDWARE }
export const INIT_COMMAND_CENTER_LOCATION = { seatName: "", organizationId: 0 }

export const DEFAULT_CONSOLE_OPERATIONS = { operationId: "", operationStatus: EOperationStatus.IDLE, postTransactionHook: () => undefined, transactions: [] }
export const initialStatesForConsole: IConsoleReducer = {
    consoleSessions: [],
    commandCenterDetails: { initialised: ECommandCenterAccessMode.INIT, commandCenterSeat: { organizationId: 0, seatName: "", receivers: [] } },
    consoleOperation: DEFAULT_CONSOLE_OPERATIONS,
    consoleMessages: [],
    contextPidMappings: [],
    nfccAppPath : ""
}

const consoleReducer: Reducer = (state: IConsoleReducer = initialStatesForConsole, action: any) => {
    switch (action.type) {
        case RESET_KVM_SESSION:
        case DECREMENT_KVM_SESSIONS:
        case INCREMENT_KVM_SESSIONS:
            return { ...state, consoleSessions: action.consoleSessions }
        case CONSOLE_OPERATIONS:
            return { ...state, consoleOperation: action.consoleOperation }
        case SET_ACTIVE_SEAT:
            return { ...state, commandCenterDetails: action.commandCenterDetails }
        case UPDATE_CONTEXT_PID_MAPPINGS:
            return { ...state, contextPidMappings: action.contextPidMappings }
        case SET_NFCC_APP_PATH:
            return { ...state, nfccAppPath: action.nfccAppPath }
        default:
    }
    return { ...state }
}

export default consoleReducer
