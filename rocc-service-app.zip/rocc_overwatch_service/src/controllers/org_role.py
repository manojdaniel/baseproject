"""
 Created on Wed Feb 23 2022
 Copyright (c) 2022 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
from flask import request, g
from flask_restful import Resource, reqparse

from src.constants.constants import API_VERSION, HELP_MESSAGE
from src.constants.headers import RBAC_ROLES_FILE_PATH
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.services.org_role_services import OrgRoleService
from src.utility.utility import construct_negative_response, check_if_array_is_empty

LOG = create_logger("OrgRole controller")


class OrgRole(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument(
        "added_org_roles", type=list, location="json", required=True, help=HELP_MESSAGE)
    parser.add_argument(
        "deleted_org_roles", type=list, location="json", required=True, help=HELP_MESSAGE)

    def get(self, org_name):
        try:
            api_version = request.headers[API_VERSION]
            if api_version != "1.0.0":
                return construct_negative_response(code="400 Bad Request ", title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request ", title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            org_role_service = OrgRoleService(g.userdetails, org_name)
            response = org_role_service.fetch_org_roles()
            return response
        except RoccException as ex:
            LOG.exception(
                f"Failed to fetch roles with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title,
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(
                f"Failed to fetch roles with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to fetch data, please contact administrator"), 500

    def put(self, org_name):
        try:
            api_version = request.headers[API_VERSION]
            if api_version != "1.0.0":
                return construct_negative_response(code="400 Bad Request", title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request", title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            body = self.parser.parse_args()
            with open(RBAC_ROLES_FILE_PATH) as rbac_roles_file:
                rbac_roles = json.load(rbac_roles_file)
                if ((check_if_array_is_empty(body["added_org_roles"]) and check_if_array_is_empty(body["deleted_org_roles"])) or (not set(body["added_org_roles"]).issubset(set(rbac_roles["ROLES"])))):
                    return {"message": "required at least one role to update or Invalid roles to update"}, 400
        except Exception as ex:
            LOG.exception(
                f"Exception while parsing org_role_object_args or Invalid Org role, error: {ex}")
            return {"message": "Error in Payload"}, 400

        try:
            org_role_service = OrgRoleService(g.userdetails, org_name)
            response = org_role_service.update_org_roles(
                body["added_org_roles"], body["deleted_org_roles"])
            if response:
                return {
                    "message": "Roles updated successfully."
                }, 200
            else:
                raise Exception

        except RoccException as ex:
            LOG.exception(
                f"Failed to update roles with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(
                f"Failed to update roles with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to update roles, please contact administrator"), 500
