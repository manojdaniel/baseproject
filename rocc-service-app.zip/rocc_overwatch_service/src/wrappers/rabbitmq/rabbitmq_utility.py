"""
 Created on Tue Mar 9 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import traceback
from src.loggers.log import create_logger
from src.wrappers.cf.cf_utility import fetch_app_name
from src.constants.constants import PERSIST_RABBIT_QUEUE, ROCC_SERVICE_TOOL_EXCHANGE, ROCC_SERVICE_TOOL_QUEUE

LOG = create_logger("RabbitmqUtility")

RABBITMQ_CONNECTION_ATTEMPT = 10    # 10 tries
RABBITMQ_CONNECTION_HEARTBEAT = 60  # 60 seconds


def compute_rmq_queue_name(rmq_queue_name=ROCC_SERVICE_TOOL_QUEUE):
    return append_app_name(rmq_queue_name)


def compute_rmq_exchange_name(rmq_exchange_name=ROCC_SERVICE_TOOL_EXCHANGE):
    return append_app_name(rmq_exchange_name, "E")


def append_app_name(item_name, item_type="Q"):
    try:
        app_name = fetch_app_name()
        return f"{item_name}.{app_name}"
    except Exception as ex:
        LOG.error(f"Computing of RabbitMQ {'Queue' if item_type == 'Q' else 'Exchange'} name failed with error: {ex}")
        LOG.error(traceback.print_exc())
    return item_name


def check_if_queue_should_auto_delete():
    try:
        should_persist = os.environ.get(PERSIST_RABBIT_QUEUE, "true")
        return False if should_persist.lower() == "true" else True
    except Exception as ex:
        LOG.error(f"Failed to get environment value for {PERSIST_RABBIT_QUEUE} with error: {ex}")
    return False
