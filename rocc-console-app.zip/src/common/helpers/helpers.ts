/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {
    APP_NAME, APP_URI_ARGS, DisconnectConsoleSessionContext, EButtonDirection, ECallStatus, EClinicalRole, EConnectionMode, EConnectionState,
    EConnectionType, ERoccWorkflow, getLocationDetailsForId, getRoomDetailFromUuid, IAVCallDetails, ICallStatus, IConsoleSession, IMessage,
    IParticipantInfo, IRoomDetails, isQualifiedForFixedCommandCenterEdit, IUserInfo, MultiEditInitiateCallContext, MultiEditStartEditingContext,
    ParkAndInitiateCallContext, ParkAndResumeContext, ParkAndStartEditingContext, parseIntBase10, ROCC_FEATURES, TransactionValue, ETransactionStatus,
    EOperationStatus, FeatureFlagHelper, ACCESS_TOKEN
} from "@rocc/rocc-client-services"
import { EMultiSessionModalNextAction } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, sendLogsToAzure } from "@rocc/rocc-logging-module"
import isEmpty from "lodash.isempty"
import { errorModalHeader, requestRejectModalHeader } from "../../components/console-monitor-selection/ConsoleMonitorSelectionHelper"
import { GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import { ECommandCenterAccessMode, IConsoleOperation, IConsoleTransaction, IContextPidMapping, IReceiver, IRoomInfo, IWorkflowInfo } from "../../redux/interfaces/types"
import {
    dispatchToParentStore, fetchGlobalConfigs, fetchGlobalCurrentUser, fetchGlobalFeatureFlags, fetchGlobalOrgUUID, fetchGlobalURLs,
    fetchLocations, fetchRooms
} from "../../redux/store/externalAppStates"
import globalStore from "../../redux/store/globalStore"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"
import { spokeNotQualifiedService } from "../../services/consoleService"
import {
    ADMIN_SERVICE_ENDPOINT, API_ENDPOINT, API_METHOD, API_METHOD_STRING, API_VERSION_STRING, BUNDLE_NAME, BUNDLE_VERSION, CALLING_APP, CALL_ACCEPT, CONTEXT_ID, CONTROL_CONSOLE,
    DEFAULT_API_VERSION, DOWNLOAD_URL, EMERALD_APP_NAME, EMERALD_APP_URI, EMERALD_APP_URI_PID, EMERALD_APP_URI_RESTART, EMERALD_APP_URI_START, EMERALD_APP_URI_STOP,
    EMERALD_APP_URI_STOP_ALL, EMERALD_KVM_MAPPING_CLI_ARGS, GET, GLOBAL_UPDATE_ROOMS, HTTP_STATUS, IAM_SERVICE_ENDPOINT, INIT_ROOM_INFO, KVM_ADMIN_USERNAME,
    MANAGE_GRAPHQL_BUNDLE_INFOS_EP, NFCC_BUNDLE_VERSION, ORG_ID_STRING, PID, PID_UPDATE_ENDPOINT, PUT, ROCC_ANY_WHERE_APP, SESSION_MANAGEMENT_EP, TARGET_APP_ARGS, TARGET_APP_ENDPOINT,
    TARGET_APP_NAME, UPDATER_NAME, URL, VERSION_STRING, WEB_SOCKET_URL
} from "../constants/constants"
import { CONSOLE_TRANSACTION } from "../constants/endpoints"
import { checkIfMultiEditWithParkResumeFeatureEnabled } from "./consoleUtility"
import { transformSessionTypeForAnalytics } from "./TelemetryTrackingHelper"

const currentUser = fetchGlobalCurrentUser()

export const checkIfViewConsoleEnabled = (permissions: any, receivers: IReceiver[]) => {
    return !!permissions.CONSOLE_VIEW && !!receivers.length
}

export const checkIfEditConsoleEnabled = (permissions: any, receivers: IReceiver[], activeConnectionMode?: EConnectionMode) => {
    let editEnabled = !!permissions.CONSOLE_EDIT && !!receivers.length
    if (activeConnectionMode && activeConnectionMode !== EConnectionMode.CC) {
        editEnabled = false
    }
    return editEnabled
}

export const checkIfIncognitoConsoleEnabled = (permissions: any, receivers: IReceiver[]) => {
    return !!permissions.CONSOLE_VIEW_INCOGNITO && !!receivers.length
}

export const checkIfPMEditConsoleEnabled = (permissions: any, receivers: IReceiver[]) => {
    return !!permissions.CONSOLE_EDIT_WITHOUT_AUTHORIZATION && !!receivers.length
}

export const getMaxNumAllowedNFCC = () => {

    const { receivers } = store.getState().consoleReducer.commandCenterDetails.commandCenterSeat

    const { MAX_NUM_OF_CONSOLE_SESSION, MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE } = fetchGlobalConfigs()

    if (receivers.length && receivers[0].id) {
        const maxNFCCWithHardware = parseIntBase10(MAX_NUM_OF_CONSOLE_SESSION) - receivers.length
        const maxConnectionLimit = Math.min(maxNFCCWithHardware, parseIntBase10(MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE))
        return maxConnectionLimit
    }
    else {
        return parseIntBase10(MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE)
    }
}

export const isMaximumNFCCLimitReached = (consoleSessions: IConsoleSession[], excludeRoom: string = "") => {
    const numOfActiveSessions = getAllActiveSessionsForConnectionMode(consoleSessions, EConnectionMode.EMERALD, excludeRoom).length

    return numOfActiveSessions >= getMaxNumAllowedNFCC()
}

export const getAllActiveSessionsForConnectionMode = (consoleSessions: IConsoleSession[], mode: EConnectionMode, excludeRoom: string = "") => {
    return consoleSessions.filter(session => session.connectionMode === mode && session.roomUuid !== excludeRoom)
}

export const getActiveSessionsForConnectionMode = (consoleSessions: IConsoleSession[], mode: EConnectionMode) => {
    return consoleSessions.find(session => session.connectionMode === mode)
}

export const getStateValueDependency = (workflows: IWorkflowInfo[]) => JSON.stringify(
    workflows.map(
        (workflow: IWorkflowInfo) => workflow.state.value
    )
)

export const checkIfEmeraldEnabled = (isPermissionEnabled: boolean, kvmUsername?: string) => {
    return isPermissionEnabled && kvmUsername && kvmUsername !== (isEmpty(kvmUsername) && KVM_ADMIN_USERNAME) && isNFCCAllowed()
}

export const checkIfEmeraldPMEnabled = (permissions: any, roomAdditionalAttributes: any, kvmUsername?: string) => {
    return checkIfEmeraldEnabled(!!permissions.CONSOLE_EDIT_WITHOUT_AUTHORIZATION, kvmUsername) && isQualifiedForFixedCommandCenterEdit(roomAdditionalAttributes)
}

export const checkIfEmeraldEditEnabled = (permissions: any, kvmUsername?: string, activeConnectionMode?: EConnectionMode) => {
    let emeraldEditEnabled = checkIfEmeraldEnabled(!!permissions.CONSOLE_EDIT, kvmUsername)
    if (activeConnectionMode && activeConnectionMode !== EConnectionMode.EMERALD) {
        emeraldEditEnabled = false
    }
    return emeraldEditEnabled
}

export const fetchAllEditConsoleType = () => {
    const { FULL_CONTROL, FULL_CONTROL_USB, PROTOCOL_MANAGEMENT } = EConnectionType
    return [FULL_CONTROL, FULL_CONTROL_USB, PROTOCOL_MANAGEMENT]
}

export const fetchAllViewConsoleType = () => {
    const { VIEW, INCOGNITO_VIEW } = EConnectionType
    return [VIEW, INCOGNITO_VIEW]
}

export const checkIfParkedConsoleEnabled = (currentSession?: IConsoleSession) => {
    return checkIfMultiEditWithParkResumeFeatureEnabled() && currentSession?.connectionStatus === EConnectionState.PARKED
}

export const getConsoleConnectionErrorMessage = (errObject: any) => {
    const { intl } = getIntlProvider()
    try {
        if (errObject.response && errObject.response.data && errObject.response.data.httpStatusCode && errObject.response.data.httpStatusCode === HTTP_STATUS.LOCKED) {
            return intl.formatMessage({ id: "content.consconsoleMessages.consoleConnectionRestricted", defaultMessage: en["content.consoleMessages.consoleConnectionRestricted"] })
        }
    } catch (error) {
        errorLogger(`Failed to parse the error object: ${JSON.stringify(error)}`)
    }
    return ""
}

export const shouldUsePID = () => {
    return !FeatureFlagHelper.isFeatureEnabled(fetchGlobalFeatureFlags(), ROCC_FEATURES.FLAG_ROCC_EMERALD_CLI, true)
}

export const constructAppUriForBundleUpgrade = (bundleName: string, nfccBundle: any) => {
    const { accessToken, id } = fetchGlobalCurrentUser()
    const apiEndpoint = `${fetchGlobalURLs().MANAGEMENT_SERVICE_URL}${MANAGE_GRAPHQL_BUNDLE_INFOS_EP}/${id}`
    const config = {
        [APP_NAME]: UPDATER_NAME,
        [APP_URI_ARGS]: {
            [ACCESS_TOKEN]: accessToken, [API_ENDPOINT]: apiEndpoint, [API_METHOD_STRING]: "PUT", [API_VERSION_STRING]: DEFAULT_API_VERSION,
            [ORG_ID_STRING]: fetchGlobalOrgUUID(), [BUNDLE_NAME]: bundleName, [BUNDLE_VERSION]: nfccBundle.version, [DOWNLOAD_URL]: nfccBundle.url
        }
    }
    return `?config=${JSON.stringify(config)}`
}

export const constructAppUriConfigs = (accessToken: string, apiVersion: string,
    action: string, pid: number, consoleServiceUrl: string, contextId: string, prevContextId?: string) => {
    if (shouldUsePID()) {
        return constructAppUriConfigsforPID(accessToken, apiVersion, action, pid, consoleServiceUrl, contextId)
    }
    else {
        return constructAppUriConfigsforCLI(accessToken, action, pid, consoleServiceUrl, [contextId], prevContextId)
    }

}
export const constructAppUriConfigsforPID = (accessToken: string, apiVersion: string,
    action: string, pid: number, consoleServiceUrl: string, contextId: string) => {
    const appArguments = [consoleServiceUrl + CONSOLE_TRANSACTION + contextId, "PUT", accessToken, apiVersion]
    const config = {
        ["appName"]: EMERALD_APP_NAME,
        ["appArguments"]: appArguments
    }
    const stopAllConfig = {
        ["appName"]: EMERALD_APP_NAME,
    }
    switch (action) {
        case EMERALD_APP_URI_STOP:
            return `?${PID}=${pid}`
        case EMERALD_APP_URI_STOP_ALL:
            return `?config=${JSON.stringify(stopAllConfig)}`
        case EMERALD_APP_URI_START:
            return `?config=${JSON.stringify(config)}`
        case EMERALD_APP_URI_RESTART:
            return `?config=${JSON.stringify(config)}&${PID}=${pid}`
        default:
            return
    }
}

export const constructAppUriConfigsforCLI = (accessToken: string, action: string, pid: number, consoleServiceUrl: string, contextId: string[], prevContextId?: string) => {
    if (action === EMERALD_APP_URI_STOP_ALL) {
        return `?config=${JSON.stringify({ [APP_NAME]: EMERALD_APP_NAME })}`
    }

    const contextUuids = contextId
    if (prevContextId) {
        contextUuids.push(prevContextId)
    }

    const cliArgs = constructCommonAppUriconfig(accessToken, pid, consoleServiceUrl, contextId[0])
    cliArgs[APP_URI_ARGS][TARGET_APP_ENDPOINT] = {
        [URL]: consoleServiceUrl + EMERALD_KVM_MAPPING_CLI_ARGS + `?listOfcontextUuid=${contextUuids.join(",")}`,
        [VERSION_STRING]: DEFAULT_API_VERSION, [API_METHOD]: PUT
    }
    cliArgs[APP_URI_ARGS][TARGET_APP_NAME] = EMERALD_APP_NAME
    return `?config=${JSON.stringify(cliArgs)}`
}

const constructCommonAppUriconfig = (accessToken: string, pid: number, consoleServiceUrl: string, contextId: string) => {
    const { sessionId, id } = fetchGlobalCurrentUser()
    const orgId = fetchGlobalOrgUUID()
    const { GRAPHQL_API_HSDP_WS_URI, IAM_SERVICES_URL, MANAGEMENT_SERVICE_URL } = fetchGlobalURLs()

    const config = {
        [APP_NAME]: ROCC_ANY_WHERE_APP,
        [APP_URI_ARGS]: {
            [ACCESS_TOKEN]: accessToken, [ORG_ID_STRING]: orgId, [CONTEXT_ID]: contextId, [WEB_SOCKET_URL]: GRAPHQL_API_HSDP_WS_URI,
            [IAM_SERVICE_ENDPOINT]: { [URL]: `${IAM_SERVICES_URL}${SESSION_MANAGEMENT_EP}${sessionId}`, [VERSION_STRING]: DEFAULT_API_VERSION, [API_METHOD]: GET },
            [ADMIN_SERVICE_ENDPOINT]: {},
            [PID_UPDATE_ENDPOINT]: {
                [URL]: consoleServiceUrl + CONSOLE_TRANSACTION + contextId, [VERSION_STRING]: DEFAULT_API_VERSION, [API_METHOD]: PUT
            },
            [TARGET_APP_ENDPOINT]: {},
            [TARGET_APP_NAME]: "",
            [TARGET_APP_ARGS]: {},
            [PID]: pid
        }
    }
    const isBundleExists = localStorage.getItem(NFCC_BUNDLE_VERSION)
    //if bundle version not available in web app, then update db
    if (!isBundleExists) {
        config[APP_URI_ARGS][ADMIN_SERVICE_ENDPOINT] = {
            [URL]: MANAGEMENT_SERVICE_URL + MANAGE_GRAPHQL_BUNDLE_INFOS_EP + id,
            [VERSION_STRING]: DEFAULT_API_VERSION, [API_METHOD]: PUT
        }
    }

    return config
}

export const isDevice = () => {
    return currentUser.clinicalRole === EClinicalRole.DEVICE
}

export const createHiddenElement = (element: string, name?: string) => {
    const el = document.createElement(element)
    if (name) {
        el.setAttribute("name", name)
    }
    el.style.display = "none"
    document.body.appendChild(el)
    return el
}

export const launchAppUri = (action: string, config: string) => {
    let url: string = shouldUsePID() ? EMERALD_APP_URI_PID : EMERALD_APP_URI
    url = `${url}${action}${config}`

    if (!isDevice()) {
        const iframeName = "AppUriLauncher"
        const iframe = createHiddenElement("iframe", iframeName)
        iframe.setAttribute("visibility", "hidden")
        iframe.setAttribute("position", "absolute")

        const a = createHiddenElement("a")
        a.setAttribute("href", url)
        a.setAttribute("target", iframeName)
        a.click()
    }
}

export const checkAndStopEmeraldApp = async (connectionMode: EConnectionMode, currentUser: IUserInfo, consoleServiceUrl: string, pid: number) => {
    if (connectionMode === EConnectionMode.EMERALD) {
        const config = await constructAppUriConfigs(currentUser.accessToken, DEFAULT_API_VERSION, EMERALD_APP_URI_STOP, pid, consoleServiceUrl, "")
        if (config) {
            launchAppUri(EMERALD_APP_URI_STOP, config)
        }
    }
}

export const getPidFromContextMapping = (contextId: string | undefined) => {
    try {
        const mappings = store.getState().consoleReducer.contextPidMappings
        const mapping = mappings && mappings.find((mapping: IContextPidMapping) => mapping.contextId === contextId)
        return mapping ? mapping.pid : 0
    } catch (error) {
        errorLogger(`Error while fetching PID from contextId. ${errorParser(error)}`)
        return 0
    }
}
export const checkIfReceiverInUse = (consoleSessions: IConsoleSession[], receiverName: string) => {
    return consoleSessions.findIndex(session => receiverName && session.receiverName === receiverName) > -1
}

export const fetchActiveSessionForReceiver = (consoleSessions: IConsoleSession[], receiverName: string) => {
    return consoleSessions.find(session => receiverName && session.receiverName === receiverName)
}

export const fetchConsoleSessionByRoomUuid = (consoleSessions: IConsoleSession[], roomUuid: string) => {
    return consoleSessions.find(session => session.roomUuid === roomUuid)
}

export const fetchViewConsoleSessionForRoom = (consoleSessions: IConsoleSession[], roomUuid: string) => {
    const viewConsoleList = fetchAllViewConsoleType()
    return consoleSessions.find(session => session.roomUuid === roomUuid && viewConsoleList.includes(session.connectionType))
}

export const checkIfEmeraldGoingOn = (consoleSessions: IConsoleSession[]) => {
    return consoleSessions.findIndex(session => session.connectionMode === EConnectionMode.EMERALD) > -1
}

export const convertConsoleSessionToTransaction = (consoleSessions: IConsoleSession, groupId: string) => {
    const { roomUuid, connectionType, receiverName, connectionMode, contextId } = consoleSessions
    const transaction: IConsoleTransaction = {
        transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType, connectionMode, transactionId: generateUniqueId(),
        connectionStatus: TransactionValue.DISCONNECTING, receiverName, contextId, groupId,
    }
    return transaction
}

export const fetchActiveTransactionIndex = (transactions: IConsoleTransaction[]) => (
    transactions.findIndex(transaction => transaction.transactionStatus === ETransactionStatus.RUNNING)
)

export const fetchActiveSession = (consoleSessions: IConsoleSession[], roomUuid: string) => {
    return consoleSessions.find(session => session.roomUuid === roomUuid)
}

export const checkIfAnyActiveTransaction = (transactions: IConsoleTransaction[]) => {
    return transactions.findIndex(transaction => transaction.transactionStatus === ETransactionStatus.RUNNING) > -1
}

export const fetchFirstWaitingTransactionIndex = (transactions: IConsoleTransaction[]) => {
    return transactions.findIndex(transaction => transaction.transactionStatus === ETransactionStatus.WAITING)
}

export const fetchActiveTransactionForRoomAndConnectionType = (transactions: IConsoleTransaction[], roomUuid: string, connectionType: EConnectionType) => {
    return transactions.find(
        transaction => transaction.roomUuid === roomUuid &&
            transaction.connectionType === connectionType &&
            transaction.transactionStatus !== ETransactionStatus.FINISHED)
}

export const fetchTransactionForRoomAndStatus = (transactions: IConsoleTransaction[], roomUuid: string, status: ETransactionStatus) => {
    return transactions.find(
        transaction => transaction.roomUuid === roomUuid &&
            transaction.transactionStatus === status)
}

export const fetchTransactionForSpecificState = (transactions: IConsoleTransaction[], transactionType: TransactionValue, connectionType: EConnectionType) => {
    return transactions.find(
        transaction => transaction.connectionStatus === transactionType &&
            transaction.connectionType === connectionType)
}

export const fetchTransactionForStatus = (transactions: IConsoleTransaction[], transactionType: TransactionValue, status: ETransactionStatus) => {
    return transactions.find(
        transaction => transaction.connectionStatus === transactionType &&
            transaction.transactionStatus === status)
}

export const fetchTransactionIndexForStatus = (transactions: IConsoleTransaction[], transactionType: TransactionValue, status: ETransactionStatus) => {
    return transactions.findIndex(
        transaction => transaction.connectionStatus === transactionType &&
            transaction.transactionStatus === status)
}

export const fetchTransactionIndexForState = (transactions: IConsoleTransaction[], status: ETransactionStatus) => {
    return transactions.findIndex(
        transaction => transaction.transactionStatus === status)
}

export const generateUniqueId = () => Math.random().toString(32).substr(2, 9)

export const generateTransactionObject = (
    roomUuid: string, connectionType: EConnectionType, connectionMode: EConnectionMode,
    connectionStatus: TransactionValue, receiverName: string, groupId: string, contextId?: string
) => ({
    transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType, connectionMode, connectionStatus, receiverName, transactionId: generateUniqueId(), contextId, groupId,
})

export const checkIfOperationIsFailed = (operationStatus: EOperationStatus) => {
    return ([EOperationStatus.FAILED, EOperationStatus.CANCELLED, EOperationStatus.TIMEOUT] as EOperationStatus[]).includes(operationStatus)
}

export const fetchTransactionIndexById = (transactions: IConsoleTransaction[], transactionId: string) => {
    return transactions.findIndex(transaction => transaction.transactionId === transactionId)
}

export const getCallContextByContactUuid = (contactUuid: string) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().externalReducer.callDetails
    return getCallsWithParticipant(contactUuid, [...onHoldCallDetails, connectedCallDetails])
}

export const checkIfCallIsGoingOn = (isCallWaitTransaction: boolean, transactions: IConsoleTransaction[], roomUuid: string) => {
    return (
        isCallWaitTransaction ||
        hasActiveVidoCallWithRoom(roomUuid) ||
        fetchTransactionForStatus(transactions, TransactionValue.AV_CALL_WAIT, ETransactionStatus.WAITING)
    )
}

export const getCallsWithParticipant = (participantUuid: string, avCallDetails: IAVCallDetails[]) => {
    return avCallDetails.find(callDetails => callDetails.participants.some(participant => participant.uuid === participantUuid))
}

export const checkIfParticipantPartOfCall = (callDetails: IAVCallDetails, participantUuid: string) => {
    return !!callDetails.participants.find(participant => participant.uuid === participantUuid)
}

export const fetchCallContextForRoomUuid = (roomUuid: string) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().externalReducer.callDetails
    return [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.participants.some(participant => participant.uuid === roomUuid))
}

export const fetchCallDetailsByContextId = (contextId: string) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().externalReducer.callDetails
    return [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
}

export const hasActiveVidoCallWithRoom = (roomUuid: string) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().externalReducer.callDetails
    const participants: IParticipantInfo[] = [];
    [...onHoldCallDetails, connectedCallDetails].forEach(callDetails => { participants.push(...callDetails.participants) })
    return participants.length && !!participants.find(participant => participant.uuid === roomUuid && participant.callStatus === CALL_ACCEPT)
}

export const hasActivTransactionForRoom = (roomUuid: string) => {
    const { transactions } = store.getState().consoleReducer.consoleOperation
    return !!transactions.find(transaction => transaction.roomUuid === roomUuid)
}

export const displayErrorModal = (message?: string, isHeaderRequired: boolean = true) => {
    const { intl } = getIntlProvider()
    const notificationModal = {
        showModal: true,
        header: isHeaderRequired ? errorModalHeader() : "",
        modalContent: message || intl.formatMessage({ id: "content.consoleMessages.consoleInternalServerError", defaultMessage: en["content.consoleMessages.consoleInternalServerError"] }),
        modalStyles: "errorModal",
        actionButton1Text: intl.formatMessage({ id: "content.ok.btn", defaultMessage: en["content.ok.btn"] }),
        actionButton1Onclick: hideNotificationModal
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

export const requestRejectModal = (roomDetails:any) => {
    const { intl } = getIntlProvider()
    const rejectDescription= intl.formatMessage({ id: "content.requestRejectModal.description", defaultMessage: en["content.requestRejectModal.description"] })
    const at= intl.formatMessage({ id: "content.banner.at", defaultMessage: en["content.banner.at"] })
    const into= intl.formatMessage({ id: "content.banner.in", defaultMessage: en["content.banner.in"] })

    const notificationModal = {
        showModal: true,
        header: requestRejectModalHeader(),
        modalContent: `${rejectDescription} ${roomDetails.name} ${at} ${roomDetails.address} ${into} ${roomDetails.location}`,
        modalStyles: "rejectModal",
        actionButton1Text: intl.formatMessage({ id: "content.ok.btn", defaultMessage: en["content.ok.btn"] }),
        actionButton1Onclick: hideNotificationModal
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

interface IDisplayNotificationModal {
    header: string | JSX.Element
    modalContent: string | JSX.Element
    onStartClick: () => void
    onStopClick?: () => void
    actionButton1Text?: string
    actionButton2Text?: string
    buttonDirection?: EButtonDirection

}
export const displayNotificationModal = (props: IDisplayNotificationModal) => {
    const { intl } = getIntlProvider()
    const { header, modalContent, actionButton1Text, actionButton2Text, onStartClick, buttonDirection } = props
    const notificationModal = {
        showModal: true,
        header,
        modalContent,
        actionButton1Text: actionButton1Text || intl.formatMessage({ id: "content.ok.btn", defaultMessage: en["content.ok.btn"] }),
        actionButton2Text: actionButton2Text || intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
        buttonDirection: buttonDirection || EButtonDirection.RIGHT,
        actionButton1Onclick: onStartClick
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

export const hideNotificationModal = () => {
    sendLogsToAzure({ contextData: { component: "NotificationModal", event: `Close modal`, Event_by: currentUser.uuid } })
    const notificationModal = { showModal: false }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

export const displayNotificationMessage = (message: IMessage[], customStyle: any, isWarning?: boolean, isNotification?: boolean, isSuccess?: boolean, hideIcon?: boolean) => {
    const notificationMessage = {
        show: true,
        hideIcon: !hideIcon && !true,
        closeMessage: {},
        isSuccess: isSuccess || false,
        isWarning: isWarning || false,
        isNotification: isNotification || false,
        fixed: false,
        timeOut: 3000,
        showNotification: true,
        message: message,
        customStyle: customStyle
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MESSAGE, payload: { notificationMessage: notificationMessage } })
}

interface IRoomSwitchMessage {
    activeSession: IConsoleSession
    activeSessionRoomName: string
    currentConnectionType: EConnectionType
    currentRoomName: string
    intl: ReactIntl.InjectedIntl
}
export const getRoomSwitchMessage = (props: IRoomSwitchMessage) => {
    const { activeSession, activeSessionRoomName, currentConnectionType, currentRoomName, intl } = props
    const viewing = `${intl.formatMessage({ id: "content.banner.viewing", defaultMessage: en["content.banner.viewing"] })}`
    const editing = `${intl.formatMessage({ id: "content.banner.editing", defaultMessage: en["content.banner.editing"] })}`
    return `${intl.formatMessage({
        id: "content.consoleMessages.confirmMessageForViewConsolePart1",
        defaultMessage: en["content.consoleMessages.confirmMessageForViewConsolePart1"]
    })} ${activeSession.connectionType === EConnectionType.FULL_CONTROL ? editing : viewing} <b>${activeSessionRoomName}</b>${intl.formatMessage({
        id: "content.consoleMessages.confirmMessageForViewConsolePart2",
        defaultMessage: en["content.consoleMessages.confirmMessageForViewConsolePart2"]
    })} ${currentConnectionType === EConnectionType.FULL_CONTROL ? editing : viewing} <b>${currentRoomName}</b>?`
}

export const fetchConsoleSession = (contexId: string, consoleSessions: IConsoleSession[]) => {
    return consoleSessions.find((session: IConsoleSession) => session.contextId === contexId)
}

export const checkIfMultiRoomIsDisabled = (featureFlags: any, receivers: IReceiver[]) => {
    return receivers.length === 1 || !FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.MULTI_CONSOLE)
}

export const isDev = () => {
    const configs = fetchGlobalConfigs()
    return configs.ROCC_DEV === "true"
}

export const getConsoleSessionByContextId = (consoleId: string, consoleSessions: IConsoleSession[]) => {
    const consoleSession = consoleSessions.find((consoleSession: IConsoleSession) => consoleSession.contextId === consoleId)
    return consoleSession
}

export const checkForProtocolTransferConnection = () => {
    const state = store.getState()
    const { consoleSessions } = state.consoleReducer
    const { FULL_CONTROL_USB } = EConnectionType
    const checkEditSession = consoleSessions.find((consoleSession: any) => consoleSession.connectionType === FULL_CONTROL_USB)
    return checkEditSession
}

export const checkIfCleanUpTaskInProgress = (consoleOperation: IConsoleOperation) => {
    const { operationStatus, transactions } = consoleOperation
    if (operationStatus === EOperationStatus.IDLE) return false
    return !!transactions.find(transaction => transaction.connectionStatus === TransactionValue.DISCONNECTING_ALL)
}

export const fetchAllDecinedCallList = (videoCallStatus: ICallStatus[]) => {
    const { CALLDECLINED, CALLREJECT, NOT_ANSWERED } = ECallStatus
    return videoCallStatus.filter(callStatus => [CALLDECLINED, CALLREJECT, NOT_ANSWERED].includes(callStatus.callStatus))
}

export const checkForConnectedCall = (videoCallStatus: ICallStatus[]) => (
    videoCallStatus.filter(callStatus => callStatus.callStatus === ECallStatus.CONNECTED)
)

export const checkCallStatus = (videoCallStatus: ICallStatus[], roomUuid: string) => {
    /**
     * 1. Check if any failed Call status
     * 2. Check if any Rejected or cancelled call status
     * 3. Check for connected call status
     */
    if (videoCallStatus.length === 1 && videoCallStatus[0].callStatus === ECallStatus.FAILED) {
        return ETransactionStatus.FAILED
    }
    const declinedCalls = fetchAllDecinedCallList(videoCallStatus)
    if (declinedCalls.length && checkIfParticipantCallDeclined(roomUuid)) {
        return ETransactionStatus.STOP
    }
    if (checkForConnectedCall(videoCallStatus) && checkForParticipantpartOfCall(roomUuid)) {
        return ETransactionStatus.FINISHED
    }
    return
}

const checkIfParticipantCallDeclined = (roomUuid: string) => {
    const gState = globalStore.GetGlobalState()
    if (gState[CALLING_APP]) {
        const { participant } = gState[CALLING_APP].callReducer.callDetails.outgoingCall
        return participant.uuid === roomUuid
    }
    return
}

export const checkForParticipantpartOfCall = (roomUuid: string) => {
    const gState = globalStore.GetGlobalState()
    if (gState[CALLING_APP]) {
        const { participants } = gState[CALLING_APP].callReducer.callDetails.connectedCallDetails
        return !!participants.find((participant: any) => participant.uuid === roomUuid)
    }
    return
}

export const displayEditToViewSwitchMessage = () => {
    const customStyle = { top: "1rem", right: "1rem", width: "29.25rem" }
    const message = messageEditToView()
    displayNotificationMessage(message, customStyle, false, true, false)
}

export const messageEditToView = () => {
    const { intl } = getIntlProvider()
    return [{
        header: intl.formatMessage({
            id: "content.notificationMessage.switchViewingSessionHeader",
            defaultMessage: en["content.notificationMessage.switchViewingSessionHeader"]
        }),
        content: intl.formatMessage({
            id: "content.notificationMessage.switchViewingSessionMessage",
            defaultMessage: en["content.notificationMessage.switchViewingSessionMessage"]
        }),
    }]
}

export const messageViewToEdit = () => {
    const { intl } = getIntlProvider()
    return [
        {
            header: intl.formatMessage({
                id: "content.notificationMessage.activeViewingSessionHeader",
                defaultMessage: en["content.notificationMessage.activeViewingSessionHeader"]
            }),
            content: `${intl.formatMessage({
                id: "content.notificationMessage.activeViewingSessionMessagePart1",
                defaultMessage: en["content.notificationMessage.activeViewingSessionMessagePart1"]
            })} ${intl.formatMessage({
                id: "content.notificationMessage.activeViewingSessionMessagePart2",
                defaultMessage: en["content.notificationMessage.activeViewingSessionMessagePart2"]
            })}`
        },
        {
            header: intl.formatMessage({
                id: "content.notificationMessage.callingScannerHeader",
                defaultMessage: en["content.notificationMessage.callingScannerHeader"]
            }),
            content: intl.formatMessage({
                id: "content.notificationMessage.callingScannerMessage",
                defaultMessage: en["content.notificationMessage.callingScannerMessage"]
            })
        },
    ]
}

export const isNFCCAllowed = () => {
    const state = store.getState()
    const { MAX_NUM_OF_CONSOLE_SESSION, MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE } = fetchGlobalConfigs()
    const { receivers } = state.consoleReducer.commandCenterDetails.commandCenterSeat

    if (receivers.length && receivers[0].id) {
        if (receivers.length >= parseIntBase10(MAX_NUM_OF_CONSOLE_SESSION) || parseIntBase10(MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE) === 0) {
            return false
        }
    } else if (parseIntBase10(MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE) === 0) {
        return false
    } else {
        // do nothing
    }
    return true
}

export const getActiveSessionConsoleRoom = (rooms: IRoomDetails[], activeSession: IConsoleSession) => {
    return rooms.find((activeSessionConsoleRoomDeatils: IRoomDetails) =>
        activeSessionConsoleRoomDeatils.identity.uuid === activeSession.roomUuid)
}

export const getNFCCMaxlimitMessage = (activeSessions: IConsoleSession[], rooms: IRoomDetails[], currentRoom: IRoomDetails) => {

    const activeNFCCRooms: any = []
    const { intl } = getIntlProvider()

    activeSessions.forEach(activeSession => {
        if (activeSession.connectionMode === EConnectionMode.EMERALD) {
            const activeSessionConsoleRoom = getActiveSessionConsoleRoom(rooms, activeSession)
            const activeSessionConsoleRoomName = activeSessionConsoleRoom ? activeSessionConsoleRoom.identity.name : ""
            const activeSessionConsoleRoomAddress = activeSessionConsoleRoom ? activeSessionConsoleRoom.address : ""
            const nameAndAddress = `<b class="boldText">${activeSessionConsoleRoomName} - ${activeSessionConsoleRoomAddress}</b>`
            activeNFCCRooms.push(nameAndAddress)
        }
    })

    const currentRoomName = currentRoom ? currentRoom.identity.name : ""
    const currentRoomAddress = currentRoom ? currentRoom.address : ""
    const newNameAndAddress = `<b class="boldText">${currentRoomName} - ${currentRoomAddress}</b>`

    return `${intl.formatMessage({ id: "content.consoleMessages.maxNFCCLimitReached1", defaultMessage: en["content.consoleMessages.maxNFCCLimitReached1"] })}
        ${activeNFCCRooms.join(intl.formatMessage({ id: "content.consoleMessages.maxNFCCLimitReached2", defaultMessage: en["content.consoleMessages.maxNFCCLimitReached2"] }))}
        ${intl.formatMessage({ id: "content.consoleMessages.maxNFCCLimitReached3", defaultMessage: en["content.consoleMessages.maxNFCCLimitReached3"] })}
        ${newNameAndAddress}
    `
}

export const isNonCommandCenterViewConnection = (currentSession: IConsoleSession, roomUuid: string) => {
    return currentSession.roomUuid === roomUuid && ([EConnectionMode.EMERALD, EConnectionMode.RDP, EConnectionMode.VNC].includes(currentSession.connectionMode) && currentSession.connectionType === EConnectionType.VIEW)
}

export const isQualifyCheckBoxChecked = (roomUuid: string) => {
    const allRooms = fetchRooms()
    const currentRoom = allRooms.find((room: any) => room.identity.uuid === roomUuid)
    return currentRoom && currentRoom.additionalAttributes && currentRoom.additionalAttributes.ncc_edit === false && currentRoom.additionalAttributes.is_ncc_warning_displayed
}

export const updateSpokeQualifiedCheckboxStatus = async (roomDetails: IRoomDetails, checked: boolean) => {
    const apiStatus = await spokeNotQualifiedService(roomDetails, checked)
    if (apiStatus) {
        const rooms = fetchRooms()
        rooms.forEach((room: IRoomDetails) => {
            if (room.identity.uuid === roomDetails.identity.uuid) {
                room.additionalAttributes.is_ncc_warning_displayed = checked
            }
        })
        dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms } })
    }
    sendLogsToAzure({ contextData: { component: CONTROL_CONSOLE, event: `${transformSessionTypeForAnalytics(EConnectionMode.EMERALD)} not qualified 'do not show' checkbox (checked) : ${checked}`, source: transformSessionTypeForAnalytics(EConnectionMode.EMERALD), eventBy: currentUser.uuid, Call_To: roomDetails.identity.uuid, Call_From: currentUser.uuid, windowType: "popup" } })
}

export const fetchActiveSessionToBeDisconnected = (consoleSessions: IConsoleSession[], receiverName: string, roomUuid: string, connectionMode: EConnectionMode) => {
    const maxNfccConnectionLimit = getMaxNumAllowedNFCC()
    let isActiveSessionWithSameRoom = false
    let activeEmeraldConnection: any = undefined
    const activeTransactionToDisconnect: IConsoleTransaction[] = []
    consoleSessions.forEach(session => {
        const { connectionType } = session
        let returnValue = false
        if (session.roomUuid === roomUuid) {
            isActiveSessionWithSameRoom = true
            returnValue = true
        } else if (
            receiverName && session.receiverName === receiverName ||
            (connectionMode == EConnectionMode.EMERALD && maxNfccConnectionLimit === 1 && session.connectionMode === connectionMode)
        ) {
            returnValue = true
        } else {/** Sonar issue */ }
        if (returnValue) {
            const groupId = generateUniqueId()
            activeTransactionToDisconnect.push(convertConsoleSessionToTransaction(session, groupId))
            if (!activeEmeraldConnection && session.connectionMode === EConnectionMode.EMERALD) {
                activeEmeraldConnection = generateTransactionObject(roomUuid, connectionType, session.connectionMode, TransactionValue.STOP_EMERALD_APP, "", groupId, session.contextId)
                activeTransactionToDisconnect.push(activeEmeraldConnection)
            }
        }
    })
    return { activeTransactionToDisconnect, isActiveSessionWithSameRoom }
}

export const checkTransactionForRoomAndState = (transactions: IConsoleTransaction[], roomUuid: string, connectionStates: TransactionValue[], transactionState: ETransactionStatus) => {
    return !!transactions.find(transaction =>
        transaction.roomUuid === roomUuid && connectionStates.includes(transaction.connectionStatus)
        && transaction.transactionStatus === transactionState)

}

export const getRoomInfoFromUuid = (rooms: IRoomInfo[], roomUuid: string) => {
    return rooms.find(room => room.roomUuid === roomUuid) || { ...INIT_ROOM_INFO }
}

export const getSpokeMessage = (permissions: any, initialized: ECommandCenterAccessMode) => {
    const { intl } = getIntlProvider()
    return !!permissions.CONSOLE_EDIT && initialized === ECommandCenterAccessMode.WITH_HARDWARE ? `${intl.formatMessage({ id: "content.consoleMessages.qualifyEditingNote1", defaultMessage: en["content.consoleMessages.qualifyEditingNote1"] })}
     ${intl.formatMessage({ id: "content.consoleMessages.qualifyEditingNote2", defaultMessage: en["content.consoleMessages.qualifyEditingNote2"] })}`
        : `${intl.formatMessage({ id: "content.consoleMessages.qualifyEditingNote1", defaultMessage: en["content.consoleMessages.qualifyEditingNote1"] })}.`

}

export const isCommandCenterConnection = (activeSessions: IConsoleSession[], roomId: string) => {
    return getRoomConnectionMode(activeSessions, roomId) === EConnectionMode.CC
}

export const getRoomConnectionMode = (activeSessions: IConsoleSession[], roomId: string) => {
    const activeSession = getRoomConnection(activeSessions, roomId)

    return activeSession ? activeSession.connectionMode : false
}

export const getRoomConnection = (activeSessions: IConsoleSession[], roomId: string) => {
    for (const activeSession of activeSessions) {
        if (activeSession.roomUuid === roomId) {
            return activeSession
        }
    }
    return false
}

export const isRoomMonitoringEnabled = (featureFlags: any) => {
    return FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_ROOM_MONITORING)
}

export const getRoomDetails = (activeSession: IConsoleSession) => {
    const rooms = fetchRooms()
    const locations = fetchLocations()
    const roomDetails = {
        name: "",
        address: "",
        location: "",
        modality: ""
    }
    const activeRoom = getRoomDetailFromUuid(rooms, activeSession.roomUuid)
    roomDetails.name = activeRoom.identity.name
    roomDetails.address = activeRoom.address
    roomDetails.location = getLocationDetailsForId(locations, activeRoom.locationId).name
    roomDetails.modality = activeRoom.modality
    return roomDetails
}

export const getActionFromWorkflowType = (workflowType: ERoccWorkflow) => {
    const {
        MULTI_EDIT_INITIATE_CALL, MULTI_EDIT_START_EDITING, PARK_AND_INITIATE_CALL,
        PARK_AND_START_EDITING, PARK_AND_RESUME, DISCONNECT_CALL, DISCONNECT_CONSOLE_SESSION
    } = ERoccWorkflow
    switch (workflowType) {
        case MULTI_EDIT_INITIATE_CALL:
        case PARK_AND_INITIATE_CALL:
            return EMultiSessionModalNextAction.INITIATE_CALL
        case MULTI_EDIT_START_EDITING:
        case PARK_AND_START_EDITING:
            return EMultiSessionModalNextAction.INITIATE_SESSION
        case PARK_AND_RESUME:
            return EMultiSessionModalNextAction.RESUME_SESSION
        case DISCONNECT_CALL:
            return EMultiSessionModalNextAction.DISCONNECT_CALL
        case DISCONNECT_CONSOLE_SESSION:
            return EMultiSessionModalNextAction.DISCONNECT_SESSION
        default:
            // TODO: Define better default
            return EMultiSessionModalNextAction.INITIATE_SESSION
    }
}

export const fetchCCTVProps = () => {
    const state = store.getState()
    const { consoleSessions } = state.consoleReducer
    const { currentUser, rooms } = state.externalReducer
    return { consoleSessions, currentUser, rooms }
}

export const getRoomUuidsFromWorkflowContext = (workflowContext: IWorkflowInfo["state"]["context"]) => {
    const state = store.getState()
    const { consoleSessions } = state.consoleReducer
    const { connectedCallDetails, onHoldCallDetails } = state.externalReducer.callDetails

    const contactUuids: string[] = []

    if ("nextSessionDetails" in workflowContext) {
        const { prevSessionDetails, nextSessionDetails } = workflowContext as ParkAndInitiateCallContext | ParkAndStartEditingContext | ParkAndResumeContext | MultiEditInitiateCallContext | MultiEditStartEditingContext
        contactUuids.push(prevSessionDetails?.contactUuid, nextSessionDetails?.contactUuid)
    } else {
        if ("contactUuid" in workflowContext) {
            contactUuids.push((workflowContext as DisconnectConsoleSessionContext).contactUuid)
        } else if ("callContextId" in workflowContext) {
            const contactUuidFromConsole = consoleSessions.find(
                (consoleSession: IConsoleSession) => consoleSession.additionalData?.callContextId === workflowContext.callContextId
            )?.roomUuid
            if (contactUuidFromConsole) {
                contactUuids.push(contactUuidFromConsole)
            } else {
                const contactUuidsFromCall = [connectedCallDetails, ...onHoldCallDetails].find(
                    (callDetails: IAVCallDetails) => callDetails.contextId === workflowContext.callContextId
                )?.participants.map(
                    (participant: IParticipantInfo) => participant.uuid
                )

                if (contactUuidsFromCall?.length) {
                    contactUuids.push(...contactUuidsFromCall)
                }
            }
        }
    }

    return contactUuids
}

export const isRoomMonitoringEnabledForCC = (featureFlags: any, currentSession: IConsoleSession) => {
    const { CC } = EConnectionMode
    return isRoomMonitoringEnabled(featureFlags) && currentSession.connectionMode === CC
}

export const getCurrentRoom = (roomUuid: string, rooms: IRoomInfo[]) => {
    const roomDetails = rooms.find((room: IRoomInfo) => room.roomUuid === roomUuid)
    return roomDetails ? roomDetails : INIT_ROOM_INFO
}

export const getAnywhereLocationNameText = () => {
    const { intl } = getIntlProvider()
    return intl.formatMessage({ id: "content.locations.anywhere", defaultMessage: en["content.locations.anywhere"] })
}
