# Changelog

## [1.1.3](https://github.com/philips-internal/rocc-console-app/compare/1.1.2...1.1.3) (2022-11-07)


### Bug Fixes

* enable master stability check all prs ([1bc4846](https://github.com/philips-internal/rocc-console-app/commit/1bc484614cd9c7ab59aee702fc1bc96390cdc62e))

## [1.1.2](https://github.com/philips-internal/rocc-console-app/compare/1.1.1...1.1.2) (2022-11-07)


### Bug Fixes

* pm edit not starting ([7ad7ded](https://github.com/philips-internal/rocc-console-app/commit/7ad7dedfe76a382b30dee7013da5ed380a50fb07))

## [1.1.1](https://github.com/philips-internal/rocc-console-app/compare/1.1.0...1.1.1) (2022-11-04)


### Bug Fixes

* view authorization workflow changes ([c45a26f](https://github.com/philips-internal/rocc-console-app/commit/c45a26f604a68469de06cd04d65ba46fd1a866f0))

## [1.1.0](https://github.com/philips-internal/rocc-console-app/compare/1.0.9...1.1.0) (2022-10-27)


### Features

* add file saver package ([bf7082e](https://github.com/philips-internal/rocc-console-app/commit/bf7082e9238c92cc1ef496d6f9479a01ede5079a))
* show popup modal to user if nfcc is not installed on user machine ([a1fb436](https://github.com/philips-internal/rocc-console-app/commit/a1fb4363874b036d8f5bab1a63c38df698e08b40))


### Bug Fixes

* show popup if NFCC bundle is not installed ([ee3a39a](https://github.com/philips-internal/rocc-console-app/commit/ee3a39a33710b042f56630bdd2a4566b7045caf1))
* sonar issues ([75044a1](https://github.com/philips-internal/rocc-console-app/commit/75044a1b6c46ae31cb977d4fa2f1629f39a6b85f))
* wrong message in popup button ([f0595b3](https://github.com/philips-internal/rocc-console-app/commit/f0595b3f4761cb4deeed6fa89c098487d111f9d5))

## [1.0.9](https://github.com/philips-internal/rocc-console-app/compare/1.0.8...1.0.9) (2022-10-03)


### Bug Fixes

* sample commit for auto release ([821b795](https://github.com/philips-internal/rocc-console-app/commit/821b7952aa8c8e61ceabcafaaf01bb9c5b28cd32))

## [1.0.8](https://github.com/philips-internal/rocc-console-app/compare/1.0.7...1.0.8) (2022-09-28)


### Bug Fixes

* sample commit to fix SL reference build ([9ad2852](https://github.com/philips-internal/rocc-console-app/commit/9ad28521cb9a4051438b16e5d290a6ab04497aa0))
* sample commit to release new version ([0e9653e](https://github.com/philips-internal/rocc-console-app/commit/0e9653e1a20557faf05bef45750a21b3695792c2))

## [1.0.7](https://github.com/philips-internal/rocc-console-app/compare/1.0.6...1.0.7) (2022-09-26)


### Bug Fixes

* sample commit for enabling autoversioning ([bb33bbc](https://github.com/philips-internal/rocc-console-app/commit/bb33bbc2bd80a26afeb10fc9719f36a7ee976cf0))

## [1.0.6](https://github.com/philips-internal/rocc-console-app/compare/1.0.5...1.0.6) (2022-09-22)


### Bug Fixes

* updated logic when user logged in ([946b2bb](https://github.com/philips-internal/rocc-console-app/commit/946b2bb33793b824d2a5ccc8d4fc37374911be46))
* updated logic when user logged in ([29b4461](https://github.com/philips-internal/rocc-console-app/commit/29b446139dc0927aa985bb3029143bb362834722))

## [1.0.5](https://github.com/philips-internal/rocc-console-app/compare/v1.0.4...1.0.5) (2022-09-12)


### Bug Fixes

* remove prefix v from version ([5d880f7](https://github.com/philips-internal/rocc-console-app/commit/5d880f7f9c561af356361aeda51cb2e4e1f66048))

## [1.0.4](https://github.com/philips-internal/rocc-console-app/compare/v1.0.3...v1.0.4) (2022-09-08)


### Bug Fixes

* enable autoversioing from octopus ([3bd4248](https://github.com/philips-internal/rocc-console-app/commit/3bd42482f34a7813e9f6550c4200ca7398416b1b))
