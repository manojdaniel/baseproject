import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { Excel } from "antd-table-saveas-excel";
import "../../../assets/common/CommonTables.scss";
import "../alertmanagement-table.scss";

interface Props {
	data: any[];
	handleClick: any;
	loading: any;
}
const ReportTable = ({ data, handleClick, loading }: Props) => {
	// Time Formate work :Start
	const [report, setReport] = useState<any>();
	useEffect(() => {
		let mydata = data.map(function (item: any) {
			return {
				AlertID: item.alertID,
				Affiliate: item.affiliate,
				Plant: item.plant,
				TimeStamp: item.timeStamp,
				AssetID: item.assetID,
				AssetDescription: item.assetDescription,
				AnomolyType: item.anomalyType,
				// AssetName: item.assetName,
				KeyIdentifierSensor1: item.keyIdentifiedSensor1,
				KeyIdentifierSensor2: item.keyIdentifiedSensor2,
				KeyIdentifierSensor3: item.keyIdentifiedSensor3,
				KeyIdentifierSensor4: item.keyIdentifiedSensor4,
				KeyIdentifierSensor5: item.keyIdentifiedSensor5,
				KeyIdentifierSensor6: item.keyIdentifiedSensor6,
				CurrentStage: item.currentStage,
				AssignedToDepart: item.assignedTo,
				AssignedToUser: item.assignedToUser,
				Status: item.status,
				AlertClass: item.alertClass,
				LongLeadAction: item.requireLeadAction,
				View: (
					<div
						className="cus-button"
						onClick={() => handleClick(item.alertID, item.currentStage)}
					>
						View
					</div>
				),
			};
		});
		setReport(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "ALERT ID",
			dataIndex: "AlertID",
			key: "AlertID",
			width: 80,
		},
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: 80,
		},
		{
			title: "PLANT",
			dataIndex: "Plant",
			key: "Plant",
			width: 80,
		},
		{
			title: "TIMESTAMP",
			dataIndex: "TimeStamp",
			key: "TimeStamp",
			width: 100,
		},
		{
			title: "ASSET ID ",
			dataIndex: "AssetID",
			key: "AssetID",
			width: 90,
		},
		{
			title: "ASSET DESCRIPTION ",
			dataIndex: "AssetDescription",
			key: "AssetDescription",
			width: 160,
		},
		{
			title: "ANOMOLY TYPE",
			dataIndex: "AnomolyType",
			key: "AnomolyType",
			width: 130,
		},
		// {
		// 	title: "ASSET NAME",
		// 	dataIndex: "AssetName",
		// 	key: "AssetName",
		// 	width: 150,
		// },
		{
			title: "KEY IDENTIFIED SENSOR",
			width: 600,
			children: [
				{
					title: "1",
					dataIndex: "KeyIdentifierSensor1",
					key: "KeyIdentifierSensor1",
					width: 100,
				},
				{
					title: "2",
					dataIndex: "KeyIdentifierSensor2",
					key: "KeyIdentifierSensor2",
					width: 100,
				},
				{
					title: "3",
					dataIndex: "KeyIdentifierSensor3",
					key: "KeyIdentifierSensor3",
					width: 100,
				},
				{
					title: "4",
					dataIndex: "KeyIdentifierSensor4",
					key: "KeyIdentifierSensor4",
					width: 100,
				},
				{
					title: "5",
					dataIndex: "KeyIdentifierSensor5",
					key: "KeyIdentifierSensor5",
					width: 100,
				},
				{
					title: "6",
					dataIndex: "KeyIdentifierSensor6",
					key: "KeyIdentifierSensor6",
					width: 100,
				},
			]
		},
		{
			title: "CURRENT STAGE",
			dataIndex: "CurrentStage",
			key: "CurrentStage",
			width: 120,
		},
		{
			title: "ASSIGNED TO DEPART",
			dataIndex: "AssignedToDepart",
			key: "AssignedToDepart",
			width: 150,
		},
		{
			title: "ASSIGNED TO USER",
			dataIndex: "AssignedToUser",
			key: "AssignedToUser",
			width: 150,
		},
		{
			title: "STATUS",
			dataIndex: "Status",
			key: "Status",
			width: 90,
		},
		{
			title: "ALERT CLASS",
			dataIndex: "AlertClass",
			key: "AlertClass",
			width: 90,
		},
		{
			title: "LONG LEAD ACTION",
			dataIndex: "LongLeadAction",
			key: "LongLeadAction",
			width: 60,
		},
		{
			title: "VIEW",
			dataIndex: "View",
			key: "View",
			width: 100,
		},
	];
	//ReportTableExcel: Start=============
	const handleClickReport = () => {
		const excel = new Excel();
		excel
			.addSheet("test")
			.addColumns(columns)
			.addDataSource(report, {
				str2Percent: true,
			})
			.saveAs("ReportTableExcel.xlsx");
	};

	return (
		<div id="ahcreport-table">
			<button
				className="alerttablebuttons"
				onClick={handleClickReport}
				style={{ display: "none" }}
				id="handleClickReport"
			>
				EXPORT TO EXCEL
			</button>
			<Table
				columns={columns}
				dataSource={report}
				pagination={{ pageSize: 2, showSizeChanger: false }}
				loading={loading}
				scroll={{ x: '100vw', y: 300 }}
			/>
		</div>
	);
};

export default ReportTable;
