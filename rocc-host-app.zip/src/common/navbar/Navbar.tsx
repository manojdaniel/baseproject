/*
 * Created on Fri June 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { NavBar } from "@dls-pdv/semantic-react-components"
import { EAppContext, ECallStatus, EClinicalRole, EConnectionType, FeatureFlagHelper, ICallStatus, IConsoleSession, IMissedCallData, IParentStore, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React, { useCallback, useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Icon } from "semantic-ui-react"
import { APP_NAME, CALLING_APP_STORE, CALL_ICON_INDEX, CONSOLE_APP_STORE, HELP_DROPDOWN_INDEX, PROTOCOL_TRANSFER_ICON_INDEX, SUPPORT_ICON_INDEX, CONFIG_WITHOUT_HARDWARE, SETTINGS_ICON_INDEX, LIVE_VIDEO_INDEX, CCTV_WINDOW_CLOSE, RAD_CONNECT_APP_TITLE, DROPDOWN_TYPE } from "../../constants/constants"
import { ADMIN_ROUTE, CONSULTS_ROUTE, PHARMA_ROUTE, SCHEDULING_ROUTE } from "../../constants/routes"
import { TRACK } from "../../constants/tracking"
import globalStore from "../../redux/store/globalStore"
import syncSessions from "../../redux/store/syncSessions"
import en from "../../resources/translations/en-US"
import { EPhoneIconColor } from "../../types/types"
import { checkIfCallGoingOn } from "../../utility/calling/CallingUtility"
import { checkIfParticularSessionGoingOn, getFullApplicationName, trackEvent } from "../../utility/helpers/helpers"
import { PrototypeBanner } from "../prototype-banner/PrototypeBanner"
import { cctvIcon, getHelpDropDownOptions, getHomepageLink, getInitialNavConfig, getInitialNavConfigForPreSignedContext, handleProtocolTransferExit, phoneIcon, protocolTransfrIcon, secondaryTopMenuLink, settingsIcon, supportIcon } from "./NavBarHelper"


interface INavBar {
	userName: string
	phoneIconCallBack: () => void
	aboutClick: () => void
	showNfccDownload?: boolean
	phoneCallStatus: ECallStatus
	videoCallStatus: ICallStatus[]
	consoleSessions: IConsoleSession[]
	isTechAppDownloadAvailable: boolean
}

const Navbar = (props: INavBar) => {

	const { userName, showNfccDownload, phoneCallStatus, videoCallStatus, consoleSessions, phoneIconCallBack, aboutClick, isTechAppDownloadAvailable } = props
	const [protocolTransferState, setProtocolTransferState] = useState("")

	const { intl } = getIntlProvider()
	const dispatch = useDispatch()
	const gState = globalStore.GetGlobalState()

	const adminText = intl.formatMessage({ id: "content.link.admin", defaultMessage: en["content.link.admin"] })
	const schedulingText = intl.formatMessage({ id: "content.link.scheduling", defaultMessage: en["content.link.scheduling"] })
	const consultsText = intl.formatMessage({ id: "content.link.consults", defaultMessage: en["content.link.consults"] })
	const pharmaText = intl.formatMessage({ id: "content.link.pharma", defaultMessage: en["content.link.pharma"] })
	const logoutText = intl.formatMessage({ id: "content.logout.list", defaultMessage: en["content.logout.list"] })


	const { featureFlags, permissions, currentUser, nfccUpgradeAvailable, appContext } = useSelector((state: IParentStore) => ({
		featureFlags: state.featureFlagsReducer.featureFlags,
		permissions: state.userReducer.permissions,
		currentUser: state.userReducer.currentUser,
		nfccUpgradeAvailable: state.appReducer.nfccUpgradeAvailable,
		appContext: state.appReducer.appContext,
	}))

	const [consoleStoreSubscribed, setConsoleStoreSubscribed] = useState(false)
	const [callingStoreSubscribed, setCallingStoreSubscribed] = useState(false)
	const [missedCalls, setMissedCalls] = useState([] as IMissedCallData[])
	const [transactions, setTransactions] = useState([])
	const [protocolTransferStatus, setProtocolTransferStatus] = useState(false)
	const [protocolTransferStep, setProtocolTransferStep] = useState(0)
	const [selectedSource, setSelectedSource] = useState({} as any)
	const [selectedDestination, setSelectedDestination] = useState({} as any)
	const [cctvWindow, setCctvWindow] = useState(false)
	const protocolTransferStatusRef = useRef(protocolTransferStatus)
	const { allRoles } = currentUser
	const isAdminOnly = allRoles.length === 1 && allRoles[0] === EClinicalRole.ADMIN

	const [count, setCount] = useState(0)
	const [callIconColor, setCallIconColor] = useState(EPhoneIconColor.WHITE)
	const initNavConfig = getInitialNavConfig({
		cctvWindow: cctvWindow,
		phoneIconColor: callIconColor,
		logoutText,
		protocolTransferStatus: protocolTransferStatusRef.current,
		count,
		showNfccDownload: !!showNfccDownload,
		phoneIconCallBack,
		dispatch,
		aboutClick,
		isAdminOnly,
		isTechAppDownloadAvailable
	})
	const [navConfig, setNavConfig] = useState(initNavConfig)
	const preSignedContextNavConfig = getInitialNavConfigForPreSignedContext({
		cctvWindow: cctvWindow,
		phoneIconColor: callIconColor,
		logoutText,
		protocolTransferStatus: protocolTransferStatusRef.current,
		count,
		showNfccDownload: !!showNfccDownload,
		phoneIconCallBack,
		dispatch,
		aboutClick,
		isAdminOnly,
		isTechAppDownloadAvailable
	})
	const isTechAppDownloadAvailableChange = useRef(isTechAppDownloadAvailable)
	const isRadconnectEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_RADCONNECT)

	const { VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT, INCOGNITO_VIEW } = EConnectionType
	const { ADMIN } = EClinicalRole

	const computeBadgeCount = useCallback(() => {
		let mCount = 0
		missedCalls.forEach((item: any) => {
			if (!item.seen) {
				mCount = mCount + 1
			}
		})
		if (count !== mCount) {
			setCount(mCount)
		}
	}, [missedCalls])

	const contructRadconnectRelatedNavConfig = (featureFlags: any, navConfig: any) => {

		if (isRadconnectEnabled) {
			/* Change title to RadConnect */
			document.title = "RadConnect"
			/* remove call, message and settings icon */
			navConfig.iconMenuItems[SETTINGS_ICON_INDEX].items.pop()
			navConfig.iconMenuItems[HELP_DROPDOWN_INDEX].items = []
			navConfig.iconMenuItems[HELP_DROPDOWN_INDEX].type = ""
			if (permissions.CALL_WEB_TO_PHONE) {
				if (navConfig.iconMenuItems[CALL_ICON_INDEX].items.length === 0) {
					navConfig.iconMenuItems[CALL_ICON_INDEX].items = [phoneIcon(callIconColor, count, phoneIconCallBack, isAdminOnly)]
				}
			}
			else {
				navConfig.iconMenuItems[CALL_ICON_INDEX].items = []
			}
			/* Set application title to Radconnect */
			navConfig.appTitleMenuItems[0].items[0].text = RAD_CONNECT_APP_TITLE
		}
		else {
			navConfig.iconMenuItems[SETTINGS_ICON_INDEX].items.length === 0 && navConfig.iconMenuItems[SETTINGS_ICON_INDEX].items.push(settingsIcon(protocolTransferStatus, dispatch, isAdminOnly, isTechAppDownloadAvailable))
			navConfig.iconMenuItems[CALL_ICON_INDEX].items.length === 0 && navConfig.iconMenuItems[CALL_ICON_INDEX].items.push(phoneIcon(callIconColor, count, phoneIconCallBack, isAdminOnly))
			navConfig.appTitleMenuItems[0].items[0].text = getFullApplicationName()
			navConfig.iconMenuItems[HELP_DROPDOWN_INDEX].items = getHelpDropDownOptions(protocolTransferStatusRef.current, aboutClick, currentUser.allRoles, showNfccDownload ?? false, dispatch)
			navConfig.iconMenuItems[HELP_DROPDOWN_INDEX].type = DROPDOWN_TYPE
		}
	}

	useEffect(() => {
		const subscribeToParentStore = () => {
			if (!consoleStoreSubscribed && gState[CONSOLE_APP_STORE]) {
				setTransactions(gState[CONSOLE_APP_STORE].consoleReducer.consoleOperation.transactions)
				setProtocolTransferStatus(gState[CONSOLE_APP_STORE].protocolTransferReducer.protocolTransferStatus)
				setSelectedSource(gState[CONSOLE_APP_STORE].protocolTransferReducer.selectedSource)
				setSelectedDestination(gState[CONSOLE_APP_STORE].protocolTransferReducer.selectedDestination)
				setProtocolTransferStep(gState[CONSOLE_APP_STORE].protocolTransferReducer.currentStep)
				setProtocolTransferState(gState[CONSOLE_APP_STORE].consoleReducer.commandCenterDetails.initialised)
				globalStore.SubscribeToPartnerState(APP_NAME, CONSOLE_APP_STORE, (changedState: any) => {
					setTransactions(changedState.consoleReducer.consoleOperation.transactions)
					setProtocolTransferStatus(changedState.protocolTransferReducer.protocolTransferStatus)
					setSelectedSource(changedState.protocolTransferReducer.selectedSource)
					setSelectedDestination(changedState.protocolTransferReducer.selectedDestination)
					setProtocolTransferStep(changedState.protocolTransferReducer.currentStep)
					setProtocolTransferState(changedState.consoleReducer.commandCenterDetails.initialised)
				})
				setConsoleStoreSubscribed(true)
			}
			if (!callingStoreSubscribed && gState[CALLING_APP_STORE]) {
				setMissedCalls(gState[CALLING_APP_STORE].callReducer.missedCalls)
				globalStore.SubscribeToPartnerState(APP_NAME, CALLING_APP_STORE, (changedState: any) => {
					setMissedCalls(changedState.callReducer.missedCalls)
				})
				setCallingStoreSubscribed(true)
			}
		}
		subscribeToParentStore()
	}, [gState])

	useEffect(() => {
		syncSessions.onmessage = function (msg: any) {
			if (msg.data.type === CCTV_WINDOW_CLOSE) {
				if (!msg.data.open) {
					setCctvWindow(true)
					const { component, event: { close } } = TRACK.LIVE_VIDEO
					trackEvent(component, close)
				} else {
					setCctvWindow(false)
				}
			}
		}
	}, [syncSessions])


	useEffect(() => {
		const newConfig = navConfig
		if (showNfccDownload && !isRadconnectEnabled) {
			newConfig.iconMenuItems[HELP_DROPDOWN_INDEX].items = getHelpDropDownOptions(protocolTransferStatusRef.current, aboutClick, currentUser.allRoles, showNfccDownload, dispatch)
			newConfig.iconMenuItems[HELP_DROPDOWN_INDEX].icon = <Icon className={`QuestionmarkCircleOutline iconBadge`}>
				{nfccUpgradeAvailable && <span className="badgeContent">{1}</span>}
			</Icon> as any
			setNavConfig({ ...newConfig })
		}
		if (isTechAppDownloadAvailable !== isTechAppDownloadAvailableChange.current && isAdminOnly) {
			isTechAppDownloadAvailableChange.current = isTechAppDownloadAvailable
			if (newConfig.iconMenuItems.length) {
				newConfig.iconMenuItems[SETTINGS_ICON_INDEX].items = [settingsIcon(protocolTransferStatus, dispatch, isAdminOnly, isTechAppDownloadAvailable)]
			}
			setNavConfig({ ...newConfig })
			handleProtocolTransferExit(protocolTransferStatus, dispatch, () => secondaryTopMenuLink(getHomepageLink()))
		}
	}, [showNfccDownload, nfccUpgradeAvailable, isTechAppDownloadAvailable])

	useEffect(() => {
		const newConfig = navConfig
		if (newConfig.iconMenuItems.length > 0) {
			computeBadgeCount()
			checkIfCallGoingOn(phoneCallStatus, videoCallStatus) ? setCallIconColor(EPhoneIconColor.GREEN) : setCallIconColor(EPhoneIconColor.WHITE)
			if (isRadconnectEnabled && !permissions.CALL_WEB_TO_PHONE) {
				newConfig.iconMenuItems[CALL_ICON_INDEX].items = []
			}
			else {
				newConfig.iconMenuItems[CALL_ICON_INDEX].items = [phoneIcon(callIconColor, count, phoneIconCallBack, isAdminOnly)]
			}
			setNavConfig({ ...newConfig })
		}
	}, [phoneCallStatus, videoCallStatus, missedCalls, count, callIconColor])

	useEffect(() => {
		protocolTransferStatusRef.current = protocolTransferStatus

		if (currentUser.onBoarded) {
			const primaryMenu: any = []
			const { component, event: { home, scheduling } } = TRACK.NAV_BAR
			if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_CC_HOME)) {
				primaryMenu.push({
					text: intl.formatMessage({ id: "content.link.home", defaultMessage: en["content.link.home"] }), onClick: () => handleProtocolTransferExit(protocolTransferStatusRef.current, dispatch, () => {
						trackEvent(component, home)
						return secondaryTopMenuLink(getHomepageLink())
					})
				})
			}
			if (isRadconnectEnabled) {
				primaryMenu.push({ text: consultsText, onClick: () => handleProtocolTransferExit(protocolTransferStatusRef.current, dispatch, () => secondaryTopMenuLink(CONSULTS_ROUTE)) })
			}

			if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_PHARMA)) {
				primaryMenu.push({ text: pharmaText, onClick: () => handleProtocolTransferExit(protocolTransferStatusRef.current, dispatch, () => secondaryTopMenuLink(PHARMA_ROUTE)) })
			}

			if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_SCHEDULING_FEATURE)) {
				primaryMenu.push({
					text: schedulingText, onClick: () => handleProtocolTransferExit(protocolTransferStatusRef.current, dispatch, () => {
						trackEvent(component, scheduling)
						return secondaryTopMenuLink(SCHEDULING_ROUTE)
					})
				})
			}
			if (currentUser.allRoles.length > 1 && currentUser.allRoles.includes(ADMIN)) {
				primaryMenu.push({
					text: adminText, onClick: () => handleProtocolTransferExit(protocolTransferStatusRef.current, dispatch, () => {
						return secondaryTopMenuLink(ADMIN_ROUTE)
					})
				})
			}
			const newConfig = navConfig

			if (newConfig.primaryMenuItems.length > 0) {
				newConfig.primaryMenuItems[0].items = primaryMenu
			}
			/* TODO: Add this condition in if statement - (computedFeatures.CONSOLE_EDIT_WITHOUT_AUTHORIZATION) */
			if (newConfig.iconMenuItems.length > 0) {
				if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.PROTOCOL_TRANSFER_FLAG)) {
					if (isAdminOnly) {
						newConfig.iconMenuItems[PROTOCOL_TRANSFER_ICON_INDEX].items.pop()
					} else {
						if (transactions.length > 0 || checkIfParticularSessionGoingOn(consoleSessions, [VIEW, INCOGNITO_VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT]) || protocolTransferState == CONFIG_WITHOUT_HARDWARE) {
							newConfig.iconMenuItems[PROTOCOL_TRANSFER_ICON_INDEX].items = [protocolTransfrIcon(true, protocolTransferStatusRef.current, dispatch)]
						}
						else {
							newConfig.iconMenuItems[PROTOCOL_TRANSFER_ICON_INDEX].items = [protocolTransfrIcon(false, protocolTransferStatusRef.current, dispatch)]
						}
					}
				}
				else {
					newConfig.iconMenuItems[PROTOCOL_TRANSFER_ICON_INDEX].items.pop()
				}
				if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_SELF_SERVICE)) {
					if (newConfig.iconMenuItems[SUPPORT_ICON_INDEX].items.length === 0) {
						newConfig.iconMenuItems[SUPPORT_ICON_INDEX].items = [supportIcon(protocolTransferStatusRef.current, dispatch)]
					}
				}
				else {
					newConfig.iconMenuItems[SUPPORT_ICON_INDEX].items.pop()
				}
				if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_ROOM_MONITORING) && cctvWindow && consoleSessions.length > 0) {
					if (newConfig.iconMenuItems[LIVE_VIDEO_INDEX].items.length === 0) {
						newConfig.iconMenuItems[LIVE_VIDEO_INDEX].items = [cctvIcon(cctvWindow, dispatch)]
					}
				}
				else {
					newConfig.iconMenuItems[LIVE_VIDEO_INDEX].items.pop()
				}
				contructRadconnectRelatedNavConfig(featureFlags, newConfig)

			}
			setNavConfig({ ...newConfig })
		}
	}, [featureFlags, currentUser, protocolTransferStatus, transactions, consoleSessions, protocolTransferStep, selectedDestination, selectedSource, protocolTransferState, cctvWindow])

	return <>
		{FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_PROTOTYPE_BANNER)
			&& <PrototypeBanner
				warningText={intl.formatMessage({
					id: "content.rocc.prototypeWarningMessage",
					defaultMessage: en["content.rocc.prototypeWarningMessage"]
				})} />}
		<NavBar config={appContext === EAppContext.PRE_SIGNED ? preSignedContextNavConfig : navConfig} userName={userName ?? intl.formatMessage({
			id: "content.rocc.username",
			defaultMessage: en["content.rocc.username"]
		})} />
	</>

}
export default Navbar
