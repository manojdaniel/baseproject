/*
 * Created on Wed Nov 24 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EButtonDirection, EConnectionType, EPosition, getRoomDetailFromUuid, isQualifiedForFixedCommandCenterEdit } from "@rocc/rocc-client-services"
import { ConsoleOperations, EIconType } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger } from "@rocc/rocc-logging-module"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"
import cx from "classnames"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { Icon, Modal } from "semantic-ui-react"
import { connectionUtility, getConnectionAdapter } from "../../common/helpers/connection"
import { getRoomAdditionalAttributes, onReceiverUseConfirmation } from "../../common/helpers/consoleUtility"
import { checkIfEmeraldPMEnabled, checkIfMultiRoomIsDisabled, checkIfPMEditConsoleEnabled, hideNotificationModal, isNFCCAllowed, isRoomMonitoringEnabled } from "../../common/helpers/helpers"
import { GLOBAL_LEFTSIDE_PANEL, GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import { IReceiverSelectionModal, IStore } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchRooms } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import NfccDropdown from "../nfcc-dropdown/NfccDropdown"
import styles from "./ProtocolManagement.scss"

interface IPMConsole {
    roomUuid: string
    showTitle?: boolean
    iconPosition?: EPosition
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    component?: string
}

const componentName = "Protocol Management"

const ProtocolManagement = (props: IPMConsole) => {
    const { roomUuid, setReceiverSelectionModal, iconPosition, showTitle } = props
    const {
        featureFlags,
        consoleSessions,
        receivers,
        consoleOperation,
        commandCenterDetails,
        protocolTransferStatus,
        currentUser,
        permissions
    } = useSelector((state: IStore) => ({
        featureFlags: state.externalReducer.featureFlags,
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        commandCenterDetails: state.consoleReducer.commandCenterDetails,
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        currentUser: state.externalReducer.currentUser,
        permissions: state.externalReducer.permissions
    }))

    const [loading, setLoading] = useState(false)
    const [disabled, setDisabled] = useState(false)
    const [connectionState, setConnectionState] = useState(false)
    const [preferredConnection, setPreferredConnection] = useState(null)
    const consoleSessionsRef = useRef(consoleSessions)
    const roomAdditionalAttributes = getRoomAdditionalAttributes(roomUuid)
    const showMenu = (!!permissions.CONSOLE_EDIT_WITHOUT_AUTHORIZATION && isNFCCAllowed() && isQualifiedForFixedCommandCenterEdit(roomAdditionalAttributes))
    const { intl } = getIntlProvider()

    const { PROTOCOL_MANAGEMENT } = EConnectionType

    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    useEffect(() => {
        const { connectionState, loading, disabled } = getConnectionAdapter().getViewOrPMConsoleStatus({
            consoleOperation, consoleSessions, roomUuid, connectionType: PROTOCOL_MANAGEMENT, protocolTransferStatus
        })
        setLoading(loading)
        setDisabled(disabled)
        setConnectionState(connectionState)
    }, [consoleOperation, consoleSessions, protocolTransferStatus])

    useEffect(()=>{
        const availableConnections = connectionUtility.createConnectionList(getRoomDetailFromUuid(fetchRooms(), roomUuid),{
            username : currentUser.kvmUsername,
            seatname: commandCenterDetails.commandCenterSeat.seatName
        })
        if (availableConnections.length == 0){
            return
        }
        const preferredConnectionSource = getConnectionAdapter().getPreferredConnection(availableConnections, EConnectionType.PROTOCOL_MANAGEMENT)
        if (!preferredConnectionSource){
            return
        }
        if(preferredConnectionSource.connectionMode == EModalityConnectionMode.KVM){
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.EMERALD)){
                // Check Emerald App Permissions and Configs
                const emeraldPMEnabled = checkIfEmeraldPMEnabled(permissions, roomAdditionalAttributes, currentUser.kvmUsername)
                const isEmeraldEnabled = isRoomMonitoringEnabled(featureFlags) ?
                    (emeraldPMEnabled && receivers.length === 0) :
                    emeraldPMEnabled
                if(!isEmeraldEnabled || !showMenu){
                    preferredConnectionSource.subConnectionMode.filter((subConnection)=>subConnection!==EModalitySubConnectionMode.EMERALD)
                }
            }
            if (preferredConnectionSource.subConnectionMode.includes(EModalitySubConnectionMode.CC)){
                const status = !checkIfPMEditConsoleEnabled(permissions, receivers)
                if(status){
                    preferredConnectionSource.subConnectionMode.filter((subConnection)=>subConnection!==EModalitySubConnectionMode.CC)
                }
            }
        }
        setPreferredConnection(preferredConnectionSource as any)
    },[commandCenterDetails])

    const getHeader = () => {
        return (
            <Modal.Header className={styles.modalHeader}>
                <Icon className={cx("icon ExclamationMarkCircle", styles.exclamationSymbol)} />
                <span className={styles.headerText}>
                    {intl.formatMessage({ id: "content.protocolTransfer.startConfirmation", defaultMessage: en["content.protocolTransfer.startConfirmation"] })}
                </span>
            </Modal.Header>
        )
    }

    const getContent = () => {
        const displayContent = `${intl.formatMessage({
            id: "content.consoleMessages.protocolManagerConfirmMessage",
            defaultMessage: en["content.consoleMessages.protocolManagerConfirmMessage"]
        })}`
        return (
            <Modal.Description>
                <div className={styles.contentText} dangerouslySetInnerHTML={{ __html: displayContent }} />
            </Modal.Description>
        )
    }

<<<<<<< HEAD
    const onStartClick = (connectionMode: EModalityConnectionMode, subConnectionMode : EModalitySubConnectionMode| null) => {

=======
    const onStartClick = (connectionMode: EConnectionMode) => {
        hideNotificationModal()
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
        const props = {
            connectionMode,
            subConnectionMode,
            roomUuid,
            connectionType: PROTOCOL_MANAGEMENT,
            receivers,
            consoleSessions: consoleSessionsRef.current,
            onReceiverSelectionRequired: ()=> setReceiverSelectionModal({ showReceiverModal: true, connectionType: PROTOCOL_MANAGEMENT }),
            onReceiverUseConfirmation : (props: any)=> onReceiverUseConfirmation({...props, setReceiverSelectionModal}),
            featureFlags,
            componentName
        }

        if (subConnectionMode === EModalitySubConnectionMode.CC) {
            checkIfMultiRoomIsDisabled(featureFlags, receivers) ? getConnectionAdapter().connect(props)
                : setReceiverSelectionModal({ showReceiverModal: true, connectionType: PROTOCOL_MANAGEMENT })
        } else {
            getConnectionAdapter().connect(props)
        }
        infoLogger(`RoomUUid : ${roomUuid}`)
    }

    const performConsoleDisconnectionOps = () => {
        const { status }= getConnectionAdapter().disconnect({ roomUuid, connectionType: PROTOCOL_MANAGEMENT })
        if(status){
            dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: false,
                    activeLeftPanel: "",
                    desktopFullScreen: false,
                }
            })
        }
    }

    const handleClick = (connectionMode: EModalityConnectionMode, subConnectionMode : EModalitySubConnectionMode | null) => {
        const notificationModal = {
            showModal: true,
            header: getHeader(),
            modalContent: getContent(),
            actionButton1Text: intl.formatMessage({ id: "content.start.btn", defaultMessage: en["content.start.btn"] }),
            actionButton2Text: intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
            buttonDirection: EButtonDirection.RIGHT,
            actionButton1Onclick: () => onStartClick(connectionMode, subConnectionMode),
            actionButton2Onclick: () => hideNotificationModal(),
            modalStyles: "pmStartModal"
        }
        dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
    }

    const startEditing = intl.formatMessage({ id: "content.startEditing.btn", defaultMessage: en["content.startEditing.btn"] })
    const stopEditing = intl.formatMessage({ id: "content.stopEditing.btn", defaultMessage: en["content.stopEditing.btn"] })

    if (connectionState || loading) {
        return <ConsoleOperations
            stopConsoleOperationHandler={performConsoleDisconnectionOps}
            loading={loading}
            disabled={disabled}
            iconPosition={iconPosition ? iconPosition : EPosition.HORIZONTAL}
            connectionState={connectionState}
            showTitle={showTitle ?? false}
            consoleOperationProps={{
                start: {
                    title: startEditing,
                    type: PROTOCOL_MANAGEMENT,
                    icon: EIconType.EDIT_START_ICON,
                },
                stop: {
                    title: stopEditing,
                    type: PROTOCOL_MANAGEMENT,
                    icon: EIconType.EDIT_STOP_ICON,
                }
            }} showToolTip={false} tooltipMessage={""} />
    }

    
    return (
        <>
            <NfccDropdown
                text={intl.formatMessage({ id: "content.mode.protocolManagement", defaultMessage: en["content.mode.protocolManagement"] })}
                showMenu={true}
                commandCenterDetails={preferredConnection}
                featureFlags={featureFlags}
                handleClick={handleClick}
            />
        </>
    )
}

export default ProtocolManagement
