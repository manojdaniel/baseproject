/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Reducer } from "redux"
import { FETCH_LOCATION_DATA, FETCH_LOCATION_DATA_FAILED, GLOBAL_UPDATE_ACTIVE_LOCATION, GLOBAL_UPDATE_CUSTOMER_METADATA, GLOBAL_UPDATE_ROOMS, UPDATE_CUSTOMER_ORG_ID, UPDATE_ROOM_PRESENCE } from "../actions/types"
import { EFetchStatus, ICustomerReducer } from "@rocc/rocc-client-services"

export const initialStatesForCustomer: ICustomerReducer = {
    metaData: { id: -1, displayName: "", name: "", orgId: "", contacts: [] },
    locationFetched: EFetchStatus.notStarted,
    locations: [],
    rooms: [],
    activeLocationId: -1,
    initRoomsFetched: false,
}

const customerReducer: Reducer<ICustomerReducer> = (state: ICustomerReducer = initialStatesForCustomer, action: any) => {
    switch (action.type) {
        case UPDATE_CUSTOMER_ORG_ID: {
            const cMetaData = state.metaData
            cMetaData.orgId = action.orgId
            return { ...state, metaData: cMetaData }
        }
        case FETCH_LOCATION_DATA: {
            const { customerMetaData, locations, rooms } = action
            return { ...state, metaData: customerMetaData, locations, rooms, locationFetched: EFetchStatus.success, initRoomsFetched: action.initRoomsFetched }
        }
        case FETCH_LOCATION_DATA_FAILED:
            return { ...state, locationFetched: EFetchStatus.failed }
        case GLOBAL_UPDATE_ACTIVE_LOCATION:
            return { ...state, activeLocationId: action.activeLocationId }

        case UPDATE_ROOM_PRESENCE:
            return { ...state, rooms: action.rooms }
        case GLOBAL_UPDATE_ROOMS:
            return { ...state, rooms: action.payload.rooms }
        case GLOBAL_UPDATE_CUSTOMER_METADATA:
            return { ...state, metaData: action.metaData }
        default:
    }
    return { ...state }
}

export default customerReducer
