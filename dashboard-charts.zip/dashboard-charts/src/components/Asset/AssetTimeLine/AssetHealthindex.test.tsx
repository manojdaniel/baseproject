import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AssetHealthIndex from "./AssetHealthIndex";

//Mock data for the chart component
const data = [
	{
		assetId: "2Y-3602",
		timestamp: "2022-01-01T00:06:23.323",
		assetHealthIndex: 2,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-01-11T00:06:23.323",
		assetHealthIndex: 2,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-02-15T00:24:25.67",
		assetHealthIndex: 5,
		color: "Red",
		status: "warning",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-03-29T00:37:51.567",
		assetHealthIndex: 1,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-04-05T00:51:41.083",
		assetHealthIndex: 8,
		color: "Red",
		status: "Normal",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-01T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-03T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-06T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-09T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-12T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-15T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-18T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-21T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-24T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-05-29T01:06:50.79",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-06-29T01:21:28.29",
		assetHealthIndex: 6,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-07-19T01:36:17.2",
		assetHealthIndex: 4,
		color: "Red",
		status: "Normal",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-08-09T01:51:02.653",
		assetHealthIndex: 5,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-02T02:08:36.14",
		assetHealthIndex: 2,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-10T02:22:13.72",
		assetHealthIndex: 2,
		color: "Red",
		status: "Normal",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-12T02:08:36.14",
		assetHealthIndex: 2,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-15T02:22:13.72",
		assetHealthIndex: 2,
		color: "Red",
		status: "Normal",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-20T02:08:36.14",
		assetHealthIndex: 2,
		color: "Red",
		status: "Anomaly Alert",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-28T02:22:13.72",
		assetHealthIndex: 2,
		color: "Red",
		status: "Normal",
	},
	{
		assetId: "2Y-3602",
		timestamp: "2022-09-29T02:22:13.72",
		assetHealthIndex: 2,
		color: "Red",
		status: "Normal",
	},
];

//Test Case to check chart exist in the component.
describe("AssetHealthIndex", () => {
	it("renders the chart with data", () => {
		const { container } = render(
			<AssetHealthIndex assetHealthIndexData={data} />
		);
		expect(container.querySelector("#chartdiv")).toBeInTheDocument();
	});
});
