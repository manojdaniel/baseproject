export const myTaskTableData = [
  {
    "AlertID": 12345,
    "Affiliate": "Yanpet",
    "Plant": "MT Vernon",
    "AssetID": "2k-2301",
    "AssetName": "Natural Gas Compressor",
    "AnomolyType": "Behavioural",
    "LongLeadAction": "Yes",
    "AssignedTo": "Digitilization Champion",
    "TimeStamp": "022-12-09T09:46:18",
    "Open": "Open"
  },
  {
    "AlertID": 12346,
    "Affiliate": "Yanpet",
    "Plant": "MT Vernon",
    "AssetID": "2k-2301",
    "AssetName": "Natural Gas Compressor",
    "AnomolyType": "Behavioural",
    "LongLeadAction": "No",
    "AssignedTo": "Digitilization Champion",
    "TimeStamp": "022-12-09T09:46:18",
    "Open": "Open"
  },
  {
    "AlertID": 12347,
    "Affiliate": "Yanpet",
    "Plant": "MT Vernon",
    "AssetID": "2k-2301",
    "AssetName": "Natural Gas Compressor",
    "AnomolyType": "Behavioural",
    "LongLeadAction": "Yes",
    "AssignedTo": "Digitilization Champion",
    "TimeStamp": "022-12-09T09:46:18",
    "Open": "Open"
  },
  {
    "AlertID": 12348,
    "Affiliate": "Yanpet",
    "Plant": "MT Vernon",
    "AssetID": "2k-2301",
    "AssetName": "Natural Gas Compressor",
    "AnomolyType": "Behavioural",
    "LongLeadAction": "No",
    "AssignedTo": "Digitilization Champion",
    "TimeStamp": "022-12-09T09:46:18",
    "Open": "Open"
  }
]