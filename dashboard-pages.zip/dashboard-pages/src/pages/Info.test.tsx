import React from "react";
import { render, screen } from "@testing-library/react";
import Info from "./Info";
import "@testing-library/jest-dom/extend-expect";
import Status from "components/Status";
import InfoTable from "table/InfoTable";

describe("Info component", () => {
  test("renders without crashing", () => {
    render(<Info />);
  });

  test("renders the plant top bar data", () => {
    const plantTopBar = [
      {
        affiliateCount: 1,
        assetCount: 49,
        healthIndex: "84% ",
        pmCompliance: "100% ",
        sparesAvailability: "3%",
        active: 28,
        overdueInvestigation: 26,
        underInvestigation: 2,
        healthTrend: 1,
        alertTrend: 1,
      },
    ];

    render(<Status data={plantTopBar} page={"ALLPLANT"} healthIndexToolTip={[]} />);

    plantTopBar.forEach((item) => {
      const healthIndex = screen.getByText(item.healthIndex.trim());
      expect(healthIndex).toBeInTheDocument();

      const pmCompliance = screen.getByText(item.pmCompliance.trim());
      expect(pmCompliance).toBeInTheDocument();

      const sparesAvailability = screen.getByText(
        item.sparesAvailability.trim()
      );
      expect(sparesAvailability).toBeInTheDocument();
    });
  });

  test("renders the info table data", () => {
    const infoTableData = [
      {
        FileName: "DOC Document",
        DownloadBtn: "Download",
      },
      {
        FileName: "JPG Document",
        DownloadBtn: "Download",
      },
      {
        FileName: "PDF Document",
        DownloadBtn: "Download",
      },
      {
        FileName: "JS Document",
        DownloadBtn: "Download",
      },
      {
        FileName: "ZIP Document",
        DownloadBtn: "Download",
      },
    ];

    render(<InfoTable data={infoTableData} />);

    infoTableData.forEach((item) => {
      const fileName = screen.getByText(item.FileName);
      expect(fileName).toBeInTheDocument();

      const downloadBtn = screen.getByText(item.DownloadBtn);
      expect(downloadBtn).toBeInTheDocument();
    });
  });

  test("renders the 'Info Page' text", () => {
    render(<Info />);
    const infoPageText = screen.getByText("Info Page");
    expect(infoPageText).toBeInTheDocument();
  });
});
