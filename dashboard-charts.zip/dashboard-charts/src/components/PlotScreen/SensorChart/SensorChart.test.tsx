import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import SensorChart from "./index";

//Mock data for the chart component
const data = [
	{
		Timestamp: "2023-03-06T18:41:12.2559203Z",
		value: 670.23645,
		ConvertedTimeStamp: "2023-03-07 00:11:12.255",
	},
	{
		Timestamp: "2023-03-06T18:56:12.2559203Z",
		value: 681.345,
		ConvertedTimeStamp: "2023-03-07 00:26:12.255",
	},
	{
		Timestamp: "2023-03-06T19:11:12.2559203Z",
		value: 647.940857,
		ConvertedTimeStamp: "2023-03-07 00:41:12.255",
	},
	{
		Timestamp: "2023-03-06T19:26:12.2559203Z",
		value: 652.985,
		ConvertedTimeStamp: "2023-03-07 00:56:12.255",
	},
	{
		Timestamp: "2023-03-06T19:41:12.2559203Z",
		value: 675.702942,
		ConvertedTimeStamp: "2023-03-07 01:11:12.255",
	},
	{
		Timestamp: "2023-03-06T19:56:12.2559203Z",
		value: 675.283569,
		ConvertedTimeStamp: "2023-03-07 01:26:12.255",
	},
	{
		Timestamp: "2023-03-06T20:11:12.2559203Z",
		value: 678.7812,
		ConvertedTimeStamp: "2023-03-07 01:41:12.255",
	},
	{
		Timestamp: "2023-03-06T20:26:12.2559203Z",
		value: 671.249756,
		ConvertedTimeStamp: "2023-03-07 01:56:12.255",
	},
	{
		Timestamp: "2023-03-06T20:41:12.2559203Z",
		value: 681.162537,
		ConvertedTimeStamp: "2023-03-07 02:11:12.255",
	},
	{
		Timestamp: "2023-03-06T20:56:12.2559203Z",
		value: 665.9206,
		ConvertedTimeStamp: "2023-03-07 02:26:12.255",
	},
	{
		Timestamp: "2023-03-06T21:11:12.2559203Z",
		value: 657.2832,
		ConvertedTimeStamp: "2023-03-07 02:41:12.255",
	},
	{
		Timestamp: "2023-03-06T21:26:12.2559203Z",
		value: 685.6746,
		ConvertedTimeStamp: "2023-03-07 02:56:12.255",
	},
	{
		Timestamp: "2023-03-06T21:41:12.2559203Z",
		value: 670.329651,
		ConvertedTimeStamp: "2023-03-07 03:11:12.255",
	},
	{
		Timestamp: "2023-03-06T21:56:12.2559203Z",
		value: 680.805359,
		ConvertedTimeStamp: "2023-03-07 03:26:12.255",
	},
	{
		Timestamp: "2023-03-06T22:11:12.2559203Z",
		value: 670.6863,
		ConvertedTimeStamp: "2023-03-07 03:41:12.255",
	},
	{
		Timestamp: "2023-03-06T22:26:12.2559203Z",
		value: 675.4694,
		ConvertedTimeStamp: "2023-03-07 03:56:12.255",
	},
	{
		Timestamp: "2023-03-06T22:41:12.2559203Z",
		value: 683.917,
		ConvertedTimeStamp: "2023-03-07 04:11:12.255",
	},
	{
		Timestamp: "2023-03-06T22:56:12.2559203Z",
		value: 674.5167,
		ConvertedTimeStamp: "2023-03-07 04:26:12.255",
	},
	{
		Timestamp: "2023-03-06T23:11:12.2559203Z",
		value: 684.6663,
		ConvertedTimeStamp: "2023-03-07 04:41:12.255",
	},
	{
		Timestamp: "2023-03-06T23:26:12.2559203Z",
		value: 661.561462,
		ConvertedTimeStamp: "2023-03-07 04:56:12.255",
	},
	{
		Timestamp: "2023-03-06T23:41:12.2559203Z",
		value: 683.4659,
		ConvertedTimeStamp: "2023-03-07 05:11:12.255",
	},
	{
		Timestamp: "2023-03-06T23:56:12.2559203Z",
		value: 677.4968,
		ConvertedTimeStamp: "2023-03-07 05:26:12.255",
	},
	{
		Timestamp: "2023-03-07T00:11:12.2559203Z",
		value: 661.2606,
		ConvertedTimeStamp: "2023-03-07 05:41:12.255",
	},
	{
		Timestamp: "2023-03-07T00:26:12.2559203Z",
		value: 686.9126,
		ConvertedTimeStamp: "2023-03-07 05:56:12.255",
	},
	{
		Timestamp: "2023-03-07T00:41:12.2559203Z",
		value: 637.737244,
		ConvertedTimeStamp: "2023-03-07 06:11:12.255",
	},
	{
		Timestamp: "2023-03-07T00:56:12.2559203Z",
		value: 676.601563,
		ConvertedTimeStamp: "2023-03-07 06:26:12.255",
	},
	{
		Timestamp: "2023-03-07T01:11:12.2559203Z",
		value: 684.752,
		ConvertedTimeStamp: "2023-03-07 06:41:12.255",
	},
	{
		Timestamp: "2023-03-07T01:26:12.2559203Z",
		value: 673.980347,
		ConvertedTimeStamp: "2023-03-07 06:56:12.255",
	},
	{
		Timestamp: "2023-03-07T01:41:12.2559203Z",
		value: 682.2297,
		ConvertedTimeStamp: "2023-03-07 07:11:12.255",
	},
	{
		Timestamp: "2023-03-07T01:56:12.2559203Z",
		value: 642.2911,
		ConvertedTimeStamp: "2023-03-07 07:26:12.255",
	},
	{
		Timestamp: "2023-03-07T02:11:12.2559203Z",
		value: 672.2927,
		ConvertedTimeStamp: "2023-03-07 07:41:12.255",
	},
	{
		Timestamp: "2023-03-07T02:26:12.2559203Z",
		value: 649.425964,
		ConvertedTimeStamp: "2023-03-07 07:56:12.255",
	},
	{
		Timestamp: "2023-03-07T02:41:12.2559203Z",
		value: 675.325,
		ConvertedTimeStamp: "2023-03-07 08:11:12.255",
	},
	{
		Timestamp: "2023-03-07T02:56:12.2559203Z",
		value: 671.794861,
		ConvertedTimeStamp: "2023-03-07 08:26:12.255",
	},
	{
		Timestamp: "2023-03-07T03:11:12.2559203Z",
		value: 662.7453,
		ConvertedTimeStamp: "2023-03-07 08:41:12.255",
	},
	{
		Timestamp: "2023-03-07T03:26:12.2559203Z",
		value: 661.463745,
		ConvertedTimeStamp: "2023-03-07 08:56:12.255",
	},
	{
		Timestamp: "2023-03-07T03:41:12.2559203Z",
		value: 671.794861,
		ConvertedTimeStamp: "2023-03-07 09:11:12.255",
	},
	{
		Timestamp: "2023-03-07T03:56:12.2559203Z",
		value: 651.770447,
		ConvertedTimeStamp: "2023-03-07 09:26:12.255",
	},
	{
		Timestamp: "2023-03-07T04:11:12.2559203Z",
		value: 662.4527,
		ConvertedTimeStamp: "2023-03-07 09:41:12.255",
	},
	{
		Timestamp: "2023-03-07T04:26:12.2559203Z",
		value: 667.6435,
		ConvertedTimeStamp: "2023-03-07 09:56:12.255",
	},
	{
		Timestamp: "2023-03-07T04:41:12.2559203Z",
		value: 665.632568,
		ConvertedTimeStamp: "2023-03-07 10:11:12.255",
	},
	{
		Timestamp: "2023-03-07T04:56:12.2559203Z",
		value: 669.108643,
		ConvertedTimeStamp: "2023-03-07 10:26:12.255",
	},
	{
		Timestamp: "2023-03-07T05:11:12.2559203Z",
		value: 660.29425,
		ConvertedTimeStamp: "2023-03-07 10:41:12.255",
	},
	{
		Timestamp: "2023-03-07T05:26:12.2559203Z",
		value: 670.9874,
		ConvertedTimeStamp: "2023-03-07 10:56:12.255",
	},
	{
		Timestamp: "2023-03-07T05:41:12.2559203Z",
		value: 663.7906,
		ConvertedTimeStamp: "2023-03-07 11:11:12.255",
	},
	{
		Timestamp: "2023-03-07T05:56:12.2559203Z",
		value: 667.7294,
		ConvertedTimeStamp: "2023-03-07 11:26:12.255",
	},
	{
		Timestamp: "2023-03-07T06:11:12.2559203Z",
		value: 690.827942,
		ConvertedTimeStamp: "2023-03-07 11:41:12.255",
	},
	{
		Timestamp: "2023-03-07T06:26:12.2559203Z",
		value: 678.2793,
		ConvertedTimeStamp: "2023-03-07 11:56:12.255",
	},
	{
		Timestamp: "2023-03-07T06:41:12.2559203Z",
		value: 670.672363,
		ConvertedTimeStamp: "2023-03-07 12:11:12.255",
	},
	{
		Timestamp: "2023-03-07T06:56:12.2559203Z",
		value: 687.674744,
		ConvertedTimeStamp: "2023-03-07 12:26:12.255",
	},
	{
		Timestamp: "2023-03-07T07:11:12.2559203Z",
		value: 645.1695,
		ConvertedTimeStamp: "2023-03-07 12:41:12.255",
	},
	{
		Timestamp: "2023-03-07T07:26:12.2559203Z",
		value: 682.95,
		ConvertedTimeStamp: "2023-03-07 12:56:12.255",
	},
	{
		Timestamp: "2023-03-07T07:41:12.2559203Z",
		value: 716.7132,
		ConvertedTimeStamp: "2023-03-07 13:11:12.255",
	},
	{
		Timestamp: "2023-03-07T07:56:12.2559203Z",
		value: 657.2435,
		ConvertedTimeStamp: "2023-03-07 13:26:12.255",
	},
	{
		Timestamp: "2023-03-07T08:11:12.2559203Z",
		value: 667.2088,
		ConvertedTimeStamp: "2023-03-07 13:41:12.255",
	},
	{
		Timestamp: "2023-03-07T08:26:12.2559203Z",
		value: 689.509949,
		ConvertedTimeStamp: "2023-03-07 13:56:12.255",
	},
	{
		Timestamp: "2023-03-07T08:41:12.2559203Z",
		value: 660.8445,
		ConvertedTimeStamp: "2023-03-07 14:11:12.255",
	},
	{
		Timestamp: "2023-03-07T08:56:12.2559203Z",
		value: 672.9814,
		ConvertedTimeStamp: "2023-03-07 14:26:12.255",
	},
	{
		Timestamp: "2023-03-07T09:11:12.2559203Z",
		value: 675.2216,
		ConvertedTimeStamp: "2023-03-07 14:41:12.255",
	},
	{
		Timestamp: "2023-03-07T09:26:12.2559203Z",
		value: 673.762756,
		ConvertedTimeStamp: "2023-03-07 14:56:12.255",
	},
	{
		Timestamp: "2023-03-07T09:41:12.2559203Z",
		value: 674.9695,
		ConvertedTimeStamp: "2023-03-07 15:11:12.255",
	},
	{
		Timestamp: "2023-03-07T09:56:12.2559203Z",
		value: 674.245239,
		ConvertedTimeStamp: "2023-03-07 15:26:12.255",
	},
	{
		Timestamp: "2023-03-07T10:11:12.2559203Z",
		value: 672.7039,
		ConvertedTimeStamp: "2023-03-07 15:41:12.255",
	},
	{
		Timestamp: "2023-03-07T10:26:12.2559203Z",
		value: 680.3222,
		ConvertedTimeStamp: "2023-03-07 15:56:12.255",
	},
	{
		Timestamp: "2023-03-07T10:41:12.2559203Z",
		value: 689.691956,
		ConvertedTimeStamp: "2023-03-07 16:11:12.255",
	},
	{
		Timestamp: "2023-03-07T10:56:12.2559203Z",
		value: 680.341858,
		ConvertedTimeStamp: "2023-03-07 16:26:12.255",
	},
	{
		Timestamp: "2023-03-07T11:11:12.2559203Z",
		value: 680.316833,
		ConvertedTimeStamp: "2023-03-07 16:41:12.255",
	},
	{
		Timestamp: "2023-03-07T11:26:12.2559203Z",
		value: 628.083,
		ConvertedTimeStamp: "2023-03-07 16:56:12.255",
	},
	{
		Timestamp: "2023-03-07T11:41:12.2559203Z",
		value: 647.6595,
		ConvertedTimeStamp: "2023-03-07 17:11:12.255",
	},
	{
		Timestamp: "2023-03-07T11:56:12.2559203Z",
		value: 706.6815,
		ConvertedTimeStamp: "2023-03-07 17:26:12.255",
	},
	{
		Timestamp: "2023-03-07T12:11:12.2559203Z",
		value: 666.135559,
		ConvertedTimeStamp: "2023-03-07 17:41:12.255",
	},
	{
		Timestamp: "2023-03-07T12:26:12.2559203Z",
		value: 657.571167,
		ConvertedTimeStamp: "2023-03-07 17:56:12.255",
	},
	{
		Timestamp: "2023-03-07T12:41:12.2559203Z",
		value: 686.3444,
		ConvertedTimeStamp: "2023-03-07 18:11:12.255",
	},
	{
		Timestamp: "2023-03-07T12:56:12.2559203Z",
		value: 662.984741,
		ConvertedTimeStamp: "2023-03-07 18:26:12.255",
	},
	{
		Timestamp: "2023-03-07T13:11:12.2559203Z",
		value: 689.303,
		ConvertedTimeStamp: "2023-03-07 18:41:12.255",
	},
	{
		Timestamp: "2023-03-07T13:26:12.2559203Z",
		value: 673.0638,
		ConvertedTimeStamp: "2023-03-07 18:56:12.255",
	},
	{
		Timestamp: "2023-03-07T13:41:12.2559203Z",
		value: 674.0707,
		ConvertedTimeStamp: "2023-03-07 19:11:12.255",
	},
	{
		Timestamp: "2023-03-07T13:56:12.2559203Z",
		value: 682.3174,
		ConvertedTimeStamp: "2023-03-07 19:26:12.255",
	},
	{
		Timestamp: "2023-03-07T14:11:12.2559203Z",
		value: 668.628052,
		ConvertedTimeStamp: "2023-03-07 19:41:12.255",
	},
	{
		Timestamp: "2023-03-07T14:26:12.2559203Z",
		value: 678.235,
		ConvertedTimeStamp: "2023-03-07 19:56:12.255",
	},
	{
		Timestamp: "2023-03-07T14:41:12.2559203Z",
		value: 672.295959,
		ConvertedTimeStamp: "2023-03-07 20:11:12.255",
	},
	{
		Timestamp: "2023-03-07T14:56:12.2559203Z",
		value: 657.322937,
		ConvertedTimeStamp: "2023-03-07 20:26:12.255",
	},
	{
		Timestamp: "2023-03-07T15:11:12.2559203Z",
		value: 675.78125,
		ConvertedTimeStamp: "2023-03-07 20:41:12.255",
	},
	{
		Timestamp: "2023-03-07T15:26:12.2559203Z",
		value: 681.4763,
		ConvertedTimeStamp: "2023-03-07 20:56:12.255",
	},
	{
		Timestamp: "2023-03-07T15:41:12.2559203Z",
		value: 670.2018,
		ConvertedTimeStamp: "2023-03-07 21:11:12.255",
	},
	{
		Timestamp: "2023-03-07T15:56:12.2559203Z",
		value: 699.805054,
		ConvertedTimeStamp: "2023-03-07 21:26:12.255",
	},
	{
		Timestamp: "2023-03-07T16:11:12.2559203Z",
		value: 656.9203,
		ConvertedTimeStamp: "2023-03-07 21:41:12.255",
	},
	{
		Timestamp: "2023-03-07T16:26:12.2559203Z",
		value: 673.4737,
		ConvertedTimeStamp: "2023-03-07 21:56:12.255",
	},
	{
		Timestamp: "2023-03-07T16:41:12.2559203Z",
		value: 668.6944,
		ConvertedTimeStamp: "2023-03-07 22:11:12.255",
	},
	{
		Timestamp: "2023-03-07T16:56:12.2559203Z",
		value: 672.5146,
		ConvertedTimeStamp: "2023-03-07 22:26:12.255",
	},
	{
		Timestamp: "2023-03-07T17:11:12.2559203Z",
		value: 672.9816,
		ConvertedTimeStamp: "2023-03-07 22:41:12.255",
	},
	{
		Timestamp: "2023-03-07T17:26:12.2559203Z",
		value: 657.012268,
		ConvertedTimeStamp: "2023-03-07 22:56:12.255",
	},
	{
		Timestamp: "2023-03-07T17:41:12.2559203Z",
		value: 689.7027,
		ConvertedTimeStamp: "2023-03-07 23:11:12.255",
	},
	{
		Timestamp: "2023-03-07T17:56:12.2559203Z",
		value: 669.852234,
		ConvertedTimeStamp: "2023-03-07 23:26:12.255",
	},
	{
		Timestamp: "2023-03-07T18:11:12.2559203Z",
		value: 665.9934,
		ConvertedTimeStamp: "2023-03-07 23:41:12.255",
	},
	{
		Timestamp: "2023-03-07T18:26:12.2559203Z",
		value: 677.238037,
		ConvertedTimeStamp: "2023-03-07 23:56:12.255",
	},
	{
		Timestamp: "2023-03-07T18:41:12.2559203Z",
		value: 659.2593,
		ConvertedTimeStamp: "2023-03-08 00:11:12.255",
	},
	{
		Timestamp: "2023-03-07T18:56:12.2559203Z",
		value: 676.9427,
		ConvertedTimeStamp: "2023-03-08 00:26:12.255",
	},
	{
		Timestamp: "2023-03-07T19:11:12.2559203Z",
		value: 676.3184,
		ConvertedTimeStamp: "2023-03-08 00:41:12.255",
	},
	{
		Timestamp: "2023-03-07T19:26:12.2559203Z",
		value: 669.7112,
		ConvertedTimeStamp: "2023-03-08 00:56:12.255",
	},
	{
		Timestamp: "2023-03-07T19:41:12.2559203Z",
		value: 671.8618,
		ConvertedTimeStamp: "2023-03-08 01:11:12.255",
	},
	{
		Timestamp: "2023-03-07T19:56:12.2559203Z",
		value: 672.605957,
		ConvertedTimeStamp: "2023-03-08 01:26:12.255",
	},
	{
		Timestamp: "2023-03-07T20:11:12.2559203Z",
		value: 676.894653,
		ConvertedTimeStamp: "2023-03-08 01:41:12.255",
	},
	{
		Timestamp: "2023-03-07T20:26:12.2559203Z",
		value: 644.8977,
		ConvertedTimeStamp: "2023-03-08 01:56:12.255",
	},
	{
		Timestamp: "2023-03-07T20:41:12.2559203Z",
		value: 663.1353,
		ConvertedTimeStamp: "2023-03-08 02:11:12.255",
	},
	{
		Timestamp: "2023-03-07T20:56:12.2559203Z",
		value: 685.3173,
		ConvertedTimeStamp: "2023-03-08 02:26:12.255",
	},
	{
		Timestamp: "2023-03-07T21:11:12.2559203Z",
		value: 664.425842,
		ConvertedTimeStamp: "2023-03-08 02:41:12.255",
	},
	{
		Timestamp: "2023-03-07T21:26:12.2559203Z",
		value: 673.233765,
		ConvertedTimeStamp: "2023-03-08 02:56:12.255",
	},
	{
		Timestamp: "2023-03-07T21:41:12.2559203Z",
		value: 679.1366,
		ConvertedTimeStamp: "2023-03-08 03:11:12.255",
	},
	{
		Timestamp: "2023-03-07T21:56:12.2559203Z",
		value: 659.750732,
		ConvertedTimeStamp: "2023-03-08 03:26:12.255",
	},
	{
		Timestamp: "2023-03-07T22:11:12.2559203Z",
		value: 675.76886,
		ConvertedTimeStamp: "2023-03-08 03:41:12.255",
	},
	{
		Timestamp: "2023-03-07T22:26:12.2559203Z",
		value: 673.681,
		ConvertedTimeStamp: "2023-03-08 03:56:12.255",
	},
	{
		Timestamp: "2023-03-07T22:41:12.2559203Z",
		value: 678.4408,
		ConvertedTimeStamp: "2023-03-08 04:11:12.255",
	},
	{
		Timestamp: "2023-03-07T22:56:12.2559203Z",
		value: 666.9506,
		ConvertedTimeStamp: "2023-03-08 04:26:12.255",
	},
	{
		Timestamp: "2023-03-07T23:11:12.2559203Z",
		value: 666.438965,
		ConvertedTimeStamp: "2023-03-08 04:41:12.255",
	},
	{
		Timestamp: "2023-03-07T23:26:12.2559203Z",
		value: 676.634766,
		ConvertedTimeStamp: "2023-03-08 04:56:12.255",
	},
	{
		Timestamp: "2023-03-07T23:41:12.2559203Z",
		value: 692.7707,
		ConvertedTimeStamp: "2023-03-08 05:11:12.255",
	},
	{
		Timestamp: "2023-03-07T23:56:12.2559203Z",
		value: 659.1957,
		ConvertedTimeStamp: "2023-03-08 05:26:12.255",
	},
	{
		Timestamp: "2023-03-08T00:11:12.2559203Z",
		value: 681.124,
		ConvertedTimeStamp: "2023-03-08 05:41:12.255",
	},
	{
		Timestamp: "2023-03-08T00:26:12.2559203Z",
		value: 678.366455,
		ConvertedTimeStamp: "2023-03-08 05:56:12.255",
	},
	{
		Timestamp: "2023-03-08T00:41:12.2559203Z",
		value: 676.2571,
		ConvertedTimeStamp: "2023-03-08 06:11:12.255",
	},
	{
		Timestamp: "2023-03-08T00:56:12.2559203Z",
		value: 672.807251,
		ConvertedTimeStamp: "2023-03-08 06:26:12.255",
	},
	{
		Timestamp: "2023-03-08T01:11:12.2559203Z",
		value: 673.355957,
		ConvertedTimeStamp: "2023-03-08 06:41:12.255",
	},
	{
		Timestamp: "2023-03-08T01:26:12.2559203Z",
		value: 673.6935,
		ConvertedTimeStamp: "2023-03-08 06:56:12.255",
	},
	{
		Timestamp: "2023-03-08T01:41:12.2559203Z",
		value: 664.653564,
		ConvertedTimeStamp: "2023-03-08 07:11:12.255",
	},
	{
		Timestamp: "2023-03-08T01:56:12.2559203Z",
		value: 687.921631,
		ConvertedTimeStamp: "2023-03-08 07:26:12.255",
	},
	{
		Timestamp: "2023-03-08T02:11:12.2559203Z",
		value: 670.077148,
		ConvertedTimeStamp: "2023-03-08 07:41:12.255",
	},
	{
		Timestamp: "2023-03-08T02:26:12.2559203Z",
		value: 672.595642,
		ConvertedTimeStamp: "2023-03-08 07:56:12.255",
	},
	{
		Timestamp: "2023-03-08T02:41:12.2559203Z",
		value: 674.4873,
		ConvertedTimeStamp: "2023-03-08 08:11:12.255",
	},
	{
		Timestamp: "2023-03-08T02:56:12.2559203Z",
		value: 665.0487,
		ConvertedTimeStamp: "2023-03-08 08:26:12.255",
	},
	{
		Timestamp: "2023-03-08T03:11:12.2559203Z",
		value: 663.5422,
		ConvertedTimeStamp: "2023-03-08 08:41:12.255",
	},
	{
		Timestamp: "2023-03-08T03:26:12.2559203Z",
		value: 660.759033,
		ConvertedTimeStamp: "2023-03-08 08:56:12.255",
	},
	{
		Timestamp: "2023-03-08T03:41:12.2559203Z",
		value: 716.942932,
		ConvertedTimeStamp: "2023-03-08 09:11:12.255",
	},
	{
		Timestamp: "2023-03-08T03:56:12.2559203Z",
		value: 656.5572,
		ConvertedTimeStamp: "2023-03-08 09:26:12.255",
	},
	{
		Timestamp: "2023-03-08T04:11:12.2559203Z",
		value: 675.644836,
		ConvertedTimeStamp: "2023-03-08 09:41:12.255",
	},
	{
		Timestamp: "2023-03-08T04:26:12.2559203Z",
		value: 682.9143,
		ConvertedTimeStamp: "2023-03-08 09:56:12.255",
	},
	{
		Timestamp: "2023-03-08T04:41:12.2559203Z",
		value: 685.9453,
		ConvertedTimeStamp: "2023-03-08 10:11:12.255",
	},
	{
		Timestamp: "2023-03-08T04:56:12.2559203Z",
		value: 662.5202,
		ConvertedTimeStamp: "2023-03-08 10:26:12.255",
	},
	{
		Timestamp: "2023-03-08T05:11:12.2559203Z",
		value: 650.1453,
		ConvertedTimeStamp: "2023-03-08 10:41:12.255",
	},
	{
		Timestamp: "2023-03-08T05:26:12.2559203Z",
		value: 648.9009,
		ConvertedTimeStamp: "2023-03-08 10:56:12.255",
	},
	{
		Timestamp: "2023-03-08T05:41:12.2559203Z",
		value: 657.9413,
		ConvertedTimeStamp: "2023-03-08 11:11:12.255",
	},
	{
		Timestamp: "2023-03-08T05:56:12.2559203Z",
		value: 644.2886,
		ConvertedTimeStamp: "2023-03-08 11:26:12.255",
	},
	{
		Timestamp: "2023-03-08T06:11:12.2559203Z",
		value: 657.9944,
		ConvertedTimeStamp: "2023-03-08 11:41:12.255",
	},
	{
		Timestamp: "2023-03-08T06:26:12.2559203Z",
		value: 651.9441,
		ConvertedTimeStamp: "2023-03-08 11:56:12.255",
	},
	{
		Timestamp: "2023-03-08T06:41:12.2559203Z",
		value: 668.654,
		ConvertedTimeStamp: "2023-03-08 12:11:12.255",
	},
	{
		Timestamp: "2023-03-08T06:56:12.2559203Z",
		value: 645.7421,
		ConvertedTimeStamp: "2023-03-08 12:26:12.255",
	},
	{
		Timestamp: "2023-03-08T07:11:12.2559203Z",
		value: 660.971558,
		ConvertedTimeStamp: "2023-03-08 12:41:12.255",
	},
	{
		Timestamp: "2023-03-08T07:26:12.2559203Z",
		value: 659.829041,
		ConvertedTimeStamp: "2023-03-08 12:56:12.255",
	},
	{
		Timestamp: "2023-03-08T07:41:12.2559203Z",
		value: 677.817932,
		ConvertedTimeStamp: "2023-03-08 13:11:12.255",
	},
	{
		Timestamp: "2023-03-08T07:56:12.2559203Z",
		value: 670.5122,
		ConvertedTimeStamp: "2023-03-08 13:26:12.255",
	},
	{
		Timestamp: "2023-03-08T08:11:12.2559203Z",
		value: 686.1158,
		ConvertedTimeStamp: "2023-03-08 13:41:12.255",
	},
	{
		Timestamp: "2023-03-08T08:26:12.2559203Z",
		value: 670.2023,
		ConvertedTimeStamp: "2023-03-08 13:56:12.255",
	},
	{
		Timestamp: "2023-03-08T08:41:12.2559203Z",
		value: 690.5734,
		ConvertedTimeStamp: "2023-03-08 14:11:12.255",
	},
	{
		Timestamp: "2023-03-08T08:56:12.2559203Z",
		value: 679.9877,
		ConvertedTimeStamp: "2023-03-08 14:26:12.255",
	},
	{
		Timestamp: "2023-03-08T09:11:12.2559203Z",
		value: 667.4304,
		ConvertedTimeStamp: "2023-03-08 14:41:12.255",
	},
	{
		Timestamp: "2023-03-08T09:26:12.2559203Z",
		value: 682.978149,
		ConvertedTimeStamp: "2023-03-08 14:56:12.255",
	},
	{
		Timestamp: "2023-03-08T09:41:12.2559203Z",
		value: 667.9124,
		ConvertedTimeStamp: "2023-03-08 15:11:12.255",
	},
	{
		Timestamp: "2023-03-08T09:56:12.2559203Z",
		value: 663.8736,
		ConvertedTimeStamp: "2023-03-08 15:26:12.255",
	},
	{
		Timestamp: "2023-03-08T10:11:12.2559203Z",
		value: 687.614136,
		ConvertedTimeStamp: "2023-03-08 15:41:12.255",
	},
	{
		Timestamp: "2023-03-08T10:26:12.2559203Z",
		value: 674.0475,
		ConvertedTimeStamp: "2023-03-08 15:56:12.255",
	},
	{
		Timestamp: "2023-03-08T10:41:12.2559203Z",
		value: 644.384766,
		ConvertedTimeStamp: "2023-03-08 16:11:12.255",
	},
	{
		Timestamp: "2023-03-08T10:56:12.2559203Z",
		value: 659.568054,
		ConvertedTimeStamp: "2023-03-08 16:26:12.255",
	},
	{
		Timestamp: "2023-03-08T11:11:12.2559203Z",
		value: 664.2247,
		ConvertedTimeStamp: "2023-03-08 16:41:12.255",
	},
	{
		Timestamp: "2023-03-08T11:26:12.2559203Z",
		value: 654.517761,
		ConvertedTimeStamp: "2023-03-08 16:56:12.255",
	},
	{
		Timestamp: "2023-03-08T11:41:12.2559203Z",
		value: 649.2457,
		ConvertedTimeStamp: "2023-03-08 17:11:12.255",
	},
	{
		Timestamp: "2023-03-08T11:56:12.2559203Z",
		value: 670.98584,
		ConvertedTimeStamp: "2023-03-08 17:26:12.255",
	},
	{
		Timestamp: "2023-03-08T12:11:12.2559203Z",
		value: 653.6121,
		ConvertedTimeStamp: "2023-03-08 17:41:12.255",
	},
	{
		Timestamp: "2023-03-08T12:26:12.2559203Z",
		value: 655.0939,
		ConvertedTimeStamp: "2023-03-08 17:56:12.255",
	},
	{
		Timestamp: "2023-03-08T12:41:12.2559203Z",
		value: 663.33136,
		ConvertedTimeStamp: "2023-03-08 18:11:12.255",
	},
	{
		Timestamp: "2023-03-08T12:56:12.2559203Z",
		value: 657.335938,
		ConvertedTimeStamp: "2023-03-08 18:26:12.255",
	},
	{
		Timestamp: "2023-03-08T13:11:12.2559203Z",
		value: 661.797363,
		ConvertedTimeStamp: "2023-03-08 18:41:12.255",
	},
	{
		Timestamp: "2023-03-08T13:26:12.2559203Z",
		value: 656.6404,
		ConvertedTimeStamp: "2023-03-08 18:56:12.255",
	},
	{
		Timestamp: "2023-03-08T13:41:12.2559203Z",
		value: 654.0116,
		ConvertedTimeStamp: "2023-03-08 19:11:12.255",
	},
	{
		Timestamp: "2023-03-08T13:56:12.2559203Z",
		value: 668.9602,
		ConvertedTimeStamp: "2023-03-08 19:26:12.255",
	},
	{
		Timestamp: "2023-03-08T14:11:12.2559203Z",
		value: 660.8525,
		ConvertedTimeStamp: "2023-03-08 19:41:12.255",
	},
	{
		Timestamp: "2023-03-08T14:26:12.2559203Z",
		value: 644.8204,
		ConvertedTimeStamp: "2023-03-08 19:56:12.255",
	},
];

//Test Case to check chart exist in the component.
describe("SensorChart", () => {
	it("renders the chart with data", () => {
		const { container } = render(
			<SensorChart data={data} selectedSensor={["2Y-3001"]} />
		);
		expect(container.querySelector("#chartdiv1")).toBeInTheDocument();
	});
});
