"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from enum import Enum
from flask_restful import Resource, reqparse
from flask import request

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION

LOG = create_logger("EmailTemplate controller")


class EmailTemplateType(Enum):
    INVITE_TEMPLATE = "INVITE_TEMPLATE"
    PWD_EXPIRY_TEMPLATE = "PWD_EXPIRY_TEMPLATE"
    FORGOT_PWD_TEMPLATE = "FORGOT_PWD_TEMPLATE"


class EmailTemplate(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("content", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("template_type",
                        type=EmailTemplateType,
                        required=True,
                        help=f"template_type should be one of {[e.value for e in EmailTemplateType]}!")

    map(str, EmailTemplateType)

    def put(self, customer_id):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for EmailTemplate update is: {api_version}")
            """ TODO: Need to evaluate the token """
        except KeyError:
            return {"message": f"'{API_VERSION}' header is needed to process this request"}, 400
        body = EmailTemplate.parser.parse_args()
        LOG.info(f"EmailTemplate update with content: {body['content']} and type: {body['template_type']} is initiated")
        """ TODO: EmailTemplate update process """
        return {"message": f"EmailTemplate - {body['template_type'].value} successfully updated for customer: {customer_id}"}, 200
