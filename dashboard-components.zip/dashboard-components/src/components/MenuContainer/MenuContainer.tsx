import React from "react";
import "./MenuContainer.scss";

interface Props {
	data: any[];
	handleMenuClick: any;
	getSelectedclassName: any;
}

const MenuContainer = ({
	data,
	handleMenuClick,
	getSelectedclassName,
}: Props) => {
	return (
		<div id="pmt-menu">
			{data.map((item) => (
				<a
					id={item.id}
					key={item.id}
					className={`top-container-conten ${getSelectedclassName(item.id)}`}
					onClick={() => {
						// Log an error if the menu item is clicked
						// elmah.logError('The menu item with id ' + item.id + ' was clicked');
						// elmahio.log('The menu item with id ' + item.id + ' was clicked');
						handleMenuClick(item.id);
					}}
				>
					{item.value}
				</a>
			))}
		</div>
	);
};

export default MenuContainer;
