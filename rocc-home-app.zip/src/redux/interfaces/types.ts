/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { RoccChatClient } from "@rocc/rocc-chat-library"
import { ECallStatus, IAVCallDetails, ICallStatus, ILocationInfo, IRoomDetails, IUserInfo, IWorkflow, IUserPermissions, EUserPresence, EClinicalRole, EConnectionStatus } from "@rocc/rocc-client-services"
import { IFocusedCallAndConsole } from "@rocc/rocc-client-services/dist/types/ParentStoreTypes"
import { EConnectionType } from "../../lib/types"
import { EConnectionState, EProtocolTransferSteps } from "./enums"

export interface IStore {
    externalReducer: IExternalReducer
    communicationReducer: ICommunicationReducer
}
export interface ICommunicationReducer {
    chatClient: RoccChatClient
}

export interface IExternalReducer {
    currentUser: IUserInfo
    activeLocationId: number
    sideBar: ISideBar
    consoleDetails: IConsoleDetails
    callingDetails: ICallingDetails
    featureFlags: any
    protocolTransferDetails: IProtocolTransferDetails
    locations: ILocationInfo[]
    rooms: IRoomDetails[]
    initRoomsFetched: boolean
    workflows: IWorkflowInfo[]
    permissions: IUserPermissions
    forceCleanUp: boolean
    applicationConnectionState: EConnectionStatus
    focusedCallAndConsole?: IFocusedCallAndConsole
}

export type IWorkflowInfo = Pick<IWorkflow, "id" | "type" | "state">

export interface IProtocolTransferDetails {
    protocolTransferStatus: boolean
    selectedSource: ISelectedScannerDetails
    selectedDestination: ISelectedScannerDetails
    currentStep: EProtocolTransferSteps
    completedDestinations: string[]
}

export interface ISelectedScannerDetails {
    identity: ISelectedScannerContext
    modality?: any
}
export interface ISelectedScannerContext {
    uuid: string
    name: string
}

export interface IConsoleDetails {
    activeConsoleSessions: IConsole[]
    activeConsoleTransactions: IConsole[]
}

export interface ICallingDetails {
    phoneCallStatus: ECallStatus
    videoCallStatus: ICallStatus[]
    connectedCallDetails: IAVCallDetails
    onHoldCallDetails: IAVCallDetails[]
}

export interface IConsole {
    contextId?: string
    roomUuid: string
    connectionMode: any
    connectionType: EConnectionType
    receiverName: string
    connectionStatus: EConnectionState
    additionalData?: IObject
}

export interface IObject {
    [key: string]: any
}

export interface ISideBar {
    activeRightPanel: string
    displayRightSidePanel: boolean
    activeLeftPanel: string
    displayLeftSidePanel: boolean
    desktopFullScreen: boolean
}

export interface ISetStarredRoom {
    roomId: number
    adminServiceUrl: string
    metasiteId: number
    isRoomStarred: boolean
    userId: number
    token: string
}

export interface IChatContact {
    uuid: string
    name: string
    type: "room" | "user"
    presence: EUserPresence
    clinicalRole: EClinicalRole
}
