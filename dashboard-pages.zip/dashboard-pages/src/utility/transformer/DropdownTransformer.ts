export const regionDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.regionId, label: item.regionName };
    });
    result.unshift({ "value": 0, "label": "All" })
    return result
}

export const affiliateDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.affiliateId, label: item.name };
    });

    return result
}

export const affiliateDropdownTransformerAssetConfig = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.affiliateId, label: item.affiliateName };
    });

    return result
}
export const plantDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.plantId, label: item.plantName };
    });

    return result
}

export const assetDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.assetId, label: item.assetId };
    });

    return result
}

export const modelDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.modelId, label: item.modelName };
    });
    result.unshift({ "value": 0, "label": "All" })
    return result
}

export const modelSensorDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.sensorGroupId, label: item.modelName };
    });

    return result
}
export const modelStatusDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.status, label: item.status };
    });
    result.unshift({ "value": 0, "label": "All" })
    return result
}
export const SensorDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.piName, label: item.sensorName };
    });

    return result
}
export const AlertIDDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.alertId, label: item.alertId };
    });

    return result
}
// Alert Management Drop Down
export const alertManagementAffiliatesTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.affiliateId, label: item.affiliateName };
    });

    return result
}
export const alertManagementPlantDroprdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.plantId, label: item.plantName };
    });

    return result
}
export const alertManagementAssetIdDroprdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.assetId, label: item.assetId };
    });

    return result
}
export const alertManagementAlertIdDroprdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.alertId, label: item.alertId };
    });

    return result
}
//currentstageDropdownList
export const currentstageDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.currentStage, label: item.currentStage };
    });

    return result
}
export const longLeadActionDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.value, label: item.longLeadAction };
    });

    return result
}
export const statusDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.status, label: item.status };
    });

    return result
}

// Admin Configuration
export const roleMappingRoleDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.roleId, label: item.roleName };
    });
    return result
}

export const roleMappingPlantDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.plantId, label: item.plantName };
    });
    return result
}

export const roleMappingAffiliateDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.affiliateId, label: item.affiliateName };
    });
    return result

}

export const plantAlertListStateDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.state, label: item.state };
    });
    result.unshift({ "value": 0, "label": "All" })
    return result
}

export const plantAlertListDepartmentDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.department, label: item.department };
    });
    result.unshift({ "value": 0, "label": "All" })
    return result
}

//Spare parts
export const sparePartsSensorGroupDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.sensorGroupId, label: item.sensorGroupName };
    });
    // result.unshift({ "value": 0, "label": "All" })
    return result
}
export const getAlertManagementYearDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.yearValue, label: item.yearName };
    });

    return result
}

export const getAlertManagementMonthDropdownTransformer = (data: any) => {
    let result: any[] = []
    result = data.map(function (item: any) {
        return { value: item.monthValue, label: item.monthName };
    });

    return result
}