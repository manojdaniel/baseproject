/*
 * Created on Tue Oct 26 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Icon, Message } from "semantic-ui-react"
import styles from "./PrototypeBanner.scss"
interface IProps {
    warningText: string
}

export const PrototypeBanner = (props: IProps) => {
    return <div className={styles.prototypeBanner}>
        <div className={styles.blueLine} />
        <Message className={styles.prototypeBannerMessage}>
            {props.warningText}
            <Icon className="InformationCircle" />
        </Message>
    </div>

}
