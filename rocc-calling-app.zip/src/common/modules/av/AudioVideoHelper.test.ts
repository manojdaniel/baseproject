/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { evaluateInitialVideoStatus, getActiveAndOnHoldCalls, leaveRoom, updateCallDetails } from "./AudioVideoHelper"
import * as logging from "@rocc/rocc-logging-module"
import { mockCommunication } from "./AudioVideoRoom.test"

jest.mock("../../../redux/store/externalAppStates", () => ({
    dispatchToParentStore: jest.fn(),
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        MAX_VIDEO_BITRATE: 1500000,
        MAX_SUBSCRIPTION_BITRATE: 240000,
    }),
    fetchGlobalURLs: jest.fn().mockReturnValue({
        COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl"
    })
}))

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn().mockReturnValue({
        intl: {
            formatMessage: jest.fn()
        }
    })
}))

jest.mock("../../../redux/actions/callActions", () => ({
    storeCallDetails: jest.fn(),
    setVideoCallStatus: jest.fn(),
    setCallMessage: jest.fn(),
    setOutgoingCallDetails: jest.fn(),

}))

jest.mock("../avmessages/messageService", () => ({
    getContextDetails: jest.fn().mockReturnValue({
        status: 200,
        data: {
            requester: {},
            participants: []
        }
    }),
    getCallerID: jest.fn().mockReturnValue("callerId"),
    getRequesterActualUUID: jest.fn().mockReturnValue("requesterUuid")
}))

jest.mock("../../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        callReducer: {
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    callAcceptedTime: new Date(),
                    participants: [{ uuid: "uuid" }]
                }
            },
            videoCallStatus: [{ contextId: "contextId", callStatus: "connected" }]
        },
        externalReducer: {
            currentUser: {},
            permissions: {
                CALL_VIDEO_CALL: true
            }
        }
    })
}))

jest.mock("../../../services/callServices", () => ({
    endCall: jest.fn()
}))

jest.mock("../../helpers/dateTimeUtility", () => ({
    getDurationInFormat: jest.fn().mockReturnValue("29"),
}))

const dispatch = jest.fn()
const callEndHooks = {
    preHook: jest.fn(),
    postHook: jest.fn(),
}

describe("evaluateInitialVideoStatus tests", () => {
    it("should retur true", () => {
        const currentUser: any = {
            clinicalRole: "device",
            secondaryUUID: "secondaryUUID"
        }
        expect(evaluateInitialVideoStatus(currentUser)).toBe(true)
    })

    it("should return false", () => {
        const currentUser: any = {
            clinicalRole: "device",
            secondaryUUID: ""
        }
        expect(evaluateInitialVideoStatus(currentUser)).toBe(false)
    })
})

describe("leaveRoom tests", () => {
    it("should able to leave av room", async () => {
        const room: any = {
            localParticipant: {},
            participants: [{ identity: "uuid" }],
            disconnect: jest.fn(),
        }
        const activeCall: any = {
            contextId: "contextId",
            callAcceptedTime: new Date(),
            participants: [{ uuid: "uuid" }]
        }
        jest.spyOn(logging, "sendLogsToAzure").mockImplementation(jest.fn())
        leaveRoom(activeCall, room, dispatch, await mockCommunication(), callEndHooks)
        expect(dispatch).toBeDefined()
    })


})

describe("getActiveAndOnHoldCalls tests", () => {
    it("getActiveAndOnHoldCalls", () => {
        const response = getActiveAndOnHoldCalls()
        expect(response.connectedCallDetails.contextId).toBe("contextId")
    })

})


describe("updateCallDetails tests", () => {
    const activeCall: any = {
        contextId: "contextId",
        callAcceptedTime: new Date(),
        participants: [{ uuid: "uuid" }]
    }
    it("updateCallDetails", () => {
        updateCallDetails(activeCall, dispatch, true)
        expect(dispatch).toBeDefined()
    })

})
