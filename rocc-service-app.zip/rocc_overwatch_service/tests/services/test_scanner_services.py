"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import unittest
from unittest.mock import patch
from src.constants.config_keys import VAULT_PARENT_ORG_ID
from src.services.scanner_services import ScannerService


class TestUserServices(unittest.TestCase):
    @patch("src.services.scanner_services.get_profile_data", side_effect=lambda: json.loads(json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2"})))
    @patch("src.services.scanner_services.get_client_connection")
    @patch("src.services.scanner_services.ScannerService.populate_service_token", side_effect=lambda a: [{},{},{}])
    def test_scanner_populate_service_token(self,m_profile, m_client, m_st):
        scanner_service = ScannerService(service_user_uuid="", customer_id="", user_token="")
        scanner_service._org_db_id="abc"
        m_client.return_value = {}
        scanner_service.populate_service_token("")
        m_client.assert_called()
        m_st.assert_called()
        m_profile.assert_called()

    @patch("src.services.scanner_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2"})))
    @patch("src.services.scanner_services.get_client_connection")
    @patch("src.services.scanner_services.ScannerService.populate_service_token", side_effect=lambda a: [{}, {}, {}])
    def test_scanner_populate_service_token_case2(self, m_profile, m_client, m_st):
        os.environ["VAULT_PROFILE"] = "dummy"
        scanner_service = ScannerService(service_user_uuid="", customer_id="", user_token="")
        documents = scanner_service.populate_service_token("fr-FR")
        m_client.assert_called()
        m_st.assert_called()
        m_profile.assert_called()
        self.assertIsNotNone(documents)
