/*
 * Created on Mon Nov 12 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Grid } from "semantic-ui-react"
import SVG from "react-inlinesvg"
import consoleEditIcon from "../../../assets/images/protocolTransfer.svg"
import styles from "./ProtocolTransferActiveSession.module.scss"
import en from "../../../resources/translations/en-US"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EProtocolTransferSteps } from "../../../redux/interfaces/types"
import { getLocationDetailsForId } from "@rocc/rocc-client-services"

interface IProtocolTransferActiveSession {
    locations: any
    protocolTransferStep: any
    sourceScanner: any
    destinationScanner: any
}

const ProtocolTransferActiveSession = (props: IProtocolTransferActiveSession) => {
    const { locations, protocolTransferStep, sourceScanner, destinationScanner } = props

    const selectedScanner = (protocolTransferStep === EProtocolTransferSteps.ConnectToSourceScanner) ?
        sourceScanner : destinationScanner

    const roomName = selectedScanner.identity.name
    const address = selectedScanner.address
    const location = getLocationDetailsForId(locations, selectedScanner.locationId).name
    const { intl } = getIntlProvider()

    return (
        <Grid centered={true} className={styles.protocolTransferActiveSession} id="protocolTransferActiveSession">
            <Grid.Row>
                <SVG src={consoleEditIcon} cacheRequests={true} />
            </Grid.Row>
            <Grid.Row className={styles.headerBanner}>
                {intl.formatMessage({ id: "content.protocolTransfer.editingMessagePart2", defaultMessage: en["content.protocolTransfer.editingMessagePart2"] })}
                <span>&nbsp;{roomName}</span>
            </Grid.Row>
            <Grid.Row className={styles.infoBanner}>
                <p>
                    {intl.formatMessage({ id: "content.protocolTransfer.editingMessagePart1", defaultMessage: en["content.protocolTransfer.editingMessagePart1"] })}
                    <span>&nbsp;{roomName}&nbsp;</span>
                    {intl.formatMessage({ id: "content.room.roomBannerPart2", defaultMessage: en["content.room.roomBannerPart2"] })}
                    <span>&nbsp;{address}&nbsp;</span>
                    {intl.formatMessage({ id: "content.roomBanner.message", defaultMessage: en["content.roomBanner.message"] })}
                    <span> &nbsp;{location}</span><br /><br />
                    {intl.formatMessage({ id: "content.protocolTransfer.instructionPart1", defaultMessage: en["content.protocolTransfer.instructionPart1"] })}
                    <br /><br />
                    {intl.formatMessage({ id: "content.protocolTransfer.instructionPart2", defaultMessage: en["content.protocolTransfer.instructionPart2"] })}
                </p>
            </Grid.Row>
        </Grid>
    )
}
export default ProtocolTransferActiveSession
