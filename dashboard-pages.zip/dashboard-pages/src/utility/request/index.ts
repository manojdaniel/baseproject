import axios from "axios";
import { decryptData } from "../crypto";
import { history } from "../history";

axios.interceptors.request.use(function (config) {
    return config;
});

axios.interceptors.response.use(
    (response: any) => {

        if (response.status === 401) {

            localStorage.clear();
            sessionStorage.clear();
            history.push('/AHCWeb/#/logout');
            location.reload()
        }
        return response
    },
    (error) => Promise.reject(error)
);

const request = async (options: any) => {
    return await axios(options)
        .then((response) => {

            return response;
        })
        .catch((error) => {

            if (error.code == "ECONNABORTED") {
                return {
                    message: "Request timeout",
                    error,
                };
            }
            return error;
        });
};

const getRequest = async (url: any, head?: boolean, jwtToken?: string) => {
    let headers = {};

    if (sessionStorage.getItem("state") !== null) {
        let token: string | null = "";
        token = sessionStorage.getItem("state");
        headers = {
            Authorization: `Bearer ${token ? decryptData(token) : ""}`,
            "Content-Type": "application/json",
        };
    }
    let response: any;
    let requestOptions: any;


    if (head !== undefined && head === true) {
        requestOptions = {
            url: url,
            method: "get",
            timeout: 1000 * 3000,
            validateStatus: (status) => {
                return status >= 200 && status < 500;
            },
        };
    } else {
        requestOptions = {
            url: url,
            method: "get",
            headers: headers,
            timeout: 1000 * 3000,
            validateStatus: (status) => {
                return status >= 200 && status < 500;
            },
        };

    }

    response = await request(requestOptions);
    return response;
};

const postRequest = async (url: any, params: any) => {
    let headers = {};

    if (sessionStorage.getItem("state") !== null) {
        let token: string | null = "";
        token = sessionStorage.getItem("state");
        headers = {
            Authorization: `Bearer ${token ? decryptData(token) : ""}`,
            "Content-Type": "application/json",
        };
    }
    let response;
    const requestOptions = {
        url: url,
        method: "POST",
        headers: headers,
        data: params,
        timeout: 1000 * 3000,
        validateStatus: (status) => {
            return status >= 200 && status < 500;
        },
    };

    response = await request(requestOptions);
    return response;
};

export { getRequest, postRequest };
