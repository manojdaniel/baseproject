/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import { IConfigReducer } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { SET_LOCALE, UPDATE_CONFIGS, UPDATE_PRESIGNED_URLS, UPDATE_URLS } from "../actions/types"

export const INIT_CONFIGS = {
    ADMIN_MANUAL_PATH: "",
    AV_AUTO_DISCONNECT_TIMEOUT: "",
    DEMO_CONSOLE_VIDEOS: {
        PHILIPS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
        SIEMENS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
        GE_MR_VIEWCONSOLE_DEMO_ENV_VIDEO: "",
        PHILIPS_MR_EDITCONSOLE_DEMO_ENV_VIDEO: "",
        SIEMENS_MR_EDITCONSOLE_DEMO_ENV_VIDEO: "",
        GE_MR_EDITCONSOLE_DEMO_ENV_VIDEO: "",
    },
    DEMO_ENV: "",
    QUERY_LIMIT_ADMIN_USERS: "",
    ROCC_HELPLINE: "",
    SESSION_IDLE_TIMEOUT: "",
    ROCC_DEV: "",
    PING_URL: "",
    LOG_LEVEL: "",
    INSIGHTS_KEY: "",
    CUSTOMER_ANALYTICS_LOG_CONSENT: "",
    USER_MANUAL_PATH: "",
    QUERY_LIMIT_CONTACTS: "",
    MAX_VIDEO_BITRATE: "",
    MAX_SUBSCRIPTION_BITRATE: "",
    CONSOLE_DISCONNECT_DELAY: "",
    DANGLING_CONSOLE_CONNECTIONS_CLEANUP_INTERVAL: "",
    SIGNALING_REGION: "",
    MAX_SUPPORTED_DEVICE_USB_CAMERAS: "",
    DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING: "",
    IS_PROXY: "",
    COUNTRY_ISO_CODE: "",
    REGION: "",
    EDGE_LOCATION: "",
    CRYPT_ENABLED: "",
    REGION_UKI: "",
    PRESIGNED_URL_EXPIRY_MINUTES: "",
    CUSTOMER_PRIVACY_POLICY_URL: "",
    PRESENCE_UPDATE_TIMEOUT: "",
    DEVICE_RECOVERY_TIME_IN_MINS: "",
}

export const INIT_URLS = {
    GRAPHQL_API_HSDP_URI: "",
    GRAPHQL_API_HSDP_WS_URI: "",
    COMMUNICATION_SERVICES_URL: "",
    IAM_SERVICES_URL: "",
    RBAC_SERVICE_URL: "",
    CONSOLE_SERVICES_URL: "",
    PROXY_URL: "",
    MANAGEMENT_SERVICE_URL: "",
}

export const initialStatesForConfigs: IConfigReducer = {
    configData: {
        locales: ["en-US"],
        preferredLocale: "en-US",
        theme: "default",
        language: "en",
    },
    urls: INIT_URLS,
    configs: INIT_CONFIGS,
    isProxy: "false",
    preSignedUrls: { adminUserManual: { url: "", createdAt: new Date() }, expertUserManual: { url: "", createdAt: new Date() }, nfccBundle: { url: "", createdAt: new Date(), version: "", mandatory: false } }
}

const configReducer: Reducer = (state: IConfigReducer = initialStatesForConfigs, action: any) => {
    switch (action.type) {
        case UPDATE_URLS:
            return { ...state, urls: action.urls, isProxy: action.isProxy }
        case SET_LOCALE:
            return { ...state, configData: action.configData }
        case UPDATE_CONFIGS:
            return { ...state, configs: action.configs }
        case UPDATE_PRESIGNED_URLS:
            return { ...state, preSignedUrls: action.preSignedUrls }
        default:
    }
    return { ...state }
}

export default configReducer
