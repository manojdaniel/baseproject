/*
 * Created on Thu Dec 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionState } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import { consoleDummyObject } from "../../../common/constants/constants"
import IncognitoConsoleBanner from "./IncognitoConsoleBanner"

const mockDispatch = jest.fn()
jest.mock("react-redux", () => ({
    useSelector: () => ({
        consoleSessions: [],
        consoleOperation: {
            transactions: [{ roomUuid: "123456", connectionStatus: EConnectionState.CONNECTING }]
        },
        featureFlags: {},
        permissions: []
    }),
    useDispatch: () => mockDispatch
}))
jest.mock("../../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        consoleReducer: { commandCenterDetails: { commandCenterSeat: { receivers: [{ id: "id" }] } } },
        externalReducer: { featureFlags: { "rocc-view-authorization": false } }
    })
}))

describe("Incognito Console Banner", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }

    it("should render RoomBannerTabInfo", () => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        mockUseEffect()
        const props = {
            contextId: "",
            roomUuid: "123",
            currentSession: consoleDummyObject,
            buttonTitle: false,
            technologistName: "",
            rightSidePanel: false
        }
        wrapper = shallow(<IncognitoConsoleBanner {...props} />)

        expect(wrapper.find(".roomBannerContainer").exists()).toBeTruthy()
        wrapper.find("Popup").props().trigger.props.onClick()
        expect(mockDispatch).toHaveBeenCalled()
        expect(wrapper.find("ConsoleTrigger")).toBeDefined()
    })
})
