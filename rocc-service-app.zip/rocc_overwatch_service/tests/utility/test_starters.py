"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest.mock import patch, call

from tests.mocks.random import rand_string
from tests.mocks.utility import clear_value_for_keys, drop_keys
from src.utility.starters import *


class ServerInitializationTestCase(unittest.TestCase):
    @patch("src.utility.starters.create_logger.info")
    @patch("src.utility.starters.setup_listeners")
    @patch("src.utility.starters.load_envs")
    @patch("src.utility.starters.os.environ.get")
    def test_initialize_server(self, mock_environ_getter, mock_env_load, mock_listener_setup, mock_info):
        vault_rocc_cred_path = rand_string(20)

        mock_environ_getter.return_value = vault_rocc_cred_path
        mock_environ_getter.reset_mock()

        initialize_server()

        mock_info.assert_has_calls([
            call("Initializing kibana logging"),
            call("Starting listenters setup")
        ])
        mock_environ_getter.assert_has_calls([call(VAULT_ROCC_CRED_PATH)])
        mock_env_load.assert_called_with(path_name=vault_rocc_cred_path)
        mock_listener_setup.assert_called()


class LoadEnvsTestCase(unittest.TestCase):
    def setUp(self):
        shared_key, secret_key, log_product_key = rand_string(10), rand_string(10), rand_string(10)
        self.profile_configs = {
            VAULT_SHARED_KEY: shared_key,
            VAULT_SECRET_KEY: secret_key,
            VAULT_LOG_PRODUCT_KEY: log_product_key,
        }

        self.vault_values = {
            DATA: {
                "signatureAuthSharedKey": shared_key,
                "signatureAuthSecretKey": secret_key,
                "logProductKey": log_product_key
            }
        }

        self.expected_environ = {
            API_SIGNATURE_SHARED_KEY: shared_key,
            API_SIGNATURE_SECRET_KEY: secret_key,
            VAULT_LOG_PRODUCT_KEY: log_product_key
        }

        self.os_environ_mock_dict = {
            API_SIGNATURE_SHARED_KEY: "",
            API_SIGNATURE_SECRET_KEY: "",
            VAULT_LOG_PRODUCT_KEY: ""
        }

        self.local_info_string = "Loading API_SIGNATURE_SHARED_KEY, API_SIGNATURE_SECRET_KEY and LOG_PRODUCT_KEY in the env"
        self.cf_info_string = "Loading API_SIGNATURE_SHARED_KEY, API_SIGNATURE_SECRET_KEY and LOG_PRODUCT_KEY in the CF env"

    @patch("src.utility.starters.create_logger.info")
    def test_load_envs_profile_config(self, mock_info):
        expected_environ = self.expected_environ
        with patch.dict("src.utility.starters.os.environ", self.os_environ_mock_dict, clear=True) as mock_environ:
            env_loaded = load_envs(profile_configs=self.profile_configs)
            mock_info.assert_called_with(self.local_info_string)
            if mock_environ:
                """ TODO: Check why mock_environ is not having expected values """
                self.assertDictEqual(expected_environ, dict(mock_environ))

        self.assertTrue(env_loaded)

    @patch("src.utility.starters.create_logger.error")
    def test_load_envs_profile_config_exception(self, mock_error):
        profile_configs = drop_keys(self.profile_configs, [VAULT_SECRET_KEY])

        expected_environ = clear_value_for_keys(self.expected_environ, [API_SIGNATURE_SECRET_KEY, VAULT_LOG_PRODUCT_KEY])

        with patch.dict("src.utility.starters.os.environ", self.os_environ_mock_dict, clear=True) as mock_environ:
            env_loaded = load_envs(profile_configs=profile_configs)

            mock_error.assert_called()
            if mock_environ:
                """ TODO: Check why mock_environ is not having expected values """
                self.assertDictEqual(expected_environ, dict(mock_environ))

        self.assertFalse(env_loaded)

    @patch("src.utility.starters.create_logger.info")
    @patch("src.utility.starters.get_path_specific_vault_values")
    @patch("src.utility.starters.os.environ.get")
    def test_load_envs_vault_values(self, mock_environ_getter, mock_vault_values, mock_info):
        path_name = rand_string(10)
        mock_environ_getter.return_value = "dev"
        mock_vault_values.return_value = self.vault_values

        expected_environ = self.expected_environ

        with patch.dict("src.utility.starters.os.environ", self.os_environ_mock_dict, clear=True) as mock_environ:
            env_loaded = load_envs(path_name=path_name, vault_credentials_response=self.vault_values)

            mock_info.assert_called_with(self.cf_info_string)
            mock_environ_getter.assert_called_with("ENV_TYPE", "dev")
            mock_vault_values.assert_called_with(path_name, self.vault_values)
            if mock_environ:
                """ TODO: Check why mock_environ is not having expected values """
                self.assertDictEqual(expected_environ, dict(mock_environ))

        self.assertTrue(env_loaded)

    @patch("src.utility.starters.create_logger.error")
    @patch("src.utility.starters.get_path_specific_vault_values")
    @patch("src.utility.starters.os.environ.get")
    def test_load_envs_vault_values_no_data_exception(self, mock_environ_getter, mock_vault_values, mock_error):
        path_name = rand_string(10)
        mock_environ_getter.return_value = "dev"
        mock_vault_values.return_value = drop_keys(self.vault_values, [DATA])

        expected_environ = clear_value_for_keys(self.expected_environ, [API_SIGNATURE_SHARED_KEY, API_SIGNATURE_SECRET_KEY, VAULT_LOG_PRODUCT_KEY])

        with patch.dict("src.utility.starters.os.environ", self.os_environ_mock_dict, clear=True) as mock_environ:
            env_loaded = load_envs(path_name=path_name, vault_credentials_response=self.vault_values)

            mock_error.assert_called()
            mock_environ_getter.assert_called_with("ENV_TYPE", "dev")
            mock_vault_values.assert_called_with(path_name, self.vault_values)
            if mock_environ:
                """ TODO: Check why mock_environ is not having expected values """
                self.assertDictEqual(expected_environ, dict(mock_environ))

        self.assertFalse(env_loaded)

    @patch("src.utility.starters.create_logger.error")
    @patch("src.utility.starters.get_path_specific_vault_values")
    @patch("src.utility.starters.os.environ.get")
    def test_load_envs_vault_values_exception(self, mock_environ_getter, mock_vault_values, mock_error):
        path_name = rand_string(10)
        mock_environ_getter.return_value = "dev"
        mock_vault_values.return_value = {DATA: drop_keys(self.vault_values[DATA], ["signatureAuthSecretKey"])}

        expected_environ = clear_value_for_keys(self.expected_environ, [API_SIGNATURE_SECRET_KEY, VAULT_LOG_PRODUCT_KEY])

        with patch.dict("src.utility.starters.os.environ", self.os_environ_mock_dict, clear=True) as mock_environ:
            env_loaded = load_envs(path_name=path_name, vault_credentials_response=self.vault_values)

            mock_error.assert_called()
            mock_environ_getter.assert_called_with("ENV_TYPE", "dev")
            mock_vault_values.assert_called_with(path_name, self.vault_values)
            if mock_environ:
                """ TODO: Check why mock_environ is not having expected values """
                self.assertDictEqual(expected_environ, dict(mock_environ))

        self.assertFalse(env_loaded)
