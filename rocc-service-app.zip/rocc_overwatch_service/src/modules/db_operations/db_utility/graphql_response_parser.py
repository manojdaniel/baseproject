"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import ID, RETURNING

from src.loggers.log import create_logger

LOG = create_logger("GraphqlResponseParser")


def check_if_id_is_present(data, table_name):
    return data[table_name][0][ID] if len(data[table_name]) > 0 else False


def check_if_field_is_present(data, table_name, field_name):
    return data[table_name][0][field_name] if len(data[table_name]) > 0 else False


def extract_id_and_field_from_response(data, table_name, field_name):
    return data[table_name][0][ID] if len(data[table_name]) > 0 else False, data[table_name][0][field_name] if len(data[table_name]) > 0 else False


def extract_items_from_result(data, table_name, item_name):
    items_list = []
    try:
        if len(data[table_name]) > 0:
            for item in data[table_name]:
                items_list.append(item[item_name])
        return items_list
    except Exception as ex:
        LOG.exception(f"Error while parsing sites from DB result: {ex}")
        return []


def extract_data_items_from_result(data, table_name, item_name):
    items_list = []
    try:
        if len(data[table_name]) > 0:
            for item in data[table_name]:
                items_list.append(item[item_name][0])
        return items_list
    except Exception as ex:
        LOG.exception(f"Error while parsing sites from DB result: {ex}")
        return []


def extract_data_from_table(data, table_name):
    return data[table_name]


def extract_id_from_mutation_response(data, table_name):
    return data[table_name][RETURNING][0][ID]


def extract_response_from_mutation_response(data, table_name):
    return data[table_name][RETURNING]


def extract_id_from_query_response(data, table_name):
    return data[table_name][0][ID]


def update_dicts_with_inserted_ids(dicts, results, item_id_name, item_excel_header, result_unique_name):
    """
    Example:
    for item in result:
        for key, room in rooms.items():
            if room[EXCEL_ROOM_IDENTIFIER] == item["resource"]:
                room["resource_id"] = item[ID]
    """
    for result in results:
        for _, item in dicts.items():
            if item[item_excel_header] == result[result_unique_name]:
                item[item_id_name] = result[ID]
    return dicts


def get_aggregate_count(data, table_name):
    return data[table_name]["aggregate"]["count"]
