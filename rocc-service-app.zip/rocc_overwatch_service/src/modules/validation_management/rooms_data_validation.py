"""
 Created on Tue Nov 3 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import ROOMS_DICT
from src.constants.enums import ESummaryStates
from src.constants.headers import EXCEL_ROOM_IDENTIFIER
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.validation_service.rooms_data_validation_service import check_if_rooms_exists
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("RoomsDataValidation")


class RoomsDataValidation:

    def __init__(self, service_token, org_infra_uuid):
        LOG.info("Rooms Data validation started ..!!")
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)

    def check_if_room_detail_exists(self, room_dict):
        new_rooms = self._transaction_data["summary"]["rooms"]["new"]
        for room_identifier, room_detail in room_dict.items():
            if room_identifier in new_rooms:
                resource_id = check_if_rooms_exists(client=self._client, room_dict=room_detail)
                if not resource_id:
                    self._transaction_data = update_summary_for_entity(self._transaction_data, "rooms", room_identifier, ESummaryStates.VALIDATION_FAILED)
                    LOG.info(f"Room data for resource,{room_detail[EXCEL_ROOM_IDENTIFIER]} is not present")
                    room_detail["isPresent"] = False
                else:
                    LOG.info(f"Room data for resource,{room_detail[EXCEL_ROOM_IDENTIFIER]} is present")
            else:
                LOG.info(f"This room {room_identifier} is not a new room, skipping validation ..!")
        return room_dict, self._transaction_data

    def initiate_data_validation(self, data_dict, transaction_data):
        self._rooms_dict = data_dict[ROOMS_DICT]
        self._transaction_data = transaction_data
        self._rooms_dict, self._transaction_data = self.check_if_room_detail_exists(room_dict=self._rooms_dict)
        LOG.info("Rooms Data validation complete ..!!")
        return data_dict, self._transaction_data
