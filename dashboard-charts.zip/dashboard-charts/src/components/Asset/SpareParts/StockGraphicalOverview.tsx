// @ts-nocheck
import React, { useState, useEffect } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import HighchartsExporting from "highcharts/modules/exporting";

HighchartsExporting(Highcharts);
Highcharts.AST.allowedAttributes.push("onclick");

interface Props {
	GraphicalImageByAssetId: any[];
	mysensorGroupId: any;
	AnomalyModelbyAssetId: any[];
}
const StockGraphicalOverview = ({
	GraphicalImageByAssetId,
	mysensorGroupId,
	AnomalyModelbyAssetId,
}: Props) => {
	const [getGraphicalData, setGraphicalData] = useState<any[]>(
		AnomalyModelbyAssetId
	);
	const [imageData, setImageData] = useState<any>("");
	const AnomalyModelbyAssetIdCopy = [...AnomalyModelbyAssetId]; // Creating copy of AnomalyModelbyAssetId due to chart bug.

	// P-F-CURVE - Failure Prediction --- End========================================

	useEffect(() => {
		if (GraphicalImageByAssetId && GraphicalImageByAssetId.length > 0) {
			setImageData(GraphicalImageByAssetId[0].image);
		}
	}, [GraphicalImageByAssetId]);

	useEffect(() => {
		mysensorGroupId !== ""
			? setGraphicalData(
					AnomalyModelbyAssetId.filter(
						({ sensorGroupId }) => sensorGroupId === mysensorGroupId
					)
			  )
			: setGraphicalData(AnomalyModelbyAssetId);
	}, [mysensorGroupId]);

	//==================Globalfailureprediction filter data ==================================
	let Globalfailureprediction = [];
	AnomalyModelbyAssetId.forEach((device: any, index: any) => {
		Globalfailureprediction[index] = { ...device };
	});
	let getfailureprediction = [];
	for (var i = 0; i < Globalfailureprediction.length; i++) {
		if (Globalfailureprediction[i].rul !== -999) {
			let localdata = {
				modelName: Globalfailureprediction[i].modelName,
				modelId: Globalfailureprediction[i].modelId,
				rul: Globalfailureprediction[i].rul,
				confidenceFactor: Globalfailureprediction[i].confidenceFactor,
			};
			getfailureprediction.push(localdata);
		}
	}
	//======================END===============================================================

	// Navigation of tooltip=========================================================
	// (function (H) {
	// 	H.wrap(H.Tooltip.prototype, "refresh", function (proceed) {
	// 		proceed.apply(this, Array.prototype.slice.call(arguments, 1));

	// 		<div>
	// 			<span> Description</span>
	// 			<span> Compressor </span>
	// 		</div>;
	// 	});
	// })(Highcharts);
	//===================End navigation tooltip========================================

	const getHighcharts = () => ({
		chart: {
		  type: "scatter",
		  zoomType: 'xy',
		  backgroundColor: '#ffffff',
		  plotBackgroundImage: `${imageData}`,
		},
		title: {
		  text: null
		},
		xAxis: {
		  visible: false,
		  min: 0, max: 100
		},
		yAxis: {
		  visible: false,
		  min: 0, max: 100
		},
	
		navigation: {
		  buttonOptions: {
			theme: {
			  states: {
				hover: {
				  fill: '#fff'
				},
				select: {
				  fill: '#f7f8fa'
				}
			  }
			}
		  },
		  menuItemStyle: {
			fontWeight: 'normal',
			color: '#4d4d4d'
		  },
		  menuItemHoverStyle: {
			fontWeight: 'bold',
			background: '#009FDF',
			color: '#fff'
		  }
		},
		plotOptions: {
		  series:{stickyTracking: false},
		  scatter: {
			marker: {
			  radius: 12.5,
			  symbol: 'square',
			  lineWidth: 0.5,
			  lineColor: "black",
			  states: {
				hover: {
				  enabled: true,
				}
			  }
			},
			states: {
			  hover: {
				marker: {
				  enabled: false
				}
			  }
			},
	
		  },
		},
		tooltip: {
		  // followPointer: true,
		  useHTML: true,
		  backgroundColor: '#000000',
		  borderRadius: 10,
		  borderColor: '#000000',
		  valueDecimals: 2,
		  animation: false,
		  font: 'SabicRegular',
		  style: {
			color: 'white',
			opacity: 0.8,
			shadow: '0px 3px 6px #000000',
			// pointerEvents: 'painted'
		  },
		  hideDelay: 3000,
		  formatter() {
			const {
			  point
			} = this;
			return `<div><style> colgroup {border:1px solid white;} </style><table style="width:100%"><tr><td>Description</td><td>HP Case Diaphragm</td></tr><tr><td>Zero Stock </td><td>${point.maxRange}</td></tr><tr><td>No. Of Spare Parts</td><td>${point.minRange}</td></tr></table></div>`;
		  }
		},
		series: [{
		  showInLegend: false,
		  data: mysensorGroupId !== undefined ? getGraphicalData : AnomalyModelbyAssetIdCopy,
		}]
	
	  });

	return (
		<>
			<HighchartsReact highcharts={Highcharts} options={getHighcharts()} />
		</>
	);
};

export default StockGraphicalOverview;
