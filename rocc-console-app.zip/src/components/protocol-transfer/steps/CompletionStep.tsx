/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Icon } from "semantic-ui-react"
import cx from "classnames"
import styles from "../ProtocolTransfer.scss"
import { useDispatch, useSelector } from "react-redux"
import { Button, Grid } from "semantic-ui-react"
import en from "../../../resources/translations/en-US"
import { EGridWidth, ILeaveProtocolTransferConfirmProps, IStore } from "../../../redux/interfaces/types"
import ProtocolTransferWizardContent from "../ProtocolTransferWizardContent"
import { sourceContent, destinationContent } from "./StepUtility"
import { GLOBAL_SET_ACTIVE_TAB } from "../../../redux/actions/types"
import { dispatchToParentStore, fetchGlobalCurrentUser } from "../../../redux/store/externalAppStates"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { initLeaveProtocolTransferDlgModel } from "../../../common/constants/constants"
import { resetAllStates, resetDestination } from "../../../redux/actions/protocolTransferActions"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EXCLUDED_SRC_MSG } from "../ProtocolTransfer"

const componentName = "CompletionStep"

interface ICompleteStep {
    setLeaveProtocolTransferDlg: (props: ILeaveProtocolTransferConfirmProps) => void
}

const CompletionStep = (props: ICompleteStep) => {

    const { setLeaveProtocolTransferDlg } = props
    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const {
        selectedSource
    } = useSelector((state: IStore) => ({
        selectedSource: state.protocolTransferReducer.selectedSource
    }))

    const currentUser = fetchGlobalCurrentUser()

    const setFirstStep = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: "Start new protocol transfer session", Event_By: currentUser.uuid } })
        dispatch(resetAllStates())
    }

    const setThirdStep = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: `Select another destination for room: ${selectedSource.identity.uuid}`, Event_By: currentUser.uuid } })
        dispatch(resetDestination())
        infoLogger(`${selectedSource.identity.name} ${EXCLUDED_SRC_MSG} `)
    }

    const startNewTransferButton = () => (
        <Button
            id={"startProtocolTransfer"}
            active={true}
            onClick={setFirstStep}
            className={cx(styles.protocolTransferButton, styles.startNewTransfer)}
        >
            {intl.formatMessage({ id: "content.protocolTransfer.startNewTransfer", defaultMessage: en["content.protocolTransfer.startNewTransfer"] })}
        </Button>
    )

    const anotherDestinationButton = () => (
        <Button
            id={"transferToNewDestination"}
            active={true}
            onClick={setThirdStep}
            className={cx(styles.protocolTransferButton, styles.selectNewDestination)}
        >
            {intl.formatMessage({ id: "content.protocolTransfer.nextDestinationSelection", defaultMessage: en["content.protocolTransfer.nextDestinationSelection"] })}
        </Button>
    )

    const onLeaveProtocolTransferDlgClosed = () => {
        setLeaveProtocolTransferDlg(initLeaveProtocolTransferDlgModel)
        dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: 0 } })
    }

    const handleLeaveProtocolTransfer = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: "Clicked leave protocol transfer button", Event_By: currentUser.uuid } })
        const leaveProtocolTransferDlgModelObject: ILeaveProtocolTransferConfirmProps = {
            show: true,
            postConfirmCallback: () => { "" },
            onDialogClosed: onLeaveProtocolTransferDlgClosed
        }
        setLeaveProtocolTransferDlg(leaveProtocolTransferDlgModelObject)
    }

    const leaveProtocolTransfer = () => (
        <Button
            id={"leaveProtocolTransfer"}
            active={true}
            onClick={handleLeaveProtocolTransfer}
            className={cx(styles.protocolTransferButton, styles.leaveProtocolTransfer)}
        >
            {intl.formatMessage({ id: "content.protocolTransfer.leaveProtocolTransferButton", defaultMessage: en["content.protocolTransfer.leaveProtocolTransferButton"] })}
        </Button>
    )

    const lastStepButtons = () => (
        <Grid.Row className={styles.lastStepGridRow}>
            <Grid.Column className={cx(styles.protocolTransferGridColumn)} width={EGridWidth.FOUR}>
                {startNewTransferButton()}
            </Grid.Column>
            <Grid.Column className={cx(styles.protocolTransferGridColumn)} width={EGridWidth.FOUR}>
                {anotherDestinationButton()}
            </Grid.Column>
            <Grid.Column className={cx(styles.protocolTransferGridColumn)} width={EGridWidth.FOUR}>
                {leaveProtocolTransfer()}
            </Grid.Column>
        </Grid.Row>
    )

    const stepMessageContent = () => (
        <>
            <Icon className={cx("icon CheckmarkCircle", styles.completionStepIcon)} />
            {intl.formatMessage({ id: "content.protocolTransfer.transferProtocolCompleted", defaultMessage: en["content.protocolTransfer.transferProtocolCompleted"] })}
        </>
    )

    return <ProtocolTransferWizardContent sourceScannerContent={sourceContent(false)}
        destinationScannerContent={destinationContent(false)}
        stepMessageContent={stepMessageContent()}
        completionStepUI={lastStepButtons()} />
}

export default CompletionStep
