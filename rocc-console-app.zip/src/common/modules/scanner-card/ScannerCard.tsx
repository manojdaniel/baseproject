/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Card, Grid } from "semantic-ui-react"
import MRImage from "../../../assets/images/MR.svg"
import CTImage from "../../../assets/images/CT.svg"
import SVG from "react-inlinesvg"
import React from "react"
import styles from "./ScannerCard.scss"
import cx from "classnames"
import { EModalityType, IRoomDetails } from "@rocc/rocc-client-services"

interface IScannerDetails {
    room: IRoomDetails,
    hospitalLoc: String,
    isHighlighted: boolean,
}

const getModalityImage = (modality: string) => {
    return `${modality === EModalityType.CT ? CTImage : (modality === EModalityType.MR ? MRImage : "")}`
}

const ScannerCard = (props: IScannerDetails) => {
    return <div className={cx(styles.rectangle, (props.isHighlighted ? styles.Highlighted : null))}>
        <Card id="scannerCard" className={styles.card}>
            <Card.Content className={styles.content}>
                <Grid className={styles.grid}>
                    <Grid.Column className={styles.scannerImageColumn} >
                        <div className={props.room.modality === EModalityType.CT ? styles.ct : styles.mr}>
                            <SVG src={getModalityImage(props.room.modality)} className={props.room.modality === EModalityType.CT ? styles.ctBody : styles.mrBody} />
                        </div>
                    </Grid.Column>
                    <Grid.Column className={styles.scannerDetailsColumn}>
                        <Card.Description className={cx(styles.label, styles.textAlignment)}>
                            {props.hospitalLoc}
                        </Card.Description>
                        <Card.Description className={cx(styles.title, styles.textAlignment)}>
                            {props.room.identity.name}
                        </Card.Description>
                        <Card.Description className={cx(styles.subTitle, styles.textAlignment)}>
                            {props.room.address}
                        </Card.Description>
                    </Grid.Column>
                </Grid>
            </Card.Content>
        </Card>
    </div>
}

export default ScannerCard
