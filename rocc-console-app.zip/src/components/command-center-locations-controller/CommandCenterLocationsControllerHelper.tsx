/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { parseIntBase10 } from "@rocc/rocc-client-services"
import { LOCATION_NAME, SEP } from "../../common/constants/constants"
import { ICommandCenter, IReceiver } from "../../redux/interfaces/types"
import orderBy from "lodash.orderby"
import { fetchReceiversForASeatService } from "./CommandCenterLocationsControllerService"

export const setCommandCenterSeatService = (locationName: string, organizationId: number) => {
    const commandCenterSeat = `${locationName}${SEP}${organizationId.toString()}`
    localStorage.setItem(LOCATION_NAME, commandCenterSeat)
}

export const getCommandCenterSeatService = (orgId: string) => {
    let seatName = ""
    let organizationId = 0
    const commandCenterSeat = localStorage.getItem(LOCATION_NAME)
    if (commandCenterSeat) {
        seatName = commandCenterSeat.split(SEP)[0]
        organizationId = parseIntBase10(orgId)
        setCommandCenterSeatService(seatName, organizationId)
    }
    return { seatName, organizationId }
}

export const checkIfTwoObjectsAreEqual = (ob1: any, ob2: any) => JSON.stringify(ob1) === JSON.stringify(ob2)

export const fetchReceiverTransformer = async (dbOrgId: string, seatName: string) => {
    let receivers: IReceiver[] = []
    const result = await fetchReceiversForASeatService(dbOrgId, seatName)
    result.forEach((element: any) => {
        receivers.push({ id: element.id, receiverName: element.receiverName, monitorName: element.monitorName, isSelected: false })
    })
    if (receivers) {
        receivers = orderBy(receivers, ["monitorName"])
    }
    return receivers
}

export const getLocalStorageItem = (item: string) => {
    return localStorage.getItem(item)
}

export const setLocalStorageItem = (item: string, value: string) => {
    localStorage.setItem(item, value)
}

export const getCommandCenterLocationName = (commandCenterLocations: ICommandCenter[], seatName: string) => {
    return commandCenterLocations.find(seat => seat.seatName === seatName)
}
