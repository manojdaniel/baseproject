import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";

import ListComponent from "./index";

const mockItem = {
	name: "test item",
	image: "test.png",
	healthIndexTrend: true,
	healthIndex: 50,
	pmCompliance: 70,
	active: 2,
	underInvestigation: 1,
	overdueTrend: 1,
	overdue: 3,
};

describe("ListComponent", () => {
	it('renders item name when title is not "AFFILIATE"', () => {
		render(
			<ListComponent
				item={mockItem}
				title="not affiliate"
				handleOnClick={undefined}
			/>
		);
		expect(screen.getByText("test item")).toBeInTheDocument();
	});

	it('renders item image when title is "AFFILIATE"', () => {
		render(
			<ListComponent
				item={mockItem}
				title="AFFILIATE"
				handleOnClick={undefined}
			/>
		);
		expect(screen.getByRole("img")).toBeInTheDocument();
	});

	it("calls handleOnClick when clicked", () => {
		const mockHandleOnClick = jest.fn();
		render(
			<ListComponent
				item={mockItem}
				title="not affiliate"
				handleOnClick={mockHandleOnClick}
			/>
		);
		screen.getByText("test item").click();
		expect(mockHandleOnClick).toHaveBeenCalledWith(mockItem);
	});

	it("renders health index with correct trend arrow and value", () => {
		render(<ListComponent item={mockItem} title="not affiliate" />);
		expect(screen.getByText("HEALTH INDEX")).toBeInTheDocument();
		expect(screen.getByText("50%")).toBeInTheDocument();
		expect(
			screen.getByRole("img", { name: "table-uparrow-blue" })
		).toBeInTheDocument();
	});

	it("renders pm compliance with correct value", () => {
		render(<ListComponent item={mockItem} title="not affiliate" />);
		expect(screen.getByText("PM COMPLIANCE")).toBeInTheDocument();
		expect(screen.getByText("70%")).toBeInTheDocument();
	});

	it("renders active alerts with correct value", () => {
		render(<ListComponent item={mockItem} title="not affiliate" />);
		expect(screen.getByText("ACTIVE ALERTS")).toBeInTheDocument();
		expect(screen.getByText("2")).toBeInTheDocument();
	});

	it("renders under investigation with correct value", () => {
		render(<ListComponent item={mockItem} title="not affiliate" />);
		expect(screen.getByText("UNDER INVESTIGATION")).toBeInTheDocument();
		expect(screen.getByText("1")).toBeInTheDocument();
	});

	it("renders overdue investigation with correct trend arrow and value", () => {
		render(<ListComponent item={mockItem} title="not affiliate" />);
		expect(screen.getByText("OVERDUE INVESTIGATION")).toBeInTheDocument();
		expect(screen.getByText("3")).toBeInTheDocument();
		expect(
			screen.getByRole("img", { name: "table-uparrow-red" })
		).toBeInTheDocument();
	});
});
