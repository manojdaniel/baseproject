import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import UtilizationReportTable from "./UtilizationReportTable";
import { Table } from "antd";

jest.mock("antd", () => ({
	Table: jest.fn(() => null),
}));

describe("UtilizationReportTable", () => {
	it("should render table columns correctly", () => {
		const data = [
			{
				Affiliate: "Affiliate 1",
				Plant: "Plant 1",
				OverDueCount: 1,
				WorkInProgressCount: 2,
				NotAssignedCount: 3,
				ClosedCount: 4,
			},
			{
				Affiliate: "Affiliate 2",
				Plant: "Plant 2",
				OverDueCount: 5,
				WorkInProgressCount: 6,
				NotAssignedCount: 7,
				ClosedCount: 8,
			},
		];
		render(<UtilizationReportTable data={data} />);
		expect(Table).toHaveBeenCalledWith(
			{
				columns: expect.any(Array),
				dataSource: data,
				pagination: { pageSize: 2 },
				scroll: { y: 200 },
			},
			{}
		);
	});
});
