/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import cx from "classnames"
import styles from "./EmptyScanner.scss"
import { getIntlProvider } from "@rocc/rocc-global-components"

interface IEmptyScanner {
    messageId: string
    defaultMessage: string
    isHighlighted: boolean
}

const EmptyScanner = (props: IEmptyScanner) => {
    const { messageId, defaultMessage, isHighlighted } = props

    const { intl } = getIntlProvider()

    return (
        <div className={cx(styles.emptyScanner, styles.containerDiv, isHighlighted ? styles.highlighted : "")}>
            <div className={cx(styles.emptyScanner, styles.contentDiv, isHighlighted ? styles.highlighted : "")}>
                {intl.formatMessage({ id: messageId, defaultMessage: defaultMessage })}
            </div>
        </div>
    )
}

export default EmptyScanner
