import React from "react"
import { Table, Icon, Checkbox, SemanticWIDTHS } from "semantic-ui-react"
import { ITableColumn, ITableHeader } from "../types"

const PDVTableHeader: React.FC<ITableHeader> = ({ columns, sortColumn, multiSelect, onSort }) => {
    const gridWidth = 12
    const colWidth = Math.floor(gridWidth / columns.length)

    const raiseSort = (field: string, order?: string) => {
        const column = { ...sortColumn }
        if (column.path === field) {
            column.order = (column.order === "asc") ? "desc" : "asc"
        } else {
            column.path = field
            column.order = "asc"
        }
        if (order) {
            column.order = order
        }
        onSort(column)
    }

    return (
        <Table.Header fullWidth>
            <Table.Row>
                {columns.map((column: ITableColumn, index: number) => {
                    const { label, path, key, display, width, className } = column
                    return display && <Table.HeaderCell key={key || path} className={`sorted ${className}`}
                        width={width ? width as SemanticWIDTHS : Number(colWidth) as SemanticWIDTHS}
                    >
                        {multiSelect && index === 0 &&
                            <Checkbox label="" />
                        }
                        <span onClick={() => raiseSort(path)}>{label}</span>
                        <Icon.Group>
                            {/* <Icon link corner={true} onClick={() => raiseSort(path, "asc")} className={`ArrowUp top right ${sortColumn.path === path && sortColumn.order === "asc" ? "active" : ""}`} />
                            <Icon link corner={true} onClick={() => raiseSort(path, "desc")} className={`ArrowDown bottom right ${sortColumn.path === path && sortColumn.order === "desc" ? "active" : ""}`} /> */}
                        </Icon.Group>
                    </Table.HeaderCell>
                })}
            </Table.Row>
        </Table.Header>
    )
}

export default PDVTableHeader