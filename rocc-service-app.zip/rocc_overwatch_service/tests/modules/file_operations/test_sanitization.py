import unittest
from src.modules.file_operations.sanitization import sanitize_dicts

class SanitizeTest(unittest.TestCase):
    def test_sanitize_dicts(self):
        documents = sanitize_dicts({})
        self.assertIsNotNone(documents)
