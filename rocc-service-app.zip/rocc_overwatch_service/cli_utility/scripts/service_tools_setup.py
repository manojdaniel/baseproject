"""
 Created on Thu Nob 19 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

from cli_utility.scripts.utility import CONF, fetch_profile_configs_for_cli, prompt_and_get_rocc_url
from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_HSDP_IAM_URL
from src.constants.constants import COMPLETED, ROCC_PROXY_URL
from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs
from src.modules.parent_org_setup.service_tools_infra_setup import ServiceToolsInfraSetup
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.rbac_services.rbac_services import setup_fse_rbac_role_mappings_for_parent_org

"""
Service tool setup:
    1. During root org creation (One time activity) 
    HSDP (below steps have to be done manually since this only one time activity)
        - Create a service "servicetoolservice" in ROCCDevClientOrg (Root org)
        - Capture the following values and store them in Vault path /ServiceConfigs: 
            - SERVICE_AUTH_ISSUER
            - SERVICE_AUTH_NAME
            - SERVICE_AUTH_PRIVATE_KEY
        - Create Role SERVICEROLE and add the following permissions:
            1. CLIENT.SCOPE (raise a ticket for this particular permission)
            2. APPLICATION.READ, APPLICATION.WRITE, APPLICATION.DELETE
            3. CLIENT.READ, CLIENT.WRITE
            4. DEVICE.READ, DEVICE.WRITE
            5. EMAILTEMPLATE.READ, EMAILTEMPLATE.WRITE
            6. GROUP.READ, GROUP.WRITE
            7. HSDP_IAM_ORGANIZATION.READ, HSDP_IAM_ORGANIZATION.DELETE
            8. MDM-APPLICATION.CREATE, MDM-APPLICATION.READ, MDM-DEVICEGROUP.CREATE, MDM-DEVICEGROUP.READ
               MDM-DEVICETYPE.CREATE, MDM-DEVICETYPE.READ, MDM-OAUTHCLIENT.CREATE, MDM-OAUTHCLIENT.READ, MDM-OAUTHCLIENT.UPDATE,
               MDM-OAUTHCLIENTSCOPE.CREATE, MDM-OAUTHCLIENTSCOPE.READ, MDM-OAUTHCLIENTSCOPE.UPDATE,
               MDM-PROPOSITION.CREATE, MDM-PROPOSITION.READ, MDM-PROPOSITION.UPDATE (need to check if these can be removed for root org token. Mostly yes)
            9. ORGANIZATION.WRITE
            10. POLICY.WRITE
            11. PROPOSITION.READ, PROPOSITION.WRITE
            12. ROLE.READ, ROLE.WRITE
            13. SERVICE.READ, SERVICE.WRITE
            14. USER.READ, USER.WRITE
        - Create a GROUP "ServiceGroup"
            * Add the SERVICEROLE in ROLES
            * Add the service "servicetoolservice" in Services 
 
    2. Need to add root-org ID to allowedOrg table in IAM (Since we will be using root org service token for graphql queries/mutations)
    3. While setting up the parent org (eg rocc-dev) create a Scope policy "service-tools-policy" and add the below endpoints (this will be automated through the Service tool CLI)
        - "resources": [
                "https://*/philips/rocc/usermgmt/UserActions/bulk*?*",
                "https://*/philips/rocc/usermgmt/Users*?*",
                "https://*/philips/rocc/OrgRole*?*",
                "http://*apps.internal:8080/philips/rocc/OrgRole*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Users/bulk*?*",
                "https://*/philips/rocc/redismgmt/Redis*?*",
                "http://*apps.internal:8080/philips/rocc/redismgmt/Redis*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Group*?*",
                "http://*apps.internal:8080/philips/rocc/redismgmt/*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Users*?*",
                "http://*apps.internal:8080/philips/rocc/UserRoleMapping/bulk*?*",
                "https://*/philips/rocc/usermgmt/Group*?*",
                "http://*apps.internal:8080/philips/rocc/RolePermissionMapping*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/UserActions/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/admin/Organisation*?*",
                "https://*/philips/rocc/UserRoleMapping/bulk*?*",
                "https://*/philips/rocc/Role*?*",
                "https://*/philips/rocc/usermgmt/Users/bulk*?*",
                "https://*/philips/rocc/UserRoleMapping*?*",
                "http://*apps.internal:8080/philips/rocc/Role*?*",
                "https://*/philips/rocc/admin/Organisation*?*",
                "https://*/philips/rocc/RolePermissionMapping*?*",
                "http://*apps.internal:8080/philips/rocc/UserRoleMapping*?*",
                "https://*/philips/rocc/redismgmt/*?*"
            ],
            "actions": {
                "DELETE": true,
                "POST": true,
                "PUT": true,
                "GET": true
            },
    
    4. Need to have a service CF account to execute CF commands through the script (Bharath is following up with HSDP)

"""

LOG = create_logger("ServiceToolsSetup")


def setup_service_tools(user_details):
    profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
    rocc_proxy_url = prompt_and_get_rocc_url()
    os.environ[ROCC_PROXY_URL] = rocc_proxy_url
    vault_cred_path = CONF.get("VAULT", "ROCC_CRED_PATH")
    task_service_tools_setup(vault_cred_path=vault_cred_path,
                             vault_credentials_response=vault_credentials_response,
                             rocc_proxy_url=rocc_proxy_url,
                             profile_configs=profile_configs,
                             user_details=user_details)
    task_to_create_rbac_roles(profile_configs=profile_configs, proxy_url=rocc_proxy_url, vault_credentials_response=vault_credentials_response, user_details=user_details)


def task_service_tools_setup(vault_cred_path, vault_credentials_response, rocc_proxy_url, profile_configs, user_details):
    ob = ServiceToolsInfraSetup()
    status = ob.start_job(vault_cred_path=vault_cred_path,
                          vault_credentials_response=vault_credentials_response,
                          rocc_proxy_url=rocc_proxy_url,
                          profile_configs=profile_configs,
                          user_details=user_details)
    return status


def task_to_create_rbac_roles(profile_configs, proxy_url, vault_credentials_response, user_details):
    setup_fse_rbac_role_mappings_for_parent_org(proxy_url=proxy_url,
                                                profile_configs=profile_configs,
                                                vault_credentials_response=vault_credentials_response,
                                                org_id=profile_configs[VAULT_PARENT_ORG_ID],
                                                user_uuid=user_details["userId"])
    parent_token = create_service_token_from_vault(iam_url=profile_configs[VAULT_HSDP_IAM_URL],
                                                   issuer=profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                   private_key=profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
    prepare_and_post_audit(event_type=EJobs.RBAC_INFRA_SETUP.value, event_subtype="Parent org Rbac infra setup", action="C", outcome=0,
                           user_detail=user_details["userId"],
                           org_id=profile_configs[VAULT_PARENT_ORG_ID], token=parent_token,
                           **{EJobs.RBAC_INFRA_SETUP.value: COMPLETED},
                           **{"User Org Details": user_details["orgId"]})
