/*
 * Created on Thu Apr 07 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DisconnectCallContext, ToggleCallControlContext, ECallStatus, ERoccWorkflow, LogoutContext, MultiEditInitiateCallContext, ParkAndInitiateCallContext, ParkAndResumeContext, IAVCallDetails } from "@rocc/rocc-client-services"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import {
    APP_NAME, CALL_DISCONNECT_SUCCESS, DAEMONIZE_CALL_SUCCESS, HOLD_CALL_SUCCESS, MFE_LOGGED_OUT, MFE_LOGOUT_ELECT, PLACE_CALL_FAILED,
    PLACE_CALL_SUCCESS, RESUME_CALL_FAILED, RESUME_CALL_SUCCESS, TRACKED_WORKFLOWS, TOGGLE_FAILED, TOGGLE_SUCCESS,
} from "../../../constants/constants"
import { disconnectCall, holdCall, resumeCall, sendWorkflowEvent, setDeafenCall, setMuteCall, setVideoCallStatus } from "../../../redux/actions/callActions"
import { IRoomInfo, IStore, IWorkflowInfo } from "../../../redux/interfaces/types"
import { enableWebToWebCall } from "../../../services/callServices"
import { disconnectAllCallStatus, findCallStatusByContextId, upsertCallStatus } from "../../helpers/callUtility"
import { checkIfCallGoingOnForContext, checkIfConsoleAvailable, checkToDaemonizeCall, getCallsWithParticipant, getStateValueDependency } from "../../helpers/helpers"
import { onCallAccept } from "../avmessages/av-messages/MessageHelper"

const { MULTI_EDIT_INITIATE_CALL, MULTI_EDIT_START_EDITING, PARK_AND_INITIATE_CALL, PARK_AND_START_EDITING, PARK_AND_RESUME, DISCONNECT_CALL, DISCONNECT_CALL_WITHOUT_MODAL, DISCONNECT_CONSOLE_SESSION, TOGGLE_CALL_CONTROL, LOGOUT } = ERoccWorkflow
const COMPONENT_NAME = "Call Workflow Controller"
interface ICallDetails {
    activeContextId: string
    postTransactionHook: (isSuccess: boolean) => any
}
const initCallDetails: ICallDetails = { activeContextId: "", postTransactionHook: () => { "" } }
export const WorkflowController = () => {
    const {
        workflows, currentUser, rooms, connectedCallDetails, onHoldCallDetails, videoCallStatus,
    } = useSelector((state: IStore) => ({
        workflows: state.externalReducer.workflows.filter((workflow: IWorkflowInfo) => TRACKED_WORKFLOWS.includes(workflow.type)),
        currentUser: state.externalReducer.currentUser,
        rooms: state.externalReducer.rooms,
        connectedCallDetails: state.callReducer.callDetails.connectedCallDetails,
        onHoldCallDetails: state.callReducer.callDetails.onHoldCallDetails,
        videoCallStatus: state.callReducer.videoCallStatus,
    }))

    const [callDetails, setCallDetails] = useState(initCallDetails)
    const dispatch = useDispatch()

    const handlePuttingCallOnHold = (workflow: IWorkflowInfo) => {
        if (!connectedCallDetails.contextId) {
            dispatch(sendWorkflowEvent(workflow.id, HOLD_CALL_SUCCESS))
            return
        }
        if (checkIfConsoleAvailable(connectedCallDetails.contextId)) {
            dispatch(holdCall())
        } else {
            // Disconenct current call since multi-edit is not allowed
            dispatch(disconnectCall(connectedCallDetails.contextId))
        }
        dispatch(sendWorkflowEvent(workflow.id, HOLD_CALL_SUCCESS))
    }

    const handleCallResume = (workflow: IWorkflowInfo) => {
        const { nextSessionDetails } = workflow.state.context as ParkAndInitiateCallContext | ParkAndResumeContext
        if (nextSessionDetails?.callContextId) {
            dispatch(resumeCall(nextSessionDetails.callContextId))
            dispatch(sendWorkflowEvent(workflow.id, RESUME_CALL_SUCCESS))
            return
        }
        dispatch(sendWorkflowEvent(workflow.id, RESUME_CALL_FAILED))
    }

    const handleDaemonizingCall = async (workflow: IWorkflowInfo) => {
        const { nextSessionDetails } = workflow.state.context as ParkAndInitiateCallContext | ParkAndResumeContext | MultiEditInitiateCallContext
        if (checkToDaemonizeCall(nextSessionDetails)) {
            dispatch(holdCall())
        }
        dispatch(sendWorkflowEvent(workflow.id, DAEMONIZE_CALL_SUCCESS))
    }
    const handlePlacingCall = async (workflow: IWorkflowInfo) => {
        // TODO: Pull details from context directly
        const { nextSessionDetails } = workflow.state.context as ParkAndInitiateCallContext | ParkAndResumeContext | MultiEditInitiateCallContext
        // Check if Call is already going on with the contextId or contactUuid
        if (
            (nextSessionDetails.callContextId && checkIfCallGoingOnForContext(nextSessionDetails.callContextId))
            || getCallsWithParticipant(nextSessionDetails.contactUuid, [...onHoldCallDetails, connectedCallDetails])
        ) {
            dispatch(sendWorkflowEvent(workflow.id, PLACE_CALL_SUCCESS))
            return
        }

        if (nextSessionDetails.callContextId) {
            // It is an Incoming call since contextId already present
            onCallAccept({ contextId: nextSessionDetails.callContextId, dispatch, contactUuid: nextSessionDetails.contactUuid }, false)
            setCallDetails({
                activeContextId: nextSessionDetails.callContextId,
                postTransactionHook: (isSuccess) => {
                    dispatch(sendWorkflowEvent(workflow.id, isSuccess ? PLACE_CALL_SUCCESS : PLACE_CALL_FAILED))
                }
            })

        } else {
            // Current User is initiating the call
            // TODO: Add modality field in all call related workflows
            const enableWebCallProps = { contactUuid: nextSessionDetails.contactUuid, dispatch, componentName: COMPONENT_NAME, currentUserUuid: currentUser.uuid, modalityName: "" }
            const contextId = await enableWebToWebCall(enableWebCallProps)
            if (!contextId) {
                dispatch(sendWorkflowEvent(workflow.id, PLACE_CALL_FAILED))
                return
            }
            setCallDetails({
                activeContextId: contextId,
                postTransactionHook: (isSuccess) => {
                    dispatch(sendWorkflowEvent(workflow.id, isSuccess ? PLACE_CALL_SUCCESS : PLACE_CALL_FAILED))
                }
            })
        }
    }

    const handleDisconnectingCall = (workflow: IWorkflowInfo) => {
        const { callContextId } = workflow.state.context as DisconnectCallContext
        dispatch(setVideoCallStatus(upsertCallStatus(callContextId, ECallStatus.DISCONNECTED)))
        dispatch(sendWorkflowEvent(workflow.id, CALL_DISCONNECT_SUCCESS))
    }

    const handleToggleCallControl = (workflow: IWorkflowInfo) => {
        const { callContextId, roomUuid, toggles } = workflow.state.context as ToggleCallControlContext

        const activeCall = [connectedCallDetails, ...onHoldCallDetails].find((callDetails: IAVCallDetails) => callDetails.contextId === callContextId)

        if (!activeCall) {
            dispatch(sendWorkflowEvent(workflow.id, TOGGLE_FAILED))
            return
        }

        if (typeof toggles.muteStatus !== 'undefined') {
            sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalAudio" } })

            const activeRoom = rooms.find((room: IRoomInfo) => room.roomUuid === roomUuid)

            if (activeRoom) {
                dispatch(setMuteCall(activeCall, toggles.muteStatus))
            }
        }
        if (typeof toggles.deafenStatus !== 'undefined') {
            sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalVolume" } })
            dispatch(setDeafenCall(activeCall, toggles.deafenStatus))
        }

        dispatch(sendWorkflowEvent(workflow.id, TOGGLE_SUCCESS))
    }

    const handleLogoutElection = (workflow: IWorkflowInfo) => {
        dispatch(sendWorkflowEvent(workflow.id, MFE_LOGOUT_ELECT, { appName: APP_NAME }))
    }

    const handleLogoutOperation = (workflow: IWorkflowInfo) => {
        if ((workflow.state.context as LogoutContext).electionList.includes(APP_NAME)) {
            dispatch(setVideoCallStatus(disconnectAllCallStatus()))
            dispatch(sendWorkflowEvent(workflow.id, MFE_LOGGED_OUT, { appName: APP_NAME }))
        }
    }

    const processWorkflow = (workflowType: ERoccWorkflow, workflow: IWorkflowInfo) => {
        switch (workflowType) {
            case MULTI_EDIT_INITIATE_CALL:
            case MULTI_EDIT_START_EDITING:
            case PARK_AND_INITIATE_CALL:
            case PARK_AND_START_EDITING:
            case PARK_AND_RESUME:
            case DISCONNECT_CALL:
            case DISCONNECT_CALL_WITHOUT_MODAL:
            case DISCONNECT_CONSOLE_SESSION:
            case TOGGLE_CALL_CONTROL:
            case LOGOUT:
                return handleStateFlow(workflow)
            default:

        }
    }

    const handleStateFlow = (workflow: IWorkflowInfo) => {
        const taskActions: Record<string, any> = {
            PUTTING_CALL_ON_HOLD: handlePuttingCallOnHold,
            DAEMONIZING_CALL: handleDaemonizingCall,
            RESUMING_CALL: handleCallResume,
            PLACING_CALL: handlePlacingCall,
            DISCONNECTING_CALL: handleDisconnectingCall,
            TOGGLING_CALL_CONTROL: handleToggleCallControl,
            ELECTING_MFE_LOGOUT: handleLogoutElection,
            LOGGING_OUT_MFE: handleLogoutOperation,
        }

        const stateValue: string = Object.keys(taskActions).find(
            (stateValue: string) => workflow.state.matches(stateValue)
        ) ?? ""

        return taskActions[stateValue]?.(workflow)
    }

    useEffect(() => {
        workflows.forEach((workflow: IWorkflowInfo) => processWorkflow(workflow.type, workflow))
    }, [getStateValueDependency(workflows)])

    useEffect(() => {
        if (callDetails.activeContextId) {
            const callStatus = findCallStatusByContextId(videoCallStatus, callDetails.activeContextId)
            const { CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED, CONNECTED } = ECallStatus
            const endValues = [CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED]
            if (!callStatus) {
                callDetails.postTransactionHook(false)
                setCallDetails(initCallDetails)
                return
            }
            if (endValues.includes(callStatus.callStatus)) {
                callDetails.postTransactionHook(false)
                setCallDetails(initCallDetails)
            } else {
                if (callStatus.callStatus === CONNECTED && connectedCallDetails.contextId === callDetails.activeContextId) {
                    callDetails.postTransactionHook(true)
                    setCallDetails(initCallDetails)
                }
            }
        }
    }, [videoCallStatus, connectedCallDetails])

    return <></>
}
