/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, IMissedCallData } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Menu } from "semantic-ui-react"
import { getCallStatusFromICallStatus } from "../../../common/helpers/callUtility"
import { isAdmin } from "../../../common/helpers/helpers"
import { IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/locales/en_US.json"
import { ESidePanelTabs, ETabbarType, ITabbarItems, ITelepresencePanel } from "../../../types/types"
import ActiveTabLayout from "../active-tab-layout/ActiveTabLayout"
import TabLayout from "../tab-layout/TabLayout"
import ActiveCallTab from "../telepresence-tabs/active-call-tab/ActiveCallTab"
import ContactsListTab from "../telepresence-tabs/contact-list-tab/ContactListTab"
import MissedCallTab from "../telepresence-tabs/missed-call-tab/MissedCallTab"


const { Contacts, MissedCalls, Active } = ESidePanelTabs

const TelepresencePanelController = (props: ITelepresencePanel) => {

    const { visible, activeItem, setActiveItem, contactCardActions } = props

    const {
        videoCallStatus,
        phoneCallStatus,
        missedCalls,
        desktopCallWindowFullScreen,
        currentUser
    } = useSelector((state: IStore) => ({
        videoCallStatus: state.callReducer.videoCallStatus,
        phoneCallStatus: state.callReducer.phoneCallStatus,
        missedCalls: state.callReducer.missedCalls,
        desktopCallWindowFullScreen: state.externalReducer.sideBar.desktopFullScreen,
        currentUser: state.externalReducer.currentUser,
    }))

    const [isDesktopFullScreen, setIsDesktopFullScreen] = useState(false)
    const showPanel = (visible) ? "active" : "inactive"

    const onTabClick = (tabName: ESidePanelTabs) => {
        sendLogsToAzure({ contextData: { component: "Call Panel: Expert User View", Tab: tabName } })
        setActiveItem(tabName)
    }

    const activeTab: ITabbarItems = { name: Active, value: "active", type: ETabbarType.COMPONENT, component: <ActiveTabLayout handleActiveTabClick={onTabClick} /> }

    const menuList: ITabbarItems[] = [
        activeTab,
        { name: Contacts, value: "contacts", type: ETabbarType.STRING },
        { name: MissedCalls, value: "missed", type: ETabbarType.STRING },
    ]

    const adminMenuList: ITabbarItems[] = [activeTab]

    const getIntersectionLengthOfTwoArrays = (array1: ECallStatus[], array2: ECallStatus[]) => {
        return array1.filter((item: ECallStatus) => array2.includes(item)).length
    }

    const checkBadgeCount = () => {
        let count = 0
        missedCalls.forEach((item: IMissedCallData) => {
            if (!item.seen) {
                count = count + 1
            }
        })
        return count !== 0
    }

    const setActiveItemValue = (item: ESidePanelTabs) => {
        if (activeItem !== item) {
            setActiveItem(item)
        }
    }

    const computeActiveTab = () => {
        const { CALLING, CONNECTED, CONNECTING, CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, RINGING, FAILED } = ECallStatus
        const eligibleValues = [CALLING, RINGING, CONNECTING, CONNECTED]
        const endValues = [CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED]
        const callStatuses = getCallStatusFromICallStatus(videoCallStatus)
        if (getIntersectionLengthOfTwoArrays([...eligibleValues, ...endValues], callStatuses) > 0 ||
            [...eligibleValues, ...endValues].includes(phoneCallStatus) || isAdmin()) {
            setActiveItemValue(Active)
        } else if (checkBadgeCount()) {
            setActiveItemValue(MissedCalls)
        } else {
            setActiveItemValue(Contacts)
        }
    }

    const content = () => {
        const getAdmin = isAdmin()
        const telepresenceMenuList = getAdmin ? adminMenuList : menuList

        return (
            <>
                {!isDesktopFullScreen && <Menu pointing={true} secondary={true} stackable={true} text={true} widths={3}>
                    {displayTabItems(telepresenceMenuList)}
                </Menu>}
                <ActiveCallTab {...props} />

                {!getAdmin &&
                    <>
                        <MissedCallTab activeItem={activeItem} contactCardActions={contactCardActions} />
                        <ContactsListTab {...props} />
                    </>
                }
            </>
        )
    }

    const displayTabItems = (tabList: ITabbarItems[]) => {
        return tabList.map((item, index) => {
            if (item.type === ETabbarType.COMPONENT && item.component) {
                return <Menu.Item key={index} active={activeItem === item.name} onClick={() => onTabClick(item.name)}>
                    {item.component}
                </Menu.Item>
            }
            return <Menu.Item key={item.name} name={getName(item.name)} active={activeItem === item.name} id={item.name} onClick={() => onTabClick(item.name)} />
        })
    }

    const getName = (tabName: string) => {
        const { intl } = getIntlProvider()
        switch (tabName) {
            case Active:
                return intl.formatMessage({ id: "content.tabs.active", defaultMessage: en["content.tabs.active"] })
            case Contacts:
                return intl.formatMessage({ id: "content.tabs.contacts", defaultMessage: en["content.tabs.contacts"] })
            case MissedCalls:
                return intl.formatMessage({ id: "content.tabs.missedCalls", defaultMessage: en["content.tabs.missedCalls"] })
            default: return ""
        }
    }

    useEffect(() => {
        computeActiveTab()
        if (desktopCallWindowFullScreen) {
            setIsDesktopFullScreen(true)
            content()
        } else {
            setIsDesktopFullScreen(false)
            content()
        }
    }, [visible, videoCallStatus, phoneCallStatus, desktopCallWindowFullScreen])

    return (
        <>
            {currentUser && <TabLayout
                className={"right-sidebar-panel" + showPanel}
                tabBodyContent={content()}
            />}
        </>
    )

}

export default TelepresencePanelController
