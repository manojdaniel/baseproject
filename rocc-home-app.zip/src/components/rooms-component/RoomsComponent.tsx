/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import "@dls-pdv/semantic-ui-foundation/dist/semantic.css"
import { getFeatureFlagsReducerFromGlobalStore } from "../../common/helpers/helpers"
import { RoomsViewBody } from "../rooms-view-body/RoomsViewBody"
import { RoomViewHeaderComponent } from "@rocc/rocc-rooms-components"
import en from "../../resources/locales/en_US.json"
import { IRoomDetails } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import partition from "lodash.partition"
import { getRoomCardProps } from "../room-card-component/RoomCardHelper"
import cx from "classnames"
import styles from "./RoomsComponent.module.scss"
import { useSelector } from "react-redux"
import { IStore } from "../../redux/interfaces/types"
import { ALL_TEXT } from "../../constants/constants"
import { EProtocolTransferSteps } from "../../redux/interfaces/enums"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"

enum MODALITY_FILTER_LIST {
    ALL = "All",
    MR = "MR",
    CT = "CT",
}

const RoomsComponent = () => {
    const { activeLocationId, activeSessions, selectedSource, currentStep, protocolTransferStatus, rooms, locations, phoneCallStatus, videoCallStatus, completedDestinations, } = useSelector((state: IStore) => ({
        activeLocationId: state.externalReducer.activeLocationId,
        activeSessions: state.externalReducer.consoleDetails.activeConsoleSessions,
        selectedSource: state.externalReducer.protocolTransferDetails.selectedSource,
        currentStep: state.externalReducer.protocolTransferDetails.currentStep,
        protocolTransferStatus: state.externalReducer.protocolTransferDetails.protocolTransferStatus,
        completedDestinations: state.externalReducer.protocolTransferDetails.completedDestinations,
        rooms: state.externalReducer.rooms,
        locations: state.externalReducer.locations,
        videoCallStatus: state.externalReducer.callingDetails.videoCallStatus,
        phoneCallStatus: state.externalReducer.callingDetails.phoneCallStatus
    }))

    const flags = getFeatureFlagsReducerFromGlobalStore()
    const { intl } = getIntlProvider()

    const initModalityOption = {
        text: intl.formatMessage({ id: "content.status.all", defaultMessage: en["content.status.all"] }),
        value: ALL_TEXT
    }

    const [, setModalityOptions] = useState([initModalityOption])
    const [filteredRooms, setFilteredRooms] = useState(rooms)
    const [starredRooms, setStarredRooms] = useState([] as IRoomDetails[])
    const [otherRooms, setOtherRooms] = useState([] as IRoomDetails[])
    const [selectedOption, setSelectedOption] = useState(MODALITY_FILTER_LIST.ALL)
    const [searchValue, setSearchValue] = useState("")

    const isSourceSelected = () => {
        return (currentStep === EProtocolTransferSteps.SelectDestinationScanner || currentStep === EProtocolTransferSteps.CompletionStep) ? true : false
    }

    const excludeSource = (filteredRooms: IRoomDetails[]) => {
        if (selectedSource.identity) {
            const room = filteredRooms.find((room) => room.identity.uuid === selectedSource.identity.uuid)
            if (room) {
                const index = filteredRooms.indexOf(room)
                filteredRooms.splice(index, 1)
            }
        }
    }

    const fetchRoomDetails = (value: string) => {
        const searchResult = searchValue.toLowerCase()
        const activeRooms = rooms.filter((room: any) =>
            room.locationId === activeLocationId &&
            (room.identity.name.toLowerCase().indexOf(searchResult) > -1 || room.address.toLowerCase().indexOf(searchResult) > -1))
        let filteredRooms = []
        if (value === MODALITY_FILTER_LIST.ALL) {
            filteredRooms = [...activeRooms]
        }
        else {
            filteredRooms = activeRooms.filter((room: any) => room.modality === value)
        }
        //excluding the source scanner in the room cards group, when user is in protocol transfer mode
        if (isSourceSelected()) {
            excludeSource(filteredRooms)
        }
        setFilteredRooms(filteredRooms)
    }
    const fetchActiveRoomsDetails = () => {
        if (activeLocationId >= -1) {
            fetchRoomDetails(selectedOption)
        }
    }
    const fetchRooms = () => {
        const location = locations.find((loc: any) => loc.id === activeLocationId)
        if (location) {
            const currentLocationModalityOptions = location.modalityList.map((modality: any) => ({ text: modality.modality, value: modality.modality }))
            currentLocationModalityOptions.unshift(initModalityOption)
            setModalityOptions(currentLocationModalityOptions)
            if (location.roomsFetched) {
                fetchActiveRoomsDetails()
            }
        }
    }

    useEffect(() => {
        fetchRooms()
    }, [activeLocationId, rooms, activeSessions, locations])

    useEffect(() => { fetchRoomDetails(selectedOption) }, [searchValue])

    useEffect(() => {
        const partitionedRooms = partition(filteredRooms, (room: any) => { return room.isRoomStarred })
        setStarredRooms(partitionedRooms[0])
        setOtherRooms(partitionedRooms[1])
    }, [filteredRooms])

    useEffect(() => {
        let modality = MODALITY_FILTER_LIST.ALL
        if (isSourceSelected()) {
            modality = selectedSource.modality
        }
        setSelectedOption(modality)
        fetchRoomDetails(modality)
    }, [currentStep])

    const modalityChangeHandler = (modality: any) => {
        infoLogger(`Modality changed`)
        sendLogsToAzure({ contextData: { component: "Modality Filter", event: `Selected modality: ${modality}` } })
        setSelectedOption(modality)
        fetchRoomDetails(modality)
    }

    const roomSearchHandler = (value: any) => {
        sendLogsToAzure({ contextData: { component: "Search:Expert User View:Room Search", SearchEvent: value } })
        setSearchValue(value)
    }

    const getHospitalNameForSelectedLocation = () => {
        const location = locations.find((loc: any) => loc.id === activeLocationId)
        return location ? location.name : ""
    }

    const roomCardProps = { flags: flags.featureFlags, activeSessions, protocolTransferStatus, ptCompletedDestinations: completedDestinations, phoneCallStatus, videoCallStatus }
    const starredRoomsList = getRoomCardProps({ ...roomCardProps, rooms: starredRooms })
    const unstarredRoomsList = getRoomCardProps({ ...roomCardProps, rooms: otherRooms })
    const allRoomsList = getRoomCardProps({ ...roomCardProps, rooms: filteredRooms })
    return (
        <>
            <div className={cx(styles.roomViewHeaderWrapper)} id="roomCardHeader">
                <RoomViewHeaderComponent
                    hospitalName={getHospitalNameForSelectedLocation()}
                    modalityChangeHandler={(modality: any) => modalityChangeHandler(modality)}
                    roomSearchHandler={(result: any) => roomSearchHandler(result)}
                    dropdownDisabled={isSourceSelected() ? true : false}
                    selectedModality={selectedOption} />
            </div>

            <RoomsViewBody starredRoomsList={starredRoomsList} otherRoomsList={unstarredRoomsList} allRoomsList={allRoomsList} />
        </>
    )
}

export default RoomsComponent
