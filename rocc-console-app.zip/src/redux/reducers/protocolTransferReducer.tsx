/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Reducer } from "redux"
import { GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, GLOBAL_SET_SOURCE_SCANNER, GLOBAL_SET_DESTINATION_SCANNER, GLOBAL_SET_PROTOCOL_TRANSFER_STEP, UPDATE_DESTINATION_SCANNERS, GLOBAL_CLEAR_DESTINATIONS, GLOBAL_SET_INITIATION_ROUTE } from "../actions/types"
import { IProtocolTransferReducer, EProtocolTransferSteps } from "../interfaces/types"

export const initialStatesForProtocolTransfer: IProtocolTransferReducer = {
    protocolTransferStatus: false,
    protocolTransferExitInProgress: false,
    selectedSource: {},
    selectedDestination: {},
    completedDestinations: [],
    currentStep: EProtocolTransferSteps.SelectSourceScanner,
    initiationRoute: ""
}

const protocolTransferReducer: Reducer = (state: IProtocolTransferReducer = initialStatesForProtocolTransfer, action: any) => {
    switch (action.type) {
        case GLOBAL_SET_PROTOCOL_TRANSFER_STATUS:
            return { ...state, protocolTransferStatus: action.payload.protocolTransferStatus }
        case GLOBAL_SET_PROTOCOL_TRANSFER_EXIT:
            return { ...state, protocolTransferExitInProgress: action.payload.protocolTransferExit }
        case GLOBAL_SET_SOURCE_SCANNER:
            return { ...state, selectedSource: { ...action.payload.selectedSource } }
        case GLOBAL_SET_DESTINATION_SCANNER:
            return { ...state, selectedDestination: { ...action.payload.selectedDestination } }
        case GLOBAL_SET_PROTOCOL_TRANSFER_STEP:
            return { ...state, currentStep: action.payload.currentStep }
        case UPDATE_DESTINATION_SCANNERS: {
            const updatedScanners = [...state.completedDestinations]
            updatedScanners.push(action.selectedDestination)
            return { ...state, completedDestinations: [...updatedScanners] }
        }
        case GLOBAL_CLEAR_DESTINATIONS:
            return { ...state, completedDestinations: [] }
        case GLOBAL_SET_INITIATION_ROUTE:
            return { ...state, initiationRoute: action.payload.initiationRoute }
        default:
    }
    return { ...state }
}

export default protocolTransferReducer
