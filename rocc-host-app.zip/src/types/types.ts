/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export enum EUserPresence {
    AVAILABLE = "AVAILABLE",
    BUSY = "BUSY",
    IN_CALL = "IN_CALL",
    DND = "DND",
    OFFWORK = "OFFWORK",
    AWAY = "AWAY",
    OFFLINE = "OFFLINE",
}

export enum ELOGIN_STATUS {
    SUCCESS = "Success",
    FAILED = "Failed",
    LOADING = "Loading",
    DEFAULT = "Default",
}

export interface ILoginState {
    status: ELOGIN_STATUS,
    statusCode: number
    data: any
}

export enum EPhoneIconColor {
    WHITE = "white",
    GREEN = "green",
}

export enum EFeatures {
    ADMIN_USER_ADD = "ADMIN_USER_ADD",
    ADMIN_USER_EDIT = "ADMIN_USER_EDIT",
    ADMIN_USER_READ = "ADMIN_USER_READ",
    ADMIN_USER_DELETE = "ADMIN_USER_DELETE",
    ADMIN_LOCATION_EDIT = "ADMIN_LOCATION_EDIT",
    ADMIN_LOCATION_READ = "ADMIN_LOCATION_READ",
    ADMIN_ROOM_EDIT = "ADMIN_ROOM_EDIT",
    ADMIN_ROOM_READ = "ADMIN_ROOM_READ",
    CONSOLE_VIEW = "CONSOLE_VIEW",
    CONSOLE_VIEW_INCOGNITO = "CONSOLE_VIEW_INCOGNITO",
    CONSOLE_EDIT = "CONSOLE_EDIT",
    CONSOLE_EDIT_WITHOUT_AUTHORIZATION = "CONSOLE_EDIT_WITHOUT_AUTHORIZATION",
    CALL_VIDEO_CALL = "CALL_VIDEO_CALL",
    CALL_DESKTOP_FULL_SCREEN = "CALL_DESKTOP_FULL_SCREEN",
    CALL_WEB_TO_WEB = "CALL_WEB_TO_WEB",
    CALL_WEB_TO_PHONE = "CALL_WEB_TO_PHONE",
    CALL_ADD_PARTICIPANT = "CALL_ADD_PARTICIPANT",
    CALL_HYBRID_ROCC_CALL = "CALL_HYBRID_ROCC_CALL",
}

export enum ELoadTimes {
    LOGIN_CLICK,
    HOME_PAGE_LOADED,
}

export interface IGetInitialNavConfig {
    phoneIconColor: EPhoneIconColor
    logoutText: any
    protocolTransferStatus: boolean
    dispatch: any
    count: number
    showNfccDownload: boolean
    phoneIconCallBack: () => void
    aboutClick: () => void,
    isAdminOnly: boolean
    isTechAppDownloadAvailable: boolean
    cctvWindow: boolean
}

export type IGetIconMenuItems = Omit<IGetInitialNavConfig, "logoutText">

export enum EManualType {
    ADMIN_MANUAL = "ADMIN_MANUAL",
    USER_MANUAL = "USER_MANUAL"
}

export const GLOBAL_SET_INITIATE_PHONE_CALL = "GLOBAL_SET_INITIATE_PHONE_CALL"
