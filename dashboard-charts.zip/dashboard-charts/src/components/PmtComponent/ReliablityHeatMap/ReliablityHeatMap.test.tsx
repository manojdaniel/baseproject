import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import ReliabilityHeatMap from "./ReliablityHeatMap";

//Jest function added for navigation
const mockedUsedNavigate = jest.fn();
jest.mock("react-router-dom", () => ({
	...jest.requireActual("react-router-dom"),
	useNavigate: () => mockedUsedNavigate,
}));

//Mock tooltip data for the chart component
const toolTipData = [
	{
		assetSapId: "310060739",
		assetHealthIndex: 76,
		assetTrend: false,
		assetId: "2Y-3001A",
		assetName: "JSW N2 compressors",
	},
	{
		assetSapId: "310060748",
		assetHealthIndex: 73,
		assetTrend: false,
		assetId: "2Y-3001B",
		assetName: "JSW N2 compressors",
	},
	{
		assetSapId: "310061199",
		assetHealthIndex: 78,
		assetTrend: true,
		assetId: "2Y-3606",
		assetName: "Atlas Copco Air Compressor",
	},
	{
		assetSapId: "310061205",
		assetHealthIndex: 84,
		assetTrend: false,
		assetId: "2Y-3607",
		assetName: "Atlas Copco Air Compressor",
	},
];

//Mock statusdata for the chart component
const statusData = [
	{
		title: "Asset_Under_Risk",
		value: "10",
	},
	{
		title: "Warning",
		value: "4",
	},
	{
		title: "Normal",
		value: "2",
	},
	{
		title: "Normal",
		value: "2",
	},
];

//Mock mousehover data for the chart component
const mouseHover = [
	{
		over: false,
		statusName: "",
	},
];

describe("ReliabilityHeatMap", () => {
	//Test Case to check chart exist in the component.
	it("renders the component", () => {
		const { container } = render(
			<ReliabilityHeatMap
				statusData={statusData}
				toolTipData={toolTipData}
				selectedHeatStatus={[]}
				setMouseHover={mouseHover}
				mouseHover={mouseHover}
			/>
		);
		// expect(screen.getByTestId("reliability-heatmap")).toBeInTheDocument();
		expect(container.querySelector(".pmt-health-index")).toBeInTheDocument();
	});

	//Test Case to check correct values exist in the component.
	it("displays the correct values for each heat status", () => {
		render(
			<ReliabilityHeatMap
				statusData={statusData}
				toolTipData={toolTipData}
				selectedHeatStatus={[]}
				setMouseHover={mouseHover}
				mouseHover={mouseHover}
			/>
		);
		expect(screen.getByText(/Asset-Off/i)).toBeInTheDocument();
		expect(screen.getByText(/Normal/i)).toBeInTheDocument();
		expect(screen.getByText(/Warning/i)).toBeInTheDocument();
		expect(screen.getByText(/Asset Under Risk/i)).toBeInTheDocument();
	});

	//Test Case to check mouseover working in the component.
	it.skip("shows the tooltip on mouseover", () => {
		render(
			<ReliabilityHeatMap
				statusData={statusData}
				toolTipData={toolTipData}
				selectedHeatStatus={[]}
				setMouseHover={mouseHover}
				mouseHover={mouseHover}
			/>
		);
		const assetOff = screen.getByText(/10/i);
		fireEvent.mouseOver(assetOff);
		expect(ReliabilityHeatMap).toBeInTheDocument();
	});

	//Test Case to check mouseover working in the component.
	it.skip("hides the tooltip on mouseout", () => {
		render(
			<ReliabilityHeatMap
				statusData={statusData}
				toolTipData={toolTipData}
				selectedHeatStatus={[]}
				setMouseHover={mouseHover}
				mouseHover={mouseHover}
			/>
		);
		const assetOff = screen.getByText(/Asset-Off/i);
		fireEvent.mouseOver(assetOff);
		fireEvent.mouseOut(assetOff);
		expect(ReliabilityHeatMap).toBeInTheDocument();
	});
});
