/*
 * Created on Thu Apr 07 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DisconnectCallContext, DisconnectConsoleSessionContext, EConnectionType, ERoccWorkflow, IConsoleSession, LogoutContext, MultiEditInitiateCallContext, MultiEditStartEditingContext, ParkAndInitiateCallContext, ParkAndResumeContext, ParkAndStartEditingContext, TransactionValue } from "@rocc/rocc-client-services"
import { errorLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { sendWorkflowEvent } from "../../../redux/actions/consoleActions"
import { GLOBAL_LEFTSIDE_PANEL } from "../../../redux/actions/types"
import { IStore, IWorkflowInfo } from "../../../redux/interfaces/types"
import { dispatchToParentStore } from "../../../redux/store/externalAppStates"
import {
    APP_NAME, CANCEL, CONFIRM, CONSOLE_DISCONNECT_FAILED, CONSOLE_DISCONNECT_SUCCESS, INITIATE_EDIT_SESSION_FAILED, INITIATE_EDIT_SESSION_SUCCESS, MFE_LOGGED_OUT,
    MFE_LOGOUT_ELECT, MFE_LOGOUT_FAILED, PARK_SESSION_FAILED, PARK_SESSION_SUCCESS, RESUME_EDIT_SESSION_FAILED,
    RESUME_EDIT_SESSION_SUCCESS, TIMEOUT, TRACKED_WORKFLOWS
} from "../../constants/constants"
<<<<<<< HEAD
import { getConnectionAdapter } from "../../helpers/connection"
import { checkIfMultiEditWithParkResumeFeatureEnabled, disconnectAllConsoleSessions, handleStartEditing, initiateConsoleSwitchOperation } from "../../helpers/consoleUtility"
import { displayEditToViewSwitchMessage, getActionFromWorkflowType, getRoomUuidsFromWorkflowContext, getStateValueDependency } from "../../helpers/helpers"
=======
import { checkIfMultiEditWithParkResumeFeatureEnabled, createConsoleDisconnectOperation, disconnectAllConsoleSessions, handleAuthorisation, initiateConsoleSwitchOperation } from "../../helpers/consoleUtility"
import { getActionFromWorkflowType, getRoomUuidsFromWorkflowContext, getStateValueDependency } from "../../helpers/helpers"
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
import MultiSession, { IMultiSessionProps } from "../multi-session/MultiSession"
const { MULTI_EDIT_INITIATE_CALL, MULTI_EDIT_START_EDITING, DISCONNECT_CALL, DISCONNECT_CONSOLE_SESSION, PARK_AND_INITIATE_CALL, PARK_AND_START_EDITING, PARK_AND_RESUME, LOGOUT } = ERoccWorkflow
const COMPONENT_NAME = "Workflow Controller"
export const WorkflowController = () => {
    const {
        workflows, consoleSessions
    } = useSelector((state: IStore) => ({
        workflows: state.externalReducer.workflows.filter(
            (workflow: IWorkflowInfo) => TRACKED_WORKFLOWS.includes(workflow.type)
        ),
        consoleSessions: state.consoleReducer.consoleSessions,
    }))

    const dispatch = useDispatch()

    const [multiSessionProps, setMultiSessionProps] = useState({} as IMultiSessionProps)

    const processWorkflow = (workflowType: ERoccWorkflow, workflow: IWorkflowInfo) => {
        switch (workflowType) {
            case MULTI_EDIT_INITIATE_CALL:
            case MULTI_EDIT_START_EDITING:
            case PARK_AND_INITIATE_CALL:
            case PARK_AND_START_EDITING:
            case PARK_AND_RESUME:
            case DISCONNECT_CALL:
            case DISCONNECT_CONSOLE_SESSION:
            case LOGOUT:
                return handleStateFlow(workflow)
            default:
        }
    }

    const handleStateFlow = (workflow: IWorkflowInfo) => {
        const taskActions: any = {
            DISPLAY_MULTI_EDIT_MODAL: handleDisplayMultiEditModal,
            DISPLAY_PARK_MODAL: handleDisplayParkAndResumeModal,
            SESSION_PARKING: handleSessionParking,
            INITIATING_EDIT_CONSOLE_SESSION: handleInitiateEditSession,
            RESUMING_EDIT_CONSOLE_SESSION: handleResumingEditSession,
            DISCONNECTING_CONSOLE_SESSION: handleDisconnectingConsoleSession,
            ELECTING_MFE_LOGOUT: handleLogoutElection,
            LOGGING_OUT_MFE: handleLogoutOperation,
        }

        const stateValue: string = Object.keys(taskActions).find(
            (stateValue: string) => workflow.state.matches(stateValue)
        ) ?? ""

        return taskActions[stateValue]?.(workflow)
    }

    const handleDisplayMultiEditModal = (workflow: IWorkflowInfo) => {
        const context = workflow.state.context

        let receiverName: string | undefined
        let timeoutId: NodeJS.Timeout | undefined

        if ("nextSessionDetails" in context) {
            const { modalTimeout, nextSessionDetails } = context as MultiEditInitiateCallContext | MultiEditStartEditingContext

            receiverName = "receiverName" in nextSessionDetails ? nextSessionDetails.receiverName : undefined
            timeoutId = modalTimeout
                ? setTimeout(
                    () => {
                        setMultiSessionProps({} as IMultiSessionProps)
                        dispatch(sendWorkflowEvent(workflow.id, TIMEOUT))
                    },
                    modalTimeout
                ) as NodeJS.Timeout
                : undefined
        }

        setMultiSessionProps({
            ...multiSessionProps,
            show: true,
            nextAction: getActionFromWorkflowType(workflow.type),
            contactUuid: getRoomUuidsFromWorkflowContext(workflow.state.context)[0],
            ...(receiverName && { receiverName }),
            onConfirm: () => {
                timeoutId && clearTimeout(timeoutId)
                setMultiSessionProps({} as IMultiSessionProps)
                dispatch(sendWorkflowEvent(workflow.id, CONFIRM))
            },
            onCancel: () => {
                timeoutId && clearTimeout(timeoutId)
                setMultiSessionProps({} as IMultiSessionProps)
                dispatch(sendWorkflowEvent(workflow.id, CANCEL))
            }
        })
    }

    // TODO: Place feature flag check on CC-Host register method to disallow park related workflows to be created if feature flag is disabled.

    const handleDisplayParkAndResumeModal = (workflow: IWorkflowInfo) => {
        const timeoutId = (workflow.state.context as ParkAndResumeContext).modalTimeout
            && setTimeout(
                () => {
                    setMultiSessionProps({} as IMultiSessionProps)
                    dispatch(sendWorkflowEvent(workflow.id, TIMEOUT))
                },
                (workflow.state.context as ParkAndResumeContext).modalTimeout
            )

        setMultiSessionProps({
            ...multiSessionProps,
            show: true,
            nextAction: getActionFromWorkflowType(workflow.type),
            contactUuid: (workflow.state.context as ParkAndResumeContext).nextSessionDetails.contactUuid,
            onConfirm: () => {
                timeoutId && clearTimeout(timeoutId)
                setMultiSessionProps({} as IMultiSessionProps)
                dispatch(sendWorkflowEvent(workflow.id, CONFIRM))
            },
            onCancel: () => {
                timeoutId && clearTimeout(timeoutId)
                setMultiSessionProps({} as IMultiSessionProps)
                dispatch(sendWorkflowEvent(workflow.id, CANCEL))
            }
        })
    }

    const handleSessionParking = (workflow: IWorkflowInfo) => {
        const { prevSessionDetails } = workflow.state.context as ParkAndInitiateCallContext | ParkAndStartEditingContext | ParkAndResumeContext
        const currentSession = consoleSessions.find((session: IConsoleSession) => session.contextId === prevSessionDetails?.consoleContextId)
        if (!currentSession) {
            dispatch(sendWorkflowEvent(workflow.id, PARK_SESSION_SUCCESS))
            return
        }
        if (checkIfMultiEditWithParkResumeFeatureEnabled()) {
            initiateConsoleSwitchOperation({
                newConnectionType: EConnectionType.VIEW,
                transactionState: TransactionValue.PARKED,
                postTransactionHook: (isSuccess) => dispatch(sendWorkflowEvent(workflow.id, isSuccess ? PARK_SESSION_SUCCESS : PARK_SESSION_FAILED)),
                currentSession,
                dispatch,
            })
            return
        }
        errorLogger(`Failed to park console session ${currentSession.contextId}`)
        dispatch(sendWorkflowEvent(workflow.id, PARK_SESSION_FAILED))
    }

    const handleInitiateEditSession = (workflow: IWorkflowInfo) => {
        const { nextSessionDetails } = workflow.state.context as ParkAndStartEditingContext | MultiEditStartEditingContext
        if (nextSessionDetails.contactUuid) {
            const { contactUuid, receiverName, connectionMode } = nextSessionDetails
            handleAuthorisation({
                consoleSessions, receiverName, connectionMode,
                dispatch, roomUuid: contactUuid, componentName: COMPONENT_NAME,
                postTransactionHook: (isSuccess: boolean) => dispatch(sendWorkflowEvent(workflow.id, isSuccess ? INITIATE_EDIT_SESSION_SUCCESS : INITIATE_EDIT_SESSION_FAILED)),
                connectionType: EConnectionType.FULL_CONTROL
            })
            return
        }
        dispatch(sendWorkflowEvent(workflow.id, INITIATE_EDIT_SESSION_FAILED))
    }

    const handleResumingEditSession = (workflow: IWorkflowInfo) => {
        const { nextSessionDetails } = workflow.state.context as ParkAndResumeContext
        if (nextSessionDetails?.consoleContextId) {
            const currentSession = consoleSessions.find((session: IConsoleSession) => session.contextId === nextSessionDetails.consoleContextId)
            if (!currentSession) {
                dispatch(sendWorkflowEvent(workflow.id, RESUME_EDIT_SESSION_SUCCESS))
                return
            }

            initiateConsoleSwitchOperation({
                newConnectionType: EConnectionType.FULL_CONTROL,
                transactionState: TransactionValue.RESUMED,
                postTransactionHook: (isSuccess: boolean) => dispatch(sendWorkflowEvent(workflow.id, isSuccess ? RESUME_EDIT_SESSION_SUCCESS : RESUME_EDIT_SESSION_FAILED)),
                currentSession,
                dispatch,
            })
            return
        }

        dispatch(sendWorkflowEvent(workflow.id, RESUME_EDIT_SESSION_FAILED))
    }

    const handleDisconnectingConsoleSession = (workflow: IWorkflowInfo) => {
        const context = workflow.state.context as DisconnectConsoleSessionContext | DisconnectCallContext

        const sessionToDisconnect = consoleSessions.find(
            (session: IConsoleSession) => ("contactUuid" in context)
                ? (session.roomUuid === context.contactUuid)
                : (session.additionalData?.callContextId === context.callContextId)
        )

        if (!sessionToDisconnect) {
            dispatch(sendWorkflowEvent(workflow.id, CONSOLE_DISCONNECT_SUCCESS))
            return
        }

        const { status, isConsoleSwitching } = getConnectionAdapter().disconnect({
            roomUuid: sessionToDisconnect?.roomUuid,
            connectionType: EConnectionType.FULL_CONTROL,
            postTransactionHook: (isSuccess: boolean) => { dispatch(sendWorkflowEvent(workflow.id, isSuccess ? CONSOLE_DISCONNECT_SUCCESS : CONSOLE_DISCONNECT_FAILED)) }
        })
        if (status) {
            if (isConsoleSwitching) {
                displayEditToViewSwitchMessage()
            }
            dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: false,
                    activeLeftPanel: "",
                    desktopFullScreen: false,
                }
            })
        }
    }

    const handleLogoutElection = (workflow: IWorkflowInfo) => {
        dispatch(sendWorkflowEvent(workflow.id, MFE_LOGOUT_ELECT, { appName: APP_NAME }))
    }

    const handleLogoutOperation = (workflow: IWorkflowInfo) => {
        if ((workflow.state.context as LogoutContext).electionList.includes(APP_NAME)) {
            disconnectAllConsoleSessions({
                dispatch,
                postTransactionHook: (isSuccess: boolean) =>
                    dispatch(sendWorkflowEvent(workflow.id, isSuccess ? MFE_LOGGED_OUT : MFE_LOGOUT_FAILED, { appName: APP_NAME }))
            })
        }
    }

    useEffect(() => {
        workflows.forEach((workflow: IWorkflowInfo) => processWorkflow(workflow.type, workflow))
    }, [getStateValueDependency(workflows)])

    return <>
        {multiSessionProps.show && <MultiSession {...multiSessionProps} setSelfProps={setMultiSessionProps} />}
    </>
}
