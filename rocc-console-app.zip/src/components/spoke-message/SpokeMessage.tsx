/*
 * Created on Thu Nov 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { SpokeNotificationComponent } from "@rocc/rocc-console-components"
import React from "react"
import { useSelector } from "react-redux"
import { getSpokeMessage, isCommandCenterConnection, isQualifyCheckBoxChecked } from "../../common/helpers/helpers"
import { IStore } from "../../redux/interfaces/types"
import styles from "./SpokeMessage.scss"

interface ISpokeMessage {
    roomUuid: string
}

const SpokeMessage = ({ roomUuid }: ISpokeMessage) => {
    const {
        permissions,
        consoleSessions,
        initialized
    } = useSelector((state: IStore) => ({
        featureFlags: state.externalReducer.featureFlags,
        consoleSessions: state.consoleReducer.consoleSessions,
        initialized: state.consoleReducer.commandCenterDetails.initialised,
        permissions: state.externalReducer.permissions
    }))

    const displayMessage = !isCommandCenterConnection(consoleSessions, roomUuid) && isQualifyCheckBoxChecked(roomUuid)

    return (
        displayMessage ?
            <div className={styles.spokeNotificationMessage} id="spokeNotification">
                <SpokeNotificationComponent message={getSpokeMessage(permissions, initialized)} />
            </div> : <></>
    )
}

export default SpokeMessage
