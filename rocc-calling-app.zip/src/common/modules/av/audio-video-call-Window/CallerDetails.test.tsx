/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import CallerDetails from "./CallerDetails"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        connectedCallDetails: {
            participants: [{
                name: "Test name",
                uuid: 1345,
                callStatus: "CALL_ACCEPTED",
            }],
        },
    }),
    useDispatch: () => void (0),
}))

describe("CallerDetails component", () => {
    let wrapper: any
    let props: any

    beforeEach(() => {
        props = {
            remoteAudioTrackStatus: true,
            dominantSpeaker: {
                name: "Test name",
                clinicalRole: "Expert User",
            },
            cssStyleClass: {
            },
            numOfParticipants: 1,
        }
        wrapper = shallow(<CallerDetails {...props} />)
    })
    it("should show caller details (participant name,microphone icon, clinicial role) ", () => {
        const callerDetails = wrapper.find("div").at(0).children().find("div")
        expect(callerDetails).toHaveLength(3)
        const participantDetails = callerDetails.at(0)
        expect(participantDetails).toHaveLength(1)
        expect(participantDetails.text()).toContain("Test name")
        const spanElement = wrapper.find("span")
        expect(spanElement).toHaveLength(1)
        const microphoneIcon = spanElement.find("InlineSVG")
        expect(microphoneIcon.prop("cacheRequests")).toBeTruthy()
        expect(callerDetails.at(2).text().toLowerCase()).toBe("Expert User".toLowerCase())
    })
})
