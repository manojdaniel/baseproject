/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import FormInvoker from "./FormInvoker"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: {},
        urls: {},
    }),
    useDispatch: () => void (0),
    useHistory: () => void (0)
}))

describe("FormInvoker component", () => {
    let wrapper: any
    let formInvokerId: any
    const steps: any = [{
        key: 0,
        title: "Welcome",
    },
    {
        key: 1,
        title: "End User License Agreement",
    },
    {
        key: 2,
        title: "Complete",
    }]
    beforeEach(() => {
        wrapper = shallow(<FormInvoker isEulaRequired={false}
            steps={steps} postSubmitActions={jest.fn()} consentData={"Terms and Conditions"} />)
        formInvokerId = wrapper.find("#OnboardingFormInvoker")
    })
    it("should render with the correct id", () => {
        expect(formInvokerId).toHaveLength(1)
    })

    it("renders form invoker component", () => {
        expect(wrapper.props).toBeDefined()
    })

    it("should render container", () => {
        const container = wrapper.find("Container")
        const render = container.find("FormikForm").prop("render")
        expect(render()).toBeDefined()
        expect(container).toHaveLength(1)
    })
})
