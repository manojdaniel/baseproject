/*
 * Created on Fri Sep 03 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { CONSOLE_OPERATIONS, DECREMENT_KVM_SESSIONS, INCREMENT_KVM_SESSIONS, RESET_KVM_SESSION, SET_ACTIVE_SEAT, UPDATE_CONTEXT_PID_MAPPINGS } from "../actions/types"
import consoleReducer, { initialStatesForConsole } from "./consoleReducer"

describe("Console Reducer", () => {
  it("should handle console reducer empty action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: "" })
    expect(value).toBeDefined()
  })

  it("should handle console reducer RESET_KVM_SESSION action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: RESET_KVM_SESSION })
    expect(value).toBeDefined()
  })

  it("should handle console reducer DECREMENT_KVM_SESSIONS action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: DECREMENT_KVM_SESSIONS })
    expect(value).toBeDefined()
  })

  it("should handle console reducer INCREMENT_KVM_SESSIONS action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: INCREMENT_KVM_SESSIONS })
    expect(value).toBeDefined()
  })

  it("should handle console reducer CONSOLE_OPERATIONS action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: CONSOLE_OPERATIONS })
    expect(value).toBeDefined()
  })

  it("should handle console reducer SET_ACTIVE_SEAT action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: SET_ACTIVE_SEAT })
    expect(value).toBeDefined()
  })

  it("should handle console reducer UPDATE_CONTEXT_PID_MAPPINGS action", () => {
    const value = consoleReducer({ initialStatesForConsole }, { type: UPDATE_CONTEXT_PID_MAPPINGS })
    expect(value).toBeDefined()
  })
})
