/*
 * Created on Mon Sept 07 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { CONSOLE_STORE, PARENT_STORE } from "../../constants/constants"
import globalStore from "./globalStore"

interface IGetGloalStoreDetails {
    storeName: string
    reducerPath: string
}
export const getGlobalStoreDetails = (props: IGetGloalStoreDetails) => {
    const { storeName, reducerPath } = props
    const gState = globalStore.GetGlobalState()
    if (gState[storeName] && gState[storeName][reducerPath]) {
        return gState[storeName][reducerPath]
    }
}

/* Global states */
export const fetchGlobalURLs = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.urls
}
export const fetchGlobalConfigs = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.configs
}
export const fetchGlobalFeatureFlags = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.featureFlagsReducer.featureFlags
}
export const fetchGlobalPermissions = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.userReducer.permissions
}
export const fetchGlobalOrgUUID = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.orgId
}

export const dispatchToParentStore = (action: any) => {
    globalStore.DispatchAction(PARENT_STORE, action)
}

export const fetchGlobalLocations = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.locations
}

export const fetchGlobalReceivers = () => {
    const gState = globalStore.GetGlobalState()
    const receivers = gState[CONSOLE_STORE]?.consoleReducer?.commandCenterDetails?.commandCenterSeat.receivers
    return receivers
}
