/*
 * Created on Tuesday Feb 22 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import App from "./App"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        navData: {},
        customers: [],
        notificationBubble: { message: "", success: false }
    }),
    useDispatch: () => jest.fn(),
    connect: () => () => jest.fn()
}))

describe("App component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<App />)
    })
    it("should render with the correct id", () => {
        expect(wrapper).toHaveLength(1)
    })
})
