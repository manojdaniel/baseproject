/*
* Created on Wed Aug 03 2022
*
* Copyright (c) 2022 Philips
* (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
* Reproduction or transmission in whole or in part, in any form or by any
* means, electronic, mechanical or otherwise, is prohibited without the prior
* written consent of the copyright owner.
*/

import { EAppStates, generateUuid, IAuthConfigs } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import queryString from "query-string"
import { Dispatch } from "redux"
import { DUMMY_LOGIN_USERNAME } from "../../../constants/constants"
import { SET_APPSTATE, UPDATE_AUTH_STATE } from "../../../redux/actions/types"
import { loginErrorMessages } from "../../../utility/helpers/helpers"
import { loginHandler } from "../AuthenticationService"
import { EAuthState, IAuthDeviceInfo, IAuthInitResponse, IAuthGetOtp, IAuthLogin, IAuthLoginResponse, IAuthOtp, IAuthDeviceInfoResponse, IAuthOtpResponse, IAuthResponse, OTP_MAXIMUM_ATTEMPTS, EIamErrorTypes, EIamResponseStatus } from "./iamAuthTypes"
import en from "../../../resources/locales/en_US.json"


declare function doAuthentication(amUrl: string, data: {} | IAuthLogin | IAuthDeviceInfo | IAuthOtp | IAuthGetOtp, callbackfn: (response: any) => void): any
declare function doAuthorization(amUrl: string, clientId: string, redirectUri: string, scopes: string, handleAuthzCallBack: (response: any) => void): any

let curAttempt = OTP_MAXIMUM_ATTEMPTS
/* User email address need to be submitted for audit in generic service during hsdp login, dummy email cannot be passed */

let userEmail: any
const { INIT, VAL_CRED, MATCH_DEVICE_INFO, COLLECT_DEVICE_INFO, GET_SERVER_OTP, SUCCESS, SHOW_SERVER_OTP, REDIRECT, SHOW_LOGIN, VALIDATE_SERVER_OTP, CALL_AUTHORIZE, ERROR } = EAuthState

export const iamAuthLoginHandler = (authConfigs: IAuthConfigs, data: any, dispatch: Dispatch<any>) => {
    const { authState, authId, } = authConfigs
    dispatch({ type: UPDATE_AUTH_STATE, authState: authConfigs.authState })
    try {
        switch (authState) {
            case INIT: {
                userEmail = ""
                curAttempt = OTP_MAXIMUM_ATTEMPTS
                doAuthentication(authConfigs.authUrl, {}, (response) => initAuthentication(response, authConfigs, data, dispatch))
                break
            }
            case VAL_CRED: {
                userEmail = data.username
                const body: IAuthLogin = {
                    authId: authId,
                    hint: VAL_CRED,
                    loginId: data.username,
                    password: data.password,
                }
                doAuthentication(authConfigs.authUrl, body, (response) => validateCredentials(response, authConfigs, dispatch))
                break
            }
            case COLLECT_DEVICE_INFO: {
                const body: IAuthDeviceInfo = {
                    authId,
                    deviceDetails: getDeviceDetails(),
                    hint: MATCH_DEVICE_INFO
                }
                doAuthentication(authConfigs.authUrl, body, (response) => validateDeviceInfo(response, authConfigs, dispatch))
                break
            }
            case GET_SERVER_OTP: {
                const body = {
                    authId,
                    hint: GET_SERVER_OTP
                }
                doAuthentication(authConfigs.authUrl, body, () => { return })
                break
            }
            case VALIDATE_SERVER_OTP: {
                const body: IAuthOtp = {
                    authId,
                    hint: VALIDATE_SERVER_OTP,
                    otp: data.otp,
                    trustDevice: data.trustDevice ? "1" : "0"
                }
                doAuthentication(authConfigs.authUrl, body, (response) => validateOtp(response, authConfigs, dispatch))
                break
            }
            case CALL_AUTHORIZE: {
                if (data.invalidate) {
                    doAuthorization(authConfigs.authUrl, `${authConfigs.appClientId}&prompt=login`, authConfigs.redirectUrl, "", (repsonse) => invalidateCookies(repsonse, authConfigs, data.content, dispatch))
                }
                else {
                    dispatch({ type: SET_APPSTATE, appState: EAppStates.LOADING })
                    doAuthorization(authConfigs.authUrl, `${authConfigs.appClientId}`, authConfigs.redirectUrl, "", (repsonse) => authorizeCallback(repsonse, dispatch))
                }
                break
            }
            case ERROR:
                /* Set button loading to false if error occurs */
                setLoading(false)
                handleLoginFailure("REQUEST_PROCESSING_FAILED", dispatch)
            default:
                break
        }
    } catch (error) {
        errorLogger(`Authentication handler failed during ${authState} stage with error ${errorParser(error)}`)
        handleLoginFailure("REQUEST_PROCESSING_FAILED", dispatch)
    }
}

export const initAuthentication = (response: { status: EIamResponseStatus, content: IAuthInitResponse }, authConfigs: IAuthConfigs, data: any, dispatch: Dispatch<any>) => {
    try {
        if (response.status === EIamResponseStatus.SUCCESS) {
            if (response.content.hint === SHOW_LOGIN) {
                dispatch({ type: UPDATE_AUTH_STATE, authState: SHOW_LOGIN, authId: response.content.data[0].value })
                iamAuthLoginHandler({ ...authConfigs, authId: response.content.data[0].value, authState: VAL_CRED }, data, dispatch)
            }
            /* If previous valid cookie is present this must be called to invalidate the cookie and reinitiate login process */
            else if (response.content.hint === CALL_AUTHORIZE) {
                iamAuthLoginHandler({ ...authConfigs, authState: CALL_AUTHORIZE }, { invalidate: true, content: { ...data } }, dispatch)
            }
            else {
                iamAuthLoginHandler({ ...authConfigs, authState: response.content.hint }, {}, dispatch)
            }
            return
        }
    } catch (error) {
        errorLogger(`Failed to initiate login with error ${errorParser(error)}`)
    }
    handleLoginFailure("REQUEST_PROCESSING_FAILED", dispatch)
}

export const validateCredentials = (response: { status: EIamResponseStatus, content: IAuthLoginResponse }, authConfigs: IAuthConfigs, dispatch: Dispatch<any>) => {
    try {
        if (response.status === EIamResponseStatus.SUCCESS) {
            iamAuthLoginHandler({ ...authConfigs, authState: response.content.hint }, {}, dispatch)
            return
        }
    } catch (error) {
        errorLogger(`Failed to parse the response with error ${errorParser(error)}`)
    }
    handleLoginFailure(EIamErrorTypes.UNAUTHORIZED, dispatch)
}

export const validateDeviceInfo = (response: { status: EIamResponseStatus, content: IAuthDeviceInfoResponse }, authConfigs: IAuthConfigs, dispatch: Dispatch<any>) => {
    try {
        if (response.status === EIamResponseStatus.SUCCESS) {
            if (response.content.hint === SHOW_SERVER_OTP) {
                setLoading(false)
            }
            iamAuthLoginHandler({ ...authConfigs, authState: response.content.hint }, {}, dispatch)
            return
        }
    } catch (error) {
        errorLogger(`Failed to validate device info with error ${errorParser(error)}`)
    }
    handleLoginFailure(EIamErrorTypes.UNAUTHORIZED, dispatch)
}

export const validateOtp = (response: { status: EIamResponseStatus, content: IAuthOtpResponse }, authConfigs: IAuthConfigs, dispatch: Dispatch<any>) => {
    try {
        if (response.status === EIamResponseStatus.SUCCESS) {
            if (response.content.hint === SHOW_SERVER_OTP) {
                curAttempt = curAttempt > 1 ? curAttempt - 1 : 1
                iamErrorTransformer(EIamErrorTypes.OTP_VERIFY_FAILED)
            }
            iamAuthLoginHandler({ ...authConfigs, authState: response.content.hint }, {}, dispatch)
            return
        }
    } catch (error) {
        errorLogger(`Failed to validate OTP with error ${errorParser(error)}`)
    }
    handleLoginFailure(EIamErrorTypes.OTP_LIMIT_EXCEEDED, dispatch)
}

export const authorizeCallback = async (response: { status: EIamResponseStatus, content: IAuthResponse }, dispatch: Dispatch<any>) => {
    try {
        if (response.status === EIamResponseStatus.SUCCESS) {
            if (response.content.hint === REDIRECT) {
                dispatch({ type: UPDATE_AUTH_STATE, authState: SUCCESS, authId: "" })
                const url = new URL(response.content.data[0].value)
                const queryStrings = queryString.parse(url.search)
                const codeGrant = queryStrings.code ? queryStrings.code as string : ""
                setLoading(false)
                await loginHandler({
                    loginUserName: userEmail,
                    loginUserKey: DUMMY_LOGIN_USERNAME,
                    codeGrant: codeGrant,
                    redirectUrl: `${window.location.origin}${window.location.pathname}`
                }, dispatch)
                userEmail = undefined
                return
            }
            /* Authorization call failed, show_login hint indicates unauthorized request */
            if (response.content.hint === SHOW_LOGIN) {
                handleLoginFailure(EIamErrorTypes.UNAUTHORIZED, dispatch)
                return
            }
        }
    } catch (error) {
        errorLogger(`Failed to get code grant with error ${errorParser(error)}`)
    }
    handleLoginFailure("REQUEST_PROCESSING_FAILED", dispatch)
}


export const invalidateCookies = (response: { status: EIamResponseStatus, content: IAuthResponse }, authConfigs: IAuthConfigs, data: any, dispatch: Dispatch<any>) => {
    if (response.content.hint === SHOW_LOGIN) {
        /* data: {invalidate: true or false , content : {username, pass}} */
        iamAuthLoginHandler({ ...authConfigs, authId: "", authState: INIT }, data, dispatch)
    } else {
        handleLoginFailure("REQUEST_PROCESSING_FAILED", dispatch)
    }
}

const getDeviceDetails = () => ({
    "screen": { screenWidth: screen.width, screenHeight: screen.height, screenColourDepth: screen.colorDepth },
    "hsdpDeviceID": getHsdpDeviceID(),
    "userAgent": navigator.userAgent,
    "appName": navigator.appName,
    "appCodeName": navigator.appCodeName,
    "appVersion": navigator.appVersion,
    "platform": navigator.appVersion,
    "product": navigator.product,
    "productSub": navigator.productSub,
    "vendor": navigator.vendor,
    "language": navigator.language,
    "timezone": { "timezone": new Date().getTimezoneOffset() }
})

const getHsdpDeviceID = () => {
    let hsdpDeviceID = localStorage.getItem("hsdpDeviceID")
    if (!hsdpDeviceID) {
        hsdpDeviceID = generateUuid()
        localStorage.setItem("hsdpDeviceID", hsdpDeviceID)
    }
    return hsdpDeviceID
}

const iamErrorTransformer = (errorMessage: string) => {
    const { intl } = getIntlProvider()
    const { UNAUTHORIZED, DEVICE_VERIFICATION_FAILED, OTP_LIMIT_EXCEEDED, OTP_VERIFY_FAILED } = EIamErrorTypes
    switch (errorMessage) {
        case UNAUTHORIZED:
            return setErrorMssg(loginErrorMessages("WRONG_USER_CREDENTIALS_CODEGRANT"))
        case DEVICE_VERIFICATION_FAILED:
            return setErrorMssg(loginErrorMessages("REQUEST_PROCESSING_FAILED"))
        case OTP_VERIFY_FAILED:
            return setErrorMssg(intl.formatMessage({ id: "content.otp.invalidOtpLimit", defaultMessage: en["content.otp.invalidOtpLimit"] }, { current: curAttempt, maximum: 3 }))
        case OTP_LIMIT_EXCEEDED:
            return setErrorMssg(intl.formatMessage({ id: "content.otp.limitExceeded", defaultMessage: en["content.otp.limitExceeded"] },))
        default:
            return setErrorMssg(loginErrorMessages(errorMessage))
    }
}

const setErrorMssg = (errorMessage: string) => {
    const event = new CustomEvent("iam:setErrorMssg", { detail: errorMessage })
    window.dispatchEvent(event)
}

const setLoading = (loading: boolean) => {
    const event = new CustomEvent("iam:setLoading", { detail: loading })
    window.dispatchEvent(event)
}

const handleLoginFailure = (message: string, dispatch: Dispatch<any>) => {
    iamErrorTransformer(message)
    dispatch({ type: UPDATE_AUTH_STATE, authState: ERROR })
}
