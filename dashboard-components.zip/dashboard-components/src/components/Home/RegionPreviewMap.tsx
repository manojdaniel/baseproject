// @ts-nocheck
import React from "react";
import "./RegionPreviewMap.scss";
import {
	MapContainer,
	TileLayer,
	useMap,
	SVGOverlay,
	Popup,
	CircleMarker,
} from "react-leaflet";
import AlertMapPop from "./AlertMapPop";

interface Props {
	getSelectedRegion: any;
	getSelectedRegionData: any[];
	handleNavigation: any;
}

const RegionPreviewMap = ({
	getSelectedRegion,
	getSelectedRegionData,
	handleNavigation,
}: Props) => {

	const onClickAffiliates = (key: any, data: any) => {

		handleNavigation({ "value": data.regionId, "label": data.regionName })
		
	}

	function SetViewOnClick({ coords }: any) {
		const map = useMap();
		map.setView(coords, map.getZoom());

		return null;
	}

	//==================country filter data without NULL in longitude & latitude======
	let RegionAffiliates = [];
	getSelectedRegionData.forEach((device: any, index: any) => {
		RegionAffiliates[index] = { ...device };
	});
	let getSelectedRegionDataFinal = [];
	for (var i = 0; i < RegionAffiliates.length; i++) {
		if (
			RegionAffiliates[i].latitude !== null ||
			RegionAffiliates[i].longitude !== null
		) {
			let localdata = {
				affiliateCount: RegionAffiliates[i].affiliateCount,
				countryId: RegionAffiliates[i].countryId,
				regionId: RegionAffiliates[i].regionId,
				regionName: RegionAffiliates[i].regionName,
				name: RegionAffiliates[i].name,
				abrv: RegionAffiliates[i].abrv,
				latitude: RegionAffiliates[i].latitude,
				longitude: RegionAffiliates[i].longitude,
				healthIndex: RegionAffiliates[i].healthIndex,
				pmCompliance: RegionAffiliates[i].pmCompliance,
				active: RegionAffiliates[i].active,
				overDue: RegionAffiliates[i].overDue,
				underInvestigation: RegionAffiliates[i].underInvestigation,
			};
			getSelectedRegionDataFinal.push(localdata);
		}
	}
	//======================END===============================================================

	const getRegionAffiliates = getSelectedRegionDataFinal.filter(
		({ regionId }) => regionId === getSelectedRegion.regionId
	);

	return (
		<MapContainer
			center={[getSelectedRegion.latitude, getSelectedRegion.longitude]}
			zoom={3}
			scrollWheelZoom={false}
		>
			<TileLayer
				attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
				url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
			/>
			{getRegionAffiliates.map((data) => (
				<>
					<CircleMarker
						center={[data.latitude, data.longitude]}
						pathOptions={{ color: "#009fdf", fillColor: "#009fdf" }}
						radius={10}
						weight={15}
						opacity={0.5}
						fillOpacity={0.5}
						eventHandlers={{
							mouseover: (event) => event.target.openPopup(),
							mouseout: (event) => event.target.closePopup(),
							click: () => onClickAffiliates("affiliates", data),
						}}
					// value={10}
					>
						<Popup>
							<AlertMapPop alertmapPopData={data} />
						</Popup>
					</CircleMarker>
					<SVGOverlay
						attributes={{ stroke: "red" }}
						bounds={[
							[data.latitude, data.longitude],
							[data.latitude, data.longitude],
						]}
					>
						{data.affiliateCount > 9 ? (
							<text x="42%" y="50%" stroke="#58595b">
								{data.affiliateCount}
							</text>
						) : (
							<text x="50%" y="50%" stroke="#58595b">
								{data.affiliateCount}
							</text>
						)}
					</SVGOverlay>
				</>
			))}
			<SetViewOnClick
				coords={[getSelectedRegion.latitude, getSelectedRegion.longitude]}
			/>
		</MapContainer>
	);
};

export default RegionPreviewMap;
