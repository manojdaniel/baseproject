import React, { useEffect, useState } from "react";
import { Table, Layout } from "antd";
import "../../assets/common/CommonTables.scss";

interface Props {
	data: any[];
	saveCurrentRegionStore: any;
	loading?: any
}

const ReferenceTable = ({ data, saveCurrentRegionStore, loading }: Props) => {
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
	}, [currentScreenWidth]);
	const columns = [
		{
			title: "MODEL",
			dataIndex: "modelName",
			key: "modelName",
			width: '25%',
		},
		{
			title: "SENSOR NAME",
			dataIndex: "sensorName",
			key: "sensorName",
			width: '25%',
		},

		{
			title: "UOM",
			dataIndex: "uom",
			key: "uom",
			width: '15%',
		},
		{
			title: "HIGH",
			dataIndex: "high",
			key: "high",
			width: '15%',
		},
		{
			title: "LOW",
			dataIndex: "low",
			key: "low",
			width: '15%',
		},
	];
	const mobileColumns = [
		{
			title: "MODEL",
			dataIndex: "modelName",
			key: "modelName",
			width: 150,
		},
		{
			title: "SENSOR NAME",
			dataIndex: "sensorName",
			key: "sensorName",
			width: 150,
		},

		{
			title: "UOM",
			dataIndex: "uom",
			key: "uom",
			width: 60,
		},
		{
			title: "HIGH",
			dataIndex: "high",
			key: "high",
			width: 60,
		},
		{
			title: "LOW",
			dataIndex: "low",
			key: "low",
			width: 60,
		},
	];
	return (
		<>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Layout style={{ minHeight: "100%" }}>
							<Table
								columns={columns}
								dataSource={data}
								loading={loading}
								tableLayout={undefined}
								pagination={{ pageSize: 10, showSizeChanger: false }}
								scroll={{ x: true, y: '100%' }}
							/>
						</Layout>
					);
				} else {
					return (
						<Layout style={{ minHeight: "100%" }}>
							<Table
								columns={mobileColumns}
								tableLayout={undefined}
								loading={loading}
								dataSource={data}
								pagination={{ pageSize: 5, showSizeChanger: false }}
								scroll={{ x: '480px' }}
							/>
						</Layout>
					);
				}
			})()}
		</>
	);
};

export default ReferenceTable;
