/*
 * Created on Wed Sep 15 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { mount } from "enzyme"
import React from "react"
import { ADD_PARTICIPANT, ALREADY_ON_CALL, CALL_ACCEPT, CALL_END, CALL_MISSED, CALL_REJECT, INCOMING_CALL } from "../../../../constants/constants"
import * as CallEnd from "./event-handlers/CallEnd"
import MessageHandler from "./MessageHandler"

jest.mock("../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({
        audioOutputSource: "source 1",
        callRingStatus: true,
    }),
    useDispatch: () => jest.fn(),
}))

jest.mock("../../../../redux/store/externalAppStates", () => ({
    getGlobalStoreDetails: () => {
        return {
        }
    },
    fetchGlobalURLs: () => { "" }
}))

describe("MessageHandler component", () => {
    let wrapper: any
    const props = {
        eventType: INCOMING_CALL,
        contextId: "1",
        participant: "participant1",
    }
    beforeEach(() => {
        wrapper = mount(<MessageHandler {...props} />)
    })

    it("should render MessageHandler component with incoming call", () => {
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with accept call", () => {
        props.eventType = CALL_ACCEPT
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with add participant", () => {
        props.eventType = ADD_PARTICIPANT
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with call reject", () => {
        props.eventType = CALL_REJECT
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with call end", () => {
        props.eventType = CALL_END
        jest.spyOn(CallEnd, "callEnd").mockImplementation(() => undefined)
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with call missed", () => {
        props.eventType = CALL_MISSED
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
    it("should render MessageHandler component with aready on call", () => {
        props.eventType = ALREADY_ON_CALL
        wrapper = mount(<MessageHandler {...props} />)
        expect(wrapper.find("CallRing")).toHaveLength(1)
    })
})
