/*
 * Created on Thu Sept 22 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { DEFAULT_CONTACT_INFO, ECallStatus, IAVCallDetails } from "@rocc/rocc-client-services"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { AUDIO, VIDEO } from "../../constants/constants"
import { EAvSettingsType, EClientStatus } from "../interfaces/types"
import { DEFAULT_INCOMING_CALL_DEATILS, DEFAULT_ONGOING_CALL_DETAILS, DEFAULT_OUTGOING_CALL_DEATILS } from "../reducers/callReducer"
import { dispatchToParentStore } from "../store/externalAppStates"
import { resetBadgeCountOfMissedCalls, sendWorkflowEvent, setAVCallVolume, setCallMessage, setCallRingStatus, setChannelSid, setCommunicationVendorName, setConversationClientStatus, setDeafenCall, setDesktopCallWindowFullScreen, setIncomingCallDetails, setIsFirstParticipant, setMissedCalls, setMuteCall, setOutgoingCallDetails, setPhoneCallStatus, setRecentMissedCall, settingsVideoAudioCallStatus, setVideoCallStatus, storeCallDetails, storeOnHoldCallDetails, updateAVsettingsLocalstorage, updateCallTimeout } from "./callActions"
import { AV_SETTINGS, CALL_MESSAGE, CONNECTED_CALL_DETAILS, DEFAULT_AV_SETTINGS, IS_FIRST_PARTICPANT, ON_HOLD_CALLS, SET_AV_CALL_VOLUME, SET_CALL_DEAFEN, SET_CALL_MUTE, SET_CALL_RING_STATUS, SET_CHANNEL_SID, SET_COMMUNICATION_VENDOR, SET_CONVERSATION_CLIENT_STATUS, SET_FULL_SCREEN, SET_INCOMING_CALL_DETAILS, SET_MISSED_CALL_DATA, SET_OUTGOING_CALL_DETAILS, SET_RECENT_MISSED_CALL, UPDATE_CALL_TIMEOUT, VIDEO_CALL_STATUS } from "./types"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

jest.mock("../store/externalAppStates", () => ({
    dispatchToParentStore: jest.fn(),
}))

describe("Test for Call Actions", async () => {
    const store = mockStore({
        callReducer: {
            callTimeout: [{ contextId: "contextId", timeout: 100 }],
            missedCalls: [{ callContextId: "contextId" }],
            recentMissedCall: { callContextId: "recentContextId" },
        }
    })
    beforeEach(() => {
        store.clearActions()
    })
    it("sendWorkflowEvent is defined", () => {
        store.dispatch(sendWorkflowEvent("", "") as any)
        expect(dispatchToParentStore).toBeCalled()
        store.clearActions()
    })

    it("setPhoneCallStatus is defined", () => {
        store.dispatch(setPhoneCallStatus(ECallStatus.CALLING) as any)
        expect(String(store.getActions()[0].phoneCallStatus)).toBe(ECallStatus.CALLING)
        store.clearActions()
    })

    it("setDesktopCallWindowFullScreen is defined", () => {
        store.dispatch(setDesktopCallWindowFullScreen(true) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_FULL_SCREEN)
        store.clearActions()
    })

    it("setChannelSid is defined", () => {
        store.dispatch(setChannelSid("channelSid") as any)
        expect(String(store.getActions()[0].type)).toBe(SET_CHANNEL_SID)
        store.clearActions()
    })

    it("setIncomingCallDetails is defined", () => {
        store.dispatch(setIncomingCallDetails({ ...DEFAULT_INCOMING_CALL_DEATILS }) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_INCOMING_CALL_DETAILS)
        store.clearActions()
    })

    it("setOutgoingCallDetails is defined", () => {
        store.dispatch(setOutgoingCallDetails({ ...DEFAULT_OUTGOING_CALL_DEATILS }) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_OUTGOING_CALL_DETAILS)
        store.clearActions()
    })

    it("storeCallDetails is defined", () => {
        store.dispatch(storeCallDetails({ ...DEFAULT_ONGOING_CALL_DETAILS }) as any)
        expect(String(store.getActions()[0].type)).toBe(CONNECTED_CALL_DETAILS)
        store.clearActions()
    })

    it("storeOnHoldCallDetails is defined", () => {
        store.dispatch(storeOnHoldCallDetails([{ ...DEFAULT_ONGOING_CALL_DETAILS }]) as any)
        expect(String(store.getActions()[0].type)).toBe(ON_HOLD_CALLS)
        store.clearActions()
    })

    it("setCallMessage is defined", () => {
        store.dispatch(setCallMessage({ messageType: "CallMessage", message: "", contact: DEFAULT_CONTACT_INFO }) as any)
        expect(String(store.getActions()[0].type)).toBe(CALL_MESSAGE)
        store.clearActions()
    })

    it("setVideoCallStatus is defined", () => {
        store.dispatch(setVideoCallStatus([{ callStatus: ECallStatus.CALLING, contextId: "contextId" }]) as any)
        expect(String(store.getActions()[0].type)).toBe(VIDEO_CALL_STATUS)
        store.clearActions()
    })

    it("setIsFirstParticipant is defined", () => {
        store.dispatch(setIsFirstParticipant(true) as any)
        expect(String(store.getActions()[0].type)).toBe(IS_FIRST_PARTICPANT)
        store.clearActions()
    })

    it("settingsVideoAudioCallStatus is defined for audio input", () => {
        store.dispatch(settingsVideoAudioCallStatus(EAvSettingsType.AUDIO_INPUT, AUDIO) as any)
        expect(String(store.getActions()[0].type)).toBe(AV_SETTINGS)
        store.clearActions()
    })

    it("settingsVideoAudioCallStatus is defined for video input", () => {
        store.dispatch(settingsVideoAudioCallStatus(EAvSettingsType.VIDEO_INPUT, VIDEO) as any)
        expect(String(store.getActions()[0].type)).toBe(AV_SETTINGS)
        store.clearActions()
    })

    it("settingsVideoAudioCallStatus is defined for audio output", () => {
        store.dispatch(settingsVideoAudioCallStatus(EAvSettingsType.AUDIO_OUTPUT, "audioOutput") as any)
        expect(String(store.getActions()[0].type)).toBe(AV_SETTINGS)
        store.clearActions()
    })

    it("updateAVsettingsLocalstorage is defined", () => {
        store.dispatch(updateAVsettingsLocalstorage() as any)
        expect(String(store.getActions()[0].type)).toBe(DEFAULT_AV_SETTINGS)
        store.clearActions()
    })

    it("setAVCallVolume is defined", () => {
        store.dispatch(setAVCallVolume(100) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_AV_CALL_VOLUME)
        store.clearActions()
    })

    it("setRecentMissedCall is defined", () => {
        store.dispatch(setRecentMissedCall({ attemptedCallTime: "", callContextId: "contextId", callee: "", caller: "", id: "", seen: false }) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_RECENT_MISSED_CALL)
        store.clearActions()
    })

    it("setCallRingStatus is defined", () => {
        store.dispatch(setCallRingStatus(true) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_CALL_RING_STATUS)
        store.clearActions()
    })

    it("setConversationClientStatus is defined", () => {
        store.dispatch(setConversationClientStatus(EClientStatus.ONLINE) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_CONVERSATION_CLIENT_STATUS)
        store.clearActions()
    })

    it("updateCallTimeout is defined for status as true", () => {
        const timeoutObject: any = { contextId: "contextId", timeoutId: 100 }
        store.dispatch(updateCallTimeout(timeoutObject, true) as any)
        expect(String(store.getActions()[0].type)).toBe(UPDATE_CALL_TIMEOUT)
        store.clearActions()
    })

    it("updateCallTimeout is defined for status as false", () => {
        const timeoutObject: any = { contextId: "contextId", timeoutId: 100 }
        store.dispatch(updateCallTimeout(timeoutObject, false) as any)
        expect(String(store.getActions()[0].type)).toBe(UPDATE_CALL_TIMEOUT)
        store.clearActions()
    })

    it("updateCallTimeout is defined for context id don't exist", () => {
        const timeoutObject: any = { contextId: "contextId1", timeoutId: 100 }
        store.dispatch(updateCallTimeout(timeoutObject, false) as any)
        expect(String(store.getActions()[0].type)).toBe(UPDATE_CALL_TIMEOUT)
        store.clearActions()
    })

    it("setMissedCalls is defined", () => {
        const missedCalls: any = [{ attemptedCallTime: "", callContextId: "contextId", callee: "", caller: "", id: "", seen: false }]
        store.dispatch(setMissedCalls(missedCalls) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_RECENT_MISSED_CALL)
        store.clearActions()
    })

    it("resetBadgeCountOfMissedCalls is defined", () => {
        store.dispatch(resetBadgeCountOfMissedCalls(true) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_MISSED_CALL_DATA)
        store.clearActions()
    })

    it("setMuteCall is defined", () => {
        store.dispatch(setMuteCall({} as IAVCallDetails, true) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_CALL_MUTE)
        store.clearActions()
    })

    it("setDeafenCall is defined", () => {
        store.dispatch(setDeafenCall({} as IAVCallDetails, true) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_CALL_DEAFEN)
        store.clearActions()
    })

    it("setCommunicationVendor is defined", () => {
        store.dispatch(setCommunicationVendorName({ vendorId: "", vendorName: "" }) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_COMMUNICATION_VENDOR)
        store.clearActions()
    })

})
