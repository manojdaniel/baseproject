/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IModalReducer } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import {
    GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_NOTIFICATION_MODAL
} from "../actions/types"

export const initialStatesForModals: IModalReducer = {
    notificationModal: {
        showModal: false,
        showCloseIcon: false,
        header: "",
        modalContent: "",
    },
    notificationMessage: {
        showNotification: false,
        message: [{
            header: "",
            content: ""
        }],
        closeMessage: () => { return false },
        isSuccess: false,
        isWarning: false,
        isNotification: false
    }
}

const modalReducer: Reducer = (state: IModalReducer = initialStatesForModals, action: any) => {
    switch (action.type) {
        case GLOBAL_UPDATE_NOTIFICATION_MODAL:
            return { ...state, notificationModal: action.payload.notificationModal }
        case GLOBAL_UPDATE_NOTIFICATION_MESSAGE:
            return { ...state, notificationMessage: action.payload.notificationMessage }
        default:
    }
    return { ...state }
}

export default modalReducer
