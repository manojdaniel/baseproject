import unittest
from unittest.mock import patch
from src.constants.headers import EXCEL_ROOM_MODALITY, EXCEL_ROOM_SITE_IDENTIFIER
from src.modules.insertion_management.manage_rooms import ManageRooms
from src.constants.constants import ROOMS_DICT, SITES_DICT


class ManageRoomsTest(unittest.TestCase):
    @patch("src.modules.insertion_management.manage_rooms.get_path_specific_vault_values", side_effect=lambda path_name: {"data": {"hsdpOrganizationId": "abc"}})
    @patch("src.modules.insertion_management.manage_rooms.get_client_connection", side_effect=lambda access_token, org_infra_uuid:  None)
    @patch("src.modules.insertion_management.manage_rooms.get_site_id_from_site_short_name", side_effect=lambda client, site_short_name, sites: True)
    @patch("src.modules.insertion_management.manage_rooms.fetch_device_access_token", side_effect=lambda url, device_id: "token")
    def test_start_job(self, vault_val, con, site_id, device_token):
        vault_val.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        con.return_value = {"key": "connection object"}
        site_id.return_value = "site_id"
        device_token.return_value = "abc"
        data_dict = {}
        data_dict[ROOMS_DICT] = {"key": {"eligibility": {"new_device": ""}, "device_id": False, "Room Identifier (To be filled by Philips)": ""}}
        data_dict[SITES_DICT] = "site"
        manage_rooms = ManageRooms(
            data_dict, {}, 1234, "abc", "kvm_config_id", {}, 11)
        manage_rooms.update_rooms_dict_with_device_ids([1, 2, 3])
        manage_rooms.setup_communication_infra_for_rooms()

        manage_rooms._rooms = {"key": {EXCEL_ROOM_MODALITY: "modality", EXCEL_ROOM_SITE_IDENTIFIER: "site_identifier"}}
        manage_rooms.update_rooms_dict_with_sites()
        with self.assertRaises(Exception):
            manage_rooms._rooms = {"key": "failedcase"}
            manage_rooms.update_rooms_dict_with_sites()
        with self.assertRaises(Exception):
            manage_rooms._rooms = {"key": {EXCEL_ROOM_MODALITY: "modality", EXCEL_ROOM_SITE_IDENTIFIER: "site_identifier", "device_id": 123}}
            manage_rooms.create_rbac_roles_for_rooms()
        with self.assertRaises(Exception):
            manage_rooms.create_communication_profile("token", "device id", "short_name", {})
        self.assertIsNotNone(manage_rooms)
