/*
 * Created on Sun Oct 07 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { fetchHttpClient, safeURL, postCall, getCall, putCall, deleteCall, postService, putService, deleteService, getService } from "./apiUtility"
import * as apiUtility from "./apiUtility"

describe("test http calls and services", () => {
    let httpClientSpy: jest.SpyInstance
    const mockHttpClient = {
        postCall: jest.fn(),
        getCall: jest.fn(),
        putCall: jest.fn(),
        deleteCall: jest.fn(),
        postService: jest.fn(),
        getService: jest.fn(),
        putService: jest.fn(),
        deleteService: jest.fn(),
    }
    
    const httpParams = {
        url: "http-call-url",
        data: { attr: "value" },
        headers: { headerType: "header-value" },
    }

    beforeAll(() => {
        httpClientSpy = jest.spyOn(apiUtility, "fetchHttpClient").mockImplementation(() => mockHttpClient as any)
    })

    it("should call http post call", () => {
        postCall(httpParams)
        const postCallMock = (fetchHttpClient() as any).postCall as jest.Mock
        expect(postCallMock).toBeCalledWith(httpParams)
    })

    it("should call http get call", () => {
        const {data, ...getParams} = httpParams
        getCall(getParams)
        const getCallMock = (fetchHttpClient() as any).getCall as jest.Mock
        expect(getCallMock).toBeCalledWith(getParams)
    })


    it("should call http put call", () => {
        putCall(httpParams)
        const putCallMock = (fetchHttpClient() as any).putCall as jest.Mock
        expect(putCallMock).toBeCalledWith(httpParams)
    })

    it("should call http delete call", () => {
        deleteCall(httpParams)
        const deleteCallMock = (fetchHttpClient() as any).deleteCall as jest.Mock
        expect(deleteCallMock).toBeCalledWith(httpParams)
    })

    it("should call http post service", () => {
        postService(httpParams)
        const postServiceMock = (fetchHttpClient() as any).postService as jest.Mock
        expect(postServiceMock).toBeCalledWith(httpParams)
    })

    it("should call http get service", () => {
        const {data, ...getParams} = httpParams
        getService(getParams)
        const getServiceMock = (fetchHttpClient() as any).getService as jest.Mock
        expect(getServiceMock).toBeCalledWith(getParams)
    })

    it("should call http put service", () => {
        putService(httpParams)
        const putServiceMock = (fetchHttpClient() as any).putService as jest.Mock
        expect(putServiceMock).toBeCalledWith(httpParams)
    })

    
    it("should call http delete call", () => {
        deleteService(httpParams)
        const deleteServiceMock = (fetchHttpClient() as any).deleteService as jest.Mock
        expect(deleteServiceMock).toBeCalledWith(httpParams)
    })

    afterEach(() => {
        httpClientSpy.mockClear()
    })

    afterAll(() => {
        httpClientSpy.mockRestore()
    })

})

describe("safe url", () => {
    it("should append uri if not present on url", () => {
        const safeUrlReturn = safeURL("https://some-url.com/", "uri")
        expect(safeUrlReturn).toEqual("https://some-url.com/uri")
    })

    it("should return url as is if uri already present on url", () => {
        const safeUrlReturn = safeURL("https://some-url.com/uri", "uri")
        expect(safeUrlReturn).toEqual("https://some-url.com/uri")
    })
})
