/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { EProtocolTransferSteps, ILeaveProtocolTransferConfirmProps } from "../../redux/interfaces/types"
import CompletionStep from "./steps/CompletionStep"
import ConnectToDestinationScanner from "./steps/ConnectToDestinationScanner"
import ConnectToSourceScanner from "./steps/ConnectToSourceScanner"
import SelectDestinationScanner from "./steps/SelectDestinationScanner"
import SelectSourceScanner from "./steps/SelectSourceScanner"

interface IProtocolTransferStepProvider {
    stepNumber: number
    setLeaveProtocolTransferDlg: (props: ILeaveProtocolTransferConfirmProps) => void
}

const ProtocolTransferStepProvider = (props: IProtocolTransferStepProvider) => {

    const { stepNumber, setLeaveProtocolTransferDlg } = props

    const getStepContent = () => {
        switch (stepNumber) {
            case EProtocolTransferSteps.SelectSourceScanner: {
                return <SelectSourceScanner />
            }
            case EProtocolTransferSteps.ConnectToSourceScanner: {
                return <ConnectToSourceScanner />
            }
            case EProtocolTransferSteps.SelectDestinationScanner: {
                return <SelectDestinationScanner />
            }
            case EProtocolTransferSteps.ConnectToDestinationScanner: {
                return <ConnectToDestinationScanner />
            }
            case EProtocolTransferSteps.CompletionStep: {
                return <CompletionStep
                    setLeaveProtocolTransferDlg={setLeaveProtocolTransferDlg}
                />
            }
        }
        return null
    }
    return getStepContent()
}

export default ProtocolTransferStepProvider
