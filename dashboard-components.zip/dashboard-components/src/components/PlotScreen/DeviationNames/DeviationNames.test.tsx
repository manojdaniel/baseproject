import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import DeviationNames from "./index";

describe("DeviationNames", () => {
	it("renders correctly", () => {
		const { getByText } = render(<DeviationNames />);
		expect(getByText("MEASURE NAMES")).toBeInTheDocument();
		expect(getByText("Distance")).toBeInTheDocument();
		expect(getByText("Warning Level")).toBeInTheDocument();
		expect(getByText("Alert Level")).toBeInTheDocument();
		expect(getByText("Anomaly Alert")).toBeInTheDocument();
		expect(getByText("Warning")).toBeInTheDocument();
		expect(getByText("Normal")).toBeInTheDocument();
		expect(getByText("Asset off")).toBeInTheDocument();
		expect(
			getByText("Poor data / State Change / Pi data disconnection")
		).toBeInTheDocument();
	});
});
