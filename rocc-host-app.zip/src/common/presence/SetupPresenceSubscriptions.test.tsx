/*
 * Created on Tue May 24 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"

import { SetupPresenceSubscriptions } from "./SetupPresenceSubscriptions"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        featureFlags: { "rocc-radconnect": true },
        currentUser: {
            onBoarded: true,
            allRoles: ["Admin", "ExpertUser", "Radiologist", "Technologist"],
            clinicalRole: "Expert user"
        },
        contacts: [],
        contactsFetched: false,
        rooms: []
    }),
    useDispatch: () => void (0),
}))


const client: any = {
    map: jest.fn().mockReturnValue({
        get: jest.fn().mockReturnValue({
            descriptor: {
                data: {
                    loggedInTech: "123",
                    presence: EUserPresence.AVAILABLE

                }
            }
        }),
        on: jest.fn(),
    })
}

describe("should render PresenceController component", () => {

    it("should render SubscribeToPresence component", () => {
        const wrapper = shallow(<SetupPresenceSubscriptions syncClient={client} />)
        expect(wrapper.find("SubscribeToPresence")).toHaveLength(1)
    })
})
