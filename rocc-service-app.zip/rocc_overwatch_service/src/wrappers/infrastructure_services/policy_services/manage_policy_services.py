"""
 Created on Thu Oct 29 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, API_VERSION, ACCEPT
from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_EVAL_APP_ID, VAULT_PARENT_POLICY_NAME, VAULT_HSDP_IDM_URL, VAULT_PASSWORD_EXPIRY_DAYS

LOG = create_logger("ManageHSDPPolicyServices")


def create_all_policies(token, profile_configs):
    # TODO: Need to add policies to support service token on R-BAC/Manage user operations
    policy_ids = []
    password_policy_id = None
    try:
        """ Policy creation """
        policy_id = create_policy(token, profile_configs)
        if policy_id is not None:
            LOG.info(f"PolicyId::::::{policy_id}\n")
            policy_ids.append(policy_id)

        """ Scope Policy creation """
        scope_policy_id = create_scope_policy(token, profile_configs)
        if scope_policy_id is not None:
            LOG.info(f"ScopePolicyId:::::: {scope_policy_id}\n")
            policy_ids.append(scope_policy_id)

        """ Communication profile delete Policy creation """
        communication_profile_delete_policy_id = create_communication_profile_delete_policy(
            token, profile_configs)
        if communication_profile_delete_policy_id is not None:
            LOG.info(
                f"communication_profile_delete_policy_id:::::: {communication_profile_delete_policy_id}\n")
            policy_ids.append(communication_profile_delete_policy_id)

        """ Communication profile Policy creation """
        communication_profile_policy_id = create_communication_profile_policy(
            token, profile_configs)
        if communication_profile_policy_id is not None:
            LOG.info(
                f"communication_profile_policy_id:::::: {communication_profile_policy_id}\n")
            policy_ids.append(communication_profile_policy_id)

        """ User role mapping Policy creation """
        user_role_mapping_policy_id = create_user_role_mapping_policy(
            token, profile_configs)
        if user_role_mapping_policy_id is not None:
            LOG.info(
                f"user_role_mapping_policy_id:::::: {user_role_mapping_policy_id}\n")
            policy_ids.append(user_role_mapping_policy_id)

        """ Security questions Policy creation """
        security_question_policy_id = create_get_security_question_policy(
            token, profile_configs)
        if security_question_policy_id is not None:
            LOG.info(
                f"security_question_policy_id:::::: {security_question_policy_id}\n")
            policy_ids.append(security_question_policy_id)

        """ Validate role mapping Policy creation """
        validate_role_mapping_policy_id = create_validate_policy(
            token, profile_configs)
        if validate_role_mapping_policy_id is not None:
            LOG.info(
                f"validate_role_mapping_policy_id:::::: {validate_role_mapping_policy_id}\n")
            policy_ids.append(validate_role_mapping_policy_id)

        """ Password Policy creation """
        password_policy_id = create_password_policy(token, profile_configs)
        if password_policy_id is not None:
            LOG.info(f"password_policy_id:::::: {password_policy_id}\n")
        """ Password Policy creation """
        service_tools_policy_id = create_service_tools_policy(
            token, profile_configs)
        if service_tools_policy_id is not None:
            LOG.info(
                f"service_tools_policy_id:::::: {service_tools_policy_id}\n")
            policy_ids.append(service_tools_policy_id)
    except Exception as ex:
        LOG.error(f"Error while creating policies: {ex}")
    return policy_ids, password_policy_id


def create_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": profile_configs[VAULT_PARENT_POLICY_NAME],
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/presence*?*", "http://*apps.internal:8080/philips/rocc/presence*?*",
                          "https://*/philips/rocc/Token*?*", "http://*apps.internal:8080/philips/rocc/Token*?*",
                          "https://*/philips/rocc/Call*?*", "http://*apps.internal:8080/philips/rocc/Call*?*",
                          "https://*/philips/rocc/Message*?*", "http://*apps.internal:8080/philips/rocc/Message*?*",
                          "https://*/philips/rocc/user/*?*", "http://*apps.internal:8080/philips/rocc/user/*?*",
                          "https://*/philips/rocc/data/Graphql*?*", "http://*apps.internal:8080/philips/rocc/data/Graphql*?*",
                          "https://*/philips/rocc/calendarservice*?*", "http://*apps.internal:8080/philips/rocc/calendarservice*?*",
                          "https://*/philips/rocc/RegionConfig*?*", "http://*apps.internal:8080/philips/rocc/RegionConfig*?*",
                          "https://*/philips/rocc/filemgmt*?*", "http://*apps.internal:8080/philips/rocc/filemgmt*?*",
                          "https://*/philips/rocc/conversations*?*", "http://*apps.internal:8080/philips/rocc/conversations*?*",
                          "https://*/philips/rocc/radconnect*?*", "http://*apps.internal:8080/philips/rocc/radconnect*?*"],
            "actions": {"POST": "true", "GET": "true", "DELETE": "true", "PUT": "true"},
            "subject": {"type": "AuthenticatedUsers"}}
    try:

        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Access policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating access policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating access policy: {ex}")
    return False


def create_scope_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}Scope",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/admin/*?*", "http://*apps.internal:8080/philips/rocc/admin/*?*",
                          "https://*/philips/rocc/devicemgmt/*?*", "http://*apps.internal:8080/philips/rocc/devicemgmt/*?*",
                          "https://*/philips/rocc/authorize/*?*", "http://*apps.internal:8080/philips/rocc/authorize/*?*",
                          "https://*/philips/rocc/twilio/Account*?*", "http://*apps.internal:8080/philips/rocc/twilio/Account*?*",
                          "https://*/philips/rocc/manage/SecurityQuestions*?*", "http://*apps.internal:8080/philips/rocc/manage/SecurityQuestions*?*",
                          "https://*/philips/rocc/mgmt/platform/*?*", "http://*apps.internal:8080/philips/rocc/mgmt/platform/*?*",
                          "https://*/philips/rocc/usermgmt/platform*?*", "http://*apps.internal:8080/philips/rocc/usermgmt/platform*?*"],
            "actions": {"POST": "true", "GET": "true", "DELETE": "true", "PUT": "false"},
            "subject": {"type": "AuthenticatedUsers"},
            "condition": {"type": "Scope", "value": {"allOf": ["openid"]}}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Scope policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating scope policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating scope policy: {ex}")
    return False


def create_communication_profile_delete_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}CPScope",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/CommunicationProfile*?*", "http://*apps.internal:8080/philips/rocc/CommunicationProfile*?*"],
            "actions": {"DELETE": "true", "PUT": "true"},
            "subject": {"type": "AuthenticatedUsers"},
            "condition": {"type": "Scope", "value": {"allOf": ["openid"]}}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Communication profile delete policy is already present: {response.json()}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating communication profile delete policy: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(
            f"Error while creating communication profile delete policy: {ex}")
    return False


def create_communication_profile_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}DeleteCommProfile",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/CommunicationProfile*?*", "http://*apps.internal:8080/philips/rocc/CommunicationProfile*?*"],
            "actions": {"POST": "true", "GET": "true"},
            "subject": {"type": "AuthenticatedUsers"}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Communication profile policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating communication profile policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating communication profile policy: {ex}")
    return False


def create_user_role_mapping_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}UR",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/UserRoleMapping*?*", "http://*apps.internal:8080/philips/rocc/UserRoleMapping*?*"],
            "actions": {"GET": "true"},
            "subject": {"type": "AuthenticatedUsers"}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"User role mapping policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating user role mapping policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating user role mapping policy: {ex}")
    return False


def create_get_security_question_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}SecurityQues",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/manage/SecurityQuestions*?*", "http://*apps.internal:8080/philips/rocc/manage/SecurityQuestions*?*"],
            "actions": {"GET": "true"},
            "subject": {"type": "AuthenticatedUsers"}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Security questions policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating security questions policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating security questions policy: {ex}")
    return False


def create_validate_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}VAL",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/Validate*?*", "http://*apps.internal:8080/philips/rocc/Validate*?*"],
            "actions": {"POST": "true", "GET": "false", "DELETE": "false", "PUT": "false"},
            "subject": {"type": "AuthenticatedUsers"}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Validate policy is already present: {json.dumps(response.json())}")
            return None
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating validate policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating validate policy: {ex}")
    return False


def create_password_policy(token, profile_values):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"managingOrganization": profile_values[VAULT_PARENT_ORG_ID],
            "expiryPeriodInDays": profile_values[VAULT_PASSWORD_EXPIRY_DAYS]}
    try:
        response = requests.post(f"{profile_values[VAULT_HSDP_IDM_URL]}/authorize/identity/PasswordPolicy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            return response.json()["id"]
        elif response.status_code == 409:
            LOG.warning(
                f"Password policy is already present: {response.json()}")
            return None
        elif response.status_code == 422:
            LOG.error(f"Policy RATE LIMIT exceeded: {response.json()}")
        else:
            LOG.error(
                f"Error while creating password policy: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating password policy: {ex}")
    return False


def create_group_policy_service(token, org_id, group_id, profile_configs):
    group_policy_id = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": f"{profile_configs[VAULT_PARENT_POLICY_NAME]}Group", "managingOrganization": org_id,
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/admin/*?*", "http://*apps.internal:8080/philips/rocc/admin/*?*",
                          "https://*/philips/rocc/devicemgmt/*?*",
                          "http://*apps.internal:8080/philips/rocc/devicemgmt/*?*",
                          "https://*/philips/rocc/redismgmt/*?*",
                          "http://*apps.internal:8080/philips/rocc/redismgmt/*?*", "https://*/philips/rocc/usermgmt*?*",
                          "http://*apps.internal:8080/philips/rocc/usermgmt*?*",
                          "https://*/philips/rocc/locationmgmt*?*",
                          "http://*apps.internal:8080/philips/rocc/locationmgmt*?*",
                          "https://*/philips/rocc/RolePermissionMapping*?*",
                          "http://*apps.internal:8080/philips/rocc/RolePermissionMapping*?*",
                          "https://*/philips/rocc/Permission*?*",
                          "http://*apps.internal:8080/philips/rocc/Permission*?*",
                          "https://*/philips/rocc/OrgPermission*?*",
                          "http://*apps.internal:8080/philips/rocc/OrgPermission*?*",
                          "https://*/philips/rocc/Role*?*", "http://*apps.internal:8080/philips/rocc/Role*?*",
                          "https://*/philips/rocc/OrgRole*?*", "https://*/philips/rocc/UserRoleMapping*?*",
                          "http://*apps.internal:8080/philips/rocc/OrgRole*?*",
                          "http://*apps.internal:8080/philips/rocc/UserRoleMapping*?*"],
            "actions": {"POST": "true", "GET": "true", "DELETE": "true", "PUT": "true"},
            "subject": {"type": "Group", "value": {"anyOf": [group_id]}}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Org group policy is created successfully")
            group_policy_id = response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Org group policy is already present: {json.dumps(response.json())}")
            error_reasn = f"Org group policy is already present: {json.dumps(response.json())}"
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
            error_reasn = f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}"
        else:
            LOG.error(
                f"Error while creating org group policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating org group policy: {ex}")
        error_reasn = f"Error while creating org group policy:{repr(ex.args)}"
    return group_policy_id, error_reasn


def get_policy_by_name(token, organization_id, policy_name, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.get(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy?organizationId={organization_id}&name={policy_name}",
                                headers=iam_headers)
        if response.status_code == 200:
            return response.json()
        else:
            LOG.error(f"Error while getting policy: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while getting policy: {ex}")
    return False


def create_bulk_delete_policy(token, organization_id, policy_name, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": policy_name,
            "managingOrganization": organization_id,
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": ["https://*/philips/rocc/mgmt/platform/*?*",
                          "http://*apps.internal:8080/philips/rocc/mgmt/platform/*?*"
                          "https://*/philips/rocc/usermgmt/platform/*?*",
                          "http://*apps.internal:8080/philips/rocc/usermgmt/platform/*?*"],
            "actions": {"DELETE": "true"},
            "subject": {"type": "AuthenticatedUsers"},
            "condition": {"type": "Scope", "value": {"allOf": ["openid"]}}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info("Successfully create the bulk delete policy")
            return response.json()["id"]
        else:
            LOG.error(f"Error while creating scope policy: {response.json()}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating scope policy: {ex}")
    return False


def create_service_tools_policy(token, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": "service-tools-policy",
            "managingOrganization": profile_configs[VAULT_PARENT_ORG_ID],
            "policySetId": profile_configs[VAULT_EVAL_APP_ID],
            "resources": [
                "https://*/philips/rocc/usermgmt/Users*?*",
                "https://*/philips/rocc/OrgRole*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Users/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/Permission*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Users*?*",
                "http://*apps.internal:8080/philips/rocc/UserRoleMapping/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/RolePermissionMapping*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/UserActions/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/admin/Organisation*?*",
                "https://*/philips/rocc/Role*?*",
                "https://*/philips/rocc/usermgmt/Users/bulk*?*",
                "https://*/philips/rocc/UserRoleMapping*?*",
                "https://*/philips/rocc/admin/Organisation*?*",
                "https://*/philips/rocc/usermgmt/UserActions/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/OrgRole*?*",
                "https://*/philips/rocc/redismgmt/Redis*?*",
                "https://*/philips/rocc/Permission*?*",
                "http://*apps.internal:8080/philips/rocc/redismgmt/Redis*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Group*?*",
                "http://*apps.internal:8080/philips/rocc/redismgmt/*?*",
                "https://*/philips/rocc/usermgmt/Group*?*",
                "https://*/philips/rocc/UserRoleMapping/bulk*?*",
                "http://*apps.internal:8080/philips/rocc/Role*?*",
                "https://*/philips/rocc/RolePermissionMapping*?*",
                "http://*apps.internal:8080/philips/rocc/UserRoleMapping*?*",
                "https://*/philips/rocc/redismgmt/*?*",
                "https://*/philips/rocc/usermgmt/UserActions*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/UserActions*?*",
                "https://*/philips/rocc/usermgmt/Users/*?*",
                "http://*apps.internal:8080/philips/rocc/usermgmt/Users*?*",
                "https://*/philips/rocc/RegionConfig*?*",
                "http://*apps.internal:8080/philips/rocc/RegionConfig*?*"
            ],
            "actions": {"POST": "true", "GET": "true", "DELETE": "true", "PUT": "true"},
            "subject": {"type": "AuthenticatedUsers"},
            "condition": {"type": "Scope", "value": {"allOf": ["openid"]}}}
    try:
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info(
                f"Successfully created policy for service tools. Id is {response.json()['id']}")
            return response.json()["id"]
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Service tool policy is already present: {json.dumps(response.json())}")
            return True
        elif response.status_code == 422:
            LOG.error(
                f"Policy RATE LIMIT exceeded: {json.dumps(response.json())}")
        else:
            LOG.error(
                f"Error while creating service tools policy: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating service tools policy: {ex}")
    return False


def delete_policy(token, policy_id, profile_configs):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.delete(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/access/Policy/{policy_id}",
                                   headers=iam_headers)
        if response.status_code == 204:
            LOG.info(f"Successfully deleted the policy: {policy_id}")
            return True
        else:
            LOG.error(f"Error while deleting policy: {response.json()}")
    except Exception as ex:
        LOG.error(f"Error while deleting policy: {ex}")
    return False


def delete_policies(token, policy_ids, profile_configs):
    deleted_ids = []
    failed_ids = []
    try:
        for policy_id in policy_ids:
            LOG.warn(f"Deleting policy with ID: {policy_id}")
            status = delete_policy(
                token=token, policy_id=policy_id, profile_configs=profile_configs)
            if status:
                deleted_ids.append(policy_id)
            else:
                failed_ids.append(policy_id)
    except Exception as ex:
        LOG.error(f"Failed to delete policies with error: {ex}")
    if len(deleted_ids) > 0:
        LOG.info(
            f"Following policy ids were deleted successfully: {deleted_ids}")
    if len(failed_ids) > 0:
        LOG.warn(f"Following policy ids were not deleted: {failed_ids}")


def delete_password_policy(token, profile_configs, policy_id):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    try:
        response = requests.delete(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/PasswordPolicy/{policy_id}",
                                   headers=iam_headers)
        if response.status_code == 204:
            LOG.info(f"Successfully deleted the password policy: {policy_id}")
            return True
        else:
            LOG.error(
                f"Error while deleting password policy: {response.json()}")
    except Exception as ex:
        LOG.error(f"Error while deleting password policy: {ex}")
    return False
