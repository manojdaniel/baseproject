// @ts-nocheck
import React, { useEffect, Suspense } from "react";
import ReactDOM from "react-dom";
import { HashRouter } from "react-router-dom";
import { Provider } from 'react-redux';
import "./assets/common/CommonDashboard.scss";
import "./assets/common/CommonDashboard.scss";
import Router from "./routes/Router";
// import Header from "components/Header";
import HeaderWrapper from "./wrapper/HeaderWrapper";
import BreadCrumb from "./components/BreadCrumb/BreadCrumb";
import MobileHeader from "./components/MobileHeader/MobileHeader";
//import CalendarComponent from "components/CalendarComponent";
import CalendarComponent from "./components/CalendarComponent/CalendarComponent";
import Footer from "components/Footer";
import store from "./redux";
import TimerComponent from "./components/TimerComponent";
import Favicon from "react-favicon";
import fav from "./assets/images/sabic-favicon.png"
import { history } from "./utility/history";
import { getLoggedInUserDetailsJSON } from "./DataModel/UserProfile";
import Loader from "components/Loader";

const App = (props: any) => {
  return (
    <Provider store={store}>
      <Favicon url={fav} />
      <HashRouter history={history} navigator={history}>
        <Suspense fallback={<div id="mainloader" style={{ width:"100%",height:"100vh",display:"flex",justifyContent:"center",alignItems:"center"}}><Loader/></div>}>
          <div id="container">
            <MobileHeader />
            <HeaderWrapper />
            <TimerComponent />
            <div id="content">
              <div className="content-inner">
                <div id="breadcrumb">
                  <BreadCrumb />
                  <CalendarComponent />
                </div>
                <Router />
              </div>
            </div>
            <Footer />
          </div>
        </Suspense>
      </HashRouter>
    </Provider>
  )
}

ReactDOM.render(<App />, document.getElementById("app"));
