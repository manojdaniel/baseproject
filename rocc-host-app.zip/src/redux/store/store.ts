/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import thunk from "redux-thunk"
import rootReducer from "../reducers/rootReducer"
import globalStore from "./globalStore"
import { persistStore, persistReducer } from "redux-persist"
import storageSession from "redux-persist/lib/storage/session"
import hardSet from "redux-persist/lib/stateReconciler/hardSet"
import { APP_NAME, STORAGE_KEY } from "../../constants/constants"
import { GLOBAL_FORCE_CLEAN_UP, GLOBAL_REFRESH_TOKEN, GLOBAL_UPDATE_CHAT_CLIENT_STATUS, GLOBAL_RIGHTSIDE_PANEL, GLOBAL_UPDATE_ACTIVE_LOCATION, GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_ROOMS, GLOBAL_UPDATE_CUSTOMER_METADATA, GLOBAL_SET_ACTIVE_TAB, GLOBAL_LEFTSIDE_PANEL, GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, } from "../actions/types"

const persistConfig = {
    key: `${APP_NAME}_${STORAGE_KEY}`,
    storage: storageSession,
    stateReconciler: hardSet,
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store = globalStore.CreateStore(
    APP_NAME,
    persistedReducer,
    [thunk], [
    GLOBAL_REFRESH_TOKEN,
    GLOBAL_FORCE_CLEAN_UP,
    GLOBAL_REFRESH_TOKEN,
    GLOBAL_RIGHTSIDE_PANEL,
    GLOBAL_LEFTSIDE_PANEL,
    GLOBAL_UPDATE_CHAT_CLIENT_STATUS,
    GLOBAL_UPDATE_ACTIVE_LOCATION,
        GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION,
    GLOBAL_UPDATE_ROOMS,
    GLOBAL_UPDATE_NOTIFICATION_MESSAGE,
    GLOBAL_UPDATE_CUSTOMER_METADATA,
    GLOBAL_SET_ACTIVE_TAB
])

export const persistor = persistStore(store)

export default store
