// @ts-nocheck
import React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import moment from "moment";
import "./MaintenanceHistory.scss";
interface Props {
	maintenanceHistoryData: any[];
}

const MaintenanceHistory = ({ maintenanceHistoryData }: Props) => {
	//=====================

	const mygetdate = (gedata: any) => {
		let utcdate = Date.UTC(
			new Date(gedata).getFullYear(),
			new Date(gedata).getMonth(),
			new Date(gedata).getDate()
		);
		return utcdate;
	};

	let MaintenanceHistoryGetData = [];
	maintenanceHistoryData.forEach((device, index) => {
		MaintenanceHistoryGetData[index] = { ...device };
	});

	let dataset = [];
	for (var i = 0; i < MaintenanceHistoryGetData.length; i++) {
		if (MaintenanceHistoryGetData[i].notificationType === "M1") {
			let localdata = {
				showInLegend: false,
				color: "#000",
				data: [
					[
						mygetdate(MaintenanceHistoryGetData[i].timestamp),
						MaintenanceHistoryGetData[i].notificationNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNTAiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE1MCIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iI2ZmY2QwMCIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					shared: true,
					split: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;line-height:25px;border:2px red solid;">
                            <tspan>&nbsp;NOTIFICATION TYPE : ${
															MaintenanceHistoryGetData[i].notificationType
														}</tspan><br/>
                            <tspan>CREATED ON : ${moment(
															new Date(MaintenanceHistoryGetData[i].timestamp)
														).format("DD MMM YY")}</tspan><br/>
                            <tspan>CAUSE TEXT : ${
															MaintenanceHistoryGetData[i].causeText
														}</tspan><br/>
                            <tspan>COMPANY CODE : ${
															MaintenanceHistoryGetData[i].companyCode
														}</tspan><br/>
                            <tspan>COMPLETION DATE : ${moment(
															new Date(
																MaintenanceHistoryGetData[i].completionDate
															)
														).format("DD-MM-YYYY")}</tspan><br/>
                            <tspan>COMPLETION TIME : ${
															MaintenanceHistoryGetData[i].completionTime
														}</tspan><br/>
                            <tspan>DESCRIPTION 1 : ${
															MaintenanceHistoryGetData[i].description1
														}</tspan><br/>
                            <tspan>DESCRIPTION 2 : ${
															MaintenanceHistoryGetData[i].description2
														}</tspan><br/>
                            <tspan>MAIN WORKCTR : ${
															MaintenanceHistoryGetData[i].mainWorKctr
														}</tspan><br/>
                            <tspan>NOTIFICATION : ${
															MaintenanceHistoryGetData[i].notification
														}</tspan><br/>
                            <tspan>OBJECT PART CODE : ${
															MaintenanceHistoryGetData[i].objectPartCode
														}</tspan><br/>
                            <tspan>OBJECT PART CODE TEXT : ${
															MaintenanceHistoryGetData[i].objectPartCodeText
														}</tspan><br/>
                            <tspan>ORDER : ${
															MaintenanceHistoryGetData[i].order
														}</tspan><br/>
                            <tspan>TEXT : ${
															MaintenanceHistoryGetData[i].text
														}</tspan><br/><br/>
                            <div style="height:30px"></div>
                        </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		} else if (MaintenanceHistoryGetData[i].notificationType === "M2") {
			let localdata = {
				showInLegend: false,
				color: "#000",
				data: [
					[
						mygetdate(MaintenanceHistoryGetData[i].timestamp),
						MaintenanceHistoryGetData[i].notificationNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDQiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0NCIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iI2YyOGUyYiIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;line-height:25px;border:2px red solid;">
                            <tspan>&nbsp;NOTIFICATION TYPE : ${
															MaintenanceHistoryGetData[i].notificationType
														}</tspan><br/>
                            <tspan>CREATED ON : ${moment(
															new Date(MaintenanceHistoryGetData[i].timestamp)
														).format("DD MMM YY")}</tspan><br/>
                            <tspan>CAUSE TEXT : ${
															MaintenanceHistoryGetData[i].causeText
														}</tspan><br/>
                            <tspan>COMPANY CODE : ${
															MaintenanceHistoryGetData[i].companyCode
														}</tspan><br/>
                            <tspan>COMPLETION DATE : ${moment(
															new Date(
																MaintenanceHistoryGetData[i].completionDate
															)
														).format("DD-MM-YYYY")}</tspan><br/>
                            <tspan>COMPLETION TIME : ${
															MaintenanceHistoryGetData[i].completionTime
														}</tspan><br/>
                            <tspan>DESCRIPTION 1 : ${
															MaintenanceHistoryGetData[i].description1
														}</tspan><br/>
                            <tspan>DESCRIPTION 2 : ${
															MaintenanceHistoryGetData[i].description2
														}</tspan><br/>
                            <tspan>MAIN WORKCTR : ${
															MaintenanceHistoryGetData[i].mainWorKctr
														}</tspan><br/>
                            <tspan>NOTIFICATION : ${
															MaintenanceHistoryGetData[i].notification
														}</tspan><br/>
                            <tspan>OBJECT PART CODE : ${
															MaintenanceHistoryGetData[i].objectPartCode
														}</tspan><br/>
                            <tspan>OBJECT PART CODE TEXT : ${
															MaintenanceHistoryGetData[i].objectPartCodeText
														}</tspan><br/>
                            <tspan>ORDER : ${
															MaintenanceHistoryGetData[i].order
														}</tspan><br/>
                            <tspan>TEXT : ${
															MaintenanceHistoryGetData[i].text
														}</tspan><br/><br/>
                            <div style="height:30px"></div>
                        </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		} else if (MaintenanceHistoryGetData[i].notificationType === "M3") {
			let localdata = {
				showInLegend: false,
				color: "#000",
				data: [
					[
						mygetdate(MaintenanceHistoryGetData[i].timestamp),
						MaintenanceHistoryGetData[i].notificationNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDYiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0NiIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iIzAwOWZkZiIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;line-height:25px;border:2px red solid;">
                            <tspan>&nbsp;NOTIFICATION TYPE : ${
															MaintenanceHistoryGetData[i].notificationType
														}</tspan><br/>
                            <tspan>CREATED ON : ${moment(
															new Date(MaintenanceHistoryGetData[i].timestamp)
														).format("DD MMM YY")}</tspan><br/>
                            <tspan>CAUSE TEXT : ${
															MaintenanceHistoryGetData[i].causeText
														}</tspan><br/>
                            <tspan>COMPANY CODE : ${
															MaintenanceHistoryGetData[i].companyCode
														}</tspan><br/>
                            <tspan>COMPLETION DATE : ${moment(
															new Date(
																MaintenanceHistoryGetData[i].completionDate
															)
														).format("DD-MM-YYYY")}</tspan><br/>
                            <tspan>COMPLETION TIME : ${
															MaintenanceHistoryGetData[i].completionTime
														}</tspan><br/>
                            <tspan>DESCRIPTION 1 : ${
															MaintenanceHistoryGetData[i].description1
														}</tspan><br/>
                            <tspan>DESCRIPTION 2 : ${
															MaintenanceHistoryGetData[i].description2
														}</tspan><br/>
                            <tspan>MAIN WORKCTR : ${
															MaintenanceHistoryGetData[i].mainWorKctr
														}</tspan><br/>
                            <tspan>NOTIFICATION : ${
															MaintenanceHistoryGetData[i].notification
														}</tspan><br/>
                            <tspan>OBJECT PART CODE : ${
															MaintenanceHistoryGetData[i].objectPartCode
														}</tspan><br/>
                            <tspan>OBJECT PART CODE TEXT : ${
															MaintenanceHistoryGetData[i].objectPartCodeText
														}</tspan><br/>
                            <tspan>ORDER : ${
															MaintenanceHistoryGetData[i].order
														}</tspan><br/>
                            <tspan>TEXT : ${
															MaintenanceHistoryGetData[i].text
														}</tspan><br/><br/>
                            <div style="height:30px"></div>
                        </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		} else if (MaintenanceHistoryGetData[i].notificationType === "M6") {
			let localdata = {
				showInLegend: false,
				color: "#000",
				data: [
					[
						mygetdate(MaintenanceHistoryGetData[i].timestamp),
						MaintenanceHistoryGetData[i].notificationNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDkiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0OSIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iIzU4NTk1YiIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<text class="ttt" style="color:#fff;font-size:0.75rem;line-height:25px;border:2px red solid;">
                            <rect>&nbsp;NOTIFICATION TYPE : ${
															MaintenanceHistoryGetData[i].notificationType
														}</rect><br/>
                            <rect>CREATED ON : ${moment(
															new Date(MaintenanceHistoryGetData[i].timestamp)
														).format("DD MMM YY")}</rect><br/>
                            <rect>CAUSE TEXT : ${
															MaintenanceHistoryGetData[i].causeText
														}</rect><br/>
                            <rect>COMPANY CODE : ${
															MaintenanceHistoryGetData[i].companyCode
														}</rect><br/>
                            <rect>COMPLETION DATE : ${moment(
															new Date(
																MaintenanceHistoryGetData[i].completionDate
															)
														).format("DD-MM-YYYY")}</rect><br/>
                            <rect>COMPLETION TIME : ${
															MaintenanceHistoryGetData[i].completionTime
														}</rect><br/>
                            <rect>DESCRIPTION 1 : ${
															MaintenanceHistoryGetData[i].description1
														}</rect><br/>
                            <rect>DESCRIPTION 2 : ${
															MaintenanceHistoryGetData[i].description2
														}</rect><br/>
                            <rect>MAIN WORKCTR : ${
															MaintenanceHistoryGetData[i].mainWorKctr
														}</rect><br/>
                            <rect>NOTIFICATION : ${
															MaintenanceHistoryGetData[i].notification
														}</rect><br/>
                            <rect>OBJECT PART CODE : ${
															MaintenanceHistoryGetData[i].objectPartCode
														}</rect><br/>
                            <rect>OBJECT PART CODE TEXT : ${
															MaintenanceHistoryGetData[i].objectPartCodeText
														}</rect><br/>
                            <rect>ORDER : ${
															MaintenanceHistoryGetData[i].order
														}</rect><br/>
                            <rect>TEXT : ${
															MaintenanceHistoryGetData[i].text
														}</rect><br/><br/>
                            <rect style="height:30px"></rect>
                        </text>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		}
	}

	//=====================

	const getHighcharts = () => ({
		chart: {
			type: "scatter",
			zoomType: "xy",
			height: 230,
		},
		title: {
			text: null,
		},
		xAxis: {
			visible: true,
			tickInterval: 24 * 3600 * 1000, // the number of milliseconds in a day
			allowDecimals: false,
			type: "datetime",
			labels: {
				formatter() {
					return Highcharts.dateFormat("%d-%b-%y", this.value);
				},
				// style: {
                //     fontSize: '0.8rem',
                // }
			},
		},
		yAxis: {
			visible: false,
			min: 0,
			max: 4,
		},

		navigation: {
			buttonOptions: {
				enabled: false,
			},
		},
		plotOptions: {
			scatter: {
				marker: {
					radius: 10,
					symbol: "oval",
					states: {
						hover: {
							enabled: false,
						},
					},
				},
				states: {
					hover: {
						marker: {
							enabled: false,
						},
					},
				},
			},
		},
		tooltip: {
			enabled: true,
		},

		series: dataset,
	});

	return (
			<div id="asset-timeline">
				<div id="asset-timeline-left">
					<div id="asset-timeline-plot">
						<div className="asset-timeline-filter">
							<div className="title">MAINTENANCE HISTORY</div>
						</div>
						<div className="asset-timeline-plot-graph">
							<HighchartsReact
								highcharts={Highcharts}
								options={getHighcharts()}
							/>
						</div>
					</div>
				</div>
				<div id="asset-timeline-right">
					<div id="asset-timeline-names">
						<div className="right-title">NOTIFICATION TYPE</div>
						<div className="asset-timeline-list maintainance-notificationtype">
							<div>
								<span style={{ background: "#FFCD00" }}></span>
								<span>M1</span>
							</div>
							<div>
								<span style={{ background: "#F28E2B" }}></span>
								<span>M2</span>
							</div>
							<div>
								<span style={{ background: "#009FDF" }}></span>
								<span>M3</span>
							</div>
							<div>
								<span style={{ background: "#58595B" }}></span>
								<span>M4</span>
							</div>
						</div>
					</div>
				</div>
			</div>
	);
};

export default MaintenanceHistory;
