import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import React from "react";
import ReportTable from "./ReportTable";

// Mock the Table component
jest.mock("antd", () => {
	const originalAntd = jest.requireActual("antd");
	return {
		...originalAntd,
		Table: jest.fn().mockImplementation(() => null),
	};
});
jest.mock("antd/es/typography/Link", () => {
	return ({ children }: { children: React.ReactNode }) => {
		return <a href="#">{children}</a>;
	};
});

describe("ReportTable", () => {
	const data = [
		{
			AlertID: 1,
			Affiliate: "Affiliate 1",
			Plant: "Plant 1",
			TimeStamp: "2023-04-26T14:30:00.000Z",
			AssetID: 1,
			AssetDescription: "Asset Description 1",
			AnomolyType: "Anomaly Type 1",
			AssetName: "Asset Name 1",
			KeyIdentifierSensor1: "Key Identifier Sensor 1",
			KeyIdentifierSensor2: "Key Identifier Sensor 2",
			KeyIdentifierSensor3: "Key Identifier Sensor 3",
			KeyIdentifierSensor4: "Key Identifier Sensor 4",
			KeyIdentifierSensor5: "Key Identifier Sensor 5",
			KeyIdentifierSensor6: "Key Identifier Sensor 6",
			CurrentStage: "Current Stage 1",
			AssignedToDepart: "Assigned to Department 1",
			AssignedToUser: "Assigned to User 1",
			Status: "Status 1",
			AlertClass: "Alert Class 1",
			LongLeadAction: "Long Lead Action 1",
			View: "View 1",
		},
	];

	it("should render the component without errors", () => {
		render(<ReportTable data={data} />);
	});
});
