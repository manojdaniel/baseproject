/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import cx from "classnames"
import React, { ReactFragment } from "react"
import styles from "./TabLayout.scss"

interface ITabLayout {
    className?: string
    tabBodyContent?: ReactFragment
    tabActionContent?: ReactFragment
}

const TabLayout = (props: ITabLayout) => {

    const {
        className,
        tabBodyContent,
        tabActionContent,
    } = props
    
    return (
        <div className={cx(styles.tabLayout, className)} id={"tabLayout"}>
            {(tabBodyContent !== undefined) && tabBodyContent}
            {(tabActionContent !== undefined) && tabActionContent}
        </div>
    )
}

export default TabLayout
