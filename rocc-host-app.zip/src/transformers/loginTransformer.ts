/*
 * Created on Wed May 19 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserPermissions } from "@rocc/rocc-client-services"
import { DEFAULT_EDGE_LOCATION, DEFAULT_SIGNALING_REGION, DEFAULT_PRESENCE_UPDATE_TIMEOUT } from "../constants/constants"
import { computePermissionList, initalizeUrls } from "../redux/services/appServices"

export const loginTransformer = (response: any) => {
    /* 
    - Extract session
    - Extract configs
    - Extract rbacPermissions
    - Extract featureFlagFeatures
    - Extract defaultFeatureFlags
    */
    const { session, allOrgList } = extractSessionData(response.data.loginResponse)
    const { configs, urls } = extractProdConfigs(response.data)
    const userPermissions: string[] = response.data.userPermissions
    const computedUserPermissions: IUserPermissions = computePermissionList(userPermissions)
    const featureFlagConfig: any = response.data.featureFlagConfig
    const defaultFeatureFlags: any = response.data.defaultFeatureFlags
    const isProxy = response.data.isProxy

    return { session, configs, urls, computedUserPermissions, featureFlagConfig, defaultFeatureFlags, allOrgList, isProxy }
}

const extractSessionData = (data: any) => {
    const session = {
        accessToken: data.accessToken,
        accessTokenExpiryTime: data.expiryTime,
        sessionId: data.sessionId,
        uuid: data.userId,
        orgInfraUuid: data.orgId,
        userName: data.userName,
    }
    return { session, allOrgList: data.allOrgList }
}

const extractProdConfigs = (data: any) => {
    const urls = {
        IAM_SERVICES_URL: data.configs.LOGIN_ACCESS_URL,
        COMMUNICATION_SERVICES_URL: data.configs.TWILLIO_SERVER_URL,
        CONSOLE_SERVICES_URL: data.configs.CONSOLE_SERVICES_URL,
        PROXY_URL: data.configs.LOGIN_ACCESS_URL,
        MANAGEMENT_SERVICE_URL: data.configs.ADMIN_SERVICE_URL,
        GRAPHQL_API_HSDP_URI: data.configs.GRAPHQL_API_HSDP_URI,
        GRAPHQL_API_HSDP_WS_URI: data.configs.GRAPHQL_API_HSDP_WS_URI,
        RBAC_SERVICE_URL: data.configs.RBAC_SERVICE_URL,
    }
    const configs = {
        ADMIN_MANUAL_PATH: data.configs.ADMIN_MANUAL_PATH,
        AV_AUTO_DISCONNECT_TIMEOUT: data.configs.AV_AUTO_DISCONNECT_TIMEOUT,
        DEMO_CONSOLE_VIDEOS: data.configs.DEMO_CONSOLE_VIDEOS,
        DEMO_ENV: data.configs.DEMO_ENV,
        QUERY_LIMIT_ADMIN_USERS: data.configs.QUERY_LIMIT_ADMIN_USERS,
        ROCC_HELPLINE: data.configs.ROCC_HELPLINE,
        SESSION_IDLE_TIMEOUT: data.configs.SESSION_IDLE_TIMEOUT,
        ROCC_DEV: data.configs.ROCC_DEV,
        PING_URL: data.configs.PING_URL,
        LOG_LEVEL: data.configs.LOG_LEVEL,
        INSIGHTS_KEY: data.configs.INSIGHTS_KEY,
        CUSTOMER_ANALYTICS_LOG_CONSENT: data.configs.CUSTOMER_ANALYTICS_LOG_CONSENT,
        USER_MANUAL_PATH: data.configs.USER_MANUAL_PATH,
        QUERY_LIMIT_CONTACTS: data.configs.QUERY_LIMIT_CONTACTS,
        MAX_VIDEO_BITRATE: data.configs.MAX_VIDEO_BITRATE,
        MAX_SUBSCRIPTION_BITRATE: data.configs.MAX_SUBSCRIPTION_BITRATE,
        CONSOLE_DISCONNECT_DELAY: data.configs.CONSOLE_DISCONNECT_DELAY,
        DANGLING_CONSOLE_CONNECTIONS_CLEANUP_INTERVAL: data.configs.DANGLING_CONSOLE_CONNECTIONS_CLEANUP_INTERVAL,
        MAX_SUPPORTED_DEVICE_USB_CAMERAS: data.configs.MAX_SUPPORTED_DEVICE_USB_CAMERAS,
        DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING: data.configs.DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING,
        MAX_NUM_OF_CONSOLE_SESSION: data.configs.MAX_NUM_OF_CONSOLE_SESSION,
        MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE: data.configs.MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE,
        MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE: data.configs.MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE,
        COUNTRY_ISO_CODE: data.configs.COUNTRY_ISO_CODE,
        REGION: data.configs.REGION,
        REGION_UKI: data.configs.REGION_UKI,
        IS_PROXY: data.isProxy,
        CRYPT_ENABLED: data.configs.CRYPT_ENABLED,
        PRESIGNED_URL_EXPIRY_MINUTES: data.configs.PRESIGNED_URL_EXPIRY_MINUTES,
        EDGE_LOCATION: DEFAULT_EDGE_LOCATION,
        SIGNALING_REGION: DEFAULT_SIGNALING_REGION,
        CUSTOMER_PRIVACY_POLICY_URL: data.configs.CUSTOMER_PRIVACY_POLICY_URL,
        PRESENCE_UPDATE_TIMEOUT: data.configs.PRESENCE_UPDATE_TIMEOUT || DEFAULT_PRESENCE_UPDATE_TIMEOUT,
        DEVICE_RECOVERY_TIME_IN_MINS: data.configs.DEVICE_RECOVERY_TIME_IN_MINS
    }
    return { configs, urls: initalizeUrls(urls) }
}
