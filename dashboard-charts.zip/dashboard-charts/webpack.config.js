const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

const deps = require("./package.json").dependencies;
module.exports = {

  resolve: {
    extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
  },

  module: {
    rules: [
      {
        test: /\.m?js/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false,
        },
      },
      {
        test: /\.(css|s[ac]ss)$/i,
        use: ["style-loader", "css-loader", "postcss-loader", "sass-loader"],
      },
      {
        test: /\.(png|jp(e*)g|svg|gif)$/,
        exclude: /(node_modules)/,
        use: ["url-loader"],
      },
      {
        test: /\.(ts|tsx|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
        },
      },
    ],
  },

  plugins: [
    new ModuleFederationPlugin({
      name: "charts",
      filename: "remoteEntry.js",
      remotes: {},
      exposes: {
        "./GraphicalOverview": "./src/components/Asset/AssetModel/GraphicalOverview.tsx",
        "./ReliablityHeatMap": "./src/components/PmtComponent/ReliablityHeatMap/ReliablityHeatMap.tsx",
        "./AlertStatusAsset": "./src/components/AlertDashboard/AlertStatusAsset",
        "./PerformanceTrend": "./src/components/AlertDashboard/PerformanceTrend",
        "./StackedBarAsset": "./src/components/AlertDashboard/StackedBarAsset",
        "./StackedBarDepartment": "./src/components/AlertDashboard/StackedBarDepartment",
        "./AssetHealthIndex": "./src/components/Asset/AssetTimeLine/AssetHealthIndex.tsx",
        "./MaintenanceHistory": "./src/components/Asset/AssetTimeLine/MaintenanceHistory.tsx",
        "./HanaIncident": "./src/components/Asset/AssetTimeLine/HanaIncident.tsx",
        "./SensorChart": "./src/components/PlotScreen/SensorChart",
        "./DeviationChart": "./src/components/PlotScreen/DeviationChart",
        "./PlantTimelineChart": "./src/components/PlantTimeline/PlantTimelineChart.tsx",
        "./AlertStatusByAsset": "./src/components/PerformanceDashboad/AlertStatusAsset/AlertStatusByAsset.tsx",
        "./StackBarChart": "./src/components/PerformanceDashboad/StackedBar/StackBarChart.tsx",
        "./AlertStatusDepartment": "./src/components/PerformanceDashboad/AlertStatusByDepartment/AlertStatusDepartment.tsx",
        "./MonthWiseChart": "./src/components/ModelPerformance/MonthWiseBarchart/MonthWiseChart.tsx",
        "./AdminAssetModel": "./src/components/Asset/AdminAssetModel",
        "./StockGraphicalOverview": "./src/components/Asset/SpareParts/StockGraphicalOverview.tsx",
        "./PerformanceCurveChart": "./src/components/PerformanceCurve/PerformanceCurveChart.tsx",
        "./PredictionCurve": "./src/components/Asset/PredictionCase/PredictionCase.tsx",
      },

      shared: {
        ...deps,
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
      },
    }),
    new HtmlWebPackPlugin({
      template: "./src/index.html",
    }),
  ],
};
