"""
 Created on Tue Dec 1 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import base64
import json
import pytz
import os
import uuid
import requests
from datetime import datetime

from src.constants.constants import ACCEPT, API_SIGNATURE_SECRET_KEY, API_SIGNATURE_SHARED_KEY, API_VERSION, APPLICATION_JSON, CONTENT_TYPE, HSDP_API_SIGNATURE, LOG_INGESTER_URL, SIGNED_DATE, UTF_8
from src.constants.config_keys import VAULT_LOG_PRODUCT_KEY
from src.utility.api_signature import LogApiSignature


def make_log_ingester(message, severity, component, transaction_id=None):
    try:
        shared_key = os.environ.get(API_SIGNATURE_SHARED_KEY, None)
        secret_key = os.environ.get(API_SIGNATURE_SECRET_KEY, None)
        log_ingester_url = os.environ.get(LOG_INGESTER_URL, None)
        if shared_key and secret_key and log_ingester_url:
            log_api_signature = LogApiSignature(shared_key=shared_key, secret_key=secret_key)
            signed_date = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            hsdp_api_signature = log_api_signature.generate_signature(signed_date)
            headers = {API_VERSION: "1", CONTENT_TYPE: APPLICATION_JSON, HSDP_API_SIGNATURE: hsdp_api_signature, SIGNED_DATE: signed_date, ACCEPT: APPLICATION_JSON}
            log_object = prepare_log_object(message, severity, component, transaction_id)
            requests.post(url=log_ingester_url,
                          data=json.dumps(log_object),
                          headers=headers)
    except Exception as ex:
        print(f"Kibana logging failed with error: {ex}")


def prepare_log_object(message, severity, component, transaction_id=None):
    try:
        app_name = "ROCCServiceToolBackendService"
        if os.environ.get("ENV_TYPE", "dev") == "cloud":
            vcap_application = json.loads(os.getenv("VCAP_APPLICATION", {}))
            if vcap_application:
                app_name = vcap_application.get("name", app_name)

        return {
            "resourceType": "bundle",
            "type": "transaction",
            "total": 1,
            "productKey": os.environ[VAULT_LOG_PRODUCT_KEY],
            "entry": [{
                "resource": {
                    "resourceType": "LogEvent",
                    "id": str(uuid.uuid4()),
                    "applicationName": app_name,
                    "applicationInstance": "ROCCServiceToolBackendApp",
                    "eventId": str(uuid.uuid4()),
                    "serviceName": "ROCCServiceToolBackendService",
                    "component": component,
                    "applicationVersion": "1.0.0",
                    "category": "TRACELOG",
                    "transactionId": transaction_id if transaction_id else str(uuid.uuid4()),
                    "serverName": "ROCCServiceToolBackendApp Server",
                    "severity": severity,
                    "logTime": str(datetime.now().replace(tzinfo=pytz.utc).strftime("%Y-%m-%dT%H:%M:%S%z")),
                    "logData": {
                        "message": base64.b64encode(message.encode(UTF_8)).decode()
                    }
                }
            }]
        }

    except Exception as ex:
        print(f"Kibana logging failed while preparing log message object with error: {ex}")
