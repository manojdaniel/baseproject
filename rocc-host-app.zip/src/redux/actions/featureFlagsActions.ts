/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { UPDATE_FEATURE_FLAGS, UPDATE_FEATURE_FLAG_CONFIGS, UPDATE_DEFAULT_FLAGS } from "./types"

export const setFeatureFlagConfig = (featureFlagConfig: any) => {
    return { type: UPDATE_FEATURE_FLAG_CONFIGS, featureFlagConfig: { featureFlagConfig } }
}

export const setDefaultFeatureFlags = (defaultFlags: any) => {
    return { type: UPDATE_DEFAULT_FLAGS, defaultFeatureFlags: defaultFlags }
}

export const updateFeatureFlags = (featureFlags: any) => {
    return { type: UPDATE_FEATURE_FLAGS, featureFlags: { featureFlags } }
}
