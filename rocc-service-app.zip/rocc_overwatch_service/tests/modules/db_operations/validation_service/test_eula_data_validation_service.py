import unittest
from src.modules.db_operations.validation_service.eula_data_validation_service import verify_if_eula_data_exists


class EulaDataValidationTest(unittest.TestCase):
    def test_verify_if_eula_no_data_exists(self):
        data = {}
        metasites = verify_if_eula_data_exists(
            {}, "document_name", data)
        self.assertIsNone(metasites)
