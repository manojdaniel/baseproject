/*
 * Created on Thu Sept 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import CallParticipants from "./CallParticipants"
import { DEFAULT_CONTACT_INFO, ROCC_FEATURES } from "@rocc/rocc-client-services"
import * as helpers from "../../common/helpers/helpers"

const testState = {
    externalReducer: {
        currentUser: { ...DEFAULT_CONTACT_INFO, uuid: "uuid", accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US", loggedInLocation: "" },
    },
    callReducer: {
        callDetails: {
            connectedCallDetails: {
                participants: [{
                    id: "id", uuid: "uuid", name: "name", clinicalRole: "device", description: "siteName", phoneNumber: ["phoneNumber"],
                }, {
                    id: "id1", uuid: "uuid1", name: "name1", clinicalRole: "device1", description: "siteName", phoneNumber: ["phoneNumber"], callStatus: "RINGING",
                }]
            }
        }
    }
}

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn().mockReturnValue(jest.fn)
}))

jest.mock("@rocc/rocc-global-components", () => ({
    ...jest.requireActual("@rocc/rocc-global-components"),
    getIntlProvider: jest.fn().mockReturnValue({
        intl: {
            formatMessage: jest.fn()
        }
    })

}))

jest.mock("../../redux/actions/callActions", () => ({ storeCallDetails: jest.fn() }))

jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "http://localhost" }
    })
}))

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockImplementation(() => ({
        externalReducer: {
            featureFlags: {
                [ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME]: true,
            }
        }

    }))
}))

jest.mock("../../redux/store/globalStore", () => ({
    ...jest.requireActual("../../redux/store/globalStore"),
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            userReducer: {
                contacts: [
                    { id: "id", uuid: "uuid", name: "name", clinicalRole: "device", description: "siteName", phoneNumber: ["phoneNumber"], },
                    { id: "id2", uuid: "uuid2", name: "name2", clinicalRole: "device", description: "siteName2", phoneNumber: ["phoneNumber"], }
                ],
                currentUser: {
                    loggedInLocation: ""
                }
            }
        }
    }),
    SubscribeToPartnerState: jest.fn(),
    CreateStore: jest.fn()
}))

jest.mock("../../services/callServices", () => ({
    addParticipantService: jest.fn(),
    checkIfParticipantAdded: false,
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const cardProps = (contactUuid: string) => (
    <div id={contactUuid} />
)

const activeCall = {
    participants: [{
        id: "id", uuid: "uuid", name: "name", clinicalRole: "device", description: "siteName", phoneNumber: ["phoneNumber"],
    }, {
        id: "id1", uuid: "uuid1", name: "name1", clinicalRole: "device1", description: "siteName", phoneNumber: ["phoneNumber"], callStatus: "RINGING",
    }]
}

describe("CallParticpant tests", () => {
    const props: any = {
        participantCards: {
            components: [cardProps, () => ""]
        },
        contactCards: {
            components: [cardProps]
        },
        activeCall,
    }
    beforeEach(() => {
        useSelectorMock(testState)
        jest.spyOn(helpers, "getSiteName").mockImplementation(() => ("location1"))

    })

    it("should display call particpants", () => {
        withHooks(() => {
            const wrapper = shallow(<CallParticipants {...props} />)
            expect(wrapper.find("AccordionCallList")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
