import React, { useRef, useState, useEffect } from "react";
import "./AlertMapPop.scss";
import tooltipActive from "../../assets/images/tooltip-active.svg";
import tooltipHeart from "../../assets/images/tooltip-heart.svg";
import tooltipPmcompliance from "../../assets/images/tooltip-pmcompliance.svg";
import tooltipSearch from "../../assets/images/tooltip-search.svg";
import tooltipSparesAvailability from "../../assets/images/tooltip-spares-availability.svg";
import tooltipTime from "../../assets/images/tooltip-time.svg";
import tooltipUparrow from "../../assets/images/tooltip-uparrow.svg";

interface Props {
	alertmapPopData: any;
}

const AlertMapPop = ({ alertmapPopData }: Props) => {
	return (
		<div className="map-tooltip">
			<h3>OVERALL {alertmapPopData.name.toUpperCase()}</h3>
			<div className="map-content">
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipHeart} />
					</div>
					<div className="map-tooltip-content">
						<span>
							{alertmapPopData.healthIndex}%
							<i>
								<img src={tooltipUparrow} />
							</i>
						</span>
						<span>HEALTH INDEX</span>
					</div>
				</div>
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipActive} />
					</div>
					<div className="map-tooltip-content">
						<span>{alertmapPopData.active}</span>
						<span>ACTIVE</span>
					</div>
				</div>
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipTime} />
					</div>
					<div className="map-tooltip-content">
						<span>
							{alertmapPopData.overDue}
							<i>
								<img src={tooltipUparrow} />
							</i>
						</span>
						<span>OVERDUE INVESTIGATION</span>
					</div>
				</div>
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipPmcompliance} />
					</div>
					<div className="map-tooltip-content">
						<span>{alertmapPopData.pmCompliance}</span>
						<span>PM COMPLIANCE</span>
					</div>
				</div>
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipSearch} />
					</div>
					<div className="map-tooltip-content">
						<span>{alertmapPopData.underInvestigation}</span>
						<span>UNDER INVESTIGATION</span>
					</div>
				</div>
				<div className="map-tooltip-row">
					<div className="map-tooltip-img">
						<img src={tooltipSparesAvailability} />
					</div>
					<div className="map-tooltip-content">
						<span>{alertmapPopData.sparesAvailability}</span>
						<span>SPARES AVAILABILITY</span>
					</div>
				</div>
			</div>
		</div>
	);
};

export default AlertMapPop;
