/*
 * Created on Wed Sep 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus, IAVCallDetails } from "@rocc/rocc-client-services"
import { getIntlProvider, NoRecordsContent } from "@rocc/rocc-global-components"
import cx from "classnames"
import includes from "lodash.includes"
import some from "lodash.some"
import uniqBy from "lodash.uniqby"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Message } from "semantic-ui-react"
import { filterCallStatus, getCallStatusFromICallStatus } from "../../../../common/helpers/callUtility"
import { getActiveStyles, getTranslatedCallType, getAppReducerFromGlobalStore } from "../../../../common/helpers/helpers"
import AudioVideoCalling from "../../../../common/modules/av/AudioVideoCalling"
import { CONTEXT_ID, INIT_RIGHTSIDE_PANEL } from "../../../../constants/constants"
import { holdCall, resumeCall, setCallMessage, setOutgoingCallDetails, setVideoCallStatus } from "../../../../redux/actions/callActions"
import { GLOBAL_RIGHTSIDE_PANEL } from "../../../../redux/actions/types"
import { IStore } from "../../../../redux/interfaces/types"
import { DEFAULT_CALL_MESSAGE, DEFAULT_OUTGOING_CALL_DEATILS } from "../../../../redux/reducers/callReducer"
import { dispatchToParentStore } from "../../../../redux/store/externalAppStates"
import en from "../../../../resources/translations/en-US"
import { EActiveCallPanel, ESidePanelTabs, IConnectedCallProps } from "../../../../types/types"
import ConnectingCall from "../../../connecting-call/ConnectingCall"
import IntermediateCallWindow from "../../../intermediate-call-window/IntermediateCallWindow"
import OutgoingCall from "../../../outgoing-call/OutgoingCall"
import WebToPhoneCall from "../../../web-to-phone-call/WebToPhoneCall"
import styles from "./ActiveCallTab.scss"

interface IActiveCallTab {
    activeItem: ESidePanelTabs
    connectedCallProps?: IConnectedCallProps
}

const { CALLING, CONNECTED, CONNECTING, DISCONNECTED, FAILED, CALLDECLINED, NOT_ANSWERED, CALLREJECT, IDLE, PAUSED, RESUMED } = ECallStatus
const { DEFAULT, ONGOING_WEB_TO_PHONE_CALL, ONGOING_WEB_TO_WEB_CALL, OUTGOING_CALL, CALL_MESSAGE, CONNECTING_CALL } = EActiveCallPanel

const ActiveCallTab = (props: IActiveCallTab) => {

    const { activeItem } = props
    const { intl } = getIntlProvider()

    const {
        videoCallStatus, phoneCallStatus, connectedCallDetails, onHoldCallDetails, incomingCall, outgoingCall, callMessage,
    } = useSelector((state: IStore) => ({
        videoCallStatus: state.callReducer.videoCallStatus,
        phoneCallStatus: state.callReducer.phoneCallStatus,
        connectedCallDetails: state.callReducer.callDetails.connectedCallDetails,
        onHoldCallDetails: state.callReducer.callDetails.onHoldCallDetails,
        incomingCall: state.callReducer.callDetails.incomingCall,
        outgoingCall: state.callReducer.callDetails.outgoingCall,
        callMessage: state.callReducer.callMessage,
    }))

    const focusedCallAndConsole = getAppReducerFromGlobalStore().focusedCallAndConsole
    const [activeCallPanel, setActiveCallPanel] = useState(EActiveCallPanel.DEFAULT)
    const [activeCalls, setActiveCalls] = useState([] as IAVCallDetails[])

    const dispatch = useDispatch()

    useEffect(() => {
        const avCalls = uniqBy([connectedCallDetails, ...onHoldCallDetails], CONTEXT_ID).filter(
            (callDetails: IAVCallDetails) => (
                [CONNECTED, PAUSED, RESUMED].includes(
                    videoCallStatus.find(call => call.contextId === callDetails.contextId)?.callStatus ?? IDLE
                ) && callDetails.participants
            )
        )
        setActiveCalls([...avCalls])

    }, [connectedCallDetails, onHoldCallDetails])

    useEffect(() => {
        if (focusedCallAndConsole?.callContextId === "") {
            return
        }
        if (!onHoldCallDetails.length) {
            return
        }
        if (connectedCallDetails.contextId !== focusedCallAndConsole?.callContextId) {
            dispatch(holdCall())
        }
        if (onHoldCallDetails.some((callDetails: IAVCallDetails) => callDetails.contextId === focusedCallAndConsole?.callContextId)) {
            dispatch(resumeCall(focusedCallAndConsole?.callContextId ?? ""))
        }

    }, [focusedCallAndConsole])

    const handleActivePanelForAVCall = () => {
        const callStatuses = getCallStatusFromICallStatus(videoCallStatus)
        const { twilioToken } = connectedCallDetails
        let activePanel = DEFAULT
        if (callStatuses.includes(CONNECTED) && twilioToken) {
            activePanel = ONGOING_WEB_TO_WEB_CALL
        } else if (callStatuses.includes(CALLING)) {
            activePanel = OUTGOING_CALL
        } else if (callStatuses.includes(CONNECTING)) {
            activePanel = CONNECTING_CALL
        } else if ((some([CALLDECLINED, NOT_ANSWERED, DISCONNECTED, FAILED], (el: any) =>
            includes(callStatuses, el)))) {
            activePanel = CALL_MESSAGE
        }
        setActiveCallPanel(activePanel)
    }

    const closeCallMessage = () => {
        const updatedCallStatus = videoCallStatus.filter(
            (callValue) => ![CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED]
                .includes(callValue.callStatus),
        )
        dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
        dispatch(setVideoCallStatus([...updatedCallStatus]))
        dispatch(setCallMessage(DEFAULT_CALL_MESSAGE))
        const onHoldCall = onHoldCallDetails[0]?.contextId
        if (onHoldCall) {
            dispatch(resumeCall(onHoldCallDetails[0].contextId))
        }
        else {
            dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { ...INIT_RIGHTSIDE_PANEL } })
        }

    }

    const showCallMessageFooter = () => {
        return <Button
            onClick={() => closeCallMessage()}
            content={intl.formatMessage({ id: "content.close.btn", defaultMessage: en["content.close.btn"] })}
            color="grey"
            className={styles.closePanelButton}
        />
    }

    const fetchConnectingCallDetails = () => {
        const callStatuses = filterCallStatus(videoCallStatus, CONNECTING, true)
        for (const callStatus of callStatuses) {
            if (outgoingCall.contextId === callStatus.contextId) {
                return outgoingCall.participant
            } else if (incomingCall.contextId === callStatus.contextId) {
                return incomingCall.participant
            }
        }
        return { ...DEFAULT_CONTACT_INFO }
    }

    const displayCallMessage = () => (
        <IntermediateCallWindow
            displayName={callMessage.contact.name}
            metaData={<Message className={styles.callPanelMessages}>
                <Message.Header>
                    {getTranslatedCallType(callMessage.messageType)}
                </Message.Header>
            </Message>}
            subMessage={
                <Message className={styles.callPanelMessages}>
                    <Message.Content>{callMessage.message}</Message.Content>
                </Message>
            }
            callWindowFullscreen={false}
            callMessage={""}
            description={""}
            additionalComponent={showCallMessageFooter}
        />
    )

    useEffect(() => {
        if ([CALLING, CONNECTED].includes(phoneCallStatus)) {
            setActiveCallPanel(ONGOING_WEB_TO_PHONE_CALL)
        } else {
            handleActivePanelForAVCall()
        }
    }, [videoCallStatus, phoneCallStatus])

    const statusDisplayPanel = () => {
        switch (activeCallPanel) {
            case CALL_MESSAGE:
                return displayCallMessage()

            case CONNECTING_CALL: {
                const contact = fetchConnectingCallDetails()
                return <ConnectingCall
                    participant={contact}
                    callWindowFullscreen={false}
                    callMessage={intl.formatMessage({ id: "content.outgoingCall.connecting", defaultMessage: en["content.outgoingCall.connecting"] })}
                />
            }

            case OUTGOING_CALL:
                return <OutgoingCall callWindowFullscreen={false} />

            case ONGOING_WEB_TO_PHONE_CALL:
                return <WebToPhoneCall />

            default:
                return <div className={styles.noRecords} >
                    <NoRecordsContent
                        content={intl.formatMessage({ id: "content.tabMessage.noActiveCallsMessage", defaultMessage: en["content.tabMessage.noActiveCallsMessage"] })}
                    />
                </div>
        }
    }

    const activeWebToWebPanel = () => {
        return (
            <div>
                {activeCalls.map(callDetails => <AudioVideoCalling key={callDetails.contextId} activeCall={callDetails} {...props} />)}
            </div>
        )
    }

    const renderPanel = () => {
        return <>
            {activeWebToWebPanel()}
            {statusDisplayPanel()}
        </>
    }

    const activeStyle = getActiveStyles(activeItem, ESidePanelTabs.Active)

    return <div className={cx(styles.activeCallTab, activeStyle)} id={"activeCallTab"}>
        {renderPanel()}
    </div>
}

export default ActiveCallTab
