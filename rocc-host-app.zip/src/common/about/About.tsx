/*
 * Created on Mon Jan 31 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import { Modal } from "semantic-ui-react"
import Importer from "./../../assets/images/Importer.svg"
import Caution from "./../../assets/images/caution.svg"
import FactoryFilled from "./../../assets/images/factoryFilled.svg"
import IFU from "./../../assets/images/ifu.svg"
import Logo from "./../../assets/images/logo.svg"
import { APP_VERSION, LANGUAGES } from "../../constants/constants"
import { fetchVersion } from "../../redux/actions/appActions"
import SVG from "react-inlinesvg"
import { useDispatch, useSelector } from "react-redux"
import styles from "./About.scss"
import en from "../../resources/translations/en-US"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EConnectionStatus, IParentStore } from "@rocc/rocc-client-services"


interface IAboutProps {
  isModalOpen: boolean
  closeModal: () => void
  companyName: string
  applicationTitle: string
}

const About = (props: IAboutProps) => {
  const { companyName, isModalOpen, closeModal, applicationTitle } = props

  const [init, setInit] = useState(false)

  const { applicationConnectionState, version, locale } = useSelector((state: IParentStore) => ({
    applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
    version: state.appReducer.version,
    locale: state.configReducer.configData.preferredLocale
  }))

  const dispatch = useDispatch()
  const { intl } = getIntlProvider()
  const isUKILanguage = locale === LANGUAGES.GREAT_BRITAIN.LOCALE

  useEffect(() => {
    if (applicationConnectionState === EConnectionStatus.ONLINE && !init) {
      setInit(true)
      dispatch(fetchVersion(APP_VERSION))
    }
  }, [applicationConnectionState])

  return (
    <>
      <Modal className={styles.aboutModal} open={isModalOpen} onClose={closeModal} closeIcon={"Cross huge"}>
        <div className={styles.container}>
          <div className={styles.logo}>
            <SVG src={Logo} cacheRequests={true} />
          </div>

          <div className={styles.appName}>
            {companyName} <br />
            {applicationTitle}
          </div>
          <div className={styles.version}>
            {intl.formatMessage({ id: "content.aboutPage.version", defaultMessage: en["content.aboutPage.version"] })}
            {" "}{version}
          </div>

          <div className={styles.copyright}>
            {intl.formatMessage({ id: "content.aboutPage.aboutContentPart1", defaultMessage: en["content.aboutPage.aboutContentPart1"] })}
            <br />
            {intl.formatMessage({ id: "content.aboutPage.aboutContentPart2", defaultMessage: en["content.aboutPage.aboutContentPart2"] })}
            <br />
            {intl.formatMessage({ id: "content.aboutPage.aboutContentPart3", defaultMessage: en["content.aboutPage.aboutContentPart3"] })}
            <br />
            {intl.formatMessage({ id: "content.aboutPage.aboutContentPart4", defaultMessage: en["content.aboutPage.aboutContentPart4"] })}
          </div>

          <br />
          {isUKILanguage ? <></> : <br />}

          <div className={styles.addressContainer}>
            <SVG src={FactoryFilled} cacheRequests={true} />
            <div className={styles.address}>
              <span>
                {intl.formatMessage({ id: "content.aboutPage.addressLine1", defaultMessage: en["content.aboutPage.addressLine1"] })}
              </span>
              {isUKILanguage ? <>
                <span>
                  {intl.formatMessage({ id: "content.aboutPage.addressLine2", defaultMessage: en["content.aboutPage.addressLine2"] })},&nbsp;
                  {intl.formatMessage({ id: "content.aboutPage.addressLine3", defaultMessage: en["content.aboutPage.addressLine3"] })},&nbsp;
                  {intl.formatMessage({ id: "content.aboutPage.addressLine4", defaultMessage: en["content.aboutPage.addressLine4"] })},&nbsp;
                  {intl.formatMessage({ id: "content.aboutPage.addressLine5", defaultMessage: en["content.aboutPage.addressLine5"] })},&nbsp;
                </span>
                <div className={styles.importerAddressContainer}>
                  <SVG src={Importer} cacheRequests={true} />
                  <div className={styles.address}>
                    <span className={styles.addressHeader}>
                      {intl.formatMessage({ id: "content.aboutPage.ukAddressHeader", defaultMessage: en["content.aboutPage.ukAddressHeader"] })}
                    </span>
                    <span>
                      {intl.formatMessage({ id: "content.aboutPage.ukAddressLine1", defaultMessage: en["content.aboutPage.ukAddressLine1"] })}
                    </span>
                    <span>
                      {intl.formatMessage({ id: "content.aboutPage.ukAddressLine2", defaultMessage: en["content.aboutPage.ukAddressLine2"] })}
                    </span>
                  </div>
                </div>
              </>
                : <>
                  <span>
                    {intl.formatMessage({ id: "content.aboutPage.addressLine2", defaultMessage: en["content.aboutPage.addressLine2"] })}
                  </span>
                  <span>
                    {intl.formatMessage({ id: "content.aboutPage.addressLine3", defaultMessage: en["content.aboutPage.addressLine3"] })}
                  </span>
                  <span>
                    {intl.formatMessage({ id: "content.aboutPage.addressLine4", defaultMessage: en["content.aboutPage.addressLine4"] })}
                  </span>
                  <span>
                    {intl.formatMessage({ id: "content.aboutPage.addressLine5", defaultMessage: en["content.aboutPage.addressLine5"] })}
                  </span>
                </>}
            </div>
          </div>

          <div className={styles.footer}>
            <SVG className={styles.ifuIcon} src={IFU} cacheRequests={true} />
            <SVG className={styles.cautionIcon} src={Caution} cacheRequests={true} />
          </div>
        </div>
      </Modal>
    </>
  )
}

export default About
