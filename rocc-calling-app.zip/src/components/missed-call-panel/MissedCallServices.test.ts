/*
 * Created on Tue Sept 21 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, EResponse, IUserInfo } from "@rocc/rocc-client-services"
import * as apiUtility from "../../common/helpers/apiUtility"
import { clearBadgeCountService, getMissedCallsService, postMissedCallService } from "./MissedCallServices"

jest.mock("@rocc/rocc-http-client")

const getAxiosResponse = (data: any) => {
    return {
        data: { data },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {}
    }
}

const currentUser: IUserInfo = { ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", accessTokenExpiryTime: "", onBoarded: true, sessionId: "sessionId", locale: "en-US" }

const missedcallResponse = [{
    "id": 10482,
    "callContextId": "2407494f-5606-4089-b6e9-436ae995c1a3",
    "attemptedCallTime": "2021-09-17T08:44:45.000+0000",
    "caller": "f89ff0bc-b109-458d-be0f-7be4c2c99844",
    "callee": "900b968f-76ac-4593-8c4f-b094d50aad89",
    "seen": true
}]

const missedcallRequest = {
    "currentUser": currentUser,
    "url": "https://missedcall/philips/rocc",
    "callContextId": "2407494f-5606-4089-b6e9-436ae995c1a3",
    "caller": "f89ff0bc-b109-458d-be0f-7be4c2c99844",
    "callee": "900b968f-76ac-4593-8c4f-b094d50aad89",
    "seen": true
}

describe("getMissedCallsService tests", () => {
    it("get missed details 200 response", () => {
        const response = getAxiosResponse(missedcallResponse)
        jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(response))
        getMissedCallsService("https://missedcall/philips/rocc", "token", "userUuid").then(response => {
            expect(response.status).toBe(EResponse.SUCCESS)
        })
    })

    it("get missed details 400 response", () => {
        const response = {
            data: {},
            status: 400,
            statusText: "Bad Request",
            headers: {},
            config: {}
        }
        jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(response))
        getMissedCallsService("https://missedcall/philips/rocc", "token", "userUuid").then(response => {
            expect(response.status).toBe(EResponse.ERROR)
        })
    })
})

describe("postMissedCallService tests", () => {
    it("post missed details 200 response", () => {
        const response = getAxiosResponse(missedcallResponse)
        jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(response))
        const { currentUser, url, callContextId, callee, caller, seen } = missedcallRequest
        postMissedCallService(currentUser, url, callContextId, callee, caller, seen).then(response => {
            expect(response).toBeUndefined()
        })
    })
})

describe("clearBadgeCountService tests", () => {
    it("clearBadgeCountService 200 response", () => {
        const response = getAxiosResponse(missedcallResponse)
        jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(response))
        const { currentUser, url, callContextId, seen } = missedcallRequest
        clearBadgeCountService([callContextId], currentUser.uuid, "accesstoken", seen, url).then(response => {
            expect(response).toBeTruthy()
        })
    })

    it("clearBadgeCountService 400 response", () => {
        const response = {
            data: {},
            status: 400,
            statusText: "Bad Request",
            headers: {},
            config: {}
        }
        jest.spyOn(apiUtility, "putService").mockReturnValue(Promise.resolve(response))
        const { currentUser, url, callContextId, seen } = missedcallRequest
        clearBadgeCountService([callContextId], currentUser.uuid, "accesstoken", seen, url).then(response => {
            expect(response).toBeFalsy()
        })
    })
})
