/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { graphqlClient } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { QUERY_COMMAND_CENTER_SEATS, QUERY_FETCH_ALL_RECEIVERS_FOR_A_SEAT, SUBSCRIPTION_PID_ACTIVE_EMERALD_CONNECTIONS_FOR_USER } from "../../graphql/queries/queries"

export const fetchCommandCenterService = async (metasiteId: number) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_COMMAND_CENTER_SEATS,
            variables: { orgId: metasiteId },
        })
        return result.data.command_center_seats
    } catch (error) {
        errorLogger(`Error while fetching Expert user seats, error: ${errorParser(error)}`)
        return []
    }
}
export const fetchReceiversForASeatService = async (dbOrgId: string, seatName: string) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_FETCH_ALL_RECEIVERS_FOR_A_SEAT,
            variables: { orgId: dbOrgId, seatName },
        })
        return result.data.receivers
    } catch (error) {
        errorLogger(`Error while fetching receivers for seat ${seatName}, error: ${errorParser(error)}`)
        return []
    }
}


export const subscribeToConsolePidChange = (requester: string) => {
    return graphqlClient.subscribe({
        query: SUBSCRIPTION_PID_ACTIVE_EMERALD_CONNECTIONS_FOR_USER,
        variables: { requester }
    })
}
