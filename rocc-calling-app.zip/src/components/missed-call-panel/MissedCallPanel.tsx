/*
 * Created on Thu Sep 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { UserList } from "@rocc/rocc-calling-components"
import { ECallStatus, EClinicalRole, getDetailsByUUID, IMissedCallData } from "@rocc/rocc-client-services"
import { getIntlProvider, NoRecordsContent } from "@rocc/rocc-global-components"
import { errorLogger } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { getAppReducerFromGlobalStore, getConfigReducerFromGlobalStore, getCustomrReducerFromGlobalStore, getRoleName, getSiteName, getUserReducerFromGlobalStore } from "../../common/helpers/helpers"
import { DEVICE, DEVICE_MISSED_CALL_SIDEBAR, GUEST, TELEPRESENCE_SIDEBAR, TIMEOUT_60000 } from "../../constants/constants"
import { resetBadgeCountOfMissedCalls } from "../../redux/actions/callActions"
import { IStore } from "../../redux/interfaces/types"
import { fetchGlobalURLs } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import { ESidePanelTabs, IContactProps } from "../../types/types"
import { getLocalTime, getMissedCalls } from "./MissedCallHelpers"
import styles from "./MissedCallPanel.scss"
import { clearBadgeCountService } from "./MissedCallServices"

export interface IMissedCallPanel {
    activeItem: ESidePanelTabs
    contactCardActions: (props: IContactProps) => any[]
}

export enum EProfile {
    USER = "user",
    DEVICE = "device",
}

const { MissedCalls } = ESidePanelTabs
const MissedCallPanel = (props: IMissedCallPanel) => {
    const { activeItem, contactCardActions } = props
    const activeTab = activeItem === MissedCalls
    const [cards, setCards] = useState([] as any[])
    const [clearing, setClearing] = useState([] as string[])
    const [init, setInit] = useState(false)
    const [eligibleContextId, setEligibleContextId] = useState("")
    const [eligibleTechUUID, setEligibleTechUUID] = useState("")
    const [currentTime, setCurrentTime] = useState(new Date())

    const {
        missedCalls,
        videoCallStatus,
        permissions,
        featureFlags,
    } = useSelector((state: IStore) => ({
        missedCalls: state.callReducer.missedCalls,
        videoCallStatus: state.callReducer.videoCallStatus,
        permissions: state.externalReducer.permissions,
        featureFlags: state.externalReducer.featureFlags,
    }))

    const { currentUser, contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    const { activeRightPanel, displayRightSidePanel } = getAppReducerFromGlobalStore().sideBar
    const { language } = getConfigReducerFromGlobalStore().configData
    const { COMMUNICATION_SERVICES_URL } = fetchGlobalURLs()
    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const setMissedCallCards = async () => {
        try {
            const dispalyItem: any[] = []
            for (const missedCall of missedCalls) {
                const mContact = await getDetailsByUUID(missedCall.caller, contacts, rooms)
                if (mContact.uuid) {
                    dispalyItem.push({
                        id: mContact.id,
                        uuid: mContact.uuid,
                        title: mContact.name,
                        metaData: getRoleName(mContact.clinicalRole),
                        presence: mContact.status,
                        description: (mContact.clinicalRole == DEVICE) ? getSiteName(mContact.description, mContact.siteId) : mContact.loggedInLocation,
                        timestamp: getLocalTime(missedCall.attemptedCallTime, currentTime, language),
                        userActions: contactCardActions({ contact: mContact, permissions, featureFlags })
                    })
                }
            }
            setCards(dispalyItem)
        } catch (error) {
            errorLogger(`Encountered error while listing missed calls: ${JSON.stringify(error)}`)
        }
    }

    useEffect(() => {
        /* Compute condition to call getMissedCall API
        1. Only when the sidebar opens with Missed Call as Active tab
        2. Compute based on relevant call status change
         */
        const { CALLDECLINED, NOT_ANSWERED } = ECallStatus
        const isActiveTab = activeRightPanel && [TELEPRESENCE_SIDEBAR, DEVICE_MISSED_CALL_SIDEBAR].includes(activeRightPanel) && activeItem === MissedCalls
        const matchedCallRecord = videoCallStatus.filter((r) => [CALLDECLINED, NOT_ANSWERED].includes(r.callStatus))
        const isDevice = currentUser && currentUser.clinicalRole === EClinicalRole.DEVICE ? true : false
        let isTechLoggedIn = false
        let isCallEnd = false
        if (matchedCallRecord && matchedCallRecord.length && matchedCallRecord[0].contextId !== eligibleContextId) {
            setEligibleContextId(matchedCallRecord[0].contextId)
            isCallEnd = true
        }
        const { secondaryName, secondaryUUID } = currentUser
        if (isDevice && secondaryUUID) {
            isTechLoggedIn = !!secondaryName && !["", eligibleTechUUID].includes(secondaryUUID)
            if (isTechLoggedIn) {
                setEligibleTechUUID(secondaryUUID)
            } else {
                if (eligibleTechUUID && secondaryName === GUEST) {
                    setEligibleTechUUID("")
                }
            }
        }

        if (isActiveTab || isCallEnd || !init || isTechLoggedIn /*|| !activeTechProfile.id*/) {
            getMissedCalls(currentUser, dispatch, COMMUNICATION_SERVICES_URL, secondaryUUID)
            if (!init) { setInit(true) }
        }
    }, [activeRightPanel, activeItem, videoCallStatus, currentUser])

    useEffect(() => {
        setMissedCallCards()
    }, [rooms, contacts, missedCalls, activeRightPanel])

    useEffect(() => {
        /* To clear badge count */
        if (activeRightPanel && [TELEPRESENCE_SIDEBAR, DEVICE_MISSED_CALL_SIDEBAR].includes(activeRightPanel) && activeItem === MissedCalls) {
            const callContextIds = [] as string[]
            missedCalls.forEach((item: IMissedCallData) => {
                if (!item.seen) {
                    callContextIds.push(item.callContextId)
                }
            })
            if (callContextIds.length && !clearing.length) {
                setClearing(callContextIds)
                clearBadgeCount(callContextIds)
            }
        }
    }, [displayRightSidePanel, activeItem])

    const clearBadgeCount = async (callContextIds: string[]) => {
        const { accessToken, uuid, secondaryUUID } = currentUser
        const isDevice = currentUser && currentUser.clinicalRole === EClinicalRole.DEVICE ? true : false
        const isTechLoggedIn = isDevice && secondaryUUID
        const userId = isTechLoggedIn ? secondaryUUID : uuid
        const cleared = await clearBadgeCountService(callContextIds, userId, accessToken, true, COMMUNICATION_SERVICES_URL)
        if (cleared) {
            dispatch(resetBadgeCountOfMissedCalls(true))
        }
        setClearing([])
    }

    const updateCurrentTime = () => {
        const newCurrentTime = new Date()
        if (currentTime !== newCurrentTime) {
            setCurrentTime(newCurrentTime)
        }
    }

    useEffect(() => {
        const intervalID = setInterval(updateCurrentTime, TIMEOUT_60000)
        return () => clearInterval(intervalID)
    }, [])

    const renderCards = () => {
        return <UserList data={cards} boldUserName={false} alternateAvatar={true} activeCall={false} optimizedRendering={true} />
    }

    return (
        <div id="missedCallPanel" className={cx(styles["missed-call"], activeTab && styles.active)}>
            {activeTab && missedCalls.length && cards.length > 0 ? renderCards() :
                <div className={styles.noRecords}>
                    <NoRecordsContent
                        content={<span>
                            {intl.formatMessage({ id: "content.missedCall.noMissedCalls", defaultMessage: en["content.missedCall.noMissedCalls"] })}
                        </span>}
                    />
                </div>
            }
        </div>
    )
}

export default MissedCallPanel
