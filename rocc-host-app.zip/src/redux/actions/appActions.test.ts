/*
 * Created on Wed Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse, EAppContext } from "@rocc/rocc-client-services"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { ELoadTimes } from "../../types/types"
import { captureLoadTimesAction, fetchVersion, setActiveTab, setAppRefreshState, setFseMode, setRightSidePanel, setRoomMonitoringWindow, updateAppContext, updateFseMode } from "./appActions"
import { GLOBAL_RIGHTSIDE_PANEL, SET_APP_CONTEXT } from "./types"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

const mockDispatch = jest.fn()
jest.mock("react-redux", () => ({
    useDispatch: () => mockDispatch
}))

describe("should test app actions", () => {
    const store = mockStore({
        externalReducer: {
            currentUser: {},
        },
        appReducer: {
            fseData: {}
        }
    })
    beforeEach(() => {
        store.clearActions()
    })

    it("fetchVersion is defined", () => {
        store.dispatch(fetchVersion("") as any)
        expect(String(store.getActions())).toBeDefined()
        store.clearActions()
    })


    it("setRightSidePanel is defined", () => {
        store.dispatch(setRightSidePanel(true, "") as any)
        expect(String(store.getActions()[0].type)).toBe(GLOBAL_RIGHTSIDE_PANEL)
        store.clearActions()
    })
    it("setFseData should be defined", () => {
        setAppRefreshState(EResponse.DEFAULT, mockDispatch)
        expect(mockDispatch).toHaveBeenCalled()
        store.clearActions()
    })

    it("setFseData should be defined", () => {
        store.dispatch(setActiveTab(0) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })

    it("updateFseMode should be defined", () => {
        store.dispatch(updateFseMode(true) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })

    it("setFseMode should be defined", () => {
        setFseMode([{ orgId: 1 }], "false", mockDispatch)
        expect(mockDispatch).toBeDefined()
        store.clearActions()
    })
    it("captureLoadTimesAction should be defined", () => {
        captureLoadTimesAction(ELoadTimes.LOGIN_CLICK, mockDispatch)
        expect(mockDispatch).toBeDefined()
        store.clearActions()
    })
    it("updateAppContext is defined", () => {
        store.dispatch(updateAppContext(EAppContext.REGULAR) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_APP_CONTEXT)
        store.clearActions()
    })

    it("setRoomMonitoring is defined", () => {
        store.dispatch(setRoomMonitoringWindow(true) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
})
