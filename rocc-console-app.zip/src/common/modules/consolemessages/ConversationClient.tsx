/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { RoccChatClient } from "@rocc/rocc-chat-library"
import { EConnectionStatus, EResponse } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import isEmpty from "lodash.isempty"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { IStore } from "../../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import { CONSOLE_DATA, CONSOLE_STATUS, GLOBAL_FORCE_CLEAN_UP, MEDIA_ROOM, MEDIA_ROOM_ID, MEDIA_TOKEN, MESSAGE_TYPE } from "../../constants/constants"
import ConsoleMessageHandler from "./ConsoleMessageHandler"
import MediaRoomMessageHandler from "./MediaRoomMessageHandler"
import { fetchCommunicationClientDetails } from "./messageService"

const FILE_NAME = "ConsoleConversationClient"
const INIT_CONSOLE_MESSAGE = { consoleStatus: "", consoleContextId: "", userId: "", jwtToken: "" }
const INIT_MEDIA_ROOM_MESSAGE = { mediaRoomId: "", mediaToken: "", eventType: "" }

enum ETwilioEvents {
    TOKEN_ABOUT_TO_EXPIRE = "tokenAboutToExpire",
    TOKEN_EXPIRED = "tokenExpired",
    MESSAGE_ADDED = "messageAdded",
    CONNECTION_STATE_CHANGED = "connectionStateChanged",
    CONNECTION_ERROR = "connectionError",
    DEFAULT = "default",
}

const ConversationClient = () => {
    /**
     * fetch conversation token
     * create conversation client
     * subscribe for conversation event
     */

    const [chatClient, setChatClient] = useState({} as RoccChatClient)
    const [componentMounted, setComponentMounted] = useState(false)
    const [consoleMessages, setConsoleMessages] = useState(INIT_CONSOLE_MESSAGE)
    const [mediaRoomMessage, setMediaRoomMessage] = useState(INIT_MEDIA_ROOM_MESSAGE)

    const { currentUser, forceCleanUp, applicationConnectionState } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser,
        forceCleanUp: state.externalReducer.forceCleanUp,
        applicationConnectionState: state.externalReducer.applicationConnectionState,
    }))

    const chatClientRef = useRef(chatClient)
    const userTokenRef = useRef(currentUser.accessToken)

    const createRoccChatClient = async (userToken?: string) => {
        /* Fetch communication & crypt tokens */
        const urls = fetchGlobalURLs()
        const { status, tokenDetails } = await fetchCommunicationClientDetails(
            urls.COMMUNICATION_SERVICES_URL, userToken ?? currentUser.accessToken, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            /* Fetch Chat client */
            const roccChatClient = new RoccChatClient({ communicationToken: tokenDetails.communicationToken })
            await roccChatClient.initializeClient()
            setChatClient(roccChatClient)
            setupChatClient(roccChatClient)
        } else {
            dispatchToParentStore({ type: GLOBAL_FORCE_CLEAN_UP, payload: { forceCleanUp: true } })
        }
        if (!componentMounted) {
            setComponentMounted(true)
        }
    }

    useEffect(() => {
        return () => {
            cleanUpTasks()
        }
    }, [])

    useEffect(() => { chatClientRef.current = chatClient }, [chatClient])
    useEffect(() => {
        userTokenRef.current = currentUser.accessToken
        if (currentUser.accessToken && isEmpty(chatClient)) {
            infoLogger(`Initializing Conversation client for console application for user ${currentUser.uuid} and session: ${currentUser.sessionId}`)
            createRoccChatClient(currentUser.accessToken)
        }
    }, [currentUser.accessToken])

    useEffect(() => {
        if (!forceCleanUp && applicationConnectionState === EConnectionStatus.ONLINE && !isEmpty(chatClient)) {
            infoLogger(`Updating Conversation client in console application for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
            updateToken(ETwilioEvents.DEFAULT)
        }
    }, [forceCleanUp, applicationConnectionState])

    const cleanUpTasks = () => {
        if (!isEmpty(chatClientRef.current)) {
            infoLogger(`Initiating cleanup of conversation client in console app for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
            chatClientRef.current.communicationShutdown()
            setChatClient({} as RoccChatClient)
        } else {
            infoLogger(`Couldn't close converation client in console application since it is already closed for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
        }
    }

    const setupChatClient = (chatClient: RoccChatClient) => {
        chatClient.communicationOnEvent(ETwilioEvents.MESSAGE_ADDED, messageAdded)
        chatClient.communicationOnEvent(ETwilioEvents.TOKEN_ABOUT_TO_EXPIRE, () => updateToken(ETwilioEvents.TOKEN_ABOUT_TO_EXPIRE))
        chatClient.communicationOnEvent(ETwilioEvents.TOKEN_EXPIRED, () => updateToken(ETwilioEvents.TOKEN_EXPIRED))
        chatClient.communicationOnEvent(ETwilioEvents.CONNECTION_STATE_CHANGED, connectionStateChanged)
        chatClient.communicationOnEvent(ETwilioEvents.CONNECTION_ERROR, handleConnectionError)
        infoLogger(`Conversation client creation in console app is successful for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
    }

    const messageAdded = (message: any) => {
        if (message.state.body && message.state.body.trim().length > 0) {
            const messageBody = JSON.parse(message.state.body)
            if (messageBody[CONSOLE_DATA] !== undefined) {
                try {
                    const data = JSON.parse(messageBody[CONSOLE_DATA])
                    setConsoleMessages({ consoleStatus: data[CONSOLE_STATUS], consoleContextId: data.contextId, userId: data.userId, jwtToken: data.additionalData?.jwtToken })
                } catch (e) {
                    errorLogger(`Failed to parse message body: ${messageBody} : ${e} for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                }
            } else if (messageBody[MESSAGE_TYPE] === MEDIA_ROOM) {
                setMediaRoomMessage({ mediaRoomId: messageBody[MEDIA_ROOM_ID], mediaToken: messageBody[MEDIA_TOKEN], eventType: messageBody["MessageStatus"] })
            } else {
                //sonar critical bug fix
            }
        }
    }

    const updateToken = async (event: ETwilioEvents) => {
        infoLogger(`${FILE_NAME} Updating ChatClient`)
        const urls = fetchGlobalURLs()
        const { status, tokenDetails } = await fetchCommunicationClientDetails(urls.COMMUNICATION_SERVICES_URL, userTokenRef.current, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            if (!isEmpty(chatClientRef.current)) {
                infoLogger(`Existing Communication client is updated with new token by event: ${event} for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                chatClientRef.current.communicationUpdateToken(tokenDetails.communicationToken)
            } else {
                infoLogger(`Communication client is re-created by event: ${event} for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                createRoccChatClient(userTokenRef.current)
            }
        } else {
            dispatchToParentStore({ type: GLOBAL_FORCE_CLEAN_UP, payload: { forceCleanUp: true } })
        }
    }

    const connectionStateChanged = (message: any) => {
        if (componentMounted) {
            switch (message.toLowerCase()) {
                case "disconnecting":
                    infoLogger(`ConversationClient is disconnecting in console application for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    break
                case "connected":
                    infoLogger(`ConversationClient is connected in console application for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    break
                case "denied":
                    /** ChatClient creation failed trying to recreate chatClient */
                    errorLogger(`ConversationClient is disconnected in console application, trying to reconnect for user ${currentUser.uuid} and session ${currentUser.sessionId}`)
                    updateToken(ETwilioEvents.DEFAULT)
                    break
                default:
            }
        }
    }

    const handleConnectionError = (errorMessage: any) => {
        const { terminal, message, errorCode, httpStatusCode } = errorMessage
        errorLogger(`For User: ${currentUser.uuid}, encountered connection error in console app with message: ${message}, terminal: ${terminal}, errorCode: ${errorCode}, httpStatusCode: ${httpStatusCode}`)
    }

    return (
        <>
            <ConsoleMessageHandler contextId={consoleMessages.consoleContextId} consoleConnectionStatus={consoleMessages.consoleStatus} userId={consoleMessages.userId} jwtToken={consoleMessages.jwtToken} />
            <MediaRoomMessageHandler mediaRoomId={mediaRoomMessage.mediaRoomId} mediaToken={mediaRoomMessage.mediaToken} eventType={mediaRoomMessage.eventType} />
        </>
    )
}

export default ConversationClient
