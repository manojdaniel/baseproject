/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { EROCC_CONTEXT, ECallStatus } from "@rocc/rocc-client-services"
import { getCallStatusFromICallStatus } from "../../common/helpers/callUtility"
import { IStore } from "../../redux/interfaces/types"
import { IncomingCallModal, IncomingCallWindow } from "@rocc/rocc-calling-components"
import { prepareIncomingCallModal } from "../../common/helpers/helpers"

interface IIncomingCall {
    deviceType: EROCC_CONTEXT
}

const IncomingCall = ({ deviceType }: IIncomingCall) => {

    const { incomingCallDetails, videoCallStatus } = useSelector((state: IStore) => ({
        incomingCallDetails: state.callReducer.callDetails.incomingCall,
        videoCallStatus: state.callReducer.videoCallStatus
    }))

    const [showIncomingModal, setShowIncomingModal] = useState(false)

    const dispatch = useDispatch()

    useEffect(() => {
        const callStatuses = getCallStatusFromICallStatus(videoCallStatus)
        setShowIncomingModal(callStatuses.includes(ECallStatus.RINGING))
    }, [videoCallStatus])

    const callStatuses = getCallStatusFromICallStatus(videoCallStatus)

    if (showIncomingModal) {
        const object = prepareIncomingCallModal(incomingCallDetails, deviceType, setShowIncomingModal, dispatch)
        const isDesktop = deviceType === EROCC_CONTEXT.DESKTOP
        return (
            isDesktop || (callStatuses.includes(ECallStatus.CONNECTED)) ?
                <IncomingCallModal {...object} /> :
                <IncomingCallWindow {...object} />
        )
    } else {
        return <></>
    }
}

export default IncomingCall
