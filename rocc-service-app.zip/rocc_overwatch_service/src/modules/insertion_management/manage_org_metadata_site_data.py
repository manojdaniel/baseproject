"""
 Created on Wed Apr 21 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.constants.constants import ID, INSERT, KVM_CONFIGURATION_DICT, OBJECTS, ROCC_KVM_CONFIGURATIONS, ROCC_ORGANIZATIONS, ROCC_SCHEMA, ROCC_SITES, SITES_DICT
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import check_and_add_fse_to_org_mapping, fetch_org_db_id_from_identifier
from src.modules.db_operations.db_utility.graphql_response_parser import extract_id_from_mutation_response, extract_response_from_mutation_response
from src.modules.db_operations.db_utility.raw_data_transformer import extract_table_name_from_schema_table_name
from src.modules.db_operations.insertion_services.sites_db_services import construct_eula_documents, construct_kvm_boxilla_object, construct_new_org_details_object, \
    construct_site_contacts_object, construct_sites
from src.wrappers.graphql.mutations.mutations import insert_rocc_site_contacts, insert_new_customer_data, insert_new_sites_data, upsert_eula_docs, upsert_kvm_configs, \
    update_rocc_overwatch_customers_raw_data
from src.modules.db_operations.insertion_services.room_db_services import get_kvm_configuration_id_by_org_db_id

LOG = create_logger("ManageOrgMetadataAndSiteDataTask")


class ManageOrgMetadataAndSiteDataTask():
    def __init__(self, data_dict, client, transaction_data, customer_short_name, org_hsdp_uuid, user_uuid, locale):
        self._client = client
        self._user_uuid = user_uuid
        self._data_dict = data_dict
        self._transaction_data = transaction_data
        self._customer_short_name = customer_short_name
        self._org_hsdp_uuid = org_hsdp_uuid
        self._locales = locale.split(",")

    def execute(self, upload_record_id):
        """
        - Check if customer is present
            - If no, Handle new customer
            - If yes, Update
                - method - update site data
                - method - update eula data
                - method - update kvm data
        """
        LOG.info("Initiating TASK OrgMetadataAndSitesDataInsertion")
        try:
            org_db_id = fetch_org_db_id_from_identifier(client=self._client, customer_identifier=self._customer_short_name)
            if not org_db_id:
                """ Handle new customer """
                kvm_config_id, org_db_id = self.task_add_new_customer_data()
                sites_dict = self._data_dict[SITES_DICT]
                for site_identifier, site in sites_dict.items():
                    site["org_db_id"] = org_db_id
                    LOG.info(f"Updating org_db_id with: {org_db_id} for site: {site_identifier}")
                self._data_dict[SITES_DICT] = sites_dict
                variable_values = {"upload_record_id": upload_record_id, "data": self._data_dict}
                self._client.execute(update_rocc_overwatch_customers_raw_data, variable_values=variable_values)
            else:
                """ Handle existing customer """
                kvm_config_id = self.task_add_new_data_for_existing_customer_data(org_db_id)
            check_and_add_fse_to_org_mapping(client=self._client, fse_user_uuid=self._user_uuid, org_db_id=org_db_id)
            return self._data_dict, self._transaction_data, kvm_config_id, org_db_id

        except RoccException as e_x:
            LOG.error(f"Exception occurred while inserting sites in DB {e_x}")
            raise RoccException(e_x.status_code, str(e_x.payload)) from e_x
        except Exception as e_x:
            LOG.error(f"Exception occurred while inserting sites in DB {e_x}")
            raise RoccException(500, "Exception occurred while inserting sites in DB") from e_x

    def task_add_new_customer_data(self):
        try:
            variables = {OBJECTS: construct_new_org_details_object(data_dict=self._data_dict,
                                                                   client=self._client,
                                                                   transaction_data=self._transaction_data,
                                                                   org_hsdp_uuid=self._org_hsdp_uuid,
                                                                   user_uuid=self._user_uuid,
                                                                   locales=self._locales,
                                                                   customer_short_name=self._customer_short_name)}
            response = extract_response_from_mutation_response(self._client.execute(insert_new_customer_data, variable_values=variables), f"{INSERT}{ROCC_ORGANIZATIONS}")
            if len(response):
                kvm_config_id = response[0][extract_table_name_from_schema_table_name(ROCC_KVM_CONFIGURATIONS, ROCC_SCHEMA)][0][ID]
                org_db_id = response[0][ID]
                sites_dict = self._data_dict[SITES_DICT]
                for site_response in response[0]["sites"]:
                    """ Manage site contacts """
                    variables = {OBJECTS: construct_site_contacts_object(organization_id=response[0][ID], site_id=site_response["id"],
                                                                         data=sites_dict[site_response["identifier"]],
                                                                         client=self._client,
                                                                         user_uuid=self._user_uuid)}

                    self._client.execute(insert_rocc_site_contacts, variable_values=variables)
                    sites_dict[site_response["identifier"]][ID] = site_response[ID]
                self._data_dict[SITES_DICT] = sites_dict
                return kvm_config_id, org_db_id
            else:
                LOG.exception("Exception occurred while inserting new customer data")
                raise RoccException(500, "Exception occurred while inserting new customer data")
        except Exception as e_x:
            LOG.exception(f"Exception occurred while inserting new customer data with error: {e_x}")
            raise RoccException(500, "Exception occurred while inserting new customer data") from e_x

    def task_add_new_data_for_existing_customer_data(self, org_db_id):
        """
        - Required orgDbId
        - Update:
            - Check and new sites
            - Check and add eula
            - Check and add kvm configs
        """
        try:
            self.task_check_and_add_sites(org_db_id)
            self.task_check_and_add_eula(org_db_id)
            kvm_config_id = self.task_check_and_add_kvm_configs(org_db_id)
            return kvm_config_id
        except Exception as e_x:
            LOG.exception(f"Exception occurred while inserting new customer data with error: {e_x}")
            raise RoccException(500, "Exception occurred while adding data to existing customer") from e_x

    def task_check_and_add_sites(self, org_db_id):
        try:
            """
            - Loop through all sites
                - check if site is not present
                    - add site
                    - add site contacts
            """
            sites_dict = self._data_dict[SITES_DICT]
            sites_obj = construct_sites(sites_dict, self._client, self._transaction_data, self._user_uuid, org_db_id)
            if len(sites_obj):
                variables = {OBJECTS: sites_obj}
                response = extract_response_from_mutation_response(self._client.execute(insert_new_sites_data, variable_values=variables), f"{INSERT}{ROCC_SITES}")

                self.task_check_and_add_site_contacts(sites_response=response, org_db_id=org_db_id)
            else:
                LOG.info("Skipping sites data insertion, since there are no eligible sites")

        except Exception as e_x:
            LOG.exception(f"Exception occurred while inserting new sites to customer: {self._customer_short_name} data with error: {e_x}")
            raise RoccException(500, "Exception occurred while adding sites data to existing customer") from e_x

    def task_check_and_add_eula(self, org_db_id):
        try:
            eula_docs = construct_eula_documents(locales=self._locales, user_uuid=self._user_uuid, customer_short_name=self._customer_short_name, org_db_id=org_db_id)
            self._client.execute(upsert_eula_docs, {OBJECTS: eula_docs})
        except Exception as e_x:
            LOG.exception(f"Failed to add/update EULA for customer: {self._customer_short_name} with error: {e_x}")
            raise RoccException(500, "Exception occurred while adding eula data to existing customer") from e_x

    def task_check_and_add_kvm_configs(self, org_db_id):
        try:
            kvm_dict = self._data_dict[KVM_CONFIGURATION_DICT]
            if bool(kvm_dict):
                LOG.info("KVM Configurations are populated in the excel sheet for existing customer. Updating")
                kvm_configs = construct_kvm_boxilla_object(
                    kvm_dict=self._data_dict[KVM_CONFIGURATION_DICT],
                    user_uuid=self._user_uuid, transaction_data=self._transaction_data, org_db_id=org_db_id)
                kvm_config_id = extract_id_from_mutation_response(self._client.execute(upsert_kvm_configs, {OBJECTS: kvm_configs}), f"{INSERT}{ROCC_KVM_CONFIGURATIONS}")
                return kvm_config_id
            else:
                LOG.info("KVM Configurations are not populated in the excel sheet for existing customer. Skipping")
                return get_kvm_configuration_id_by_org_db_id(client=self._client, org_db_id=org_db_id)
        except Exception as e_x:
            LOG.exception(f"Failed to add/update KVM configurations for customer: {self._customer_short_name} with error: {e_x}")
            raise RoccException(500, "Exception occurred while adding KVM data to existing customer") from e_x

    def task_check_and_add_site_contacts(self, sites_response, org_db_id):
        try:
            sites_dict = self._data_dict[SITES_DICT]
            for item in sites_response:
                variables = {OBJECTS: construct_site_contacts_object(organization_id=org_db_id,
                                                                     site_id=item["id"],
                                                                     data=sites_dict[item["identifier"]],
                                                                     client=self._client,
                                                                     user_uuid=self._user_uuid)}
                self._client.execute(insert_rocc_site_contacts, variable_values=variables)
        except Exception as e_x:
            LOG.exception(f"Failed to add/update Site contacts for customer: {self._customer_short_name} with error: {e_x}")
            raise RoccException(500, "Exception occurred while adding site contacts data to existing customer") from e_x
