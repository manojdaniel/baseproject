/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {
    EButtonDirection, EConnectionMode, EConnectionState, EConnectionType, EOperationStatus, ERoccWorkflow, ETransactionStatus, FeatureFlagHelper,
    getRoomDetailFromUuid, getTrackingEvent, IConsoleSession, IRoomDetails, isQualifiedForFixedCommandCenterEdit, IUserInfo, ParkAndResumeContext,
    parseIntBase10, REGISTER_WORKFLOW, ROCC_FEATURES, TransactionValue,
} from "@rocc/rocc-client-services"
import { CustomLoader, getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, infoLogger, sendLogsToAzure, warningLogger } from "@rocc/rocc-logging-module"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"
import cx from "classnames"
import React from "react"
import SVG from "react-inlinesvg"
import { Dispatch } from "redux"
import { Checkbox, CheckboxProps, Grid, Icon, Modal } from "semantic-ui-react"
import StartEditing from "../../assets/images/startEditing.svg"
import { getActiveSessionMessageForCC, getHeaderForCC } from "../../components/console-monitor-selection/ConsoleMonitorSelectionHelper"
import styles from "../../components/protocol-management/ProtocolManagement.scss"
import { resetConsoleSession, setConsoleOperations, updateConsoleSession } from "../../redux/actions/consoleActions"
import { GLOBAL_SET_INITIATE_WEB_CALL, GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import { IConsoleOperation, IConsoleTransaction, IHandleAppUri, IPerformConsoleConnectionOps, IStore, IWorkflowInfo } from "../../redux/interfaces/types"
import { DEFAULT_CONSOLE_OPERATIONS } from "../../redux/reducers/consoleReducer"
import { dispatchToParentStore, fetchGlobalConfigs, fetchGlobalURLs, fetchRooms } from "../../redux/store/externalAppStates"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"
import { consoleSwitchService, disconnectConsoleService, initiateAuthorizeCCConsoleService, initiateCCConsoleService } from "../../services/consoleService"
import {
    commandCenter, DEFAULT_API_VERSION, EMERALD_APP_URI_RESTART, EMERALD_APP_URI_START, EMERALD_APP_URI_STOP, EMERALD_APP_URI_STOP_ALL, HTTP_STATUS, INIT_MEDIA_ROOM_DETAILS,
    INIT_ROOM_INFO, MAX_SUPPORTED_MULTICAMERA_STREAMS, nonFixedCommandCenter, TRACKED_CONSOLE_WORKFLOWS
} from "../constants/constants"
import { getConnectionAdapter } from "./connection"
import { checkIfUserHasCompatibleNFCCBundle } from "./consoleHelpers"
import {
    checkIfMultiRoomIsDisabled, checkIfReceiverInUse, checkTransactionForRoomAndState, constructAppUriConfigs, displayEditToViewSwitchMessage, displayErrorModal,
    displayNotificationMessage, fetchActiveSessionForReceiver, fetchActiveSessionToBeDisconnected, fetchActiveTransactionForRoomAndConnectionType, fetchAllEditConsoleType,
    fetchCallContextForRoomUuid, fetchViewConsoleSessionForRoom, generateTransactionObject, generateUniqueId, getActiveSessionsForConnectionMode, getMaxNumAllowedNFCC,
    getNFCCMaxlimitMessage, getPidFromContextMapping, getRoomUuidsFromWorkflowContext, hasActiveVidoCallWithRoom, hideNotificationModal, isMaximumNFCCLimitReached, isNFCCAllowed,
    isRoomMonitoringEnabled, launchAppUri, messageViewToEdit, updateSpokeQualifiedCheckboxStatus
} from "./helpers"
import { trackConsoleDisconnection, trackConsoleSwitching, transformSessionTypeForAnalytics } from "./TelemetryTrackingHelper"

interface IDirectCCConnection {
    consoleTransaction: IConsoleTransaction
    currentUser: IUserInfo
    dispatch: Dispatch<any>
    seatName: string
}

const COMPONENT_NAME = "ConsoleUtility"

export const handleDirectCCConnection = async (props: IDirectCCConnection) => {
    const { currentUser, consoleTransaction, dispatch, seatName } = props
    let returnValue = ETransactionStatus.FAILED
    const { intl } = getIntlProvider()
    const mode = consoleTransaction.connectionMode === EConnectionMode.CC ? commandCenter : nonFixedCommandCenter
    try {
        const { connectionType, roomUuid, receiverName, connectionMode } = consoleTransaction
        const params = {
            connectionType, requester: currentUser.uuid, roomUuid, seatName, connectionMode,
            accessToken: currentUser.accessToken, receiverName, orgId: parseIntBase10(currentUser.orgId)
        }
        const contextId = await initiateCCConsoleService(params)

        if (contextId) {
            //TODO: Add positive Tracking event
            const currentSession: IConsoleSession = {
                requester: currentUser.uuid, receiverName, contextId, connectionMode: connectionMode,
                connectionType, roomUuid, mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS, connectionStatus: EConnectionState.CONNECTED,
                displayCameraToggle: false, multiCameraList: [], consoleStartTime: new Date().toString(),
            }
            handleConsoleTransition({ transactionStatus: TransactionValue.CONNECTING, dispatch, currentSession })
            infoLogger(`${connectionType} console session is successfully established between ${currentUser.uuid} and ${roomUuid}`)
            returnValue = ETransactionStatus.FINISHED
        } else {
            displayErrorModal(intl.formatMessage({
                id: "content.consoleMessages.consoleConnectionFailed",
                defaultMessage: en["content.consoleMessages.consoleConnectionFailed"]
            }))

            sendLogsToAzure({
                contextData: {
                    component: "consoleUtlity",
                    event: `failed to initiate ${mode} connection`,
                    Event_By: currentUser.uuid, connectionMode, connectionType
                }
            })
        }
    } catch (error: any) {
        //TODO: Add negative Tracking event
        errorLogger(`Failed to initiate command center connction with error ${errorParser(error)}`)
        displayErrorModal(intl.formatMessage({
            id: "content.consoleMessages.consoleConnectionFailed",
            defaultMessage: en["content.consoleMessages.consoleConnectionFailed"]
        }))
        sendLogsToAzure({
            contextData: {
                component: "consoleUtlity",
                event: `failed to initiate ${mode} connection`,
                Event_By: currentUser.uuid, connectionMode: consoleTransaction.connectionMode,
                connectionType: consoleTransaction.connectionType
            }
        })
    }
    return returnValue
}

interface IAuthorizeCCConnection {
    contextId: string
    currentUser: IUserInfo
    dispatch: Dispatch<any>
    consoleTransaction: IConsoleTransaction
}

export const handleAuthorizeCCConnection = async (props: IAuthorizeCCConnection) => {
    const { contextId, currentUser, dispatch, consoleTransaction } = props
    let returnValue = ETransactionStatus.FAILED
    const { intl } = getIntlProvider()
    try {
        const statusCode = await initiateAuthorizeCCConsoleService(contextId, currentUser)
        if (statusCode === HTTP_STATUS.OK) {
            //TODO: Add positive Tracking event
            const { receiverName, connectionType, roomUuid } = consoleTransaction
            const callContextId = fetchCallContextForRoomUuid(roomUuid)?.contextId
            const currentSession: IConsoleSession = {
                requester: currentUser.uuid, receiverName, contextId, connectionMode: EConnectionMode.CC,
                connectionType, roomUuid, mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS, connectionStatus: EConnectionState.CONNECTED,
                displayCameraToggle: false, multiCameraList: [], consoleStartTime: new Date().toString(), additionalData: { callContextId }
            }
            handleConsoleTransition({ transactionStatus: TransactionValue.CONNECTING, dispatch, currentSession })
            infoLogger(`${connectionType} console session is successfully established between ${currentUser.uuid} and ${roomUuid}`)
            returnValue = ETransactionStatus.FINISHED
        }
    } catch (error) {
        //TODO: Add negative Tracking event
        errorLogger(`Failed to initiate authorize command center connction with error ${errorParser(error)}`)
        displayErrorModal(intl.formatMessage({
            id: "content.consoleMessages.consoleAuthorizationFailed",
            defaultMessage: en["content.consoleMessages.consoleAuthorizationFailed"]
        }))
    }
    return returnValue
}

interface IHandleConsoleSwitch {
    currentSession: IConsoleSession
    newConnectionType: EConnectionType
    newConnectionStatus: EConnectionState
    accessToken: string
    dispatch: Dispatch<any>
}

export const handleConsoleSwitch = async (props: IHandleConsoleSwitch) => {
    const { currentSession, newConnectionType, newConnectionStatus, accessToken, dispatch } = props
    let returnValue = ETransactionStatus.FAILED
    const { intl } = getIntlProvider()
    try {
        const { respStatus } = await consoleSwitchService({
            accessToken, contextId: currentSession.contextId,
            connectionStatus: newConnectionStatus, connectionType: newConnectionType
        })
        if (respStatus === HTTP_STATUS.OK) {
            const prevConnectionType = currentSession.connectionType
            infoLogger(`Successfully able to switch console session to ${newConnectionType} for contextId: ${currentSession.contextId}`)
            const newConsoleSession = { ...currentSession, connectionType: newConnectionType, connectionStatus: newConnectionStatus }
            dispatch(updateConsoleSession(newConsoleSession, true))
            const { requester, roomUuid } = currentSession
            trackConsoleSwitching({ prevConnectionType, newConnectionType, connectionMode: currentSession.connectionMode, requester, roomUuid })
            returnValue = ETransactionStatus.FINISHED
        } else {
            displayErrorModal(intl.formatMessage({
                id: "content.consoleMessages.consoleConnectionFailed",
                defaultMessage: en["content.consoleMessages.consoleConnectionFailed"]
            }))
            errorLogger(`Failed to perform console switch for contextId: ${currentSession.contextId}`)
        }
    } catch (error) {
        errorLogger(`Failed to perform console switch with error ${errorParser(error)}`)
        displayErrorModal(intl.formatMessage({
            id: "content.consoleMessages.consoleConnectionFailed",
            defaultMessage: en["content.consoleMessages.consoleConnectionFailed"]
        }))
    }
    return returnValue
}

interface ICCDisconnect {
    currentSession: IConsoleSession
    dispatch: Dispatch<any>
    currentUser: IUserInfo
    componentName: string
}

export const handleCCDisconnect = async (props: ICCDisconnect) => {
    const { currentSession, currentUser, dispatch, componentName } = props
    const { intl } = getIntlProvider()
    let returnValue = ETransactionStatus.FAILED
    try {
        const { contextId, roomUuid, consoleStartTime, connectionType, connectionMode } = currentSession
        const params = {
            accessToken: currentUser.accessToken, contextId,
            shouldUpdateForceDelete: true, connectionMode
        }
        const disconnectStatus = await disconnectConsoleService(params)
        if (disconnectStatus === HTTP_STATUS.NO_CONTENT) {
            const trackParam = { connectionType, connectionMode, roomUuid, consoleStartTime, requester: currentUser.uuid, componentName }
            trackConsoleDisconnection(trackParam)
            handleConsoleTransition({ transactionStatus: TransactionValue.DISCONNECTING, dispatch, currentSession })
            infoLogger(`UUID: ${currentUser.uuid} Successfully disconnected ${getTrackingEvent(connectionType)} Console Connection: ${disconnectStatus}`)
            returnValue = ETransactionStatus.FINISHED
        } else if (disconnectStatus === HTTP_STATUS.ALREADY_REPORTED) {
            warningLogger(`Context Id ${contextId} is already reported for disconnection.`)
            returnValue = ETransactionStatus.RUNNING
        } else {
            currentSession.connectionStatus = EConnectionState.DISCONNECTFAILURE
            dispatch(updateConsoleSession(currentSession, true))
            displayErrorModal(intl.formatMessage({
                id: "content.consoleMessages.consoleDisconnectionFailed",
                defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
            }))
            errorLogger(`UUID: ${currentUser.uuid} ApiStatus: Error while disconnecting from console: ${disconnectStatus}`)
        }
    } catch (error: any) {
        errorLogger(`Failed to disconnect the command center connection for user: ${currentUser.uuid} with error ${errorParser(error)}`)
        displayErrorModal(intl.formatMessage({
            id: "content.consoleMessages.consoleDisconnectionFailed",
            defaultMessage: en["content.consoleMessages.consoleDisconnectionFailed"]
        }))
    }
    return returnValue
}

export const handleCCDisconnectAll = async (props: { consoleSessions: IConsoleSession[], currentUser: IUserInfo, dispatch: Dispatch<any>, componentName: string }) => {
    const { consoleSessions, currentUser, dispatch, componentName } = props

    const disconnectionStatusMap = await Promise.all(consoleSessions.map(async (session: IConsoleSession) => {
        try {
            const { contextId, connectionMode } = session
            const params = {
                accessToken: currentUser.accessToken, contextId,
                shouldUpdateForceDelete: true, connectionMode
            }
            const disconnectStatus = await disconnectConsoleService(params)

            return { session, disconnectStatus }
        } catch (error: any) {
            errorLogger(`Failed to disconnect the command center connection for user: ${currentUser.uuid} with error ${errorParser(error)}`)

        }
        return { session, disconnectStatus: HTTP_STATUS.INTERNAL_SERVER_ERROR }
    }))

    disconnectionStatusMap.forEach(({ session, disconnectStatus }) => {
        const { roomUuid, consoleStartTime, connectionType, connectionMode } = session

        if (disconnectStatus >= 200 && disconnectStatus <= 299) {
            const trackParam = { connectionType, connectionMode, roomUuid, consoleStartTime, requester: currentUser.uuid, componentName }
            trackConsoleDisconnection(trackParam)
            infoLogger(`UUID: ${currentUser.uuid} Successfully disconnected ${getTrackingEvent(connectionType)} Console Connection: ${disconnectStatus}`)
        } else {
            session.connectionStatus = EConnectionState.DISCONNECTFAILURE
            dispatch(updateConsoleSession(session, true))
            errorLogger(`UUID: ${currentUser.uuid} ApiStatus: Error while disconnecting from console: ${disconnectStatus}`)
        }
    })

    if (disconnectionStatusMap.every(({ disconnectStatus }) => disconnectStatus === HTTP_STATUS.NO_CONTENT)) {
        handleConsoleTransition({ transactionStatus: TransactionValue.DISCONNECTING_ALL, dispatch })
        return ETransactionStatus.FINISHED
    }

    return ETransactionStatus.FAILED
}

interface IHandleConsoleTransition {
    transactionStatus: TransactionValue | ETransactionStatus
    dispatch: Dispatch<any>
    currentSession?: IConsoleSession
    suspendedTransactions?: IConsoleTransaction[]
}

export const handleConsoleTransition = (props: IHandleConsoleTransition) => {
    const { transactionStatus, dispatch, currentSession, suspendedTransactions } = props
    switch (transactionStatus) {
        case TransactionValue.CONNECTING:
        case TransactionValue.ASSOCIATE_COMPLETED:
            /** Handle Transition complete scenario */
            if (currentSession) {
                handleTransitionConnectionState(currentSession, dispatch)
            }
            break
        case TransactionValue.DISCONNECTING:
            /** Handle Transaction disconnect scenario */
            if (currentSession) {
                handleTransitionDisconnectionState(currentSession, dispatch)
            }
            break
        case TransactionValue.DISCONNECTING_ALL:
            handleTransitionDisconnectionAllState(dispatch)
            break
        case ETransactionStatus.FAILED:
        case ETransactionStatus.TIMEOUT:
        case ETransactionStatus.CANCELLED:
        case ETransactionStatus.REJECTED:
            /** Handle cleanup scenario */
            handleConsleSessionCleanUp(dispatch, suspendedTransactions || [], transactionStatus)
            break
        default:
    }
}

export const handleSuspendedStates = () => {
    const state = store.getState()
    const { consoleOperation, consoleSessions } = state.consoleReducer
    const { currentUser } = state.externalReducer
    const { transactions } = consoleOperation
    const suspendedTransactions = transactions.filter(transaction => transaction.transactionStatus === ETransactionStatus.SUSPENDED && transaction.connectionStatus === TransactionValue.STOP_EMERALD_APP)
    if (suspendedTransactions.length) {
        const { roomUuid, contextId, connectionStatus } = suspendedTransactions[0]
        handleAppUri({
            roomUuid: roomUuid, connectionState: connectionStatus, contextId,
            consoleSessions, accessToken: currentUser.accessToken
        })
    }
}

export const handleTransitionConnectionState = (currentSession: IConsoleSession, dispatch: Dispatch<any>) => {
    const { consoleSessions } = store.getState().consoleReducer
    const prevSessionIndex = consoleSessions.findIndex(session => session.connectionStatus === EConnectionState.IN_TRANSITION_STATE && session.roomUuid === currentSession.roomUuid)
    if (prevSessionIndex > -1) {
        if (currentSession.connectionType === EConnectionType.FULL_CONTROL) {
            const prevSession = consoleSessions[prevSessionIndex]
            currentSession.additionalData = { ...currentSession.additionalData, prevSessionDetails: { connectionType: prevSession.connectionType } }
        }
        consoleSessions[prevSessionIndex] = { ...currentSession, mediaRoomDetails: consoleSessions[prevSessionIndex].mediaRoomDetails }
        dispatch(resetConsoleSession({ consoleSessions: [...consoleSessions], updateActiveTab: false }))
    } else {
        dispatch(updateConsoleSession(currentSession, true))
    }
}

export const handleTransitionDisconnectionState = (currentSession: IConsoleSession, dispatch: Dispatch<any>) => {
    const { consoleSessions, consoleOperation } = store.getState().consoleReducer
    const { transactions } = consoleOperation
    if (checkTransactionForRoomAndState(transactions, currentSession.roomUuid, [TransactionValue.DISCONNECTING], ETransactionStatus.FINISHED)) {
        dispatch(updateConsoleSession(currentSession, false))
    } else {
        const currentSessionIndex = consoleSessions.findIndex(session => session.contextId === currentSession.contextId)
        if (currentSessionIndex > -1) {
            if (checkTransactionForRoomAndState(transactions, currentSession.roomUuid, [TransactionValue.CONNECTING, TransactionValue.ASSOCIATE_COMPLETED], ETransactionStatus.WAITING)) {
                consoleSessions[currentSessionIndex].connectionStatus = EConnectionState.IN_TRANSITION_STATE
                dispatch(updateConsoleSession(consoleSessions[currentSessionIndex], true, false))
            } else {
                dispatch(updateConsoleSession(currentSession, false))
            }
        }

    }
}

export const handleTransitionDisconnectionAllState = (dispatch: Dispatch<any>) => {
    dispatch(resetConsoleSession({ consoleSessions: [] }))
}

export const handleConsleSessionCleanUp = (dispatch: Dispatch<any>, suspendedTransactions: IConsoleTransaction[], transactionStatus: ETransactionStatus) => {
    const { consoleSessions, consoleOperation } = store.getState().consoleReducer
    /**
     * Check if any connection is present with inTransition state
     * Check for any transaction in Disconnecting state and not equal to FULL_CONTROL
     */
    const activeSessionInTransition = consoleSessions.find(session => session.connectionStatus === EConnectionState.IN_TRANSITION_STATE)
    if (activeSessionInTransition) {
        // Check if there is any transaction in disconnecting state
        const { roomUuid, receiverName, connectionMode, connectionType } = activeSessionInTransition
        const disconnectedTransaction = consoleOperation.transactions.find(transaction =>
            transaction.roomUuid === roomUuid && transaction.connectionStatus === TransactionValue.DISCONNECTING &&
            transaction.connectionType !== EConnectionType.FULL_CONTROL && transaction.transactionStatus === ETransactionStatus.FINISHED)
        if (disconnectedTransaction) {
            const transactions = getNormalConsoleTransactions(roomUuid, receiverName, connectionMode, connectionType)
            if (suspendedTransactions.length) {
                transactions.unshift(...suspendedTransactions)
            }
            dispatch(setConsoleOperations({ operationId: generateUniqueId(), operationStatus: EOperationStatus.RUNNING, transactions }))
            displayEditToViewSwitchMessage()
            return
        }
    }
    const activeSessions = consoleSessions.filter(session => session.connectionStatus !== EConnectionState.IN_TRANSITION_STATE)
    dispatch(resetConsoleSession({ consoleSessions: activeSessions, isFailed: transactionStatus === ETransactionStatus.FAILED, updateActiveTab: false }))
    dispatch(setConsoleOperations(DEFAULT_CONSOLE_OPERATIONS))
}

export const getCurrentConsoleSession = (consoleSessions: IConsoleSession[], contextId: string) => {
    return consoleSessions.find(consoleSession => consoleSession.contextId === contextId)
}

interface ICheckConsoleStatus {
    consoleSessions: IConsoleSession[]
    consoleOperation: IConsoleOperation
    roomUuid: string
    connectionType: EConnectionType
    protocolTransferStatus: boolean
}

export const getViewOrPMConsoleStatus = (props: ICheckConsoleStatus) => {
    const { consoleSessions, consoleOperation, roomUuid, connectionType, protocolTransferStatus } = props
    let loading = false
    let disabled = false
    let connectionState = false
    const { operationStatus, transactions } = consoleOperation
    /**
     * 1. Check if console inprogress is going on
     * 2. Check if inprogress console is going on with current room and if it matches with the requester console connection type
     * 3. Decide connection state depending on whether console session has started or not
     */
    if (operationStatus !== EOperationStatus.IDLE && transactions.length) {
        disabled = true
        if (fetchActiveTransactionForRoomAndConnectionType(transactions, roomUuid, connectionType)) {
            loading = true
        }
    }
    const consoleSession = consoleSessions.find(session => session.roomUuid === roomUuid)
    if (consoleSession?.connectionType === connectionType) {
        connectionState = true
    } else if (consoleSession && getConnectionPrecedence(consoleSession.connectionType) > getConnectionPrecedence(connectionType)) {
        disabled = true
    } else {
        //sonar fix
    }

    if (protocolTransferStatus) {
        disabled = true
    }

    return { connectionState, loading, disabled }
}

interface IResumeConsoleStatus {
    consoleOperation: IConsoleOperation
    roomUuid: string
    workflows: IWorkflowInfo[]
}

export const getResumeConsoleStatus = (props: IResumeConsoleStatus) => {
    const { consoleOperation, roomUuid, workflows } = props
    let loading = false
    let disabled = false
    const { operationStatus, transactions } = consoleOperation
    if ((operationStatus !== EOperationStatus.IDLE && transactions.length) || workflows.length) {
        disabled = true
    }
    const activeWorkflow = workflows.find(workflow => {
        const { prevSessionDetails, nextSessionDetails } = workflow.state.context as ParkAndResumeContext
        return workflow.type === ERoccWorkflow.PARK_AND_RESUME && ([prevSessionDetails.contactUuid, nextSessionDetails.contactUuid].includes(roomUuid))
    })
    if (activeWorkflow) {
        loading = true
    }
    return { disabled, loading, connectionState: false }

}

interface ICheckEditConsoleStatus {
    consoleSessions: IConsoleSession[]
    consoleOperation: IConsoleOperation
    roomDetails: IRoomDetails
    connectionType: EConnectionType
    protocolTransferStatus: boolean
    workflows: IWorkflowInfo[]
}


export const getEditConsoleStatus = (props: ICheckEditConsoleStatus) => {
    const { receivers } = store.getState().consoleReducer.commandCenterDetails.commandCenterSeat
    const { consoleSessions, consoleOperation, roomDetails, connectionType, protocolTransferStatus, workflows } = props
    const { uuid } = roomDetails.identity
    const { AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, ASSOCIATE_COMPLETED } = TransactionValue
    let loading = false
    let disabled = false
    let connectionState = false
    let requestCancelState = false
    const { operationStatus, transactions } = consoleOperation

    if (operationStatus !== EOperationStatus.IDLE && transactions.length) {
        disabled = true
        const activeTransaction: any = fetchActiveTransactionForRoomAndConnectionType(transactions, uuid, connectionType)
        if (activeTransaction) {
            loading = true
            if (
                activeTransaction.transactionStatus === ETransactionStatus.RUNNING &&
                [AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, ASSOCIATE_COMPLETED].includes(activeTransaction.connectionStatus)
            ) {
                requestCancelState = true
            }
        }
    }

    const activeEditValue = checkForActiveEditSession(consoleSessions, uuid, connectionType)
    disabled = activeEditValue.disabled || disabled
    connectionState = activeEditValue.connectionState


    loading = checkForActiveEditWorkflow(workflows, uuid) || loading

    if (protocolTransferStatus || (roomDetails.additionalAttributes?.ncc_edit === false && receivers.length === 0)) {
        disabled = true
    }
    if (disabled && requestCancelState) {
        disabled = false
    }

    return { connectionState, loading, disabled, requestCancelState }
}

export const checkForActiveEditWorkflow = (workflows: IWorkflowInfo[], roomUuid: string) => {
    return !!workflows.find(workflow => {
        return TRACKED_CONSOLE_WORKFLOWS.includes(workflow.type)
            && (getRoomUuidsFromWorkflowContext(workflow.state.context).includes(roomUuid))
    })

}

const checkForActiveEditSession = (consoleSessions: IConsoleSession[], roomUuid: string, connectionType: EConnectionType) => {
    let connectionState = false
    let disabled = false
    const editConsoleType = fetchAllEditConsoleType()

    const activeEditSessions = consoleSessions.filter(session => editConsoleType.includes(session.connectionType))
    if (activeEditSessions.length) {
        let isSessionForSameRoom = false
        let isSessionOfSameConnectionType = false
        activeEditSessions.forEach(session => {
            if (session.roomUuid === roomUuid) isSessionForSameRoom = true
            if (session.connectionType === connectionType) isSessionOfSameConnectionType = true
        })
        const editState = getEditStatesFromCurrentSession(isSessionForSameRoom, isSessionOfSameConnectionType)
        disabled = editState.disabled
        connectionState = editState.connectionState

    }

    return { disabled, connectionState }
}

const getEditStatesFromCurrentSession = (isSessionForSameRoom: boolean, isSessionOfSameConnectionType: boolean) => {
    let connectionState = false
    let disabled = false
    if (isSessionForSameRoom && isSessionOfSameConnectionType) {
        connectionState = true
    } else if (isSessionForSameRoom && !isSessionOfSameConnectionType) {
        disabled = true
    } else {
        if (!checkIfMultiEditFeatureExist()) {
            disabled = true
        }
    }
    return { connectionState, disabled }
}

export const getConnectionPrecedence = (connectionType: EConnectionType) => {
    const { INCOGNITO_VIEW, VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT, FULL_CONTROL_USB } = EConnectionType
    switch (connectionType) {
        case INCOGNITO_VIEW: return 0
        case VIEW: return 1
        case FULL_CONTROL: return 2
        case FULL_CONTROL_USB: return 3
        case PROTOCOL_MANAGEMENT: return 4
        default: return -1
    }
}

interface IHandleAuthorization {
    consoleSessions: IConsoleSession[]
    roomUuid: string
    componentName: string
    connectionMode: EConnectionMode
    receiverName: string
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
    featureFlags?: any
    connectionType: EConnectionType
}


interface IHandleConsoleSessionDisconnect {
    roomUuid: string
    componentName: string
    connectionMode: EConnectionMode
}

interface IHandleToggleCallControl {
    callContextId: string
    roomUuid: string
    toggles: Partial<Record<'muteStatus' | 'deafenStatus', boolean>>
    componentName: string
}

interface IHandleCallDisconnect {
    callContextId: string
    componentName: string
}

export const handleStartEditingWrapper = (props: IHandleAuthorization) => {
    if (checkToAllowMultiEdit()) {
        registerMultiEditWorkflow(props)
    } else if (checkToAllowParkResume()) {
        registerSeamlessEditWorkflow(props)
    } else {
        handleAuthorisation(props)
    }
}

export const handleAuthorisation = ({ consoleSessions, roomUuid, componentName, dispatch, connectionMode, receiverName, postTransactionHook, connectionType }: IHandleAuthorization) => {
    /**
     * A. If Edit Console:
     *       1. Check if call is already going on
     *       2. If yes, then below events
     *              i. Disconnect existing session
     *              ii. Establish edit console session / request
     *      3. If no, then add below events
     *              i. Call Wait
     *              ii. Disconnect existing console session
     *              iii. Establish edit console session / request
     * B. If Edit or View:
     *      1. Disconnect existing active session / request
     *      2  Add transactions to list 
     *      3. Establish console request
     * 
     */
    const { currentUser } = store.getState().externalReducer
    const message = messageViewToEdit()
    const switchEventList: IConsoleTransaction[] = []
    const transactionId = generateUniqueId()
    const groupId = generateUniqueId()
    if (connectionType === EConnectionType.FULL_CONTROL) {
        if (!hasActiveVidoCallWithRoom(roomUuid)) {
            const callOperation: IConsoleTransaction = {
                transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType: EConnectionType.FULL_CONTROL, transactionId,
                connectionMode, connectionStatus: TransactionValue.AV_CALL_WAIT, receiverName, groupId,
            }
            sendLogsToAzure({ contextData: { event: "Switching from view console to edit console" } })
            sendLogsToAzure({ contextData: { component: COMPONENT_NAME, event: "Web to Web Call: Call Initiated", source: "RoomTab : Start Editing", Call_To: roomUuid, Call_From: currentUser.uuid } })
            dispatchToParentStore({
                type: GLOBAL_SET_INITIATE_WEB_CALL, payload: {
                    initiateWebCall: { contactUuid: roomUuid, componentName },
                }
            })
            switchEventList.push(callOperation)
        } else {
            message.splice(1, 1)
        }
    }
    const {
        activeTransactionToDisconnect, isActiveSessionWithSameRoom,
    } = fetchActiveSessionToBeDisconnected(consoleSessions, receiverName, roomUuid, connectionMode)

    switchEventList.push(
        ...activeTransactionToDisconnect,
        ...getConsoleTransactions(roomUuid, receiverName, connectionMode, groupId, connectionType)
    )

    dispatch(setConsoleOperations({
        operationId: generateUniqueId(),
        operationStatus: EOperationStatus.RUNNING,
        transactions: switchEventList,
        postTransactionHook,
    }))

    if (isActiveSessionWithSameRoom && connectionType === EConnectionType.FULL_CONTROL) {
        const customStyle = { top: "1rem", right: "1rem", width: "29.25rem", height: message.length > 1 && "18.063rem" }
        displayNotificationMessage(message, customStyle, false, true, false)
    }
}


interface IHandleConsoleConfirm {
    consoleSessions: IConsoleSession[]
    receiverName: string
    roomUuid: string
    connectionType: EConnectionType
    connectionMode: EConnectionMode
    dispatch: Dispatch<any>
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
    featureFlags?: any

}

export const initiateNormalConsoleSession = (props: IHandleConsoleConfirm) => {
    /**
     * if feature flag [ROCC_VIEW_AUTHORIZATION] is enabled need to raise console request
     * else start view console
     */
    const { featureFlags } = store.getState().externalReducer
    if (!!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_VIEW_AUTHORIZATION) && props.connectionType === EConnectionType.VIEW) {
        handleAuthorisation({ ...props, componentName: "" })
    } else {
        const { consoleSessions, connectionType, roomUuid, receiverName, dispatch, connectionMode, postTransactionHook } = props
        const {
            activeTransactionToDisconnect,
        } = fetchActiveSessionToBeDisconnected(consoleSessions, receiverName, roomUuid, connectionMode)
        const newConsoleTransactionDetails = getNormalConsoleTransactions(roomUuid, receiverName, connectionMode, connectionType)

        const transactions = [...activeTransactionToDisconnect, ...newConsoleTransactionDetails]
        dispatch(setConsoleOperations({ operationId: generateUniqueId(), operationStatus: EOperationStatus.RUNNING, transactions, postTransactionHook }))
    }
}

interface IConsoleSwitch {
    currentSession: IConsoleSession
    newConnectionType: EConnectionType
    transactionState: TransactionValue
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
    dispatch: Dispatch<any>
}

export const initiateConsoleSwitchOperation = (props: IConsoleSwitch) => {
    const { postTransactionHook, currentSession, newConnectionType, transactionState, dispatch } = props
    const { roomUuid, receiverName, connectionMode, contextId } = currentSession
    const groupId = generateUniqueId()
    const transactions = [generateTransactionObject(roomUuid, newConnectionType, connectionMode, transactionState, receiverName, groupId, contextId)]
    dispatch(setConsoleOperations({
        operationId: generateUniqueId(),
        operationStatus: EOperationStatus.RUNNING,
        postTransactionHook,
        transactions,
    }))
}

interface IDisconnectAllConsoleSessions {
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
    dispatch: Dispatch<any>
}

export const disconnectAllConsoleSessions = (props: IDisconnectAllConsoleSessions) => {
    const { postTransactionHook, dispatch } = props
    const { consoleSessions } = store.getState().consoleReducer
    if (!consoleSessions.length) {
        postTransactionHook?.(true)
        return
    }
    const { connectionMode, connectionType } = consoleSessions[0]

    const transactions = [
        generateTransactionObject("", connectionType, EConnectionMode.EMERALD, TransactionValue.STOP_ALL_EMERALD_APP, "", generateUniqueId()),
        generateTransactionObject("", connectionType, connectionMode, TransactionValue.DISCONNECTING_ALL, "", generateUniqueId())

    ]
    dispatch(setConsoleOperations({
        operationId: generateUniqueId(),
        operationStatus: EOperationStatus.RUNNING,
        postTransactionHook,
        transactions,
    }))
}

export const handleConsoleConfirmation = (props: IHandleConsoleConfirm) => {
    hideNotificationModal()
    if (props.connectionType === EConnectionType.FULL_CONTROL) {
        handleStartEditingWrapper({ ...props, componentName: "" })
    } else {
        initiateNormalConsoleSession({ ...props })
    }
}

interface IReceiverUseConfirmation extends IPerformConsoleConnectionOps {
    handleConsoleConfirmation : () => {}
}

export const onReceiverUseConfirmation = (props : IReceiverUseConfirmation) =>{
    console.log("prathik: onReceiverUseConfirmation is called in console app")
    if (props.receivers.length == 1){
        console.log("prathik: onReceiverUseConfirmation handleSingleReceiverAdapterResponse  is called in console app")
        handleSingleReceiverAdapterResponse(props)
    }else{
        console.log("prathik: onReceiverUseConfirmation handleMultipleReceiverAdapterResponse  is called in console app")
        handleMultipleReceiverAdapterResponse(props)
    }
}

export const handleSingleReceiverAdapterResponse = (props: IPerformConsoleConnectionOps) =>{
    const { consoleSessions, receivers } = props
    const receiverName = receivers[0].receiverName
    const activeSession = fetchActiveSessionForReceiver(consoleSessions, receiverName)
    props.selectedReceiver = receiverName
    const notificationModal = getNotificationModalInfo(activeSession, props)
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
    console.log("prathik: handleSingleReceiverAdapterResponse  is call is completed in console app")
}

const handleSingleReceiver = (props: IPerformConsoleConnectionOps) => {
    /**
     * 1. Chcek if receiver is in use
     * 2. If yes, then display a modal pop-up foe the confirmation
     * 3. If no, then start the console session
     */
    const { roomUuid, connectionType, consoleSessions, receivers } = props
    const receiverName = receivers[0].receiverName
    const activeSession = fetchActiveSessionForReceiver(consoleSessions, receiverName)
    if (activeSession && activeSession.roomUuid !== roomUuid) {
        props.selectedReceiver = receiverName
        const notificationModal = getNotificationModalInfo(activeSession, props)
        dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
    } else {
        if (connectionType === EConnectionType.FULL_CONTROL) {
            handleStartEditingWrapper({ ...props, connectionMode: EConnectionMode.CC, receiverName, componentName: "", connectionType })
        } else {
            initiateNormalConsoleSession({ ...props, receiverName })
        }
    }
}

const getNotificationModalInfo = (activeSession: IConsoleSession, props: IPerformConsoleConnectionOps) => {
    const { intl } = getIntlProvider()
    const { roomUuid, connectionType } = props
    const receiverName = props.selectedReceiver || ""
    const rooms = store.getState().externalReducer.rooms
    const oldRoomDetail = rooms.find((room) => room.roomUuid === activeSession.roomUuid)
    const oldRoomName = oldRoomDetail ? oldRoomDetail.roomName : INIT_ROOM_INFO.roomName
    const newRoomDetail = rooms.find((room) => room.roomUuid === roomUuid)
    const newRoomName = newRoomDetail ? newRoomDetail.roomName : INIT_ROOM_INFO.roomName
    const notificationModal = {
        showModal: true,
        header: "",
        modalContent: getRoomSwitchMessage(activeSession, connectionType, intl, oldRoomName, newRoomName),
        actionButton1Text: intl.formatMessage({ id: "content.yes.btn", defaultMessage: en["content.yes.btn"] }),
        actionButton2Text: intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
        buttonDirection: EButtonDirection.RIGHT,
        actionButton1Onclick: () => {
            hideNotificationModal()
            getConnectionAdapter().handleConsoleConfirmation({ ...props, receiverName })},
        actionButton2Onclick: () => hideNotificationModal(),
        modalStyles: "singleMonitorRoomSwitch"
    }
    return notificationModal
}

export const consoleRequestTimeout = (currentOperationId: string, dispatch: any) => {
    const state: IStore = store.getState()
    const consoleOperation = state.consoleReducer.consoleOperation
    const { operationId, operationStatus } = consoleOperation
    if (operationId === currentOperationId && operationStatus === EOperationStatus.RUNNING) {
        // Operation is still going on, so close that and clear the transaction
        consoleOperation.operationStatus = EOperationStatus.TIMEOUT
        dispatch(setConsoleOperations({ ...consoleOperation }))
        const transaction = consoleOperation.transactions[0]
        infoLogger(`${transaction.connectionType} console request with contextId ${transaction.contextId} 
         for the roomUuid  ${transaction.roomUuid}  has timed out`)
    }
}

const getRoomSwitchMessage = (activeSession: IConsoleSession, connectionType: EConnectionType, intl: any, activeSessionRoomName: string, newRoomName: string) => {
    const viewing = `${intl.formatMessage({ id: "content.banner.viewing", defaultMessage: en["content.banner.viewing"] })}`
    const editing = `${intl.formatMessage({ id: "content.banner.editing", defaultMessage: en["content.banner.editing"] })}`
    const message = `${intl.formatMessage({
        id: "content.consoleMessages.confirmMessageForViewConsolePart1",
        defaultMessage: en["content.consoleMessages.confirmMessageForViewConsolePart1"]
    })} ${activeSession.connectionType === "FULL_CONTROL" ? editing : viewing} <b>${activeSessionRoomName}</b>${intl.formatMessage({
        id: "content.consoleMessages.confirmMessageForViewConsolePart2",
        defaultMessage: en["content.consoleMessages.confirmMessageForViewConsolePart2"]
    })} ${connectionType === "FULL_CONTROL" ? editing : viewing} <b>${newRoomName}</b>?`
    return (
        <div dangerouslySetInnerHTML={{ __html: message }} />
    )
}

export const handleMultipleReceiverAdapterResponse = (props: IPerformConsoleConnectionOps) => {
    const { roomUuid, connectionType, consoleSessions, selectedReceiver, receivers, setReceiverSelectionModal } = props
    const { intl } = getIntlProvider()
    const activeConsoleSession = consoleSessions.find(session => session.receiverName === selectedReceiver)
    const rooms = store.getState().externalReducer.rooms
    let oldRoomDetail = rooms.find((room) => room.roomUuid === activeConsoleSession.roomUuid)
    oldRoomDetail = oldRoomDetail ? oldRoomDetail : INIT_ROOM_INFO
    let newRoomDetail = rooms.find((room) => room.roomUuid === roomUuid)
    newRoomDetail = newRoomDetail ? newRoomDetail : INIT_ROOM_INFO
    const receiver = receivers.find((receiver) => receiver.receiverName === selectedReceiver)
    const monitorName = receiver ? receiver.monitorName : ""
    const notificationModal = {
        header: getHeaderForCC(monitorName),
        showModal: true,
        modalContent: getActiveSessionMessageForCC(monitorName, newRoomDetail, oldRoomDetail),
        showCloseIcon: false,
        actionButton1Onclick: () => {
            hideNotificationModal()
            getConnectionAdapter().handleConsoleConfirmation({ ...props, receiverName: selectedReceiver })}
            ,
        actionButton2Onclick: () => setReceiverSelectionModal?.({ showReceiverModal: true, connectionType: connectionType }),
        actionButton1Text: intl.formatMessage({ id: "content.consoleSession.startNewSessionBtn", defaultMessage: en["content.consoleSession.startNewSessionBtn"] }),
        actionButton2Text: intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
        modalStyles: "activeSessionOnSelectedMonitor"
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
    console.log("prathik: handleMultipleReceiverAdapterResponse  is call is completed in console app")
}

export const handleMultipleReceiver = (props: IPerformConsoleConnectionOps) => {
    const { roomUuid, connectionType, consoleSessions, selectedReceiver, receivers, setReceiverSelectionModal, dispatch } = props
    if (selectedReceiver && checkIfReceiverInUse(consoleSessions, selectedReceiver)) {
        const activeConsoleSession = consoleSessions.find(session => session.receiverName === selectedReceiver)
        const rooms = store.getState().externalReducer.rooms
        if (activeConsoleSession && rooms) {
            const { intl } = getIntlProvider()
            let oldRoomDetail = rooms.find((room) => room.roomUuid === activeConsoleSession.roomUuid)
            oldRoomDetail = oldRoomDetail ? oldRoomDetail : INIT_ROOM_INFO
            let newRoomDetail = rooms.find((room) => room.roomUuid === roomUuid)
            newRoomDetail = newRoomDetail ? newRoomDetail : INIT_ROOM_INFO
            const receiver = receivers.find((receiver) => receiver.receiverName === selectedReceiver)
            const monitorName = receiver ? receiver.monitorName : ""
            const notificationModal = {
                header: getHeaderForCC(monitorName),
                showModal: true,
                modalContent: getActiveSessionMessageForCC(monitorName, newRoomDetail, oldRoomDetail),
                showCloseIcon: false,
                actionButton1Onclick: () => handleConsoleConfirmation({ ...props, receiverName: selectedReceiver }),
                actionButton2Onclick: () => setReceiverSelectionModal({ showReceiverModal: true, connectionType: connectionType }),
                actionButton1Text: intl.formatMessage({ id: "content.consoleSession.startNewSessionBtn", defaultMessage: en["content.consoleSession.startNewSessionBtn"] }),
                actionButton2Text: intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
                modalStyles: "activeSessionOnSelectedMonitor"
            }
            dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
        }
    } else {
        const receiverName = selectedReceiver ? selectedReceiver : ""
        if (connectionType === EConnectionType.FULL_CONTROL) {
            handleStartEditingWrapper({ consoleSessions, roomUuid, dispatch, componentName: "", receiverName, connectionMode: EConnectionMode.CC, connectionType })
        } else {
            initiateNormalConsoleSession({ ...props, receiverName })
        }
    }
}

export const handleCCConnection = (props: IPerformConsoleConnectionOps) => {
    /** Check the number of receivers */
    switch (props.receivers.length) {
        case 0:
            infoLogger(`Receives are not available for this command centre.`)
            break
        case 1:
            /** handle Single receiver connection */
            handleSingleReceiver({ ...props })
            break
        default:
            handleMultipleReceiver({ ...props })
    }
}

const getQualifyHeader = () => {
    const { intl } = getIntlProvider()
    return (
        <>
            <div className="qualifyHeader">
                {intl.formatMessage({ id: "content.consoleMessages.qualifyEditingHeader", defaultMessage: en["content.consoleMessages.qualifyEditingHeader"] })}
            </div>
        </>
    )
}

const getQualifyContent = (roomDetails: IRoomDetails) => {
    const { intl } = getIntlProvider()
    const configs = fetchGlobalConfigs()
    return <div className="qualifyContent">
        <Grid>
            <Grid.Row stretched={true}>
                <Grid.Column className="qualifyContentContactMessage">
                    {intl.formatMessage({ id: "content.consoleMessages.qualifyEditingMessage1", defaultMessage: en["content.consoleMessages.qualifyEditingMessage1"] })}
                </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched={true}>
                <Grid.Column className="qualifyContentContact">
                    <i className="icon big Support" />
                </Grid.Column>
                <Grid.Column className="qualifyContentContact" width={10}>
                    <span>
                        <a
                            className="qualifyContentContactNumber">
                            {/* onClick={() => makeHelpLineCall(dispatch)}> */}
                            {configs.ROCC_HELPLINE}
                        </a>
                    </span>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched={true}>
                <Grid.Column className="qualifyContentContactMessage">
                    {intl.formatMessage({ id: "content.consoleMessages.qualifyEditingMessage2", defaultMessage: en["content.consoleMessages.qualifyEditingMessage2"] })}
                </Grid.Column>
            </Grid.Row>
            <Grid.Row stretched={true}>
                <Grid.Column className="qualifyContentContactMessage">
                    <Checkbox
                        onChange={(_EVENT: any, data: CheckboxProps) => updateSpokeQualifiedCheckboxStatus(roomDetails, data.checked || false)}
                    />
                </Grid.Column>
                <Grid.Column className="qualifyContentConsent" width={10}>
                    {intl.formatMessage({ id: "content.consoleMessages.qualifyEditingConsent", defaultMessage: en["content.consoleMessages.qualifyEditingConsent"] })}
                </Grid.Column>
            </Grid.Row>
        </Grid>

    </div>
}

const getQualifyActionButton = () => {
    const { intl } = getIntlProvider()
    return (
        <>
            <SVG src={StartEditing} cacheRequests={true} className={"editingIcon editingQualifyIcon"} />
            {intl.formatMessage({
                id: "content.consoleMessages.startEditingUsingCC",
                defaultMessage: en["content.consoleMessages.startEditingUsingCC"]
            })}
        </>
    )
}

export const handleMaxLimitNFCCConnectionReached = (props: IPerformConsoleConnectionOps) => {
    // Used here
    const { consoleSessions, roomUuid } = props
    const rooms = fetchRooms()
    const roomDetails = getRoomDetailFromUuid(rooms, roomUuid)
    const { intl } = getIntlProvider()
    const activeSession = getActiveSessionsForConnectionMode(consoleSessions, EConnectionMode.EMERALD)
    if (getMaxNumAllowedNFCC() > 1) {
        const notificationModal = {
            showModal: true,
            header: "",
            modalContent: <div dangerouslySetInnerHTML={{ __html: getNFCCMaxlimitMessage(consoleSessions, rooms, roomDetails) }} />,
            actionButton1Text: intl.formatMessage({ id: "content.yes.btn", defaultMessage: en["content.yes.btn"] }),
            buttonDirection: EButtonDirection.RIGHT,
            actionButton1Onclick: hideNotificationModal,
            modalStyles: "errorModal"
        }
        dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
    } else if (getMaxNumAllowedNFCC() === 1) {
        if (activeSession) {
            const notificationModal = getNotificationModalInfo(activeSession, props)
            dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
        } else {
            //do nothing
        }

    } else {
        // do nothing
    }

}

export const handleNFCCConnection = (props: IPerformConsoleConnectionOps) => {
    const { roomUuid, connectionType, consoleSessions } = props
    const { currentUser } = store.getState().externalReducer
    const rooms = fetchRooms()
    const roomDetails = getRoomDetailFromUuid(rooms, roomUuid)
    if (connectionType === EConnectionType.FULL_CONTROL) {
        const { additionalAttributes } = roomDetails
        if (additionalAttributes?.ncc_edit !== false) {
            if (isMaximumNFCCLimitReached(consoleSessions, roomUuid)) {
                handleMaxLimitNFCCConnectionReached({ ...props, roomDetails })
            } else {
                handleAuthorisation({ ...props, receiverName: "" })
            }
        } else if (additionalAttributes?.is_ncc_warning_displayed) {
            // Call Cc Edit Handler to initiate edit connection
            ccEditConnectionHandler({ ...props, connectionMode: EConnectionMode.CC })
        } else {
            const notificationModal = {
                showModal: true,
                showCloseIcon: true,
                header: getQualifyHeader(),
                modalContent: getQualifyContent(roomDetails),
                actionButton1Text: getQualifyActionButton(),
                buttonDirection: EButtonDirection.RIGHT,
                actionButton1Onclick: () => {
                    hideNotificationModal()
                    ccEditConnectionHandler({ ...props, connectionMode: EConnectionMode.CC })
                    sendLogsToAzure({
                        contextData: { component: COMPONENT_NAME, event: `${transformSessionTypeForAnalytics(EConnectionMode.CC)} initiated`, source: transformSessionTypeForAnalytics(EConnectionMode.EMERALD), eventBy: currentUser.uuid, Call_To: roomDetails.identity.uuid, Call_From: currentUser.uuid, windowType: "popup" }
                    })
                },
                closeIcon: true,
                onClose: () => hideNotificationModal(),
                modalStyles: "spokeQualifyModal"
            }
            dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
            sendLogsToAzure({
                contextData: { component: COMPONENT_NAME, event: `${transformSessionTypeForAnalytics(EConnectionMode.EMERALD)} not qualified for edit popup`, source: transformSessionTypeForAnalytics(EConnectionMode.EMERALD), eventBy: currentUser.uuid, Call_To: roomDetails.identity.uuid, Call_From: currentUser.uuid }
            })
        }
    } else {
        if (isMaximumNFCCLimitReached(consoleSessions, roomUuid)) {
            handleMaxLimitNFCCConnectionReached({ ...props, roomDetails })
        } else {
            initiateNormalConsoleSession({ ...props, receiverName: "" })
        }
    }
}


export const ccEditConnectionHandler = (props: IPerformConsoleConnectionOps) => {
    const { roomUuid, receivers, dispatch, featureFlags, componentName, setReceiverSelectionModal, connectionType } = props
    const { consoleSessions } = store.getState().consoleReducer
    const activeSessionForRoom = fetchViewConsoleSessionForRoom(consoleSessions, roomUuid)
    if (activeSessionForRoom?.receiverName) {
        const props = {
            consoleSessions, roomUuid, componentName, dispatch, connectionMode: EConnectionMode.CC,
            receiverName: activeSessionForRoom.receiverName, connectionType
        }
        getConnectionAdapter().handleStartEdit(props)
    } else {
        checkIfMultiRoomIsDisabled(featureFlags, receivers) ?
        getConnectionAdapter().connect({ ...props, connectionMode: EModalityConnectionMode.KVM, subConnectionMode: EModalitySubConnectionMode.CC })
            : setReceiverSelectionModal?.({ showReceiverModal: true, connectionType: EConnectionType.FULL_CONTROL })
    }
}

interface IParkedConnectionHandler {
    currentSession: IConsoleSession
    consoleSessions: IConsoleSession[]
}

export const parkedConnectionHandler = (props: IParkedConnectionHandler) => {
    const { currentSession, consoleSessions } = props
    const { roomUuid, contextId } = currentSession
    const activeSession = consoleSessions.find(session => session.connectionType === EConnectionType.FULL_CONTROL)
    let prevSessionDetails = { contactUuid: "", consoleContextId: "", callContextId: "" }
    if (activeSession) {
        const { roomUuid, contextId, additionalData } = activeSession
        prevSessionDetails = { contactUuid: roomUuid, consoleContextId: contextId, callContextId: additionalData?.callContextId || "" }
    }
    const context = {
        prevSessionDetails,
        nextSessionDetails: {
            contactUuid: roomUuid,
            consoleContextId: contextId,
            callContextId: currentSession.additionalData?.callContextId || "",
        },
    }
    
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.PARK_AND_RESUME, context, } })
}

export const performConsoleConnectionOps = (props: IPerformConsoleConnectionOps) => {
    const { connectionMode, roomUuid } = props
    switch (connectionMode) {
        case EConnectionMode.CC:
            handleCCConnection({ ...props })
            break
        case EConnectionMode.EMERALD:
            checkIfUserHasCompatibleNFCCBundle(props)
            break
        default:
            infoLogger(`Selected connectionMode ${connectionMode} is not supported by Rocc`)
    }
    infoLogger(`RoomUUid : ${roomUuid}`)
}

export const fetchBackwardTransition = (currentSession: IConsoleSession, transactions: IConsoleTransaction[]) => {
    let isConsoleSwitching = false
    if (currentSession.additionalData?.prevSessionDetails?.connectionType) {
        isConsoleSwitching = true
        const { roomUuid, connectionMode, receiverName } = currentSession
        const prevConnectionType = currentSession.additionalData.prevSessionDetails.connectionType
        transactions.push(...getNormalConsoleTransactions(roomUuid, receiverName, connectionMode, prevConnectionType))
    }
    return isConsoleSwitching
}

export const getOnGoingEmeraldForRoom = (activeSessions: IConsoleSession[], roomUuid: string) => {
    return activeSessions.find(activeSession => activeSession.connectionMode === EConnectionMode.EMERALD && activeSession.roomUuid === roomUuid)
}

export const getConsoleTransactions = (roomUuid: string, receiverName: string, connectionMode: EConnectionMode, groupId: string, connectionType: EConnectionType) => {
    /**
     * Identify the Authorization Type
     * Depending on the Authorization Type, create suitable transactions
     * For normal authorization, we will create three transactions
     *  1. AUTHORIZATION_REQUESTING
     *  2. AUTHORIZATION_APPROVAL_WAIT
     *  3. CONNECTING
     *  4. SEND_CONNECTED_MESSAGE_TO_DEVICE
     */
    let transactions = [] as IConsoleTransaction[]
    const { AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, CONNECTING, ASSOCIATE_COMPLETED, SEND_CONNECTED_MESSAGE, UPDATE_SESSION, START_EMERALD_APP } = TransactionValue
    switch (connectionMode) {
        case EConnectionMode.CC:
            transactions = [AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, CONNECTING,
                ...(checkIfPresignedJwtFeatureEnabled() ? [SEND_CONNECTED_MESSAGE] : [])
            ].map(transaction =>
                generateTransactionObject(roomUuid, connectionType, EConnectionMode.CC, transaction, receiverName, groupId))
            break
        case EConnectionMode.EMERALD:
            // TODO: [MARKER] Check if SEND_MESSAGE is required
            transactions = [AUTHORIZATION_REQUEST, ASSOCIATE_COMPLETED, UPDATE_SESSION, START_EMERALD_APP].map(transaction =>
                generateTransactionObject(roomUuid, connectionType, EConnectionMode.EMERALD, transaction, receiverName, groupId))
            break
    }
    return transactions
}

export const getNormalConsoleTransactions = (
    roomUuid: string, receiverName: string, connectionMode: EConnectionMode, connectionType: EConnectionType
) => {
    const groupId = generateUniqueId()
    const transactions: IConsoleTransaction[] = [{
        transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType, connectionMode,
        connectionStatus: TransactionValue.CONNECTING, receiverName, transactionId: generateUniqueId(), groupId,
    }]
    if (connectionMode === EConnectionMode.EMERALD) {
        transactions.push({
            transactionStatus: ETransactionStatus.WAITING, roomUuid, connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.EMERALD,
            connectionStatus: TransactionValue.START_EMERALD_APP, receiverName, transactionId: generateUniqueId(), groupId,
        })
    }
    return transactions
}

export const handleAppUri = async (props: IHandleAppUri, previousContextId?: string | undefined) => {
    const { roomUuid, connectionState, consoleSessions, accessToken, contextId } = props
    const { STOP_EMERALD_APP, RESTART_EMERALD_APP, STOP_ALL_EMERALD_APP } = TransactionValue
    const activeSession = getOnGoingEmeraldForRoom(consoleSessions, roomUuid)
    let action = EMERALD_APP_URI_START
    let pid = 0
    const currentContextId = contextId || activeSession?.contextId || ""
    switch (connectionState) {

        case STOP_EMERALD_APP:
            action = EMERALD_APP_URI_STOP
            pid = getPidFromContextMapping(currentContextId)
            break
        case STOP_ALL_EMERALD_APP:
            action = EMERALD_APP_URI_STOP_ALL
            break
        case RESTART_EMERALD_APP:
            action = EMERALD_APP_URI_RESTART
            pid = getPidFromContextMapping(previousContextId)
            break
    }
    const { CONSOLE_SERVICES_URL } = fetchGlobalURLs()
    const uriConfigs = await constructAppUriConfigs(accessToken, DEFAULT_API_VERSION, action, pid, CONSOLE_SERVICES_URL, currentContextId, previousContextId)
    if (uriConfigs) {
        launchAppUri(action, uriConfigs)
    }
}

export const displayLoader = (inverted: boolean, content?: any) => {
    return (
        <CustomLoader
            content={content ? content : ""}
            inverted={inverted}
            customStyle={{ top: "400px" }}
            dimmer={true}
            inline={false}
            size={"medium"} />
    )
}

export const checkFeatureToggleAndCameraStreamAvailable = (featureFlags: any, flag: any, maxSupportedDeviceUSBCameras: string, deviceUSBCameraLimit: string, isCameraStreamAvailable: boolean, currentSession: IConsoleSession) => {
    const roomMonitoringWithCC = isRoomMonitoringEnabled(featureFlags) && currentSession.connectionMode === EConnectionMode.CC
    return checkMultiCameraFeature(FeatureFlagHelper.isFeatureEnabled(featureFlags, flag), roomMonitoringWithCC, maxSupportedDeviceUSBCameras, deviceUSBCameraLimit) && isCameraStreamAvailable
}

export const checkMultiCameraFeature = (consoleMultiCamera: boolean, roomMonitoring: boolean, maxSupportedDeviceUsbCameras: string, deviceUsbCamerasLimitForStreaming: string) => {
    return consoleMultiCamera && !roomMonitoring && parseIntBase10(maxSupportedDeviceUsbCameras) > 0 && parseIntBase10(deviceUsbCamerasLimitForStreaming) > 0
        && parseIntBase10(maxSupportedDeviceUsbCameras) <= MAX_SUPPORTED_MULTICAMERA_STREAMS && parseIntBase10(deviceUsbCamerasLimitForStreaming) <= MAX_SUPPORTED_MULTICAMERA_STREAMS
}

export const getEditSessionRevokedHeader = () => {
    const { intl } = getIntlProvider()
    return (
        <Modal.Header className={styles.modalHeader}>
            <Icon className={cx("icon ExclamationMarkCircle", styles.exclamationSymbol)} />
            <span className={styles.headerText}>
                {intl.formatMessage({ id: "content.consoleMessages.revokeConsoleHeader", defaultMessage: en["content.consoleMessages.revokeConsoleHeader"] })}
            </span>
        </Modal.Header>
    )
}

export const getEditSessionRevokedContent = async (roomUuid: string) => {
    const { intl } = getIntlProvider()
    const rooms = store.getState().externalReducer.rooms
    const activeRoomDetail = rooms.find((room) => room.roomUuid === roomUuid)
    let techName = ""
    let message = ""
    if (activeRoomDetail) {
        const { loggedInTech } = activeRoomDetail
        if (loggedInTech.techUuid !== "") {
            techName = loggedInTech.techName
        }

        message = `<b>${techName}</b> ${intl.formatMessage({ id: "content.consoleMessages.revokeConsoleMessage1", defaultMessage: en["content.consoleMessages.revokeConsoleMessage1"] })}
    <b>${activeRoomDetail.roomName}</b>${intl.formatMessage({ id: "content.consoleMessages.revokeConsoleMessage2", defaultMessage: en["content.consoleMessages.revokeConsoleMessage2"] })}
    <b>${activeRoomDetail.address}</b>. ${intl.formatMessage({ id: "content.consoleMessages.revokeConsoleMessage3", defaultMessage: en["content.consoleMessages.revokeConsoleMessage3"] })}`
    }
    return (
        <Modal.Description>
            <div dangerouslySetInnerHTML={{ __html: message }} />
        </Modal.Description>
    )

}

export const getEditSessionRevokedMessage = async (roomUuid: string) => {
    const { intl } = getIntlProvider()
    const notificationModal = {
        showModal: true,
        header: getEditSessionRevokedHeader(),
        modalContent: await getEditSessionRevokedContent(roomUuid),
        buttonDirection: EButtonDirection.RIGHT,
        actionButton1Text: intl.formatMessage({ id: "content.ok.btn", defaultMessage: en["content.ok.btn"] }),
        actionButton1Onclick: hideNotificationModal,
        modalStyles: "pmStartModal"
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })

}

export const isIncognitoPMNFCCPossible = (roomAdditionalAttributes: any) => {
    const { permissions } = store.getState().externalReducer
    return isNFCCAllowed() && (!!permissions.CONSOLE_VIEW_INCOGNITO) || (!!permissions.CONSOLE_EDIT_WITHOUT_AUTHORIZATION && isQualifiedForFixedCommandCenterEdit(roomAdditionalAttributes))
}

export const getRoomAdditionalAttributes = (roomUuid: string) => {
    const { rooms } = store.getState().externalReducer
    const roomInfo = rooms.find((roomInfo) => roomInfo.roomUuid === roomUuid)
    return roomInfo ? roomInfo.additionalAttributes : null
}

export const hasReceivers = () => {
    const { receivers } = store.getState().consoleReducer.commandCenterDetails.commandCenterSeat
    return receivers.length && receivers[0].id
}

export const checkForSeamlessEditFromConsoleApp = () => {
    const { consoleSessions } = store.getState().consoleReducer
    const response = { isActiveEditSession: false, isActiveEmeraldSession: false }
    const editSessions: IConsoleSession[] = consoleSessions.filter((session: IConsoleSession) => session.connectionType === EConnectionType.FULL_CONTROL)
    if (editSessions.length) {
        response.isActiveEditSession = true
        response.isActiveEmeraldSession = !!editSessions.find(session => session.connectionMode === EConnectionMode.EMERALD)
    }
    return response
}

/* NOTE: [FF] Only for testing presigned JWT behind feature flag. Remove when merging to master */
export const checkIfPresignedJwtFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_PRESIGNED_JWT)
}

export const checkIfMultiEditWithoutParkResumeFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME)
}

export const checkIfMultiEditWithParkResumeFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITH_PARK_AND_RESUME)
}

export const checkIfMultiAudioFeatureEnabled = () => {
    const { featureFlags } = store.getState().externalReducer
    return !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_MULTI_AUDIO)
}

/* TODO: Add checkIfSeamlessMultiEditFeatureExists (check isActiveEmeraldSession) */
export const checkIfMultiEditFeatureExist = () => {
    return (checkIfMultiEditWithoutParkResumeFeatureEnabled() || checkIfMultiEditWithParkResumeFeatureEnabled())
        && !checkForSeamlessEditFromConsoleApp().isActiveEmeraldSession
}

export const checkToAllowCommonMultiEditOptions = () => {
    const state = store.getState()
    const { connectedCallDetails, onHoldCallDetails } = state.externalReducer.callDetails
    const { isActiveEditSession, isActiveEmeraldSession } = checkForSeamlessEditFromConsoleApp()

    return !!((connectedCallDetails.contextId || onHoldCallDetails.length) && isActiveEditSession && !isActiveEmeraldSession)
}

export const checkToAllowParkResume = () => {
    return checkIfMultiEditWithParkResumeFeatureEnabled() && checkToAllowCommonMultiEditOptions()
}

export const checkToAllowMultiEdit = () => {
    return checkIfMultiEditWithoutParkResumeFeatureEnabled() && checkToAllowCommonMultiEditOptions()
}

export const registerMultiEditWorkflow = (props: IHandleAuthorization) => {
    const { roomUuid, consoleSessions, connectionMode, receiverName, componentName } = props
    const activeSession = consoleSessions.find(session => session.connectionType === EConnectionType.FULL_CONTROL)
    const context = {
        prevSessionDetails: {
            callContextId: activeSession?.additionalData?.callContextId || "",
            consoleContextId: activeSession?.contextId || "",
            contactUuid: roomUuid,
        },
        nextSessionDetails: {
            contactUuid: roomUuid, receiverName, connectionMode, connectionType: EConnectionType.FULL_CONTROL,
        },
    }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.MULTI_EDIT_START_EDITING, context, } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { component: componentName, event: `Edit Console: Multi-Edit Start Editing`, source: transformSessionTypeForAnalytics(connectionMode), eventBy: currentUser.uuid, Call_To: roomUuid, Call_From: currentUser.uuid } })
}

export const registerSeamlessEditWorkflow = (props: IHandleAuthorization) => {
    const { roomUuid, consoleSessions, connectionMode, receiverName, componentName } = props
    const activeSession = consoleSessions.find(session => session.connectionType === EConnectionType.FULL_CONTROL)
    const context = {
        prevSessionDetails: {
            callContextId: activeSession?.additionalData?.callContextId || "",
            consoleContextId: activeSession?.contextId || "",
            contactUuid: roomUuid,
        },
        nextSessionDetails: {
            contactUuid: roomUuid, receiverName, connectionMode, connectionType: EConnectionType.FULL_CONTROL,
        },
    }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.PARK_AND_START_EDITING, context, } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { component: componentName, event: `Edit Console: Park and Start Editing`, source: transformSessionTypeForAnalytics(connectionMode), eventBy: currentUser.uuid, Call_To: roomUuid, Call_From: currentUser.uuid } })
}

export const registerConsoleSessionDisconnectWorkflow = (props: IHandleConsoleSessionDisconnect) => {
    const { roomUuid, connectionMode, componentName } = props
    const context = { contactUuid: roomUuid }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.DISCONNECT_CONSOLE_SESSION, context } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { component: componentName, event: `Edit Console: Console Session Disconnected`, source: transformSessionTypeForAnalytics(connectionMode), eventBy: currentUser.uuid, Call_To: roomUuid, Call_From: currentUser.uuid } })
}

export const registerToggleCallControlWorkflow = (props: IHandleToggleCallControl) => {
    const { callContextId, roomUuid, toggles, componentName } = props
    const context = { callContextId, roomUuid, toggles }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.TOGGLE_CALL_CONTROL, context } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { componentName, event: "Web to Web Call: Call Control Toggled", Event_By: currentUser.uuid } })
}

export const registerCallDisconnectWorkflow = (props: IHandleCallDisconnect) => {
    const { callContextId, componentName } = props
    const context = { callContextId }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.DISCONNECT_CALL, context } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { componentName, event: "Web to Web Call: Call Disconnected", Event_By: currentUser.uuid } })
}

export const registerCallDisconnectWithoutModalWorkflow = (props: IHandleCallDisconnect) => {
    const { callContextId, componentName } = props
    const context = { callContextId }
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.DISCONNECT_CALL_WITHOUT_MODAL, context } })
    const { currentUser } = store.getState().externalReducer
    sendLogsToAzure({ contextData: { componentName, event: "Web to Web Call: Call Disconnected", Event_By: currentUser.uuid } })
}

export const filterWithoutIncognitoSession = (activeSessions: IConsoleSession[]) => {
    const { VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL } = EConnectionType
    const allEditConnectionType = [VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL]
    return activeSessions.filter(session => allEditConnectionType.includes(session.connectionType))
}

export const roomMonitoringMessage = (widthStyle: any, cameraStyles: any) => {
    const { intl } = getIntlProvider()
    return (
        <Grid.Column className={cx(cameraStyles.multiCameraGalleryView, widthStyle)} id={"multiCameraGalleryView"}>
            <div className={cx(cameraStyles.toggleDisplayCameraMessage, cameraStyles.warningMessage)}>
                <div className={cameraStyles.displayRoomMonitoringMessage1}>
                    {intl.formatMessage({ id: "content.room.liveVideoStreamingMessage1", defaultMessage: en["content.room.liveVideoStreamingMessage1"] })}
                </div>
                <div className={cameraStyles.displayRoomMonitoringMessage2}>
                    {intl.formatMessage({ id: "content.room.liveVideoStreamingMessage2", defaultMessage: en["content.room.liveVideoStreamingMessage2"] })}
                </div>
            </div>
        </Grid.Column>)
}

export const checkIfReceiversSorted = (featureFlags: any) => {
    return isRoomMonitoringEnabled(featureFlags) || checkIfMultiEditFeatureExist()
}
