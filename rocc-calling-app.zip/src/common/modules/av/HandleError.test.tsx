/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { errorLogger } from "@rocc/rocc-logging-module"
import { handleError, handleVideoSwitchError } from "./HandleError"
import React from "react"
import { MEDIASTREAM_EXCEPTION } from "./AudioVideoHelper"
import { shallow } from "enzyme"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("@rocc/rocc-logging-module", () => ({
    errorLogger: jest.fn(),
}))

describe("HandleError utility", () => {
    it("should log type error and message", () => {
        handleError("test.tsx", new Error("An unexpected error has occured"))
        expect(errorLogger).toHaveBeenCalled()
    })
})


describe("Handle VideoSwitchError", () => {
    const testFunction = (error: any) => {
        const Component = () => {
            const dispatch = jest.fn()
            handleVideoSwitchError({ name: error }, dispatch)
            return <div></div>
        }
        const wrapper = shallow(<Component />)
        expect(wrapper).toBeDefined()
    }
    it("should handle not allowed error", () => {
        testFunction(MEDIASTREAM_EXCEPTION.NOTALLOWED_ERROR)
    })
    it("should handle not found error", () => {
        testFunction(MEDIASTREAM_EXCEPTION.NOTFOUND_ERROR)
    })
    it("should handle default error", () => {
        testFunction("")
    })
})
