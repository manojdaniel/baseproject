import unittest
from unittest.mock import Mock
from src.constants.headers import EXCEL_ROOM_SCANNER_MANUFACTURER, EXCEL_ROOM_SITE_IDENTIFIER, EXCEL_ROOM_IDENTIFIER
from src.modules.db_operations.validation_service.rooms_data_validation_service import check_if_rooms_exists


class RoomDataValidationTest(unittest.TestCase):
    def test_check_if_rooms_exists(self):
        room_dict= {}
        room_dict[EXCEL_ROOM_SITE_IDENTIFIER] = "Hospital/DIC Identifier- To be filled by Philips"
        room_dict[EXCEL_ROOM_IDENTIFIER] = "hospital city"
        room_dict[EXCEL_ROOM_SCANNER_MANUFACTURER] =""
        returned_data=check_if_rooms_exists({},room_dict)
        self.assertIsNone(returned_data)

    def test_check_if_room_exists_with_no_room(self):
        room_dict = {"Hospital/DIC Identifier- To be filled by Philips":"abc",
        "Room Identifier (To be filled by Philips)":"123", "Manufacturer":"def", "Scanner software version":"0.1",
        "Scanner OS\n(Windows/Linux/etc)":"5","Scanner OS version":"0.8","Scanner Model":"Dell01",
        "Room Phone Number(with Country code)":"+917675456898","Additional Notes":"always select value",
        "DICOM AE Title":"Philips Application", "Transmitter view connection name- To be filled by Philips":"yes",
        "Transmitter edit connection name- To be filled by Philips":"anyone can edit", "Scanner\nSerial number":"1234" }
        mock_client = Mock()
        mock_client.execute.return_value = {"abc":[{"id":"1234"},11]}
        returned_data = check_if_rooms_exists(mock_client, room_dict)
        self.assertIsNone(returned_data)
