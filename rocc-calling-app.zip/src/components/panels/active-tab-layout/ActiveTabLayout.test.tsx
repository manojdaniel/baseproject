/*
 * Created on Tue May 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import * as Redux from "react-redux"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import { EModalityType, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { withHooks } from "jest-react-hooks-shallow"
import ActiveTabLayout from "./ActiveTabLayout"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn(),
}))

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            customerReducer: {
                locations: [{
                    id: 1,
                    name: "location1",
                    shortName: "location1",
                    address: "",
                    modalityList: [],
                    locationContacts: [],
                    totalRooms: 1,
                    roomsFetched: true,
                    siteId: []
                }]
            }
        }
    }),
    CreateStore: jest.fn(),
}))

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const mockAppState: any = {
    callReducer: {
        callDetails: {
            onHoldCallDetails: [{
                contextId: "contextId",
                participants: [{
                    name: "name", clinicalRole: "role", description: "", modalities: [EModalityType.CT], siteId: [],
                }],
                isMuted: false,
                isDeafened: false,

            }]
        }
    },
    externalReducer: {
        featureFlags: {
            [ROCC_FEATURES.ROCC_MULTI_AUDIO]: true
        }
    }
}

let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const getShallowWrapper = () => { return shallow(<ActiveTabLayout handleActiveTabClick={jest.fn()} />) }
const findElement = (elemantName: any) => {
    wrapper = getShallowWrapper()
    const element = wrapper.find(elemantName)
    expect(element).toHaveLength(1)
}

describe("Should render active call dropdown", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })
    it("should render call dropdown list", () => {
        withHooks(() => {
            findElement("ActiveCallList")
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("Should not render active call dropdown", () => {
    beforeEach(() => {
        mockAppState.externalReducer.featureFlags[ROCC_FEATURES.ROCC_MULTI_AUDIO] = false
        useSelectorMock(mockAppState)
    })
    it("should render div with callWindowBody", () => {
        withHooks(() => {
            findElement(".activeTab")
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
