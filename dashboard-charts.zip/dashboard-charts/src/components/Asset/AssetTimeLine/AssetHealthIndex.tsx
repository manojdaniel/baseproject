// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

interface Props {
	assetHealthIndexData: any[];
}

const AssetHealthIndex = ({ assetHealthIndexData }: Props) => {
	//  Start:AssetHealthIndex Chart=======================
	useLayoutEffect(() => {
		if (assetHealthIndexData.length > 0) {
			// Create root and chart
			let root = am5.Root.new("assetHealthIndex");
			/* remove amchart logo */

			root._logo.dispose();

			root.setThemes([am5themes_Animated.new(root)]);

			let chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					panY: false,
					wheelY: "zoomX",
					layout: root.verticalLayout,
					maxTooltipDistance: 0,
				})
			);
			chart.get("colors").set("colors", [
				am5.color(0x4e79a7), //Light sky blue
			]);

			chart.zoomOutButton.get("background").setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart.zoomOutButton.get("background").states.create("hover", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart.zoomOutButton.get("background").states.create("down", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			//===============================To get data : start
			let AssetTimeLineGetData = [];
			assetHealthIndexData.forEach((device, index) => {
				AssetTimeLineGetData[index] = { ...device };
			});
			let data = [];
			for (var i = 0; i < AssetTimeLineGetData.length; i++) {
				let localdata = {
					date: new Date(AssetTimeLineGetData[i].timestamp).getTime(),
					value:
						AssetTimeLineGetData[i].assetHealthIndex !== null
							? AssetTimeLineGetData[i].assetHealthIndex
							: 0,
				};
				data.push(localdata);
			}
			//===============================To get data : end

			// Create Y-axis
			var yAxis = chart.yAxes.push(
				am5xy.ValueAxis.new(root, {
					extraTooltipPrecision: 1,
					renderer: am5xy.AxisRendererY.new(root, {}),
				})
			);
			let yRenderer = yAxis.get("renderer");
			yRenderer.labels.template.setAll({
				fontSize: "0.8rem"
			});

			// Create X-Axis ==day/month/year
			let xAxis = chart.xAxes.push(
				am5xy.DateAxis.new(root, {
					baseInterval: { timeUnit: "day", count: 1 },
					renderer: am5xy.AxisRendererX.new(root, {
						minGridDistance: 50,
					}),
				})
			);
			let xRenderer = xAxis.get("renderer");
			xRenderer.labels.template.setAll({
				fontSize: "0.8rem"
			});
			// Create series
			function createSeries(name: any, field: any) {
				let series = chart.series.push(
					am5xy.LineSeries.new(root, {
						name,
						xAxis,
						yAxis,
						valueYField: field,
						valueXField: "date",
						tooltip: am5.Tooltip.new(root, {}),
					})
				);

				series.bullets.push(function () {
					return am5.Bullet.new(root, {
						sprite: am5.Circle.new(root, {
							radius: 5,
							fill: series.get("fill"),
						}),
					});
				});

				series.strokes.template.set("strokeWidth", 2);

				series.get("tooltip").label.set("text", "{valueY}");
				series.data.setAll(data);
			}

			createSeries("Series #1", "value");

			// Add cursor
			chart.set(
				"cursor",
				am5xy.XYCursor.new(root, {
					behavior: "zoomXY",
					xAxis,
				})
			);

			xAxis.set(
				"tooltip",
				am5.Tooltip.new(root, {
					themeTags: ["axis"],
				})
			);

			yAxis.set(
				"tooltip",
				am5.Tooltip.new(root, {
					themeTags: ["axis"],
				})
			);

			return () => {
				root.dispose();
			};
		}
	}, [assetHealthIndexData]);
	//  End:AssetHealthIndex Chart=======================

	return (
		<div id="assetHealthIndex" style={{ width: "100%", height: "200px" }}></div>
	);
};

export default AssetHealthIndex;
