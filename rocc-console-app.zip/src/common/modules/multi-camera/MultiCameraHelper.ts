/*
 * Created on Fri Dec 03 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, IConsoleSession, parseIntBase10 } from "@rocc/rocc-client-services"
import { errorLogger, errorParser, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "react"
import { createLocalTracks, createLocalVideoTrack, LocalTrack, Room } from "twilio-video"
import { updateConsoleSession } from "../../../redux/actions/consoleActions"
import { fetchGlobalConfigs, fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import store from "../../../redux/store/store"
import syncSessions from "../../../redux/store/syncSessions"
import { APPLICATION_JSON, BANDWIDTH_PROFILE_MODE, COMMUNICATION_SERVICE_MEDIA_ROOM_URI, CONSOLE_MEDIA_ROOM_UPDATE, CONTENT_TYPE, DEFAULT_SUBSCRIPTION_BITRATE, DEFAULT_VIDEO_BITRATE } from "../../constants/constants"
import { getService, putService } from "../../helpers/apiUtility"
import { detachParticipantTracks } from "../../helpers/multiCameraUtility"
import { ERoomType, IAddLocalTracks, ICloseMediaRoom, IHandleUnloadEventHandler, ILeaveRoom, IMediaRoomConnectOptions, IUpdateCurrentSession, IUpdateMediaRoomForConsole } from "./MultiCameraTypes"

const FILENAME = "MultiCameraHelper.ts :"

export const getMediaRoomConnectOptions = (connectOptions: IMediaRoomConnectOptions) => {
    const { localTracks, region, videoStatus, renderDimensions, roomName, roomType } = connectOptions
    const configs = fetchGlobalConfigs()
    const maxSubscriptionBitrateValue = configs.MAX_SUBSCRIPTION_BITRATE
    const maxVideoBitrateValue = configs.MAX_VIDEO_BITRATE
    const bandWidthProfileOptionsForGroupRoom = {
        video: {
            mode: BANDWIDTH_PROFILE_MODE.COLLABORATION,
            renderDimensions,
            maxSubscriptionBitrate: maxSubscriptionBitrateValue ? parseIntBase10(maxSubscriptionBitrateValue) : DEFAULT_SUBSCRIPTION_BITRATE,
            maxVideoBitrate: maxVideoBitrateValue ? parseIntBase10(maxVideoBitrateValue) : DEFAULT_VIDEO_BITRATE,
        },
    }

    const bandWidthProfileOptionsForDefaultRoom = {
        video: {
            mode: BANDWIDTH_PROFILE_MODE.GRID,
        },
    }

    return {
        name: roomName,
        _useTwilioConnection: true,
        audio: false,
        video: videoStatus,
        bandWidthProfile: roomType === ERoomType.GROUP ? bandWidthProfileOptionsForGroupRoom : bandWidthProfileOptionsForDefaultRoom,
        networkQuality: true,
        tracks: localTracks,
        dominantSpeaker: true,
        region,
    }
}

export const fetchMediaRoomDetails = async (mediaRoomId: string) => {
    try {
        const state = store.getState()
        const { accessToken } = state.externalReducer.currentUser
        const configs = fetchGlobalConfigs()
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
            Authorization: accessToken,
        }
        const params = {
            url: `${configs.COMMUNICATION_SERVICES_URL}${COMMUNICATION_SERVICE_MEDIA_ROOM_URI}/${mediaRoomId}`,
            headers,
        }
        const response = await getService(params)
        if (response.status === 200) {
            return response.data
        } else {
            const ERROR_MESSAGE = `Error occurred while fetching media room details : ${response.data}`
            errorLogger(`${FILENAME}${ERROR_MESSAGE}`)
            throw ERROR_MESSAGE
        }
    } catch (error) {
        errorLogger(`${FILENAME} Exception occurred while fetching media room details : ${errorParser(error)}`)
        throw error
    }
}

export const checkMultiCameraDeviceDisconnected = (cameraStreamAvailable: ECameraStreamAvailable, newState: ECameraStreamAvailable) => {
    return cameraStreamAvailable === ECameraStreamAvailable.DEVICE_DISCONNECTED ? ECameraStreamAvailable.DEVICE_DISCONNECTED : newState
}

export const toggleDisplayCamera = (consoleSession: IConsoleSession, dispatch: Dispatch<any>) => {
    const newConsoleSession: IConsoleSession = { ...consoleSession }
    const { cameraStreamAvailable } = newConsoleSession.mediaRoomDetails
    const { INITIATED, CAMERA_STREAM_DISCONNECTED } = ECameraStreamAvailable
    infoLogger(`${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId} - Setting display camera state: ${!newConsoleSession.displayCameraToggle}.`)
    if (consoleSession.displayCameraToggle) {
        newConsoleSession.displayCameraToggle = false
        newConsoleSession.multiCameraList = []
        newConsoleSession.mediaRoomDetails.cameraStreamAvailable = checkMultiCameraDeviceDisconnected(cameraStreamAvailable, CAMERA_STREAM_DISCONNECTED)
        dispatch(updateConsoleSession(newConsoleSession, true, false))
    } else {
        newConsoleSession.displayCameraToggle = true
        newConsoleSession.multiCameraList = []
        newConsoleSession.mediaRoomDetails.cameraStreamAvailable = checkMultiCameraDeviceDisconnected(cameraStreamAvailable, INITIATED)
        dispatch(updateConsoleSession(newConsoleSession, true, false))
    }
}

export const RenderDimensions = () => {
    return {
        high: { height: 1080, width: 1920 },
        standard: { height: 720, width: 1280 },
        low: { height: 93, width: 150 },
    }
}

export const renewMediaRoomToken = async (mediaRoomId: string, accessTokenProp?: string) => {
    const state = store.getState()
    const { accessToken, uuid } = state.externalReducer.currentUser
    infoLogger(`${FILENAME}: For user: ${uuid} - Renewing twillio media token for media room id ${mediaRoomId}.`)
    try {
        const communicationServiceUrl = fetchGlobalURLs()?.COMMUNICATION_SERVICES_URL || ""
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
            Authorization: accessTokenProp ? accessTokenProp : accessToken,
        }
        const params = {
            url: `${communicationServiceUrl}${COMMUNICATION_SERVICE_MEDIA_ROOM_URI}/${mediaRoomId}/$renew-token`,
            data: {},
            headers,
        }
        const response = await putService(params)
        if (response.status === 200) {
            infoLogger("Renew of Media token is successfully.")
            return response.data
        }
    } catch (error) {
        errorLogger(`${FILENAME} Exception occurred while refreshing the media room token : ${error}`)
    }
}

export const addLocalTracks = async (props: IAddLocalTracks) => {
    const { isDevice, maxSupportedCameras, cameraTrackName, currentUserUuid } = props
    infoLogger(`${FILENAME}: For user: ${currentUserUuid} - Adding local tracks.`)
    let localTracks: LocalTrack[] = []
    if (isDevice) {
        const mediaDevices = await navigator.mediaDevices.enumerateDevices()
        for (const device of mediaDevices) {
            try {
                if (device.kind === "videoinput" && maxSupportedCameras && cameraTrackName && filterCameras(device.label) && localTracks.length <= parseIntBase10(maxSupportedCameras)) {
                    localTracks.push(await createLocalVideoTrack({ deviceId: device.deviceId, name: cameraTrackName + (localTracks.length + 1) }))
                }
            } catch (error) {
                errorLogger(`${FILENAME}: Failed to create Local tracks for device: ${device} with error: ${error}`)
            }
        }
        sendLogsToAzure({ contextData: { component: "Multi Camera: Controller", event: `Camera streaming - ${localTracks.length}`, Event_By: currentUserUuid } })
    } else {
        try {
            localTracks = await createLocalTracks({ audio: false, video: false })
        } catch (error) {
            errorLogger(`${FILENAME}: Failed to create Locale track for Expert user: ${error}`)
        }
    }
    return localTracks
}

const filterCameras = (cameraLabel: string) => {
    const cameraLabelLowerCase = cameraLabel.toLowerCase()
    const vendorRegex = /(microsoft|surface|facetime)/
    const cameraRegex = /(front|back|rear|ir|camera)/
    return !(vendorRegex.test(cameraLabelLowerCase) && cameraRegex.test(cameraLabelLowerCase))
}

export const closeMediaRoom = (props: ICloseMediaRoom) => {
    const { room, previewTracksRef, setPreviewTracks, setActiveRoom } = props
    const { localParticipant, participants } = room
    detachParticipantTracks(localParticipant)
    for (const participant of participants.values()) {
        detachParticipantTracks(participant)
    }
    if (previewTracksRef && previewTracksRef.current) {
        for (const track of previewTracksRef.current) {
            if (track.kind === "video" || track.kind === "audio") {
                track.stop()
            }
        }
    }
    const prevRoom = room.disconnect()
    setPreviewTracks([])
    setActiveRoom(undefined as unknown as Room)
    return prevRoom
}

export const handleUnloadEventHandler = (props: IHandleUnloadEventHandler) => {
    if (props.addHandler) {
        window.addEventListener("beforeunload", () => {
            const prevRoom = closeMediaRoom({ ...props })
            infoLogger(`Disconnect media room  : ${prevRoom.name}`)
        })
    } else {
        window.removeEventListener("beforeunload", () => {
            const prevRoom = closeMediaRoom({ ...props })
            infoLogger(`Disconnect media room  : ${prevRoom.name}`)
        })
    }
}


export const leaveMediaRoom = (props: ILeaveRoom) => {
    const { room, dispatch, setVideoTracks, videoTracksRef, setRemoteVideoStatus, disconnectState, consoleSession, isSyncConsoleSession } = props
    infoLogger(`${FILENAME}: ${consoleSession && `For user: ${consoleSession.requester} console context Id ${consoleSession.contextId} and room id ${consoleSession.mediaRoomDetails.mediaRoomId} - `} Initiating leave media room`)
    try {
        // TODO: Update Media Room Detail in DB        
        if (room) {
            infoLogger(`${FILENAME}: ${consoleSession && `For user: ${consoleSession.requester}`} - Disconnecting twillio room ${room.name}, detaching local and remote tracks`)
            detachParticipantTracks(room.localParticipant)
            room.participants.forEach(detachParticipantTracks)
            room.removeAllListeners()
            room.disconnect()
        }
        if (consoleSession) {
            infoLogger(`${FILENAME}: For user: ${consoleSession.requester} - updating console session cameraStreamAvailability to ${disconnectState}`)
            updateCurrentSession({ consoleSession, disconnectState, isSyncConsoleSession, dispatch, multiCameraFeature: !!setRemoteVideoStatus })
        }
        setRemoteVideoStatus && setRemoteVideoStatus(false)
        setVideoTracks([])
        videoTracksRef.current = []
    } catch (error) {
        errorLogger(`${FILENAME} Exception occurred while leaving media room: ${errorParser(error)}`)
    }
}

export const updateCurrentSession = (props: IUpdateCurrentSession) => {
    const { consoleSession, isSyncConsoleSession, disconnectState, dispatch, multiCameraFeature } = props
    const { CAMERA_STREAM_DISCONNECTED, INITIATED } = ECameraStreamAvailable
    const { contextId, mediaRoomDetails } = consoleSession
    const { cameraStreamAvailable, mediaRoomId, mediaRoomToken } = mediaRoomDetails
    const cameraAvailableState = disconnectState ? disconnectState : CAMERA_STREAM_DISCONNECTED
    infoLogger(`${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId} - updating console session cameraStreamAvailability redux value to ${disconnectState}`)
    if (isSyncConsoleSession) {
        syncSessions.postMessage({
            type: CONSOLE_MEDIA_ROOM_UPDATE,
            cameraStreamStatus: {
                contextId: contextId,
                mediaRoomDetails: { cameraStreamAvailable: cameraAvailableState, mediaRoomId, mediaRoomToken }
            }
        })
    } else {
        const state = store.getState()
        const { consoleSessions } = state.consoleReducer
        const currentSession = consoleSessions.find((session: IConsoleSession) => session.contextId === consoleSession.contextId)
        if (currentSession) {
            currentSession.displayCameraToggle = multiCameraFeature ? currentSession.displayCameraToggle : false
            infoLogger(`${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId} - updating console session displayCameraToggle: ${currentSession.displayCameraToggle}.`)
            if (cameraStreamAvailable === INITIATED) {
                currentSession.mediaRoomDetails.cameraStreamAvailable = cameraAvailableState
                currentSession.multiCameraList = []
            }
            dispatch(updateConsoleSession({ ...currentSession }, true, false))
        }
    }
}

export const updateConsoleMediaDetails = (props: IUpdateMediaRoomForConsole) => {
    const { mediaRoomId, mediaRoomToken, dispatch, cameraStreamAvailable, isSyncSession, contextId } = props
    if (isSyncSession) {
        syncSessions.postMessage({ type: "CONSOLE_MEDIA_ROOM_UPDATE", cameraStreamStatus: { contextId, mediaRoomDetails: { cameraStreamAvailable, mediaRoomId, mediaRoomToken } } })
    } else {
        const state = store.getState()
        const { consoleSessions } = state.consoleReducer
        const currentSession = consoleSessions.find(session => session.contextId === contextId)
        if (currentSession) {
            currentSession.mediaRoomDetails.mediaRoomId = mediaRoomId
            currentSession.mediaRoomDetails.mediaRoomToken = mediaRoomToken
            currentSession.mediaRoomDetails.cameraStreamAvailable = cameraStreamAvailable
            dispatch(updateConsoleSession(currentSession, true, false))
            infoLogger(`Updating console session ${currentSession.contextId} cameraStreamAvailable to ${cameraStreamAvailable} for User ${currentSession.requester}.`)
        }
    }
}
