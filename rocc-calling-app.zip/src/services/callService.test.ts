/*
 * Created on Tue Sept 14 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, EClinicalRole, ERoccWorkflow, EUserPresence, IAVCallDetails, IContactInfo, IUserInfo } from "@rocc/rocc-client-services"
import * as callUtility from "../common/helpers/callUtility"
import * as helpers from "../common/helpers/helpers"
import * as AudioVideoHelper from "../common/modules/av/AudioVideoHelper"
import { HTTP_STATUS } from "../constants/constants"
import { dispatchToParentStore } from "../redux/store/externalAppStates"
import * as callServices from "./callServices"

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
}))

const dispatch = jest.fn()
const componentName = "Component Name"
const currentUser: IUserInfo = {
    ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US",
    accessTokenExpiryTime: ""
}

const contactInfo: IContactInfo = {
    id: "", uuid: "", siteId: [], orgId: "", status: EUserPresence.AVAILABLE, name: "",
    phoneNumber: "", clinicalRole: EClinicalRole.DEFAULT, email: "", roomName: "", allRoles: [],
    secondaryUUID: "", secondaryName: "", modalities: [], description: ""
}
const contact = {
    uuid: "contactUuid",
}

jest.useFakeTimers()

jest.mock("../common/helpers/helpers", () => ({
    getCurrentUserAndUrlsReduxState: () => ({
        currentUser,
    }),
    getUserReducerFromGlobalStore: () => ({
        currentUser,
        contacts: [contact]
    }),
    getCustomrReducerFromGlobalStore: () => ({
        rooms: []
    }),
    fetchActiveEditSession: () => ({
        activeSession: {
            contextId: "contextId",
        }
    }),
    checkToAllowMultiEdit: jest.fn(),
    checkToAllowParkResume: jest.fn()
}))

jest.mock("../redux/store/store", () => ({
    dispatch: jest.fn(),
    getState: jest.fn().mockReturnValue({
        callReducer: {
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    participants: [{
                        uuid: "uuid",
                        callStatus: "RINGING",
                    }]
                },
                onHoldCallDetails: [],
            }
        },
        externalReducer: {
            currentUser: {
                uuid: "uuid",
            }
        }
    })
}))

jest.mock("../redux/store/externalAppStates", () => ({
    fetchGlobalConfigs: () => ({
        COUNTRY_ISO_CODE: "US",
        REGION: "ALL"
    }),
    fetchGlobalURLs: () => ({
        urls: {
            COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl"
        }
    }),
    fetchGlobalFeatureFlags: () => ({
        ROCC_PP_CALLING_MODE: "true"
    }),
    dispatchToParentStore: jest.fn(),
}))

jest.mock("../redux/actions/callActions", () => ({
    setVideoCallStatus: jest.fn(),
    setCallMessage: jest.fn(),
    setPhoneCallStatus: jest.fn(),
    setOutgoingCallDetails: jest.fn(),
    storeCallDetails: jest.fn(),

}))

jest.mock("../common/helpers/apiUtility", () => ({
    postService: () => { return { status: HTTP_STATUS.OK, data: {} } },
    putService: () => { return { status: HTTP_STATUS.OK, data: {} } }
}))

jest.mock("../common/modules/avmessages/av-messages/event-handlers/OutgoingCall", () => ({
    outgoingCall: jest.fn()
}))

jest.mock("../redux/reducers/callReducer", () => ({
    DEFAULT_OUTGOING_CALL_DEATILS: {
        contextId: ""
    }
}))

jest.mock("../common/modules/av/AudioVideoHelper", () => ({
    updateCallDetails: jest.fn(),
}))

describe("enableWebToWebCallWrapper tests", () => {
    let checkMultiEditMock: jest.Mock
    let checkParkResumeMock: jest.Mock
    let multiEditWorkflowSpy: jest.SpyInstance
    let parkWorkflowSpy: jest.SpyInstance

    beforeEach(() => {
        checkMultiEditMock = (helpers.checkToAllowMultiEdit as jest.Mock).mockReturnValue(false)
        checkParkResumeMock = (helpers.checkToAllowParkResume as jest.Mock).mockReturnValue(false)
        multiEditWorkflowSpy = jest.spyOn(callServices, "registerMultiEditInitiateCallWorkflow")
        parkWorkflowSpy = jest.spyOn(callServices, "registerParkAndInitiateCallWorkflow")
    })

    afterEach(() => {
        checkMultiEditMock.mockReset()
        checkParkResumeMock.mockReset()
        multiEditWorkflowSpy.mockReset()
        parkWorkflowSpy.mockReset()
    })

    it("should start multi edit workflow when multi-edit-without-park-resume flag available", () => {
        checkMultiEditMock.mockReturnValue(true)

        callServices.enableWebToWebCallWrapper({ contactUuid: "contactUuid", dispatch, componentName, currentUserUuid: "currentUserUuid", modalityName: "CT" })

        expect(checkMultiEditMock).toBeCalled()
        expect(checkParkResumeMock).not.toBeCalled()
        expect(multiEditWorkflowSpy).toBeCalled()
        expect(parkWorkflowSpy).not.toBeCalled()
    })

    it("should start park and resume workflow when multi-edit-with-park-resume flag available", () => {
        checkParkResumeMock.mockReturnValue(true)

        callServices.enableWebToWebCallWrapper({ contactUuid: "contactUuid", dispatch, componentName, currentUserUuid: "currentUserUuid", modalityName: "CT" })

        expect(checkMultiEditMock).toBeCalled()
        expect(checkParkResumeMock).toBeCalled()
        expect(multiEditWorkflowSpy).not.toBeCalled()
        expect(parkWorkflowSpy).toBeCalled()
    })

    it("should start trigger web call handler when park-resume flag isn't available", () => {
        callServices.enableWebToWebCallWrapper({ contactUuid: "contactUuid", dispatch, componentName, currentUserUuid: "currentUserUuid", modalityName: "CT" })

        expect(checkMultiEditMock).toBeCalled()
        expect(checkParkResumeMock).toBeCalled()
        expect(multiEditWorkflowSpy).not.toBeCalled()
        expect(parkWorkflowSpy).not.toBeCalled()
    })
})

describe("enableWebToWebCall tests", () => {
    it("should able to initiate web call", () => {
        const contactUuid = "contactUuid"
        const spy = jest.spyOn(callServices, "enableWebToWebCall")
        jest.spyOn(callUtility, "upsertCallStatus").mockReturnValue([{ contextId: "", callStatus: "CONNECTING" }] as any)
        callServices.enableWebToWebCall({ contactUuid, dispatch, componentName, currentUserUuid: "currentUserUuid", modalityName: "CT" })
        expect(spy).toBeCalled()
    })
})

describe("audioCallService tests", () => {
    it("should able to make Api call", () => {
        callServices.audioCallService({ accessToken: "accessToken", currentUserUuid: "uuid", phoneNumber: "phoneNumber", communicationServiceUrl: "communicationServiceUrl" }).then(response => {
            expect(response.success).toBe(true)
        })
    })
})

describe("enableBrowserToPhoneCall tests", () => {
    it("should able to store data in redux if contactUuid is provided", () => {
        callServices.enableBrowserToPhoneCall({ contactUuid: "contactUuid", phoneNumber: "phoneNumber", dispatch, componentName: "" })
        expect(dispatch).toBeCalled()
    })
})

describe("enableBrowserToPhoneCall else tests", () => {
    it("should able to store data in redux if contactInfo is provided", () => {
        callServices.enableBrowserToPhoneCall({ contactUuid: "", phoneNumber: "phoneNumber", dispatch, componentName: "", contactInfo: contactInfo })
        expect(dispatch).toBeCalled()
    })
})

describe("addParticipantService tests", () => {
    afterEach(() => {
        jest.clearAllMocks()
    })
    it("should able to make API call", () => {
        const contact: any = { uuid: "uuid" }
        const currentUser: any = { uuid: "uuid1", accessToken: "accessToken" }
        const communicationServiceUrl = "http://localhost"
        const spy = jest.spyOn(callServices, "addParticipantService")
        callServices.addParticipantService({ contextId: "contextId", contact, currentUser, communicationServiceUrl })
        expect(spy).toBeCalled()
    })
})

describe("checkIfParticipantAdded tests", () => {
    const serviceSpy = jest.spyOn(callServices, "checkIfParticipantAdded")
    const updateCallDetailsMock = (AudioVideoHelper.updateCallDetails as jest.Mock).mockReturnValue(undefined)
    callServices.checkIfParticipantAdded("contextId", {} as IUserInfo, "commUrl", "uuid", dispatch)
    expect(serviceSpy).toBeCalled()
    expect(updateCallDetailsMock).toBeCalled()
})

describe("addUserToCall tests", () => {
    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should skip adding participant if already exists", () => {
        const activeCall = {
            participants: [
                { uuid: "uuid" },
            ]
        } as IAVCallDetails
        const user = {
            uuid: "uuid"
        } as IContactInfo

        const addParticipantServiceSpy = jest.spyOn(callServices, "addParticipantService")
        callServices.addUserToCall(activeCall, user, dispatch)
        expect(addParticipantServiceSpy).not.toBeCalled()
    })

    it("should update participant array when participant addition is successful", () => {
        const activeCall = {
            participants: [
                { uuid: "uuid1" },
            ]
        } as IAVCallDetails
        const user = {
            uuid: "uuid"
        } as IContactInfo

        const participantCheckSpy = jest.spyOn(callServices, "checkIfParticipantAdded")
        const updateCallDetailsMock = (AudioVideoHelper.updateCallDetails as jest.Mock).mockReturnValue(undefined)
        const addParticipantServiceSpy = jest.spyOn(callServices, "addParticipantService").mockReturnValue(Promise.resolve(false))

        callServices.addUserToCall(activeCall, user, dispatch)

        expect(participantCheckSpy).not.toBeCalled()
        expect(updateCallDetailsMock).toBeCalledTimes(1)
        expect(addParticipantServiceSpy).toBeCalled()

        jest.runAllTimers()
        expect(participantCheckSpy).toBeCalled()
    })
})

describe("initiateWebCallHandler  tests", () => {
    const props = { contactUuid: "uuis", componentName: "comp", dispatch: dispatch }
    callServices.initiateWebCallHandler(props)
    expect(dispatch).toBeCalled()
})

describe("registerMultiEditInitiateCallWorkflow tests", () => {
    callServices.registerMultiEditInitiateCallWorkflow({ contactUuid: "contactUuid", contextId: "contextId" })
})

describe("registerParkAndInitiateCallWorkflow tests", () => {
    callServices.registerParkAndInitiateCallWorkflow({ contactUuid: "contactUuid", contextId: "contextId" })
})

describe("disconnectCallWorkflow tests", () => {
    it("should register call disconnect workflow", () => {
        callServices.registerCallDisconnectWorkflow({ contextId: "contextId" })
        expect(dispatchToParentStore).toBeCalledWith(expect.objectContaining({
            payload: {
                type: ERoccWorkflow.DISCONNECT_CALL,
                context: { callContextId: "contextId" }
            }
        }))
    })
})

describe("endCall tests", () => {
    const props = {
        currentUser: currentUser,
        communicationServiceUrl: "https://communicationUrl",
        contextId: "contextId"
    }
    it("should end Call", () => {
        callServices.endCall(props)

    })
})
