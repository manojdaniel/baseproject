import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import CalendarComponent from "./CalendarComponent";

// Test case 2
it('renders a "Today" label', () => {
	// Render the CalendarComponent
	render(<CalendarComponent />);

	// Assert that the "Today" label is rendered
	expect(screen.getByText("Today:")).toBeInTheDocument();
});

// Test case 3
it("renders a default date", () => {
	// Render the CalendarComponent
	render(<CalendarComponent />);

	// Assert that the default date format is rendered
	expect(screen.getByText(/Feb 7 - \d{1,2}:\d{1,2}/)).toBeInTheDocument();
});

// Test case 4 - This test case is commented out
// because it is not being used in the current test suite
/*
  it("calls the onClickHandler when a custom date is clicked", () => {
    const mockOnClickHandler = jest.fn();
    render(<CalendarComponent onClickHandler={mockOnClickHandler} />);
    const customDateButton = screen.getByText("1D");
    userEvent.click(customDateButton);
    expect(mockOnClickHandler).toHaveBeenCalled();
  });
  */
