
"""
 Created on Fri Apr 1 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from werkzeug.datastructures import ImmutableMultiDict

from src.loggers.log import create_logger

LOG = create_logger("DictUtils")


def drill_and_apply(fn_list, data_dict, exception_collector=[]):
    for dict_key, dict_value in data_dict.items():
        if isinstance(dict_value, dict):
            drill_and_apply(fn_list=fn_list, data_dict=dict_value)
        else:
            data = dict_value
            for func in fn_list:
                try:
                    data = func(data)
                except Exception as exception:
                    LOG.exception(f"Following exception occured while applying function: {exception}")
                    exception_collector.append(exception)
                data_dict[dict_key] = data


def exract_file_from_immutable_object(files, form_field):
    try:
        file_obj = ImmutableMultiDict(files)
        file_obj_dict = file_obj.to_dict()
        file_content = file_obj_dict.get(form_field)
        return file_content
    except Exception as ex:
        LOG.exception(f"Failed to extract file data with error: {ex}")
        raise ex
