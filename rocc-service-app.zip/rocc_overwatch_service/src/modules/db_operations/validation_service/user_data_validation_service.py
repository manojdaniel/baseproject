"""
 Created on Sun Nov 1 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from graphql import GraphQLError

from src.constants.constants import ROCC_USERS
from src.constants.headers import EXCEL_USER_FIRST_NAME, EXCEL_USER_LAST_NAME, EXCEL_USER_EMAIL_ID, EXCEL_USER_HOSPITAL_IDENTIFIER, \
    EXCEL_USER_PHONE, EXCEL_USER_MODALITY, EXCEL_USER_ADDITIONAL_ROLES, EXCEL_USER_ROLES
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import verify_if_user_detail_exists

LOG = create_logger("UserDataValidationService")


def verify_if_user_exists(client, user_detail):
    role = str(user_detail[EXCEL_USER_ADDITIONAL_ROLES])
    if role == "NA":
        role = [r.lower() + "role" for r in str(user_detail[EXCEL_USER_ROLES]).replace(" ", "").split(",")]
    else:
        role = [r.lower() + "role" for r in str(f"{user_detail[EXCEL_USER_ADDITIONAL_ROLES]},{user_detail[EXCEL_USER_ROLES]}").replace(" ", "").split(",")]
    variables = {
        "first_name": user_detail[EXCEL_USER_FIRST_NAME],
        "last_name": user_detail[EXCEL_USER_LAST_NAME],
        "email_id": user_detail[EXCEL_USER_EMAIL_ID],
        "site_identifiers": str(user_detail[EXCEL_USER_HOSPITAL_IDENTIFIER]).split(","),
        "phone": user_detail[EXCEL_USER_PHONE],
        "role": role,
        "modalities": str(user_detail[EXCEL_USER_MODALITY]).replace(" ", "").split(",")
    }
    try:
        response = client.execute(verify_if_user_detail_exists, variable_values=variables)
        return check_if_id_is_present(response, ROCC_USERS)
    except GraphQLError as ge:
        LOG.info("Exception occurred while querying data from graphql,{}".format(ge))
        LOG.info(traceback.print_exc())
    except Exception as ex:
        LOG.info("Exception occurred while parsing data ,{}".format(ex))
        LOG.info(traceback.print_exc())
