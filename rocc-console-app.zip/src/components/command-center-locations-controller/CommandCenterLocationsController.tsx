/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EClinicalRole, parseIntBase10 } from "@rocc/rocc-client-services"
import { SeatAccessModeComponent, SeatConfirmModeComponent, SeatLaunchModeComponent, SeatVerifyModeComponent } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { ACCESS_MODE_SET, COMMAND_CENTER_LOCATION, COMMAND_CENTER_LOCATION_NAME, CONSOLE_ACCESS_MODE, NO_COMMAND_CENTER_LOCATION } from "../../common/constants/constants"
import { displayNotificationMessage, getAnywhereLocationNameText } from "../../common/helpers/helpers"
import { updateCommandCenterSeat } from "../../redux/actions/consoleActions"
import { GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION } from "../../redux/actions/types"
import { EACCESS_MODE_SET, ECommandCenterAccessMode, ELocationSelectionPage, ICommandCenter, ICommandCenterLocation, IStore } from "../../redux/interfaces/types"
import { INIT_COMMAND_CENTER_LOCATION } from "../../redux/reducers/consoleReducer"
import { dispatchToParentStore, fetchMetaSiteId } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"

import {
    checkIfTwoObjectsAreEqual, fetchReceiverTransformer, getCommandCenterLocationName, getCommandCenterSeatService, getLocalStorageItem,
    setCommandCenterSeatService, setLocalStorageItem
} from "./CommandCenterLocationsControllerHelper"
import { fetchCommandCenterService } from "./CommandCenterLocationsControllerService"

const CommandCenterLocationController = () => {
    const { NOMODAL, CONFIRM, HARDWARE, INPUT, LAUNCH } = ELocationSelectionPage
    const { currentUser, initialized } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser,
        initialized: state.consoleReducer.commandCenterDetails.initialised,
    }))
    const { orgId } = currentUser
    const [open, setOpen] = useState(false)
    const [page, setPage] = useState(NOMODAL)
    const [selectedSeatName, setSelectedSeatName] = useState("")
    const [commandCenterLocations, setCommandCenterLocations] = useState([{ seatName: "", registeredCount: 0, seatId: 0, orgId: 0, commandCenterLocation: "" }])
    const initDefaultAccessMode = getLocalStorageItem(CONSOLE_ACCESS_MODE)
    const initCommandCenterLocation = getCommandCenterSeatService(currentUser.orgId.toString())
    const dispatch = useDispatch()
    const accessModeSet = getLocalStorageItem(ACCESS_MODE_SET)
    const { intl } = getIntlProvider()

    const initDefaultSeats = async () => {
        const defaultSeats = await fetchCommandCenterService(fetchMetaSiteId())
        setCommandCenterLocations(defaultSeats)
        return defaultSeats
    }


    const getReceivers = async (orgId: string, inputSeatName: string) => {
        const receivers = await fetchReceiverTransformer(orgId, inputSeatName)
        return receivers
    }

    const setActiveSeatname = async (commandCenterLocation: ICommandCenterLocation, updateDb: boolean) => {
        const receivers = await getReceivers(orgId, commandCenterLocation.seatName)
        const commandCenterDetails = {
            initialised: ECommandCenterAccessMode.WITH_HARDWARE,
            commandCenterSeat: {
                seatName: commandCenterLocation.seatName,
                organizationId: parseIntBase10(orgId),
                receivers
            }
        }
        setCommandCenterSeatService(commandCenterLocation.seatName, parseIntBase10(orgId))
        dispatch(updateCommandCenterSeat({ ...commandCenterDetails }, updateDb))
    }


    const noModal = () => {
        if (open && page === NOMODAL) { setOpen(false) }
    }
    const backLink = () => {
        setLocalStorageItem(CONSOLE_ACCESS_MODE, NO_COMMAND_CENTER_LOCATION)
        setPage(HARDWARE)
    }

    const onAccessModeConfirm = () => {
        setLocalStorageItem(CONSOLE_ACCESS_MODE, COMMAND_CENTER_LOCATION)
        setPage(INPUT)
        sendLogsToAzure({ contextData: { component: "Console service Modal", event: `ROCC seat confirmed` } })

    }
    const getInputSeats = () => {
        initDefaultSeats()
        const inputSeats = [{ seatName: "", registeredCount: 0 }]
        commandCenterLocations.forEach((seat) => {
            inputSeats.push({
                seatName: seat.seatName,
                registeredCount: seat.registeredCount
            })
        })
        return inputSeats.filter(item => item.seatName !== "")
    }
    const onAccessModeCancel = () => {
        setLocalStorageItem(CONSOLE_ACCESS_MODE, NO_COMMAND_CENTER_LOCATION)
        setPage(LAUNCH)
    }
    const setSeatNameWithoutHardware = () => {
        const inputCommandCenterDetails = {
            initialised: ECommandCenterAccessMode.WITHOUT_HARDWARE,
            commandCenterSeat: {
                seatName: "",
                organizationId: parseIntBase10(orgId),
                receivers: []
            }
        }
        setLocalStorageItem(ACCESS_MODE_SET, EACCESS_MODE_SET.YES)
        dispatch(updateCommandCenterSeat(inputCommandCenterDetails, false))
    }
    const onLaunchConfirm = () => {
        setLocalStorageItem(CONSOLE_ACCESS_MODE, NO_COMMAND_CENTER_LOCATION)
        setSeatNameWithoutHardware()
        setPage(NOMODAL)
        dispatchToParentStore({ type: GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, userLoggedInLocation: getAnywhereLocationNameText() })
        setLocalStorageItem(COMMAND_CENTER_LOCATION_NAME, getAnywhereLocationNameText())
        sendLogsToAzure({ contextData: { component: "Console service Modal", event: `Hardware Settings set to NO Command Center` } })

    }
    const onLaunchModeBack = () => {
        setPage(HARDWARE)
    }

    const onLocationConfirm = (seatName: string) => {
        getReceivers(orgId, seatName)
        setSelectedSeatName(seatName)
        setPage(CONFIRM)
    }
    const updateLocation = (seatName: string) => {
        const commandCenterLocation = {
            seatName: seatName,
            organizationId: parseIntBase10(orgId)
        }
        setUserActiveLocation(seatName, commandCenterLocations)
        setActiveSeatname(commandCenterLocation, true)
        const message = [{
            header: intl.formatMessage({
                id: "content.configuredSuccessful.title",
                defaultMessage: en["content.configuredSuccessful.title"]
            }),
            content: `${intl.formatMessage({
                id: "content.configuredSuccessful.message",
                defaultMessage: en["content.configuredSuccessful.message"]
            })} "${seatName}"`
        }]
        const customStyle = { top: "1rem", right: "1rem", width: "22.5rem" }
        displayNotificationMessage(message, customStyle, false, false, true, false)
        setPage(NOMODAL)
    }

    const setUserActiveLocation = (seatName: string, commandCenterLocations: ICommandCenter[]) => {
        const loggedInLocation = getCommandCenterLocationName(commandCenterLocations, seatName)
        if (loggedInLocation) {
            setLocalStorageItem(COMMAND_CENTER_LOCATION_NAME, loggedInLocation.commandCenterLocation)
            dispatchToParentStore({ type: GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, userLoggedInLocation: loggedInLocation.commandCenterLocation })
        }

    }

    const computeSubModal = async (initDefaultAccessMode: ELocationSelectionPage | string | null, initCommandCenterLocation: ICommandCenterLocation) => {
        if ((initDefaultAccessMode === null) && checkIfTwoObjectsAreEqual(initCommandCenterLocation, INIT_COMMAND_CENTER_LOCATION) && page === NOMODAL) {
            setPage(ELocationSelectionPage.HARDWARE)
            if (!open) { setOpen(true) }
        } else if ((initDefaultAccessMode === NO_COMMAND_CENTER_LOCATION) && page === NOMODAL && initialized === ECommandCenterAccessMode.INIT && accessModeSet !== EACCESS_MODE_SET.YES) {
            setPage(ELocationSelectionPage.LAUNCH)
            if (!open) { setOpen(true) }
        } else if ((initDefaultAccessMode !== NO_COMMAND_CENTER_LOCATION && initDefaultAccessMode !== null) && checkIfTwoObjectsAreEqual(initCommandCenterLocation, INIT_COMMAND_CENTER_LOCATION) && page !== INPUT && page !== CONFIRM) {
            setPage(ELocationSelectionPage.INPUT)
            if (!open) { setOpen(true) }
        } else if (initDefaultAccessMode !== null && !checkIfTwoObjectsAreEqual(initCommandCenterLocation, INIT_COMMAND_CENTER_LOCATION) && page === CONFIRM) {
            setPage(ELocationSelectionPage.CONFIRM)
            if (!open) { setOpen(true) }
        } else if (initDefaultAccessMode !== null && !checkIfTwoObjectsAreEqual(initCommandCenterLocation, INIT_COMMAND_CENTER_LOCATION)) {
            if (page !== NOMODAL) {
                setPage(ELocationSelectionPage.NOMODAL)
            }
            setActiveSeatname(initCommandCenterLocation, true)

            noModal()
        } else {
            setSeatNameWithoutHardware()
        }
    }
    useEffect(() => {
        if (currentUser.clinicalRole && currentUser.clinicalRole === EClinicalRole.EXPERTUSER) {
            computeSubModal(initDefaultAccessMode, initCommandCenterLocation)
        }
    }, [currentUser, initialized])

    useEffect(() => {
        initDefaultSeats().then((defaultSeats) => {
            setUserActiveLocation(initCommandCenterLocation.seatName, defaultSeats)
        })
    }, [])

    const renderSubModal = () => {
        switch (page) {
            case ELocationSelectionPage.LAUNCH:
                return <SeatLaunchModeComponent
                    onBackClick={() => onLaunchModeBack()}
                    onLaunchClick={() => onLaunchConfirm()}
                />
            case ELocationSelectionPage.HARDWARE:
                return <SeatAccessModeComponent
                    onYesClick={() => onAccessModeConfirm()}
                    onNoClick={() => onAccessModeCancel()}
                />
            case ELocationSelectionPage.INPUT:
                return < SeatVerifyModeComponent
                    onBackClick={backLink}
                    onLaunchClick={onLocationConfirm}
                    onLabelNotFound={() => onAccessModeCancel()}
                    commandCenterLocations={getInputSeats()}
                    showModal={true} />
            case ELocationSelectionPage.CONFIRM:
                return <SeatConfirmModeComponent
                    location={{ seatName: selectedSeatName }}
                    onBackClick={() => setPage(INPUT)}
                    onSubmitClick={() => updateLocation(selectedSeatName)}
                />
            case ELocationSelectionPage.NOMODAL:
            default:
                return noModal()
        }
    }

    return (
        <>
            {renderSubModal()}
        </>
    )

}

export default CommandCenterLocationController
