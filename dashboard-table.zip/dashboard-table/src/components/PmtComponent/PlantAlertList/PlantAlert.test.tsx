import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import PlantAlertList from "./PlantAlertList";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});

describe("PlantAlertList", () => {
	const data = [
		{
			timeStamp: "2023-04-20T09:00:00.000Z",
			assetId: "asset1",
			alertId: "alert1",
			description: "Description 1",
			status: "Active",
			recommendation: "Recommendation 1.1. Recommendation 1.2.",
		},
		{
			timeStamp: "2023-04-20T10:00:00.000Z",
			assetId: "asset2",
			alertId: "alert2",
			description: "Description 2",
			status: "Resolved",
			recommendation: "Recommendation 2.1. Recommendation 2.2.",
		},
	];

	it("should render the component without errors", () => {
		render(<PlantAlertList data={data} plantName={""} />);
	});
});
//   test("renders PlantAlertList component", () => {
//     render(<PlantAlertList data={data} plantName={plantName} />);
//     expect(screen.getByText("PLANT ALERT LIST")).toBeInTheDocument();
//     expect(screen.getByText("Plant1")).toBeInTheDocument();
//     expect(screen.getByText("TIME STAMP")).toBeInTheDocument();
//     expect(screen.getByText("ASSET ID")).toBeInTheDocument();
//     expect(screen.getByText("ALERT ID")).toBeInTheDocument();
//     expect(screen.getByText("ALERT DESCRIPTION")).toBeInTheDocument();
//     expect(screen.getByText("ALERT STATUS")).toBeInTheDocument();
//     expect(screen.getByText("alert1")).toBeInTheDocument();
//     expect(screen.getByText("Description 1")).toBeInTheDocument();
//     expect(screen.getByText("Active")).toBeInTheDocument();
//     expect(
//       screen.getByText(
//         moment("2023-04-20T09:00:00.000Z").format("DD/MM/YYYY HH:MM:SS A")
//       )
//     ).toBeInTheDocument();
//     expect(screen.getByText("alert2")).toBeInTheDocument();
//     expect(screen.getByText("Description 2")).toBeInTheDocument();
//     expect(screen.getByText("Resolved")).toBeInTheDocument();
//     expect(
//       screen.getByText(
//         moment("2023-04-20T10:00:00.000Z").format("DD/MM/YYYY HH:MM:SS A")
//       )
//     ).toBeInTheDocument();
//   });

//   test("formats time stamp correctly", () => {
//     render(<PlantAlertList data={data} plantName={plantName} />);
//     expect(screen.getByText("20/04/2023 09:04:00 AM")).toBeInTheDocument();
//     expect(screen.getByText("20/04/2023 10:04:00 AM")).toBeInTheDocument();
//   });

//   test("renders tooltip with correct content", () => {
//     render(<PlantAlertList data={data} plantName={plantName} />);
//     fireEvent.mouseEnter(screen.getByText("alert1"));
//     expect(screen.getByText("1. Recommendation 1.1")).toBeInTheDocument();
//     expect(screen.getByText("2. Recommendation 1.2.")).toBeInTheDocument();
//   });

//   test("tooltip disappears when mouse leaves", () => {
//     render(<PlantAlertList data={data} plantName={plantName} />);
//     fireEvent.mouseEnter(screen.getByText("alert1"));
//     fireEvent.mouseLeave(screen.getByText("alert1"));
//     expect(screen.queryByText("1. Recommendation 1.1")).not.toBeInTheDocument();
//     expect(
//       screen.queryByText("2. Recommendation 1.2.")
//     ).not.toBeInTheDocument();
//   });
// });
