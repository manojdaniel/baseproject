"""
 Created on Tue Nov 3 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from graphql import GraphQLError

from src.constants.constants import ROCC_SCANNER_RESOURCES
from src.constants.headers import EXCEL_ROOM_EDIT_CONNECTION, EXCEL_ROOM_PHONE_NUMBER, EXCEL_ROOM_SCANNER_DICOM_AE_TITLE, \
    EXCEL_ROOM_SCANNER_MANUFACTURER, EXCEL_ROOM_SCANNER_MODEL, EXCEL_ROOM_SCANNER_NOTES, \
    EXCEL_ROOM_SCANNER_OS, EXCEL_ROOM_SCANNER_OS_VERSION, EXCEL_ROOM_SCANNER_SERIAL_NUMBER, \
    EXCEL_ROOM_SCANNER_SOFTWARE_VERSION, EXCEL_ROOM_SITE_IDENTIFIER, EXCEL_ROOM_IDENTIFIER, EXCEL_ROOM_VIEW_CONNECTION
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import verify_if_rooms_detail_exist

LOG = create_logger("RoomsDataValidationService")


def check_if_rooms_exists(client, room_dict):
    try:
        variable_values = {"site": room_dict[EXCEL_ROOM_SITE_IDENTIFIER],
                           "resource": room_dict[EXCEL_ROOM_IDENTIFIER],
                           }
        variable_values = {
            "resource": room_dict[EXCEL_ROOM_IDENTIFIER],
            "site": room_dict[EXCEL_ROOM_SITE_IDENTIFIER],
            "manufacturer": room_dict[EXCEL_ROOM_SCANNER_MANUFACTURER],
            "software_version": str(room_dict[EXCEL_ROOM_SCANNER_SOFTWARE_VERSION]),
            "os_type": room_dict[EXCEL_ROOM_SCANNER_OS],
            "os_version": str(room_dict[EXCEL_ROOM_SCANNER_OS_VERSION]),
            "model": room_dict[EXCEL_ROOM_SCANNER_MODEL],
            "phone": room_dict[EXCEL_ROOM_PHONE_NUMBER],
            "notes": room_dict[EXCEL_ROOM_SCANNER_NOTES],
            "ae_title": room_dict[EXCEL_ROOM_SCANNER_DICOM_AE_TITLE],
            "tx_name": [room_dict[EXCEL_ROOM_VIEW_CONNECTION], room_dict[EXCEL_ROOM_EDIT_CONNECTION]],
            "tx_type": ["view", "full_control"],
            "serial_no": room_dict[EXCEL_ROOM_SCANNER_SERIAL_NUMBER]
        }
        response = client.execute(verify_if_rooms_detail_exist, variable_values=variable_values)
        return check_if_id_is_present(response, ROCC_SCANNER_RESOURCES)
    except GraphQLError as ge:
        LOG.exception(f"During room data validation, Exception occurred while querying data from graphql with error: {ge}")
    except Exception as ex:
        LOG.exception(f"During room data validation, Exception occurred while parsing data with error: {ex}")
