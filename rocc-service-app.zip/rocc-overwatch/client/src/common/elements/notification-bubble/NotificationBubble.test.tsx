/*
 * Created on Thu Oct 15 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mount, shallow } from "enzyme"
import React from "react"
import NotificationBubble from "./NotificationBubble"


describe("NotificationBubble component", () => {
    let wrapper: any
    let notificationBubbleId: any
    beforeEach(() => {
        wrapper = shallow(<NotificationBubble
            content={""}
            handleDismiss={() => void (0)}
            header={""}
            status={"success"}
        />)
        notificationBubbleId = wrapper.find("#NotificationBubble")
    })
    it("should render with the correct id", () => {
        expect(notificationBubbleId).toHaveLength(1)
    })
    it("should render when status is warning", () => {
        wrapper = mount(<NotificationBubble
            content={""}
            handleDismiss={() => void (0)}
            header={""}
            status={"warning"}
        />)
        expect(wrapper.find(".warning")).toBeDefined()
    })
    it("should render when status is info", () => {
        wrapper = mount(<NotificationBubble
            content={""}
            handleDismiss={() => void (0)}
            header={""}
            status={"info"}
            timeOutValue={1}
        />)
        expect(wrapper.find(".info")).toBeDefined()
    })
    it("should render when status is error", () => {
        wrapper = mount(<NotificationBubble
            content={""}
            handleDismiss={() => void (0)}
            header={""}
            status={"error"}
        />)
        expect(wrapper.find(".error")).toBeDefined()
    })
})
