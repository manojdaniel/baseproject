"""
 Created on Tue Sep 28 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import unittest
from unittest.mock import Mock
from werkzeug.datastructures import ImmutableMultiDict

from src.utility.dict_utils import drill_and_apply, exract_file_from_immutable_object


class DrillDownTestCase(unittest.TestCase):
    def test_drill_and_apply(self):
        exception = []
        mock_function = Mock()
        drill_and_apply([mock_function], {1: "a"}, exception)
        mock_function.assert_called_once()

    def test_exract_file_from_immutable_object(self):
        files = ImmutableMultiDict([("file", "data")])
        data = exract_file_from_immutable_object(files=files, form_field="file")
        self.assertEqual(data, "data")

    def test_exract_file_from_immutable_object_throw_error(self):
        self.assertRaises(Exception,exract_file_from_immutable_object,"files","form_field")
    