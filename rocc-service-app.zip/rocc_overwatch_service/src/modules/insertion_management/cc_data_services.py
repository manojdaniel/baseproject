"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from src.constants.constants import ID, ROCC_CC_RECEIVER_MAPPINGS, ROCC_COMMAND_CENTRE_SEATS, ROCC_RECEIVERS, SITES_DICT, COMMAND_CENTERS_DICT, OBJECTS, RETURNING,  \
    TEMPLATE_DETAILS, TEMPLATE_VERSION_1_0_0, TEMPLATE_VERSION_1_0_6
from src.constants.headers import EXCEL_CC_SEAT_INFO, EXCEL_CC_SEAT_NAME, EXCEL_CC_IP, EXCEL_MONITOR_IDENTIFICATION_LABEL, EXCEL_RECEIVER_SEAT_NAME
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_field_is_present, check_if_id_is_present
from src.wrappers.graphql.mutations.mutations import insert_seats_receivers, insert_receivers_for_existing_cc, update_receiver
from src.wrappers.graphql.queries.queries import verify_if_receiver_present, verify_if_cc_data_exists
from src.constants.enums import ESummaryStates
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.utility.semver import parse_version

LOG = create_logger("CCDataServices")


class CcDataServices:

    def __init__(self, client, org_db_id, data_dict, transaction_data, user_uuid):
        self._org_db_id = org_db_id
        self._client = client
        self._transaction_data = transaction_data
        self._user_uuid = user_uuid
        self._data_dict = data_dict
        self._rcvr_dict = self._data_dict[COMMAND_CENTERS_DICT]
        self._template_version = parse_version(self._data_dict[TEMPLATE_DETAILS]["version"])
        self._sites_dict = self._data_dict[SITES_DICT]

    def execute(self):
        try:
            multi_console_support = parse_version(self._data_dict[TEMPLATE_DETAILS]["version"]) >= parse_version(TEMPLATE_VERSION_1_0_6)
            LOG.info("Initiating TASK: Command center data insertion")
            self.verify_and_insert_records(multi_console_support)
            self._data_dict[COMMAND_CENTERS_DICT] = self._rcvr_dict
            LOG.info("Command Center data insertion complete ..!!")
            return self._data_dict, self._transaction_data

        except Exception as ex:
            LOG.exception("Error in handling receiver data insertion with error: {ex}")
            raise RoccException(500, "Error in handling receiver data insertion")
    

    def handle_multi_console(self, key, cc_object):
        response = self._client.execute(verify_if_cc_data_exists,
                                            variable_values={"seat_name": cc_object[EXCEL_CC_SEAT_NAME],
                                                             "organization_id": self._org_db_id, 
                                                             "receiverName": cc_object[EXCEL_RECEIVER_SEAT_NAME]})
        command_center_id = check_if_id_is_present(data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)
        cc_receiver_mapping_id = check_if_id_is_present(data=response, table_name=ROCC_CC_RECEIVER_MAPPINGS)
        try:
            if cc_receiver_mapping_id:
                receiver_id = check_if_field_is_present(data=response, table_name=ROCC_CC_RECEIVER_MAPPINGS, field_name="receiver_id")
                self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", key, ESummaryStates.EXISTING)
                LOG.info(f"Multi Console: Updating data for CC {cc_object[EXCEL_CC_SEAT_NAME]} and receiver {cc_object[EXCEL_RECEIVER_SEAT_NAME]} since the mapping already exists")
                self._client.execute(update_receiver,
                                        variable_values={
                                        ID: receiver_id,
                                        OBJECTS: self.prepare_update_receiver_object(cc_object)
                                    })

            elif command_center_id and not cc_receiver_mapping_id:
                LOG.info(f"Multi Console: Creating {cc_object[EXCEL_CC_SEAT_NAME]}:::{cc_object[EXCEL_RECEIVER_SEAT_NAME]} mapping since Command Center {cc_object[EXCEL_CC_SEAT_NAME]} is already present in DB.")
                self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", key, ESummaryStates.NEW)
                self._client.execute(insert_receivers_for_existing_cc,
                                    variable_values={OBJECTS: self.prepare_receiver_object_for_existing_cc(
                                                                cc_object, command_center_id
                                                            )})
            else:
                LOG.info(f"Multi Console: Creating complete data for CC {cc_object[EXCEL_CC_SEAT_NAME]} and receiver {cc_object[EXCEL_RECEIVER_SEAT_NAME]}")
                self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", key, ESummaryStates.NEW)
                self._client.execute(insert_seats_receivers, variable_values={OBJECTS: self.prepare_cc_object(cc_object, True)})
        except Exception as ex:
            LOG.error("Multi Console: Exception occured while inserting command center data into db: {}".format(ex))
            LOG.error(traceback.print_exc())
            raise RoccException(500, "Multi Console: Exception occured while inserting data into db: {}".format(ex))
        

    def handle_single_console(self, key, cc_object, new_cc):
        response = self._client.execute(verify_if_receiver_present,
                                                variable_values={"seat_name": cc_object[EXCEL_CC_SEAT_NAME],
                                                                "organization_id": self._org_db_id})
        result = check_if_id_is_present(data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)
        if result:
            self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", key, ESummaryStates.EXISTING)
            LOG.info(f"For Receiver {cc_object[EXCEL_CC_SEAT_NAME]}, skipping data insertion since it is already present")
        else:
            LOG.info(f"Inserting new data into tables rocc_command_centre_seats, rocc_command_centre_receiver_mappings, rocc_command_centre_receiver_mappings")
            self._transaction_data = update_summary_for_entity(self._transaction_data, "cc", key, ESummaryStates.NEW)
            new_cc.append(self.prepare_cc_object(cc_object, False))


    def verify_and_insert_records(self, multi_console_support): 
        new_cc = []
        for key, cc_object in self._rcvr_dict.items():
            if multi_console_support:
                self.handle_multi_console(key=key, cc_object=cc_object)
            else:
                self.handle_single_console(key=key, cc_object=cc_object, new_cc=new_cc)

        if len(new_cc) > 0:
            variables = {OBJECTS: new_cc}
            try:
                self._client.execute(insert_seats_receivers, variable_values=variables)
            except Exception as ex:
                LOG.error("Exception occured while inserting command center data into db: {}".format(ex))
                LOG.error(traceback.print_exc())
                raise RoccException(500, "Exception occured while inserting data into db: {}".format(ex))
    

    def prepare_cc_object(self, cc_object, multi_console_support):
        monitor_name =  "1" if not multi_console_support else str(int(float(cc_object[EXCEL_MONITOR_IDENTIFICATION_LABEL])))
        rc_name_key = EXCEL_CC_SEAT_NAME if self._template_version == parse_version(TEMPLATE_VERSION_1_0_0) else EXCEL_RECEIVER_SEAT_NAME
        new_dict = {
            "organization_id": self._org_db_id,
            "seat_name": cc_object[EXCEL_CC_SEAT_NAME],
            "seat_info": cc_object[EXCEL_CC_SEAT_INFO],
            "created_by": self._user_uuid,
            "modified_by": self._user_uuid,
            "rocc_command_centre_receiver_mappings": {
                "data": [
                    {
                        "created_by": self._user_uuid,
                        "modified_by": self._user_uuid,
                        "rocc_receiver": {
                            "data": {
                                "receiver_ip": cc_object[EXCEL_CC_IP],
                                "receiver_connection_name":cc_object[rc_name_key],
                                "monitor_name": monitor_name,
                                "created_by": self._user_uuid,
                                "modified_by": self._user_uuid
                            }
                        }
                    }

                ]
            }
        }
        return new_dict


    def prepare_receiver_object_for_existing_cc(self, cc_object, command_center_id):
        new_dict = {
            "receiver_connection_name": cc_object[EXCEL_RECEIVER_SEAT_NAME],
            "receiver_ip": cc_object[EXCEL_CC_IP],
            "monitor_name": str(int(float(cc_object[EXCEL_MONITOR_IDENTIFICATION_LABEL]))),
            "created_by": self._user_uuid,
            "modified_by": self._user_uuid,
            "rocc_command_centre_receiver_mappings": {
                "data": {
                    "created_by": self._user_uuid,
                    "modified_by": self._user_uuid,
                    "command_centre_seat_id": command_center_id
                }
            }
        }
        return new_dict
    
    def prepare_update_receiver_object(self, cc_object):
        new_dict = {
            "monitor_name": str(int(float(cc_object[EXCEL_MONITOR_IDENTIFICATION_LABEL]))),
            "receiver_connection_name": cc_object[EXCEL_RECEIVER_SEAT_NAME],
            "receiver_ip": cc_object[EXCEL_CC_IP]
        }
        return new_dict
