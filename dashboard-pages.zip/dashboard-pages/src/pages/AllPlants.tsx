import React, { useRef, useEffect, useState } from "react";
import Status from "components/Status";
import { useDispatch, useSelector } from "react-redux";
import Dropdown from "components/Dropdown";
import ListComponent from "components/ListComponent";
import HealthIndexComponent from "components/HealthIndexComponent";
import { useNavigate } from "react-router-dom";
import NoData from "components/NoData";
import {
	getRegionDropdownList,
	getAffiliateDropdownList,
	getPlantTopBar,
	getPlantDetails,
	getGlobalSelecetedRegion,
	getGlobalSelecetedAffiliate,
	getGlobalSelecetedPlant,
	getPlantDetailsEmpty,
	getPlantAlertStatus,
} from "../redux/reducers/CommonReducer";
import { PMT_ROUTE } from "../constant/constants";
import "./Affiliates.scss";
import Loader from "components/Loader";
import { encryptRSAData } from "../utility/rsa";

const AllPlants = () => {
	let navigate = useNavigate();
	let dispatch = useDispatch();

	const [selectedRegion, setSelectedRegion] = useState<any>({
		value: 0,
		label: "All",
	});
	const [selectedAffiliate, setSelectedAffiliate] = useState<any>();
	const [sortedData, setSortedData] = useState<any>([]);

	const {
		regionDropdownList,
		affiliateDropdownList,
		plantTopBar,
		plantDetails,
		globalSelecetedRegion,
		globalSelecetedAffiliate,
		loadingPlantDetails,
		loadingRegionDropdownList,
		loadingAffiliateDropdownList,
		loadingPlantTopBar,
	} = useSelector((state: any) => ({
		regionDropdownList: state.Common.regionDropdownList,
		affiliateDropdownList: state.Common.affiliateDropdownList,
		plantTopBar: state.Common.plantTopBar,
		plantDetails: state.Common.plantDetails,
		globalSelecetedRegion: state.Common.globalSelecetedRegion,
		globalSelecetedAffiliate: state.Common.globalSelecetedAffiliate,

		loadingPlantDetails: state.Common.loadingPlantDetails,
		loadingRegionDropdownList: state.Common.loadingRegionDropdownList,
		loadingAffiliateDropdownList: state.Common.loadingAffiliateDropdownList,
		loadingPlantTopBar: state.Common.loadingPlantTopBar,
	}));

	useEffect(() => {
		// let data1 = encodeURIComponent(encryptRSAData(`2l-31010/18/22-03-2023/5-06-2026`))
		// let data2 = decryptRSAData(decodeURIComponent(data1))

		if (
			Object.keys(globalSelecetedAffiliate).length > 0 &&
			Object.keys(globalSelecetedRegion).length > 0
		) {
			setSelectedAffiliate(globalSelecetedAffiliate);
			setSelectedRegion(globalSelecetedRegion);
			dispatch(
				getPlantTopBar(
					encryptRSAData(
						`regionId=${globalSelecetedRegion.value}&affiliateId=${globalSelecetedAffiliate.value}`
					)
				)
			); //{regionId}/{affiliateId}/{userid}
			dispatch(
				getPlantDetails(
					encryptRSAData(
						`regionId=${globalSelecetedRegion.value}&affiliateId=${globalSelecetedAffiliate.value}`
					)
				)
			); //{regionId}/{affiliateId}/{userid}
			dispatch(getRegionDropdownList("")); //{userId}
			dispatch(
				getAffiliateDropdownList(
					encryptRSAData(`regionId=${globalSelecetedRegion.value}`)
				)
			); //{regionId}/{userid}
		} else if (Object.keys(globalSelecetedRegion).length > 0) {
			setSelectedRegion(globalSelecetedRegion);
			dispatch(
				getAffiliateDropdownList(
					encryptRSAData(`regionId=${globalSelecetedRegion.value}`)
				)
			); //{regionId}/{userid}
			dispatch(getRegionDropdownList("")); //{userId}
			dispatch(
				getPlantTopBar(
					encryptRSAData(
						`regionId=${globalSelecetedRegion.value}&affiliateId=0`
					)
				)
			); //{regionId}/{affiliateId}
		} else {
			dispatch(getRegionDropdownList("")); //{userId}
			dispatch(getAffiliateDropdownList(encryptRSAData(`regionId=0`))); //{regionId}/{userid}
			dispatch(getPlantTopBar(encryptRSAData(`regionId=0&affiliateId=0`))); //{regionId}/{affiliateId}
			dispatch(getPlantDetailsEmpty("")); //making plant Details Empty
		}
	}, [globalSelecetedAffiliate, globalSelecetedRegion]);

	const handleRegionDropDown = (e: any) => {
		setSelectedRegion(e);
		dispatch(getPlantDetailsEmpty("")); //making plant Details Empty
		setSelectedAffiliate("");
		dispatch(getAffiliateDropdownList(encryptRSAData(`regionId=${e.value}`))); //{regionId}/{userid}
		dispatch(
			getGlobalSelecetedRegion({
				value: e.value,
				label: e.label,
			})
		);
		dispatch(
			getGlobalSelecetedAffiliate("")
		);

	};

	const handleAffiliateDropDown = (e: any) => {
		setSelectedAffiliate(e);
		dispatch(
			getPlantTopBar(
				encryptRSAData(
					`regionId=${selectedRegion.value}&affiliateId=${e.value}`
				)
			)
		); //{regionId}/{affiliateId}/{userid}
		dispatch(
			getPlantDetails(
				encryptRSAData(
					`regionId=${selectedRegion.value}&affiliateId=${e.value}`
				)
			)
		); //{regionId}/{affiliateId}/{userid}
		dispatch(
            getGlobalSelecetedAffiliate({
                value: e.value,
                label: e.label,
            })
        );
	};

	const handleOnClick = (item: any) => {
		dispatch(
			getGlobalSelecetedRegion({
				value: selectedRegion.value,
				label: selectedRegion.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedAffiliate({
				value: selectedAffiliate.value,
				label: selectedAffiliate.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedPlant({ value: item.plantId, label: item.name })
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		navigate("/plant/pmt");
	};

	const navigateActiveUIOIAllPlant = (data: any, item: any, e: any) => {
		if (e && e.stopPropagation) e.stopPropagation();
		dispatch(
			getGlobalSelecetedRegion({
				value: selectedRegion.value,
				label: selectedRegion.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedAffiliate({
				value: selectedAffiliate.value,
				label: selectedAffiliate.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedPlant({ value: item.plantId, label: item.name })
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(getPlantAlertStatus({ value: data, label: data }));
		navigate(`/plant/alertSatistics/alertList`);
	};

	const navigatePMCompliance = (item: any, e: any) => {
		if (e && e.stopPropagation) e.stopPropagation();
		dispatch(
			getGlobalSelecetedRegion({
				value: selectedRegion.value,
				label: selectedRegion.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedAffiliate({
				value: selectedAffiliate.value,
				label: selectedAffiliate.label,
			})
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		dispatch(
			getGlobalSelecetedPlant({ value: item.plantId, label: item.name })
		); // { "value": "2Y-3001A", "label": "2Y-3001A" }
		navigate("/plant/pmCompliance");
	};

	useEffect(() => {
		let list = plantDetails
			.slice()
			.sort((a, b) => b.healthIndex - a.healthIndex);
		setSortedData(list);
	}, [plantDetails]);

	return (
		<>
			{loadingPlantTopBar ? (
				<div className="statusloader"><Loader /></div>
			) : (
				<Status
					data={plantTopBar}
					page={"ALLPLANT"}
					healthIndexToolTip={[]}
					navigateActiveUIOIAllPlant={navigateActiveUIOIAllPlant}
				/>
			)}
			<div id="affilates-page">
				<div id="affilates-left">
					<div className="common-box-inner">
						<div className="title">
							{selectedAffiliate !== undefined &&
								Object.keys(selectedAffiliate).length > 0
								? `${selectedAffiliate.label} PLANTS LIST`
								: "GLOBAL PLANTS LIST"}
						</div>
						<div id="new-filter">
							<div className="nf-left">
								<div className="subtext-name">
									Click on the Plant to get more details
								</div>
							</div>
							<div className="nf-right">
								<div>
									<label className="cus-label">Region</label>
									<Dropdown
										name={"Select Region"}
										options={regionDropdownList}
										handleChange={handleRegionDropDown}
										defaultValue={""}
										value={selectedRegion}
										loading={loadingRegionDropdownList}
									/>
								</div>
								<div>
									<label className="cus-label">Affiliate</label>
									<Dropdown
										name={"Select Affiliate"}
										options={affiliateDropdownList}
										handleChange={handleAffiliateDropDown}
										defaultValue={""}
										value={selectedAffiliate}
										loading={loadingAffiliateDropdownList}
									/>
								</div>
							</div>
						</div>
						<div className="affilates-box">
							{loadingPlantDetails ? (
								<div className="fullloader"><Loader /></div>
								) : plantDetails.length === 0 ? (
									<div className="tc-loaderpd">
										<NoData />
									</div>
								) : (

								<>
									{plantDetails.map((item: any) => (
										<ListComponent
											item={item}
											handleOnClick={handleOnClick}
											title={"PLANT"}
											navigateActiveUIOIAllPlant={navigateActiveUIOIAllPlant}
											navigatePMCompliance={navigatePMCompliance}
										/>
									))}

								</>
								
							)}
						</div>
					</div>
				</div>
				<div id="affilates-right">
					<div className="common-box-inner">
						<div className="common-box-filter">
							<div className="title">PLANTS HEALTH INDEX</div>
						</div>
						<div className="common-box-asset-name custheight-list">
							<div className="asset-name">
								Click on the Plant to get more details
							</div>
						</div>
						<div className="affilates-box">
							{loadingPlantDetails ? (
								<div className="fullloader"><Loader /></div>
								) : sortedData.length === 0 ? (
									<div className="tc-loaderpd">
										<NoData />
									</div>
								) : (
								<>
									{sortedData.map((item: any) => (
										<HealthIndexComponent item={item} title={"PLANT"} />
									))}
								</>
							)}
						</div>
					</div>
				</div>
			</div>
		</>
	);
};
export default AllPlants;

{
	/* <div>{searchValue.id}</div> */
}

// useEffect(() => {
//     if (Object.keys(globalSelecetedAffiliate).length == 0) {
//         dispatch(getRegionDropdownList("18"));//{userId}
//         dispatch(getPlantTopBar("0/0/18")); //{regionId}/{affiliateId}/{userid}
//     }
// }, []);

// useEffect(() => {
//     // Setting global value to local region useState on first load
//     if (Object.keys(globalSelecetedRegion).length > 0) {
//         setSelectedRegion(globalSelecetedRegion)
//         dispatch(getAffiliateDropdownList(`${globalSelecetedRegion.value}/18`));//{regionId}/{userid}
//     }
// }, [globalSelecetedRegion]);

// useEffect(() => {
//     // Setting global value to local region useState
//     if (Object.keys(globalSelecetedAffiliate).length > 0) {
//         setSelectedAffiliate(globalSelecetedAffiliate)
//         dispatch(getPlantTopBar(`${globalSelecetedRegion.value}/${globalSelecetedAffiliate.value}/18`)); //{regionId}/{affiliateId}/{userid}
//         dispatch(getPlantDetails(`${globalSelecetedRegion.value}/${globalSelecetedAffiliate.value}/18`));//{regionId}/{affiliateId}/{userid}
//     }
// }, [globalSelecetedAffiliate]);
