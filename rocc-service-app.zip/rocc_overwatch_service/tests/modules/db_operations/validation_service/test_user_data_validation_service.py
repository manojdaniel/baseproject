import unittest
from src.modules.db_operations.validation_service.user_data_validation_service import verify_if_user_exists

class UserDataValidationTest(unittest.TestCase):
    def test_verify_if_user_exists(self):
        sites = {
            "Additional functionality for Expert user":"GlobalHealth",
            "Role":"admin",
            "First Name":"abc",
            "Last Name":"Last Name",
            "Email ID /Unique ID":"xyx@abc.com",
            "Multiple Hospital/DIC Identifier Employee Belongs To( To be filled by Philips)":"abc",
            "Phone Number (with Country code)":"91+",
            "Modality (CT or MR)":"ct"

        }
        metasites = verify_if_user_exists({},sites)
        self.assertIsNone(metasites)
