/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { alreadyOnCall } from "./AlreadyOnCall"

jest.useFakeTimers()

jest.mock("../../../../../redux/store/store", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/store")
    return {
        ...actualFn,
        getState: jest.fn().mockImplementation(() => ({
            callReducer: {
                videoCallStatus: [{ callStatus: ECallStatus.RINGING, contextId: "contextId" }],
                callDetails: {
                    connectedCallDetails: {
                        contextId: "contextId",
                        participants: [{
                            uuid: "uuid"
                        }],
                        callAcceptedTime: Date.now(),
                    },
                    incomingCall: {
                        contextId: "incomingContextId",
                        participant: {
                            uuid: "uuid",
                        }
                    },
                }
            },
            externalReducer: {
                currentUser: {
                    uuid: "uuid"
                }
            }

        }))
    }
})

const dispatch = jest.fn()

describe("AlreadyOnCall tests", () => {
    it("handle participant already on call scenario", () => {
        alreadyOnCall({ contextId: "contextId", dispatch, participant: "uuid" })
        jest.runAllTimers()
    })
})
