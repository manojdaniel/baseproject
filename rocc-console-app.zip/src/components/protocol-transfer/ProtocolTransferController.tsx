/*
 * Created on Tues Nov 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Grid, Icon, Segment } from "semantic-ui-react"
import ProtocolTransfer from "./ProtocolTransfer"
import styles from "./ProtocolTransferController.scss"
import { useSelector } from "react-redux"
import { EProtocolTransferSteps, IStore } from "../../redux/interfaces/types"
import { EConnectionType, getLocationDetailsForId, getRoomDetailFromUuid, IConsoleSession } from "@rocc/rocc-client-services"
import { fetchGlobalLocations, fetchRooms } from "../../redux/store/externalAppStates"
import { checkForProtocolTransferConnection } from "../../common/helpers/helpers"
import en from "../../resources/translations/en-US"
import { getIntlProvider } from "@rocc/rocc-global-components"
import ProtocolTransferActiveSession from "./protocol-transfer-active-session/ProtocolTransferActiveSession"
import cx from "classnames"
import { displayLoader } from "../../common/helpers/consoleUtility"

const ProtocolTransferController = () => {
    const {
        protocolTransferStatus, activeConsoleSessions, protocolTransferStep, protocolTransferExitInProgress, selectedSource, selectedDestination, consoleOperation, displayRightSidePanel
    } = useSelector((state: IStore) => ({
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        protocolTransferStep: state.protocolTransferReducer.currentStep,
        protocolTransferExitInProgress: state.protocolTransferReducer.protocolTransferExitInProgress,
        selectedSource: state.protocolTransferReducer.selectedSource,
        selectedDestination: state.protocolTransferReducer.selectedDestination,
        activeConsoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        displayRightSidePanel: state.externalReducer.displayRightSidePanel
    }))
    const locations = fetchGlobalLocations()
    const rooms = fetchRooms()
    const { intl } = getIntlProvider()

    const { FULL_CONTROL, FULL_CONTROL_USB, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, VIEW } = EConnectionType

    const getEditingConsoleMessage = () => {
        const session = activeConsoleSessions && activeConsoleSessions.filter((session: IConsoleSession) => session.connectionType === EConnectionType.FULL_CONTROL_USB)
        const details = getRoomDetails(session[0])
        return (
            <div className={cx(styles.roomBannerHeader, displayRightSidePanel && styles.protocolTransferwithSidePanel)}>
                <Segment className={styles.protocolTransferBanner}>
                    <div>
                        {protocolTransferBannerIconAndMessage()}{" "}
                        {details.name}{" "}
                        {intl.formatMessage({ id: "content.room.roomBannerPart2", defaultMessage: en["content.room.roomBannerPart2"] })}{" "}
                        {details.address}{" "}
                        {intl.formatMessage({ id: "content.roomBanner.message", defaultMessage: en["content.roomBanner.message"] })}{" "}
                        {details.location}.
                    </div>
                </Segment>
            </div>
        )
    }

    const protocolTransferBannerIconAndMessage = () => {
        return (
            <>
                <Icon className={"icon ExclamationMarkCircle medium"} />
                {protocolTransferStatus &&
                    intl.formatMessage({ id: "content.protocolTranfer.bannerMessage", defaultMessage: en["content.protocolTranfer.bannerMessage"] })
                }
            </>
        )
    }

    const checkProtocolTransferStep = () => {
        return protocolTransferExitInProgress || protocolTransferStep === EProtocolTransferSteps.ConnectToSourceScanner
            || protocolTransferStep === EProtocolTransferSteps.ConnectToDestinationScanner
    }

    const getRoomDetails = (activeSession: IConsoleSession) => {
        const roomDetails = { name: "", address: "", location: "" }
        const roomUuid = activeSession.roomUuid
        const details = getRoomDetailFromUuid(rooms, roomUuid)
        roomDetails.name = details.identity.name.concat(roomDetails.name)
        roomDetails.address = details.address
        roomDetails.location = getLocationDetailsForId(locations, details.locationId).name
        return roomDetails
    }


    const displayConnectionLoader = () => (
        (protocolTransferStatus || protocolTransferExitInProgress) && consoleOperation.transactions?.length > 0 ?
            displayLoader(true, checkProtocolTransferStep() ?
                <>
                    {intl.formatMessage({ id: "content.protocolTransfer.consoleDisconnecting", defaultMessage: en["content.protocolTransfer.consoleDisconnecting"] })}
                    <br /><br />
                    {intl.formatMessage({ id: "content.protocolTransfer.consoleDisconnectionWarning", defaultMessage: en["content.protocolTransfer.consoleDisconnectionWarning"] })}
                </>
                :
                <>
                    {intl.formatMessage({ id: "content.protocolTransfer.consoleConnecting", defaultMessage: en["content.protocolTransfer.consoleConnecting"] })}
                    <br /><br />
                    {intl.formatMessage({ id: "content.protocolTransfer.consoleConnectionWarning", defaultMessage: en["content.protocolTransfer.consoleConnectionWarning"] })}
                </>

            )
            :
            null)

    const protocolTransferGridRow = () => {
        return protocolTransferStatus ? <Grid.Row className={cx(styles.protocolTransfer, displayRightSidePanel && styles.protocolTransferwithSidePanel)} ><ProtocolTransfer /></Grid.Row > : null
    }

    const checkConsoleSession = () => {
        const activeSession = activeConsoleSessions.find((consoleSession) =>
            [FULL_CONTROL, FULL_CONTROL_USB, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, VIEW].includes(consoleSession.connectionType))
        return activeSession
    }

    const protocolTransferSessionActive = () => { return protocolTransferStatus && checkProtocolTransferStep() }

    const protocolTransferActiveSessionGrid = () => {
        return protocolTransferSessionActive() ?
            <Grid.Row centered={true} className={cx(styles.protocolTransferActiveSessionGridRow, displayRightSidePanel && styles.protocolTransferwithSidePanel)}>
                <Grid.Column className={styles.protocolTransferActiveSessionGridColumn}>
                    <ProtocolTransferActiveSession locations={locations} protocolTransferStep={protocolTransferStep} sourceScanner={selectedSource} destinationScanner={selectedDestination} />
                </Grid.Column>
            </Grid.Row>
            :
            null
    }

    return (
        <>
            {checkForProtocolTransferConnection() && getEditingConsoleMessage()}
            {displayConnectionLoader()}
            {protocolTransferGridRow()}
            {checkConsoleSession() && protocolTransferActiveSessionGrid()}
        </>
    )
}

export default ProtocolTransferController
