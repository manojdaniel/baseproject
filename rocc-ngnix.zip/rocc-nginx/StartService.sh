#!/bin/bash
#Set environment variable for resolver
from_os="`grep nameserver /etc/resolv.conf`"
nameserver_from_os="$(echo $from_os | cut -d' ' -f2)"
echo "name server is --> "$nameserver_from_os
if [ -z "$nameserver_from_os" ]
then
      echo "nameserver is empty"
      sed -i "s,ROCC_NAME_SERVER,127.0.0.1,g" /etc/nginx/nginx.conf
else
      echo "nameserver is NOT empty"
      sed -i "s,ROCC_NAME_SERVER,$nameserver_from_os,g" /etc/nginx/nginx.conf
fi

#run rusty
echo "running openresty --- "
nginx -g "daemon off;"
