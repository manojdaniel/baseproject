// const HtmlWebPackPlugin = require("html-webpack-plugin");
// const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
// const path = require("path")
// const InterpolateHtmlPlugin = require("interpolate-html-plugin")
// const deps = require("./package.json").dependencies;
// const webpack = require("webpack")
// const getConfig = require('./config')


// module.exports = (env) => {
//   const environment = env.system === 'prod' ? 'prod' : env.system === 'qa' ? 'qa' : env.system === 'dev' ? 'dev' : 'local';
//   const outputPath = `./build/${env.system}/dist`;
//   return {

//     output: {
//       path: path.resolve(__dirname, outputPath),
//     },
//     resolve: {
//       extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
//     },


//     module: {
//       rules: [
//         {
//           test: /\.m?js/,
//           type: "javascript/auto",
//           resolve: {
//             fullySpecified: false,
//           },
//         },
//         {
//           test: /\.(css|s[ac]ss)$/i,
//           use: ["style-loader", "css-loader", "sass-loader"],
//         },
//         {
//           test: /\.(png|jp(e*)g|svg|gif)$/,
//           exclude: /(node_modules)/,
//           use: ["url-loader"],
//         },
//         {
//           test: /\.(ico)$/,
//           exclude: /node_modules/,
//           use: ["file-loader?name=[name].[ext]"]
//         },
//         {
//           test: /\.(ts|tsx|js|jsx)$/,
//           exclude: /node_modules/,
//           use: {
//             loader: "babel-loader",
//           },

//         },
//         { test: /\.json$/, loader: 'json-loader' },
//       ],
//     },

//     plugins: [
//       new webpack.DefinePlugin({
//         CONFIG: JSON.stringify(getConfig(process, environment)),
//         // 'process.env.NODE_ENV': JSON.stringify(environment),
//       }),
//       new ModuleFederationPlugin({
//         name: "sabic-dashboard",
//         filename: "remoteEntry.js",
//         remotes: {
//           components: `components@${getConfig(process, environment).REACT_COMPONENT}remoteEntry.js`,
//           table: `table@${getConfig(process, environment).REACT_TABLE}remoteEntry.js`,
//           charts: `charts@${getConfig(process, environment).REACT_CHART}remoteEntry.js`,

//         },
//         exposes: {},
//         shared: {
//           ...deps,
//           react: {
//             singleton: true,
//             requiredVersion: deps.react,
//           },
//           "react-dom": {
//             singleton: true,
//             requiredVersion: deps["react-dom"],
//           },
//         },
//       }),
//       new InterpolateHtmlPlugin({
//         PUBLIC_URL: '' // can modify `static` to another name or get it from `process`
//       }),
//       new HtmlWebPackPlugin({
//         template: "./src/index.html",
//         favicon: './src/assets/images/sabic-favicon.png',
//       }),

//     ],
//   }
// };

const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const path = require("path")
const deps = require("./package.json").dependencies;
const webpack = require('webpack'); // only add this if you don't have yet

require('dotenv').config({ path: './.env' });

const component = `${process.env.REACT_COMPONENT}`
const chart = `${process.env.REACT_CHART}`
const table = `${process.env.REACT_TABLE}`

module.exports = {

  resolve: {
    extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
  },


  module: {
    rules: [
      {
        test: /\.m?js/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false,
        },
      },
      {
        test: /\.(css|s[ac]ss)$/i,
        use: ["style-loader", "css-loader", "sass-loader"],
      },
      {
        test: /\.(png|jp(e*)g|svg|gif)$/,
        exclude: /(node_modules)/,
        use: ["url-loader"],
      },
      {
        test: /\.(ts|tsx|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
        },
      },
    ],
  },

  plugins: [
    new ModuleFederationPlugin({
      name: "sabic-dashboard",
      filename: "remoteEntry.js",
      remotes: {
        components: `components@${component}remoteEntry.js`,
        table: `table@${table}remoteEntry.js`,
        charts: `charts@${chart}remoteEntry.js`,

      },
      exposes: {},
      shared: {
        ...deps,
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
      },
    }),
    new HtmlWebPackPlugin({
      template: "./src/index.html",
      favicon: './src/assets/images/sabic-favicon.png',
    }),
    new webpack.DefinePlugin({
      "process.env": JSON.stringify(process.env),
    }),
  ]
};
