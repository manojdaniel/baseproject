/*
 * Created on Thu Apr 28 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import RoomMonitoring from "./RoomMonitoring"
import { shallow } from "enzyme"

jest.mock("../../redux/store/syncSessions", () => ({
    __esModule: true,
    default: {
        postMessage: jest.fn().mockReturnValue({})
    }
}))

jest.mock(("react-router"), () => {
    return { withRouter: (component: any) => (component) }
})

describe("RoomMonitoring", () => {
    let wrapper: any
    let roomMonitoringId: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        wrapper = shallow(<RoomMonitoring />)
        roomMonitoringId = wrapper.find("#roomMonitoring")
        mockUseEffect()
    })
    it("should render with the correct id", () => {
        expect(roomMonitoringId).toHaveLength(1)
    })

    it("should render div", () => {
        expect(wrapper.find("div")).toHaveLength(4)
    })
})
