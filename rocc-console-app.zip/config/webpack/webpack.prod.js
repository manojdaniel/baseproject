/*
 * Created on Mon Aug 1 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

const { merge } = require("webpack-merge")
const common = require("./webpack.common.js")
const SourceMapDevToolPlugin = require("webpack").SourceMapDevToolPlugin
const CompressionPlugin = require("compression-webpack-plugin")

module.exports = (env) => merge(common, {
  mode: "production",
  plugins: [
    new CompressionPlugin({
      algorithm: "gzip",
    }),
    new SourceMapDevToolPlugin({
      filename: env.publicPath + "[file].map",
      publicPath: "",
      exclude : [/console_vendors.*/]
    })
  ]
})
