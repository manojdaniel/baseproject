/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import thunk from "redux-thunk"
import * as Redux from "react-redux"
import configureMockStore from "redux-mock-store"
import React from "react"
import WebToPhoneCall from "./WebToPhoneCall"
import { withHooks } from "jest-react-hooks-shallow"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn(),
}))

let store: any
let wrapper: any
let useSelectorSpy: jest.SpyInstance
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
let mockAppState: any
const externalReducer: any = {
    currentUser: { accessToken: "accessToken", uuid: "uuid" },
}
let callWindow: any

jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValue({ EDGE_LOCATION: "gll" })
}))

jest.mock("../../services/callServices", () => ({
    audioCallService: jest.fn().mockReturnValue({
        success: true, data: { capabilityToken: "capabilityToken", contextId: "contextId" }
    })
}))

describe("WebToPhoneCall tests when call status is Idle", () => {
    beforeEach(() => {
        useSelectorSpy = jest.spyOn(Redux, "useSelector")
        mockAppState = {
            callReducer: {
                phoneCallStatus: ECallStatus.IDLE,
                recipient: { ...DEFAULT_CONTACT_INFO, uuid: "uuid", phoneNumber: "+91123456789" },
            },
            externalReducer,
        }
        store = mockStore(mockAppState)
        useSelectorSpy.mockImplementation(cb => {
            return cb(store.getState())
        })
        wrapper = shallow(<WebToPhoneCall />)
        callWindow = wrapper.find("IntermediateCallWindow")
    })

    it("should render CallWindow", () => {
        expect(callWindow).toHaveLength(1)
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("WebToPhoneCall tests when call status is Calling and test useEffect", () => {
    beforeEach(() => {
        useSelectorSpy = jest.spyOn(Redux, "useSelector")
        mockAppState = {
            callReducer: {
                phoneCallStatus: ECallStatus.CALLING,
                recipient: { ...DEFAULT_CONTACT_INFO, uuid: "uuid", phoneNumber: "+91123456789" },
            },
            externalReducer,
        }
        store = mockStore(mockAppState)
        useSelectorSpy.mockImplementation(cb => {
            return cb(store.getState())
        })
    })
    it("should render CallWindow and call initiatePhoneCall", () => {
        withHooks(() => {
            wrapper = shallow(<WebToPhoneCall />)
            callWindow = wrapper.find("IntermediateCallWindow")
            expect(callWindow).toHaveLength(1)
            const additionalComponent = callWindow.props("additionalComponent").additionalComponent
            const disconnectCall = additionalComponent().props.onClick()
            expect(disconnectCall).toBeDefined()
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
