import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import MyTaskTable from "./MyTaskTable";

jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});

jest.mock("antd/es/typography/Link", () => {
	return ({ children }: { children: React.ReactNode }) => {
		return <a href="#">{children}</a>;
	};
});
describe("MyTaskTable", () => {
	const data = [
		{
			AlertID: 1,
			Affiliate: "Some affiliate",
			Plant: "Some plant",
			AssetID: "Some asset ID",
			AnomolyType: "Some anomoly type",
			LongLeadAction: "Some long lead action",
			TaskAssignedTo: "Some task assignee",
			TimeStamp: new Date(),
			Open: "Some open text",
		},
		{
			AlertID: 2,
			Affiliate: "Another affiliate",
			Plant: "Another plant",
			AssetID: "Another asset ID",
			AnomolyType: "Another anomoly type",
			LongLeadAction: "Another long lead action",
			TaskAssignedTo: "Another task assignee",
			TimeStamp: new Date(),
			Open: "Another open text",
		},
	];

	//   beforeEach(() => {
	//     jest.clearAllMocks();
	//   });
	it("should render the component without errors", () => {
		render(<MyTaskTable data={data} />);
	});
});
