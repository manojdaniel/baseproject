import React, { useRef, useEffect, useState } from "react";
import Closed from "./Profile/Closed";
import Pending from "./Profile/Pending";
import Inbox from "./Profile/Inbox";
import Active from "./Profile/Active";
import "./UserProfile.scss";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getEmployeeList, userProfileActive } from "../redux/reducers/CommonReducer";
import { encryptRSAData } from "../utility/rsa";
import iconProfile from "../assets/images/icon_Profile_square.svg";


interface Props {
	buttonName: string;
	onClickHandler: any;
}

const UserProfile = () => {
	const location = useLocation();
	let dispatch = useDispatch();
	const { loggedInUserDetails, userName, userRole, userEmail, employeeList } =
		useSelector((state: any) => ({
			loggedInUserDetails: state.Common.loggedInUserDetails,
			userName: state.Common.userName,
			userRole: state.Common.userRole,
			userEmail: state.Common.userEmail,
			employeeList: state.Common.employeeList,
		}));

	const [userInfo, setUserInfo] = useState<any>([]);
	// useEffect(() => {
	//     if (Object.keys(loggedInUserDetails).length > 0) {
	//         if (loggedInUserDetails.result !== null) {
	//             let res = loggedInUserDetails.result;
	//             setUserInfo(res)
	//         }

	//     }
	// }, [userInfo, loggedInUserDetails]);

	useEffect(() => {
		if (userEmail !== "") {
			dispatch(getEmployeeList(encryptRSAData(`search=${userEmail}`)));
		}
	}, [loggedInUserDetails]);
	const userData = {
		username: "SRIRAMDAS VIJAY",
		userdesignation: "Sr. Web Designer",
		userlocation: "Yanpet",
		useremail: "VijayS@sabic.com",
		userphone: "7386424444",
	};

	const DATA = [
		{ id: "INBOX", value: "INBOX", datacount: "4" },
		{ id: "ACTIVE", value: "ACTIVE", datacount: "3" },
		{ id: "PENDING", value: "PENDING", datacount: "2" },
		{ id: "CLOSED", value: "CLOSED", datacount: "0" },
	];

	const [elements, setElements] = useState(DATA);
	// const [getUserProfileInfo, setUserProfileInfo] = useState(`${location.state.data}`);
	// useEffect(() => {
	//     setSelectedID(`${location.state.data}`);
	// }, [location.state.data]);

	const [selectedID, setSelectedID] = useState(`INBOX`); // you could set a default id as well

	const handleClick = (id: any) => {
		setSelectedID(id)
		dispatch(userProfileActive(id));
	};

	useEffect(() => {
		try {
			if (location.state.data !== undefined) {
				setSelectedID(location.state.data);
			}
		} catch (error) {

		}
	}, [location.state]);

	// useEffect(() => {
	// 	dispatch(userProfileActive(`${selectedID}`));
	// }, [selectedID]);

	const getSelectedclassName = (id: any) => selectedID === id ? "selected" : "";

	const TopContainer = () => {
		return (
			<div className="user-profile-tabs">
				{elements.map((el) => (
					<div
						key={el.id}
						id={el.id}
						className={`top-container-conten ${getSelectedclassName(el.id)}`}
						onClick={() => handleClick(el.id)}
					>
						{el.value}
						{/* <span style={{float: "right"}}>{el.datacount}</span> */}
					</div>
				))}
			</div>
		);
	};

	const renderStep = () => {
		switch (selectedID) {
			case "INBOX":
				return <Inbox />;
			case "ACTIVE":
				return <Active />;
			case "PENDING":
				return <Pending />;
			case "CLOSED":
				return <Closed />;
			default:
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	return (
		<div id="userprofile-page">
			<div className="userProfile-left">
				<div className="common-box-inner">
					<div className="common-box-filter">
						<div className="title usertitlegap">USER INFORMATION</div>
					</div>
					<div className="user-row-box">
						<div className="user-pic">
							<span>
								<img
									src={`https://mail.sabic.com/ews/exchange.asmx/s/GetUserPhoto?email=${userEmail}&size=HR240x240`}
									onError={({ currentTarget }) => {
										currentTarget.onerror = null; // prevents looping
										currentTarget.src = `${iconProfile}`;
									}}
								/>
							</span>
						</div>
						<div className="user-row first-row">
							{/* <div>{loggedInUserDetails.result.userName !=="" || null ? loggedInUserDetails.result.userName : ""}</div> */}
							<div>USER NAME</div>
							<div>{userName}</div>
						</div>
						<div className="user-row">
							<div>USER LOCATION</div>
							{employeeList.length > 0 ? (
								<div>{employeeList[0].location}</div>
							) : null}
						</div>
						<div className="user-row">
							<div>USER EMAIL</div>
							<div>{userEmail}</div>
						</div>

						<div className="user-row last-user-row">
							<div>USER PHONE NUMBER</div>
							{employeeList.length > 0 ? (
								<div>{employeeList[0].contactNo}</div>
							) : null}
							{/* <div>{userInfo.phoneNumber}</div> */}
						</div>
					</div>
				</div>
			</div>
			<div className="userProfile-right">
				<div className="common-box-inner">
					<div className="common-box-filter">
						<div className="title usertitlegap">USER ACTIVITIES</div>
					</div>
					<div id="content-affiliates" style={{ top: "0px" }}>
						<TopContainer />
						{/* {renderStep()} */}
					</div>
				</div>
			</div>
		</div>
	);
};

export default UserProfile;
