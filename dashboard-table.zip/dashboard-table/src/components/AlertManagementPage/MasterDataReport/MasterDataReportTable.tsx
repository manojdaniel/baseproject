import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { Excel } from "antd-table-saveas-excel";
import "../../../assets/common/CommonTables.scss";
import moment from "moment";
import "../alertmanagement-table.scss";

interface Props {
	data: any[];
	loading: any;
}
const MasterDataReportTable = ({ data, loading }: Props) => {
	// Time Formate work :Start
	const [masterdatareport, setmasterdatareport] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);

		let mydata = data.map(function (item: any) {
			return {
				AssetTag: item.assestTag,
				AssetName: item.assetName,
				AlertNumber: item.alertNumber,
				Affiliate: item.affiliate,
				Plant: item.plant,
				AlertType: item.alertType,
				TimeStamp: moment(new Date(`${item.time_stamp}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				ActionOverdue: item.actionOverdue,
				AssignedTo: item.assignedTo,
				CurrentStage: item.currentStage,
				OpenDate: moment(new Date(`${item.openDate}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				EndDate: moment(new Date(`${item.endDate}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				// AnomolyFeedback: item.AnomolyFeedback,
				Stage: item.state,
				Ticket: item.ticket,
				Ageing: item.ageing,
				SensorGroup: item.sensorGroup,
			};
		});
		setmasterdatareport(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "ASSET TAG",
			dataIndex: "assestTag",
			key: "AssetTag",
			width: "100",
		},
		{
			title: "ASSET NAME",
			dataIndex: "AssetName",
			key: "AssetName",
			width: "100",
		},
		{
			title: "ALERT NUMBER",
			dataIndex: "AlertNumber",
			key: "AlertNumber",
			width: "100",
		},
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: "100",
		},
		{
			title: "PLANT",
			dataIndex: "Plant",
			key: "Plant",
			width: "100",
		},
		{
			title: "ALERT TYPE ",
			dataIndex: "AlertType",
			key: "AlertType",
			width: "100",
		},
		{
			title: "TIME STAMP",
			dataIndex: "TimeStamp",
			key: "TimeStamp",
			width: "100",
		},

		{
			title: "ACTIVE OVERDUE ",
			dataIndex: "ActionOverdue",
			key: "ActionOverdue",
			width: "100",
		},
		{
			title: "ASSIGNED TO",
			dataIndex: "AssignedTo",
			key: "AssignedTo",
			width: "100",
		},
		{
			title: "CURRENT STAGE",
			dataIndex: "CurrentStage",
			key: "CurrentStage",
			width: "100",
		},
		{
			title: "OPEN DATE",
			dataIndex: "OpenDate",
			key: "OpenDate",
			width: "100",
		},
		{
			title: "END DATE",
			dataIndex: "EndDate",
			key: "EndDate",
			width: "100",
		},
		{
			title: "STAGE",
			dataIndex: "Stage",
			key: "Stage",
			width: "100",
		},
		{
			title: "TICKET",
			dataIndex: "Ticket",
			key: "Ticket",
			width: "100",
		},
		{
			title: "AGEING",
			dataIndex: "Ageing",
			key: "Ageing",
			width: "100",
		},
		{
			title: "SENSOR GROUP",
			dataIndex: "SensorGroup",
			key: "SensorGroup",
			width: "100",
		},
	];

	const mobileColumns = [
		{
			title: "ASSET TAG",
			dataIndex: "assestTag",
			key: "AssetTag",
			width: 100,
		},
		{
			title: "ASSET NAME",
			dataIndex: "AssetName",
			key: "AssetName",
			width: 100,
		},
		{
			title: "ALERT NUMBER",
			dataIndex: "AlertNumber",
			key: "AlertNumber",
			width: 100,
		},
		{
			title: "AFFILIATE",
			dataIndex: "Affiliate",
			key: "Affiliate",
			width: 100,
		},
		{
			title: "PLANT",
			dataIndex: "Plant",
			key: "Plant",
			width: 100,
		},
		{
			title: "ALERT TYPE ",
			dataIndex: "AlertType",
			key: "AlertType",
			width: 75,
		},
		{
			title: "TIME STAMP",
			dataIndex: "TimeStamp",
			key: "TimeStamp",
			width: 90,
		},

		{
			title: "ACTIVE OVERDUE ",
			dataIndex: "ActionOverdue",
			key: "ActionOverdue",
			width: 70,
		},
		{
			title: "ASSIGNED TO",
			dataIndex: "AssignedTo",
			key: "AssignedTo",
			width: 100,
		},
		{
			title: "CURRENT STAGE",
			dataIndex: "CurrentStage",
			key: "CurrentStage",
			width: 100,
		},
		{
			title: "OPEN DATE",
			dataIndex: "OpenDate",
			key: "OpenDate",
			width: 90,
		},
		{
			title: "END DATE",
			dataIndex: "EndDate",
			key: "EndDate",
			width: 90,
		},
		{
			title: "STAGE",
			dataIndex: "Stage",
			key: "Stage",
			width: 70,
		},
		{
			title: "TICKET",
			dataIndex: "Ticket",
			key: "Ticket",
			width: 70,
		},
		{
			title: "AGEING",
			dataIndex: "Ageing",
			key: "Ageing",
			width: 70,
		},
		{
			title: "SENSOR GROUP",
			dataIndex: "SensorGroup",
			key: "SensorGroup",
			width: 100,
		},
	];

	//master TableExcel: Start=============
	const handleClickMasterReport = () => {
		const excel = new Excel();
		excel
			.addSheet("test")
			.addColumns(columns)
			.addDataSource(masterdatareport, {
				str2Percent: true,
			})
			.saveAs("MasterTableExcel.xlsx");
	};

	return (
		<div id="masterdatareport-table">
			<button
				className="alerttablebuttons"
				onClick={handleClickMasterReport}
				style={{ display: "none" }}
				id="handleClickMasterReport"
			>
				EXPORT TO EXCEL
			</button>

			{(() => {
				if (currentScreenWidth > 1300 && currentScreenWidth < 1800) {
					return (
						<Table
							loading={loading}
							tableLayout={undefined}
							columns={columns}
							dataSource={masterdatareport}
							pagination={{ pageSize: 10, showSizeChanger: false }}
							scroll={{ x: "100vw", y: 300 }}
						/>
					);
				} else if (currentScreenWidth > 1800) {
					return (
						<Table
							loading={loading}
							tableLayout="fixed"
							columns={columns}
							dataSource={masterdatareport}
							pagination={{ pageSize: 10, showSizeChanger: false }}
						/>
					);
				} else if (currentScreenWidth < 1300) {
					return (
						<Table
							loading={loading}
							tableLayout={undefined}
							scroll={{ x: "100vw", y: 300 }}
							columns={mobileColumns}
							dataSource={masterdatareport}
							pagination={{ pageSize: 10, showSizeChanger: false }}
						/>
					);
				}
			})()}
		</div>
	);
};

export default MasterDataReportTable;
