/*
 * Created on Mon Oct 10 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ChildAppsSetup from "./ChildAppsSetup"
import { mount } from "enzyme"
import { RoccChatClient } from "@rocc/rocc-chat-library"
import { EResponse } from "@rocc/rocc-client-services"

jest.mock("@virgilsecurity/e3kit-browser", () => ({
    EThree: jest.fn()
}))
jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalCurrentUser: () => ({ uuid: "", accessToken: "" }),
    fetchGlobalURLs: () => ({ COMMUNICATION_SERVICES_URL: "" }),
}))
jest.mock("./chatServices", () => ({
    fetchCommunicationToken: () => ({ status: EResponse.SUCCESS, tokenDetails: { communicationToken: "", channelSid: "" } }),
}))
jest.mock("react-redux", () => ({
    useSelector: () => ({
        chatClient: {} as RoccChatClient,
        applicationConnectionState: "ONLINE",
        forceCleanUp: false,
        featureFlags: [],
    }),
    useDispatch: jest.fn()
}))

describe("ChildAppsSetup tests", () => {
    it("Load ChildAppsSetup tests", () => {
        const wrapper = mount(<ChildAppsSetup />)
        expect(wrapper.find("ChatProvider")).toBeDefined()
    })
})
