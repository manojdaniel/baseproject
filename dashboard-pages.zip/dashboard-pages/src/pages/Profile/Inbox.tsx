import React, { useRef } from "react";
import InboxTable from "table/InboxTable";

interface Props {
    buttonName: string;
    onClickHandler: any;
}

const Inbox = () => {
    const inboxTableData = [
        {
            "AlertID": "168408",
            "Affiliate": "Yanpet", 
            "Plant": "MT Vernon", 
            "AssetID": "2Y-3606", 
            "AssetName": "Natural Gas Compressor",
            "AnomolyType": "Behavioural",
            "LongLeadAction": "Yes", 
            "TaskAssignedTo": "Digitilization Champion" , 
            "TimeStamp": "2023-01-20T12:11:54"
        },
        {
            "AlertID": "168408",
            "Affiliate": "Yanpet", 
            "Plant": "MT Vernon", 
            "AssetID": "2Y-3606", 
            "AssetName": "Natural Gas Compressor",
            "AnomolyType": "Behavioural",
            "LongLeadAction": "Yes", 
            "TaskAssignedTo": "Digitilization Champion" , 
            "TimeStamp": "2023-01-20T12:11:54"
        },
        {
            "AlertID": "168408",
            "Affiliate": "Yanpet", 
            "Plant": "MT Vernon", 
            "AssetID": "2Y-3606", 
            "AssetName": "Natural Gas Compressor",
            "AnomolyType": "Behavioural",
            "LongLeadAction": "Yes", 
            "TaskAssignedTo": "Digitilization Champion" , 
            "TimeStamp": "2023-01-20T12:11:54"
        },
        {
            "AlertID": "168408",
            "Affiliate": "Yanpet", 
            "Plant": "MT Vernon", 
            "AssetID": "2Y-3606", 
            "AssetName": "Natural Gas Compressor",
            "AnomolyType": "Behavioural",
            "LongLeadAction": "Yes", 
            "TaskAssignedTo": "Digitilization Champion" , 
            "TimeStamp": "2023-01-20T12:11:54"
        },
    ];
    return (
        <div>
        <div className="sub-title">INBOX LIST</div>
            <div className="common-box-content"><InboxTable data={inboxTableData} /></div>
        </div>

    );
};

export default Inbox;