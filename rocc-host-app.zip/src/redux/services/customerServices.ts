/*
 * Created on Wed Sep 15 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { graphqlClient } from "@rocc/rocc-client-services"
import { QUERY_FETCH_SITE_INFO_IN_PRESIGNED_CONTEXT_CURRENT_USER, QUERY_FETCH_SITE_INFO_USER_CURRENT_USER } from "../../graphql/queries/queries"
import { fetchLocationInfoForCurrentUserTransformer } from "../transformer/customerTransformer"

export const fetchLocationInfoForCurrentUser = async (uuid: string, deviceUuids?: String[]) => {
    const result = await graphqlClient.query(deviceUuids?.length ? {
        query: QUERY_FETCH_SITE_INFO_IN_PRESIGNED_CONTEXT_CURRENT_USER,
        variables: { uuid, deviceUuids }
    } : {
        query: QUERY_FETCH_SITE_INFO_USER_CURRENT_USER,
        variables: { uuid }
    })
    const { customerMetaData, locations, rooms } = fetchLocationInfoForCurrentUserTransformer(result.data)
    return { customerMetaData, locations, rooms }
}
