const getConfig = (process, environment) => {

    const config = {

        "qa": {
            'REACT_REDUCER': process.env.QA_REACT_REDUCER,
            'REACT_PXKEY': process.env.QA_REACT_PXKEY,
            'REACT_PXIV': process.env.QA_REACT_PXIV,
            'REACT_HTTP_CALL': process.env.QA_REACT_HTTP_CALL,
            'REACT_COMPONENT': process.env.QA_REACT_COMPONENT,
            'REACT_CHART': process.env.QA_REACT_CHART,
            'REACT_TABLE': process.env.QA_REACT_TABLE,
            'BASE_URL': process.env.QA_BASE_URL,
            'GLOBAL_URL': process.env.QA_GLOBAL_URL,
            'ASSET_URL': process.env.QA_ASSET_URL,
            'MODEL_URL': process.env.QA_MODEL_URL,
            'LOGIN_URL': process.env.QA_LOGIN_URL,
            'REACT_RSA': process.env.QA_REACT_RSA,
            'End_User_Document': process.env.QA_End_User_Document
        },
        "prod": {
            'REACT_REDUCER': process.env.PROD_REACT_REDUCER,
            'REACT_PXKEY': process.env.PROD_REACT_PXKEY,
            'REACT_PXIV': process.env.PROD_REACT_PXIV,
            'REACT_HTTP_CALL': process.env.PROD_REACT_HTTP_CALL,
            'REACT_COMPONENT': process.env.PROD_REACT_COMPONENT,
            'REACT_CHART': process.env.PROD_REACT_CHART,
            'REACT_TABLE': process.env.PROD_REACT_TABLE,
            'BASE_URL': process.env.PROD_BASE_URL,
            'GLOBAL_URL': process.env.PROD_GLOBAL_URL,
            'ASSET_URL': process.env.PROD_ASSET_URL,
            'MODEL_URL': process.env.PROD_MODEL_URL,
            'LOGIN_URL': process.env.PROD_LOGIN_URL,
            'REACT_RSA': process.env.PROD_REACT_RSA,
            'End_User_Document': process.env.PROD_End_User_Document
        },
        "dev": {
            'REACT_REDUCER': process.env.DEV_REACT_REDUCER,
            'REACT_PXKEY': process.env.DEV_REACT_PXKEY,
            'REACT_PXIV': process.env.DEV_REACT_PXIV,
            'REACT_HTTP_CALL': process.env.DEV_REACT_HTTP_CALL,
            'REACT_COMPONENT': process.env.DEV_REACT_COMPONENT,
            'REACT_CHART': process.env.DEV_REACT_CHART,
            'REACT_TABLE': process.env.DEV_REACT_TABLE,
            'BASE_URL': process.env.DEV_BASE_URL,
            'GLOBAL_URL': process.env.DEV_GLOBAL_URL,
            'ASSET_URL': process.env.DEV_ASSET_URL,
            'MODEL_URL': process.env.DEV_MODEL_URL,
            'LOGIN_URL': process.env.DEV_LOGIN_URL,
            'REACT_RSA': process.env.DEV_REACT_RSA,
            'End_User_Document': process.env.DEV_End_User_Document
        },
        "local": {
            'main': process.env.DEV_ENV,
            'REACT_REDUCER': 'headrwrapper_tsx',
            'REACT_PXKEY': '4512631236589784',
            'REACT_PXIV': '4512631236589784',
            'REACT_HTTP_CALL': 'DeActive',
            'REACT_COMPONENT': 'http://localhost:3001/',
            'REACT_CHART': 'http://localhost:3003/',
            'REACT_TABLE': 'http://localhost:3002/',
            'BASE_URL': 'https://dsappsdev.sabic.com/AHCWeb/',
            'GLOBAL_URL': 'https://dsappsdev.sabic.com/AHCWebAPIGlobal/api/v1/',
            'ASSET_URL': 'https://dsappsdev.sabic.com/AHCWebAPIAsset/api/v1/',
            'MODEL_URL': 'https://dsappsdev.sabic.com/AHCWebAPIModel/api/v1/',
            'LOGIN_URL': 'https://dsappsdev.sabic.com/AHCWebAPILogin/api/v1/',
            'REACT_RSA': "-----BEGIN PUBLIC KEY-----\n MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAskgPKBcNpz71mi4NSYa5\n mazJrO0WZim7T2yy7qPxk2NqQE7OmWWakLJcaeUYnI0kO3yC57vck66RPCjKxWuW\n SGZ7dHXe0bWb5IXjcT4mNdnUIalR+lV8czsoH/wDUvkQdG1SJ+IxzW64WvoaCRZ+\n /4wBF2cSUh9oLwGEXiodUJ9oJXFZVPKGCEjPcBI0vC2ADBRmVQ1sKsZg8zbHN+gu\n U9rPLFzN4YNrCnEsSezVw/W1FKVS8J/Xx4HSSg7AyVwniz8eHi0e3a8VzFg+H09I\n 5wK+w39sjDYfAdnJUkr6PjtSbN4/Sg/NMkKB2Ngn8oj7LCfe/7RNqIdiS+dQuSFg\n eQIDAQAB\n -----END PUBLIC KEY-----\n",
            'End_User_Document': 'https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fecm.sabic.com%2Fecm%2Fllisapi.dll%2Fapp%2Fnodes%2F714984725&data=05%7C01%7CAmit.Kumar5%40Ltts.com%7C4e0e5418b24d412a02ad08db9e155b1d%7C311b33788e8a4b5ea33fe80a3d8ba60a%7C0%7C0%7C638277586795429631%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=kg7mTtm8MMwb%2BHt9ppy3GrJbFW%2FdYAp1gcSb%2FVkZoK8%3D&reserved=0'
        }
    }

    return config[environment]
}

module.exports = getConfig