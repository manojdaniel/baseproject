/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { RoccCommunication } from "@rocc/rocc-av-communication-sdk"
import { EAvCallType, RoccException } from "@rocc/rocc-common-communication-sdk"
import { cleanup, waitFor } from '@testing-library/react'
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import * as TelemetryTrackingHelper from "../../helpers/TelemetryTrackingHelper"
import { leaveRoom } from "./AudioVideoHelper"
import AudioVideoRoom from "./AudioVideoRoom"
import { AVFactory } from "./AVFactory"

jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        SIGNALING_REGION: "gll"
    }),
    dispatchToParentStore: jest.fn(),
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))

jest.mock("../../helpers/helpers", () => ({
    getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
        rooms: [{
            identity: {
                uuid: "uuid"
            }
        }]
    }),
    getUserReducerFromGlobalStore: jest.fn().mockReturnValue({
        contacts: []
    })
}))

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn().mockReturnValue({
        intl: {
            formatMessage: jest.fn()
        }
    })
}))

jest.mock("./AudioVideoHelper", () => ({
    evaluateInitialVideoStatus: jest.fn().mockReturnValue(true),
    updateNumOfParticipants: jest.fn(),
    getAudioVideoConnectOptions: jest.fn(),
    leaveRoom: jest.fn(),
    MEDIASTREAM_EXCEPTION: {
        NOTALLOWED_ERROR: "NotAllowedError",
        NOTFOUND_ERROR: "NotFoundError",
        NOTREADABLE_ERROR: "NotReadableError",
        PERMISSION_DENIED: "Permission denied by system",
    }
}))

export async function mockCommunication(preRequisiteCheckResponse: any = null) {
    const mockRoom: any = {
        localParticipant: {
            networkQualityLevel: 5,
            audioTracks: [{
                track: [{
                    id: "123",
                    kind: "audio",
                    isStopped: false,
                    disable: jest.fn(),
                    enable: jest.fn(),
                    restart: jest.fn(),
                    stop: jest.fn(),
                    on: jest.fn(),
                    attach: jest.fn(),
                    detach: jest.fn()
                }],
                value: jest.fn().mockReturnValue([{
                    track: {
                        enable: jest.fn(),
                        disable: jest.fn(),
                        stop: jest.fn(),
                    }
                }]),
            }],
            videoTracks: [{
                track: {
                    enable: jest.fn(),
                    disable: jest.fn(),
                    stop: jest.fn(),
                },
                value: jest.fn().mockReturnValue([
                    {
                        track: {
                            disable: jest.fn(),
                            stop: jest.fn(),
                        }
                    }
                ]),
            }],
            unpublishTracks: jest.fn(),
            publishTrack: jest.fn(),
        },
        participants: [{ identity: "uuid" }],
        disconnect: jest.fn(),
    }
    if (!preRequisiteCheckResponse) {
        preRequisiteCheckResponse = Promise.resolve({
            status: true,
            initialTrackStatus: { audio: true, video: true },
            localTracks: []
        })
    }
    const communication = new RoccCommunication(EAvCallType.TWILIO)
    jest.spyOn(communication, "preRequisiteCheck").mockReturnValue(preRequisiteCheckResponse)
    jest.spyOn(communication, "initiateCall").mockReturnValue(Promise.resolve(mockRoom))
    jest.spyOn(communication, "initializeLocalParticipant").mockImplementation((_, eventList) => {
        eventList[0].callBackfn(mockRoom.localParticipant.signalStrength)
        return Promise.resolve()
    })
    jest.spyOn(communication, "initializeRoom").mockReturnValue(Promise.resolve())
    jest.spyOn(communication, "getLocalParticipant").mockReturnValue(mockRoom.localParticipant)
    jest.spyOn(communication, "getAVParticipants").mockReturnValue(mockRoom.participants)
    jest.spyOn(communication, "initializeParticipants").mockReturnValue(await Promise.resolve())
    return communication
}

jest.mock("./AVFactory", () => ({
    AVFactory: {
        getAvVendor: jest.fn().mockReturnValue(Promise.resolve(mockCommunication())),
        getVendorService: jest.fn().mockReturnValue(mockCommunication()),
        getCommunicationVendorName: jest.fn().mockReturnValue(mockCommunication())
    }
}))
jest.spyOn(TelemetryTrackingHelper, "guestUserVideoEvent").mockReturnValue("")

jest.mock("react-redux", () => ({
    useDispatch: jest.fn().mockReturnValue(jest.fn),
    useSelector: jest.fn().mockReturnValue({
        connectedCallDetails: {
            contextId: "contextId",
            roomName: "roomName",
            roomType: "Group",
            participants: [{
                uuid: "uuid",

            }]
        },
        communicationVendor: { vendorId: 1, vendorName: "TWILIO" },
        videoSource: "videoSource",
        audioSource: "audioSource",
        currentUser: {
            uuid: "uuid",
            clinicalRole: "Expert User"
        }
    })
}))

const activeCall: any = {
    contextId: "contextId",
    roomName: "roomName",
    roomType: "Group",
    numOfParticipants: 1,
    participants: [{ uuid: "uuid", }]
}


describe("AudioVideoRoom component", () => {
    let wrapper: any
    const testRenderDimensions = {
        high: { height: 720, width: 1280 },
        standard: { height: 360, width: 480 },
        low: { height: 99, width: 132 },
    }

    const renderComponent = () => shallow(<AudioVideoRoom renderDimensions={testRenderDimensions} activeCall={activeCall} />)


    describe("With AVCommunicationAdapterFeature Disabled", () => {
        afterEach(cleanup)

        it("should render AudioVideoCallWindow component", () => {
            withHooks(() => {
                const wrapper = renderComponent()
                expect(wrapper.find("AudioVideoCallWindow")).toHaveLength(1)
            })
        })

        describe("populateErrorResponse", () => {

            it("should leaveRoom with MEDIA_DEVICE_UNAVAILABLE error", () => {
                checkPopulateErrorAndExpect(new RoccException(400, "MEDIA_DEVICE_UNAVAILABLE"))
            })

            it("should leaveRoom with NO_MEDIA_PERMISSION error", () => {
                checkPopulateErrorAndExpect(new RoccException(400, "NO_MEDIA_PERMISSION"))
            })
            it("should leaveRoom with AUDIO_INPUT_UNAVAILABLE error", () => {
                checkPopulateErrorAndExpect(new RoccException(400, "AUDIO_INPUT_UNAVAILABLE"))
            })
            it("should leaveRoom with CALL_CONNECTION_ERROR error", () => {
                checkPopulateErrorAndExpect(new RoccException(400, "CALL_CONNECTION_ERROR"))
            })

            const checkPopulateErrorAndExpect = (error: RoccException) => {
                spyAndRaiseErrorInPreRequisiteCheck(error)
                withHooks(async () => {
                    renderComponent()
                    await waitFor(() => {
                        expect(leaveRoom).toHaveBeenCalled()
                    })
                })
            }

            const spyAndRaiseErrorInPreRequisiteCheck = (err: RoccException) => {
                const communication = mockCommunication(new Promise((_, error) => error(err)))
                jest.spyOn(AVFactory, "getAvVendor").mockReturnValue(Promise.resolve(communication))
            }

        })

        it("should render AudioVideoCallWindow component with all the props", () => {
            withHooks(() => {
                wrapper = shallow(<AudioVideoRoom renderDimensions={testRenderDimensions} activeCall={activeCall} />)
                expect(wrapper.props("activeRoom")).toBeDefined()
                expect(wrapper.props("remoteMediaRef")).toBeDefined()
                expect(wrapper.props("dominantSpeaker")).toBeDefined()
                expect(wrapper.props("localMediaRef")).toBeDefined()
                expect(wrapper.props("signalStrength")).toBeDefined()
                expect(wrapper.props("remoteUserVideoStatus")).toBeDefined()
                expect(wrapper.props("remoteAudioTrackStatus")).toBeDefined()
                expect(wrapper.props("videoStatus")).toBeDefined()
                expect(wrapper.props("microphoneStatus")).toBeDefined()
                expect(wrapper.props("volumeStatus")).toBeDefined()
                expect(wrapper.props("callDuration")).toBeDefined()
            })
        })
        it("should render AudioVideoCallWindow component with all the dispatch props", () => {
            withHooks(() => {
                wrapper = shallow(<AudioVideoRoom renderDimensions={testRenderDimensions} activeCall={activeCall} />)
                expect(wrapper.props("setCallStarted")).toBeDefined()
                expect(wrapper.props("setRemoteUserVideoStatus")).toBeDefined()
                expect(wrapper.props("setDominantSpeaker")).toBeDefined()
                expect(wrapper.props("updateRemoteAudioTrackStatus")).toBeDefined()
                expect(wrapper.props("setVideoStatus")).toBeDefined()
                expect(wrapper.props("setMicrophoneStatus")).toBeDefined()
                expect(wrapper.props("setVolumeStatus")).toBeDefined()
            })
        })
    })

    describe("With AVCommunicationAdapterFeature Disabled", () => {
        beforeEach(() => {
            const mockMediaDevices = {
                getUesrMedia: jest.fn().mockResolvedValueOnce({})
            }
            Object.defineProperty(window.navigator, "mediaDevices", { writable: true, value: mockMediaDevices })
        })

        afterEach(cleanup)

        it("should render AudioVideoCallWindow component", () => {
            withHooks(() => {
                const wrapper = renderComponent()
                expect(wrapper.find("AudioVideoCallWindow")).toHaveLength(1)
            })
        })

        it("should leavelRoom for no media devices found from preRequisiteCheck", () => {
            Object.defineProperty(window.navigator, "mediaDevices", { writable: true, value: false })
            withHooks(() => {
                renderComponent()
                expect(leaveRoom).toHaveBeenCalled()
            })
        })

        describe('handlePreReqError()', () => {

            beforeEach(() => {
                Object.defineProperty(window.navigator, "permissions", {
                    writable: true, value: {
                        query: jest.fn().mockReturnValue(Promise.resolve({ state: 'denied' }))
                    }
                })
            })

            it("should handle no permission allowed error with handlePreReqError", () => {
                withHooks(() => {
                    renderComponent()
                    expect(leaveRoom).toHaveBeenCalled()
                })
            })

            it("should leaveRoom on no camera permission allowed error", () => {
                Object.defineProperty(window.navigator, "permissions", {
                    writable: true, value: {
                        query: jest.fn().mockImplementation((obj) => {
                            if (obj.name === "microphone")
                                return Promise.resolve({ state: "accepted" })
                            return Promise.resolve({ state: "denied" })
                        })
                    }
                })
                withHooks(() => {
                    renderComponent()
                    expect(leaveRoom).toHaveBeenCalled()
                })
            })

            it("should leaveRoom on no mic permission allowed error", () => {
                withHooks(() => {
                    renderComponent()
                    expect(leaveRoom).toHaveBeenCalled()
                })
            })

            it("should leaveRoom on mediastream not found error for audioInput", () => {
                Object.defineProperty(window.navigator, "mediaDevices", {
                    writable: true, value: {
                        enumerateDevices: jest.fn().mockResolvedValue([{ kind: "audioinput" }, { kind: "videoinput" }])
                    }
                })
                withHooks(() => {
                    renderComponent()
                    expect(leaveRoom).toHaveBeenCalled()
                })
            })


            it("should handle other error with handlePreReqError and leaveRoom", () => {
                withHooks(() => {
                    renderComponent()
                    expect(leaveRoom).toHaveBeenCalled()
                })
            })
        })

    })
})
