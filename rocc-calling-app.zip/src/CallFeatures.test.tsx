/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import CallFeatures from "./CallFeatures"
import { shallow } from "enzyme"
import { EROCC_CONTEXT } from "@rocc/rocc-client-services"
import { mockCongifData } from "./mocks/commonMocks"
import globalStore from "./redux/store/globalStore"

const implement = jest.fn().mockReturnValue("initializeClient")

jest.mock("@rocc/rocc-chat-library", () => ({
    ChatHeader: () => <></>,
    RoccChatClient: () => jest.fn().mockImplementation(
        () => ({ initializeClient: implement })
    )
}))

jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: jest.fn(),
}))

jest.mock("./redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

describe("CallFeatures Component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(mockCongifData)
        wrapper = shallow(<CallFeatures deviceType={EROCC_CONTEXT.DESKTOP} modalityName={"CT"} />)
    })

    it("CallFeatures Component should render PersistGate component", () => {
        expect(wrapper.find("PersistGate")).toHaveLength(1)
    })
})
