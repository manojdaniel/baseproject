/*
 * Created on Thu Dec 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as helpers from "./CommandCenterLocationsControllerHelper"
import * as services from "./CommandCenterLocationsControllerService"

interface Spies {
    [key: string]: jest.SpyInstance
}

describe("helper functions for vommand center controller", () => {
    const spies: Spies = {}
    beforeEach(() => {
        ["setItem", "getItem", "clear"].forEach((fn: string) => {
            const mock = jest.fn(localStorage[fn])
            spies[fn] = jest.spyOn(Storage.prototype, fn).mockImplementation(mock)
        })
    })

    afterEach(() => {
        Object.keys(spies).forEach((key: string) => spies[key].mockRestore())
    })

    it("should set local storage item", () => {
        helpers.setCommandCenterSeatService("abcd", 1)
        expect(spies.setItem).toHaveBeenCalledTimes(1)
        helpers.setLocalStorageItem("locationName", "abcd")
        expect(spies.setItem).toHaveBeenCalled()
    })
    it("should get local storage item", () => {
        localStorage.setItem("locationName", "PHSEAT03%;;;%1")
        const res = helpers.getCommandCenterSeatService("1")
        expect(spies.setItem).toHaveBeenCalledTimes(2)
        expect(res).toStrictEqual({ seatName: "PHSEAT03", organizationId: 1 })
        helpers.getLocalStorageItem("locationName")
        expect(spies.getItem).toHaveBeenCalled()
    })
    it("should test if two objects are equal", () => {
        let res
        const obj1 = { "name": "abc" }
        const obj2 = { "name": "xyz" }
        const obj3 = obj1
        res = helpers.checkIfTwoObjectsAreEqual(obj1, obj2)
        expect(res).toBeFalsy()
        res = helpers.checkIfTwoObjectsAreEqual(obj1, obj3)
        expect(res).toBeTruthy()
    })
    it("should fetch receivers", () => {
        const spy = jest.spyOn(services, "fetchReceiversForASeatService")
        helpers.fetchReceiverTransformer("1", "abc")
        expect(spy).toHaveBeenCalled()
    })
})
