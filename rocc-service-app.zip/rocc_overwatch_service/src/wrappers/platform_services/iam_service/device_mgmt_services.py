"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import requests

from src.constants.constants import APPLICATION_JSON, CONTENT_TYPE, AUTHORIZATION, API_VERSION, ACCEPT, ORG_CTXT_HEADER, ROCC_PROXY_URL, PHILIPS_ROCC_URI
from src.loggers.log import create_logger

LOG = create_logger("IAMDeviceMgmtServices")


def store_device_details(device_response, token, org_ctxt_header):
    headers = {CONTENT_TYPE: APPLICATION_JSON,
               AUTHORIZATION: token,
               ORG_CTXT_HEADER: org_ctxt_header}
    new_device_id = ""
    for device in device_response["parameter"]:
        if device["name"] == "type":
            device_type = device["valueString"]
        if device["name"] == "OAuthClientId":
            o_auth_client_id = device["valueString"]
        if device["name"] == "OAuthClientSecret":
            o_auth_client_secret = device["valueString"]
        if device["name"] == "loginId":
            login_id = device["valueString"]
        if device["name"] == "password":
            password = device["valueString"]
        if device["name"] == "HSDPId":
            hsdp_id = device["valueString"]
            new_device_id = hsdp_id
        if device["name"] == "identitySignature":
            identity_signature = device["valueString"]
    data = {"deviceId": login_id, "hsdpId": hsdp_id, "identitySignature": identity_signature,
            "oauthClientId": o_auth_client_id, "oauthClientSecret": o_auth_client_secret,
            "password": password, "type": device_type}
    try:
        response = requests.post(f"{os.environ[ROCC_PROXY_URL]}{PHILIPS_ROCC_URI}/devicemgmt/Device",
                                 data=json.dumps(data),
                                 headers=headers)
        if response.status_code == 201 or response.status_code == 200:
            LOG.info("Device stored in IAM DB Successfully: {}".format(response.json()))
        else:
            LOG.error("Device storing in IAM DB failed with: {}".format(json.dumps(response.json())))
            response.raise_for_status()
        return new_device_id
    except Exception as ex:
        LOG.error(ex)


def create_instance_identity_mapping(url, user_uuid, user_token, service_token, org_ctxt_header, use_identity=False):
    try:
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            ORG_CTXT_HEADER: str(org_ctxt_header),
            AUTHORIZATION: service_token
        }
        body = json.dumps({"instanceId": user_uuid, "accessToken": user_token})
        if use_identity:
            body = json.dumps({"instanceId": user_uuid, "identityId": user_uuid, "accessToken": user_token})
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/authorize/InstanceMapping",
                                 data=body,
                                 headers=headers)
        api_response = json.loads(response.text)
        if response.status_code in [200, 201]:
            LOG.info(f"Instance identity mapping created successfully")
            return api_response["instanceId"], "Instance identity mapping created successfully"
        elif response.status_code in [400] and "Already exist" in api_response["defaultMessage"]:
            LOG.warning(api_response["defaultMessage"])
            return None
        else:
            LOG.error(api_response["defaultMessage"])
            return None
    except requests.exceptions.Timeout as ex:
        LOG.error("Timeout Exception occured while creating instance identity mapping for devices : {}".format(ex))
    except requests.exceptions.TooManyRedirects as ex:
        LOG.error("TooManyRedirects Exception occured while creating instance identity mapping for devices : {}".format(ex))
    except requests.exceptions.RequestException as ex:
        LOG.error("RequestException Exception occured while creating instance identity mapping for devices : {}".format(ex))
    except Exception as ex:
        LOG.error("Exception occured while creating instance identity mapping for devices : {}".format(ex))
    return None
