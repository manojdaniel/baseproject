import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import "@testing-library/jest-dom/extend-expect";
import configureMockStore from "redux-mock-store"; //npm i redux-mock-store
import BreadCrumb from "./BreadCrumb";

const mockStore = configureMockStore();
const store = mockStore({
	Common: {
		globalSelecetedRegion: { label: "Region 1" },
		globalSelecetedAffiliate: { label: "Affiliate 1" },
		globalSelecetedPlant: { label: "Plant 1" },
		globalSelecetedAsset: { label: "Asset 1" },
	},
});

describe("BreadCrumb", () => {
	beforeEach(() => {
		render(
			<BrowserRouter>
				<Provider store={store}>
					<BreadCrumb />
				</Provider>
			</BrowserRouter>
		);
	});

	it("renders the Home breadcrumb", () => {
		const homeBreadcrumb = screen.getByText("Home");
		expect(homeBreadcrumb).toBeInTheDocument();
	});

	it("renders the Affiliate breadcrumb with the correct label", () => {
		const affiliateBreadcrumb = screen.getByText("Region 1");
		expect(affiliateBreadcrumb).toBeInTheDocument();
	});

	it("renders the All Plants breadcrumb with the correct labels", () => {
		const allPlantsBreadcrumb = screen.getByText("Affiliate 1");
		expect(allPlantsBreadcrumb).toBeInTheDocument();
	});

	it("renders the Plant breadcrumb with the correct labels", () => {
		const plantBreadcrumb = screen.getByText("Plant 1");
		expect(plantBreadcrumb).toBeInTheDocument();
	});

	it("renders the Asset breadcrumb with the correct labels", () => {
		const assetBreadcrumb = screen.getByText("Asset 1");
		expect(assetBreadcrumb).toBeInTheDocument();
	});
});
