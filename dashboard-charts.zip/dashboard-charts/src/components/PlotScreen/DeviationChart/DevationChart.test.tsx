import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import DeviationChart from "./index";

//Mock data for the chart component
const data = [
	{
		localTime: "2020-11-04T01:27:00",
		assetSapId: "310061373",
		sensorGroupName: "Mixer Gearbox Bearing",
		distance: 0,
		alertThreshold: 5.160532832,
		warningThreshold: 4.635647507,
		status: "Pi Data Disconnection",
		modelId: 414,
	},
	{
		localTime: "2020-11-05T01:27:00",
		assetSapId: "310061373",
		sensorGroupName: "Mixer Bearing",
		distance: 0,
		alertThreshold: 6.160532832,
		warningThreshold: 4.635647507,
		status: "Pi Data Disconnection",
		modelId: 415,
	},
	{
		localTime: "2020-11-06T01:27:00",
		assetSapId: "310061373",
		sensorGroupName: "Mixer Gearbox Bearing",
		distance: 0,
		alertThreshold: 4.160532832,
		warningThreshold: 4.635647507,
		status: "Pi Data Disconnection",
		modelId: 414,
	},
	{
		localTime: "2020-11-07T01:27:00",
		assetSapId: "310061373",
		sensorGroupName: "Mixer Bearing",
		distance: 0,
		alertThreshold: 3.160532832,
		warningThreshold: 4.635647507,
		status: "Pi Data Disconnection",
		modelId: 415,
	},
];

describe("DeviationChart", () => {
	//Test Case to check chart exist in the component.
	it("renders the chart with data", () => {
		interface Props {
			plotData: any;
			assetName: string;
		}
		const { container } = render(
			<DeviationChart plotData={data} assetName="{Props.assestName}" />
		);
		expect(container.querySelector("#chartdiv")).toBeInTheDocument();
	});

	//Test Case to check correct Heading exist in the component
	it("renders the chart under correct heading", () => {
		render(<DeviationChart plotData={data} assetName="{Props.assestName}" />);
		expect(screen.getByText("DEVIATION PLOT")).toBeInTheDocument();
	});

	//Test Case to check correct Sensor exist in the component
	it("renders the chart under correct sensor", () => {
		render(<DeviationChart plotData={data} assetName="2Y-3001" />);
		expect(screen.getByText("2Y-3001")).toBeInTheDocument();
	});
});
