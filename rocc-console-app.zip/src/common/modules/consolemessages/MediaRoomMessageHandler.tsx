/*
 * Created on Mon Nov 29 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, IRequester } from "@rocc/rocc-client-services"
import { warningLogger, errorLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import { updateConsoleSession } from "../../../redux/actions/consoleActions"
import { IStore } from "../../../redux/interfaces/types"
import { getConsoleSessionByContextId } from "../../helpers/helpers"
import { fetchMediaRoomDetails } from "./messageService"

const FILENAME = "MediaRoomMessageHandler.tsx :"

interface IMediaRoomDetails {
    mediaRoomId: string
    mediaRoomType: string
    callState: string
    participants: string[]
    requester: IRequester
}

interface MessageHandlerProps {
    mediaRoomId: string
    mediaToken: string
    eventType: string
}

const MediaRoomMessageHandler = (props: MessageHandlerProps) => {
    const { mediaRoomId, mediaToken, eventType } = props

    const { consoleSessions, currentUser } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        currentUser: state.externalReducer.currentUser,
    }))

    const dispatch = useDispatch()

    const handleMediaRoomRequest = async (mediaRoomId: string, mediaToken: string) => {
        // Fetch Media Room Details
        // Check if user is in console session with that room
        // If yes, then add this update ActiveRoom redux value with the appropriate value
        if (eventType === "INITIATED") {
            try {
                const responseData: IMediaRoomDetails = await fetchMediaRoomDetails(mediaRoomId, currentUser)
                const userContext = responseData.requester.userContext
                if (userContext && userContext.consoleContextId) {
                    const consoleContextId = userContext.consoleContextId
                    const consoleSession = getConsoleSessionByContextId(consoleContextId, consoleSessions)
                    if (consoleSession) {
                        const mediaRoomDetails = { mediaRoomId, mediaRoomToken: mediaToken, cameraStreamAvailable: ECameraStreamAvailable.IDLE }
                        consoleSession.mediaRoomDetails = mediaRoomDetails
                        dispatch(updateConsoleSession(consoleSession, true, false))
                    } else {
                        warningLogger(`${FILENAME} Provided console session doesn't exist for contextId ${consoleContextId}`)
                    }
                }
            } catch (error) {
                errorLogger(`${FILENAME} Failed to initiate media room.`)
            }
        }
    }

    useEffect(() => {
        handleMediaRoomRequest(mediaRoomId, mediaToken)
    }, [mediaRoomId, mediaToken, eventType])

    return <></>
}

export default MediaRoomMessageHandler
