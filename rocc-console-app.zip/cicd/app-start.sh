#!/bin/bash
if [ "$SL_FLAG" == "true" ]; then
    find sl_dist -type f -name "*.js" -exec sed -i 's/sl_LabId_ReplaceMe/'"$SL_LABID"'/g' {} +
    mv dist/ dist_original/
    mv sl_dist/ dist/
fi
PORT=8080

echo "Running console application at $PORT"
serve dist -p $PORT 
