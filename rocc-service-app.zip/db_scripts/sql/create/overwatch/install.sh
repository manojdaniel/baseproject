#!/bin/bash
echo 'Creating rocc-overwatch schema'

psql -U postgres -d harbinger -f ./overwatch_schema.sql
psql -U postgres -d harbinger -f ./master_data.sql
