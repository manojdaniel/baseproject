/*
 * Created on Tue Oct 18 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, ERbacRole } from "@rocc/rocc-client-services"
import { getRoleName, renderHTMLCd } from "./stringUtility"
import en from "../../resources/translations/en-US"
import { DEVICE, DEVICE_ROLE_ROOM } from "../../constants/constants"
import { infoLogger } from "@rocc/rocc-logging-module"

const { FRONTDESK, SCHEDULER, TECHNOLOGIST, ADMIN } = EClinicalRole
jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: () => ({
        intl: {
            formatMessage: ({ id, defaultMessage }: any) => {
                infoLogger(id)
                return defaultMessage
            }
        }
    })
}))

describe("stringUtility test cases", () => {
    describe("getRoleName test cases", () => {
        it("getRoleName-expertUser test case", () => {
            expect(getRoleName(ERbacRole.EXPERTUSER_ROLE)).toBe(en["content.roles.expertUser"])
        })
        it("getRoleName-protocolManager test case", () => {
            expect(getRoleName(ERbacRole.PROTOCOL_MANAGER_ROLE)).toBe(en["content.roles.protocolManager"])
        })
        it("getRoleName-euIncognito test case", () => {
            expect(getRoleName(ERbacRole.EXPERTUSER_WITH_INCOGNITO_ROLE)).toBe(en["content.roles.euIncognito"])
        })
        it("getRoleName-Admin test case", () => {
            expect(getRoleName(ADMIN)).toBe(en["content.roles.Admin"])
        })
        it("getRoleName-technologist test case", () => {
            expect(getRoleName(TECHNOLOGIST)).toBe(en["content.roles.technologist"])
        })
        it("getRoleName-room test case", () => {
            expect(getRoleName(DEVICE_ROLE_ROOM)).toBe(en["content.roles.room"])
        })
        it("getRoleName-Device test case", () => {
            expect(getRoleName(DEVICE)).toBe(en["content.roles.Device"])
        })
        it("getRoleName-frontdesk test case", () => {
            expect(getRoleName(FRONTDESK)).toBe(en["content.roles.frontdesk"])
        })
        it("getRoleName-scheduler test case", () => {
            expect(getRoleName(SCHEDULER)).toBe(en["content.roles.scheduler"])
        })
    })
    describe("renderHTMLCd test cases", () => {
        it("should return special character", () => {
            expect(renderHTMLCd("&#8226;")).toBe(String.fromCharCode(8226))
        })
    })
})
