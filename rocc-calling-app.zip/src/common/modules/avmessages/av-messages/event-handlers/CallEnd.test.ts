/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { callEnd } from "./CallEnd"

jest.useFakeTimers()

jest.mock("../../../../../redux/actions/callActions", () => {
    const actualFn = jest.requireActual("../../../../../redux/actions/callActions")
    return {
        ...actualFn,
        setVideoCallStatus: jest.fn(),
        setCallRingStatus: jest.fn(),
        storeCallDetails: jest.fn(),
        setNumOfVideoCallParticipants: jest.fn(),
    }
})

jest.mock("../../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl"
    })
}))

jest.mock("../../../../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue(({
        callReducer: {
            videoCallStatus: [{ callStatus: ECallStatus.IDLE, contextId: "" }],
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    participants: [{
                        primaryUuid: "primaryUuid",
                    }],
                    callAcceptedTime: Date.now(),
                },
                onHoldCallDetails: [],
            }
        },
        externalReducer: {
            currentUser: {}
        }
    }))
}))

const dispatch = jest.fn()

describe("CallEnd tests", () => {
    it("should able to handle callend", () => {

        callEnd({ contextId: "contextId", dispatch })
        jest.runAllTimers()
        expect(dispatch).toBeCalled()
    })
})
