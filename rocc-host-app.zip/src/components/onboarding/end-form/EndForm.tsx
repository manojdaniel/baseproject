/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { TermsAndConditionsAgreeAction, TermsAndConditionsContent, TermsAndConditionsPreviousAction } from "@rocc/rocc-authentication-components"
import { IParentStore } from "@rocc/rocc-client-services"
import { useSelector } from "react-redux"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import { Grid, GridColumn, GridRow, Header, Item } from "semantic-ui-react"
import en from "../../../resources/translations/en-US"
import styles from "./EndForm.scss"

interface IEndFormProps {
    onBoardingSuccessStatus: any
    value: boolean
    consentData: ""
    getAgree: () => void
    getPrevious: () => void
}

const EndForm = (props: IEndFormProps) => {
    const { configs } = useSelector((state: IParentStore) => ({
        configs: state.configReducer.configs
    }))
    const { onBoardingSuccessStatus, consentData, getAgree, getPrevious } = props
    const { intl } = getIntlProvider()
    const { CUSTOMER_PRIVACY_POLICY_URL } = configs

    return (
        <div className={styles.endForm} id="endForm">
            <fieldset className="panel panel-default form-wrapper" id="edit-legal">

                <Header textAlign={"left"}>
                    <Item>
                        <Item.Content className={styles.endFormHeaderTitle}>
                            {intl.formatMessage({ id: "content.terms.title", defaultMessage: en["content.terms.title"] })}
                        </Item.Content>
                    </Item>
                </Header>

                <div className={styles.endFormContent}>
                    <TermsAndConditionsContent
                        consentData={consentData}
                    />
                </div>
                <Grid className={styles.termsContentGrid}>
                    <GridRow>
                        {CUSTOMER_PRIVACY_POLICY_URL && <div id="endForm" className={styles.acceptTermsAndConditions}>
                            <a href={CUSTOMER_PRIVACY_POLICY_URL} target="_blank" rel="noopener noreferrer" className={styles.privacyPolicy}>
                                {intl.formatMessage({ id: "content.onboarding.termsAction.privacyPolicy", defaultMessage: en["content.onboarding.termsAction.privacyPolicy"] })}
                            </a>
                        </div>}
                    </GridRow>
                    <GridRow>
                        <GridColumn width={6} textAlign={"left"} className={styles.getPrevious}>
                            <TermsAndConditionsPreviousAction content={intl.formatMessage({
                                id: "content.onboarding.termsAction.previousBtn",
                                defaultMessage: en["content.onboarding.termsAction.previousBtn"]
                            })} getPrevious={getPrevious} />
                        </GridColumn>
                        <GridColumn width={6} textAlign={"right"} className={styles.termsAction}>
                            <TermsAndConditionsAgreeAction content={intl.formatMessage({
                                id: "content.onboarding.termsAction.agreeBtn",
                                defaultMessage: en["content.onboarding.termsAction.agreeBtn"]
                            })} getAgree={getAgree} />
                        </GridColumn>

                    </GridRow>
                </Grid>
            </fieldset>
            {!onBoardingSuccessStatus && <div style={styles.errorMessage}>
                {intl.formatMessage({ id: "content.onboardingFailed.text", defaultMessage: en["content.onboardingFailed.text"] })}
            </div>}
        </div>
    )
}

export default EndForm
