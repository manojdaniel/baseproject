import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import LiveTrackingTable from "./LiveTrackingTable";
import { Table } from "antd";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});
const mockData = [
	{
		timeStamp: "2023-04-20T14:35:00Z",
		status: "Running",
		modelName: "Model1",
		influencingSensor1: 10,
		influencingSensor2: 20,
		influencingSensor3: 30,
		influencingSensor4: 40,
		influencingSensor5: 50,
		influencingSensor6: 60,
		influencingSensor7: 70,
	},
	// ...add more mock data as needed
];

describe("LiveTrackingTable", () => {
	it("renders a table with correct columns", () => {
		render(<LiveTrackingTable data={mockData} />);
		const columns = screen
			.getAllByRole("columnheader")
			.map((column) => column.textContent);
		expect(columns).toEqual([
			"TIME STAMP",
			"MODEL STATUS",
			"MODEL NAME",
			"INFLUENCING SENSOR1",
			"INFLUENCING SENSOR2",
			"INFLUENCING SENSOR3",
			"INFLUENCING SENSOR4",
			"INFLUENCING SENSOR5",
			"INFLUENCING SENSOR6",
			"INFLUENCING SENSOR7",
		]);
	});
	it("should render the component without errors", () => {
		render(<LiveTrackingTable data={mockData} />);

		expect(Table).toHaveBeenCalled(); // Verify that Antd Table was called
	});
	it("renders a row for each data item", () => {
		render(<LiveTrackingTable data={mockData} />);
		const rows = screen.getAllByRole("row").slice(1); // ignore header row
		expect(rows).toHaveLength(mockData.length);
	});

	it("formats time stamp correctly", () => {
		render(<LiveTrackingTable data={mockData} />);
		const formattedTimeStamp = screen.getByText("20/04/2023 14:04:00 PM");
		expect(formattedTimeStamp).toBeInTheDocument();
	});

	// ...add more test cases as needed
});
