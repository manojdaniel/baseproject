import React, { useState, useEffect } from "react";
import { Table, Popover, Button, Radio } from "antd";
import "./Compressor.scss"
// import type { ColumnsType } from "antd/es/table";

// interface DataType {
// 	key: React.Key;
// 	SR: number;
// 	SpareDescription: string;
// 	Min: number;
// 	Available: number;
// 	Max: number;
// 	MaterialNumber: number;
// 	Type: string;
// 	AvailableQuantityinOtherAffiliates: string;
// 	DeliveryTime: number;
// 	Reserve: string;
// 	Details: string;
// 	Status: symbol;
// 	DeliveryStatus: string;
// 	AHCGroupAssignment: string;
// }
// const columns: ColumnsType<DataType> = [

// const data = [
// 	{
// 		SR: 1,
// 		SpareDescription: "Bearing,E",
// 		MaterialNumber: 124831,
// 		Type: "PD",
// 		Min: 1,
// 		Available: 2,
// 		Max: 3,
// 		AvailableQuantityinOtherAffiliates: 5,
// 		DeliveryTime: 3,
// 		Reserve: "Reserve",
// 		Details: "More",
// 		Status: "Circle",
// 		DeliveryStatus: "P.O Email Expedetise",
// 		AHCGroupAssignment: "Bearing",
// 	},
// 	{
// 		SR: 2,
// 		SpareDescription: "Bearing,E",
// 		MaterialNumber: 124831,
// 		Type: "PD",
// 		Min: 2,
// 		Available: 3,
// 		Max: 4,
// 		AvailableQuantityinOtherAffiliates: 6,
// 		DeliveryTime: 4,
// 		Reserve: "Reserve",
// 		Details: "More",
// 		Status: "Circle",
// 		DeliveryStatus: "P.O Email Expedetise",
// 		AHCGroupAssignment: "Bearing",
// 	}
// ];

interface Props {
	data: any[];

}
const CompressorSensor = ({ data }: Props) => {

	const [getTableData, setTableData] = useState<any>();
	let count =0;
	useEffect(() => {
			let mydata = data.map(function (item: any) {
			count++;
			return {
				SR: count,
				SpareDescription: item.spareDescription,
				MaterialNumber: item.materialNumber,
				Type: item.type,
				Min: item.min,
				Available: item.available,
				Max: item.max,
				// AvailableQuantityinOtherAffiliates: (
				// 	<Popover content={
				// 		<table>
				// 			<tr>
				// 				<td>Hadded</td>
				// 				<td>5</td>
				// 			</tr>
				// 			<tr>
				// 				<td>Gas</td>
				// 				<td>3</td>
				// 			</tr>
				// 		</table>
				// 	} title="">
				// 		5
				// 	</Popover>
				// ),
				DeliveryTime: item.deliveryTime,
				// Reserve: (
				// 	<a href="#">{item.Reserve}</a>
				// ),
				// Details: (
				// 	<a href="#">{item.Details}</a>
				// ),
				Status: (
					<div style={{ textAlign: "center" }}>
						<Button type="primary" style={{ background: item.status }} shape="circle" size="small" />
					</div>
				),
				OpenPOQTY: item.openPOQTY,
				AHCGroupAssignment: (
					item.ahcGroupAssignment
					// <div
					// 	className="cus-button"
					// 	onClick={() => handleClick(item.alertID, item.currentStage)}
					// >
					// 	View
					// </div>
				),
			};
		});
		setTableData(mydata);
	}, [data]);


	const columns = [
		{
			title: "SR",
			dataIndex: "SR",
			key: "SR",
			width: 50,
		},
		{
			title: "Spare Description",
			dataIndex: "SpareDescription",
			key: "SpareDescription",
			width: 100,
		},
		{
			title: "Material Number",
			dataIndex: "MaterialNumber",
			key: "MaterialNumber",
			width: 100,
		},
		{
			title: "Type",
			dataIndex: "Type",
			key: "Type",
			width: 100,
		},
		{
			title: "Quantity OnSite",
			children: [
				{
					title: "Min",
					dataIndex: "Min",
					key: "Min",
					width: 50,
				},
				{
					title: "Available",
					dataIndex: "Available",
					key: "Available",
					width: 50,
				},
				{
					title: "Max",
					dataIndex: "Max",
					key: "Max",
					width: 50,
				},
			],
		},
		// {
		// 	title: "Available Quantity in Other Affiliates",
		// 	dataIndex: "AvailableQuantityinOtherAffiliates",
		// 	key: "AvailableQuantityinOtherAffiliates",
		// 	width: 100,
		// },
		{
			title: "DeliveryTime",
			dataIndex: "DeliveryTime",
			key: "DeliveryTime",
			width: 100,
		},
		// {
		// 	title: "Reserve",
		// 	dataIndex: "Reserve",
		// 	key: "Reserve",
		// 	width: 80,
		// 	// render: (text: any) => <a href="#">{text}</a>,
		// },
		// {
		// 	title: "Details",
		// 	dataIndex: "Details",
		// 	key: "Details",
		// 	width: 80,
		// 	// render: (text: any) => <a href="#">{text}</a>,
		// },
		{
			title: "Status",
			dataIndex: "Status",
			key: "Status",
			width: 80,
			// render: () => <a type="circle"></a>,
		},
		{
			title: "Open PO QTY",
			dataIndex: "OpenPOQTY",
			key: "OpenPOQTY",
			width: 80,
		},
		{
			title: "AHCGroup Assignment",
			dataIndex: "AHCGroupAssignment",
			key: "AHCGroupAssignment",
			width: 60,
			// render: (text: any) => <a href="#">{text}</a>,
		},
	];
	return (
		<Table
			columns={columns}
			dataSource={getTableData}
			bordered
			size="middle"
			pagination={false}
			scroll={{ x: "1080px" }}
		/>
	);
}

export default CompressorSensor;
