"""
 Created on Tue Mar 16 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest import mock

import requests

from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_access_token_from_hsdp, create_device_provision_token, create_service_token_from_vault
from tests.mocks.mock_requests import DUMMY_PRIVATE_KEY, MockResponse


class TestManageTokenServices(unittest.TestCase):

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"access_token": "mocked_access_token"}, 200))
    def test_create_service_token_from_vault_200(self, m_post):
        response = create_service_token_from_vault(iam_url="/hsdp_iam_url", issuer="dummy_issuer", private_key=DUMMY_PRIVATE_KEY)
        self.assertEqual(response, "mocked_access_token")

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    def test_create_service_token_from_vault_400(self, m_post, m_log):
        create_service_token_from_vault(iam_url="/hsdp_iam_url", issuer="dummy_issuer", private_key=DUMMY_PRIVATE_KEY)
        m_log.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.RoccException")
    def test_create_service_token_from_vault_exception(self, m_post, m_log, m_rocc_excption):
        m_post.side_effect = requests.exceptions.RequestException("Exception")
        create_service_token_from_vault(iam_url="/hsdp_iam_url", issuer="dummy_issuer", private_key=DUMMY_PRIVATE_KEY)
        m_log.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"access_token": "mocked_access_token"}, 200))
    def test_create_device_provision_token_200(self, m_post):
        vault_response = {"data": {"deviceClientId": "", "deviceClientSecret": ""}}
        response = create_device_provision_token(iam_url="/hsdp_iam_url", vault_response=vault_response)
        self.assertEqual(response, "mocked_access_token")

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    def test_create_device_provision_token_400(self, m_post, m_log):
        vault_response = {"data": {"deviceClientId": "", "deviceClientSecret": ""}}
        create_device_provision_token(iam_url="/hsdp_iam_url", vault_response=vault_response)
        m_log.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.RoccException")
    def test_create_device_provision_token_exception(self, m_post, m_log, m_rocc_excption):
        m_post.side_effect = Exception("Exception")
        vault_response = {"data": {"deviceClientId": "", "deviceClientSecret": ""}}
        create_device_provision_token(iam_url="/hsdp_iam_url", vault_response=vault_response)
        m_log.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"access_token": "mocked_access_token"}, 200))
    def test_create_access_token_from_hsdp_200(self, m_post):
        response = create_access_token_from_hsdp(iam_url="/hsdp_iam_url", username="", password="", client_id="", client_secret="")
        self.assertEqual(response, "mocked_access_token")

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    def test_create_access_token_from_hsdp_400(self, m_post, m_log):
        create_access_token_from_hsdp(iam_url="/hsdp_iam_url", username="", password="", client_id="", client_secret="")
        m_log.assert_called()

    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.requests.post")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.create_logger.error")
    @mock.patch("src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services.RoccException")
    def test_create_access_token_from_hsdp_exception(self, m_post, m_log, m_rocc_excption):
        m_post.side_effect = Exception("Exception")
        create_access_token_from_hsdp(iam_url="/hsdp_iam_url", username="", password="", client_id="", client_secret="")
        m_log.assert_called()


suite = unittest.TestSuite()

suite.addTest(TestManageTokenServices("test_create_service_token_from_vault_200"))
suite.addTest(TestManageTokenServices("test_create_service_token_from_vault_400"))
suite.addTest(TestManageTokenServices("test_create_service_token_from_vault_exception"))
suite.addTest(TestManageTokenServices("test_create_device_provision_token_200"))
suite.addTest(TestManageTokenServices("test_create_device_provision_token_400"))
suite.addTest(TestManageTokenServices("test_create_device_provision_token_exception"))
suite.addTest(TestManageTokenServices("test_create_access_token_from_hsdp_200"))
suite.addTest(TestManageTokenServices("test_create_access_token_from_hsdp_400"))
suite.addTest(TestManageTokenServices("test_create_access_token_from_hsdp_exception"))

unittest.TextTestRunner(verbosity=1).run(suite)
