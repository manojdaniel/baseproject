"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs
from src.modules.job_management.failed_job import FailedJob
from src.modules.job_management.customer_org_setup_job import CustomerOrgSetupJob
from src.modules.job_management.cf_customer_setup_job import CFCustomerSetupJob
from src.modules.job_management.customer_data_insertion_job import CustomerDataInsertionJob
from src.modules.job_management.data_validation_job import DataValidationJob
from src.modules.job_management.completed_job import CompletionJob
from src.modules.job_management.timed_wait_job import TimedWaitJob
from src.constants.constants import CURRENT_JOB, OPERATION_STATUS, COMPLETED

LOG = create_logger("Events handler")


def handle_event(payload):
    invalid_key_msg = f"Received Invalid JobType key: {payload[CURRENT_JOB]}, expected one of {[e.value for e in EJobs]}!"
    try:
        """ TODO: Replace lambda function with respective function calls"""
        switcher = {
            EJobs.CUSTOMER_ORG_SETUP.value: lambda payload: initiate_job(CustomerOrgSetupJob(), payload=payload),
            EJobs.CF_CUSTOMER_SETUP.value: lambda payload: initiate_job(CFCustomerSetupJob(), payload=payload),
            EJobs.TIMED_WAIT.value: lambda payload: initiate_job(TimedWaitJob(), payload=payload),
            EJobs.VALIDATE_ONBOARDED_DATA.value: lambda payload: initiate_job(DataValidationJob(), payload=payload),
            EJobs.CUSTOMER_DATA_INSERTION.value: lambda payload: initiate_job(CustomerDataInsertionJob(), payload=payload),
            EJobs.COMPLETE.value: lambda payload: initiate_job(CompletionJob(), payload=payload),
            EJobs.FAILED.value: lambda payload: initiate_job(FailedJob(), payload=payload),
        }
        switcher.get(payload[CURRENT_JOB], lambda: LOG.error(invalid_key_msg))(payload)
    except KeyError as ke:
        LOG.error(f"{invalid_key_msg} Error: {ke}")
        LOG.error(traceback.print_exc())
    except Exception as ex:
        LOG.exception("Failed to parse the received message with error: {}".format(ex))
        LOG.error(traceback.print_exc())


def initiate_job(ob, payload):
    LOG.debug("Initiating job: {}".format(payload[CURRENT_JOB]))
    if payload[OPERATION_STATUS] and payload[OPERATION_STATUS] != COMPLETED:
        ob.start_job(payload=payload)
