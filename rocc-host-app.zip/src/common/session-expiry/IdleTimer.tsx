/*
 * Created on Tue Sep 28 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence, IParentStore } from "@rocc/rocc-client-services"
import React, { useCallback, useRef, useState } from "react"
import { useSelector } from "react-redux"

interface IUseIdletimer {
    timeout: number
    warningTimeout: number
    onWarn: () => void
    onTimeOut: () => void
}

const useIdletimer = ({ timeout, warningTimeout, onWarn }: IUseIdletimer) => {

    const warn = useCallback(() => {
        onWarn && onWarn()
    }, [onWarn])

    const { currentUser } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
    }))

    const warnTimeout = useRef(undefined as any)
    const [stopTimeout, setStopTimeout] = useState(false)

    const setTimeouts = () => {
        if (!stopTimeout) { warnTimeout.current = setTimeout(warn, warningTimeout) }

    }

    const clearTimeouts = () => {
        if (warnTimeout.current) {
            clearTimeout(warnTimeout.current)
            warnTimeout.current = undefined
        }
    }

    const resetTimeout = () => {
        clearTimeouts()
        setTimeouts()
    }

    React.useEffect(() => {
        if (currentUser.status === EUserPresence.IN_CALL) {
            clearTimeouts()
            setStopTimeout(true)
        } else {
            if (!warnTimeout) { setTimeouts() }
            setStopTimeout(false)
        }
    }, [currentUser.status])

    React.useEffect(() => {
        const events = [
            "load",
            "mousemove",
            "mousedown",
            "click",
            "scroll",
            "keypress"
        ]

        for (const i in events) {
            window.addEventListener(events[i], resetTimeout)
        }

        setTimeouts()
        return () => {
            for (const i in events) {
                window.removeEventListener(events[i], resetTimeout)
                clearTimeouts()
            }
        }
    }, [timeout, warn, warningTimeout])

}

export default useIdletimer
