import "@testing-library/jest-dom/extend-expect";
import PushNotification from "./index";
import { notification } from "antd";

// Mock the notification module from antd
jest.mock("antd", () => ({
	notification: {
		success: jest.fn(),
		error: jest.fn(),
		warning: jest.fn(),
		info: jest.fn(),
	},
}));

describe("PushNotification", () => {
	afterEach(() => {
		jest.clearAllMocks();
	});

	test('should call notification.success for type "success"', () => {
		const message = "Success message";
		PushNotification("success", message);
		expect(notification.success).toHaveBeenCalledWith({
			message,
			duration: 2,
			placement: "topRight",
			style: { marginTop: "120px" },
		});
	});

	test('should call notification.error for type "error"', () => {
		const message = "Error message";
		PushNotification("error", message);
		expect(notification.error).toHaveBeenCalledWith({
			message,
			duration: 2,
			placement: "topRight",
			style: { marginTop: "120px" },
		});
	});

	test('should call notification.warning for type "warning"', () => {
		const message = "Warning message";
		PushNotification("warning", message);
		expect(notification.warning).toHaveBeenCalledWith({
			message,
			duration: 2,
			placement: "topRight",
			style: { marginTop: "120px" },
		});
	});

	test("should call notification.info for any other type", () => {
		const message = "Info message";
		PushNotification("other", message);
		expect(notification.info).toHaveBeenCalledWith({
			message,
			duration: 2,
			placement: "topRight",
			style: { marginTop: "120px" },
		});
	});
});
