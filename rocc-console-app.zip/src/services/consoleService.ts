/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionState, EConnectionType, EMutationOperation, FeatureFlagHelper, IRoomDetails, IUserInfo, parseIntBase10, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { errorLogger, errorParser, infoLogger, warningLogger } from "@rocc/rocc-logging-module"
import { ADDITIONAL_ATTRIBUTES, API_VERSION, API_VERSION_101, APPLICATION_JSON, CONTENT_TYPE, DEFAULT_API_VERSION, EMERALD_FETCH_CLI_ARGS, EMERALD_KVM_MAPPING_CLI_ARGS, HTTP_STATUS, IS_NCC_WARNING_DISPLAYED, MANAGE_GRAPHQL_IN_APP_MUTATIONS_EP } from "../common/constants/constants"
import { CONSOLE_ACTIVE_SESSIONS, CONSOLE_AUTHORIZATION, CONSOLE_CONNECTION, CONSOLE_CONTROL_CONNECTION, CONSOLE_SESSION_AUTHORIZATION_EP, CONSOLE_SESSION_EDIT, CONSOLE_SESSION_EP, EMERALD_CONNECTION, EMERALD_DISCONNECTION, KVM_CONNECTION_MAPPING, MANAGE_GRAPHQL_CONSOLE_MUTATIONS_EP, RESOURCE_ADDITIOINAL_ATTRIBUTE } from "../common/constants/endpoints"
import { deleteService, getService, postService, putService } from "../common/helpers/apiUtility"
import { sleep } from "../common/helpers/dateTimeUtility"
import { fetchGlobalConfigs, fetchGlobalCurrentUser, fetchGlobalFeatureFlags, fetchGlobalURLs } from "../redux/store/externalAppStates"

interface IUpdateCommandCenterRegistrationCount {
    userOperationType: EMutationOperation
    requesterId: number
    orgId: number
    seatName: string
    managementServiceUrl: string
    token: string
}

const notEligibleForDelete: string[] = []

interface IInitiateCCConsole {
    connectionType: EConnectionType
    connectionMode: EConnectionMode
    requester: string
    roomUuid: string
    seatName: string
    accessToken: string
    receiverName: string
    orgId: number
}

const isMultiVendorEnabled = () => FeatureFlagHelper.isFeatureEnabled(fetchGlobalFeatureFlags(), ROCC_FEATURES.ROCC_MULTI_KVM_VENDOR, true)

export const initiateCCConsoleService = async (params: IInitiateCCConsole) => {
    const { connectionType, requester, roomUuid, seatName, accessToken, receiverName, orgId, connectionMode } = params
    const multiVendorEnabled = isMultiVendorEnabled()
    const ccURI = multiVendorEnabled ? CONSOLE_SESSION_EP : CONSOLE_CONNECTION
    const nfccURI = multiVendorEnabled ? KVM_CONNECTION_MAPPING : EMERALD_CONNECTION
    const consoleAPIURL = connectionMode === EConnectionMode.EMERALD ? nfccURI : ccURI
    const data = {
        connectionType,
        requester,
        roomUuid,
        seatName,
        receiverName,
        orgId,
    }
    const headers = getRequestHeader(accessToken, multiVendorEnabled ? DEFAULT_API_VERSION : API_VERSION_101)
    try {
        const urls = fetchGlobalURLs()
        const response = await postService({
            data,
            headers,
            url: `${urls.CONSOLE_SERVICES_URL}${consoleAPIURL}`,
        })
        return response.data.contextId
    } catch (error) {
        errorLogger(`Console connection failed with error: ${errorParser(error)}`)
        throw error
    }
}

// TODO: [MARKER] Modify to remove PUT call
// TODO: [MARKER] Check if notEligibleForConnection logic should be ported over from tech-main-app method
export const initiateAuthorizeCCConsoleService = async (contextId: string, currentUser: IUserInfo) => {
    try {
        const multiVendorEnabled = isMultiVendorEnabled()
        const urls = fetchGlobalURLs()
        let response
        if (multiVendorEnabled) {
            response = await putService({
                url: `${urls.CONSOLE_SERVICES_URL}${CONSOLE_SESSION_EP}/${contextId}${CONSOLE_SESSION_EDIT}`,
                headers: getRequestHeader(currentUser.accessToken, DEFAULT_API_VERSION),
            })
        }
        else {
            response = await postService({
                url: `${urls.CONSOLE_SERVICES_URL}${CONSOLE_CONTROL_CONNECTION}`,
                headers: getRequestHeader(currentUser.accessToken, DEFAULT_API_VERSION),
                data: { contextId },
            })
        }
        return response.status
    } catch (error) {
        errorLogger(`Authorize console connection failed for contextId: ${contextId} for user: ${currentUser.uuid} with error ${errorParser(error)}`)
        throw error
    }
}

interface IDisconnectConsoleService {
    accessToken: string
    contextId: string
    shouldUpdateForceDelete: boolean
    connectionMode: EConnectionMode
}
export const disconnectConsoleService = async (params: IDisconnectConsoleService) => {
    const multiVendorEnabled = isMultiVendorEnabled()
    const { accessToken, contextId, shouldUpdateForceDelete, connectionMode } = params
    const configs = fetchGlobalConfigs()
    const urls = fetchGlobalURLs()
    let url = ""
    switch (connectionMode) {
        case EConnectionMode.CC: url = `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? CONSOLE_SESSION_EP : CONSOLE_CONNECTION}/${contextId}`
            break
        case EConnectionMode.EMERALD: url = `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? KVM_CONNECTION_MAPPING : EMERALD_DISCONNECTION}/${contextId}`
            break
        case EConnectionMode.VNC:
        default:
            infoLogger(`Currently requested connection mode ${connectionMode} is not supported`)
            return
    }

    if (!notEligibleForDelete.includes(contextId)) {
        notEligibleForDelete.push(contextId)
        const headers = getRequestHeader(accessToken, DEFAULT_API_VERSION)
        const delayValue = configs.CONSOLE_DISCONNECT_DELAY ? parseIntBase10(configs.CONSOLE_DISCONNECT_DELAY) : 0
        try {
            /* TODO: Remove the sleep - this is done to control the load at KVM - Rx side*/
            const responses = await Promise.all([
                deleteService({
                    headers,
                    url: url,
                    data: { shouldUpdateForceDelete: shouldUpdateForceDelete || false },
                }),
                sleep(delayValue)
            ])

            return responses[0].status
        } catch (error: any) {
            errorLogger(`Console disconnection failed with error: ${errorParser(error)}`)
            notEligibleForDelete.splice(notEligibleForDelete.indexOf(contextId))
            if (shouldUpdateForceDelete) { handleDisconnectFailure(params) }
            return (error.response && error.response.status) ? error.response.status : HTTP_STATUS.INTERNAL_SERVER_ERROR
        }
    } else {
        return HTTP_STATUS.ALREADY_REPORTED
    }
}

export const handleDisconnectFailure = (params: IDisconnectConsoleService) => {
    try {
        /* Triggering dangling connections cleanup flow */
        const { accessToken, contextId } = params
        const urls = fetchGlobalURLs()
        const headers = getRequestHeader(accessToken, DEFAULT_API_VERSION)
        warningLogger("Since console disconnection encountered error, triggering dangling connections cleanup flow")
        putService({
            headers,
            url: `${urls.MANAGEMENT_SERVICE_URL}${MANAGE_GRAPHQL_CONSOLE_MUTATIONS_EP}`,
            data: { params: [{ contextId, forceDeleteType: "F_INIT" }], userOperationType: EMutationOperation.UPDATE_CONSOLE_FORCE_UPDATE_FLAG },
        })
    } catch (error) {
        errorLogger(`Initializing of dangling-connections cleanup flow failed with error: ${errorParser(error)}`)
    }
}
interface IUpdateCommandCenterRegistrationCount {
    userOperationType: EMutationOperation
    requesterId: number
    orgId: number
    seatName: string
    managementServiceUrl: string
    token: string
}

export const updateCommandCenterRegistrationCountService = (
    { userOperationType, requesterId, orgId, seatName, managementServiceUrl, token }: IUpdateCommandCenterRegistrationCount
) => async () => {
    try {
        return await (postService({
            url: `${managementServiceUrl}${MANAGE_GRAPHQL_IN_APP_MUTATIONS_EP}`,
            body: { requesterId, userOperationType, params: { orgId, seatName } },
            headers: getRequestHeader(token, DEFAULT_API_VERSION),
        }))
    } catch (error: any) {
        errorLogger(`Updating registration count for seat: ${seatName} failed with error: ${errorParser(error)}`)
        return error.statusCode || HTTP_STATUS.INTERNAL_SERVER_ERROR
    }
}

export const getActiveConnections = async (accessToken: string, customParams: string) => {
    const headers = getRequestHeader(accessToken, DEFAULT_API_VERSION)
    try {
        const multiVendorEnabled = isMultiVendorEnabled()
        const urls = fetchGlobalURLs()
        const response = await getService({
            headers,
            url: `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? CONSOLE_SESSION_EP : CONSOLE_ACTIVE_SESSIONS}${customParams}`,
        })
        return response.data
    } catch (error: any) {
        errorLogger(`Failed to fetch active connections with error: ${errorParser(error)}`)
        if (error.response) {
            throw error
        } else { throw new Error("Network Error") }
    }
}

interface IRequestAuthorization {
    connectionType: EConnectionType
    connectionMode: EConnectionMode
    requester: string
    roomUuid: string
    seatName: string
    accessToken: string
    receiverName: string
    callContextId?: string
    orgId: number
    auth: boolean
}
export const requestAuthorizationService = async (props: IRequestAuthorization) => {
    const { connectionMode, requester, roomUuid, accessToken, receiverName, callContextId, orgId, seatName, connectionType, auth } = props
    const multiVendorEnabled = isMultiVendorEnabled()
    const urls = fetchGlobalURLs()
    let url = ""

    switch (connectionMode) {
        case EConnectionMode.CC: url = `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? CONSOLE_SESSION_AUTHORIZATION_EP : CONSOLE_AUTHORIZATION}`
            break
        case EConnectionMode.EMERALD: url = `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? KVM_CONNECTION_MAPPING : EMERALD_CONNECTION}`
            break
        case EConnectionMode.VNC:
        default:
            infoLogger(`Currently requested connection mode ${connectionMode} is not supported`)
            return
    }
    const data = {
        requester, roomUuid, callContextId, seatName, connectionType, receiverName, orgId, auth
    }
    try {
        infoLogger(`console url is ${urls.CONSOLE_SERVICES_URL}`)
        const response = await postService({
            data,
            headers: getRequestHeader(accessToken, DEFAULT_API_VERSION),
            url,
        })
        if (response.status === HTTP_STATUS.CREATED) {
            return response.data.contextId
        }
    } catch (error) {
        errorLogger(`Failed to initiate console authorization request for user ${requester} and device ${roomUuid} : ${error}`)
    }
}

export const spokeNotQualifiedService = async (roomDetails: IRoomDetails, spokeStatus: boolean) => {
    const { accessToken } = fetchGlobalCurrentUser()
    const data = {
        [ADDITIONAL_ATTRIBUTES]: {
            [IS_NCC_WARNING_DISPLAYED]: spokeStatus
        }
    }
    const headers = getRequestHeader(accessToken, DEFAULT_API_VERSION)

    try {
        const { MANAGEMENT_SERVICE_URL } = fetchGlobalURLs()
        const response = await putService({
            data,
            headers,
            url: `${MANAGEMENT_SERVICE_URL}${RESOURCE_ADDITIOINAL_ATTRIBUTE}${roomDetails.identity.id}`
        })
        if (response.status === HTTP_STATUS.OK) {
            return true
        }
    } catch (error) {
        errorLogger(`Errron on spokeNotQualifiedService: ${errorParser(error)}`)
    }
    return false
}

export const updateConsoleAuthorizationService = async (params: {
    contextId: string,
    token: string,
    consoleStatus: string,
}) => {
    const { consoleStatus, token, contextId } = params
    const multiVendorEnabled = isMultiVendorEnabled()
    const urls = fetchGlobalURLs()
    try {
        const response = await putService({
            url: `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? CONSOLE_SESSION_AUTHORIZATION_EP : CONSOLE_AUTHORIZATION}/${contextId}`,

            headers: getRequestHeader(token, DEFAULT_API_VERSION),
            data: { consoleStatus },
        })
        return { respStatus: response.status, respContextId: response.data.contextId, respMessage: response.data.defaultMessage ? response.data.defaultMessage : "" }
    } catch (error: any) {
        errorLogger(`Encountered error while updating console authorization request: ${errorParser(error)}`)
        return { respStatus: error.response.status ? error.response.status : 500, respContextId: contextId, respMessage: error.response.data.defaultMessage }
    }
}

export interface IConsoleSwitch {
    contextId: string
    accessToken: string
    connectionType: EConnectionType
    connectionStatus: EConnectionState
}

export const consoleSwitchService = async (props: IConsoleSwitch) => {
    const { contextId, connectionType, connectionStatus, accessToken } = props
    const multiVendorEnabled = isMultiVendorEnabled()
    const urls = fetchGlobalURLs()
    try {
        const response = await putService({
            url: `${urls.CONSOLE_SERVICES_URL}${multiVendorEnabled ? CONSOLE_SESSION_EP : CONSOLE_CONNECTION}/${contextId}/$switch`,
            headers: getRequestHeader(accessToken, DEFAULT_API_VERSION),
            data: {
                newConnectionType: connectionType,
                newConsoleStatus: connectionStatus
            },
        })
        return { respStatus: response.status, respContextId: response.data.contextId, respMessage: response.data.defaultMessage ? response.data.defaultMessage : "" }
    } catch (error: any) {
        errorLogger(`Encountered error while performing ${connectionType === EConnectionType.FULL_CONTROL ? "resume" : "park"} operation on console session: ${errorParser(error)}`)
        throw error
    }
}

export const getRequestHeader = (accessToken: string, apiVersion: string) => ({
    [CONTENT_TYPE]: APPLICATION_JSON,
    Authorization: accessToken,
    [API_VERSION]: apiVersion,
})

export const getCommandLineArgs = async (params: any) => {
    const { accessToken, consoleUrl, customParams } = params
    const multiVendorEnabled = isMultiVendorEnabled()
    const headers = getRequestHeader(accessToken, DEFAULT_API_VERSION)
    try {
        const response = await getService({
            headers,
            url: `${consoleUrl}${multiVendorEnabled ? EMERALD_KVM_MAPPING_CLI_ARGS : EMERALD_FETCH_CLI_ARGS}${customParams}`
        })
        return response.data
    } catch (error: any) {
        errorLogger(`Failed to fetch active connections with error: ${errorParser(error)}`)
        if (error.response) {
            throw error
        } else { throw new Error("Network Error") }
    }
}
