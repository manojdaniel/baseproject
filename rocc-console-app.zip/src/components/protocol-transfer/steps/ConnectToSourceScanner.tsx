/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import en from "../../../resources/translations/en-US"
import ProtocolTransferWizardContent from "../ProtocolTransferWizardContent"
import { sourceContent, destinationContent } from "./StepUtility"

const ConnectToSourceScanner = () => {
    const { intl } = getIntlProvider()
    const stepMessageContent = intl.formatMessage({ id: "content.protocolTransfer.copyProtocol", defaultMessage: en["content.protocolTransfer.copyProtocol"] })

    return <ProtocolTransferWizardContent sourceScannerContent={sourceContent(true)}
        destinationScannerContent={destinationContent(false)}
        stepMessageContent={stepMessageContent} />
}

export default ConnectToSourceScanner
