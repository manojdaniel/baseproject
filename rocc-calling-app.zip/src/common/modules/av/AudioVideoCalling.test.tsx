/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { shallow } from "enzyme"
import React from "react"
import AudioVideoCalling from "./AudioVideoCalling"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))
jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))
const activeCall: any = {
    contextId: "contextId",
    callAcceptedTime: new Date(),
    participants: [{ uuid: "uuid" }]
}

describe("AudioVideoCalling component", () => {
    it("should render AudioVideoRoom component with renderDimensions property", () => {
        const wrapper = shallow(<AudioVideoCalling activeCall={activeCall} />)
        const audioVideoRoomComponent = wrapper.find("AudioVideoRoom")

        expect(audioVideoRoomComponent).toHaveLength(1)
    })
})
