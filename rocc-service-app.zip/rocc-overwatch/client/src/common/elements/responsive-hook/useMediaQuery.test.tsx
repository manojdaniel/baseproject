/*
 * Created on Mon Nov 28 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mount } from "enzyme"
import React from "react"
import useMediaQuery from "./useMediaQuery"

const mockMatchMedia = () => {
    Object.defineProperty(window, "matchMedia", {
        writable: true,
        value: jest.fn().mockImplementation(query => ({
            matches: false,
            media: query,
            onchange: null,
            addListener: jest.fn(), // Deprecated
            removeListener: jest.fn(), // Deprecated
            addEventListener: jest.fn(),
            removeEventListener: jest.fn(),
            dispatchEvent: jest.fn(),
        }))
    })
}

describe("useMediaQuery test cases", () => {
    it("useMediaQuery tests ", () => {
        mockMatchMedia()
        const TestComponent = () => {
            const widthTrigger = useMediaQuery("(min-width: 1300px)")
            return widthTrigger ? <div /> : <span />
        }
        const wrapper = mount(<TestComponent />)
        wrapper.update()
        wrapper.unmount()
        expect(wrapper.find("div")).toBeDefined()
    })
})
