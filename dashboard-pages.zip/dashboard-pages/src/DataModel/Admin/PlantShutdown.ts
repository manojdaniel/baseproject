export const plantShutdownData = [
    {
      "affiliateId": 17,
      "affiliateName": "aff test",
      "plantId": 25,
      "plantName": "quas-222 plant test",
      "countryId": 7,
      "countryName": "test country",
      "abbreviation": "a_test",
      "shutdown": false,
      "startDate": "2022-08-19",
      "endDate": "2022-08-19",
      "remarks": "Some Remarks"
    },
    {
      "affiliateId": 14,
      "affiliateName": "affiliate test",
      "plantId": 22,
      "plantName": "quas-1 plant test",
      "countryId": 7,
      "countryName": "test country",
      "abbreviation": "afft_test",
      "shutdown": false,
      "startDate": "2023-08-08",
      "endDate": "2023-08-25",
      "remarks": "Remarks"
    }
  
  ];