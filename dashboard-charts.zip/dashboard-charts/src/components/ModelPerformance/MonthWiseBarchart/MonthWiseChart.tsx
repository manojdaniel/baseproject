// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
interface Props {
	data: any[];
}
const MonthWiseChart = ({ data }: Props) => {
	useLayoutEffect(() => {
		if (data.length > 0) {
			/* Chart code */
			// Create root element
			// https://www.amcharts.com/docs/v5/getting-started/#Root_element
			let root = am5.Root.new("chartdiv4");
			/* remove amchart logo */

			root._logo.dispose();
			let mydata = data.map(function (item: any) {
				return {
					date: item.date,
					truePositive: handleData(item.truePositive),
					falsePositive: handleData(item.falsePositive),
					unClassified: handleData(item.unClassified),
				};

			});
			function handleData(val) {
				if (val === 0) return null;
				else return val;
			}

			let Topdata = [];
			mydata.forEach((device, index) => {
				Topdata[index] = { ...device };
			});
			// Set themes
			// https://www.amcharts.com/docs/v5/concepts/themes/
			root.setThemes([am5themes_Animated.new(root)]);

			let chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					height: am5.percent(90),
					panX: false,
					panY: false,
					wheelX: "panX",
					wheelY: "zoomX",
					layout: root.verticalLayout,
					// x: 200,
				})
			);

			chart.get("colors").set("colors", [
				am5.color(0x929292), //Gray
				am5.color(0x3bb44a), //green
				am5.color(0xe35205), //red

			]);

			chart.zoomOutButton.get("background").setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8,
				cursorOverStyle: am5.color(0x009fdf)
			});

			chart.zoomOutButton.get("background").states.create("hover", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart.zoomOutButton.get("background").states.create("down", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			let xRenderer = am5xy.AxisRendererX.new(root, { minGridDistance: 40 });

			// Create X-Axis
			var xAxis = chart.xAxes.push(
				am5xy.DateAxis.new(root, {
					width: am5.percent(80),
					height: am5.percent(120),

					baseInterval: { timeUnit: "month", count: 1 },
					markUnitChange: true,
					renderer: xRenderer,
					paddingBottom: 10,
				})
			);
			xRenderer.grid.template.setAll({
				fontSize: "0.9rem",
				paddingBottom: 10,
			});
			xRenderer.labels.template.setAll({
				fontSize: "0.9rem",
				paddingBottom: 10,
			});

			let yAxis = chart.yAxes.push(
				am5xy.ValueAxis.new(root, {
					min: 0,
					renderer: am5xy.AxisRendererY.new(root, {
						strokeOpacity: 0.1,
						fontSize: "0.9rem",
					}),
				})
			);
			let yRenderer = yAxis.get("renderer");
			yRenderer.labels.template.setAll({
				fontSize: "0.9rem",
			});

			// Add legend
			// https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
			// var legend = chart.leftAxesContainer.children.push(
			// 	am5.Legend.new(root, {
			// 		background: am5.Rectangle.new(root, {}),
			// 		height: am5.percent(80),
			// 		centerX: am5.percent(8),
			// 		x: -170,
			// 		position: "absolute",
			// 		centerY: am5.percent(10),
			// 		useDefaultMarker: true,
			// 		y: 50,
			// 	})
			// );
			// legend.markerRectangles.template.setAll({
			// 	width: 18,
			// 	height: 10,
			// 	cornerRadiusTL: 8,
			// 	cornerRadiusTR: 7,
			// 	cornerRadiusBL: 7,
			// 	cornerRadiusBR: 7,
			// 	fontSize: 11,
			// 	y: 4,
			// });

			// Add series
			// https://www.amcharts.com/docs/v5/charts/xy-chart/series/
			function makeSeries(name: any, fieldName: any) {
				var series = chart.series.push(
					am5xy.ColumnSeries.new(root, {
						name,
						xAxis,
						yAxis,
						valueYField: fieldName,
						valueXField: "date",
						stacked: true,
						fontSize: "0.9rem",
					})
				);
				let tooltip = am5.Tooltip.new(root, {
					getFillFromSprite: true,

					getLabelFillFromSprite: true,
				});
				series.set("tooltip", tooltip);
				series.columns.template.setAll({
					tooltipText: "{valueY}",
					tooltipY: am5.percent(5),
					fontSize: "0.9rem",

					width: am5.percent(35),
				});
				series.data.processor = am5.DataProcessor.new(root, {
					dateFormat: "yyyy-MM-dd",

					dateFields: ["date"],
				});

				series.data.setAll(Topdata);

				series.bullets.push(function () {
					return am5.Bullet.new(root, {
						sprite: am5.Label.new(root, {
							fill: root.interfaceColors.get("alternativeText"),
							centerY: am5.p50,
							centerX: am5.p50,
							populateText: true,
						}),
					});
				});

				series.appear();
				// legend.data.push(series);
			}

			makeSeries("UnClassified", "unClassified");
			makeSeries("True Positive", "truePositive");
			makeSeries("False Positive", "falsePositive");

			chart.appear(1000, 100);

			return () => {
				root.dispose();
			};
		}
	}, [data]);
	return (
		<div id="chartdiv4" style={{ width: "100%", height: "250px" }}></div>
	);
};

export default MonthWiseChart;
