import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AlertStatusList from "./AlertStatusList";

jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});
describe("AlertStatusList", () => {
	const data = [
		{
			timeStamp: "2022-03-20T16:39:57.000Z",
			assetID: "A001",
			alertID: "AL01",
			assetDescription: "Asset 1",
			modelName: "Model 1",
			alertStatus: "Active",
			modelStatus: "Running",
			alertClass: "Class 1",
			ageing: "0 days",
		},
		{
			timeStamp: "2022-03-19T12:08:21.000Z",
			assetID: "A002",
			alertID: "AL02",
			assetDescription: "Asset 2",
			modelName: "Model 2",
			alertStatus: "Resolved",
			modelStatus: "Stopped",
			alertClass: "Class 2",
			ageing: "1 day",
		},
	];
	it("should render the component without errors", () => {
		render(<AlertStatusList data={data} />);
	});
});
