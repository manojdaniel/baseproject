/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import AudioVideoSource from "./AudioVideoSource"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({}),
}))

describe("AudioVideoSource component", () => {
    let wrapper: any
    let props: any

    beforeEach(() => {
        props = {
            activeRoom: null,
            previewTracks: null,
        }

    })
    it("should render empty Fragment component", () => {
        withHooks(() => {
            wrapper = shallow(<AudioVideoSource {...props} />)
            expect(wrapper.find("Fragment")).toHaveLength(1)
        })
    })
})
