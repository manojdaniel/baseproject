/*
 * Created on Fri Dec 3 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, ERoomStatus, EUserPresence} from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import { rooms } from "../../mocks/mock-data"
import { EConnectionState } from "../../redux/interfaces/enums"
import RoomCardComponent from "./RoomCardComponent"
import * as services from "./RoomCardServices"

const roomcardProps = {
    roomIdentity: {
        id: 37,
        name: "CT Analytics Scanner 04",
        uuid: "room uuid",
        address: "Trauma Department"
    },
    isStarred: false,
    modalityProps: {
        modalityName: "MR",
        modalityStyles: "",
    },
    userNameProps: {
        techUserName: "Test",
        techUserId: "tech user id"
    },
    flags: {
        isMultiConsoleFlagEnabled: false,
        isRoomActiveSession: false,
        protocolTransferFlagEnabled: true,
        isStarredFlagEnabled: true
    },
    connectionProps: {
        connectionType: "VIEW",
        connectionMode: "COMMANDCENTER"
    },
    protocolTransferReducerProps: {
        protocolTransferStatus: false,
        completedDestinations: false
    },
    monitorName: "1",
    footerProps: {
        phoneNumbers: [{
            "text": "1234567890",
            "value": "1234567890"
        }],
        roomUuid: "",
        isDisabled: false,
        modalityName: "CT",
        presence: EUserPresence.OFFLINE,
        roomName: "",
    },
    roomStatus: ERoomStatus.IDLE,
}

const configReducer = {
    urls: {
        MANAGEMENT_SERVICE_URL: "abc.com"
    }
}

const mockDispatch = jest.fn()
jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalRooms: jest.fn(() => {
        return rooms
    }),
    fetchMetaSiteId: jest.fn(() => {
        return 1
    }),
    fetchGlobalAppVersion: jest.fn(() => {
        return "test-version-123"
    })
}))

jest.mock("../../common/helpers/helpers", () => ({
    getConfigReducerFromGlobalStore: jest.fn(() => {
        return configReducer
    }),
}))
jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        externalReducer: {
            featureFlags: {
                ROCC_VIEW_AUTHORIZATION: true
            }
        }
    })
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({
        userId: "someuserId",
        userUuid: "someUUid",
        token: "abc",
        consoleDetails: {
            activeConsoleSessions: [],
            activeConsoleTransactions: [
                {
                    roomUuid: "room uuid"
                }
            ]
        },
        workflows: [],
    }),
    useDispatch: () => mockDispatch
}))

describe("Room Card Component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        wrapper = shallow(<RoomCardComponent {...roomcardProps} />)
    })

    it("should render Room Card", () => {
        expect(wrapper.find("RoomCardInfoComponent").exists()).toBeTruthy()
        expect(wrapper.find("ModalityInfo").exists()).toBeTruthy()
        expect(wrapper.find("UserNameComponent").exists()).toBeTruthy()
        expect(wrapper.find("RoomCardFooter").exists()).toBeTruthy()
    })

    it("should render star and unstar room functionality", () => {
        const response = {
            status: 200
        }
        const spy = jest.spyOn(services, "setStarredRoom").mockImplementation(() => {
            return Promise.resolve(response)
        })
        wrapper.find("RoomCardInfoComponent").props().starredHandler("uuid", true)
        expect(spy).toHaveBeenCalled()
    })
})

describe(" should render loader", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    const useEffectMockMethod = () => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
    }
    afterEach(() => {
        jest.clearAllMocks()
    })
    beforeEach(() => {
        const connectionStatus = EConnectionState.CONNECTING
        React.useState = jest.fn().mockReturnValueOnce([connectionStatus, jest.fn()]).mockReturnValueOnce([[EConnectionType.VIEW], jest.fn()])
    })
    it("should render loader", () => {
        useEffectMockMethod()
        wrapper = shallow(<RoomCardComponent {...roomcardProps} />)
        expect(wrapper.find("CustomLoader").exists()).toBeTruthy()
    })
})
