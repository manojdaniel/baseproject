"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import traceback
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_PARENT_ORG_ID

from src.constants.constants import ROCC_PROXY_URL, COMPLETED
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs, ETasks
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.rbac_services.rbac_services import setup_rbac_permissions, setup_fse_rbac_role_mappings_for_parent_org

LOG = create_logger("RBACInfraSetup")


class RBACInfraSetup:
    def __init__(self):
        self._success = False

    def start_job(self, profile_configs, rocc_proxy_url, vault_credentials_response, user_details):
        try:
            LOG.info(f"Starting Job: {EJobs.RBAC_INFRA_SETUP.value}")
            self.load_proxy_url(rocc_proxy_url=rocc_proxy_url)
            self.load_vault_configs(profile_configs)
            self._user_uuid = user_details["userId"]
            self._user_org = user_details["orgId"]
            self._token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                          issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                          private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self.execute_tasks(vault_credentials_response=vault_credentials_response)
            prepare_and_post_audit(event_type=EJobs.RBAC_INFRA_SETUP.value, event_subtype=EJobs.RBAC_INFRA_SETUP.value, action="E", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=self._profile_configs[VAULT_PARENT_ORG_ID],
                                   token=self._token,
                                   **{EJobs.RBAC_INFRA_SETUP.value: COMPLETED},
                                   **{"User Org Details": self._user_org})
            LOG.info(f"Finished Job: {EJobs.RBAC_INFRA_SETUP.value}")
        except RoccException as e:
            LOG.error("Exception {e}")
            raise RoccException(e.status_code, str(e.payload))
        except Exception as e:
            LOG.error(f"General exception occured during RBAC infra setup {e}")
            LOG.error(traceback.print_exc())
        return self._success

    def load_vault_configs(self, profile_configs):
        """Fetch vault configs from the profile path"""
        try:
            self._profile_configs = profile_configs if profile_configs else get_profile_data()
            LOG.info("Profile configs loaded")

        except Exception as ex:
            self._success = False
            LOG.error(f"Failed to retrieve vault profile configs with error: {ex}")
            raise RoccException(500, f"Failed to retrieve vault profile configs with error: {ex}")

    def load_proxy_url(self, rocc_proxy_url=None):
        """Fetch proxy url"""
        try:
            self._rocc_proxy_url = rocc_proxy_url if rocc_proxy_url else os.environ[ROCC_PROXY_URL]
        except Exception as ex:
            self._success = False
            LOG.error(f"Failed to retrieve proxy url with error: {ex}")
            raise RoccException(500, f"Failed to retrieve proxy url with error: {ex}")

    def roll_back_on_failure(self):
        """ Roll-back, if there is a failed task """
        pass

    def execute_tasks(self, vault_credentials_response):
        """
        Tasks:
        - SETUP_RBAC_PERMISSIONS
        - Setup FSE R-BAC Roles, Permission, Mappings for Parent org
            - Check if roles are present in DB. If not add it
            - Check if roles are existing. If not add it to R-BAC
            - Check if permission are existing. If not add it to R-BAC
            - Check if role-permission-mapping are existing. If not add it to R-BAC
        """
        try:
            org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            response = setup_rbac_permissions(url=self._rocc_proxy_url,
                                              token=self._token)
            prepare_and_post_audit(event_type="Customer org Rbac Infra setup", event_subtype="Setup customer org permission", action="C", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=org_id,
                                   token=self._token,
                                   **{"Setup customer org permission": COMPLETED},
                                   **{"User Org Details": self._user_org})
            setup_fse_rbac_role_mappings_for_parent_org(proxy_url=self._rocc_proxy_url,
                                                        profile_configs=self._profile_configs,
                                                        vault_credentials_response=vault_credentials_response,
                                                        org_id=org_id,
                                                        user_uuid=self._user_uuid)
            prepare_and_post_audit(event_type="Parent org Rbac Infra setup", event_subtype="Setup parent org role and permission mapping", action="C", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=org_id,
                                   token=self._token,
                                   **{"Setup parent org role and permission mapping": COMPLETED},
                                   **{"User Org Details": self._user_org})
            self._success = True if response else False
        except Exception as e:
            LOG.error(f"Execution of RBAC tasks failed with error {e}")
        return False
