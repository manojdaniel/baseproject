# Changelog

## [1.2.4](https://github.com/philips-internal/rocc-cc-host/compare/1.2.3...1.2.4) (2022-11-29)


### Bug Fixes

* authentication components error message ([aae7032](https://github.com/philips-internal/rocc-cc-host/commit/aae7032e570b9252672ecde5ea2d65194e50a190))
* cctv window close changes ([7fef6ec](https://github.com/philips-internal/rocc-cc-host/commit/7fef6ec9ca46d3366e71d52059e1b649c73d2b96))
* close cctv if single console session ([e614663](https://github.com/philips-internal/rocc-cc-host/commit/e6146638d3e449ab7bb42961440754a26c0540c8))
* live window icon not showing when 2 receivers ([c15db3c](https://github.com/philips-internal/rocc-cc-host/commit/c15db3c6ac35313327b093dfd5a49e805794b758))
* roommonitoring nfcc fix ([913fdbf](https://github.com/philips-internal/rocc-cc-host/commit/913fdbfffde199b14da3efb02381b6819a75d66d))
* updated console component version ([ba3bd56](https://github.com/philips-internal/rocc-cc-host/commit/ba3bd565909e4d8f7b049ab1e2116ea319c523ce))
* updated locales ([01744e6](https://github.com/philips-internal/rocc-cc-host/commit/01744e6bc0e920fdbafe1bd84731143010e29acf))
* username validation error message persistance ([20d35d1](https://github.com/philips-internal/rocc-cc-host/commit/20d35d1223e38f061a2c2c5ee86afb9239781689))

## [1.2.3](https://github.com/philips-internal/rocc-cc-host/compare/1.2.2...1.2.3) (2022-11-24)


### Bug Fixes

* additional tabs ([7a19fc8](https://github.com/philips-internal/rocc-cc-host/commit/7a19fc8cea5596f1a6a148cf687546e4fa476c7d))
* enabled hybrid connection ([84288d3](https://github.com/philips-internal/rocc-cc-host/commit/84288d31def12dddfe86c4c4986ef0910d77660f))

## [1.2.2](https://github.com/philips-internal/rocc-cc-host/compare/1.2.1...1.2.2) (2022-11-18)


### Bug Fixes

* demo video url change ([f9fc1f2](https://github.com/philips-internal/rocc-cc-host/commit/f9fc1f2560e167612b7278693c90e3536c492033))
* updated insights key ([091e939](https://github.com/philips-internal/rocc-cc-host/commit/091e93920455c71827c15e9d57a1c7d7b0208a35))

## [1.2.1](https://github.com/philips-internal/rocc-cc-host/compare/1.2.0...1.2.1) (2022-11-11)


### Bug Fixes

* update global components version ([ebface9](https://github.com/philips-internal/rocc-cc-host/commit/ebface98ad6618e4ab5e83dcc4587a17f7c7ca79))

## [1.2.0](https://github.com/philips-internal/rocc-cc-host/compare/1.1.7...1.2.0) (2022-11-10)


### Features

* add nfcc upgrade notification bubble ([b99de03](https://github.com/philips-internal/rocc-cc-host/commit/b99de03814a19904b31068c7c21d9215391bc669))


### Bug Fixes

* resolved conflict ([3f90e7c](https://github.com/philips-internal/rocc-cc-host/commit/3f90e7c0e6c9574e3f13dc295a574a2d63e5b3c9))
* resolved conflict ([11a4754](https://github.com/philips-internal/rocc-cc-host/commit/11a475476f2e5d4d12b0ab79668eed2d909d4d4f))
* send logs to azure with additional tags and org id ([451f17e](https://github.com/philips-internal/rocc-cc-host/commit/451f17ecba3c595c08b0e87d5f7c8e3e13d163d3))

## [1.1.7](https://github.com/philips-internal/rocc-cc-host/compare/1.1.6...1.1.7) (2022-11-07)


### Bug Fixes

* bug-139632 admin onboarding screen getting skipped ([38f4ebe](https://github.com/philips-internal/rocc-cc-host/commit/38f4ebeee072f318b4f6718a20365b5d105972be))
* nfcc notification not disappear after upgrade ([12b4919](https://github.com/philips-internal/rocc-cc-host/commit/12b4919fac3ef85a099f4aaa720a19e4106e77a8))

## [1.1.6](https://github.com/philips-internal/rocc-cc-host/compare/1.1.5...1.1.6) (2022-11-04)


### Bug Fixes

* remove unused component ([22f4a4b](https://github.com/philips-internal/rocc-cc-host/commit/22f4a4b3d7b07e6700f2342af7761eb10e7f1c34))
* us 139474 admin onboard fixing ([6f236eb](https://github.com/philips-internal/rocc-cc-host/commit/6f236eb307db3029b93d68a8f3c77aee8968fae3))

## [1.1.5](https://github.com/philips-internal/rocc-cc-host/compare/1.1.4...1.1.5) (2022-10-28)


### Bug Fixes

* page not found error ([5802527](https://github.com/philips-internal/rocc-cc-host/commit/58025276fc3b139086c45a2757df0b3ebb272ba7))
* page not found error ([e0fcb99](https://github.com/philips-internal/rocc-cc-host/commit/e0fcb991ce3e4a729b2030081b5f1ca825dc30ee))
* providing fix for master failure [MASTER-FIX] ([1863b5b](https://github.com/philips-internal/rocc-cc-host/commit/1863b5bc810c80cf398a4c03f60fb55b4e425bfd))

## [1.1.4](https://github.com/philips-internal/rocc-cc-host/compare/1.1.3...1.1.4) (2022-10-13)


### Bug Fixes

* check for page not found issue ([f1b86e6](https://github.com/philips-internal/rocc-cc-host/commit/f1b86e61c6fa69115feefd87e5c2422dcc534d6e))

## [1.1.3](https://github.com/philips-internal/rocc-cc-host/compare/1.1.2...1.1.3) (2022-10-11)


### Bug Fixes

* added contextId to pane ([3780973](https://github.com/philips-internal/rocc-cc-host/commit/378097324daa9ba33edc0b968e945f3421320706))

## [1.1.2](https://github.com/philips-internal/rocc-cc-host/compare/1.1.1...1.1.2) (2022-10-03)


### Bug Fixes

* updated an endpoint to fetch the proper locale configuration ([6305ebe](https://github.com/philips-internal/rocc-cc-host/commit/6305ebe28996f52e933e5d413c7b01fa4a9cd00b))

## [1.1.1](https://github.com/philips-internal/rocc-cc-host/compare/1.1.0...1.1.1) (2022-09-28)


### Bug Fixes

* sample commit for updating SL branch ([6e70be2](https://github.com/philips-internal/rocc-cc-host/commit/6e70be23b5f06e94945fd3b7c135d08a201e8076))
* sample commit to release new version ([9e43db9](https://github.com/philips-internal/rocc-cc-host/commit/9e43db9291c0936d8c5626fed91790e83efdc001))

## [1.1.0](https://github.com/philips-internal/rocc-cc-host/compare/1.0.9...1.1.0) (2022-09-22)


### Features

* useEffect added to to re initialize featureflag after refresh ([2a01fa3](https://github.com/philips-internal/rocc-cc-host/commit/2a01fa3722c5c4798130482ade5c781da348d0b0))


### Bug Fixes

* sonar fix for code duplicated ([946a134](https://github.com/philips-internal/rocc-cc-host/commit/946a13486d1d29bd812e2d85fbd908002f6922d6))
* using performance interface to detect reload ([5235ef1](https://github.com/philips-internal/rocc-cc-host/commit/5235ef13c5bf4eb6145c5023fd59ceab75d8dfdb))

## [1.0.9](https://github.com/philips-internal/rocc-cc-host/compare/1.0.8...1.0.9) (2022-09-20)


### Bug Fixes

* updated with azure logs ([c1d8720](https://github.com/philips-internal/rocc-cc-host/commit/c1d87209b9ac0605d94a61897119d6f6adda01af))

## [1.0.8](https://github.com/philips-internal/rocc-cc-host/compare/1.0.7...1.0.8) (2022-09-18)


### Bug Fixes

* addressed feedback comments ([213a275](https://github.com/philips-internal/rocc-cc-host/commit/213a2750992b20114edc30f81d29c763c891d8db))
* us-137826-popup-css-changes ([fd5d0d7](https://github.com/philips-internal/rocc-cc-host/commit/fd5d0d791684353730e9e5566f851241c79ed8e4))

## [1.0.7](https://github.com/philips-internal/rocc-cc-host/compare/1.0.6...1.0.7) (2022-09-13)


### Bug Fixes

* merge conflicts are resolved ([7a20dcc](https://github.com/philips-internal/rocc-cc-host/commit/7a20dcccd7a902ac6ea29a3a46c2403703f564bb))
* updated presence service updated and removed userlocation in customReducer ([9938c55](https://github.com/philips-internal/rocc-cc-host/commit/9938c55f1c3349bc4d0bc5c348135454bf6a7576))
* updated presence service updated with API version number ([861474c](https://github.com/philips-internal/rocc-cc-host/commit/861474c1c541f6660b56ee33dd7b34118a3dd7fe))
* updated presence service updated with API version number ([777260e](https://github.com/philips-internal/rocc-cc-host/commit/777260ed5cf841771a0fbd9484107e917d058821))

## [1.0.6](https://github.com/philips-internal/rocc-cc-host/compare/v1.0.5...1.0.6) (2022-09-12)


### Bug Fixes

* remove prefix v from version ([bcfb5da](https://github.com/philips-internal/rocc-cc-host/commit/bcfb5da8fed0fdbae3e12fc7e285dd88366bb605))

## [1.0.5](https://github.com/philips-internal/rocc-cc-host/compare/v1.0.4...v1.0.5) (2022-09-08)


### Bug Fixes

* enable autoversioing ([087c487](https://github.com/philips-internal/rocc-cc-host/commit/087c487db4e317e6ba220d4128a0cff1ac0abfa4))
