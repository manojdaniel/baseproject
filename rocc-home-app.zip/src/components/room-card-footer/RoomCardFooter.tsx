/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EClinicalRole, EConnectionType, FeatureFlagHelper, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { MoreOptionsComponent } from "@rocc/rocc-rooms-components"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Popup } from "semantic-ui-react"
import { CURRENT_APP_NAME, PARENT_STORE, ROOM_CARD } from "../../constants/constants"
import { IRoomCardFooter } from "../../lib/types"
import { IChatContact, IStore } from "../../redux/interfaces/types"
import { fetchGlobalCurrentUser, fetchGlobalReceivers } from "../../redux/store/externalAppStates"
import { checkIfEditSessionGoingOn, checkIfRoomHasActiveSession } from "../room-card-component/RoomCardHelper"
import styles from "./RoomCardFooter.module.scss"
import { getIntlProvider } from "@rocc/rocc-global-components"
import en from "../../resources/locales/en_US.json"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"

const remoteLoadFailMsg = `In app: ${CURRENT_APP_NAME}, failed to load`
const WebCallFeature = React.lazy(() => import("roccCalling/WebCallFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} WebCallFeature with error: ${errorParser(ex)}`)))
const PhoneCallFeature = React.lazy(() => import("roccCalling/PhoneCallFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} PhoneCallFeature with error: ${errorParser(ex)}`)))
const ConsoleTrigger = React.lazy(() => import("roccConsole/ConsoleTrigger").catch((ex) => errorLogger(`${remoteLoadFailMsg} ConsoleTrigger with error: ${errorParser(ex)}`)))
const ChatTriggerFeature = React.lazy(() => import("roccChat/ChatTriggerFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} ChatTrigger with error: ${errorParser(ex)}`)))

const RoomCardFooter = ({ isDisabled, phoneNumbers, roomUuid, modalityName, roomName, presence }: IRoomCardFooter) => {
    const [moreOptions, setMoreOptions] = useState([] as any[])
    const [phoneCallEnabled, setPhoneCallEnabled] = useState(true as boolean)
    const [multiEditEnabled, setMultiEditEnabled] = useState(false)
    const { activeSessions, featureFlags, permissions, protocolTransferStatus } = useSelector((state: IStore) => ({
        activeSessions: state.externalReducer.consoleDetails.activeConsoleSessions,
        featureFlags: state.externalReducer.featureFlags,
        permissions: state.externalReducer.permissions,
        protocolTransferStatus: state.externalReducer.protocolTransferDetails.protocolTransferStatus
    }))
    const currentUser = fetchGlobalCurrentUser()
    const receivers = fetchGlobalReceivers()

    const arr: any[] = []
    const { INCOGNITO_ROLE, PROTOCOL_MANAGER } = EClinicalRole
    const incognitoRoleEnabled = !!permissions.CONSOLE_VIEW_INCOGNITO
    const pmRoleEnabled = !!permissions.CONSOLE_EDIT_WITHOUT_AUTHORIZATION
    const { allRoles } = currentUser
    const isIncognito = allRoles.includes(INCOGNITO_ROLE)
    const isProtocolManager = allRoles.includes(PROTOCOL_MANAGER)

    const { intl } = getIntlProvider()

    const getMoreOptions = () => {
        if (isIncognito && incognitoRoleEnabled) {
            arr.push(<><ConsoleTrigger showTitle={true} roomUuid={roomUuid} connectionType={EConnectionType.INCOGNITO_VIEW} componentName={ROOM_CARD} /></>)
        }
        /**TODO: Create a Feature Flag for Protocol Managemer and check if its enabled */
        if (isProtocolManager && pmRoleEnabled) {
            arr.push(<><ConsoleTrigger showTitle={true} roomUuid={roomUuid} connectionType={EConnectionType.PROTOCOL_MANAGEMENT} componentName={ROOM_CARD} /></>)
        }
        setMoreOptions(arr)
    }

    useEffect(() => {
        getMoreOptions()
        permissions.CALL_WEB_TO_PHONE ? setPhoneCallEnabled(true) : setPhoneCallEnabled(false)
        !checkIfEditSessionGoingOn(activeSessions, roomUuid) ? setMultiEditEnabled(true) : setMultiEditEnabled(false)
    }, [featureFlags, activeSessions])

    const isMoreOptionsDisabled = () => {
        const isRoomActiveSession = checkIfRoomHasActiveSession(roomUuid, activeSessions)
        return isRoomActiveSession ? true : false
    }
    const footerDisabled = receivers && receivers.length > 0 ? isDisabled && !multiEditEnabled : isDisabled
    const renderFooter = () => {
        return (
            <div id="cardFooter" className={cx(styles.footer, footerDisabled && styles.disabled)}>
                <div className={styles.callIcon} id="webCall">
                    <WebCallFeature contactUuid={roomUuid} isDisabled={footerDisabled} modalityName={modalityName} />
                </div>
                {phoneCallEnabled && <div className={styles.callIcon} id="phoneCall">
                    <PhoneCallFeature contactUuid={roomUuid} phoneNumbers={phoneNumbers} isDisabled={isDisabled} showTitle={true} modalityName={modalityName} />
                </div>}
                {!!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_CHAT, false) && permissions.CHAT_CREATE && <div className={styles.callIcon} id="chatTrigger">
                    <ChatTriggerFeature
                        chatContacts={[{ uuid: roomUuid, name: roomName, clinicalRole: EClinicalRole.DEVICE, presence } as IChatContact]}
                        chatMetadata={{ title: roomName, description: `ScannerRoom`, useDefaultWindow: true }}
                        parentStoreName={PARENT_STORE}
                    />
                </div>}
                {moreOptions.length ?
                    <div className={cx(styles.moreOptionsButton)} id="moreOptions">
                        <MoreOptionsComponent
                            dropdownOptions={moreOptions}
                            isDisabled={isDisabled || protocolTransferStatus || isMoreOptionsDisabled()}
                        />
                    </div>
                    :
                    <></>
                }
            </div>
        )
    }

    const renderPopup = () => {
        return (
            isDisabled && <>
                <Popup
                    inverted
                    content={intl.formatMessage({ id: "content.roomBanner.switchToViewModeDescription", defaultMessage: en["content.roomBanner.switchToViewModeDescription"] })}
                    trigger={renderFooter()}
                    size={"large"}
                    position={"bottom right"}
                    style={{ font: "normal 400 1rem/1.33rem CentraleSans-Light" }}
                /></>

        )
    }

    const showPopup = () => {
        const isActiveIncognitoSession = activeSessions.find(session => session.connectionType === EConnectionType.INCOGNITO_VIEW)
        return isDisabled && isActiveIncognitoSession
    }

    return (
        <>
            {showPopup() ? renderPopup() : renderFooter()}
        </>
    )
}

export default RoomCardFooter
