/*
 * Created on Tue May 10 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import React from "react"
import { useCallOptionStatus } from "./customHooks"
import * as helpers from "./helpers"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        phoneCallStatus: ECallStatus.IDLE,
        featureFlags: {},
        videoCallStatus: { contextId: "contextId", callStatus: ECallStatus.IDLE },
        outgoingCall: { contextId: "" },
        incomingCall: { contextId: "" },
        onHoldCallDetails: {}
    }),
}))

describe("useCallOptionStatus tests", () => {
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }

    it("should return callStatus disabled with phone call and webcall as false", () => {
        const callStatusDisabled = { isPhoneCallDisabled: false, isWebCallDisabled: false }
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        React.useState = jest.fn().mockReturnValue([callStatusDisabled, () => { void (0) }])
        mockUseEffect()
        jest.spyOn(helpers, "checkIfCallGoingOn").mockImplementation(jest.fn()).mockReturnValue(false)
        jest.spyOn(helpers, "checkIfSeamlessEditFeatureExist").mockImplementation(jest.fn()).mockReturnValue(false)
        jest.spyOn(helpers, "getCallsWithParticipant").mockImplementation(jest.fn())
        expect(useCallOptionStatus("contactUuid")).toEqual({ "isPhoneCallDisabled": false, "isWebCallDisabled": false })
    })

    it("should check callStatus when phonecall is going on", () => {
        const callStatusDisabled = { isPhoneCallDisabled: true, isWebCallDisabled: true }
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        React.useState = jest.fn().mockReturnValue([callStatusDisabled, () => { void (0) }])
        mockUseEffect()
        jest.spyOn(helpers, "checkIfCallGoingOn").mockImplementation(jest.fn()).mockReturnValue(true)
        jest.spyOn(helpers, "checkIfSeamlessEditFeatureExist").mockImplementation(jest.fn()).mockReturnValue(false)
        jest.spyOn(helpers, "getCallsWithParticipant").mockImplementation(jest.fn())
        expect(useCallOptionStatus("contactUuid")).toEqual({ "isPhoneCallDisabled": true, "isWebCallDisabled": true })
    })
})
