import React, { useRef, useEffect, useState } from "react";
import AlertStatusByAsset from "charts/AlertStatusByAsset";
import StackBarChart from "charts/StackBarChart";
import AlertStatusDepartment from "charts/AlertStatusDepartment";
import {
    getmodelalertstatuspiechart,
    getmodeltotalalertstatusbyasset,
    getmodelalertstatusbydepartmentbyplant,
} from "../../../../redux/reducers/CommonReducer";
import { modeltotalalstackbarTransformer } from "../../../../utility/transformer/ModelPerformanceTransformers";
import { useDispatch, useSelector } from "react-redux";
import "./PerformanceDashboard.scss";
import Loader from "components/Loader";
import NoData from "components/NoData";
import moment from "moment";
import { encryptRSAData } from "../../../../utility/rsa";

const PerformanceDashboard = () => {
    let dispatch = useDispatch();
    const [assetBarData, setAssetBarData] = useState<any>([]);
    // const [assetstackBarData, setAssetstackBarData] = useState<any>([]);

    const {
        modelalertstatuspiechart,
        modeltotalalertstatusbyasset,
        modelalertstatusbydepartmentbyplant,
        globalSelecetedPlant,
        modelPerformanceAssetDropdownChangedValue,
        loadingmodelalertstatusbydepartmentbyplant,
        loadingmodelalertstatuspiechart,
        selectedBreadCrumbDate,
        breadCrumbDateFormated,
        breadCrumbDate,
        commonToDate,
        commonFromDate,
        commonFromDateFormat,
        commonToDateFormat,
    } = useSelector((state: any) => ({
        modelalertstatuspiechart: state.Common.modelalertstatuspiechart,
        modeltotalalertstatusbyasset: state.Common.modeltotalalertstatusbyasset,
        modelalertstatusbydepartmentbyplant:
            state.Common.modelalertstatusbydepartmentbyplant,
        globalSelecetedPlant: state.Common.globalSelecetedPlant,
        modelPerformanceAssetDropdownChangedValue:
            state.Common.modelPerformanceAssetDropdownChangedValue,

        loadingmodelalertstatusbydepartmentbyplant:
            state.Common.loadingmodelalertstatusbydepartmentbyplant,
        loadingmodelalertstatuspiechart:
            state.Common.loadingmodelalertstatuspiechart,

        commonFromDateFormat: state.Common.commonFromDateFormat,
        commonToDateFormat: state.Common.commonToDateFormat,
        commonToDate: state.Common.commonToDate,
        commonFromDate: state.Common.commonFromDate,

        selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
        breadCrumbDate: state.Common.breadCrumbDate,
        breadCrumbDateFormated: state.Common.breadCrumbDateFormated,
    }));

    useEffect(() => {
        let today = moment(new Date()).format("YYYY-MM-DD");
        if (breadCrumbDateFormated !== "" && breadCrumbDateFormated !== undefined) {
            if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
                if (modelPerformanceAssetDropdownChangedValue.label === "All") {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Pie Chart///plant id//{asset Id}{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Stacked Asset Bar///plant id/{asset Id}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); ////plant id/{asset Id}/{ userid }
                } else {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Pie Chart///plant id//{asset Id}{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Stacked Asset Bar///plant id/{asset Id}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); ////plant id/{asset Id}/{ userid }
                }
            } else {
                if (Object.keys(globalSelecetedPlant).length > 0) {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Pie Chart//{plantId}/{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //Stacked Asset Bar//{plantId}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{userid}
                }
            }
        }
    }, [breadCrumbDateFormated, modelPerformanceAssetDropdownChangedValue]);

    useEffect(() => {
        if (
            commonToDateFormat !== "" &&
            commonToDateFormat !== undefined &&
            commonFromDateFormat !== "Invalide date"
        ) {
            if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
                if (modelPerformanceAssetDropdownChangedValue.label === "All") {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Pie Chart///plant id//{asset Id}{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Stacked Asset Bar///plant id/{asset Id}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); ////plant id/{asset Id}/{ userid }
                } else {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Pie Chart///plant id//{asset Id}{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Stacked Asset Bar///plant id/{asset Id}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); ////plant id/{asset Id}/{ userid }
                }
            } else {
                if (Object.keys(globalSelecetedPlant).length > 0) {
                    dispatch(
                        getmodelalertstatuspiechart(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Pie Chart//{plantId}/{userid}
                    dispatch(
                        getmodeltotalalertstatusbyasset(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //Stacked Asset Bar//{plantId}/{userid}
                    dispatch(
                        getmodelalertstatusbydepartmentbyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{userid}
                }
            }
        }
    }, [modelPerformanceAssetDropdownChangedValue, commonToDateFormat]);

    useEffect(() => {
        if (modeltotalalertstatusbyasset.length > 0) {
            let transformer: any[];

            //   " modeltotalalertstatusbyasset" +
            //   JSON.stringify(modeltotalalertstatusbyasset)
            // );
            transformer = modeltotalalstackbarTransformer(
                modeltotalalertstatusbyasset
            );

            setAssetBarData(transformer);
        }
    }, [modeltotalalertstatusbyasset]);

    return (
        <div>
            <div className="pd-dashboard-box">
                <div className="common-box-inner">
                    <div className="common-box-filter">
                        <div className="title">ALERT CLASS BY ASSET</div>
                    </div>
                    <div className="common-box-content twocharts">
                        <div className="pd-box">
                            <div className="pd-left">
                                {loadingmodelalertstatuspiechart ? (
                                    <div className="tc-loaderpd"><Loader /></div>
                                ) : modelalertstatuspiechart.length === 0 ? (
                                    <div className="tc-loaderpd"><NoData /></div>
                                ) : (
                                    <AlertStatusByAsset data={modelalertstatuspiechart} />
                                )}
                            </div>
                            <div className="pd-right">
                                {loadingmodelalertstatuspiechart ? (
                                    <div className="tc-loaderpd"><Loader /></div>
                                ) : assetBarData.length === 0 ? (
                                    <div className="tc-loaderpd"><NoData /></div>
                                ) : (
                                    <StackBarChart data={assetBarData} />
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="pd-dashboard-box">
                <div className="common-box-inner">
                    <div className="common-box-filter">
                        <div className="title">ACCURACY TREND</div>
                    </div>
                    <div className="common-box-content">
                        {loadingmodelalertstatusbydepartmentbyplant ? (
                            <div className="tc-loaderpd"><Loader /></div>
                        ) : modelalertstatusbydepartmentbyplant.length === 0 ? (
                            <div className="tc-loaderpd"><NoData /></div>
                        ) : (
                            <AlertStatusDepartment
                                data={modelalertstatusbydepartmentbyplant}
                            />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
export default PerformanceDashboard;