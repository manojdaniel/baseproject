import unittest
from unittest.mock import patch
from src.constants.constants import SITES_DICT
from src.modules.validation_management.site_data_validation import SiteDataValidation


class SiteDataValidationTest(unittest.TestCase):
    @patch("src.modules.validation_management.site_data_validation.get_client_connection", side_effect=lambda service_token, org_infra_uuid: {"data": {"hsdpOrganizationId": "abc"}})
    @patch("src.modules.validation_management.site_data_validation.check_if_site_exists", side_effect=lambda client, site_identifier, site_info: True)
    def test_cc_site_validation_success(self, con, mock_site_exist):
        con.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        mock_site_exist.return_value = True
        site_data_validation = SiteDataValidation("service-token", "org-uuid")
        site_data_validation._transaction_data = {
            "summary": {
                "sites": {
                    "new": ["abc"]
                }
            }
        }
        site_dict = {"abc": "abc"}
        data_dict = {SITES_DICT: ""}
        site_data_validation.check_site_exists(site_dict)
        site_data_validation.initiate_data_validation(data_dict, {})
        self.assertIsNotNone(site_data_validation)
