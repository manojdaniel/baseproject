/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { Dispatch } from "hoist-non-react-statics/node_modules/@types/react"
import en from "../../../resources/translations/en-US"
import { ACTIVE_CALL_MESSAGE } from "../../../constants/constants"
import { setCallMessage } from "../../../redux/actions/callActions"
import { errorLogger } from "@rocc/rocc-logging-module"
import { MEDIASTREAM_EXCEPTION } from "./AudioVideoHelper"

export const handleError = (source: string, error: Error) => {
    errorLogger(`${source}: ${error.message} ${error.name}`)
}

export const handleVideoSwitchError = (error: any, dispatch: Dispatch<any>) => {
    const { intl } = getIntlProvider()
    switch (error.name) {
        case MEDIASTREAM_EXCEPTION.NOTALLOWED_ERROR:
            errorLogger(`Failed to attach video track, ${MEDIASTREAM_EXCEPTION.NOTALLOWED_ERROR}`)
            dispatch(setCallMessage(
                { messageType: ACTIVE_CALL_MESSAGE, message: intl.formatMessage({ id: "content.callMessage.cameraPermissionDenied", defaultMessage: en["content.callMessage.cameraPermissionDenied"] }), contact: DEFAULT_CONTACT_INFO }))
            break
        case MEDIASTREAM_EXCEPTION.NOTFOUND_ERROR:
            errorLogger(`Failed to attach video track  since camera not available, ${MEDIASTREAM_EXCEPTION.NOTFOUND_ERROR}`)
            dispatch(setCallMessage(
                { messageType: ACTIVE_CALL_MESSAGE, message: intl.formatMessage({ id: "content.callMessage.cameraUnavailable", defaultMessage: en["content.callMessage.cameraUnavailable"] }), contact: DEFAULT_CONTACT_INFO }))
            break
        default:
            errorLogger(`Failed to attach video track: ${error.name} ${JSON.stringify(error.message)}`)
            dispatch(setCallMessage({
                messageType: ACTIVE_CALL_MESSAGE, message: intl.formatMessage({ id: "content.callMessage.videoDeviceInitiateFailed", defaultMessage: en["content.callMessage.videoDeviceInitiateFailed"] }), contact: DEFAULT_CONTACT_INFO,
            }))

    }
}
