import React, { useRef, useEffect, useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import './AlertManagementPage.scss';

const AlertManagementPage = () => {

    const { userRole } =
        useSelector((state: any) => ({
            userRole: state.Common.userRole,
        }));

    const location = useLocation();
    const [elements, setElements] = useState<any>([]);
    const [selectedID, setSelectedID] = useState<any>(); // you could set a default id as well
    let navigate = useNavigate();
    console.log("userRole", userRole);
    useEffect(() => {
        handleMenuClick("ampHome")
    }, []);

    useEffect(() => {
        if (userRole === "Super Admin") {
            let dte = [
                { id: "ampHome", value: "Home" },
                { id: "ampMyTask", value: "My Tasks" },
                { id: "ampReports", value: "Reports" },
                { id: "ampUtilizationReport", value: "Utilization Report" },
                { id: "ampMasterReport", value: "Master Data Report" },
            ];
            setElements(dte);
        } else {
            let dte = [
                { id: "ampHome", value: "Home" },
                { id: "ampMyTask", value: "My Tasks" },
                { id: "ampReports", value: "Reports" },
            ];
            setElements(dte);
        }
    }, [userRole]);

    const handleMenuClick = (id: any) => {
        setSelectedID(id)
        switch (id) {
            case "ampHome":
                navigate('/plant/alertManagementPage/ampHome');
                break;
            case "ampMyTask":
                navigate('/plant/alertManagementPage/ampMyTask');
                break;
            case "ampReports":
                navigate('/plant/alertManagementPage/ampReports');
                break;
            case "ampUtilizationReport":
                navigate('/plant/alertManagementPage/ampUtilizationReport');
                break;
            case "ampMasterReport":
                navigate('/plant/alertManagementPage/ampMasterReport');
                break;
            default:
                break;
                return <div>{"INFO_NO_STEP_AVAILABLE"}</div>
        }
    }

    let currentPathname = location.pathname.split("/")[3];
    const getSelectedclassName = (link: any) => currentPathname === link ? "active" : "notselected";


    const TopContainer = () => {
        return (
            <>
                {elements.map((el) => (
                    <a
                        key={el.id}
                        className={`alertManagementSelector ${getSelectedclassName(el.id)}`}
                        onClick={() =>handleMenuClick(el.id)}
                    >
                        {el.value}
                    </a>
                ))}
            </>

        );
    }


    return (
        <div id="alertmanagementpage">

            <div id="alertmanagement-left"><TopContainer /></div>
            <div id="alertmanagement-right"><Outlet /></div>

        </div>
    );
};
export default AlertManagementPage;