/*
 * Created on Fri Dec 03 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, EConnectionType, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { infoLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { LocalTrack, Room } from "twilio-video"
import { IStore } from "../../../../redux/interfaces/types"
import { checkIfRoomAvailableInRoom } from "../../../helpers/multiCameraUtility"
import UseCameraController from "../../use-camera-controller/UseCameraController"
import MultiCameraGalleryView from "../gallery-view/MultiCameraGalleryView"
import { leaveMediaRoom, toggleDisplayCamera } from "../MultiCameraHelper"
import { IMultiCameraController, IMultiCamVideoTrack } from "../MultiCameraTypes"
import MultiCameraParticipant from "../participant/MultiCameraParticipant"

const FILENAME = "MultiCameraController.tsx : "

const MultiCameraController = (props: IMultiCameraController) => {

    const {
        activeTabIndex,
        consoleSessions,
        currentUser,
        featureFlags,
        displayLeftSidePanel,
        displayRightSidePanel,
    } = useSelector((state: IStore) => ({
        activeTabIndex: state.externalReducer.activeTabIndex,
        consoleSessions: state.consoleReducer.consoleSessions,
        currentUser: state.externalReducer.currentUser,
        featureFlags: state.externalReducer.featureFlags,
        displayLeftSidePanel: state.externalReducer.displayLeftSidePanel,
        displayRightSidePanel: state.externalReducer.displayRightSidePanel,
    }))

    const { consoleSession } = props
    const [remoteVideoStatus, setRemoteVideoStatus] = useState(false)
    const [activeRoom, setActiveRoom] = useState(undefined as unknown as Room)
    const [previewTracks, setPreviewTracks] = useState([] as LocalTrack[])
    const [fullscreenState, setFullscreenState] = useState(false)
    const [videoTracks, setVideoTracks] = useState([] as IMultiCamVideoTrack[])
    const previewTracksRef = useRef(previewTracks)
    const activeRoomRef = useRef(activeRoom)
    const videoTracksRef = useRef(videoTracks)
    const consoleSessionRef = useRef(consoleSession)
    const { NOT_AVAILABLE, INITIATED, AUTO_DISCONNECTED, CAMERA_STREAM_DISCONNECTED, DEVICE_DISCONNECTED } = ECameraStreamAvailable
    const dispatch = useDispatch()
    const loggerInitialMessage = `${FILENAME}: For user: ${currentUser.uuid} - Console session ${consoleSession.contextId}`
    
    const { initialiseRoom, initialiseMediaRoom } = UseCameraController({
        previewTracks,
        consoleSession: consoleSessionRef.current,
        filename: FILENAME,
        currentUserUuid: currentUser.uuid,
        dispatch,
        previewTracksRef,
        setVideoTracks,
        setPreviewTracks,
        setActiveRoom,
        setRemoteVideoStatus,
        isSyncSession: false,
    })

    useEffect(() => {
        return (() => {
            infoLogger(`${loggerInitialMessage} - Component destroyed leaving twillio room ${consoleSessionRef.current.mediaRoomDetails.mediaRoomId}.`)
            const props = {
                room: activeRoomRef.current,
                dispatch,
                setVideoTracks,
                videoTracksRef,
                setRemoteVideoStatus,
                disconnectState: AUTO_DISCONNECTED,
                consoleSession: consoleSessionRef.current,
            }
            leaveMediaRoom(props)
        })
    }, [])

    useEffect(() => {
        if (activeRoom) {
            activeRoomRef.current = activeRoom
        }
    }, [activeRoom])

    useEffect(() => {
        previewTracksRef.current = previewTracks
    }, [previewTracks])

    useEffect(() => {
        if (consoleSession) {
            consoleSessionRef.current = consoleSession
        }
    }, [consoleSession])

    const eventToggleDisplayCamera = () => {
        window.addEventListener("beforeunload", () => {
            if (consoleSessionRef.current.displayCameraToggle && consoleSession.connectionType !== EConnectionType.PROTOCOL_MANAGEMENT) {
                toggleDisplayCamera(consoleSessionRef.current, dispatch)
            }
        })
    }
    useEffect(() => {
        const { displayCameraToggle, mediaRoomDetails } = consoleSession
        const { cameraStreamAvailable } = mediaRoomDetails
        if (displayCameraToggle && ![NOT_AVAILABLE, DEVICE_DISCONNECTED].includes(cameraStreamAvailable) && !initialiseRoom) {
            infoLogger(`${loggerInitialMessage} - Display camera ${displayCameraToggle} initialize twillio stream.`)
            eventToggleDisplayCamera()
            initialiseMediaRoom()
        } else if (!displayCameraToggle && activeRoom) {
            infoLogger(`${loggerInitialMessage} - Display camera ${displayCameraToggle} leave twillio stream.`)
            const props = {
                room: activeRoomRef.current,
                dispatch,
                setVideoTracks,
                videoTracksRef,
                setRemoteVideoStatus,
                disconnectState: cameraStreamAvailable === DEVICE_DISCONNECTED ? DEVICE_DISCONNECTED : CAMERA_STREAM_DISCONNECTED,
                consoleSession: consoleSessionRef.current,
            }
            leaveMediaRoom(props)
        }
        return (() => {
            eventToggleDisplayCamera()
        })
    }, [props.consoleSession.displayCameraToggle])

    useEffect(() => {
        const { displayCameraToggle, mediaRoomDetails } = consoleSessionRef.current
        const { cameraStreamAvailable } = mediaRoomDetails
        const roomAvailable = checkIfRoomAvailableInRoom(activeRoomRef.current, consoleSessionRef.current.roomUuid)
        if (displayCameraToggle && cameraStreamAvailable !== NOT_AVAILABLE && !roomAvailable && !initialiseRoom) {
            const props = {
                room: activeRoomRef.current,
                dispatch,
                consoleSession: consoleSessionRef.current,
                videoTracksRef,
                setVideoTracks,
                setRemoteVideoStatus
            }
            leaveMediaRoom(props)
            infoLogger(`${loggerInitialMessage} - Camera stream is now ${cameraStreamAvailable} initialize twillio stream.`)
            initialiseMediaRoom()
        }
    }, [consoleSessionRef.current.mediaRoomDetails])

    useEffect(() => {
        const index = consoleSessions.findIndex((session => session.contextId === consoleSessionRef.current.contextId))
        const { displayCameraToggle, mediaRoomDetails } = consoleSession
        if (index !== -1 && displayCameraToggle) {
            if ((index + 1 === activeTabIndex) && ![INITIATED, DEVICE_DISCONNECTED].includes(mediaRoomDetails.cameraStreamAvailable)) {
                infoLogger(`${loggerInitialMessage} - reinitializing twillio stream due to tab switch.`)
                initialiseMediaRoom()
            } else if (activeTabIndex > 0 && (index + 1 !== activeTabIndex) && mediaRoomDetails.cameraStreamAvailable === INITIATED) {
                infoLogger(`${loggerInitialMessage}  - stopping twillio stream due to tab switch.`)
                const props = {
                    room: activeRoomRef.current,
                    dispatch,
                    consoleSession: consoleSessionRef.current,
                    videoTracksRef,
                    setVideoTracks,
                    setRemoteVideoStatus,
                }
                leaveMediaRoom(props)
            }
        }
    }, [activeTabIndex])

    return (
        <>
            <MultiCameraParticipant
                consoleSession={consoleSession}
                activeRoom={activeRoomRef.current}
                setVideoTracks={setVideoTracks}
                videoTracksRef={videoTracksRef}
                setRemoteVideoStatus={setRemoteVideoStatus}
                onDevice={false}
                setFullscreenState={setFullscreenState}
            />
            <MultiCameraGalleryView
                multiCameraFlagExists={featureFlags && featureFlags[ROCC_FEATURES.MULTI_CAMERA]}
                activeSessions={consoleSessions}
                consoleSession={consoleSession}
                videoTracks={videoTracks}
                setVideoTracks={setVideoTracks}
                remoteVideoStatus={remoteVideoStatus}
                setRemoteVideoStatus={setRemoteVideoStatus}
                displayRightSidePanel={displayRightSidePanel}
                displayLeftSidePanel={displayLeftSidePanel}
                currentUserUuid={currentUser.uuid}
                fullscreenState={fullscreenState}
                setFullscreenState={setFullscreenState}
            />
        </>

    )
}

export default MultiCameraController
