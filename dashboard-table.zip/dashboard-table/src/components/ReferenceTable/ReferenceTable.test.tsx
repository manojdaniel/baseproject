import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import ReferenceTable from "./ReferenceTable";
import { Table } from "antd";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});
describe("ReferenceTable", () => {
	const data = [
		{
			modelName: "Model A",
			sensorName: "Sensor 1",
			uom: "kg",
			high: 100,
			low: 50,
		},
		{
			modelName: "Model B",
			sensorName: "Sensor 2",
			uom: "m",
			high: 10,
			low: 5,
		},
	];
	const saveCurrentRegionStore = jest.fn();

	beforeEach(() => {
		render(
			<ReferenceTable
				data={data}
				saveCurrentRegionStore={saveCurrentRegionStore}
			/>
		);
	});
	it("should render the component without errors", () => {
		render(<ReferenceTable data={data} saveCurrentRegionStore={undefined} />);

		expect(Table).toHaveBeenCalled(); // Verify that Antd Table was called
	});
	it("should render table columns", () => {
		expect(screen.getByText("MODEL")).toBeInTheDocument();
		expect(screen.getByText("SENSOR NAME")).toBeInTheDocument();
		expect(screen.getByText("UOM")).toBeInTheDocument();
		expect(screen.getByText("HIGH")).toBeInTheDocument();
		expect(screen.getByText("LOW")).toBeInTheDocument();
	});

	it("should render table data", () => {
		expect(screen.getByText("Model A")).toBeInTheDocument();
		expect(screen.getByText("Sensor 1")).toBeInTheDocument();
		expect(screen.getByText("kg")).toBeInTheDocument();
		expect(screen.getByText("100")).toBeInTheDocument();
		expect(screen.getByText("50")).toBeInTheDocument();

		expect(screen.getByText("Model B")).toBeInTheDocument();
		expect(screen.getByText("Sensor 2")).toBeInTheDocument();
		expect(screen.getByText("m")).toBeInTheDocument();
		expect(screen.getByText("10")).toBeInTheDocument();
		expect(screen.getByText("5")).toBeInTheDocument();
	});

	it("should call saveCurrentRegionStore when the Test button is clicked", () => {
		const testButton = screen.getByText("Test");
		testButton.click();
		expect(saveCurrentRegionStore).toHaveBeenCalledWith("Asia");
	});
});
