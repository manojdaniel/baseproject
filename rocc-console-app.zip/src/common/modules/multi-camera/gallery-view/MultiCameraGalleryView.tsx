/*
 * Created on Fri Dec 03 2021
 *
 * Copyright (c) 2020 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, EConnectionMode, EConnectionType, FeatureFlagHelper, IConsoleSession, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { MultiCameraGalleryItemGroup, MultiCameraGalleryViewInFullscreen } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Grid } from "semantic-ui-react"
import { updateConsoleSession } from "../../../../redux/actions/consoleActions"
import { IStore } from "../../../../redux/interfaces/types"
import en from "../../../../resources/translations/en-US"
import { attachTrack, detachTracks } from "../../../helpers/multiCameraUtility"
import { toggleDisplayCamera } from "../MultiCameraHelper"
import { IMultiCamVideoTrack } from "../MultiCameraTypes"
import styles from "./MultiCameraGalleryView.scss"

const componentName = "Multi Camera: GalleryView "
const eventString = "Full screen"

interface IMultiCameraGalleryView {
    activeSessions: IConsoleSession[]
    videoTracks: IMultiCamVideoTrack[]
    setVideoTracks: (tracks: IMultiCamVideoTrack[]) => void
    consoleSession: IConsoleSession
    remoteVideoStatus: boolean
    setRemoteVideoStatus: (status: boolean) => void
    fullscreenState: boolean
    setFullscreenState: (status: boolean) => void
    displayRightSidePanel: boolean
    displayLeftSidePanel: boolean
    currentUserUuid: string
    multiCameraFlagExists: boolean
}

const MultiCameraGalleryView = (props: IMultiCameraGalleryView) => {

    const { consoleSession, videoTracks, setVideoTracks, remoteVideoStatus, setRemoteVideoStatus, displayRightSidePanel, displayLeftSidePanel, currentUserUuid, fullscreenState, setFullscreenState, multiCameraFlagExists } = props

    const { cameraStreamAvailable } = consoleSession.mediaRoomDetails
    const { multiCameraList } = consoleSession
    const { VIEW, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL } = EConnectionType
    const [childKey, setChildKey] = useState(1)
    const {
        featureFlags
    } = useSelector((state: IStore) => ({
        featureFlags: state.externalReducer.featureFlags
    }))

    useEffect(() => {
        setChildKey(prev => prev + 1)
    }, [cameraStreamAvailable])

    const widthStyle = displayLeftSidePanel ? styles.narrowWidth : styles.maxWidth

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const getSelectedVideoTracks = () => {
        return videoTracks.filter((videoTrackItem: IMultiCamVideoTrack) => {
            const index = multiCameraList.findIndex((cameraStream) => videoTrackItem.videoTrack.name === cameraStream.cameraStreamName)
            if (index !== -1) {
                return multiCameraList[index].selected
            }
            return false
        })
    }

    const toggleFullscreen = (trackName: string, state: boolean) => {
        const index = videoTracks.findIndex((videoTrackItem: IMultiCamVideoTrack) => videoTrackItem.videoTrack.name === trackName)
        if (index !== -1) {
            infoLogger(`${componentName}: For user: ${currentUserUuid} - Console session ${consoleSession.contextId} - Toggling fullscreen for track ${trackName}.`)
            videoTracks[index].fullScreen = state
            setVideoTracks([...videoTracks])
            setFullscreenState(state)
        }
    }

    const getFullscreenVideoTrack = () => {
        const fullscreenTrack = videoTracks.find((videoTrackItem) => videoTrackItem.fullScreen === true)
        return fullscreenTrack
    }

    const checkIfAllThumbnailsCaptured = () => {
        return multiCameraList.every((multiCameraItem) => multiCameraItem.thumbnail)
    }

    const updateThumbnail = (trackName: string, thumbnailImage: any) => {
        const cameraItemIndex = multiCameraList.findIndex((multiCameraItem) => multiCameraItem.cameraStreamName === trackName)
        if (cameraItemIndex !== -1) {
            infoLogger(`${componentName}: For user: ${currentUserUuid} - Console session ${consoleSession.contextId} - Updating thumbnail for track ${trackName}.`)
            let newMultiCameraList = []
            multiCameraList[cameraItemIndex] = { ...multiCameraList[cameraItemIndex], thumbnail: thumbnailImage }
            newMultiCameraList = [...multiCameraList]
            consoleSession.multiCameraList = newMultiCameraList
            dispatch(updateConsoleSession({ ...consoleSession }, true, false))
        }
    }

    const handleFullScreenClick = (trackName: string) => {
        fullscreenState ? sendLogsToAzure({ contextData: { component: componentName, event: `${eventString} collapse`, Event_By: currentUserUuid } })
            : sendLogsToAzure({ contextData: { component: componentName, event: `${eventString} expand`, Event_By: currentUserUuid } })
        toggleFullscreen(trackName, !fullscreenState)
    }

    const renderGridOrFullScreenView = () => {
        return fullscreenState ? <MultiCameraGalleryViewInFullscreen
            key={childKey}
            currentUserUuid={currentUserUuid}
            consoleContextId={consoleSession.contextId}
            videoTrackItem={getFullscreenVideoTrack()}
            handleFullScreenClick={handleFullScreenClick}
            displayRightSidePanel={displayRightSidePanel}
            attachTrack={attachTrack}
            detachTracks={detachTracks}
            infoLogger={infoLogger}
        />
            : <MultiCameraGalleryItemGroup
                key={childKey}
                currentUserUuid={currentUserUuid}
                consoleContextId={consoleSession.contextId}
                videoTracks={getSelectedVideoTracks()}
                handleFullScreenClick={handleFullScreenClick}
                remoteVideoStatus={remoteVideoStatus}
                setRemoteVideoStatus={setRemoteVideoStatus}
                thumbnailsCaptured={checkIfAllThumbnailsCaptured()}
                updateThumbnail={updateThumbnail}
                attachTrack={attachTrack}
                detachTracks={detachTracks}
                infoLogger={infoLogger}
            />
    }

    const getCameraStreamMessages = (cameraStreamAvailable: ECameraStreamAvailable) => {
        const { intl } = getIntlProvider()
        switch (cameraStreamAvailable) {
            case ECameraStreamAvailable.NOT_AVAILABLE:
                return <span>
                    {intl.formatMessage({ id: "content.room.loadingStreams", defaultMessage: en["content.room.loadingStreams"] })}
                </span>
            case ECameraStreamAvailable.DEVICE_DISCONNECTED:
                return <span>
                    {intl.formatMessage({ id: "content.room.noMultiCamera", defaultMessage: en["content.room.noMultiCamera"] })}
                </span>
            case ECameraStreamAvailable.MEDIA_ROOM_FAILED:
                return <span>
                    {intl.formatMessage({ id: "content.room.noExternalCamera", defaultMessage: en["content.room.noExternalCamera"] })}
                </span>
            default:
                return <>
                    <span>
                        {intl.formatMessage({ id: "content.room.toggleDisplayCameraMessage1", defaultMessage: en["content.room.toggleDisplayCameraMessage1"] })}
                    </span>
                    <span
                        className={styles.displayCameraControl}
                        onClick={() => {
                            if (cameraStreamAvailable) {
                                sendLogsToAzure({ contextData: { component: componentName, event: "Camera on", Event_By: currentUserUuid } })
                                toggleDisplayCamera(consoleSession, dispatch)
                            }
                        }
                        }
                    >
                        {intl.formatMessage({ id: "content.room.displayCameras", defaultMessage: en["content.room.displayCameras"] })}
                    </span>
                    {intl.formatMessage({ id: "content.room.toggleDisplayCameraMessage2", defaultMessage: en["content.room.toggleDisplayCameraMessage2"] })}
                </>
        }
    }
    const getCameraMessage = () => {
        const isRoomMonitoringEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_ROOM_MONITORING)
        const { connectionType, connectionMode } = consoleSession
        const { INCOGNITO_VIEW } = EConnectionType
        const { EMERALD, VNC, RDP } = EConnectionMode
        if (multiCameraFlagExists && connectionType !== INCOGNITO_VIEW && !isRoomMonitoringEnabled) {
            return getCameraStreamMessages(cameraStreamAvailable)
        } else if (isRoomMonitoringEnabled) {
            if (connectionMode === EMERALD || connectionMode === VNC || connectionMode === RDP ) {
                return getCameraStreamMessages(cameraStreamAvailable)
            } else {
                return <>
                    <div className={styles.displayRoomMonitoringMessage1}>
                        {intl.formatMessage({ id: "content.room.liveVideoStreamingMessage1", defaultMessage: en["content.room.liveVideoStreamingMessage1"] })}
                    </div>
                    <div className={styles.displayRoomMonitoringMessage2}>
                        {intl.formatMessage({ id: "content.room.liveVideoStreamingMessage2", defaultMessage: en["content.room.liveVideoStreamingMessage2"] })}
                    </div>
                </>
            }
        } else {
            return intl.formatMessage({ id: "content.room.noMultiCamera", defaultMessage: en["content.room.noMultiCamera"] })
        }
    }

    return ([VIEW, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL].includes(consoleSession.connectionType)) ?
        (
            <Grid.Column className={cx(styles.multiCameraGalleryView, widthStyle)} id={"multiCameraGalleryView"}>
                {consoleSession.displayCameraToggle && consoleSession.mediaRoomDetails.cameraStreamAvailable !== ECameraStreamAvailable.DEVICE_DISCONNECTED ?
                    renderGridOrFullScreenView()
                    : <div className={styles.toggleDisplayCameraMessage}>
                        {getCameraMessage()}
                    </div>
                }
            </Grid.Column>
        ) : <></>
}

export default MultiCameraGalleryView
