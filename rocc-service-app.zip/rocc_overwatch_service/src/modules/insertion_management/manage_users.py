"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import EMP_DICT, IS_SUCCESSFULL
from src.constants.enums import ESummaryStates
from src.constants.headers import EXCEL_USER_EMAIL_ID
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.insertion_services.user_db_services import fetch_userlist, check_if_new_user, prepare_invitation_mail_object
from src.wrappers.platform_services.management_service.user_management_service import send_invitation_mail, delete_users, add_users_in_db

LOG = create_logger("ManageUsersTask")


class ManageUsers():
    def __init__(self, data_dict, client, token, transaction_data, org_infra_uuid, org_db_id, transaction_id):
        self._data_dict = data_dict
        self._emp_dict = data_dict[EMP_DICT]
        self._client = client
        self._token = token
        self._org_db_id = org_db_id
        self._transaction_data = transaction_data
        self._transaction_id = transaction_id
        self._org_ctxt_header = {"Org-Id": org_infra_uuid}

    def execute(self):
        """
        1. Compute the new users to be added.
        2. Construct the request body to add new users in DB according to the data provided
        3. Call management service Users/bulk API to add users (with data from step 2)
        4. Call management service UserActions/bulk API to send email to users (skip this step for ONLY technologist users )
        5. Incase of failure in Step 5. Call the rollback function to delete the inserted data for failed users.
        """

        self.compute_user_eligibility()
        self._emp_dict = self.convert_email_to_lowercase()
        new_user_list = self.create_add_users_list()

        if len(new_user_list) > 0:
            successful_user_list = self.add_new_users(new_user_list)
            if len(successful_user_list) > 0:
                email_request_body = prepare_invitation_mail_object(successful_user_list, self._emp_dict)
                #pylint: disable=unused-variable
                email_success_list, email_failure_list = send_invitation_mail(request_body=email_request_body,
                                                                              emp_dict=self._emp_dict,
                                                                              org_ctxt_header=self._org_ctxt_header,
                                                                              access_token=self._token,
                                                                              transaction_id=self._transaction_id)
                if len(email_failure_list) > 0:
                    self.rollback_failed_users(email_failure_list)

        else:
            LOG.info("No new users to be added")
        self._data_dict[EMP_DICT] = self._emp_dict
        return self._data_dict, self._transaction_data

    def convert_email_to_lowercase(self):
        try:
            for key, employee in self._emp_dict.items():
                employee[EXCEL_USER_EMAIL_ID] = employee[EXCEL_USER_EMAIL_ID].lower()
                self._emp_dict[key] = employee
        except Exception as ex:
            LOG.error(f"Error while fetching existing unique Ids : {ex}")
        return self._emp_dict

    def compute_user_eligibility(self):
        LOG.info("Computing new users to be added")
        self._emp_dict, self._transaction_data = check_if_new_user(self._emp_dict, self._client, transaction_data=self._transaction_data)

    def create_add_users_list(self):
        new_user_list = fetch_userlist(self._emp_dict, self._client, self._org_db_id)
        return new_user_list

    def add_new_users(self, new_users):
        self._emp_dict, successfull_user_list = add_users_in_db(new_users, self._org_ctxt_header,
                                                                access_token=self._token,
                                                                emp_dict=self._emp_dict,
                                                                transaction_id=self._transaction_id)
        return successfull_user_list

    def rollback_failed_users(self, failed_user_list):
        LOG.info(f"Rolling back inserted data for users: {failed_user_list}")
        delete_users(failed_user_list, self._org_ctxt_header, access_token=self._token)
        for key, employee in self._emp_dict.items():
            if key in failed_user_list:
                self._transaction_data = update_summary_for_entity(self._transaction_data, "rooms", key, ESummaryStates.INSERTION_FAILED)
                employee[IS_SUCCESSFULL] = False
