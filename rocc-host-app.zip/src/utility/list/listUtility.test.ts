/*
 * Created on Mon Apr 19 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { insertElementIfNotExists, insertObjectIfNotExists } from "./listUtility"

describe("Unit tests for List utility", () => {
    let testArray: any[]
    beforeEach(() => {
        testArray = [{
            id: 1, data: 123,
        }]
    })
    it("test insertObjectIfNotExists", () => {
        const response = insertObjectIfNotExists(testArray, { id: 2, data: 124 }, "data")
        expect(response.length).toBe(2)
    })
    it("test insertElementIfNotExists", () => {
        const response = insertElementIfNotExists(testArray, { id: 2, data: 124 })
        expect(response.length).toBe(2)
    })
})
