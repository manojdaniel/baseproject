/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import "@dls-pdv/semantic-ui-foundation/dist/semantic.css"
import { FeatureFlagHelper, IRoomDetails, parseIntBase10, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { CustomLoader, getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { IRoomCardHeader, ModalityInfo, RoomCardInfoComponent, UserNameComponent } from "@rocc/rocc-rooms-components"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Card, CardContent, CardHeader } from "semantic-ui-react"
import { getConfigReducerFromGlobalStore } from "../../common/helpers/helpers"
import { CONSOLE_STORE, ROOM_CARD } from "../../constants/constants"
import { EConnectionType, IRoomCard } from "../../lib/types"
import { GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_ROOMS } from "../../redux/actions/types"
import { EAppUriValue, EConnectionState, EConnectionStatus, EDefaultTransactionValue, EProtocolTransferSteps } from "../../redux/interfaces/enums"
import { IConsoleDetails, IStore } from "../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalRooms, fetchMetaSiteId } from "../../redux/store/externalAppStates"
import globalStore from "../../redux/store/globalStore"
import store from "../../redux/store/store"
import en from "../../resources/translations/en-US"
import RoomCardFooter from "../room-card-footer/RoomCardFooter"
import styles from "./RoomCardComponent.module.scss"
import { checkActiveWorkflowForRoom, getActiveConsoleSession, getConnectionMode, getStarRoomErrorHeader, getStarRoomErrorMessage } from "./RoomCardHelper"
import { setStarredRoom } from "./RoomCardServices"


const ConsoleTrigger = React.lazy(() => import("roccConsole/ConsoleTrigger").catch(() => false))
const RoomCardComponent = (props: IRoomCard) => {

    const {
        roomIdentity,
        isStarred,
        modalityProps,
        userNameProps,
        flags,
        connectionProps,
        protocolTransferReducerProps,
        monitorName,
        footerProps
    } = props
    const { VIEW, INCOGNITO_VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT } = EConnectionType
    const [connectionStatus, setConnectionStatus] = useState("" as EConnectionStatus)
    const [roomCardOptions, setRoomCardOptions] = useState([VIEW])
    const { name, address, uuid, id } = roomIdentity

    const {
        userId, userUuid, token, consoleDetails, selectedSource,
        selectedDestination, protocolTransferStep, protocolTransferStatus, workflows, featureFlags
    } = useSelector((state: IStore) => ({
        userId: state.externalReducer.currentUser.id,
        userUuid: state.externalReducer.currentUser.uuid,
        token: state.externalReducer.currentUser.accessToken,
        consoleDetails: state.externalReducer.consoleDetails,
        selectedSource: state.externalReducer.protocolTransferDetails.selectedSource,
        selectedDestination: state.externalReducer.protocolTransferDetails.selectedDestination,
        protocolTransferStep: state.externalReducer.protocolTransferDetails.currentStep,
        protocolTransferStatus: state.externalReducer.protocolTransferDetails.protocolTransferStatus,
        workflows: state.externalReducer.workflows,
        featureFlags: state.externalReducer.featureFlags,
    }))
    useEffect(() => {
        const isMultiEditEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME)
            || FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITH_PARK_AND_RESUME)
        if (isMultiEditEnabled) {
            setRoomCardOptions([...roomCardOptions, FULL_CONTROL])
        }
    }, [])

    const { intl } = getIntlProvider()
    const rooms = fetchGlobalRooms()
    const configReducer = getConfigReducerFromGlobalStore()
    let selectedScannerUuid = ""

    const isViewMode = getConnectionMode(VIEW, flags, connectionProps)
    const isIncognito = getConnectionMode(INCOGNITO_VIEW, flags, connectionProps)
    const isEditMode = getConnectionMode(FULL_CONTROL, flags, connectionProps)
    const isPMMode = getConnectionMode(PROTOCOL_MANAGEMENT, flags, connectionProps)
    const connectingMessage = intl.formatMessage({ id: "content.outgoingCall.connecting", defaultMessage: en["content.outgoingCall.connecting"] })
    const disconnectingMessage = intl.formatMessage({ id: "content.consoleViewDisconnect.disconnecting", defaultMessage: en["content.consoleViewDisconnect.disconnecting"] })

    const connectionStates = [EConnectionState.CONNECTING, EAppUriValue.RESTART_EMERALD_APP, EAppUriValue.START_EMERALD_APP, EDefaultTransactionValue.CONNECTING]
    const disConnectionStates = [EConnectionState.DISCONNECTING, EAppUriValue.STOP_EMERALD_APP, EDefaultTransactionValue.DISCONNECTING]
    const isPartOfActiveWorkflow = checkActiveWorkflowForRoom(workflows, uuid)
    const loading = (connectionStates.indexOf(connectionStatus) > -1) || (disConnectionStates.indexOf(connectionStatus) > -1) || isPartOfActiveWorkflow

    if (protocolTransferStep === EProtocolTransferSteps.SelectSourceScanner || protocolTransferStep === EProtocolTransferSteps.ConnectToSourceScanner) {
        selectedScannerUuid = selectedSource.identity && selectedSource.identity.uuid
    } else if (protocolTransferStep === EProtocolTransferSteps.SelectDestinationScanner || protocolTransferStep === EProtocolTransferSteps.ConnectToDestinationScanner) {
        selectedScannerUuid = selectedDestination.identity && selectedDestination.identity.uuid
    }

    const isRoomConnecting = (uuid: string) => {
        const activeTransactions = consoleDetails.activeConsoleTransactions
        let connectionStatus: EConnectionStatus = EConnectionState.DEFAULT
        activeTransactions.forEach((transaction) => {
            if (transaction.roomUuid === uuid) {
                infoLogger(`connection status for room ${transaction.connectionStatus}`)
                connectionStatus = transaction.connectionStatus
            }
        })
        return connectionStatus
    }

    const starredHandler = async (selectedRoomUuid: string, isRoomStarred: boolean) => {
        sendLogsToAzure({ contextData: { component: ROOM_CARD, event: `${isRoomStarred ? "Unstar" : "Star"}`, room: uuid } })
        const response = await setStarredRoom({
            roomId: id,
            adminServiceUrl: configReducer.urls.MANAGEMENT_SERVICE_URL,
            metasiteId: fetchMetaSiteId(),
            isRoomStarred: !isRoomStarred,
            userId: parseIntBase10(userId),
            token: token
        })
        if (response.status === 200) {
            const updatedRooms: IRoomDetails[] = []
            rooms.forEach((room: IRoomDetails) => {
                if (room.identity.uuid === selectedRoomUuid) {
                    room.isRoomStarred = !isRoomStarred
                }
                updatedRooms.push(room)
            })
            dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms: updatedRooms } })
            infoLogger(`UUID: ${userUuid} Successfully updated starred room`)
        } else {
            const notificationMessage = {
                show: true,
                hideIcon: true,
                closeMessage: {},
                isSuccess: false,
                isWarning: false,
                fixed: false,
                timeOut: 3000,
                showNotification: true,
                message: [{
                    header: getStarRoomErrorHeader(isRoomStarred),
                    content: getStarRoomErrorMessage(),
                }],
                isNotification: false,
                customStyle: { top: "1rem", right: "1rem", width: "22.4375rem", height: "9.8125rem" }
            }
            dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MESSAGE, payload: { notificationMessage: notificationMessage } })
            errorLogger(`UUID: ${userUuid} ApiStatus: Error while updating star rooms: ${JSON.stringify(response)}`)
        }
    }
    const radioButtonHandler = (selecetdRoomUuid: any) => {
        let selectedRoom: IRoomDetails = {} as any
        rooms.forEach((room: IRoomDetails) => {
            if (room.identity.uuid === selecetdRoomUuid) {
                infoLogger(`UUID: ${userUuid} Selected room is ${room}`)
                selectedRoom = room
            }
        })
        if (protocolTransferStep === EProtocolTransferSteps.SelectSourceScanner) {
            globalStore.DispatchAction(CONSOLE_STORE,
                { type: "GLOBAL_SET_SOURCE_SCANNER", payload: { selectedSource: selectedRoom } })
            infoLogger(`UUID: ${userUuid} Selected source scanner: ${selectedRoom.identity.uuid}`)
            sendLogsToAzure({ contextData: { component: ROOM_CARD, event: `Selected source scanner: ${selectedRoom.identity.uuid}`, Event_By: userUuid } })
        } else if (protocolTransferStep === EProtocolTransferSteps.SelectDestinationScanner) {
            globalStore.DispatchAction(CONSOLE_STORE, {
                type: "GLOBAL_SET_DESTINATION_SCANNER", payload: { selectedDestination: selectedRoom }
            })
            infoLogger(`UUID: ${userUuid} Selected source scanner: ${selectedRoom.identity.uuid}`)
            sendLogsToAzure({ contextData: { component: ROOM_CARD, event: `Selected destination scanner: ${selectedRoom.identity.uuid}`, Event_By: userUuid } })
        }
    }

    const getBorderColor = () =>
        flags.isMultiConsoleFlagEnabled ?
            isIncognito ? styles.icognitoMode : isEditMode ? styles.editMode : isPMMode ? styles.pmMode : isViewMode ? styles.viewingConsole : ""
            :
            isIncognito ? styles.multiConsoleDisabledIcognitoMode : isEditMode ? styles.multiConsoleDisabledEditMode : isPMMode ?
                styles.multiConsoleDisabledPmMode : isViewMode ? styles.multiConsoleDisabledViewingConsole : ""

    const roomCardInfoProps: IRoomCardHeader = {
        roomName: name,
        roomAddress: address,
        isStarredFlagEnabled: flags.isStarredFlagEnabled,
        isStarred,
        roomUuid: uuid,
        isMultiConsoleFlagEnabled: flags.isMultiConsoleFlagEnabled,
        protocolTransferFlagEnabled: flags.protocolTransferFlagEnabled,
        isRoomActiveSession: flags.isRoomActiveSession,
        monitorName: monitorName,
        protocolTransferReducer: protocolTransferReducerProps,
        connectionProps,
        starredHandler,
        radioButtonHandler,
        selectedScannerUuid,
    }

    const renderConsoleSession = () => {
        const { activeConsoleTransactions, activeConsoleSessions } = consoleDetails
        const activeSessions = [...activeConsoleTransactions, ...activeConsoleSessions]
        const activeSession = getActiveConsoleSession(activeSessions, uuid)
        let connectionType = VIEW
        if (activeSession) {
            switch (activeSession.connectionType) {
                case INCOGNITO_VIEW: connectionType = INCOGNITO_VIEW
                    break
                case PROTOCOL_MANAGEMENT: connectionType = PROTOCOL_MANAGEMENT
                    break
                case FULL_CONTROL: connectionType = FULL_CONTROL
                    break
                default:
            }
            return <ConsoleTrigger showTitle={true} roomUuid={uuid} connectionType={connectionType} componentName={ROOM_CARD} connectionState={activeSession?.connectionStatus || EConnectionState.DEFAULT} />
        }
        else {
            return <>{roomCardOptions.map((value, index) => <ConsoleTrigger key={index} showTitle={true} secondary={value === FULL_CONTROL} roomUuid={uuid} connectionType={value} componentName={ROOM_CARD} connectionState={EConnectionState.DEFAULT} />)} </>
        }

    }

    const renderContent = () => {
        return (
            <CardContent id={"cardContent"} className={styles.cardContent}>
                <div id={"modalityInfo"} className={!protocolTransferStatus ? styles.modalityInfo : ""}>
                    <div className={styles.viewConsoleTrigger}>
                        {!protocolTransferStatus && renderConsoleSession()}
                    </div>
                    <ModalityInfo {...modalityProps} />
                </div>
                <div className={styles.userName}>
                    <UserNameComponent {...userNameProps} />
                </div>
                <div className={styles.footer}>
                    <RoomCardFooter {...footerProps} modalityName={modalityProps.modalityName} roomUuid={uuid} />
                </div>
            </CardContent>
        )
    }

    const fetchLoadingText = () => {
        if (connectionStates.indexOf(connectionStatus) > -1) {
            return connectingMessage
        } else if (disConnectionStates.indexOf(connectionStatus) > -1) {
            return disconnectingMessage
        } else {
            return ""
        }
    }

    const renderConsoleTrigger = (isViewAuthEnabled: boolean, consoleDetails: IConsoleDetails) => {

        if (isViewAuthEnabled && consoleDetails.activeConsoleTransactions?.filter((console) => console.connectionType === VIEW).length > 0) {
            return <ConsoleTrigger showTitle={false} roomUuid={uuid} connectionType={EConnectionType.VIEW} key={`${uuid}_view`} requestViewAuthorizationCancel={true} />
        }
        else {
            return <></>
        }
    }

    const renderLoader = () => {
        const { featureFlags, consoleDetails } = store.getState().externalReducer

        const isViewAuthEnabled = !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_VIEW_AUTHORIZATION)
        return (<div className={styles.cardLoaderWrapper}>
            <CustomLoader
                content={fetchLoadingText()}
                dimmer={false}
                inverted={false}
                inline={false}
                size={"medium"}
                customStyle={{ zIndex: 1 }}
            />
            {renderConsoleTrigger(isViewAuthEnabled, consoleDetails)}
        </div>

        )
    }

    useEffect(() => {
        const connectionStatus = isRoomConnecting(uuid)
        setConnectionStatus(connectionStatus)
    }, [consoleDetails])

    return (
        <Card id={"roomCard"} className={cx(getBorderColor(), styles.roomCard)}>
            <CardHeader id={"roomCardHeader"} className={styles.cardHeader}>
                {FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_CAMERA_AI, false) && <span id={"roomStatus"} className={styles.roomStatus}>{props.roomStatus}</span>}
                <RoomCardInfoComponent {...roomCardInfoProps} />
            </CardHeader>
            {
                loading ? renderLoader() : renderContent()
            }

        </Card>
    )
}

export default RoomCardComponent
