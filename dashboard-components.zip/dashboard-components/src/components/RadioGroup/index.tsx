// import React, { useState } from "react";

// const RadioGroup = ({
// 	options,
// 	name,
// 	defaultOption,
// 	onChange,
// 	title,
// 	disabled,
// }: any) => {
// 	const [selectedOption, setSelectedOption] = useState(defaultOption);

// 	const handleOptionChange = (event) => {
// 		setSelectedOption(event.target.value);
// 		if (onChange) {
// 			onChange(event.target.value);
// 		}
// 	};

// 	return (
// 		<div>
// 			{title && <h5>{title}</h5>}
// 			{options.map((option: any) => (
// 				<label key={option.value}>
// 					<input
// 						type="radio"
// 						name={name}
// 						value={option.value}
// 						checked={selectedOption === option.value}
// 						onChange={handleOptionChange}
// 						disabled={disabled}
// 					/>
// 					{option.label}
// 				</label>
// 			))}
// 		</div>
// 	);
// };

// export default RadioGroup;

import React, { useState } from "react";

const RadioGroup = ({
	options,
	name,
	defaultOption,
	onChange,
	title,
	disabled,
}: any) => {
	const [selectedOption, setSelectedOption] = useState(defaultOption);

	const handleOptionClick = (event) => {
		const clickedValue = event.target.value;

		if (clickedValue === selectedOption) {
			// If the clicked radio button is the same as the currently selected one, clear the selection.
			setSelectedOption("");
			if (onChange) {
				onChange("");
			}
		} else {
			setSelectedOption(clickedValue);
			if (onChange) {
				onChange(clickedValue);
			}
		}
	};

	return (
		<div>
			{title && <h5>{title}</h5>}
			{options.map((option: any) => (
				<label key={option.value}>
					<input
						type="radio"
						name={name}
						value={option.value}
						checked={selectedOption === option.value}
						onClick={handleOptionClick}
						disabled={disabled}
					/>
					{option.label}
				</label>
			))}
		</div>
	);
};

export default RadioGroup;