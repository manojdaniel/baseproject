/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoccVideoCall } from "@rocc/rocc-av-communication-sdk"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react" // eslint-disable-line @typescript-eslint/no-unused-vars
import { useSelector } from "react-redux"
import { AUDIO, DEFAULT, LOCAL_VIDEO } from "../../../constants/constants"
import { IStore } from "../../../redux/interfaces/types"
import { handleError } from "./HandleError"

interface IAudioVideoSource {
    activeRoom: any
    previewTracks: any
    videoStatus: boolean
    vendorService: IRoccVideoCall
}

const AudioVideoSource = (props: IAudioVideoSource) => {

    const { videoStatus } = props

    const { isMuted, audioOutput, audioSource, videoSource, volume } = useSelector((state: IStore) => ({
        isMuted: state.callReducer.callDetails.connectedCallDetails.isMuted,
        audioSource: state.callReducer.audioSource,
        audioOutput: state.callReducer.audioOutput,
        videoSource: state.callReducer.videoSource,
        volume: state.callReducer.volume,
    }))

    const [callActiveStatus, setCallActiveStatus] = useState(false)

    const updateParticipantVolume = () => {
        try {
            const players = document.getElementsByTagName(AUDIO)
            // loop through players using forEach
            for (const player of players) {
                player.volume = volume / 100
            }
        } catch (error: any) {
            handleError("AudioVideoSource.tsx:updateParticipantVolume()", error)
        }
    }

    const updateAudioSource = async () => {
        const { activeRoom } = props
        const deviceId = audioSource ? audioSource : DEFAULT

        try {
            const container = document.getElementById(LOCAL_VIDEO)
            const response = await props.vendorService.updateMicrophoneDevice({ room: activeRoom, deviceId, container })
            props.previewTracks.push(response)

        } catch (error: any) {
            handleError("AudioVideoSource.tsx:updateAudioSource()", error)
        }
    }

    const updateVideoSource = async () => {
        const { activeRoom } = props
        try {
            const deviceId = videoSource ? videoSource : DEFAULT
            const container = document.getElementById(LOCAL_VIDEO)
            const response = await props.vendorService.updateVideoSource({ room: activeRoom, deviceId, container })
            props.previewTracks.push(response)
            sendLogsToAzure({ contextData: { component: "AudioVideoSource", event: `${"Changed the video source to"} ${videoSource}` } })
        } catch (error: any) {
            handleError("AudioVideoSource.tsx:updateVideoSource()", error)
        }
    }

    const updateAudioOutput = async () => {
        const { activeRoom } = props
        const deviceId = audioOutput ? audioOutput : DEFAULT
        props.vendorService.updateSpeaker({ room: activeRoom, deviceId, volume, container: document.body })
    }

    useEffect(() => {
        if (props.activeRoom) {
            setCallActiveStatus(true)
        }
    }, [props.activeRoom])

    useEffect(() => { if (callActiveStatus && isMuted) { updateAudioSource() } }, [audioSource])
    useEffect(() => { if (callActiveStatus && videoStatus) { updateVideoSource() } }, [videoSource])
    useEffect(() => { if (callActiveStatus) { updateAudioOutput() } }, [audioOutput])
    useEffect(() => { updateParticipantVolume() }, [volume])

    return <></>
}

export default AudioVideoSource
