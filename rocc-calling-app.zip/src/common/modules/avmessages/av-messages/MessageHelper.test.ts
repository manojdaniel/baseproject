/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus } from "@rocc/rocc-client-services"
import { setIncomingCallDetails, setOutgoingCallDetails } from "../../../../redux/actions/callActions"
import { ICallAccept, ICallReject, ICallTimeOut } from "../av-messages/types"
import { getCallerSecondaryUuidIfAvailable, onCallAccept, onCallReject, onCallTimeout, setRecentMissedCallInRedux, storeCallDetailsInRedux, updateVideoCallStatus } from "./MessageHelper"
import { IParticipant } from "./types"

jest.mock("../../../../redux/actions/callActions", () => ({
    setCallRingStatus: jest.fn(),
    setVideoCallStatus: jest.fn(),
    setIncomingCallDetails: jest.fn(),
    setCallMessage: jest.fn(),
    setOutgoingCallDetails: jest.fn(),
    updateCallTimeout: jest.fn(),
    setRecentMissedCall: jest.fn(),
    storeCallDetails: jest.fn(),
}))

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
}))

jest.mock("../../../../redux/store/store", () => ({
    getState: jest.fn().mockImplementation(() => ({
        callReducer: {
            videoCallStatus: [{ callStatus: ECallStatus.CALLING, contextId: "contextId" }],
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    participants: [{
                        primaryUuid: "primaryUuid",
                    }],
                    callAcceptedTime: Date.now(),
                }
            }
        },
        externalReducer: {
            currentUser: { uuid: "uuid", accessToken: "accessToken", sessionId: "sessionId" }
        }
    }))
}))

jest.mock("../../../helpers/helpers", () => ({
    getUserReducerFromGlobalStore: jest.fn().mockReturnValue({
        contacts: []
    }),
    getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
        rooms: []
    }),
    getTranslatedCallType: jest.fn()
}))

jest.mock("../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    }),
    dispatchToParentStore: jest.fn(),
}))

const dispatch = jest.fn()

describe("getCallerSecondaryUuidIfAvailable tests", () => {
    const participants: IParticipant[] = [{
        primaryUuid: "primaryUuid",
        callStatus: "CALLING",
        secondaryUUID: ["secondaryUuid"]
    }]
    it("should return participant Uuid", () => {
        expect(getCallerSecondaryUuidIfAvailable("primaryUuid", participants)).toBe("secondaryUuid")
    })

    it("should not return participant Uuid", () => {
        expect(getCallerSecondaryUuidIfAvailable("primaryUuid1", participants)).toBe(undefined)
    })
})

describe("onCallTimeout tests", () => {
    const callTimeoutProps: ICallTimeOut = {
        caller: { ...DEFAULT_CONTACT_INFO, uuid: "uuid1" },
        callee: { ...DEFAULT_CONTACT_INFO, uuid: "uuid2" },
        contextId: "contextId",
        isCallee: true,
        lastCallStatus: ECallStatus.CALLING,
        dispatch
    }
    it("should handle call timeout", () => {
        onCallTimeout(callTimeoutProps)
        expect(setIncomingCallDetails).toHaveBeenCalled()
    })

    it("should handle call timeout from caller side", () => {
        callTimeoutProps.isCallee = false
        onCallTimeout(callTimeoutProps)
        expect(setOutgoingCallDetails).toHaveBeenCalled()
    })
})

describe("onCallAccept tests", () => {
    const callAcceptedProps: ICallAccept = {
        contextId: "contextId",
        dispatch,
        contactUuid: "contactUuid",
    }
    jest.mock("./MessageHelper")

    it("should respond with CALL_ACCEPTED", () => {
        onCallAccept(callAcceptedProps, false)
        expect(dispatch).toHaveBeenCalled()
    })

})

describe("onCallReject tests", () => {
    const callRejectedProps: ICallReject = {
        setState: false,
        contextId: "contextId",
        dispatch
    }
    it("should handle CALL_REJECTED", () => {
        onCallReject(callRejectedProps)
        expect(dispatch).toHaveBeenCalled()
    })
})

describe("setRecentMissedCallInRedux tests", () => {
    it("should dispatch missed call", () => {
        setRecentMissedCallInRedux("callContextId", "callerUuid", "calleeUuid", dispatch)
        expect(dispatch).toHaveBeenCalled()
    })
})

describe("updateVideoCallStatus tests", () => {
    it("update existing videoCall status value", () => {
        const newVideoCallStatus = updateVideoCallStatus("contextId", true, ECallStatus.RINGING)
        expect(newVideoCallStatus[0].callStatus).toBe(ECallStatus.RINGING)
    })

    it("remove existing videoCall status value", () => {
        const newVideoCallStatus = updateVideoCallStatus("contextId", false)
        expect(newVideoCallStatus.length).toBe(0)
    })

    it("update existing videoCall status value", () => {
        const newVideoCallStatus = updateVideoCallStatus("contextId1", true, ECallStatus.RINGING)
        expect(newVideoCallStatus.length).toBe(2)
    })
})

describe("storeCallDetailsInRedux tests", () => {
    const data = {
        contextId: "contextId",
        roomName: "roomName",
        participants: [{
            primaryUuid: "primaryUuid",
            callStatus: "CALL_ACCEPTED"
        }],
        requester: {
            userContext: {
                twilioToken: "twilioToken"
            }
        }
    }
    it("should able to call dispatch", () => {
        storeCallDetailsInRedux(data, dispatch).then(callDetails => {
            expect(callDetails.contextId).toBe("contextId")
        })
    })
})
