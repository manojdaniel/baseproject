/*
 * Created on Mon Nov 12 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import ProtocolTransferActiveSession from "./ProtocolTransferActiveSession"

const args = {
    locations: [
        {
            id: 2,
            name: "Washington",
            address: "2222 Peter drive",
            shortName: "SAL02",
            modalityList: [
                {
                    id: 1,
                    modality: "MR"
                },
                {
                    id: 2,
                    modality: "CT"
                }
            ],
            roomsFetched: true,
            locationContacts: {
                frontDesk: [],
                transport: [],
                scheduler: []
            },
            totalRooms: 0
        }
    ],
    protocolTransferStep: 2,
    sourceScanner: {
        identity: {
            id: 8,
            name: "CT",
            uuid: "abc"
        },
        locationId: 2,
        address: "Department",
        modality: "CT",
        modalityId: 2,
        favourite: false,
        phoneNumber: "+123",
        disabled: false,
        presenceData: {
            presence: "OFFLINE",
            mapId: ""
        },
        isConnecting: false
    },
    destinationScanner: {
        identity: {
            id: 13,
            name: "MRI",
            uuid: "abcd"
        },
        locationId: 2,
        address: "Department",
        modality: "MR",
        modalityId: 1,
        favourite: false,
        phoneNumber: "+123",
        disabled: false,
        presenceData: {
            presence: "OFFLINE",
            mapId: ""
        },
        isConnecting: false
    }
}
describe("ProtocolTransferActiveSession", () => {
    let wrapper: any
    let protocolTransferActiveSession: any

    beforeEach(() => {
        wrapper = shallow(<ProtocolTransferActiveSession {...args} />)
        protocolTransferActiveSession = wrapper.find("Grid")
    })

    it("should render the protocolTransferActiveSession Grid", () => {
        expect(protocolTransferActiveSession).toHaveLength(1)
    })

    it("should render Grid with 3 Grid Rows", () => {
        expect(protocolTransferActiveSession.find("GridRow")).toHaveLength(3)
    })

    it("should read the right redux state values", () => {
        const spanEl = protocolTransferActiveSession.find("span")
        const roomName = spanEl.at(0).text()
        const address = spanEl.at(2).text()
        const location = spanEl.at(3).text()
        expect(roomName).toMatch("CT")
        expect(address).toMatch("Department")
        expect(location).toMatch("Washington")
    })
})
