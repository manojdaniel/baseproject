"""
 Created on Fri Apr 29 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest.mock import Mock, patch

from src.wrappers.infrastructure_services.device_mdm_services.device_mdm_services import cleanup_device_type, \
    cleanup_device_group, create_device_application, create_device_boot_strap_client, create_device_type, \
    create_device_group, update_device_client_scope, provision_devices_service, update_proposition_status, \
    create_device_proposition, manage_device_proposition_service
from tests.mocks.mock_requests import MOCK_URL


class TestDeviceMDMServices(unittest.TestCase):
    def test_cleanup_device_type(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = cleanup_device_type(
            token="", type_id="abc", profile_configs=profile_configs)
        self.assertIsNotNone(actual)

    def test_cleanup_device_group(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = cleanup_device_group(
            token="", group_id="abc", profile_configs=profile_configs)
        self.assertIsNotNone(actual)

    def test_create_device_type(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_device_type(token="", device_group_id="group_id", type_name="abc",
                                    profile_configs=profile_configs, infra_configs={}, client={})
        self.assertIsNotNone(actual)

    def test_create_device_group(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_device_group(token="", application_id=1, group_name="abc",
                                     profile_configs=profile_configs, infra_configs={}, client={})
        self.assertIsNotNone(actual)

    def test_provision_devices_service(self):
        vault_response = {
            "data": {"hsdpOrganizationId": "123", "deviceTypeName": "device-name"}}
        actual = provision_devices_service(
            number_of_devices=1, vault_response=vault_response, provision_token="abc", token="xyz")
        self.assertIsNotNone(actual)

    def test_update_proposition_status(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = update_proposition_status(
            token="xyz", proposition_id=1, profile_configs=profile_configs)
        self.assertIsNotNone(actual)

    def test_create_device_proposition(self):
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        profile_configs["DEVICE_MDM_URL"] = "xyz"
        infra_configs = {"DEVICE_PROPOSITION_NAME": "abc"}
        actual = create_device_proposition(
            token="xyz", org_id=1, profile_configs=profile_configs, infra_configs=infra_configs)
        self.assertIsNotNone(actual)

    @patch("requests.put")
    def test_update_device_client_scope(self, mock_put):
        mock_response = Mock()
        mock_response.status_code = 204
        mock_put.return_value = mock_response
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = update_device_client_scope(
            token="xyz", bootstrap_client_id=1, profile_configs=profile_configs)
        self.assertEqual(actual, True)

    @patch("requests.post")
    def test_create_device_boot_strap_client(self, mock_post):
        mock_response = Mock()
        mock_response.status_code = 201
        mock_post.return_value = mock_response
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_device_boot_strap_client(
            token="xyz", application_id=1, oauth_cname="oauth_cname", profile_configs=profile_configs, infra_configs={}, client={})
        self.assertIsNotNone(actual)

    @patch("requests.post")
    def test_create_device_application(self, mock_post):
        mock_response = Mock()
        mock_response.status_code = 201
        mock_post.return_value = mock_response
        profile_configs = dict(PARENT_POLICY_NAME="", PARENT_ORG_ID="",
                               VAULT_EVAL_APP_ID="", HSDP_IDM_URL=MOCK_URL)
        actual = create_device_application(
            token="xyz", proposition_id=1, app_name="app_name", profile_configs=profile_configs, infra_configs={}, client={})
        self.assertIsNotNone(actual)

    @patch("src.wrappers.infrastructure_services.device_mdm_services.device_mdm_services.get_profile_data")
    @patch("src.wrappers.infrastructure_services.device_mdm_services.device_mdm_services.create_device_proposition", side_effect=lambda *args, **kwargs: (None, "Reason"))
    def test_manage_device_proposition_service(self, m_gpd, m_cdp):
        response = manage_device_proposition_service(
            "token", "token", "orgId", {}, {})
        self.assertIsNone(response.get("device_bootstrap_client_id"))
        m_gpd.assert_called()
        m_cdp.assert_called()
