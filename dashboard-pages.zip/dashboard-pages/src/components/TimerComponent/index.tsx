import React, { useState, useEffect } from "react";
import { getLoggedInUserDetails } from "../../redux/reducers/CommonReducer";
import { useDispatch, useSelector } from "react-redux";

const INTERVAL = 9 * 60 * 1000; // 5 minutes in milliseconds

const TimerComponent = () => {
	let dispatch = useDispatch();
	const [timeLeft, setTimeLeft] = useState<any>(() => {
		// Get the time left from the local storage
		const savedTime = localStorage.getItem("timeLeft");

		// If there's no time left in the local storage, default to INTERVAL
		return savedTime ? Number(savedTime) : INTERVAL;
	});

	useEffect(() => {
		// Save the time left in the local storage
		localStorage.setItem("timeLeft", timeLeft);

		if (timeLeft <= 0) {
			// If no time is left, call the API (or in this case, console.log) and reset the timer

			dispatch(getLoggedInUserDetails(""));
			setTimeLeft(INTERVAL);
		} else {
			// Otherwise, set up a countdown timer
			const timerId = setTimeout(() => setTimeLeft(timeLeft - 1000), 1000);

			// Clean up the timer when the component unmounts or when timeLeft changes
			return () => clearTimeout(timerId);
		}
	}, [timeLeft]);

	return <div></div>;
};

export default TimerComponent;
