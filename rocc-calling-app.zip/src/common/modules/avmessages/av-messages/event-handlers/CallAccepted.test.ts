/*
 * Created on Fri July 15 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { callAccepted } from "./CallAccepted"

jest.useFakeTimers()

jest.mock("../../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl"
    })
}))

jest.mock("../../../../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue(({
        callReducer: {
            videoCallStatus: [{ callStatus: ECallStatus.IDLE, contextId: "" }],
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    participants: [{
                        primaryUuid: "primaryUuid",
                    }],
                    callAcceptedTime: Date.now(),
                },
                onHoldCallDetails: [],
            }
        },
        externalReducer: {
            currentUser: {}
        }
    }))
}))

const dispatch = jest.fn()

describe("callAccepted tests", () => {
    it("should able to handle callAccepted", () => {

        callAccepted({ contextId: "contextId", dispatch })
        jest.runAllTimers()
        expect(dispatch).toBeCalled()
    })
})
