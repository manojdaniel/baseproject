/*
 * Created on Tue Jun 29 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoomStatus, FeatureFlagHelper, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { errorLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef } from "react"
import { useSelector } from "react-redux"
import { GLOBAL_UPDATE_ROOMS } from "../../../redux/actions/types"
import { IStore } from "../../../redux/interfaces/types"
import { dispatchToParentStore } from "../../../redux/store/externalAppStates"
import { fetchRoomsStatus, getRoomStatusForRoomIdTransformer } from "./RoomStatusService"

const RoomStatus = () => {

    const {
        rooms, initRoomsFetched,
    } = useSelector((state: IStore) => ({
        rooms: state.externalReducer.rooms,
        initRoomsFetched: state.externalReducer.initRoomsFetched,
    }))

    const roomsRef = useRef(rooms)

    const subscribeRoomsStatus = () => {
        const roomIds = rooms.map(room => room.identity.id)
        fetchRoomsStatus(roomIds).subscribe((result: any) => {
            if (result.error) {
                errorLogger(`Exception occured while fetching rooms status: ${result.error}`)
            } else if (result.data) {
                const roomsStatus = getRoomStatusForRoomIdTransformer(result.data)
                roomsStatus.forEach(roomStatus => {
                    const roomIndex = rooms.findIndex(room => room.identity.id === roomStatus.resourceId)
                    if (roomIndex > -1) {
                        rooms[roomIndex] = { ...rooms[roomIndex], roomStatus: roomStatus.cameraEvent as ERoomStatus }
                    }
                })

                dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms } })
            }
        })

    }

    useEffect(() => { roomsRef.current = rooms }, [rooms])

    useEffect(() => {
        if (initRoomsFetched) {
            subscribeRoomsStatus()

        }
    }, [initRoomsFetched])

    return (
        <></>
    )
}

const RoomStatusController = () => {
    const { featureFlags } = useSelector((state:IStore) => ({
        featureFlags: state.externalReducer.featureFlags,
    }))
    if(FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_CAMERA_AI, false)) {
        return <RoomStatus />
    }
    return <></>
}

export default RoomStatusController
