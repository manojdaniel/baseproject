"""
 Created on Thurs June 02 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask_restful import Resource, reqparse
from flask import request, g
from src.loggers.log import create_logger
from src.services.mfa_org_policy_services import MfaOrgPolicyServices
from src.utility.utility import construct_negative_response
from src.utility.semver import parse_version
from src.exceptions.RoccException import RoccException
from src.constants.http_status_string import http_status_string_registry
from src.constants.constants import API_VERSION, AUTHORIZATION,  HELP_MESSAGE


LOG = create_logger("MFaPolicy controller")


class MfaPolicy(Resource):
    fu_parser_mfa_org_policy = reqparse.RequestParser()
    fu_parser_mfa_org_policy.add_argument("org_name", type=str, required=True, help=HELP_MESSAGE)
    fu_parser_mfa_org_policy.add_argument("org_hsdp_id", type=str, required=True, help=HELP_MESSAGE)
    fu_parser_mfa_org_policy.add_argument("is_checked", type=str, required=True, help=HELP_MESSAGE)

    def post(self):

        try:
            LOG.info("******************MFaPolicy controller**********")
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400

        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            body = self.fu_parser_mfa_org_policy.parse_args()
            mfa_org_policy_services = MfaOrgPolicyServices(customer_name=body["org_name"], service_user_uuid=g.userdetails,
                                                           customer_org_uuid=body["org_hsdp_id"], service_user_token=user_token)
            response_data, status = mfa_org_policy_services.add_update_mfa_policy(body)

            if not response_data:
                raise RoccException(status_code=status, payload=str("Failed to add/update mfaOrgPolicy"))
            return response_data, status

        except RoccException as ex:
            return construct_negative_response(code=http_status_string_registry[ex.status_code],
                                               title=ex.title,
                                               error_message=ex.payload,
                                               additional_info=ex.additional_info), ex.status_code
        except Exception:
            return construct_negative_response(code=500,
                                               title="Add mfaOrgPolicy in vault failed",
                                               error_message="Failed to add mfaOrgPolicy in vault"), 500
