import unittest

from src.wrappers.cf.cf_utility import fetch_data_from_vcap_app


class CFUtilityTestCase(unittest.TestCase):
    def test_fetch_data_from_vcap_app(self):
        self.assertIsNotNone(fetch_data_from_vcap_app("test", "test"))


if __name__ == '__main__':
    unittest.main()
