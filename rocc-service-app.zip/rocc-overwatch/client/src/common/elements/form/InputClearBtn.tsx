/*
 * Created on Fri Feb 12 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Icon } from "semantic-ui-react"
import "./InputClearBtn.scss"

interface IInputClearBtn {
    handleClear: () => void
}
const InputClearBtn = (props: IInputClearBtn) => {
    const { handleClear } = props
    return (
        <Icon className={"icon CrossCircle inputClear"} onClick={handleClear} />
    )
}
export default InputClearBtn
