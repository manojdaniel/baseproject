/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useRef, useState } from "react"
import "@dls-pdv/semantic-ui-foundation/dist/semantic.min.css"
import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { defineMessages, IntlProvider } from "react-intl"
import { Provider, useSelector } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import store, { persistor } from "./redux/store/store"
import ViewConsole from "./components/view-console/ViewConsole"
import IncognitoConsole from "./components/incognito-view-console/IncognitoConsole"
import ProtocolManagement from "./components/protocol-management/ProtocolManagement"
import { EConnectionType, getRoomDetailFromUuid, EPosition, EConnectionState } from "@rocc/rocc-client-services"
import { EN_LANGUAGE, EN_LOCALE, initReceiverSelectionModal } from "./common/constants/constants"
import ConsoleMonitorSelection from "./components/console-monitor-selection/ConsoleMonitorSelection"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import EditConsole from "./components/edit-console/EditConsole"
import { IStore } from "./redux/interfaces/types"
import SpokeMessage from "./components/spoke-message/SpokeMessage"
import { fetchRooms } from "./redux/store/externalAppStates"
import { setupLogger } from "@rocc/rocc-logging-module"
import { isDev } from "./common/helpers/helpers"
import messages from "./resources/translations/messages"
import ResumeConsole from "./components/parked-console/ResumeConsole"

interface IConsoleTrigger {
	connectionType: EConnectionType
	roomUuid: string
	showTitle?: boolean
	iconPosition?: EPosition
	componentName?: string
	callPanelEvent?: boolean
	connectionState?: EConnectionState
	secondary?:boolean
}
const { VIEW, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, FULL_CONTROL } = EConnectionType
const ConsoleTrigger = (props: IConsoleTrigger) => {

	const { roomUuid, connectionState } = props
	const [receiverSelectionModal, setReceiverSelectionModal] = useState(initReceiverSelectionModal)
	const httpClient = useRoccHttpClient()

	const roomDetailsRef = useRef(getRoomDetailFromUuid(fetchRooms(), roomUuid))
	const activeRoomUuid = roomDetailsRef && roomDetailsRef.current && roomDetailsRef.current.identity.uuid
	const locale = sessionStorage.getItem("locale")
	const language = sessionStorage.getItem("language")

	const {
		rooms
	} = useSelector((state: IStore) => ({
		rooms: state.externalReducer.rooms,
	}))

	useEffect(() => {
		setupAxiosHandler(httpClient)
		setupLogger({ isDev: isDev() })
	}, [])

	useEffect(() => {
		roomDetailsRef.current = getRoomDetailFromUuid(fetchRooms(), roomUuid)
	}, [roomUuid, rooms])

	const getConsoleConnection = () => {
		const { showTitle, connectionType, roomUuid, iconPosition, componentName, callPanelEvent,secondary } = props
		switch (connectionType) {
			case VIEW: {
				if (connectionState === EConnectionState.PARKED) {
					return <ResumeConsole roomUuid={roomUuid} showTitle={showTitle} setReceiverSelectionModal={setReceiverSelectionModal} iconPosition={iconPosition} component={componentName} />
				}
				return <ViewConsole roomUuid={roomUuid} showTitle={showTitle} setReceiverSelectionModal={setReceiverSelectionModal} iconPosition={iconPosition} component={componentName} />
			}
			case INCOGNITO_VIEW: return <IncognitoConsole roomUuid={roomUuid} showTitle={showTitle} setReceiverSelectionModal={setReceiverSelectionModal} iconPosition={iconPosition} component={componentName} />
			case PROTOCOL_MANAGEMENT: return <ProtocolManagement roomUuid={roomUuid} showTitle={showTitle} setReceiverSelectionModal={setReceiverSelectionModal} iconPosition={iconPosition} component={componentName} />
			case FULL_CONTROL: return <EditConsole roomUuid={roomUuid} showTitle={showTitle} setReceiverSelectionModal={setReceiverSelectionModal} iconPosition={iconPosition} component={componentName} callPanelEvent={callPanelEvent} secondary={secondary}/>
			default: return (callPanelEvent ? <SpokeMessage roomUuid={roomUuid} /> : <></>)
		}
	}
	const defaultLocale = language || EN_LOCALE
	const defaultMessage = (locale: string) => defineMessages(messages[locale])
	return <>
		<Provider store={store}>
			<PersistGate loading={null} persistor={persistor}>
				<HttpClientProvider client={httpClient}>
					<IntlProvider
						defaultLocale={defaultLocale}
						locale={defaultLocale}
						messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
					>
						<>
							{activeRoomUuid !== "" ? getConsoleConnection() : <></>}
							{receiverSelectionModal.showReceiverModal && <ConsoleMonitorSelection
								connectionType={props.connectionType}
								roomUuid={props.roomUuid}
								receiverSelectionModal={receiverSelectionModal}
								setReceiverSelectionModal={setReceiverSelectionModal}
							/>}
						</>
					</IntlProvider>
				</HttpClientProvider>
			</PersistGate>
		</Provider>
	</>
}

export default ConsoleTrigger
