/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse, IUserInfo } from "@rocc/rocc-client-services"
import { IManagedAxios } from "@rocc/rocc-http-client"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { fetchGlobalCurrentUser, fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import { getRequestHeader } from "../../../services/consoleService"
import { ACCEPT, API_VERSION, APPLICATION_JSON, AUTHORIZATION, CHAT, COMMUNICATION_SERVICE_MEDIA_ROOM_URI, CONTENT_TYPE, DEFAULT_API_VERSION, HTTP_STATUS } from "../../constants/constants"
import { COMMUNICATION_SERVICE_MESSAGE_URI, COMMUNICATION_TOKEN_EP } from "../../constants/endpoints"
import { getService, postService } from "../../helpers/apiUtility"


export const fetchCommunicationClientDetails = async (url: string, token: string, userId: string) => {
    let tokenDetails = { communicationToken: "", channelSid: "" }
    let status = EResponse.ERROR
    try {
        const params: IManagedAxios = {
            url: `${url}${COMMUNICATION_TOKEN_EP}`,
            headers: {
                [ACCEPT]: APPLICATION_JSON,
                [CONTENT_TYPE]: APPLICATION_JSON,
                [AUTHORIZATION]: token,
                [API_VERSION]: DEFAULT_API_VERSION
            },
            data: {
                userId,
                tokenType: CHAT
            }
        }
        const response = await postService(params)
        if (HTTP_STATUS.OK === response.status) {
            tokenDetails = {
                communicationToken: response.data.twillioAccessToken,
                channelSid: response.data.channelSid,
            }
            status = EResponse.SUCCESS
            return { status, tokenDetails }
        }
    } catch (error) {
        errorLogger(`Twilio token failed with error: ${errorParser(error)}`)
    }
    return { status, tokenDetails }
}

export const fetchMediaRoomDetails = async (mediaRoomId: string, currentUser: IUserInfo) => {
    try {
        const { COMMUNICATION_SERVICES_URL } = fetchGlobalURLs()
        const headers = getRequestHeader(currentUser.accessToken, DEFAULT_API_VERSION)
        const params = {
            url: `${COMMUNICATION_SERVICES_URL}${COMMUNICATION_SERVICE_MEDIA_ROOM_URI}/${mediaRoomId}`,
            headers,
        }
        const response = await getService(params)
        if (response.status === HTTP_STATUS.OK) {
            return response.data
        } else {
            const ERROR_MESSAGE = `Error occurred while fetching media room details : ${errorParser(response.data)} for user ${currentUser.uuid} `
            errorLogger(`${ERROR_MESSAGE}`)
            throw ERROR_MESSAGE
        }
    } catch (error) {
        errorLogger(`Exception occurred while fetching media room details : ${errorParser(error)} for user ${currentUser.uuid}`)
        throw error
    }
}

export const sendMessage = async ({ consoleData, userId }: {
    consoleData: any
    userId: string
}) => {
    const { accessToken } = fetchGlobalCurrentUser()
    const { COMMUNICATION_SERVICES_URL } = fetchGlobalURLs()

    const data = { userId, consoleData }
    const url = `${COMMUNICATION_SERVICES_URL}${COMMUNICATION_SERVICE_MESSAGE_URI}`

    try {
        const response = await postService({
            url,
            data,
            headers: getRequestHeader(accessToken, DEFAULT_API_VERSION),
        })
        if (response.status === HTTP_STATUS.OK) {
            infoLogger("Message sent sucessfully.")
            return response.data
        } else {
            const ERROR_MESSAGE = `Error occurred while sending message : ${errorParser(response.data)}`
            errorLogger(`${ERROR_MESSAGE}`)
            throw ERROR_MESSAGE
        }
    } catch (error) {
        errorLogger(`Exception occurred while sending message : ${errorParser(error)}`)
        throw error
    }
}
