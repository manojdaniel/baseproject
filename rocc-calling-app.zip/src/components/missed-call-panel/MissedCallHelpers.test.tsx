/*
 * Created on Tue Oct 12 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getMissedCalls, formattedDateTimeMsg, getLocalTime } from "./MissedCallHelpers"
import * as MissedCallServices from "./MissedCallServices"
import en from "../../resources/translations/en-US"
import { mount } from "enzyme"

describe("MissedCallHelpers tests", () => {
    const dispatch = jest.fn()
    const currentUser = {
        accessToken: "123",
        uuid: "123"
    }
    const url = "dummyurl"
    const secondaryUuid = true
    let messageElement: any
    const GMT = " GMT"
    const octoberDate = "Wed, 13 Oct 2021 "
    const midnightTime = "00:00:000"
    let currentTime = new Date(octoberDate + "00:00:001" + GMT)
    const missedCallTime = octoberDate + midnightTime + GMT
    const language = "EN"
    let timeStampElement: any
    const onestring = "1"
    const elementTwo = 2
    const ago = " ago"
    const testCasetitle = "get LocalTime element with "
    const checkIfNotString = (element: any) => typeof element !== "string"
    const checkfunction = (currentTimeValue: Date, testString1: string, testString2: string) => {
        timeStampElement = getLocalTime(missedCallTime, currentTimeValue, language)
        if (checkIfNotString(timeStampElement)) {
            messageElement = mount(timeStampElement)
            expect(messageElement.at(0).text()).toContain(testString1)
            expect(messageElement.at(elementTwo).text()).toContain(testString2)
        }
    }

    it("get missed details", () => {
        jest.spyOn(MissedCallServices, "getMissedCallsService").mockReturnValue(Promise.resolve(["missedcall1", "missedcall2"]))
        getMissedCalls(currentUser, dispatch, url, secondaryUuid)
        expect(MissedCallServices.getMissedCallsService).toBeCalled()
    })

    it("get formattedDateTimeMsg element", () => {
        const messageElement = mount(formattedDateTimeMsg(1, "content.missedCall.minute", en["content.missedCall.minute"], language))
        expect(messageElement.at(0).text()).toContain(onestring)
        expect(messageElement.at(elementTwo).text()).toContain("minute")
    })

    it(testCasetitle + "just now", () => {
        timeStampElement = getLocalTime(missedCallTime, currentTime, language)
        if (checkIfNotString(timeStampElement)) {
            messageElement = mount(timeStampElement)
            expect(messageElement.at(0).text()).toContain("Just now")
        }
    })

    it(testCasetitle + "hours" + ago, () => {
        currentTime = new Date(octoberDate + "23:00:000" + GMT)
        checkfunction(currentTime, "23", "hours")
    })

    it(testCasetitle + "hour" + ago, () => {
        currentTime = new Date(octoberDate + "01:00:000" + GMT)
        checkfunction(currentTime, onestring, "hour")
    })

    it(testCasetitle + "minutes" + ago, () => {
        currentTime = new Date(octoberDate + "00:05:000" + GMT)
        checkfunction(currentTime, "5", "minutes")
    })

    it(testCasetitle + "minute" + ago, () => {
        currentTime = new Date(octoberDate + "00:01:120" + GMT)
        checkfunction(currentTime, onestring, "minute")
    })

    it(testCasetitle + "day" + ago, () => {
        currentTime = new Date("Thu, 14 Oct 2021" + midnightTime + GMT)
        checkfunction(currentTime, onestring, "day")
    })

    it(testCasetitle + "days" + ago, () => {
        currentTime = new Date("Fri, 15 Oct 2021" + midnightTime + GMT)
        checkfunction(currentTime, "2", "days")
    })

    it(testCasetitle + "month" + ago, () => {
        currentTime = new Date("Sat, 13 Nov 2021" + midnightTime + GMT)
        checkfunction(currentTime, onestring, "month")
    })

    it(testCasetitle + "months" + ago, () => {
        currentTime = new Date("Thu, 13 Jan 2022" + midnightTime + GMT)
        timeStampElement = getLocalTime(missedCallTime, currentTime, language)
        if (checkIfNotString(timeStampElement)) {
            messageElement = mount(timeStampElement)
            expect(messageElement.at(1).text()).toContain("3")
            expect(messageElement.at(elementTwo).text()).toContain("months")
        }
    })
})
