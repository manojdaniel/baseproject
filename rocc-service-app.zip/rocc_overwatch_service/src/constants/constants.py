"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

# Generic constants
SEP = "=" * 30
UTF_8 = "UTF-8"
DATA = "data"
SPACE_ID = "space_id"
VAULT_URL = "vault_url"
CLIENT_TOKEN = "client_token"
TWILIO_PLAN_SUBACCOUNT = "subaccount"
ROCC_SUFFIX = "-rocc"
TEMPLATE_VERSION_1_0_0 = "1.0.0"
TEMPLATE_VERSION_1_0_1 = "1.0.1"
TEMPLATE_VERSION_1_0_2 = "1.0.2"
TEMPLATE_VERSION_1_0_3 = "1.0.3"
TEMPLATE_VERSION_1_0_4 = "1.0.4"
TEMPLATE_VERSION_1_0_5 = "1.0.5"
TEMPLATE_VERSION_1_0_6 = "1.0.6"
HELP_MESSAGE = "This field cannot be left blank!"
APPEND = "append"

# Environment constants
HSDP_VAULT = "hsdp-vault"
HSDP_RABBITMQ = "hsdp-rabbitmq"
ROCC_PROXY_URL = "ROCC_PROXY_URL"
HSDP_IAM_URL = "HSDP_IAM_URL"
VAULT_ROCC_CRED_PATH = "VAULT_ROCC_CRED_PATH"
CF_TARGET_ENDPOINT = "cf_api"
CF_DOMAIN = "CF_DOMAIN"
PROXY_APP_NAME = "PROXY_APP_NAME"
CF_SPACE_NAME = "space_name"
TWILIO_POOL_APP_NAME = "TWILIO_POOL_APP_NAME"
TWILIO_APP_NAME = "TWILIO_APP_NAME"
ENV = "ENV"
VCAP_APPLICATION = "VCAP_APPLICATION"

# API/Endpoints constants
PHILIPS_OVERWATCH_URI = "/philips/rocc-overwatch"
PHILIPS_ROCC_URI = "/philips/rocc"
EMAIL_TEMPLATE_URI = "/authorize/identity/EmailTemplate"
AUTHORIZATION = "Authorization"
CONTENT_TYPE = "Content-Type"
APPLICATION_JSON = "application/json"
API_VERSION = "api-version"
ORG_CTXT_HEADER = "org_ctxt_header"
RESPONSE_RESOURCE_TYPE = "resourceType"
RESPONSE_OPERATION_TYPE = "operationType"
RESPONSE_IDENTIFIER = "identifier"
SERVICE_AUTH_ISSUER = "serviceAuthIssuer"
SERVICE_AUTH_PRIVATE_KEY = "serviceAuthPrivateKey"
APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded"
X_VAULT_TOKEN = "X-Vault-Token"
X_TOKEN = "X-Token"
ACCEPT = "Accept"
CORS_HEADERS = "CORS_HEADERS"
HELP_MSG = "This field cannot be left blank!"
HSDP_ORGANIZATION_ID = "hsdpOrganizationId"
HSDP_API_SIGNATURE = "hsdp-api-signature"
SIGNED_DATE = "SignedDate"
API_SIGNATURE_SHARED_KEY = "API_SIGNATURE_SHARED_KEY"
API_SIGNATURE_SECRET_KEY = "API_SIGNATURE_SECRET_KEY"
LOG_INGESTER_URL = "LOG_INGESTER_URL"

# API Headers
CUSTOMER_IDENTIFIER = "customer_identifier"

# Status constants
INIT = "INIT"
FAILED = "FAILED"
NOT_STARTED = "NOT_STARTED"
COMPLETED = "COMPLETED"
PROCESS_COMPLETE = "PROCESS_COMPLETE"
PARTIALLY_COMPLETE = "PARTIALLY_COMPLETE"
STATUS = "STATUS"
SKIPPED = "SKIPPED"

# RabbitMQ constants
ROCC_SERVICE_TOOL_EXCHANGE = "service.tool.exchange"
ROCC_SERVICE_TOOL_ROUTING_KEY = "service.tool.requests"
ROCC_SERVICE_TOOL_QUEUE = "service.tool.queue"
ROCC_SERVICE_TOOL_JOB_QUEUE = "service.tool.job.requests.queue"
ROCC_DELAYED_QUEUE = "service.tool.requests.delay"
ROCC_DELAY_EXCHANGE = "service.tool.delay.exchange"
TARGET_QUEUE = "TARGET_QUEUE"
ROUTING_KEY = "ROUTING_KEY"
CURRENT_JOB = "CURRENT_JOB"
JOB_LIST = "JOB_LIST"
OPERATION = "OPERATION"
OPERATION_STATUS = "OPERATION_STATUS"
TRANSACTION_ID = "TRANSACTION_ID"
ENTITY_ID = "ENTITY_ID"
ENTITY_TYPE = "ENTITY_TYPE"
JOB_NAME = "JOB_NAME"
INDEX = "INDEX"
PERSIST_RABBIT_QUEUE = "PERSIST_RABBIT_QUEUE"
DELAY_MESSAGE_TIME_IN_SECONDS = "DELAY_MESSAGE_TIME_IN_SECONDS"
DELAY_QUEUE_EXPIRY_TIME_IN_SECONDS = "DELAY_QUEUE_EXPIRY_TIME_IN_SECONDS"
RABBIT_RETRY_MAX_TRIES = "RABBIT_RETRY_MAX_TRIES"
RABBIT_RETRY_DELAY = "RABBIT_RETRY_DELAY"
RABBIT_RETRY_MAX_JITTER = "RABBIT_RETRY_MAX_JITTER"

# DB Column Names
JOB_NAME_COLUMN = "job_name"
TASK_NAME_COLUMN = "task_name"
OPERATION_TYPE_COLUMN = "operation_type"
CURRENT_JOB_ID_COLUMN = "current_job_id"
CURRENT_TASK_ID_COLUMN = "current_task_id"
UPLOAD_RECORD_ID_COLUMN = "upload_record_id"
ENTITY_ID_COLUMN = "entity_id"
ENTITY_TYPE_COLUMN = "entity_type"
TRANSACTION_DATA_COLUMN = "transaction_data"
STATUS_COLUMN = "status"
CREATED_BY = "created_by"
MODIFIED_BY = "modified_by"
RECEIVER_ID = "receiver_id"
REMOTE_FACILITY_ID = "remote_facility_id"
SUPER_TECH_SEAT_ID = "supertech_seat_id"
SEAT_ID = "seat_id"
SITE_ID = "site_id"
DEVICE_HSDP_UUID = "device_hsdp_uuid"
ORG_HSDP_UUID = "org_hsdp_uuid"
BOXILLA_IP = "boxilla_ip"
TRANSMITTER_IP = "transmitter_ip"
RECEIVER_IP = "receiver_ip"
ORG_IDENTIFIER = "org_identifier"
AFFECTED_ROWS = "affected_rows"

# Dictionaries
SITES_DICT = "SITES_DICT"
EMP_DICT = "EMP_DICT"
ROOMS_DICT = "ROOMS_DICT"
MODALITY_DICT = "MODALITY_DICT"
COMMAND_CENTERS_DICT = "COMMAND_CENTERS_DICT"
ROLE_PERMISSION_DICT = "ROLE_PERMISSION_DICT"
ERROR_DICT = "ERROR_DICT"
CUSTOMER_INFO_DICT = "CUSTOMER_INFO_DICT"
TEMPLATE_DETAILS = "TEMPLATE_DETAILS"
KVM_CONFIGURATION_DICT = "KVM_CONFIGURATION_DICT"
EULA_DICT = "EULA_DICT"
EMAIL_ID = "Email ID /Unique ID"
PHONE_NO = "Phone Number (with Country code)"
ROOM_PHONE_NO_WITH_COUNTRY_CODE = "Room Phone Number(with Country code)"
FRONT_DESK_CONTACT_NO_WITH_COUNTRY_CODE = "Frontdesk Contact Number (with country code)"
SCHEDULER_CONTACT_NO_WITH_COUNTRY_CODE = "Schedular Contact Number(with country code)"
CUSTOMER_IDENTIFIER_CUSTOMER_INFO_SHEET = "IDN/Customer Identifier- To be filled by Philips"

# Table names
""" Overwatch Tables """
ROCC_OVERWATCH_SERVICE_JOB_TRANSACTIONS = "rocc_overwatch_service_job_transactions"
ROCC_OVERWATCH_RAW_UPLOAD_DATA = "rocc_overwatch_raw_upload_data"
ROCC_OVERWATCH_CUSTOMERS = "rocc_overwatch_customers"
ROCC_OVERWATCH_SERVICE_TASKS = "rocc_overwatch_service_tasks"
ROCC_OVERWATCH_INFRASTRUCTURE_CONFIGS = "rocc_overwatch_infrastructure_configurations"
""" ROCC Tables """
ROCC_SITES = "rocc_sites"
ROCC_MODALITY_TYPES = "rocc_modality_types"
ROCC_TRANSMITTERS = "rocc_rocc_transmitters"
ROCC_COMMAND_CENTRE_SEATS = "rocc_rocc_command_centre_seats"
ROCC_RECEIVERS = "rocc_rocc_receivers"
ROCC_RECEIVER = "rocc_receiver"
ROCC_CC_RECEIVER_MAPPINGS = "rocc_rocc_command_centre_receiver_mappings"
ROCC_COMMAND_CENTER_RECEIVER_MAPPINGS = "rocc_command_centre_receiver_mappings"
ROCC_KVM_TRANSACTIONS_AGGREGATE = "rocc_rocc_kvm_transactions_aggregate"
ROCC_UPDATE_COMMAND_CENTER_SEATS = "update_rocc_rocc_command_centre_seats"
ROCC_DELETE_COMMAND_CENTER_SEATS = "delete_rocc_rocc_command_centre_seats"
ROCC_USERS = "rocc_users"
ROCC_ORGANIZATIONS = "rocc_organizations"
ROCC_KVM_CONFIGURATIONS = "rocc_rocc_kvm_configurations"
ROCC_SCANNER_RESOURCES = "rocc_scanner_resources"
ROCC_TX_MAPPINGS = "rocc_rocc_transmitter_mappings"
ROCC_TABLETS = "rocc_rocc_tablets"
ROCC_SCHEMA = "rocc"
ROCC_APPLICATION_ROLES = "rocc_rocc_application_roles"
ROCC_DOCUMENTS = "rocc_rocc_organization_documents"
ROCC_CONTACT_TYPES = "rocc_rocc_contact_types"
ROCC_USER_ORGANIZATION_MAPPINGS = "rocc_rocc_user_organization_mappings"


# DB Fields
CONTACT_TYPE = "contact_type"

# Query names
INSERT = "insert_"
UPDATE = "update_"
# DB Response
RETURNING = "returning"
ID = "id"
OBJECTS = "objects"
CUSTOMER_NAME = "customer_name"
TASKS = "tasks"
TRANSACTION_DATA = "transaction_data"
JOBS = "jobs"
CURRENT_JOB_ID = "current_job_id"


# Payload Constansts
CURRENT_JOB = "CURRENT_JOB"
TRANSACTION_ID = "transaction_id"
ENTITY_ID = "ENTITY_ID"
ID = "id"
STATUS_VARIABLE = "status"
NAME = "name"
JOB_ID = "job_id"
TASK_ID = "task_id"
USER_UUID = "USER_UUID"
FAILED_AT = "failed_at"
REASON = "reason"

# Employee dict constants
IS_NEW = "isNew"
IS_SUCCESSFULL = "isSuccessfull"
SUCCESSFULL_USER_LIST = "successful_user_list"
FAILED_USER_LIST = "failed_user_list"

# Vault keys
BB_BOXILLA_IP = "BBBoxillaIP"
BB_BOXILLA_USER = "BBBoxillaUser"
BOXILLA_REST_USER_PASS_VALUE = "boxillaRestUserPassValue"
BOXILLA_USER_PASS_VALUE = "boxillaUserPassValue"
BOXILLA_EMERALD_APP_USER_CREDENTIAL: "boxillaEmeraldAppUserCredentials"
BOXILLA_EMERALD_APP_PUBLIC_KEY: "boxillaEmeraldAppPublicKey"
MFA_ORG_POLICY: "mfaOrgPolicy"


# Separator
EXCEL_MULTI_KEY_SEPARATOR = ":::"

# Error constants
RECEIVER_FK_VIOLATION = "rocc_command_centre_receiver_mappings_receiver_id_fk"

# Org role constants
MANDATORY_ORG_ROLES = ["ADMINROLE", "EXPERTUSERROLE", "DEVICEROLE"]
# REGEX FOR EMAIL ACCEPT ENGLISH ALBHABETS ONLY
EMAIL_FORMAT_REGEX = "(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
PHONE_NO_FORMAT_REGEX = "^(\\+?[0-9]*?)?[0-9]*$"
IP_FORMAT = "^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"

# PERMISSION RESOURCE ACTION NAME ADDED
FSE_USER = "FSE_USER"
FSE_USER_ADD = "FSE_USER_ADD"
FSE_USER_EDIT = "FSE_USER_EDIT"
ROLES = "roles"
EMAIL_ID_KEY = "email_id"


# MFA POLICY FOR MULTIFACTOR AUTHENTICATION
MFA_ORG_POLICY = "mfaOrgPolicy"
MFA_ORG_POLICY_ID = "mfaOrgPolicyId"
MFA_ORG_POLICY_FALSE = "False"
MFA_ORG_POLICY_TRUE = "True"
IF_MATCH = "If-Match"


# MODALITY CONNECTION COLUMN NAMES FOR DB
CONNECTION_IP = "IP"
CONNECTION_PRIORITY = "Priority"
CONNECTION_MODE = "Connection_mode"
CONNECTION_USERNAME = "Connection_username"
CONNECTION_PROPERTIES = "Properties"

# ALLOWED PRIORITIES
PRIORITIES = ["Priority-1", "Priority-2", "Priority-3", ""]
