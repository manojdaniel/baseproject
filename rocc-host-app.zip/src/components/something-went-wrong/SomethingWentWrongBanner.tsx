/*
 * Created on Mon Jan 24 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { parseIntBase10, EConnectionStatus, IParentStore, EClinicalRole } from "@rocc/rocc-client-services"
import { SomethingWentWrong } from "@rocc/rocc-global-components"
import { warningLogger } from "@rocc/rocc-logging-module"
import React, { useRef, useEffect } from "react"
import { useSelector } from "react-redux"
import { TRACK } from "../../constants/tracking"
import { trackEvent } from "../../utility/helpers/helpers"

const SomethingWentWrongBanner = ({ onRetry }: { onRetry: () => void }) => {
    const {
        deviceRecoveryTimeInMins,
        applicationConnectionState,
        forceCleanUp,
        currentUser
    } = useSelector((state: IParentStore) => ({
        deviceRecoveryTimeInMins: state.configReducer.configs.DEVICE_RECOVERY_TIME_IN_MINS,
        applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
        forceCleanUp: state.userReducer.forceCleanUp,
        currentUser: state.userReducer.currentUser
    }))

    const deviceOrDesktopTag = currentUser.clinicalRole === EClinicalRole.DEVICE ? "Device" : "Desktop"
    const forceCleanUpRef = useRef(forceCleanUp)

    let timeoutId: NodeJS.Timeout
    const timeoutLength = deviceRecoveryTimeInMins ? parseIntBase10(deviceRecoveryTimeInMins) * 60 * 1000 : 2 * 60 * 1000

    useEffect(() => { forceCleanUpRef.current = forceCleanUp }, [forceCleanUp])
    useEffect(() => {
        if (applicationConnectionState === EConnectionStatus.ONLINE && forceCleanUp) {
            timeoutId = setTimeout(() => {
                /* Auto-recovery */
                if (forceCleanUpRef.current) {
                    warningLogger(`${deviceOrDesktopTag}: Automatically triggering Retry option from Recovery banner!`)
                    onRetry()
                }
            }, timeoutLength)
        } else {
            if (timeoutId) {
                clearTimeout(timeoutId)
            }
        }
    }, [applicationConnectionState, forceCleanUp])


    const handleClick = () => {
        const { component, event: { retry } } = TRACK.SOMETHING_WENT_WRONG
        trackEvent(component, retry, { Page: `${deviceOrDesktopTag} Home` })
        warningLogger(`${deviceOrDesktopTag}: Manually triggering Retry option from Recovery banner!`)

        if (timeoutId) {
            clearTimeout(timeoutId)
        }
        onRetry()
    }


    return (
        <SomethingWentWrong display={forceCleanUp} handleClick={handleClick} />
    )
}

export default SomethingWentWrongBanner
