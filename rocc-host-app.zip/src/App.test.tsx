/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import App from "./App"
import { shallow } from "enzyme"

jest.mock("react-redux", () => ({
  useSelector: () => ({
    configData: {
      locales: ["en-US"],
      preferredLocale: "en-US",
      theme: "default",
      language: "en",
    }
  }),
  useDispatch: () => void (0),
}))

describe("App Component", () => {
  let wrapper: any
  let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
  beforeEach(() => {
    useEffect = jest.spyOn(React, "useEffect")
    const mockUseEffect = () => {
      useEffect.mockImplementationOnce(f => f())
    }
    mockUseEffect()
    wrapper = shallow(<App />)
  })

  it("App Component should render Routes component", () => {
    expect(wrapper.find("Routes")).toHaveLength(1)
  })

  it("App Component should render PersistGate component", () => {
    expect(wrapper.find("PersistGate")).toHaveLength(1)
  })
})
