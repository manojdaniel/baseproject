
import unittest
from unittest.mock import Mock
from src.constants.headers import EXCEL_HOSPITAL_IDENTIFIER
from src.exceptions.RoccException import RoccException
from src.modules.db_operations.db_utility.common_query_functions import fetch_overwatch_customer_id_from_name, \
    get_site_id_from_site_short_name, fetch_org_db_id_from_identifier, fetch_clinical_role_id, \
    get_organization_user_mappings, check_and_add_fse_to_org_mapping, update_user_org_mapping


class FetchSiteIdFromNameTest(unittest.TestCase):

    def test_get_site_id_from_site_short_name_success_present_in_sheet(self):
        response = get_site_id_from_site_short_name(client="mock_client", site_short_name="site_name", sites={"key": {EXCEL_HOSPITAL_IDENTIFIER: "site_name", "site_id": 1}})
        self.assertEqual(response, False, "Site id should be returned if present in excel sheet")

    def test_get_site_id_from_site_short_name_success_not_present_in_sheet(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_sites": [{"id": 1}]}
        response = get_site_id_from_site_short_name(client=mock_client, site_short_name="site_name", sites={})
        self.assertEqual(response, 1, "Site id should be fetched and returned if not present in excel sheet")

    def test_get_site_id_from_site_short_name_failure_client(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        response = get_site_id_from_site_short_name(client=mock_client, site_short_name="site_name", sites={})
        self.assertEqual(response, False, "Return false on when site id is false")

    def test_get_site_id_from_site_short_name_failure_key_error(self):
        mock_client = Mock()
        response = get_site_id_from_site_short_name(client=mock_client, site_short_name="site_name", sites={"key": {EXCEL_HOSPITAL_IDENTIFIER: "site_name"}})
        self.assertEqual(response, False, "Return false on key error")

    def test_get_site_id_from_site_short_name_failure_exception(self):
        mock_client = Mock()
        response = get_site_id_from_site_short_name(client=mock_client, site_short_name="site_name", sites="")
        self.assertEqual(response, False, "Return false on exception")


class FetchOverwatchCustomerIdFromName(unittest.TestCase):

    def test_fetch_overwatch_customer_id_from_name_success_customer_present(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_overwatch_customers": [{"id": 1}]}
        response = fetch_overwatch_customer_id_from_name(client=mock_client, customer_name="test")
        self.assertEqual(response, 1, "Should return 1 if customer present")

    def test_fetch_overwatch_customer_id_from_name_failure_not_found(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_overwatch_customers": []}
        self.assertRaises(RoccException, fetch_overwatch_customer_id_from_name, mock_client, "test")

    def test_fetch_overwatch_customer_id_from_name_failure_client_error(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        self.assertRaises(RoccException, fetch_overwatch_customer_id_from_name, mock_client, "test")

class FetchOrdDBIdFromIdentifierTest(unittest.TestCase):

    def test_fetch_org_db_id_from_identifier_success(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_organizations": [{"id": 1}]}
        response = fetch_org_db_id_from_identifier(client=mock_client, customer_identifier="test")
        self.assertEqual(response, 1, "Should return 1 if org id present")

    def test_fetch_org_db_id_from_identifier_failure_client_error(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        response = fetch_org_db_id_from_identifier(client=mock_client, customer_identifier="test")
        self.assertEqual(response, False, "Return false on when org id is not present")

class FetchClinicalRoleIdTest(unittest.TestCase):

    def test_fetch_clinical_role_id_failure(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_rocc_application_roles": [{"id": 1}]}
        response = fetch_clinical_role_id(role="", client=mock_client, user_uuid="test")
        self.assertEqual(response, None, "Should return None if no given role exists")

    def test_fetch_clinical_role_id_success(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_rocc_application_roles": [{"id": 1}]}
        response = fetch_clinical_role_id(role="test", client=mock_client, user_uuid="test")
        self.assertEqual(response, 1, "Should return 1 if role id present")

    def test_fetch_clinical_role_id_success_mutation_response(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_rocc_application_roles": [{"id": 0}],"insert_rocc_rocc_application_roles":{"returning":[{"id": 1}]}}
        response = fetch_clinical_role_id(role="test", client=mock_client, user_uuid="test")
        self.assertEqual(response, 1, "Should return 1 if role id extract from db")

    def test_fetch_clinical_role_id_failure_client_error(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        fetch_clinical_role_id(role="test", client=mock_client, user_uuid="test")

class GetOrganizationUserMappingsTest(unittest.TestCase):

    def get_organization_user_mappings_failure(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_rocc_application_roles": [{"id": 1}]}
        response = get_organization_user_mappings(client=mock_client, variable_values="test")
        self.assertEqual(response, None, "Should return None if no given role exists")

    def test_fetch_clinical_role_id_success(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_rocc_application_roles": [{"id": 1}]}
        response = get_organization_user_mappings( client=mock_client, variable_values="test")
        self.assertIsNone(response, "Should return 1 if role id present")

class CheckAndAddFseToOrgMapping(unittest.TestCase):

    def test_check_and_add_fse_to_org_mapping_count(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"rocc_users": [{"id": 1}], "rocc_rocc_user_organization_mappings_aggregate":{"aggregate":{"count":0}}}
        response = check_and_add_fse_to_org_mapping(client=mock_client, fse_user_uuid="1", org_db_id="rocc_users")
        self.assertIsNone(response, "Should return 1 if role id present")

    def test_check_and_add_fse_to_org_mapping(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        response = check_and_add_fse_to_org_mapping(client=mock_client, fse_user_uuid="1", org_db_id="rocc_users")
        self.assertIsNone(response, "Should return 1 if role id present")


class UpdateUserOrgMapping(unittest.TestCase):
    def test_update_user_org_mapping(self):
        mock_client = Mock()
        mock_client.side_effect = Exception()
        response = update_user_org_mapping(client=mock_client, variable_values="test")
        self.assertIsNone(response, "Should return 1 if role id present")

    def test_update_user_org_mapping_count(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"Updated org_user_mapping."}
        update_user_org_mapping(client=mock_client, variable_values="test")
