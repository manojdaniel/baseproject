/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EConnectionMode, EConnectionState, EConnectionType, EModalityType, IConsoleSession } from "@rocc/rocc-client-services"
import { EBannerType, RoomBannerTabInfo } from "@rocc/rocc-console-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React from "react"
<<<<<<< HEAD
import { useSelector } from "react-redux"
import { getConnectionAdapter } from "../../../common/helpers/connection"
import { checkIfMultiAudioFeatureEnabled, checkIfMultiEditWithoutParkResumeFeatureEnabled, checkIfMultiEditWithParkResumeFeatureEnabled, registerCallDisconnectWorkflow, registerConsoleSessionDisconnectWorkflow, registerCallDisconnectWithoutModalWorkflow, registerToggleCallControlWorkflow } from "../../../common/helpers/consoleUtility"
import { checkForConnectedCall, fetchCallDetailsByContextId, getRoomDetails, getWarningMessage, hasActiveVidoCallWithRoom } from "../../../common/helpers/helpers"
import { GLOBAL_LEFTSIDE_PANEL } from "../../../redux/actions/types"
=======
import { useDispatch, useSelector } from "react-redux"
import { checkIfMultiAudioFeatureEnabled, checkIfMultiEditWithoutParkResumeFeatureEnabled, checkIfMultiEditWithParkResumeFeatureEnabled, createConsoleDisconnectOperation, registerCallDisconnectWorkflow, registerConsoleSessionDisconnectWorkflow, registerCallDisconnectWithoutModalWorkflow, registerToggleCallControlWorkflow } from "../../../common/helpers/consoleUtility"
import { checkForConnectedCall, fetchCallDetailsByContextId, getRoomDetails, hasActiveVidoCallWithRoom } from "../../../common/helpers/helpers"
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
import { IStore } from "../../../redux/interfaces/types"
import { dispatchToParentStore } from "../../../redux/store/externalAppStates"
import styles from "../console-view-banner/ViewConsoleBanner.scss"

const componentName = "Active Console Tab Header"

interface IActiveConsoleSession {
    activeSession: IConsoleSession
}
const component = "Active Console Tab Header"

const ActiveConsoleTabHeader = (props: IActiveConsoleSession) => {
    const { activeSession } = props
    const { roomUuid, receiverName, connectionType, connectionMode } = activeSession
    const { CT, MR } = EModalityType
    const { EMERALD, VNC, RDP } = EConnectionMode

<<<<<<< HEAD
    const { receivers, videoCallStatus, connectedCallDetails, onHoldCallDetails } = useSelector((state: IStore) => ({
=======
    const dispatch = useDispatch()

    const { consoleSessions, receivers, videoCallStatus } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        videoCallStatus: state.externalReducer.callDetails.videoCallStatus,
    }))

    const getMonitorName = (recevierName: string) => {
        const receiver = receivers && receivers.find(receiver => receiver.receiverName === recevierName)
        return receiver ? receiver.monitorName : ""
    }

    const callIcon = videoCallStatus && checkForConnectedCall(videoCallStatus) && hasActiveVidoCallWithRoom(roomUuid)

    const { name, address, location, modality } = getRoomDetails(activeSession)
    const isMultiAudioEnabled = checkIfMultiAudioFeatureEnabled()
    const callDetails = fetchCallDetailsByContextId(activeSession.additionalData?.callContextId)
    const callOptions = { contextId: callDetails?.contextId || "", isMuted: callDetails?.isMuted || false, isDeafened: callDetails?.isDeafened || false, participants: callDetails?.participants || [] }

    const bannerType = (checkIfMultiEditWithoutParkResumeFeatureEnabled() && EBannerType.MULTI_EDIT_WITHOUT_PARK)
        || (checkIfMultiEditWithParkResumeFeatureEnabled() && EBannerType.MULTI_EDIT_WITH_PARK)
        || EBannerType.SINGLE_EDIT

    const disconnectConsoleSession = () => {
        if (checkIfMultiEditWithoutParkResumeFeatureEnabled()) {
            registerConsoleSessionDisconnectWorkflow({ roomUuid, componentName, connectionMode })
        } else {
            const { status } = getConnectionAdapter().disconnect({ roomUuid, connectionType: EConnectionType.FULL_CONTROL })
            if (status) {
                dispatchToParentStore({
                    type: GLOBAL_LEFTSIDE_PANEL,
                    payload: {
                        displayLeftSidePanel: false,
                        activeLeftPanel: "",
                        desktopFullScreen: false,
                    }
                })
            }
        }
    }

    const disconnectCallWrapper = (callContextId: string) => {
        if (checkIfMultiEditWithoutParkResumeFeatureEnabled()) {
            registerCallDisconnectWorkflow({ callContextId, componentName })
        } else {
            registerCallDisconnectWithoutModalWorkflow({ callContextId, componentName })
        }
    }

    const callEndEvent = (callOptions: any) => {
        disconnectCallWrapper(callOptions.contextId)
        sendLogsToAzure({ contextData: { component, event: `${" Call ended with Participant with uuid"} ${callOptions.participants[0].uuid}` } })
    }

    const callMuteEvent = (callOptions: any) => {
        registerToggleCallControlWorkflow({ callContextId: callOptions.contextId, toggles: { muteStatus: !callOptions.isMuted }, roomUuid, componentName })
        const muted = !callOptions.isMuted ? "muted" : "unmuted"
        sendLogsToAzure({ contextData: { component, event: `${"Participant with uuid"} ${callOptions.participants[0].uuid} ${muted}` } })

    }
    const callDeafenEvent = (callOptions: any) => {
        registerToggleCallControlWorkflow({ callContextId: callOptions.contextId, toggles: { deafenStatus: !callOptions.isDeafened }, roomUuid, componentName })
        const deafened = !callOptions.isDeafened ? "deafened" : "undeafended"
        sendLogsToAzure({ contextData: { component, event: `${"Participant with uuid"} ${callOptions.participants[0].uuid} ${deafened}` } })

    }

    const consoleSessionEndEvent = (callOptions: any) => {
        disconnectConsoleSession()
        sendLogsToAzure({ contextData: { component, event: `${" Console Session ended with Participant with uuid"} ${callOptions.participants[0].uuid}` } })
    }

    const bannerTabProps = {
        bannerType,
        consoleConnectionType: connectionType,
        activeTab: true,
        showCallIcon: callIcon || false,
        showParked: activeSession.connectionStatus === EConnectionState.PARKED,
        recieverName: getMonitorName(receiverName),
        roomName: name,
        roomDepartment: address,
        roomLocation: location,
        roomModality: modality === CT ? CT : MR,
<<<<<<< HEAD
        warningMessage: getWarningMessage(),
        nccConnection: [EMERALD, VNC, RDP].includes(connectionMode),
=======
        nccConnection: connectionMode === EMERALD,
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
        isMultiAudioEnabled,
        callDetails: { contextId: callOptions.contextId, isMuted: callOptions.isMuted, isDeafened: callOptions.isDeafened },
        onConsoleSessionEndIconClick: () => consoleSessionEndEvent(callOptions),
        onCallEndIconClick: () => callEndEvent(callOptions),
        onMuteIconClick: () => callMuteEvent(callOptions),
        onDeafendedIconClick: () => callDeafenEvent(callOptions),
    }

    return (

        <div className={styles.tabHeader} id="bannerTab">
            <RoomBannerTabInfo {...bannerTabProps} />
        </div>
    )
}

export default ActiveConsoleTabHeader
