/*
 * Created on Thu Oct 15 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import PDVTableHead from "./TableHead"

describe("TableHead component", () => {
    let wrapper: any
    let tableHeadId: any
    let props: any
    props = {
        title: "string",
        actions:"",
    }
    beforeEach(() => {
        wrapper = shallow(<PDVTableHead {...props}  />)
        tableHeadId = wrapper.find("#TableHead")
    })
    it("should render with the correct id", () => {
        expect(tableHeadId).toHaveLength(1)
    })
})