"""
 Created on Thurs June 02 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import requests
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_HSDP_IDM_URL
from src.exceptions.RoccException import RoccException
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.constants.constants import DATA, ID, IF_MATCH, MFA_ORG_POLICY_ID, MFA_ORG_POLICY_TRUE, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, APPLICATION_JSON, CONTENT_TYPE, AUTHORIZATION, API_VERSION, ACCEPT, MFA_ORG_POLICY, MFA_ORG_POLICY_FALSE
from src.loggers.log import create_logger
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit

LOG = create_logger("MfaOrgPolicyServices")


class MfaOrgPolicyServices():

    def __init__(self, customer_name, service_user_uuid, customer_org_uuid, service_user_token):
        try:
            LOG.info("MfaOrgPolicyServices initialize")
            self.service_user_uuid = service_user_uuid
            self.customer_name = customer_name
            self.customer_org_uuid = customer_org_uuid
            self.service_user_token = service_user_token
            self._profile_configs = get_profile_data()
        except RoccException as ex:
            LOG.error(f"Mfa Org policy Service initialization failed with error: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"Mfa Org policy Service Service initialization failed with error: {ex}")
            raise RoccException(title="Initialization Failed", status_code=500, payload="Internal server error") from ex

    def populate_customer_service_tokens(self):

        LOG.info("populate_customer_service_tokens")
        customer_vault_values = get_path_specific_vault_values(self.customer_name)
        self.customer_vault_values = customer_vault_values
        self.service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                             issuer=customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                             private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
        LOG.info("service token generated for customer")

    def add_update_mfa_policy(self, body):
        self.request = body
        response_data = False
        response_status = 500
        self.populate_customer_service_tokens()
        req_url, req_body, req_headers = self.create_mfa_invoke_param()
        if not (self.customer_vault_values[DATA][MFA_ORG_POLICY].lower() == MFA_ORG_POLICY_FALSE.lower() or
                self.customer_vault_values[DATA][MFA_ORG_POLICY].lower() == MFA_ORG_POLICY_TRUE.lower()):
            LOG.error("Invalid value for mfaOrgPolicy property")
            return response_data, response_status

        if self.customer_vault_values[DATA][MFA_ORG_POLICY].lower() == MFA_ORG_POLICY_FALSE.lower() and self.customer_vault_values[DATA][MFA_ORG_POLICY_ID] == "":
            response_data, response_status = self.add_mfa_policy(url=req_url, body=req_body, header=req_headers)
        else:
            response_data, response_status = self.update_mfa_policy(url=req_url, body=req_body, header=req_headers)

        return response_data, response_status

    def create_mfa_invoke_param(self):
        req_url = f"{self._profile_configs[VAULT_HSDP_IDM_URL]}/authorize/scim/v2/MFAPolicies"
        req_body = {
            "schemas": ["urn:ietf:params:scim:schemas:core:philips:hsdp:2.0:MFAPolicy"],
            "name": f"MFAPolicy-{self.customer_name}",
            "description": f"MFAPolicy-{self.customer_name}",
            "types": [
                    "SERVER_OTP_EMAIL"
            ],
            "resource": {
                "type": "Organization",
                "value": self.request["org_hsdp_id"]
            }
        }
        req_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {self.service_token}", API_VERSION: "2", ACCEPT: APPLICATION_JSON}

        return req_url, req_body, req_headers

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._profile_configs:
            try:
                prepare_and_post_audit(event_type="Add-update MFA Org Policy", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self.service_user_uuid,
                                       org_id=self.customer_org_uuid, token=self.service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def add_mfa_policy(self, url, body, header):
        response_status = 500
        response_data = False
        try:
            response = requests.post(url, data=json.dumps(body), headers=header)
            if response.status_code == 201:
                LOG.info("Mfa post operation is successful")
                self.safe_audit(event_subtype="Add mfaOrgPolicy", action="C", outcome=0, code="Add mfaOrgPolicy post operation", value="Success")
                response_data = response.json()[ID]
                response_status = 201
            elif response.status_code == 409 and response.json()["scimType"] == 'conflict':
                LOG.warning(f"Failed to add mfa org policy with response:{response.json()}")
                response_status = 409
            else:
                LOG.warning(f"Failed to add mfa org policy with response:{response.json()}")
                self.safe_audit(event_subtype="Add mfaOrgPolicy", action="C", outcome=8, code="Add mfaOrgPolicy post operation", value="failure")
        except Exception as ex:
            LOG.error(f"Failed to add mfa org policy:{ex}")
        return response_data, response_status

    def update_mfa_policy(self, url, body, header):
        response_status = 500
        response_data = False
        mfa_org_policy_id = self.customer_vault_values[DATA][MFA_ORG_POLICY_ID]
        try:
            response = requests.get(f"{url}/{mfa_org_policy_id}", data=json.dumps(body), headers=header)
            if response.status_code == 200:
                header[IF_MATCH] = response.json()["meta"]["version"]
                body["active"] = True if self.request["is_checked"].lower() == "True".lower() else False
                response = requests.put(f"{url}/{mfa_org_policy_id}", data=json.dumps(body), headers=header)
                if response.status_code == 200:
                    LOG.info("MFA org policy status is updated for current customer")
                    self.safe_audit(event_subtype="Update mfaOrgPolicy", action="U", outcome=0, code="Update mfaOrgPolicy operation", value="Success")
                    response_data = response.json()[ID]
                    response_status = 200
                else:
                    LOG.warning(f"MFA org policy is not updated with response:{response.json()}")
                    self.safe_audit(event_subtype="Update mfaOrgPolicy", action="U", outcome=8, code="Update mfaOrgPolicy operation", value="Success")
            else:
                LOG.warn(f"Failed to fetch version number from mfa api:{response.json()}")
        except Exception as ex:
            LOG.error(f"Failed to add/update mfa api:{ex}")
        return response_data, response_status
