"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from gql import gql

""" Overwatch schema queries """
check_if_customer_exists_in_db = gql("""
query check_if_customer_already_present($customer_name: String!) {
  rocc_overwatch_customers(where: {name: {_eq: $customer_name}}) {
    id
    name
  }
}
""")

fetch_customer_id_from_raw_upload = gql("""
query fetch_customer_id_from_raw_upload($record_id:uuid!) {
  rocc_overwatch_customers(where: {rawUploadDataByCustomerId: {id: {_eq: $record_id}}}) {
      id
      name
  }
}
""")

fetch_infra_configs = gql("""
query fetch_infra_configs($customer_id: Int!) {
  rocc_overwatch_infrastructure_configurations(where: {customer_id: {_eq: $customer_id}}) {
    id
    infra_configs
    profile
    proxy_url
  }
}
""")

check_if_job_exists_in_db = gql("""
query check_if_job_exists($job_name: String!) {
  job: rocc_overwatch_service_jobs(where: {job_name: {_eq: $job_name}}) {
    id
    job_name
  }
}
""")

check_if_task_exists_in_db = gql("""
query check_if_task_exists($task_name: String!) {
  task: rocc_overwatch_service_tasks(where: {task_name: {_eq: $task_name}}) {
    id
    task_name
  }
}
""")

fetch_task_id_and_order_by_name = gql("""
query fetch_task_id_and_order_from_name($task_name: String!, $job_name: String!) {
  task: rocc_overwatch_service_tasks(where: {task_name: {_eq: $task_name}, serviceJobByServiceJobId: {job_name: {_eq: $job_name}}}) {
    id
    task_name
    execution_order
  }
}
""")

fetch_raw_details_from_transaction_id = gql("""
query fetch_raw_details_from_transaction_id($transaction_id: uuid!) {
  raw_data: rocc_overwatch_raw_upload_data(where: {serviceJobTransactionsByRawUploadId: {id: {_eq: $transaction_id}}}) {
    id
    customer_id
    data
  }
}
""")

get_transaction_details_by_tx_id_from_db_query = gql("""
query rocc_overwatch_service_job_transactions($transaction_id: uuid!){
    rocc_overwatch_service_job_transactions(where: {id: {_eq: $transaction_id}, _and: {status:{_neq: "COMPLETED"}}}) {
            id
            current_job_id
            entity_id
            current_task_id
            entity_type
            operation_type
            status
            transaction_data
    }
}
""")

fetch_active_transactions_for_customer = gql("""
query fetch_ongoing_transactions_for_customer($customer_id: Int!) {
  rocc_overwatch_service_job_transactions(where:
    {_and: [
    	{entity_type: {_eq: "CUSTOMER"}},
    	{entity_id: {_eq: $customer_id}},
      {status: {_eq: "INIT"}}
    ]}) {
    id
  }
}
""")

fetch_all_transactions_for_customer = gql("""
query fetch_all_transactions_for_customer($customer_id: Int!) {
  rocc_overwatch_service_job_transactions(where:
    {_and: [
    	{entity_type: {_eq: "CUSTOMER"}},
    	{entity_id: {_eq: $customer_id}}
    ]}) {
    id
  }
}
""")


fetch_tasks_for_jobid = gql("""
query rocc_overwatch_service_tasks($job_id: Int!) {
  rocc_overwatch_service_tasks(where: {job_id: {_eq: $job_id}}) {
    id
    task_name
    execution_order
  }
}
""")

###########################

""" Common ROCC queries """
check_if_organization_present = gql("""
query check_if_organization_present($customer_identifier: String) {
  rocc_organizations(where: {org_identifier: {_ilike: $customer_identifier}}) {
    id
  }
}
""")

fetch_all_customers = gql("""
query fetch_all_customers {
  rocc_organizations {
    id
    org_identifier
    org_hsdp_uuid
  }
}
""")

fetch_customer_name_from_db_id = gql("""
query fetch_customer_name_from_db_id($org_db_id: Int!) {
  rocc_organizations: rocc_organizations(where: {id: {_eq: $org_db_id}}){
    id
    org_identifier
  }
}
""")

fetch_clinical_role_id_from_name = gql("""
query get_clinical_role($role: String) {
  rocc_rocc_application_roles(where: {role: {_eq: $role}}){
    id
  }
}
""")


fetch_contact_type_id_from_rocc_contact_types = gql("""
query fetch_contact_type_id_from_rocc_contact_types($contact_type: String!) {
  rocc_rocc_contact_types(where: {contact_type: {_eq: $contact_type}}) {
    id
  }
}
""")


check_if_unique_ids_exist = gql("""
query check_if_users_exist($unique_ids: [String!]!) {
  rocc_users (where: {unique_identity: {_in: $unique_ids}}) {
    id
    unique_identity
  }
}
""")

check_if_modality_present = gql("""
query check_if_modality_present($modality: String!) {
  rocc_modality_types(where: {modality: {_eq: $modality}}) {
    id
    modality
  }
}
""")

fetch_required_info_for_user_creation = gql("""
query fetch_required_info_for_user_creation($roles: [String!], $sites: [String!], $modalities: [String!], $resources: [String!]) {
  rocc_rocc_application_roles(where: {role: {_in: $roles}}) {
    application_role_id: id
  }
  rocc_sites(where: {identifier: {_in: $sites}}) {
    site_id: id
  }
  rocc_modality_types(where: {modality: {_in: $modalities}}) {
    modality_id: id
  }
  rocc_scanner_resources(where: {identifier: {_in: $resources}}) {
    scanner_resource_id: id
  }
}
""")


check_if_scanner_resources_present = gql("""
query check_if_scanner_resources_present($identifier: String!, $org_db_id: Int!) {
  rocc_scanner_resources(where: {_and: [{identifier: {_eq: $identifier}}, {organization_id: {_eq: $org_db_id}}]}) {
    id
    identifier
    site_id
  }
}
""")


get_tablet_for_scanner = gql("""
query get_tablet_for_scanner($scanner_resource_id: Int!) {
  rocc_rocc_tablets(where: {scanner_resource_id: {_eq: $scanner_resource_id}}) {
    id
    device_hsdp_uuid
  }
}
""")

check_if_scanner_transmitter_mapping_present = gql("""
query check_if_scanner_transmitter_mapping_present($transmitter_connection_name: String!, $scanner_resource_id: Int!) {
  rocc_rocc_transmitter_mappings(where: {_and: [{transmitter_connection_name: {_eq: $transmitter_connection_name}}, {scanner_resource_id: {_eq: $scanner_resource_id}}]}) {
    id
    transmitter_connection_name
    scanner_resource_id
  }
}
""")

check_if_transmitter_is_present = gql("""
query check_if_transmitter_is_present($transmitter_ip: String!, $kvm_config_id: Int!, $transmitter_name: String) {
  rocc_rocc_transmitters(where: {_and: [
    {transmitter_ip: {_eq: $transmitter_ip}},
    {kvm_configuration_id: {_eq: $kvm_config_id}},
    {transmitter_name: {_eq: $transmitter_name}}
  ]}) {
    id
  }
}
""")

fetch_site_id_from_site_short_name = gql("""
query fetch_site_id_from_site_short_name($identifier: String!) {
  rocc_sites(where: {identifier: {_eq: $identifier}}){
    id
    name
    identifier
  }
}
""")

verify_if_receiver_present = gql("""
query check_if_data_exists($seat_name: String!,$organization_id:Int!) {
  rocc_rocc_command_centre_seats(where: {_and: [
    {seat_name: {_eq: $seat_name}},
    {organization_id:{_eq:$organization_id}}
  ]}) {
    id
    seat_name
  }
}
""")

verify_if_cc_data_exists = gql("""
query check_if_cc_data_exists($seat_name: String!,$organization_id:Int!, $receiverName: String!) {
  rocc_rocc_command_centre_seats(where: {_and: [
    {seat_name: {_eq: $seat_name}},
    {organization_id:{_eq:$organization_id}}
  ]}) {
    id
    seat_name
  }
  rocc_rocc_receivers(where: {receiver_connection_name: {_eq: $receiverName}}) {
    id
  }
  rocc_rocc_command_centre_receiver_mappings(where :{_and:[
    {rocc_command_centre_seat: {seat_name: {_eq: $seat_name}}},
    {rocc_receiver: {receiver_connection_name: {_eq: $receiverName}}}
  ]}) {
    id
    receiver_id
  }
}
""")

fetch_cc_details = gql("""
query fetch_cc_details($cc_id: Int!){
  rocc_rocc_command_centre_seats(where: {id:{_eq:$cc_id}}){
    id
    seat_name
    seat_info
    rocc_command_centre_receiver_mappings{
      rocc_receiver{
        id
        receiver_ip
        monitor_name
        receiver_connection_name
      }
    }
  }
}
""")

fetch_user_details_with_email = gql("""
query fetch_user_details_with_email($email_id: String!) {
  rocc_users(where:{user_email_id: {_eq: $email_id}}) {
    id
    applicationRoleMappingsByUserId {
      id
      rocc_application_role {
        id
        role
      }
    }
  }
}
""")

fetch_fse_roles_and_ids = gql("""
query fetch_fse_roles_id{
  rocc_rocc_application_roles(where: {_or:[{role: {_ilike: "fse%"}},{role:{_ilike:"release%"}},{role:{_ilike:"cpp%"}}]}) {
    id
    role
  }
}
""")

fetch_kvm_user_details = gql("""
query fetch_kvm_user_details($user_db_id: Int!, $org_db_id: Int!) {
  rocc_users(where: {_and: [
    {id: {_eq: $user_db_id}},
    {organizationMappingsByUserId: {organization_id: {_eq: $org_db_id}}}
  ]}) {
    id
    kvm_user_name
  }
}
""")

###########################

""" Validation Queries """
get_sites_from_db_query = gql("""
query get_sites_from_db {
  rocc_sites {
    identifier
  }
}
""")

get_resources_from_db_query = gql("""
query get_resources_from_db {
  rocc_scanner_resources {
    identifier
  }
}
""")

get_modalities_from_db_query = gql("""
query get_modalities_from_db {
  rocc_modality_types {
    modality
  }
}
""")

check_if_site_details_exists = gql("""
query check_if_site_details_exists($address: String!, $city: String!, $state_or_province: String!, $postal_code: String!, $frontdesk_no: String!, $scheduler_no: String!, $name: String!, $site_identifier: String!) {
  rocc_sites(where: {_and: [{identifier: {_eq: $site_identifier}}, {name: {_eq: $name}}, {address: {_eq: $address}}, {city: {_eq: $city}}, {state_or_province: {_eq: $state_or_province}}, {postal_code: {_eq: $postal_code}}, {rocc_site_contacts: {primary_contact_number: {_in: [$frontdesk_no, $scheduler_no]}}}]}) {
    id
    name
    address
    city
    state_or_province
    postal_code
    organization_id
    rocc_site_contacts {
      contact_name
      contact_type_id
    }
  }
}

""")

verify_if_cc_detail_present = gql("""
query verify_command_center_data($seat_name: String!, $seat_info: String!, $rx_name: String!, $rx_ip: String!) {
  rocc_rocc_command_centre_seats(where: {_and: [
    {seat_name: {_eq: $seat_name}},
    {seat_info: {_eq: $seat_info}},
    {rocc_command_centre_receiver_mappings: {rocc_receiver: {receiver_connection_name: {_eq: $rx_name}}}},
    {rocc_command_centre_receiver_mappings: {rocc_receiver: {receiver_ip: {_eq: $rx_ip}}}}
  ]}) {
    id
  }
}
""")

verify_eula_data = gql("""
query check_terms_of_service($data_blob:String!, $document_type:String!){
  rocc_rocc_organization_documents(where:{_and:[{data_blob:{_eq:$data_blob}},{web_consent_document_name:{_eq:$document_type}}]}){
    id
    organization_id
    web_consent_document_name
  }
}
""")

verify_if_user_detail_exists = gql("""
query check_users($first_name: String!, $last_name: String!, $email_id: String!, $site_identifiers: [String!]!, $role: [String!]!, $modalities: [String!]!, $phone: String!) {
  rocc_users(where: {_and: [
    {first_name: {_eq: $first_name}},
    {last_name: {_eq: $last_name}},
    {unique_identity: {_eq: $email_id}},
    {user_email_id: {_eq: $email_id}},
    {user_primary_phone: {_eq: $phone}}
    {siteMappingsByUserId: {site: {identifier: {_in: $site_identifiers}}}},
    {applicationRoleMappingsByUserId: {rocc_application_role: {role: {_in: $role}}}},
    {modalityTypeMappingsByUserId: {modality_type: {modality: {_in: $modalities}}}}
  ]}) {
    id
  }
}
""")

verify_if_rooms_detail_exist = gql("""
query verify_if_room_detail_exists($site: String!, $resource: String!, $manufacturer: String!, $software_version: String!, $os_type: String!, $os_version: String!, $model: String!, $phone: String!, $tx_name: [String!]!, $tx_type: [String!]!, $serial_no: String!, $ae_title: String!, $notes: String!) {
  rocc_scanner_resources(where: {_and: [
    {site: {identifier: {_eq: $site}}},
    {identifier: {_eq: $resource}},
    {manufacturer: {_eq: $manufacturer}},
    {scanner_software_version: {_eq: $software_version}},
    {scanner_os_type: {_eq: $os_type}},
    {scanner_os_version: {_eq: $os_version}},
    {model: {_eq: $model}},
    {primary_phone: {_eq: $phone}},
    {rocc_transmitter_mappings: {transmitter_connection_name: {_in: $tx_name}}},
    {rocc_transmitter_mappings: {transmitter_connection_type: {_in: $tx_type}}},
    {serial_number: {_eq: $serial_no}},
    {dicom_ae_title: {_eq: $ae_title}},
    {notes: {_eq: $notes}}
]}) {
    id
  }
}

""")

check_if_kvm_data_exists = gql("""
query kvm_configuration_data($org_id: Int!, $boxilla_ip: String!, $boxilla_user_name: String!, $boxilla_rest_user_name: String!) {
  rocc_rocc_kvm_configurations(where: {_and: [
    {organization_id: {_eq: $org_id}},
    {boxilla_ip: {_eq: $boxilla_ip}},
    {boxilla_user_name: {_eq: $boxilla_user_name}},
    {rest_user_name: {_eq: $boxilla_rest_user_name}}
  ]}) {
    id
  }
}
""")

get_scanner_details_by_site_and_org_id = gql("""
query get_scanner_details_by_site_and_org_id($resource_id: Int!, $site_id: Int!, $org_hsdp_uuid: String!) {
  rocc_scanner_resources(where: {_and: [
    {id: {_eq: $resource_id}},
    {site_id: {_eq: $site_id}},
    {organization: {org_hsdp_uuid: {_eq: $org_hsdp_uuid}}}
  ]}) {
    id
    organization_id
    dicom_ae_title
    manufacturer
    model
    serial_number
    notes
    location
    primary_phone
    secondary_phone
    scanner_os_type
    scanner_os_version
    scanner_software_version
    additional_attributes
    modality_connection
    rocc_transmitter_mappings {
      transmitter_connection_name
      transmitter_connection_type
      created_at
      created_by
      modified_at
      modified_by
      transmitter {
        kvm_configuration_id
        transmitter_name
        transmitter_ip
      }
    }
  }
}
""")

query_check_if_scanner_exists = gql("""
query check_if_scanner_exists($identifier: String!, $site_id: Int!) {
    rocc_scanner_resources(where: {_and: [ {identifier: {_eq: $identifier}}
    {site_id: {_eq: $site_id}}
    ]}) {
        id
    }
}
""")

query_get_org_id_by_uuid = gql("""
query get_org_id_by_uuid($org_hsdp_uuid: String!) {
  rocc_organizations(where: {org_hsdp_uuid: {_eq: $org_hsdp_uuid}}) {
    id
  }
}
""")

query_get_kvm_configuration_id_by_org_db_id = gql("""
query get_kvm_configuration_id_by_org_db_id($org_db_id: Int!) {
  rocc_rocc_kvm_configurations(where: {organization_id: {_eq: $org_db_id}}) {
    id
  }
}
""")

query_get_scanner_details_by_scanner_identifier = gql("""
query query_get_scanner_id_by_identifier($identifier: String) {
  rocc_scanner_resources(where: {identifier: {_eq: $identifier}}) {
    id
    identifier
    site_id
    rocc_rocc_tablets: rocc_tablets {
      device_hsdp_uuid
    }
    rocc_organizations: organization {
      id
      org_hsdp_uuid
      org_identifier
      rocc_rocc_kvm_configurations: rocc_kvm_configurations {
        id
        boxilla_ip
      }
      rocc_rocc_command_centre_seats: rocc_command_centre_seats {
        id
        rocc_rocc_command_centre_receiver_mappings: rocc_command_centre_receiver_mappings {
          id
          rocc_rocc_receivers: rocc_receiver {
            id
            receiver_ip
          }
        }
      }
    }
  }
}
""")

check_if_transaction_exists_for_seat_receiver = gql("""
query fetch_kvm_transactions($seat_name: String!, $rx_names: [String!]!, $org_id: Int!) {
  rocc_rocc_kvm_transactions_aggregate(where: {_and: [{organization_id: {_eq: $org_id}}, {_or: [{seat_name: {_eq: $seat_name}}, {rc_name: {_in: $rx_names}}]}]}) {
    aggregate {
      count
    }
  }
}
""")

fetch_organization_mappings_by_user = gql("""
query fetch_all_organization_mappings_by_user($user_id: Int!) {
  rocc_rocc_user_organization_mappings(where: {user_id: {_eq: $user_id}}) {
    id
    organization_id
  }
}

""")
check_if_fse_is_assigned_to_org = gql("""
query check_if_fse_is_assigned_to_org($org_db_id: Int!, $fse_user_db_id: Int!) {
  rocc_rocc_user_organization_mappings_aggregate(where: {_and: [{organization_id: {_eq: $org_db_id}}, {user_id: {_eq: $fse_user_db_id}}]}) {
    aggregate {
      count
    }
  }
}
""")
fetch_user_db_id_from_uuid = gql("""
query fetch_user_db_id_from_uuid($user_uuid: String!) {
  rocc_users(where: {user_hsdp_uuid: {_eq: $user_uuid}}) {
    id
    first_name
    last_name
    user_email_id
    applicationRoleMappingsByUserId {
      id
      rocc_application_role {
        id
        role
      }
    }
  }
}
""")

###########################
