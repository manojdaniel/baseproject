"""
 Created on Thurs June 02 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask_restful import Resource, reqparse
from flask import request, g
from src.services.fse_user_services import FseUserService
from src.loggers.log import create_logger
from src.utility.utility import construct_negative_response
from src.utility.semver import parse_version
from src.exceptions.RoccException import RoccException
from src.constants.http_status_string import http_status_string_registry
from src.constants.constants import API_VERSION, APPLICATION_JSON, AUTHORIZATION, CONTENT_TYPE,  HELP_MESSAGE, APPEND, EMAIL_ID_KEY, ORG_CTXT_HEADER, PHILIPS_ROCC_URI


LOG = create_logger("FseUser controller")


class FseUser(Resource):
    fu_parser_add_fse = reqparse.RequestParser()
    fu_parser_add_fse.add_argument("email_id", type=str, required=True, help=HELP_MESSAGE)
    fu_parser_add_fse.add_argument("roles", type=str, required=True, help=HELP_MESSAGE, action=APPEND)
    fu_parser_add_fse.add_argument("first_name", type=str, required=True, help=HELP_MESSAGE)
    fu_parser_add_fse.add_argument("last_name", type=str, required=True, help=HELP_MESSAGE)
    fu_parser_add_fse.add_argument("allowed_customers", type=str, required=False, help=HELP_MESSAGE, action=APPEND)

    fu_parser_edit_fse = reqparse.RequestParser()
    fu_parser_edit_fse.add_argument("roles", type=str, required=True, help=HELP_MESSAGE, action=APPEND)
    fu_parser_edit_fse.add_argument("allowed_customers", type=str, required=False, help=HELP_MESSAGE, action=APPEND)

    def post(self):

        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400

        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            body = self.fu_parser_add_fse.parse_args()
            if body["allowed_customers"] is None:
                body["allowed_customers"] = []
            if body[EMAIL_ID_KEY] is not None and isinstance(body[EMAIL_ID_KEY], str):
                body[EMAIL_ID_KEY] = body[EMAIL_ID_KEY].lower()
            fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                              service_user_token=user_token)
            response = fse_user_service.add_fse_user(fse_user=body)
            return response, response["status"]

        except RoccException as ex:
            return construct_negative_response(code=http_status_string_registry[ex.status_code],
                                               title=ex.title,
                                               error_message=ex.payload,
                                               additional_info=ex.additional_info), ex.status_code
        except Exception:
            return construct_negative_response(code=500,
                                               title="Add fse user failed",
                                               error_message="Failed to add fse user"), 500

    def put(self, user_uuid):
        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400

        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400

        try:
            body = self.fu_parser_edit_fse.parse_args()
            body["fse_user_hsdp_uuid"] = user_uuid
            if body["allowed_customers"] is None:
                body["allowed_customers"] = []
            LOG.info(f"parsing arg {body}")
            fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                              service_user_token=user_token)
            response = fse_user_service.edit_fse_user(fse_user=body)
            return response, response["status"]

        except RoccException as ex:
            return construct_negative_response(code=http_status_string_registry[ex.status_code],
                                               title=ex.title,
                                               error_message=ex.payload,
                                               additional_info=ex.additional_info), ex.status_code
        except Exception:
            return construct_negative_response(code=500,
                                               title="Edit fse user failed",
                                               error_message="Failed to edit fse user"), 500

    def delete(self, user_id):
        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        LOG.info("*****Deactivate fse user****")
        fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                          service_user_token=user_token)
        url = f"{PHILIPS_ROCC_URI}/usermgmt/Users/{user_id}"
        req_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"{user_token}",
                       ORG_CTXT_HEADER: str({"Org-Id": fse_user_service._parent_org_uuid}),
                       "is_customer_specific": "false"}
        response_data, response_code = fse_user_service.delete_fse_user(url=url, header=req_headers)
        if not response_data:
            raise RoccException(status_code=response_code, payload=str("Failed to deactivate Fse user"))
        return response_data, response_code


class ReInviteFseUser(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("action", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("locale", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("userId", type=int, required=True, help=HELP_MESSAGE)
    parser.add_argument("isfseUserCheck", type=bool, required=True, help=HELP_MESSAGE)

    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        request_data = ReInviteFseUser.parser.parse_args()
        fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                          service_user_token=user_token)
        url = f"{PHILIPS_ROCC_URI}/usermgmt/UserActions"
        req_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"{fse_user_service._parent_service_token}", ORG_CTXT_HEADER: str({"Org-Id": fse_user_service._parent_org_uuid})}
        response_data, response_code = fse_user_service.reinvite_fse_user(url=url, body=request_data, header=req_headers)
        if not response_data:
            raise RoccException(status_code=response_code, payload=str("Failed to send email reinvitation to Fse user"))
        return response_data, response_code


class ReactivateFseUser(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("userId", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("uuid", type=str, required=True, help=HELP_MESSAGE)

    activate_parser = reqparse.RequestParser()
    activate_parser.add_argument("email_id", type=str, required=True, help=HELP_MESSAGE)

    def put(self, user_id, uuid):
        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        LOG.info("****Reactivate Fse User*****")
        request_data = ReactivateFseUser.parser.parse_args()
        fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                          service_user_token=user_token)
        url = f"{PHILIPS_ROCC_URI}/usermgmt/Users/reactivate/{user_id}/{uuid}"
        req_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"{fse_user_service._parent_service_token}", ORG_CTXT_HEADER: str({"Org-Id": fse_user_service._parent_org_uuid})}
        response_data, response_code = fse_user_service.reactivate_fse_user(url=url, body=request_data, header=req_headers)
        if not response_data:
            raise RoccException(status_code=response_code, payload=str("Failed to reactivate Fse user"))
        return response_data, response_code

    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            user_token = request.headers[AUTHORIZATION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        LOG.info("****activate Fse User*****")
        request_data = ReactivateFseUser.activate_parser.parse_args()
        fse_user_service = FseUserService(service_user_uuid=g.userdetails,
                                          service_user_token=user_token)
        response_data, response_code = fse_user_service.update_status_fse_user(request_data["email_id"])
        if not response_data:
            raise RoccException(status_code=response_code, payload=str("Failed to update Fse user status"))
        return response_data, response_code
