export const getPerormanceTrend = [
    {
        "plantId": 14,
        "utilization": 0,
        "overdueAlerts": 12,
        "newAlerts": 0,
        "averageResponseTime": 0,
        "datee": "11-1-2022"
    },
    {
        "plantId": 14,
        "utilization": 0,
        "overdueAlerts": 37,
        "newAlerts": 0,
        "averageResponseTime": 0,
        "datee": "12-1-2022"
    },
    {
        "plantId": 14,
        "utilization": 50,
        "overdueAlerts": 1,
        "newAlerts": 1,
        "averageResponseTime": 0,
        "datee": "1-1-2023"
    },
    {
        "plantId": 14,
        "utilization": 100,
        "overdueAlerts": 0,
        "newAlerts": 5,
        "averageResponseTime": 0,
        "datee": "2-1-2023"
    }
]
// export const getAlertStatusAsset = [
//     {
//         "countofAlerts": 56,
//         "state": "Closed"
//     },
//     {
//         "countofAlerts": 35,
//         "state": "Overdue"
//     }
// ]
export const getAlertStatusAsset = [
    {

        "state": "Overdue Investigation",
        "countofAlerts": 35
    },
    {

        "state": "Closed",
        "countofAlerts": 56
    },
    {
        "state": "Under Investigation",
        "countofAlerts": 42
    }
];
export const getStackedBarAsset = [
    { "count": 6, "state": "Overdue", "assetID": "2K-3101" }, { "count": 10, "state": "Overdue", "assetID": "2K-3201" }, { "count": 7, "state": "Overdue", "assetID": "2K-4101" }, { "count": 4, "state": "Overdue", "assetID": "2K-4103" }, { "count": 4, "state": "Overdue", "assetID": "2Y-3001A" }, { "count": 5, "state": "Overdue", "assetID": "2Y-3001B" }, { "count": 1, "state": "Overdue", "assetID": "2Y-3013A" }, { "count": 1, "state": "Overdue", "assetID": "2Y-3013B" }, { "count": 8, "state": "Overdue", "assetID": "2Y-3123" }, { "count": 6, "state": "Overdue", "assetID": "2Y-3223" }, { "count": 16, "state": "Overdue", "assetID": "2Y-3605" }, { "count": 19, "state": "Overdue", "assetID": "2Y-3606" }, { "count": 9, "state": "Overdue", "assetID": "2Y-3607" }, { "count": 13, "state": "Overdue", "assetID": "2Y-3608" }, { "count": 3, "state": "Overdue", "assetID": "2Y-3665" }, { "count": 5, "state": "Overdue", "assetID": "2Y-4123A" }, { "count": 3, "state": "Overdue", "assetID": "2Y-4123B" },
]
export const getStackedBarDepartment = [
    {
        "count": 62,
        "state": "Closed",
        "department": "Digitalization Champion"
    },
    {
        "count": 70,
        "state": "Overdue",
        "department": "Digitalization Champion"
    }
]