import { createSlice } from "@reduxjs/toolkit";
import {
  HOME,
  HOME_ROUTE,
  initialSelectedData,
} from "../../constant/constants";
import moment from "moment";
import { encryptData } from "../../utility/crypto";
import jwt_decode from "jwt-decode";
import { decryptUsingAES256, encryptUsingAES256 } from "../../utility/crypto";

const CommonSlice = createSlice({
  name: "Common",
  initialState: {
    message: "",
    // User Profile Start
    loggedInUserDetails: {},
    loadingLoggedInUserDetails: false,
    // Home Page Start
    regions: [],
    loadingRegions: false,
    assetListByPlant: [],
    loadingGetAssetListByPlantId: false,
    plantAlertSpmt: [],
    loadingplantAlertSpmt: false,
    assetCardPmtByplantId: [],
    loadingAssetCardPmtByplantId: false,
    assetCardPmtByAssetId: [],
    loadingAssetCardPmtByAssetId: false,
    assetStatusPmtByPlantId: [],
    loadingAssetStatusPmtByPlantId: false,
    statusAssetPmtByPlantId: [],
    loadingStatusAssetPmtByPlantId: false,
    setStatusListbyPlantId: [],
    loadingSetStatusListbyPlantId: false,
    heatMapToolTipbyAssetStatus: [],
    loadingHeatMapToolTipbyAssetStatus: false,
    topBarToolTipbyPlantId: [],
    loadingTopBarToolTipbyPlantId: false,
    sensorGroupId: "",
    // Asset Model Start
    assetlistOfAssetModelByplantid: [],
    loadingassetlistOfAssetModelByplantid: false,
    AnomalyModelbyAssetId: [],
    loadinggetAnomalyModelbyAssetId: false,
    FailurepreDictionByAssetId: [],
    loadingFailurepreDictionByAssetId: false,
    GraphicalImageByAssetId: [],
    loadingGraphicalImageByAssetId: false,
    AssetKPIForAssetModel: [],
    loadingAssetKPIForAssetModel: false,
    //PlotScreen
    plotModelDropDown: [],
    loadingPlotModelDropDown: false,
    plotAssetDropDown: [],
    loadingPlotAssetDropDown: false,
    plotSensorDropDown: [],
    loadingPlotSensorDropDown: false,
    plotDeviationData: [],
    loadingPlotDeviationData: false,
    plotStatusData: [],
    loadingPlotStatusData: false,
    plotDeviationModel: [],
    loadingPlotDeviationModel: false,
    plotSensorData: [],
    loadingPlotSensorData: false,
    //AlertStatus
    StatisticsAlertListByPlantId: [],
    loadingStatisticsAlertListByPlantId: false,
    //ASSET TIMELINE Start
    assetHealthIndex: [],
    loadingAssetHealthIndex: false,
    maintenanceHistory: [],
    loadingMaintenanceHistory: false,
    hanaIncident: [],
    loadingHanaIncident: false,
    // Dates
    commonFromDate: "",
    commonToDate: "",
    commonFromDateFormat: "",
    commonToDateFormat: "",

    selectedBreadCrumbDate: "3M",
    breadCrumbDate: "3M",
    breadCrumbDateFormated: "",
    todayDate: "",
    //Live Tracking Start
    livetrackingtable: [],
    loadinglivetrackingtable: false,
    modelstatusdropdown: [],
    loadingmodelstatusdropdown: false,
    //ALERT MANAGEMENT PAGE Start=======
    //MyTasktable
    myTaskTable: [],
    loadingMyTaskTable: false,
    //Reporttable
    reporttable: [],
    loadingreporttable: false,
    //requestLogTable
    requestLogTable: [],
    loadingrequestLogTable: false,
    //utilization report
    utilizationreporttable: [],
    loadingutilizationreporttable: false,
    //Master data report
    masterdatareporttable: [],
    loadingmasterdatareporttable: false,
    // Alert Detail
    alertDetails: [],
    loadingAlertDetails: false,
    alertAttachementDetails: [],
    loadingAlertAttachementDetails: false,
    /*
    Workflow
    */
    workflowAlertDetails: [],
    loadingWorkflowAlertDetails: false,
    workflowRequestLog: [],
    loadingWorkflowRequestLog: false,
    workflowSearchData: [],
    loadingWorkflowSearchData: false,
    workflowAttachementDetails: [],
    loadingWorkflowAttachementDetails: false,
    workflowUserRole: "",
    loadingWorkflowUserRole: false,
    WorkflowStatus: [],
    loadingWorkflowStatus: false,
    //ALERT MANAGEMENT PAGE End===========
    // Alert Dashboard
    loadingAssetPieChart: false,
    assetPieChart: [],
    loadingAssetStackedBar: false,
    assetStackedBar: [],
    loadingDepartementStackedBar: false,
    departementStackedBar: [],
    loadingPerformaceChart: false,
    performaceChart: [],
    //PLANT TIMELINE
    loadingplantTimelineByPlant: false,
    plantTimelineByPlant: [],

    // Header Search
    searchValue: { navigateTo: "", id: "", title: "", identifier: "" },
    loadingGlobalSearch: false,
    globalSearchData: [],
    //Reference table
    referenceTableModelData: [],
    loadingReferenceTableModelData: false,
    referenceOffilineData: [],
    loadingReferenceOffilineData: false,
    //monthwisetable
    loadingplantmodelbasedtabledatabyplant: false,
    plantmodelbasedtabledatabyplant: [],
    //PMCompliance
    loadingpmcompliance: false,
    pmcompliance: [],
    //modelperformancemonthwisebarchart
    loadingplantmonthwisebarchartdata: false,
    plantmonthwisebarchartdata: [],

    //Modelperformance
    loadingmodelalertstatuspiechart: false,
    modelalertstatuspiechart: [],
    loadingmodeltotalalertstatusbyasset: false,
    modeltotalalertstatusbyasset: [],
    loadingmodelalertstatusbydepartmentbyplant: false,
    modelalertstatusbydepartmentbyplant: [],
    modelPerformanceAssetDropdownChangedValue: {},
    //Store current region value
    currRegionValue: "",
    // Dropdowns
    regionDropdownList: [],
    loadingRegionDropdownList: false,
    affiliateDropdownList: [],
    loadingAffiliateDropdownList: false,
    plantDropdownList: [],
    loadingPlantDropdownList: false,
    assetDropdownList: [],
    loadingAssetDropdownList: false,
    modelDropdownList: [],
    loadingModelNameDropdownList: false,
    modelSensorDropdownList: [],
    modelSensorUnTransformedList: [],
    loadingModelSensorDropdownList: false,
    modelStatusDropdownList: [],
    loadingModelStatusDropdownList: false,
    sensorDropdownList: [],
    loadingSensorDropdownList: false,
    // Alert management Droprdown Start
    alertManagementAffiliatesDroprdown: [],
    loadingAlertManagementAffiliatesDroprdown: false,
    alertManagementPlantDroprdown: [],
    loadingAlertManagementPlantDroprdown: false,
    alertManagementAssetIdDroprdown: [],
    loadingAlertManagementAssetIdDroprdown: false,
    alertManagementAlertIdDroprdown: [],
    loadingAlertManagementAlertIdDroprdown: false,
    longLeadActionDropdownList: [],
    loadingLongLeadActionDropdownList: false,
    statusDropdownList: [],
    loadingStatusDropdownList: false,
    currentstageDropdownList: [],
    loadingcurrentstageDropdownList: false,
    // Alert management Droprdown End
    //alertID dropdown 
    alertIDDropdownList: [],
    loadingAlertIDDropdownList: false,
    // all selected values stored in { "value": "2Y-3001A", "label": "2Y-3001A" }
    globalSelecetedRegion: {},
    globalSelecetedAffiliate: {},
    globalSelecetedPlant: {},
    globalSelecetedAsset: {},
    globalSelectedAlertID: {},
    //Dropdowns
    //Asset Alert List
    alertlisttable: [],
    loadingalertlisttable: false,
    alertListTopBarSummary: [],
    loadingAlertListTopBarSummary: false,
    alertlistassetiddropdown: [],
    loadingalertlistassetiddropdown: false,
    alertlistmodelnamedropdown: [],
    loadingalertlistmodelnamedropdown: false,
    alertlistassetmodelstatusdropdown: [],
    loadingalertlistassetmodelstatusdropdown: false,
    //affiliate Page
    affiliateTopBar: [],
    loadingAffiliateTopBar: false,
    affiliateDetails: [],
    loadingAffiliateDetails: false,
    //Home Page
    globalTopBarSummary: [],
    loadingGlobalTopBarSummary: false,
    globalMapSummaryByUserId: [],
    loadingGlobalMapSummaryByUserId: false,
    globalRegionMapSummaryByUserId: [],
    loadingGlobalRegionMapSummaryByUserId: false,
    // Plant Page
    plantTopBar: [],
    loadingPlantTopBar: false,
    plantDetails: [],
    loadingPlantDetails: false,
    //Admin Configuration
    affiliateRollout: [],
    loadingAffiliateRollout: false,
    plantRollout: [],
    loadingPlantRollout: false,
    affiliateRolloutStatus: [],
    loadingAffiliateRolloutStatus: false,
    plantRolloutStatus: [],
    loadingPlantRolloutStatus: false,
    assetModelConfigTableData: [],
    loadingAssetModelConfigTableData: false,
    assetModelConfigTableStatus: [],
    loadingAssetModelConfigTableStatus: false,
    exceptionLogs: [],
    loadingExceptionLogs: false,
    roleListDropdown: [],
    loadingRoleListDropdown: false,
    plantListDropdown: [],
    loadingPlantListDropdown: false,
    affiliateListDropdown: [],
    loadingAffiliateListDropdown: false,
    roleAddMappingStatus: [],
    loadingRoleAddMappingStatus: false,
    roleMappingWorklist: [],
    loadingRoleMappingWorklist: false,
    employeeList: [],
    loadingEmployeeList: false,
    //Asset model config dropdown
    assetModelConfigDropdown: [],
    loadingAssetModelConfigDropdown: false,
    assetModelConfigAffiliateDropdown: [],
    loadingAssetModelConfigAffiliateDropdown: false,
    assetModelConfigPlantDropdown: [],
    loadingAssetModelConfigPlantDropdown: false,
    //Alert Statistics
    plantUtilizationTime: [],
    loadingPlantUtilizationTime: false,
    getFailurePopupData: {},
    refreshPmtPage: false,
    refreshAlertListPage: false,
    refreshMyTaskPage: false,
    /*
     Upload Attachements
     */
    uploadAttachementStatus: [],
    loadingUploadAttachementStatus: false,
    roleUpdateMappingStatus: [],
    loadingRoleUpdateMappingStatus: false,
    plantAlertStatus: [],
    loadinPlantAlertStatus: false,

    plantAlertListStateDropdown: [],
    loadingPlantAlertListStateDropdown: false,
    // OnePlantUser
    onePlantUser: false,
    oneAffiliateUser: false,
    onePlantUserData: {},
    userId: "",
    userRole: "",
    userEmail: "",
    userName: "",
    plantDepartmentStatus: [],
    loadinPlantDepartmentStatus: false,
    plantAlertListDepartmentDropdown: [],
    loadingPlantAlertListDepartmentDropdown: false,
    exceptionLog: [],
    loadingExceptionLog: false,
    //Plant Shutdown
    plantShutdown: [],
    loadingPlantShutdown: false,
    alertBreadCrumbs: [],
    loadingAlertBreadCrumbs: false,
    //Spare parts Table
    sparePartsSAP: [],
    loadingSparePartsSAP: false,
    sparePartsSensor: [],
    loadingSparePartsSensor: false,
    sparePartsSAPDropdown: [],
    loadingSparePartsSAPDropdown: false,
    updateSparePartsSapStatus: [],
    loadingUpdateSparePartsSapStatus: false,
    userProfileActiveOn: "",
    //work flow page
    IBMAlertDetailsByAlertId: [],
    loadingIBMAlertDetailsByAlertId: false,
    consultSomeone: [],
    loadingConsultSomeone: false,
     //Utilization Report Year Month
     alertManagementYearListDroprdown: [],
     loadingAlertManagementYearListDroprdown: false,
     alertManagementMonthListDroprdown: [],
     loadingAlertManagementMonthListDroprdown: false,
  },
  reducers: {
    // User Profile Start
    updateLoggedInUserDetails: (state, action) => {
      state.loggedInUserDetails = action.payload;
    },
    getLoggedInUserDetails: (state, action) => {
      state.loadingLoggedInUserDetails = true;
    },
    getLoggedInUserDetailsSuccess: (state, action) => {
      state.loggedInUserDetails = action.payload;
      state.loadingLoggedInUserDetails = false;
      if (Object.keys(action.payload).length > 0) {
        if (action.payload.statusCode === 200) {
          state.onePlantUser = action.payload.result.onePlantUser
          state.oneAffiliateUser = action.payload.result.oneAffiliateUser
          state.onePlantUserData = action.payload.result
          let serializedState = encryptData(action.payload.result.jwtToken)
          window.sessionStorage.setItem('state', serializedState);
          let decoded: any
          decoded = jwt_decode(action.payload.result.jwtToken);
          if (decoded.hasOwnProperty('Username')) {
            state.userName = decryptUsingAES256(decoded['Username'])
          } else {
            state.userName = decryptUsingAES256(decoded['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'])
          }
          state.userId = decryptUsingAES256(decoded['Id'])
          state.userRole = decoded['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']
          let email = decryptUsingAES256(decoded['EmailId']);
          if (email.includes("^")) {
            state.userEmail = email.split("^")[0]
          } else {
            state.userEmail = email
          }
        }
      }
    },
    getLoggedInUserDetailsFailure: (state, action) => {
      state.loadingLoggedInUserDetails = false;
    },
    //Store current region value
    getCurrRegionValue: (state, action) => {
      state.currRegionValue = action.payload;
    },
    getRegions: (state, action) => {
      state.loadingRegions = true;
    },
    getRegionSuccess: (state, action) => {
      state.regions = action.payload;
      state.loadingRegions = false;
    },
    getRegionsFailure: (state, action) => {
      state.loadingRegions = false;
    },
    getAssetListByPlantId: (state, action) => {
      state.loadingGetAssetListByPlantId = true;
    },
    getAssetListByPlantIdSuccess: (state, action) => {
      state.assetListByPlant = action.payload;
      state.loadingGetAssetListByPlantId = false;
    },
    getAssetListByPlantIdFailure: (state, action) => {
      state.loadingGetAssetListByPlantId = false;
    },
    getPlantAlertSpmt: (state, action) => {
      state.loadingplantAlertSpmt = true;
    },
    getPlantAlertSpmtSuccess: (state, action) => {
      state.plantAlertSpmt = action.payload;
      state.loadingplantAlertSpmt = false;
    },
    getPlantAlertSpmtFailure: (state, action) => {
      state.message = action.payload;
      state.loadingplantAlertSpmt = false;
    },
    getAssetCardPmtByPlantId: (state, action) => {
      state.loadingAssetCardPmtByplantId = true;
    },
    getAssetCardPmtByPlantIdSuccess: (state, action) => {
      state.assetCardPmtByplantId = action.payload;
      state.loadingAssetCardPmtByplantId = false;
    },
    getAssetCardPmtByPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAssetCardPmtByplantId = false;
    },
    getAssetCardPmtByAssetId: (state, action) => {
      state.loadingAssetCardPmtByAssetId = true;
    },
    getAssetCardPmtByAssetIdSuccess: (state, action) => {
      state.assetCardPmtByAssetId = action.payload;
      state.loadingAssetCardPmtByAssetId = false;
    },
    getAssetCardPmtByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAssetCardPmtByAssetId = false;
    },
    getAssetStatusPmtByPlantId: (state, action) => {
      state.loadingAssetStatusPmtByPlantId = true;
    },
    getAssetStatusPmtByPlantIdSuccess: (state, action) => {
      state.assetStatusPmtByPlantId = action.payload;
      state.loadingAssetStatusPmtByPlantId = false;
    },
    getAssetStatusPmtByPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAssetStatusPmtByPlantId = false;
    },
    getStatusAssetPmtByPlantId: (state, action) => {
      state.loadingStatusAssetPmtByPlantId = true;
    },
    getStatusAssetPmtByPlantIdSuccess: (state, action) => {
      state.statusAssetPmtByPlantId = action.payload;
      state.loadingStatusAssetPmtByPlantId = false;
    },
    getStatusAssetPmtByPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingStatusAssetPmtByPlantId = false;
    },
    getssetStatusListbyPlantId: (state, action) => {
      state.loadingSetStatusListbyPlantId = true;
    },
    getssetStatusListbyPlantIdSuccess: (state, action) => {
      state.setStatusListbyPlantId = action.payload;
      state.loadingSetStatusListbyPlantId = false;
    },
    getssetStatusListbyPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingSetStatusListbyPlantId = false;
    },
    getHeatMapToolTipbyAssetStatus: (state, action) => {
      state.heatMapToolTipbyAssetStatus = [];
      state.loadingHeatMapToolTipbyAssetStatus = true;
    },
    getHeatMapToolTipbyAssetStatusSuccess: (state, action) => {
      state.heatMapToolTipbyAssetStatus = action.payload;
      state.loadingHeatMapToolTipbyAssetStatus = false;
    },
    getHeatMapToolTipbyAssetStatusFailure: (state, action) => {
      state.message = action.payload;
      state.loadingHeatMapToolTipbyAssetStatus = false;
    },
    getHeatMapToolTipbyAssetStatusEmpty: (state, action) => {
      state.heatMapToolTipbyAssetStatus = [];
    },
    getTopBarToolTipbyPlantId: (state, action) => {
      state.loadingTopBarToolTipbyPlantId = true;
    },
    getTopBarToolTipbyPlantIdSuccess: (state, action) => {
      state.topBarToolTipbyPlantId = action.payload;
      state.loadingTopBarToolTipbyPlantId = false;
    },
    getTopBarToolTipbyPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingTopBarToolTipbyPlantId = false;
    },
    // Asset Model Start
    getassetlistOfAssetModelByplantid: (state, action) => {
      state.loadingassetlistOfAssetModelByplantid = true;
    },
    getassetlistOfAssetModelByplantidSuccess: (state, action) => {
      state.assetlistOfAssetModelByplantid = action.payload;
      state.loadingassetlistOfAssetModelByplantid = false;
    },
    getassetlistOfAssetModelByplantidFailure: (state, action) => {
      state.message = action.payload;
      state.loadingassetlistOfAssetModelByplantid = false;
    },
    getAnomalyModelbyAssetId: (state, action) => {
      state.loadinggetAnomalyModelbyAssetId = true;
    },
    getAnomalyModelbyAssetIdSuccess: (state, action) => {
      state.AnomalyModelbyAssetId = action.payload;
      state.loadinggetAnomalyModelbyAssetId = false;
    },
    getAnomalyModelbyAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadinggetAnomalyModelbyAssetId = false;
    },
    getFailurepreDictionByAssetId: (state, action) => {
      state.loadingFailurepreDictionByAssetId = true;
    },
    getFailurepreDictionByAssetIdSuccess: (state, action) => {
      state.FailurepreDictionByAssetId = action.payload;
      state.loadingFailurepreDictionByAssetId = false;
    },
    getFailurepreDictionByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingFailurepreDictionByAssetId = false;
    },
    getGraphicalImageByAssetId: (state, action) => {
      state.loadingGraphicalImageByAssetId = true;
    },
    getGraphicalImageByAssetIdSuccess: (state, action) => {
      state.GraphicalImageByAssetId = action.payload;
      state.loadingGraphicalImageByAssetId = false;
    },
    getGraphicalImageByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingGraphicalImageByAssetId = false;
    },
    getAssetKPI: (state, action) => {
      state.loadingAssetKPIForAssetModel = true;
    },
    getAssetKPISuccess: (state, action) => {
      state.AssetKPIForAssetModel = action.payload;
      state.loadingAssetKPIForAssetModel = false;
    },
    getAssetKPIFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAssetKPIForAssetModel = false;
    },
    getSensorGroupId: (state, action) => {
      state.sensorGroupId = action.payload;
    },
    // Plot Screen
    getPlotModelDropDown: (state, action) => {
      state.loadingPlotModelDropDown = true;
    },
    getPlotModelDropDownSuccess: (state, action) => {
      state.plotModelDropDown = action.payload;
      state.loadingPlotModelDropDown = false;
    },
    getPlotModelDropDownFailure: (state, action) => {
      state.loadingPlotModelDropDown = false;
    },
    getPlotAssetDropDown: (state, action) => {
      state.loadingPlotAssetDropDown = true;
    },
    getPlotAssetDropDownSuccess: (state, action) => {
      state.plotAssetDropDown = action.payload;
      state.loadingPlotAssetDropDown = false;
    },
    getPlotAssetDropDownFailure: (state, action) => {
      state.loadingPlotAssetDropDown = false;
    },
    getPlotSensorDropDown: (state, action) => {
      state.loadingPlotSensorDropDown = true;
    },
    getPlotSensorDropDownSuccess: (state, action) => {
      state.plotSensorDropDown = action.payload;
      state.loadingPlotSensorDropDown = false;
    },
    getPlotSensorDropDownFailure: (state, action) => {
      state.loadingPlotSensorDropDown = false;
    },
    getPlotDeviationData: (state, action) => {
      state.plotDeviationData = [];
      state.loadingPlotDeviationData = true;
    },
    getPlotDeviationDataSuccess: (state, action) => {
      state.plotDeviationData = action.payload;
      state.loadingPlotDeviationData = false;
    },
    getPlotDeviationDataFailure: (state, action) => {
      state.loadingPlotDeviationData = false;
    },
    getPlotStatusData: (state, action) => {
      state.loadingPlotStatusData = true;
    },
    getPlotStatusDataSuccess: (state, action) => {
      state.plotStatusData = action.payload;
      state.loadingPlotStatusData = false;
    },
    getPlotStatusDataFailure: (state, action) => {
      state.loadingPlotStatusData = false;
    },
    getPlotDeviationModel: (state, action) => {
      state.loadingPlotDeviationModel = true;
    },
    getPlotDeviationModelSuccess: (state, action) => {
      state.plotDeviationModel = action.payload;
      state.loadingPlotDeviationModel = false;
    },
    getPlotDeviationModelFailure: (state, action) => {
      state.loadingPlotDeviationModel = false;
    },
    getPlotSensorData: (state, action) => {
      state.loadingPlotSensorData = true;
    },
    getPlotSensorDataSuccess: (state, action) => {
      state.plotSensorData = action.payload;
      state.loadingPlotSensorData = false;
    },
    getPlotSensorDataFailure: (state, action) => {
      state.loadingPlotSensorData = false;
    },
    // Plot Screen Ends
    // Date
    getCommonFromDate: (state, action) => {

      let date = moment(action.payload).format("YYYY-MM-DD");
      state.commonFromDate = action.payload;
      state.commonFromDateFormat = date;
    },
    getCommonToDate: (state, action) => {

      let date = moment(action.payload).format("YYYY-MM-DD");
      state.commonToDate = action.payload;
      state.commonToDateFormat = date;
    },
    getBreadCrumbDate: (state, action) => {
      let date = moment(action.payload.updatedDate).format("YYYY-MM-DD");

      (state.selectedBreadCrumbDate = action.payload.id),
        (state.breadCrumbDate = action.payload.updatedDate),
        (state.breadCrumbDateFormated = date);
    },
    getTodayDate: (state, action) => {
      if (action.payload === "") {
        let date = moment(action.payload).format("MMM-DD - HH:mm");
        state.todayDate = "";
      } else {
        let date = moment(action.payload).format("MMM-DD - HH:mm");
        state.todayDate = date;
      }
    },
    //ASSET TIMELINE Start
    getAssetHealthIndexByAssetId: (state, action) => {
      state.loadingAssetHealthIndex = true;
    },
    getAssetHealthIndexByAssetIdSuccess: (state, action) => {
      state.assetHealthIndex = action.payload;
      state.loadingAssetHealthIndex = false;
    },
    getAssetHealthIndexByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAssetHealthIndex = false;
    },
    getMaintenanceHistoryByAssetId: (state, action) => {
      state.loadingMaintenanceHistory = true;
    },
    getMaintenanceHistoryByAssetIdSuccess: (state, action) => {
      state.maintenanceHistory = action.payload;
      state.loadingMaintenanceHistory = false;
    },
    getMaintenanceHistoryByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingMaintenanceHistory = false;
    },
    getHanaIncidentByAssetId: (state, action) => {
      state.loadingHanaIncident = true;
    },
    getHanaIncidentByAssetIdSuccess: (state, action) => {
      state.hanaIncident = action.payload;
      state.loadingHanaIncident = false;
    },
    getHanaIncidentByAssetIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingHanaIncident = false;
    },

    //AlertStatus

    getAlertStatisticsAlertListByPlantId: (state, action) => {
      state.loadingStatisticsAlertListByPlantId = true;
    },
    getAlertStatisticsAlertListByPlantIdSuccess: (state, action) => {
      state.StatisticsAlertListByPlantId = action.payload;
      state.loadingStatisticsAlertListByPlantId = false;
    },
    getAlertStatisticsAlertListByPlantIdFailure: (state, action) => {
      state.message = action.payload;
      state.loadingStatisticsAlertListByPlantId = false;
    },
    //ALERT MANAGEMENT PAGE Start=======
    //mytask
    getMyTaskTable: (state, action) => {
      state.loadingMyTaskTable = true;
    },
    getMyTaskTableSuccess: (state, action) => {
      state.myTaskTable = action.payload;
      state.loadingMyTaskTable = false;
    },
    getMyTaskTableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingMyTaskTable = false;
    },
    //reporttable
    getreporttable: (state, action) => {
      state.loadingreporttable = true;
    },
    getreporttableSuccess: (state, action) => {
      state.reporttable = action.payload;
      state.loadingreporttable = false;
    },
    getreporttableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingreporttable = false;
    },
    //utilizationreport table
    getutilizationreporttable: (state, action) => {
      state.loadingutilizationreporttable = true;
    },
    getutilizationreporttableSuccess: (state, action) => {
      state.utilizationreporttable = action.payload;
      state.loadingutilizationreporttable = false;
    },
    getutilizationreporttableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingutilizationreporttable = false;
    },
    // Master Data report table -
    getmasterdatareporttable: (state, action) => {
      state.loadingmasterdatareporttable = true;
    },
    getmasterdatareporttableSuccess: (state, action) => {
      state.masterdatareporttable = action.payload;
      state.loadingmasterdatareporttable = false;
    },
    getmasterdatareporttableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingmasterdatareporttable = false;
    },
    //Alert Details
    getAlertDetails: (state, action) => {
      state.loadingAlertDetails = true;
    },
    getAlertDetailsSuccess: (state, action) => {
      state.alertDetails = action.payload;
      state.loadingAlertDetails = false;
    },
    getAlertDetailsFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAlertDetails = false;
    },
    //requestLogTable
    getRequestLogTable: (state, action) => {
      state.loadingrequestLogTable = true;
    },
    getRequestLogTableSuccess: (state, action) => {
      state.requestLogTable = action.payload;
      state.loadingrequestLogTable = false;
    },
    getRequestLogTableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingrequestLogTable = false;
    },
    //Alert Details
    getAlertAttachementDetails: (state, action) => {
      state.loadingAlertAttachementDetails = true;
    },
    getAlertAttachementDetailsSuccess: (state, action) => {
      state.alertAttachementDetails = action.payload;
      state.loadingAlertAttachementDetails = false;
    },
    getAlertAttachementDetailsFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAlertAttachementDetails = false;
    },
    /*
    Workflow
    */
    getWorkflowAlertDetails: (state, action) => {
      state.loadingWorkflowAlertDetails = true;
    },
    getWorkflowAlertDetailsSuccess: (state, action) => {
      state.workflowAlertDetails = action.payload;
      state.loadingWorkflowAlertDetails = false;
    },
    getWorkflowAlertDetailsFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowAlertDetails = false;
    },
    getWorkflowRequestLog: (state, action) => {
      state.loadingWorkflowRequestLog = true;
    },
    getWorkflowRequestLogSuccess: (state, action) => {
      state.workflowRequestLog = action.payload;
      state.loadingWorkflowRequestLog = false;
    },
    getWorkflowRequestLogFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowRequestLog = false;
    },
    getWorkflowSearchData: (state, action) => {
      state.loadingWorkflowSearchData = true;
    },
    getWorkflowSearchDataSuccess: (state, action) => {
      let result = Array.isArray(action.payload);
      if (result) {
        state.workflowSearchData = action.payload;
        state.loadingWorkflowSearchData = false;
      } else {
        if (Object.keys(action.payload).length > 0 && action.payload.empID !== null) {
          let value: any = []
          value.push(action.payload)
          state.workflowSearchData = value;
        }
      }
      state.loadingWorkflowSearchData = false;
    },
    getWorkflowSearchDataFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowSearchData = false;
    },
    setWorkflowSearchDataEmpty: (state, action) => {
      state.workflowSearchData = [];
    },
    getWorkflowAttachementDetails: (state, action) => {
      state.loadingWorkflowAttachementDetails = true;
    },
    getWorkflowAttachementDetailsSuccess: (state, action) => {
      state.workflowAttachementDetails = action.payload;
      state.loadingWorkflowAttachementDetails = false;
    },
    getWorkflowAttachementDetailsFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowAttachementDetails = false;
    },
    getWorkflowUserRole: (state, action) => {
      state.loadingWorkflowUserRole = true;
    },
    getWorkflowUserRoleSuccess: (state, action) => {
      state.workflowUserRole = action.payload.role;
      state.loadingWorkflowUserRole = false;
    },
    getWorkflowUserRoleFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowUserRole = false;
    },
    updateWorkflowStatus: (state, action) => {
      state.loadingWorkflowStatus = true;
    },
    updateWorkflowStatusSuccess: (state, action) => {
      state.WorkflowStatus = action.payload;
      state.loadingWorkflowStatus = false;
    },
    updateWorkflowStatusFailure: (state, action) => {
      state.message = action.payload;
      state.loadingWorkflowStatus = false;
    },
    resetUpdateWorkflowStatus: (state, action) => {
      state.WorkflowStatus = []
      state.loadingWorkflowStatus = false;
    },
    /*
     Upload Attachements
     */
    uploadAttachements: (state, action) => {
      state.loadingUploadAttachementStatus = true;
    },
    uploadAttachementsSuccess: (state, action) => {
      state.uploadAttachementStatus = action.payload;
      state.loadingUploadAttachementStatus = false;
    },
    uploadAttachementsFailure: (state, action) => {
      state.message = action.payload;
      state.loadingUploadAttachementStatus = false;
    },
    resetUploadAttachements: (state, action) => {
      state.uploadAttachementStatus = [];
      state.loadingUploadAttachementStatus = false;
    },
    //ALERT MANAGEMENT PAGE End=======
    //Livetracking
    getLivetrackingtable: (state, action) => {
      state.livetrackingtable = [];
      state.loadinglivetrackingtable = true;
    },
    getLivetrackingtableSuccess: (state, action) => {
      state.livetrackingtable = action.payload;
      state.loadinglivetrackingtable = false;
    },
    getLivetrackingtableFailure: (state, action) => {
      state.message = action.payload;
      state.loadinglivetrackingtable = false;
    },
    getmodelstatusdropdown: (state, action) => {
      state.loadingmodelstatusdropdown = true;
    },
    getmodelstatusdropdownSuccess: (state, action) => {
      state.modelstatusdropdown = action.payload;
      state.loadingmodelstatusdropdown = false;
    },
    getmodelstatusdropdownFailure: (state, action) => {
      state.message = action.payload;
      state.loadingmodelstatusdropdown = false;
    },
    // Alert Dashboard
    getAssetPieChart: (state, action) => {
      state.loadingAssetPieChart = true;
    },
    getAssetPieChartSuccess: (state, action) => {
      state.assetPieChart = action.payload;
      state.loadingAssetPieChart = false;
    },
    getAssetPieChartFailure: (state, action) => {
      state.loadingAssetPieChart = false;
    },
    getAssetStackedBar: (state, action) => {
      state.loadingAssetStackedBar = true;
    },
    getAssetStackedBarSuccess: (state, action) => {
      state.assetStackedBar = action.payload;
      state.loadingAssetStackedBar = false;
    },
    getAssetStackedBarFailure: (state, action) => {
      state.loadingAssetStackedBar = false;
    },
    getDepartementStackedBar: (state, action) => {
      state.loadingDepartementStackedBar = true;
    },
    getDepartementStackedBarSuccess: (state, action) => {
      state.departementStackedBar = action.payload;
      state.loadingDepartementStackedBar = false;
    },
    getDepartementStackedBarFailure: (state, action) => {
      state.loadingDepartementStackedBar = false;
    },
    getPerformaceChart: (state, action) => {
      state.loadingPerformaceChart = true;
    },
    getPerformaceChartSuccess: (state, action) => {
      state.performaceChart = action.payload;
      state.loadingPerformaceChart = false;
    },
    getPerformaceChartFailure: (state, action) => {
      state.loadingPerformaceChart = false;
    },
    //PLANT TIMELINE
    getPlantTimelineByPlantId: (state, action) => {
      state.loadingplantTimelineByPlant = true;
    },
    getPlantTimelineByPlantIdSuccess: (state, action) => {
      state.plantTimelineByPlant = action.payload;
      state.loadingplantTimelineByPlant = false;
    },
    getPlantTimelineByPlantIdFailure: (state, action) => {
      state.loadingplantTimelineByPlant = false;
    },
    // Header Search
    getHeaderSearch: (state, action) => {
      state.searchValue = action.payload;
    },
    getGlobalSearch: (state, action) => {
      state.loadingGlobalSearch = true;
    },
    getGlobalSearchSuccess: (state, action) => {
      state.globalSearchData = action.payload;
      state.loadingGlobalSearch = false;
    },
    getGlobalSearchFailure: (state, action) => {
      state.loadingGlobalSearch = false;
    },
    //ReferenceTable Area
    getReferenceTableModelData: (state, action) => {
      state.loadingReferenceTableModelData = true;
    },
    getReferenceTableModelDataSuccess: (state, action) => {
      state.referenceTableModelData = action.payload;
      state.loadingReferenceTableModelData = false;
    },
    getReferenceTableModelDataFailure: (state, action) => {
      state.message = action.payload;
      state.loadingReferenceTableModelData = false;
    },
    getReferenceOffilineData: (state, action) => {
      state.loadingReferenceOffilineData = true;
    },
    getReferenceOffilineDataSuccess: (state, action) => {
      state.referenceOffilineData = action.payload;
      state.loadingReferenceOffilineData = false;
    },
    getReferenceOffilineDataFailure: (state, action) => {
      state.message = action.payload;
      state.loadingReferenceOffilineData = false;
    },
    //modelperformance
    getmodelalertstatuspiechart: (state, action) => {
      state.loadingmodelalertstatuspiechart = true;
    },
    getmodelalertstatuspiechartSuccess: (state, action) => {
      state.modelalertstatuspiechart = action.payload;
      state.loadingmodelalertstatuspiechart = false;
    },
    getmodelalertstatuspiechartFailure: (state, action) => {
      state.loadingAssetPieChart = false;
    },

    //monthwisebarchart
    getplantmonthwisebarchartdata: (state, action) => {
      state.loadingplantmonthwisebarchartdata = true;
    },
    getplantmonthwisebarchartdata_byplantidSuccess: (state, action) => {
      state.plantmonthwisebarchartdata = action.payload;
      state.loadingplantmonthwisebarchartdata = false;
    },
    getplantmonthwisebarchartdata_byplantidFailure: (state, action) => {
      state.loadingplantmonthwisebarchartdata = false;
    },
    //modelperformance monthwisetable
    getplantmodelbasedtabledatabyplant: (state, action) => {
      state.loadingplantmodelbasedtabledatabyplant = true;
    },
    getplantmodelbasedtabledatabyplantidSuccess: (state, action) => {
      state.plantmodelbasedtabledatabyplant = action.payload;
      state.loadingplantmodelbasedtabledatabyplant = false;
    },
    getplantmodelbasedtabledatabyplantidFailure: (state, action) => {
      state.loadingplantmodelbasedtabledatabyplant = false;
    },
    //Pmcompliance
    getpmcompliance: (state, action) => {
      state.loadingpmcompliance = true;
    },
    getPMComplianceSuccess: (state, action) => {
      state.pmcompliance = action.payload;
      state.loadingpmcompliance = false;
    },
    getPMComplianceFailure: (state, action) => {
      state.loadingpmcompliance = false;
    },

    //stackedbar-modelperformance
    getmodeltotalalertstatusbyasset: (state, action) => {
      state.loadingmodeltotalalertstatusbyasset = true;
    },
    getmodeltotalalertstatusbyassetSuccess: (state, action) => {
      state.modeltotalalertstatusbyasset = action.payload;
      state.loadingmodeltotalalertstatusbyasset = false;
    },
    getmodeltotalalertstatusbyassetFailure: (state, action) => {
      state.loadingmodeltotalalertstatusbyasset = false;
    },
    //AlertStatusbydepartment-modelperformanance
    getmodelalertstatusbydepartmentbyplant: (state, action) => {
      state.loadingmodelalertstatusbydepartmentbyplant = true;
    },
    getmodelalertstatusbydepartmentbyplantSuccess: (state, action) => {
      state.modelalertstatusbydepartmentbyplant = action.payload;
      state.loadingmodelalertstatusbydepartmentbyplant = false;
    },
    getmodelalertstatusbydepartmentbyplantFailure: (state, action) => {
      state.loadingmodelalertstatusbydepartmentbyplant = false;
    },
    getModelPerformanceAssetDropdownChange: (state, action) => {
      state.modelPerformanceAssetDropdownChangedValue = action.payload;
    },
    // Dropdowns
    getRegionDropdownList: (state, action) => {
      state.loadingRegionDropdownList = true;
    },
    getRegionDropdownListSuccess: (state, action) => {
      state.regionDropdownList = action.payload;
      state.loadingRegionDropdownList = false;
    },
    getRegionDropdownListFailure: (state, action) => {
      state.loadingRegionDropdownList = false;
    },
    getAffiliateDropdownList: (state, action) => {
      state.loadingAffiliateDropdownList = true;
    },
    getAffiliateDropdownListSuccess: (state, action) => {
      state.affiliateDropdownList = action.payload;
      state.loadingAffiliateDropdownList = false;
    },
    getAffiliateDropdownListFailure: (state, action) => {
      state.loadingAffiliateDropdownList = false;
    },
    getPlantDropdownList: (state, action) => {
      state.loadingPlantDropdownList = true;
    },
    getPlantDropdownListSuccess: (state, action) => {
      state.plantDropdownList = action.payload;
      state.loadingPlantDropdownList = false;
    },
    getPlantDropdownListFailure: (state, action) => {
      state.loadingPlantDropdownList = false;
    },
    getAssetDropdownList: (state, action) => {
      state.loadingAssetDropdownList = true;
    },
    getAssetDropdownListSuccess: (state, action) => {
      state.assetDropdownList = action.payload;
      state.loadingAssetDropdownList = false;
    },
    getAssetDropdownListFailure: (state, action) => {
      state.loadingAssetDropdownList = false;
    },
    getModelDropdownList: (state, action) => {
      state.loadingModelNameDropdownList = true;
    },
    getModelDropdownListSuccess: (state, action) => {
      state.modelDropdownList = action.payload;
      state.loadingModelNameDropdownList = false;
    },
    getModelDropdownListFailure: (state, action) => {
      state.loadingModelNameDropdownList = false;
    },
    getModelSensorDropdownList: (state, action) => {
      state.loadingModelSensorDropdownList = true;
    },
    getModelSensorDropdownListSuccess: (state, action) => {
      state.modelSensorDropdownList = action.payload.data;
      state.modelSensorUnTransformedList = action.payload.list;
      state.loadingModelSensorDropdownList = false;
    },
    getModelSensorDropdownListFailure: (state, action) => {
      state.loadingModelSensorDropdownList = false;
    },
    getModelStatusDropdownList: (state, action) => {
      state.loadingModelStatusDropdownList = true;
    },
    getModelStatusDropdownListSuccess: (state, action) => {
      state.modelStatusDropdownList = action.payload;
      state.loadingModelStatusDropdownList = false;
    },
    getModelStatusDropdownListFailure: (state, action) => {
      state.loadingModelStatusDropdownList = false;
    },
    getSensorDropdownList: (state, action) => {
      state.loadingSensorDropdownList = true;
    },
    getSensorDropdownListSuccess: (state, action) => {
      state.sensorDropdownList = action.payload;
      state.loadingSensorDropdownList = false;
    },
    getSensorDropdownListFailure: (state, action) => {
      state.loadingSensorDropdownList = false;
    },
    getAlertIDDropdownList: (state, action) => {
      state.loadingAlertIDDropdownList = true;
    },
    getAlertIDDropdownListSuccess: (state, action) => {
      state.alertIDDropdownList = action.payload;
      state.loadingAlertIDDropdownList = false;
    },
    getAlertIDDropdownListFailure: (state, action) => {
      state.loadingAlertIDDropdownList = false;
    },
    // Alert management Droprdown Start
    getAlertManagementAffiliatesDroprdown: (state, action) => {
      state.loadingAlertManagementAffiliatesDroprdown = true;
    },
    getAlertManagementAffiliatesDroprdownSuccess: (state, action) => {
      state.alertManagementAffiliatesDroprdown = action.payload;
      state.loadingAlertManagementAffiliatesDroprdown = false;
    },
    getAlertManagementAffiliatesDroprdownFailure: (state, action) => {
      state.loadingAlertManagementAffiliatesDroprdown = false;
    },
    //=======
    getAlertManagementPlantDroprdown: (state, action) => {
      state.loadingAlertManagementPlantDroprdown = true;
    },
    getAlertManagementPlantDroprdownSuccess: (state, action) => {
      state.alertManagementPlantDroprdown = action.payload;
      state.loadingAlertManagementPlantDroprdown = false;
    },
    getAlertManagementPlantDroprdownFailure: (state, action) => {
      state.loadingAlertManagementPlantDroprdown = false;
    },
    getAlertManagementPlantDroprdownEmpty: (state, action) => {
      state.alertManagementPlantDroprdown = [];
    },
    //=======
    getAlertManagementAssetIdDroprdown: (state, action) => {
      state.loadingAlertManagementAssetIdDroprdown = true;
    },
    getAlertManagementAssetIdDroprdownSuccess: (state, action) => {
      state.alertManagementAssetIdDroprdown = action.payload;
      state.loadingAlertManagementAssetIdDroprdown = false;
    },
    getAlertManagementAssetIdDroprdownFailure: (state, action) => {
      state.loadingAlertManagementAssetIdDroprdown = false;
    },
    getAlertManagementAssetIdDroprdownEmpty: (state, action) => {
      state.alertManagementAssetIdDroprdown = [];
    },
    //=======
    getAlertManagementAlertIdDroprdown: (state, action) => {
      state.loadingAlertManagementAlertIdDroprdown = true;
    },
    getAlertManagementAlertIdDroprdownSuccess: (state, action) => {
      state.alertManagementAlertIdDroprdown = action.payload;
      state.loadingAlertManagementAlertIdDroprdown = false;
    },
    getAlertManagementAlertIdDroprdownFailure: (state, action) => {
      state.loadingAlertManagementAlertIdDroprdown = false;
    },
    getAlertManagementAlertIdDroprdownEmpty: (state, action) => {
      state.alertManagementAlertIdDroprdown = [];
    },
    //========
    getcurrentstageDropdownList: (state, action) => {
      state.loadingcurrentstageDropdownList = true;
    },
    getcurrentstageDropdownListSuccess: (state, action) => {
      state.currentstageDropdownList = action.payload;
      state.loadingcurrentstageDropdownList = false;
    },
    getcurrentstageDropdownListFailure: (state, action) => {
      state.loadingcurrentstageDropdownList = false;
    },
    getLongLeadActionDropdownList: (state, action) => {
      state.loadingLongLeadActionDropdownList = true;
    },
    getLongLeadActionDropdownListSuccess: (state, action) => {
      state.longLeadActionDropdownList = action.payload;
      state.loadingLongLeadActionDropdownList = false;
    },
    getLongLeadActionDropdownListFailure: (state, action) => {
      state.loadingLongLeadActionDropdownList = false;
    },
    getStatusDropdownList: (state, action) => {
      state.loadingStatusDropdownList = true;
    },
    getStatusDropdownListSuccess: (state, action) => {
      state.statusDropdownList = action.payload;
      state.loadingStatusDropdownList = false;
    },
    getStatusDropdownListFailure: (state, action) => {
      state.loadingStatusDropdownList = false;
    },
    // Alert management Droprdown END
    getGlobalSelecetedRegion: (state, action) => {
      state.globalSelecetedRegion = action.payload;
    },
    getGlobalSelecetedAffiliate: (state, action) => {
      state.globalSelecetedAffiliate = action.payload;
    },
    getGlobalSelecetedPlant: (state, action) => {
      state.globalSelecetedPlant = action.payload;
    },
    getGlobalSelecetedAsset: (state, action) => {
      state.globalSelecetedAsset = action.payload;
      //Asset AlertList
    },
    getGlobalSelectAlertID: (state, action) => {
      state.globalSelectedAlertID = action.payload;
    },

    // Alert List Table
    getAlertListtable: (state, action) => {
      state.alertlisttable = [];
      state.loadingalertlisttable = true;
    },
    getAlertListtableSuccess: (state, action) => {
      state.alertlisttable = action.payload;
      state.loadingalertlisttable = false;
    },
    getAlertListtableFailure: (state, action) => {
      state.message = action.payload;
      state.loadingalertlisttable = false;
    },
    getAlertListTopBarSummary: (state, action) => {
      state.loadingAlertListTopBarSummary = true;
    },
    getAlertListTopBarSummarySuccess: (state, action) => {
      state.alertListTopBarSummary = action.payload;
      state.loadingAlertListTopBarSummary = false;
    },
    getAlertListTopBarSummaryFailure: (state, action) => {
      state.message = action.payload;
      state.loadingAlertListTopBarSummary = false;
    },
    getAlertListAssetIDDropdown: (state, action) => {
      state.loadingalertlistassetiddropdown = true;
    },
    getAlertListAssetIDDropdownSuccess: (state, action) => {
      state.alertlistassetiddropdown = action.payload;
      state.loadingalertlistassetiddropdown = false;
    },
    getAlertListAssetIDDropdownFailure: (state, action) => {
      state.message = action.payload;
      state.loadingalertlistassetiddropdown = false;
    },
    getAlertListModelNameDropdown: (state, action) => {
      state.loadingalertlistmodelnamedropdown = true;
    },
    getAlertListModelNameDropdownSuccess: (state, action) => {
      state.alertlistmodelnamedropdown = action.payload;
      state.loadingalertlistmodelnamedropdown = false;
    },
    getAlertListModelNameDropdownFailure: (state, action) => {
      state.message = action.payload;
      state.loadingalertlistmodelnamedropdown = false;
    },
    getAlertListModelStatusDropdown: (state, action) => {
      state.loadingalertlistassetmodelstatusdropdown = true;
    },
    getAlertListModelStatusDropdownSuccess: (state, action) => {
      state.alertlistassetmodelstatusdropdown = action.payload;
      state.loadingalertlistassetmodelstatusdropdown = false;
    },
    getAlertListModelStatusDropdownFailure: (state, action) => {
      state.message = action.payload;
      state.loadingalertlistassetmodelstatusdropdown = false;
    },
    // affiliate Page
    getAffiliateTopBar: (state, action) => {
      state.loadingAffiliateTopBar = true;
    },
    getAffiliateTopBarSuccess: (state, action) => {
      state.affiliateTopBar = action.payload;
      state.loadingAffiliateTopBar = false;
    },
    getAffiliateTopBarFailure: (state, action) => {
      state.loadingAffiliateTopBar = false;
    },
    getAffiliateDetails: (state, action) => {
      state.affiliateDetails = [];
      state.loadingAffiliateDetails = true;
    },
    getAffiliateDetailsSuccess: (state, action) => {
      state.affiliateDetails = action.payload;
      state.loadingAffiliateDetails = false;
    },
    getAffiliateDetailsFailure: (state, action) => {
      state.loadingAffiliateDetails = false;
    },
    //Home Page
    getGlobalTopBarSummary: (state, action) => {
      state.loadingGlobalTopBarSummary = true;
    },
    getGlobalTopBarSummarySuccess: (state, action) => {
      state.globalTopBarSummary = action.payload;
      state.loadingGlobalTopBarSummary = false;
    },
    getGlobalTopBarSummaryFailure: (state, action) => {
      state.loadingGlobalTopBarSummary = false;
    },
    getGlobalMapSummaryByUserId: (state, action) => {
      state.loadingGlobalMapSummaryByUserId = true;
    },
    getGlobalMapSummaryByUserIdSuccess: (state, action) => {
      state.globalMapSummaryByUserId = action.payload;
      state.loadingGlobalMapSummaryByUserId = false;
    },
    getGlobalMapSummaryByUserIdFailure: (state, action) => {
      state.loadingGlobalMapSummaryByUserId = false;
    },
    getGlobalRegionMapSummaryByUserId: (state, action) => {
      state.loadingGlobalRegionMapSummaryByUserId = true;
    },
    getGlobalRegionMapSummaryByUserIdSuccess: (state, action) => {
      state.globalRegionMapSummaryByUserId = action.payload;
      state.loadingGlobalRegionMapSummaryByUserId = false;
    },
    getGlobalRegionMapSummaryByUserIdFailure: (state, action) => {
      state.loadingGlobalRegionMapSummaryByUserId = false;
    },
    // Plant Page
    getPlantTopBar: (state, action) => {
      state.loadingPlantTopBar = true;
    },
    getPlantTopBarSuccess: (state, action) => {
      state.plantTopBar = action.payload;
      state.loadingPlantTopBar = false;
    },
    getPlantTopBarFailure: (state, action) => {
      state.loadingPlantTopBar = false;
    },
    getPlantDetails: (state, action) => {
      state.plantDetails = [];
      state.loadingPlantDetails = true;
    },
    getPlantDetailsSuccess: (state, action) => {
      state.plantDetails = action.payload;
      state.loadingPlantDetails = false;
    },
    getPlantDetailsFailure: (state, action) => {
      state.loadingPlantDetails = false;
    },
    getPlantDetailsEmpty: (state, action) => {
      state.plantDetails = [];
    },
    //Admin Configuration Start
    getAffiliateRollout: (state, action) => {
      state.loadingAffiliateRollout = true;
    },
    getAffiliateRolloutSuccess: (state, action) => {
      state.affiliateRollout = action.payload;
      state.loadingAffiliateRollout = false;
    },
    getAffiliateRolloutFailure: (state, action) => {
      state.loadingAffiliateRollout = false;
    },
    getPlantRollout: (state, action) => {
      state.loadingPlantRollout = true;
    },
    getPlantRolloutSuccess: (state, action) => {
      state.plantRollout = action.payload;
      state.loadingPlantRollout = false;
    },
    getPlantRolloutFailure: (state, action) => {
      state.loadingPlantRollout = false;
    },
    updateAffiliateRollout: (state, action) => {
      state.loadingAffiliateRolloutStatus = true;
    },
    updateAffiliateRolloutSuccess: (state, action) => {
      state.affiliateRolloutStatus = action.payload;
      state.loadingAffiliateRolloutStatus = false;
    },
    updateAffiliateRolloutFailure: (state, action) => {
      state.loadingAffiliateRolloutStatus = false;
    },
    updatePlantRollout: (state, action) => {
      state.loadingPlantRolloutStatus = true;
    },
    updatePlantRolloutSuccess: (state, action) => {
      state.plantRolloutStatus = action.payload;
      state.loadingPlantRolloutStatus = false;
    },
    updatePlantRolloutFailure: (state, action) => {
      state.loadingPlantRolloutStatus = false;
    },
    getAssetModelConfigTableData: (state, action) => {
      state.loadingAssetModelConfigTableData = true;
    },
    getAssetModelConfigTableDataSuccess: (state, action) => {
      state.assetModelConfigTableData = action.payload;
      state.loadingAssetModelConfigTableData = false;
    },
    getAssetModelConfigTableDataFailure: (state, action) => {
      state.loadingAssetModelConfigTableData = false;
    },
    updateAssetModelConfigTableStatus: (state, action) => {
      state.loadingAssetModelConfigTableStatus = true;
    },
    updateAssetModelConfigTableStatusSuccess: (state, action) => {
      state.assetModelConfigTableStatus = action.payload;
      state.loadingAssetModelConfigTableStatus = false;
    },
    updateAssetModelConfigTableStatusFailure: (state, action) => {
      state.loadingAssetModelConfigTableStatus = false;
    },
    getExceptionLog: (state, action) => {
      state.loadingExceptionLogs = true;
    },
    getExceptionLogSuccess: (state, action) => {
      state.exceptionLogs = action.payload;
      state.loadingExceptionLogs = false;
    },
    getExceptionLogFailure: (state, action) => {
      state.loadingExceptionLogs = false;
    },
    getRoleMappingRoleDropdownList: (state, action) => {
      state.loadingRoleListDropdown = true;
    },
    getRoleMappingRoleDropdownListSuccess: (state, action) => {
      state.roleListDropdown = action.payload;
      state.loadingRoleListDropdown = false;
    },
    getRoleMappingRoleDropdownListFailure: (state, action) => {
      state.loadingRoleListDropdown = false;
    },
    getRoleMappingPlantDropdownList: (state, action) => {
      state.loadingPlantListDropdown = true;
    },
    getRoleMappingPlantDropdownListSuccess: (state, action) => {
      state.plantListDropdown = action.payload;
      state.loadingPlantListDropdown = false;
    },
    getRoleMappingPlantDropdownListFailure: (state, action) => {
      state.loadingPlantListDropdown = false;
    },
    getRoleMappingAffiliateDropdownList: (state, action) => {
      state.loadingAffiliateListDropdown = true;
    },
    getRoleMappingAffiliateDropdownListSuccess: (state, action) => {
      state.affiliateListDropdown = action.payload;
      state.loadingAffiliateListDropdown = false;
    },
    getRoleMappingAffiliateDropdownListFailure: (state, action) => {
      state.loadingAffiliateListDropdown = false;
    },
    addRoleMapping: (state, action) => {
      state.loadingRoleAddMappingStatus = true;
    },
    addRoleMappingSuccess: (state, action) => {
      state.roleAddMappingStatus = action.payload;
      state.loadingRoleAddMappingStatus = false;
    },
    addRoleMappingFailure: (state, action) => {
      state.loadingRoleAddMappingStatus = false;
    },
    updateRoleMapping: (state, action) => {
      state.loadingRoleAddMappingStatus = true;
    },
    updateRoleMappingSuccess: (state, action) => {
      state.roleAddMappingStatus = action.payload;
      state.loadingRoleAddMappingStatus = false;
    },
    updateRoleMappingFailure: (state, action) => {
      state.loadingRoleAddMappingStatus = false;
    },
    getRoleMappingWorklist: (state, action) => {
      state.loadingRoleMappingWorklist = true;
    },
    getRoleMappingWorklistSuccess: (state, action) => {
      state.roleMappingWorklist = action.payload;
      state.loadingRoleMappingWorklist = false;
    },
    getRoleMappingWorklistFailure: (state, action) => {
      state.loadingRoleMappingWorklist = false;
    },
    getEmployeeList: (state, action) => {
      state.loadingEmployeeList = true;
    },
    getEmployeeListSuccess: (state, action) => {
      state.employeeList = action.payload;
      state.loadingEmployeeList = false;
    },
    getEmployeeListFailure: (state, action) => {
      state.loadingEmployeeList = false;
    },
    //Asset model config dropdown
    getAssetModelConfigDropdownList: (state, action) => {
      state.loadingAssetModelConfigDropdown = true;
    },

    getAssetModelConfigDropdownListSuccess: (state, action) => {
      state.assetModelConfigDropdown = action.payload;
      state.loadingAssetModelConfigDropdown = false;
    },
    getAssetModelConfigDropdownListFailure: (state, action) => {
      state.loadingAssetModelConfigDropdown = false;
    },
    getAssetModelConfigAffiliateDropdownList: (state, action) => {
      state.loadingAssetModelConfigAffiliateDropdown = true;
    },
    getAssetModelConfigAffiliateDropdownListSuccess: (state, action) => {
      state.assetModelConfigAffiliateDropdown = action.payload;
      state.loadingAssetModelConfigAffiliateDropdown = false;
    },
    getAssetModelConfigAffiliateDropdownListFailure: (state, action) => {
      state.loadingAssetModelConfigAffiliateDropdown = false;
    },
    getAssetModelConfigPlantDropdownList: (state, action) => {
      state.loadingAssetModelConfigPlantDropdown = true;
    },
    getAssetModelConfigPlantDropdownListSuccess: (state, action) => {
      state.assetModelConfigPlantDropdown = action.payload;
      state.loadingAssetModelConfigPlantDropdown = false;
    },
    getAssetModelConfigPlantDropdownListFailure: (state, action) => {
      state.loadingAssetModelConfigPlantDropdown = false;
    },
    //Alert Statistics
    getPlantUtilizationTime: (state, action) => {
      state.loadingPlantUtilizationTime = true;
    },
    getPlantUtilizationTimeSuccess: (state, action) => {
      state.plantUtilizationTime = action.payload;
      state.loadingPlantUtilizationTime = false;
    },
    getPlantUtilizationTimeFailure: (state, action) => {
      state.loadingPlantUtilizationTime = false;
    },
    getFailurePopupDataFun: (state, action) => {
      state.getFailurePopupData = action.payload;
    },
    getFailurePopupDataFunEmpty: (state, action) => {
      state.getFailurePopupData = {};
    },
    setRefreshPmtPage: (state, action) => {
      state.refreshPmtPage = action.payload;
    },
    setRefreshAlertListPage: (state, action) => {
      state.refreshAlertListPage = action.payload;
    },
    setRefreshMyTaskPage: (state, action) => {
      state.refreshMyTaskPage = action.payload;
    },
    updateAffiliateRolloutStatus: (state, action) => {
      state.affiliateRolloutStatus = action.payload;
    },
    updatePlantRolloutStatus: (state, action) => {
      state.plantRolloutStatus = action.payload;
    },
    addRoleMappingStatus: (state, action) => {
      state.roleAddMappingStatus = action.payload;
    },
    updateRoleMappingStatus: (state, action) => {
      state.roleUpdateMappingStatus = action.payload;
    },
    updateAssetModelConfigResponseStatus: (state, action) => {
      state.assetModelConfigTableStatus = action.payload;
    },
    getPlantAlertStatus: (state, action) => {
      state.plantAlertStatus = action.payload;
    },
    getPlantAlertListStateDropdownList: (state, action) => {
      state.loadingPlantAlertListStateDropdown = true;
    },
    getPlantAlertListStateDropdownListSuccess: (state, action) => {
      state.plantAlertListStateDropdown = action.payload;
      state.loadingPlantAlertListStateDropdown = false;
    },
    getPlantAlertListStateDropdownListFailure: (state, action) => {
      state.loadingPlantAlertListStateDropdown = false;
    },
    getPlantDepartmentStatus: (state, action) => {
      state.plantDepartmentStatus = action.payload;
    },
    getPlantAlertListDepartmentDropdownList: (state, action) => {
      state.loadingPlantAlertListDepartmentDropdown = true;
    },
    getPlantAlertListDepartmentDropdownListSuccess: (state, action) => {
      state.plantAlertListDepartmentDropdown = action.payload;
      state.loadingPlantAlertListDepartmentDropdown = false;
    },
    getPlantAlertListDepartmentDropdownListFailure: (state, action) => {
      state.loadingPlantAlertListDepartmentDropdown = false;
    },
    getExceptionLogById: (state, action) => {
      state.loadingExceptionLog = true;
    },
    getExceptionLogByIdSuccess: (state, action) => {
      state.exceptionLog = action.payload;
      state.loadingExceptionLog = false;
    },
    getExceptionLogByIdFailure: (state, action) => {
      state.loadingExceptionLog = false;
    },
    //Plant Shutdown
    getPlantShutdown: (state, action) => {
      state.loadingPlantShutdown = true;
    },
    getPlantShutdownSuccess: (state, action) => {
      state.plantShutdown = action.payload;
      state.loadingPlantShutdown = false;
    },
    getPlantShutdownFailure: (state, action) => {
      state.loadingPlantShutdown = false;
    },
    getAlertBreadCrumbs: (state, action) => {
      state.loadingAlertBreadCrumbs = true;
    },
    getAlertBreadCrumbsSuccess: (state, action) => {
      state.alertBreadCrumbs = action.payload;
      state.loadingAlertBreadCrumbs = false;
    },
    getAlertBreadCrumbsFailure: (state, action) => {
      state.loadingAlertBreadCrumbs = false;
    },
    getAlertBreadCrumbsEmpty: (state, action) => {
      state.alertBreadCrumbs = [];
    },
    //Spare parts
    getSparePartsSAP: (state, action) => {
      state.loadingSparePartsSAP = true;
    },
    getSparePartsSAPSuccess: (state, action) => {
      state.sparePartsSAP = action.payload;
      state.loadingSparePartsSAP = false;
    },
    getSparePartsSAPFailure: (state, action) => {
      state.loadingSparePartsSAP = false;
    },
    getSparePartsSensor: (state, action) => {
      state.loadingSparePartsSensor = true;
    },
    getSparePartsSensorSuccess: (state, action) => {
      state.sparePartsSensor = action.payload;
      state.loadingSparePartsSensor = false;
    },
    getSparePartsSensorFailure: (state, action) => {
      state.loadingSparePartsSensor = false;
    },
    getSparePartsSAPDropdown: (state, action) => {
      state.loadingSparePartsSAPDropdown = true;
    },
    getSparePartsSAPDropdownSuccess: (state, action) => {
      state.sparePartsSAPDropdown = action.payload;
      state.loadingSparePartsSAPDropdown = false;
    },
    getSparePartsSAPDropdownFailure: (state, action) => {
      state.loadingSparePartsSAPDropdown = false;
    },
    updateSparePartsSap: (state, action) => {
      state.loadingUpdateSparePartsSapStatus = true;
    },
    updateSparePartsSapSuccess: (state, action) => {
      state.updateSparePartsSapStatus = action.payload;
      state.loadingUpdateSparePartsSapStatus = false;
    },
    updateSparePartsSapFailure: (state, action) => {
      state.loadingUpdateSparePartsSapStatus = false;
    },
    updateSparePartsSapResponse: (state, action) => {
      state.updateSparePartsSapStatus = action.payload;
    },
    userProfileActive: (state, action) => {
      state.userProfileActiveOn = action.payload;
    },
    //work flow page
    getIBMAlertDetailsByAlertId: (state, action) => {
      state.loadingIBMAlertDetailsByAlertId = true;
    },
    getIBMAlertDetailsByAlertIdSuccess: (state, action) => {
      state.IBMAlertDetailsByAlertId = action.payload;
      state.loadingIBMAlertDetailsByAlertId = false;
    },
    getIBMAlertDetailsByAlertIdFailure: (state, action) => {
      state.loadingIBMAlertDetailsByAlertId = false;
    },
    getConsultSomeone: (state, action) => {
      state.loadingConsultSomeone = true;
    },
    getConsultSomeoneSuccess: (state, action) => {
      state.consultSomeone = action.payload;
      state.loadingConsultSomeone = false;
    },
    getConsultSomeoneFailure: (state, action) => {
      state.loadingConsultSomeone = false;
    },
     //Utilization Report Year Month
     getAlertManagementYearDropdown: (state, action) => {
      state.loadingAlertManagementYearListDroprdown = true;
    },
    getAlertManagementYearDropdownSuccess: (state, action) => {
      state.alertManagementYearListDroprdown = action.payload;
      state.loadingAlertManagementYearListDroprdown = false;
    },
    getAlertManagementYearDropdownFailure: (state, action) => {
      state.loadingAlertManagementYearListDroprdown = false;
    },
    getAlertManagementMonthDropdown: (state, action) => {
      state.loadingAlertManagementMonthListDroprdown = true;
    },
    getAlertManagementMonthDropdownSuccess: (state, action) => {
      state.alertManagementMonthListDroprdown = action.payload;
      state.loadingAlertManagementMonthListDroprdown = false;
    },
    getAlertManagementMonthDropdownFailure: (state, action) => {
      state.loadingAlertManagementMonthListDroprdown = false;
    },
  }
});
//work flow page
export const {
  getFailurePopupDataFun,
  getFailurePopupDataFunEmpty,
  // User Profile Start
  updateLoggedInUserDetails,
  getLoggedInUserDetails,
  getLoggedInUserDetailsSuccess,
  getLoggedInUserDetailsFailure,
  // Home Start
  getRegions,
  getRegionSuccess,
  getRegionsFailure,
  getAssetListByPlantId,
  getAssetListByPlantIdSuccess,
  getAssetListByPlantIdFailure,
  getPlantAlertSpmt,
  getPlantAlertSpmtSuccess,
  getPlantAlertSpmtFailure,
  getAssetCardPmtByPlantId,
  getAssetCardPmtByPlantIdSuccess,
  getAssetCardPmtByPlantIdFailure,
  getAssetCardPmtByAssetId,
  getAssetCardPmtByAssetIdSuccess,
  getAssetCardPmtByAssetIdFailure,
  getAssetStatusPmtByPlantId,
  getAssetStatusPmtByPlantIdSuccess,
  getAssetStatusPmtByPlantIdFailure,
  getStatusAssetPmtByPlantId,
  getStatusAssetPmtByPlantIdSuccess,
  getStatusAssetPmtByPlantIdFailure,
  getssetStatusListbyPlantId,
  getssetStatusListbyPlantIdSuccess,
  getssetStatusListbyPlantIdFailure,
  getHeatMapToolTipbyAssetStatus,
  getHeatMapToolTipbyAssetStatusSuccess,
  getHeatMapToolTipbyAssetStatusFailure,
  getHeatMapToolTipbyAssetStatusEmpty,
  getTopBarToolTipbyPlantId,
  getTopBarToolTipbyPlantIdSuccess,
  getTopBarToolTipbyPlantIdFailure,
  // Asset Model Start
  getassetlistOfAssetModelByplantid,
  getassetlistOfAssetModelByplantidSuccess,
  getassetlistOfAssetModelByplantidFailure,
  getAnomalyModelbyAssetId,
  getAnomalyModelbyAssetIdSuccess,
  getAnomalyModelbyAssetIdFailure,
  getFailurepreDictionByAssetId,
  getFailurepreDictionByAssetIdSuccess,
  getFailurepreDictionByAssetIdFailure,
  getGraphicalImageByAssetId,
  getGraphicalImageByAssetIdSuccess,
  getGraphicalImageByAssetIdFailure,
  getAssetKPI,
  getAssetKPISuccess,
  getAssetKPIFailure,
  getSensorGroupId,
  // Plot Screen
  getPlotModelDropDown,
  getPlotModelDropDownSuccess,
  getPlotModelDropDownFailure,
  getPlotAssetDropDown,
  getPlotAssetDropDownSuccess,
  getPlotAssetDropDownFailure,
  getPlotSensorDropDown,
  getPlotSensorDropDownSuccess,
  getPlotSensorDropDownFailure,
  getPlotDeviationData,
  getPlotDeviationDataSuccess,
  getPlotStatusData,
  getPlotStatusDataSuccess,
  getPlotStatusDataFailure,
  getPlotDeviationModel,
  getPlotDeviationModelSuccess,
  getPlotDeviationModelFailure,
  getPlotSensorData,
  getPlotSensorDataSuccess,
  getPlotSensorDataFailure,
  // Plot Screen Ends
  // Dates
  getCommonFromDate,
  getCommonToDate,
  getBreadCrumbDate,
  getTodayDate,
  //AlertStatusList
  getAlertStatisticsAlertListByPlantId,
  getAlertStatisticsAlertListByPlantIdSuccess,
  getAlertStatisticsAlertListByPlantIdFailure,
  //ASSET TIMELINE Start
  getAssetHealthIndexByAssetId,
  getAssetHealthIndexByAssetIdSuccess,
  getAssetHealthIndexByAssetIdFailure,
  getMaintenanceHistoryByAssetId,
  getMaintenanceHistoryByAssetIdSuccess,
  getMaintenanceHistoryByAssetIdFailure,
  getHanaIncidentByAssetId,
  getHanaIncidentByAssetIdSuccess,
  getHanaIncidentByAssetIdFailure,
  //ALERT MANAGEMENT PAGE Start=======
  // dropdown
  getAlertManagementAffiliatesDroprdown,
  getAlertManagementAffiliatesDroprdownSuccess,
  getAlertManagementAffiliatesDroprdownFailure,
  getAlertManagementPlantDroprdown,
  getAlertManagementPlantDroprdownSuccess,
  getAlertManagementPlantDroprdownFailure,
  getAlertManagementPlantDroprdownEmpty,
  getAlertManagementAssetIdDroprdown,
  getAlertManagementAssetIdDroprdownSuccess,
  getAlertManagementAssetIdDroprdownFailure,
  getAlertManagementAssetIdDroprdownEmpty,
  getAlertManagementAlertIdDroprdown,
  getAlertManagementAlertIdDroprdownSuccess,
  getAlertManagementAlertIdDroprdownFailure,
  getAlertManagementAlertIdDroprdownEmpty,
  //mytask
  getMyTaskTable,
  getMyTaskTableSuccess,
  getMyTaskTableFailure,
  //report table
  getreporttable,
  getreporttableSuccess,
  getreporttableFailure,
  //utilizationreport table
  getutilizationreporttable,
  getutilizationreporttableSuccess,
  getutilizationreporttableFailure,
  //Master data report
  getmasterdatareporttable,
  getmasterdatareporttableSuccess,
  getmasterdatareporttableFailure,
  getAlertDetails,
  getAlertDetailsSuccess,
  getAlertDetailsFailure,
  getAlertAttachementDetails,
  //requestLogTable
  getRequestLogTable,
  getRequestLogTableSuccess,
  getRequestLogTableFailure,
  /*
   Workflow
   */
  getWorkflowAlertDetails,
  getWorkflowRequestLog,
  getWorkflowSearchData,
  getWorkflowAttachementDetails,
  getWorkflowUserRole,
  setWorkflowSearchDataEmpty,
  updateWorkflowStatus,
  resetUpdateWorkflowStatus,
  /*
   Upload Attachements
   */
  uploadAttachements,
  uploadAttachementsSuccess,
  uploadAttachementsFailure,
  resetUploadAttachements,
  //ALERT MANAGEMENT PAGE End=======
  //Livetracking
  getLivetrackingtable,
  getLivetrackingtableSuccess,
  getLivetrackingtableFailure,
  getmodelstatusdropdown,
  getmodelstatusdropdownSuccess,
  getmodelstatusdropdownFailure,
  //Alert Dashboard
  getAssetPieChart,
  getAssetPieChartSuccess,
  getAssetPieChartFailure,
  getAssetStackedBar,
  getAssetStackedBarSuccess,
  getAssetStackedBarFailure,
  getDepartementStackedBar,
  getDepartementStackedBarSuccess,
  getDepartementStackedBarFailure,
  getPerformaceChart,
  getPerformaceChartSuccess,
  getPerformaceChartFailure,
  //PLANT TIMELINE
  getPlantTimelineByPlantId,
  getPlantTimelineByPlantIdSuccess,
  getPlantTimelineByPlantIdFailure,

  // Header Search
  getHeaderSearch,
  getGlobalSearch,
  getGlobalSearchSuccess,
  getGlobalSearchFailure,
  //ReferenceTable
  getReferenceTableModelData,
  getReferenceTableModelDataSuccess,
  getReferenceTableModelDataFailure,
  getReferenceOffilineData,
  getReferenceOffilineDataSuccess,
  getReferenceOffilineDataFailure,
  //ModelPerformanance
  getmodelalertstatuspiechart,
  getmodelalertstatuspiechartSuccess,
  getmodelalertstatuspiechartFailure,
  getmodeltotalalertstatusbyasset,
  getmodeltotalalertstatusbyassetFailure,
  getmodeltotalalertstatusbyassetSuccess,
  getmodelalertstatusbydepartmentbyplant,
  getmodelalertstatusbydepartmentbyplantFailure,
  getmodelalertstatusbydepartmentbyplantSuccess,
  //monthwise table
  getplantmodelbasedtabledatabyplant,
  getplantmodelbasedtabledatabyplantidFailure,
  getplantmodelbasedtabledatabyplantidSuccess,
  //Pmcompliance
  getpmcompliance,
  getPMComplianceSuccess,
  getPMComplianceFailure,
  //modelperformance monthwise barchart
  getplantmonthwisebarchartdata,
  getplantmonthwisebarchartdata_byplantidSuccess,
  getplantmonthwisebarchartdata_byplantidFailure,
  getModelPerformanceAssetDropdownChange,
  //Store current region value
  getCurrRegionValue,
  // Dropdowns
  getRegionDropdownList,
  getAffiliateDropdownList,
  getPlantDropdownList,
  getAssetDropdownList,
  getModelDropdownList,
  getModelSensorDropdownList,
  getModelStatusDropdownList,
  getSensorDropdownList,
  getGlobalSelecetedRegion,
  getGlobalSelecetedAffiliate,
  getGlobalSelecetedPlant,
  getGlobalSelecetedAsset,
  getAlertIDDropdownList,
  getGlobalSelectAlertID,
  // Alert management Droprdown
  getLongLeadActionDropdownList,
  getLongLeadActionDropdownListSuccess,
  getLongLeadActionDropdownListFailure,
  getStatusDropdownList,
  getStatusDropdownListSuccess,
  getStatusDropdownListFailure,
  getcurrentstageDropdownList,
  getcurrentstageDropdownListSuccess,
  getcurrentstageDropdownListFailure,
  //Asset AlertList
  getAlertListtable,
  getAlertListtableSuccess,
  getAlertListtableFailure,
  getAlertListTopBarSummary,
  getAlertListTopBarSummarySuccess,
  getAlertListTopBarSummaryFailure,
  getAlertListAssetIDDropdown,
  getAlertListAssetIDDropdownSuccess,
  getAlertListAssetIDDropdownFailure,
  getAlertListModelNameDropdown,
  getAlertListModelNameDropdownSuccess,
  getAlertListModelNameDropdownFailure,
  getAlertListModelStatusDropdown,
  getAlertListModelStatusDropdownSuccess,
  getAlertListModelStatusDropdownFailure,
  //affiliate Page
  getAffiliateTopBar,
  getAffiliateDetails,
  // Plant Page
  getPlantTopBar,
  getPlantDetails,
  getPlantDetailsEmpty,
  //Home Page
  getGlobalTopBarSummary,
  getGlobalTopBarSummarySuccess,
  getGlobalTopBarSummaryFailure,
  getGlobalMapSummaryByUserId,
  getGlobalMapSummaryByUserIdSuccess,
  getGlobalMapSummaryByUserIdFailure,
  getGlobalRegionMapSummaryByUserId,
  getGlobalRegionMapSummaryByUserIdSuccess,
  getGlobalRegionMapSummaryByUserIdFailure,
  //Admin Configuration
  getAffiliateRollout,
  getAffiliateRolloutSuccess,
  getAffiliateRolloutFailure,
  getPlantRollout,
  getPlantRolloutSuccess,
  getPlantRolloutFailure,
  updateAffiliateRollout,
  updateAffiliateRolloutSuccess,
  updateAffiliateRolloutFailure,
  updatePlantRollout,
  updatePlantRolloutSuccess,
  updatePlantRolloutFailure,
  getAssetModelConfigTableData,
  getAssetModelConfigTableDataSuccess,
  getAssetModelConfigTableDataFailure,
  updateAssetModelConfigTableStatus,
  updateAssetModelConfigTableStatusSuccess,
  updateAssetModelConfigTableStatusFailure,
  getExceptionLog,
  getExceptionLogSuccess,
  getExceptionLogFailure,
  getRoleMappingRoleDropdownList,
  getRoleMappingRoleDropdownListSuccess,
  getRoleMappingRoleDropdownListFailure,
  getRoleMappingPlantDropdownList,
  getRoleMappingPlantDropdownListSuccess,
  getRoleMappingPlantDropdownListFailure,
  getRoleMappingAffiliateDropdownList,
  getRoleMappingAffiliateDropdownListSuccess,
  getRoleMappingAffiliateDropdownListFailure,
  addRoleMapping,
  addRoleMappingSuccess,
  addRoleMappingFailure,
  updateRoleMapping,
  updateRoleMappingSuccess,
  updateRoleMappingFailure,
  getRoleMappingWorklist,
  getRoleMappingWorklistSuccess,
  getRoleMappingWorklistFailure,
  getEmployeeList,
  getEmployeeListSuccess,
  getEmployeeListFailure,
  //Asset model config dropdown
  getAssetModelConfigDropdownList,
  getAssetModelConfigDropdownListSuccess,
  getAssetModelConfigDropdownListFailure,
  getAssetModelConfigAffiliateDropdownList,
  getAssetModelConfigAffiliateDropdownListSuccess,
  getAssetModelConfigAffiliateDropdownListFailure,
  getAssetModelConfigPlantDropdownList,
  getAssetModelConfigPlantDropdownListSuccess,
  getAssetModelConfigPlantDropdownListFailure,
  //Alert Statistics
  getPlantUtilizationTime,
  getPlantUtilizationTimeSuccess,
  getPlantUtilizationTimeFailure,
  ///Refesh Workflow
  setRefreshPmtPage,
  setRefreshAlertListPage,
  setRefreshMyTaskPage,
  updateAffiliateRolloutStatus,
  updatePlantRolloutStatus,
  addRoleMappingStatus,
  updateRoleMappingStatus,
  updateAssetModelConfigResponseStatus,
  getPlantAlertStatus,

  getPlantAlertListStateDropdownList,
  getPlantAlertListStateDropdownListSuccess,
  getPlantAlertListStateDropdownListFailure,

  getExceptionLogById,
  getExceptionLogByIdSuccess,
  getExceptionLogByIdFailure,

  getPlantDepartmentStatus,

  getPlantAlertListDepartmentDropdownList,
  getPlantAlertListDepartmentDropdownListSuccess,
  getPlantAlertListDepartmentDropdownListFailure,
  //Plant Shutdown
  getPlantShutdown,
  getPlantShutdownSuccess,
  getPlantShutdownFailure,

  getAlertBreadCrumbs,
  getAlertBreadCrumbsSuccess,
  getAlertBreadCrumbsFailure,
  getAlertBreadCrumbsEmpty,

  //spare parts
  getSparePartsSAP,
  getSparePartsSAPSuccess,
  getSparePartsSAPFailure,
  getSparePartsSensor,
  getSparePartsSensorSuccess,
  getSparePartsSensorFailure,
  getSparePartsSAPDropdown,
  getSparePartsSAPDropdownSuccess,
  getSparePartsSAPDropdownFailure,
  updateSparePartsSap,
  updateSparePartsSapSuccess,
  updateSparePartsSapFailure,
  updateSparePartsSapResponse,
  userProfileActive,
   //work flow page
  getIBMAlertDetailsByAlertId,
  getIBMAlertDetailsByAlertIdSuccess,
  getIBMAlertDetailsByAlertIdFailure,
  getConsultSomeone,
  getConsultSomeoneSuccess,
  getConsultSomeoneFailure,
  //Utilization Report Year Month
  getAlertManagementYearDropdown,  
  getAlertManagementYearDropdownSuccess,  
  getAlertManagementYearDropdownFailure, 
  getAlertManagementMonthDropdown,  
  getAlertManagementMonthDropdownSuccess,  
  getAlertManagementMonthDropdownFailure,

} = CommonSlice.actions;

export default CommonSlice.reducer;
