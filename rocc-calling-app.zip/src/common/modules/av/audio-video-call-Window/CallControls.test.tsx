/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import { ECallOptions } from "../types"
import CallControls from "./CallControls"

jest.mock("../../../helpers/helpers", () => ({
    getCustomrReducerFromGlobalStore: () => ({
        rooms: {},
        locations: {}
    }),
}))

jest.mock("../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({
        connectedCallDetails: {
            participants: [{
                name: "Test name",
                uuid: 1345,
                callStatus: "CALL_ACCEPT",
            }],
        },
        videoSource: "videoSource",
        currentUser: { uuid: "uuid" },
        volume: 100,
        numOfParticipants: 2,
        permissions: {
            CALL_VIDEO_CALL: true,
        },
    }),
    useDispatch: () => void (0),
}))

describe("CallControls component", () => {
    let wrapper: any
    let props: any

    beforeEach(() => {
        props = {
            activeCall: {
                isMuted: false,
                isDeafened: false,
            },
            activeRoom: {
                localParticipant: {
                    videoTracks: {
                        values: jest.fn().mockReturnValue([
                            {
                                track: {
                                    disable: jest.fn(),
                                    stop: jest.fn(),
                                }
                            }
                        ]),
                    },
                    unpublishTracks: jest.fn(),
                },
                participants: [{ identity: "uuid" }],
                disconnect: jest.fn(),
            },
            videoStatus: true,
            callDuration: {},
            previewTracks: null,
            cssStyleClass: {},
            selectedOption: ECallOptions,
            setVideoStatus: jest.fn(),
            setSelectedOption: jest.fn(),
        }

    })
    it("should render ToggleLocalVideo, ToggleLocalAudio, ToggleLocalVolume, settings icon, end call icon", () => {
        withHooks(() => {
            wrapper = shallow(<CallControls {...props} />)
            expect(wrapper.find("CallWindowFooter")).toHaveLength(1)
            const callWindowFooter = wrapper.find("CallWindowFooter")
            expect(callWindowFooter.prop("videoStatus")).toBeTruthy()
            expect(callWindowFooter.prop("callWindowFullscreen")).toBeUndefined()
            expect(callWindowFooter.prop("microphoneStatus")).toBeDefined()
            expect(callWindowFooter.prop("audioOutputStatus")).toBeDefined()
            expect(callWindowFooter.prop("toggleParticipants")).toEqual(expect.any(Function))
        })
    })
})
