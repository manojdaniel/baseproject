import React, { useEffect, useState } from "react";
import { Button, Table, Tooltip } from "antd";
import { useNavigate } from "react-router-dom";
import "../../../assets/common/CommonTables.scss";
import moment from "moment";
import Link from "antd/es/typography/Link";

interface Props {
	data: any[];
	plantName: string;
	handleUpdate: any;
	userId: any;
}
const PlantAlertList = ({ data, plantName, handleUpdate, userId }: Props) => {
	const navigate = useNavigate();
	const [getPlantAlertList, setPlantAlertList] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				timeStamp: moment(new Date(`${item.timeStamp}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				assetId: item.assetId,
				alertId: (
					<Link onClick={() => viewAlert(item.assetId, item.alertId)}>{item.alertId}</Link>
				),
				description: item.description,
				status: item.status,
				recommendation: item.recommendation,
				TakeAction:
					userId === item.taskAssignedTo ? (
						<Link onClick={() => takeAction(item.alertId)}>Take Action</Link>
					) : (
						<button className="cust-button-disabled" disabled>
							Take Action
						</button>
					),
				ViewAlert: (
					<Link onClick={() => viewPlot(item.assetId)}>View Alert</Link>
				),
			};
		});
		setPlantAlertList(mydata);
	}, [data]);

	const takeAction = (alertId) => {
		handleUpdate("takeAction", 0, alertId);
	};

	const viewPlot = (assetId) => {
		//alert(assetId)
		// navigate(`/assets/plots`);
		handleUpdate("viewPlot", assetId, 0);
	};

	const viewAlert = (assetId, alertId) => {
		//alert(assetId)
		// navigate(`/assets/plots`);
		handleUpdate("viewAlert", assetId, alertId);
	};

	const getTooltipContent = (gettooltip: any) => {
		try {
			const getRecommendation = getPlantAlertList.filter(
				({ alertId }) => alertId === gettooltip
			);

			const getmsg = getRecommendation[0].recommendation;
			const replacenum = getmsg.replace(/[0-9]/g, "");
			const splitvalue = replacenum.split(".");
			const getTooltipAr = splitvalue.filter(function (v: any) {
				return v !== " ";
			});
			const getTooltipArFinal = getTooltipAr.filter((item) => item);
			return getTooltipArFinal.map((item: any, index: any) => (
				<div key={index + 1}>
					<span>{index + 1}.</span>
					<span>{item}</span>
				</div>
			));
		} catch (error) {}
	};

	const columns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: "15%",
		},
		{
			title: "ASSET ID",
			dataIndex: "assetId",
			key: "assetId",
			width: "12%",
		},
		{
			title: "ALERT ID",
			dataIndex: "alertId",
			key: "alertId",
			width: "12%",
			render: (alertId: any) => (
				<Tooltip title={getTooltipContent(alertId)}>{alertId}</Tooltip>
			),
		},
		{
			title: "ALERT DESCRIPTION",
			dataIndex: "description",
			key: "description",
			width: "15%",
		},
		{
			title: "ALERT STATUS",
			dataIndex: "status",
			key: "status",
			width: "11%",
			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
		{
			title: "TAKE ACTION",
			dataIndex: "TakeAction",
			key: "TakeAction",
			width: "12.5%",
		},
		{
			title: "VIEW ALERT",
			dataIndex: "ViewAlert",
			key: "ViewAlert",
			width: "12.5%",
		},
	];

	const columns35 = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: "15%",
		},
		{
			title: "ASSET ID",
			dataIndex: "assetId",
			key: "assetId",
			width: "10%",
		},
		{
			title: "ALERT ID",
			dataIndex: "alertId",
			key: "alertId",
			width: "15%",
			render: (alertId: any) => (
				<Tooltip title={getTooltipContent(alertId)}>{alertId}</Tooltip>
			),
		},
		{
			title: "ALERT DESCRIPTION",
			dataIndex: "description",
			key: "description",
			width: "15%",
		},
		{
			title: "ALERT STATUS",
			dataIndex: "status",
			key: "status",
			width: "15%",
			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
		{
			title: "TAKE ACTION",
			dataIndex: "TakeAction",
			key: "TakeAction",
			width: "15%",
		},
		{
			title: "VIEW ALERT",
			dataIndex: "ViewAlert",
			key: "ViewAlert",
			width: "15%",
		},
	];
	const mobileColumns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: 80,
		},
		{
			title: "ASSET ID",
			dataIndex: "assetId",
			key: "assetId",
			width: 70,
		},
		{
			title: "ALERT ID",
			dataIndex: "alertId",
			key: "alertId",
			width: 100,
			render: (alertId: any) => (
				<Tooltip title={getTooltipContent(alertId)}>{alertId}</Tooltip>
			),
		},
		{
			title: "ALERT DESCRIPTION",
			dataIndex: "description",
			key: "description",
			width: 100,
		},
		{
			title: "ALERT STATUS",
			dataIndex: "status",
			key: "status",
			width: 70,
			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
		{
			title: "TAKE ACTION",
			dataIndex: "TakeAction",
			key: "TakeAction",
			width: 120,
		},
		{
			title: "VIEW ALERT",
			dataIndex: "ViewAlert",
			key: "ViewAlert",
			width: 100,
		},
	];
	return (
		<div id="pmt-alert-list">
			<div className="pmt-padding">
				<div className="title">PLANT ALERT LIST</div>
				<div className="pmt-filter">
					<div className="pmt-asset-name">{plantName}</div>
				</div>

				{(() => {
					if (currentScreenWidth > 3500) {
						return (
							<Table
								columns={columns35}
								dataSource={getPlantAlertList}
								tableLayout="fixed"
								pagination={false}
								scroll={{ x: true, y: 100 }}
							/>
						);
					} else if (currentScreenWidth > 1200) {
						return (
							<Table
								columns={columns}
								dataSource={getPlantAlertList}
								tableLayout="fixed"
								pagination={false}
								scroll={{ x: true, y: 100 }}
							/>
						);
					} else {
						return (
							<Table
								columns={mobileColumns}
								tableLayout={undefined}
								dataSource={getPlantAlertList}
								pagination={false}
								scroll={{ x: "620px", y: 100 }}
							/>
						);
					}
				})()}
			</div>
		</div>
	);
};

export default PlantAlertList;
