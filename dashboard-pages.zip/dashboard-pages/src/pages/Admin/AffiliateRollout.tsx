import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import AffiliateRolloutTable from "table/AffiliateRolloutTable";
import {
	getAffiliateRollout,
	updateAffiliateRollout,
	updateAffiliateRolloutStatus,
} from "../../redux/reducers/CommonReducer";
import PushNotification from "components/PushNotification";
import Loader from "components/Loader";

const AffiliateRollout = () => {
	let dispatch = useDispatch();
	const [loading, setLoading] = useState<any>(false);
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);
	const {
		affiliateRolloutData,
		loadingAffiliateRollout,
		affiliateRolloutStatus,
	} = useSelector((state: any) => ({
		affiliateRolloutData: state.Common.affiliateRollout,
		loadingAffiliateRollout: state.Common.loadingAffiliateRollout,
		affiliateRolloutStatus: state.Common.affiliateRolloutStatus,
	}));
	const dataupdate = [
		{
			retVal: 1,
			retMsg: "Affiliate Update Successful",
		},
	];

	useEffect(() => {
		if (affiliateRolloutData.length > 0) {
			setParentData(affiliateRolloutData);
			setData(affiliateRolloutData);
		}
	}, [affiliateRolloutData]);

	useEffect(() => {
		if (affiliateRolloutStatus.length > 0) {
			if (!affiliateRolloutStatus.hasOwnProperty("Succeeded")) {
				if (affiliateRolloutStatus[0].retVal === 1) {
					PushNotification("success", affiliateRolloutStatus[0].retMsg);
				} else {
					PushNotification("error", affiliateRolloutStatus[0].retMsg);
				}
			} else {
				PushNotification("error", affiliateRolloutStatus.Message);
			}
			const emptyObj = [];
			dispatch(updateAffiliateRolloutStatus(emptyObj));
		} else {
			if (affiliateRolloutStatus.hasOwnProperty("Succeeded")) {
				PushNotification("error", affiliateRolloutStatus.Message);
			}
		}
		dispatch(getAffiliateRollout(""));
	}, [affiliateRolloutStatus]);

	const handleUpdate = (affiliateID, isRollout) => {
		setLoading(true);
		let affilliatedata = {
			affilliateId: affiliateID,
			isRollout: isRollout,
		};
		dispatch(updateAffiliateRollout(affilliatedata));
		dispatch(getAffiliateRollout(""));
		setLoading(false);
	};

	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9- ]+$/i.test(keyValue)) event.preventDefault();
	};
	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.affiliateName !== null &&
				item.affiliateName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.countryName !== null &&
				item.countryName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.abbreviation !== null &&
				item.abbreviation
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.lattitude !== null &&
				item.lattitude
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.longitude !== null &&
				item.longitude
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};
	return (
		<div id="affiliate-rollout">
			{loading ? <Loader /> : null}
			<div id="new-filter" className="mt0">
				<div className="nf-left">
					<div className="title">AFFILIATE ROLLOUT</div>
					<div className="asset-name"></div>
				</div>
				<div className="nf-right">
					<div className="rightsearch">
						<input
							type="search"
							value={query}
							onChange={handleChange}
							placeholder="Search..."
							onKeyPress={handleKeyPress}
							onPaste={handleKeyPress}
						/>
					</div>
				</div>
			</div>
			<div className="common-box-content">
				{loadingAffiliateRollout ? (
					<Loader />
				) : (
					<AffiliateRolloutTable data={data} handleUpdate={handleUpdate} />
				)}
			</div>
		</div>
	);
};
export default AffiliateRollout;
