"""
 Created on Fri Oct 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import SITES_DICT
from src.constants.enums import ESummaryStates
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.validation_service.site_data_validation_service import check_if_site_exists
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("SiteDataValidation")


class SiteDataValidation():

    def __init__(self, service_token, org_infra_uuid):
        LOG.info("Validating Site data")
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)

    def check_site_exists(self, site_dict):
        try:
            new_sites = self._transaction_data["summary"]["sites"]["new"]
            for site_identifier, site_detail in site_dict.items():
                if site_identifier in new_sites:
                    response = check_if_site_exists(client=self._client, site_identifier=site_identifier, site_info=site_detail)
                    if not response:
                        self._transaction_data = update_summary_for_entity(self._transaction_data, "sites", site_identifier, ESummaryStates.NEW)
                        LOG.info(f"Site Information for site {site_identifier} is not present in DB")
                        site_detail["isPresent"] = False
                    else:
                        LOG.info(f"Site Information for site {site_identifier} is present in DB")
                else:
                    LOG.info(f"This site {site_identifier} is not a new site, skipping validation ..!")
            return site_dict, self._transaction_data
        except Exception as e:
            LOG.error(f"Error occured while checking if sites exist {e}")

    def initiate_data_validation(self, data_dict, transaction_data):
        """
        1. with data_dict. Iterate and see if all records are present in DB
        2. Make a separate dict(summanry_dict) with invalid records
        3. Return the dict back to job
        """
        try:
            self._site_dict = data_dict[SITES_DICT]
            self._transaction_data = transaction_data
            self._site_dict, self._transaction_data = self.check_site_exists(site_dict=self._site_dict)
            LOG.info("Site Data validation is complete ..!!")
            return data_dict, self._transaction_data
        except Exception as e:
            LOG.error(f"Error while validation sites {e}")
