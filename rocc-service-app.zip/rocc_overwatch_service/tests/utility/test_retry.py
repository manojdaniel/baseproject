"""
 Created on Tue Sep 28 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import unittest

from src.utility.retry import get_retrying_options

class RetryTestCase(unittest.TestCase):

    def test_get_retrying_options_throw_error(self):
        self.assertRaises(Exception,get_retrying_options,"option_list")
