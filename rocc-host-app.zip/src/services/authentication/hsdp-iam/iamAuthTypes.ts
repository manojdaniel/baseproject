/*
* Created on Wed Aug 03 2022
*
* Copyright (c) 2022 Philips
* (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
* Reproduction or transmission in whole or in part, in any form or by any
* means, electronic, mechanical or otherwise, is prohibited without the prior
* written consent of the copyright owner.
*/

export enum EAuthState {
    DEFAULT = "DEFAULT",
    INIT = "INIT",
    ERROR = "ERROR",
    SHOW_LOGIN = "SHOW_LOGIN",
    VAL_CRED = "VAL_CRED",
    COLLECT_DEVICE_INFO = "COLLECT_DEVICE_INFO",
    MATCH_DEVICE_INFO = "MATCH_DEVICE_INFO",
    SHOW_SERVER_OTP = "SHOW_SERVER_OTP",
    VALIDATE_SERVER_OTP = "VALIDATE_SERVER_OTP",
    GET_SERVER_OTP = "GET_SERVER_OTP",
    CALL_AUTHORIZE = "CALL_AUTHORIZE",
    REDIRECT = "REDIRECT",
    SUCCESS = "SUCCESS"
}

export const OTP_MAXIMUM_ATTEMPTS = 3

export enum EIamResponseStatus {
    SUCCESS = "success",
    ERROR = "error"
}

export enum ROCC_IAM_EVENTS {
    SET_ERR_MSG = "iam:setErrorMssg",
    SET_LOADING = "iam:setLoading"
}

export enum EIamErrorTypes {
    UNAUTHORIZED = "unauthorized",
    DEVICE_VERIFICATION_FAILED = "deviceVerifactionFailed",
    OTP_VERIFY_FAILED = "otpVerificationFailed",
    OTP_LIMIT_EXCEEDED = "otpAttemptError"
}
export interface IAuthInitResponse {
    data: [{
        type: "authId"
        value: string
    }]
    hint: EAuthState.SHOW_LOGIN | EAuthState.CALL_AUTHORIZE | EAuthState.ERROR
}

export interface IAuthLogin {
    loginId: string
    password: string
    authId: string
    hint: EAuthState.VAL_CRED
}

export interface IAuthLoginResponse {
    data: [{
        type: "authId"
        value: string
    }]
    hint: EAuthState.COLLECT_DEVICE_INFO | EAuthState.ERROR | EAuthState.CALL_AUTHORIZE
}

export interface IAuthDeviceInfo {
    deviceDetails: any
    authId: string
    hint: EAuthState.MATCH_DEVICE_INFO
}

export interface IAuthDeviceInfoResponse {
    data: [{
        type: "authId"
        value: string
    }]
    hint: EAuthState.SHOW_SERVER_OTP | EAuthState.ERROR
}

export interface IAuthOtp {
    authId: string
    otp: string
    hint: EAuthState.VALIDATE_SERVER_OTP
    trustDevice: "1" | "0"
}

export interface IAuthOtpResponse {
    data: any[]
    hint: EAuthState.CALL_AUTHORIZE | EAuthState.SHOW_SERVER_OTP | EAuthState.ERROR
}

export interface IAuthGetOtp {
    authId: string
    hint: EAuthState.GET_SERVER_OTP | EAuthState.ERROR
}

export interface IAuthResponse {
    data: any[]
    hint: EAuthState.REDIRECT | EAuthState.ERROR | EAuthState.SHOW_LOGIN
}
