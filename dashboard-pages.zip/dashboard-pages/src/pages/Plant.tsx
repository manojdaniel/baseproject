import React, { useRef, useState, useEffect } from "react";
import "./Plant.scss";
import MenuContainer from "components/MenuContainer";
import PmtDashboard from "./PlantPage/PmtDashboard";
import AlertSatistics from "./PlantPage/AlertSatistics";
import Status from "components/Status";
import { useDispatch, useSelector } from "react-redux";
// import { getStatusAssetPmtByPlantId, getTopBarToolTipbyPlantId } from "../redux/reducers/CommonReducer";
import { useNavigate, useLocation } from "react-router-dom";
import { Outlet } from "react-router-dom";
import Dropdown from "components/Dropdown";
import ListComponent from "components/ListComponent";
import HealthIndexComponent from "components/HealthIndexComponent";
import {
	getGlobalSelecetedAsset,
	getPlantAlertStatus,
	getPlantDepartmentStatus,
} from "../redux/reducers/CommonReducer";
import Loader from "components/Loader";

const PLANT_MENU_DATA = [
	{ id: "pmt", value: "PMT" },
	{ id: "alertSatistics", value: "ALERT STATISTICS" },
	{ id: "modelPerformance", value: "MODEL PERFORMANCE" },
	{ id: "alertManagementPage", value: "ALERT MANAGEMENT" },
	{ id: "pmCompliance", value: "PM COMPLIANCE" },
];

const Plant = () => {
	let dispatch = useDispatch();
	const location = useLocation();

	const { statusAssetPmtByPlantId, topBarToolTipbyPlantId,
		searchValue,
		loadingStatusAssetPmtByPlantId } =
		useSelector((state: any) => ({
			statusAssetPmtByPlantId: state.Common.statusAssetPmtByPlantId,
			topBarToolTipbyPlantId: state.Common.topBarToolTipbyPlantId,
			searchValue: state.Common.searchValue,

			loadingStatusAssetPmtByPlantId: state.Common.loadingStatusAssetPmtByPlantId,
		}));

	let navigate = useNavigate();

	useEffect(() => {
		//  handleMenuClick("pmt")
	}, []);

	// const [elements, setElements] = useState(PLANT_MENU_DATA);
	const [selectedID, setSelectedID] = useState(1);

	const handleMenuClick = (id: any) => {
		setSelectedID(id);
		switch (id) {
			case "pmt":
				navigate("/plant/pmt");
				break;
			case "alertSatistics":
				navigate("/plant/alertSatistics/alertDashboard");
				break;
			case "modelPerformance":
				navigate("/plant/modelPerformance");
				break;
			case "alertManagementPage":
				navigate("/plant/alertManagementPage");
				break;
			case "pmCompliance":
				navigate("/plant/pmCompliance");
				break;

			default:
				break;
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	let currentPathname = location.pathname.split("/")[2];

	const getSelectedclassName = (id: any) =>
		currentPathname === id ? "active" : "notselected";

	const goAssetModelPageFromPMTStatus = (assetId: any) => {
		if (assetId !== "") {
			dispatch(getGlobalSelecetedAsset({ value: assetId, label: assetId }));
			navigate("/assets/assetModel");
		}
	};

	const navigateActiveUIOIPMT = (data: any) => {
		dispatch(getPlantAlertStatus({ value: data, label: data }));
		dispatch(getPlantDepartmentStatus({ value: 0, label: "All" }));
		navigate(`/plant/alertSatistics/alertList`);
	};

	useEffect(() => {
		if (location.pathname.split("/")[2] === undefined) {
			if (location.pathname.split("/")[1] === "plant") {
				navigate("/plant/pmt");
			}
		}
	}, [location.pathname]);

	return (
		<>
			{loadingStatusAssetPmtByPlantId ? (
				<Loader />
			) : (
				<Status
					data={statusAssetPmtByPlantId}
					page={"PLANT"}
					healthIndexToolTip={topBarToolTipbyPlantId}
					goAssetModelPageFromPMTStatus={goAssetModelPageFromPMTStatus}
					navigateActiveUIOIPMT={navigateActiveUIOIPMT}
				/>
			)}
			<MenuContainer
				data={PLANT_MENU_DATA}
				handleMenuClick={handleMenuClick}
				getSelectedclassName={getSelectedclassName}
			/>
			<Outlet />
		</>
	);
};

export default Plant;

{
	/* <div>{searchValue.id}</div> */
}
{
	/* {renderStep()} */
}
/* <div>
				<div>
					<div>
						Gobal Plant List
						<Dropdown
							name={"Asset Id"}
							options={[{ "value": "2Y-3001A", "label": "2Y-3001A" }]}
						/>
						<Dropdown
							name={"Asset Id"}
							options={[{ "value": "2Y-3001A", "label": "2Y-3001A" }]}
						/>
						<ListComponent />
					</div>
				</div>
				<div>
					Plant Health Index
					<HealthIndexComponent />
				</div>
			</div> 
	    
	const renderStep = () => {
		switch (selectedID) {
			case 1:
				return (
					<PmtDashboard
					/>
				)
			case 2:
				return (
					<AlertSatistics
					/>
				)

			default:
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>
		}
	}
}
// const PLANT_MENU_DATA = [
//     { id: 1, value: "PMT" },
//     { id: 2, value: "ALERT STATISTICS" },
//     { id: 3, value: "MODEL PERFORMANCE" },
//     { id: 4, value: "ALERT MANAGEMENT PAGE" },
//     { id: 5, value: "PM COMPLIANCE" },
// ];
*/
