/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, extractClinicalRoleFromAllRoles, getEClinicalRoleFromDBRole, IUserInfo } from "@rocc/rocc-client-services"
import { COLUMN_SEPERATOR, ROW_SEPERATOR } from "../../constants/constants"
import { EUserPresence } from "../../types/types"

export const getCurrentUserInfoTransformer = (props: any, userEmail: string, prevCurrentUserDetails: any) => {
    const currentUser: IUserInfo = {
        id: "", uuid: "", siteId: [], orgId: "", status: EUserPresence.AVAILABLE,
        name: "", phoneNumber: "", clinicalRole: EClinicalRole.DEFAULT, email: userEmail, username: userEmail,
        accessToken: "", accessTokenExpiryTime: "", onBoarded: false, presenceMapId: "", sessionId: "", locale: "",
        roomName: "", description: "",
        allRoles: [], modalities: [], kvmUsername: "", secondaryName: "", secondaryUUID: "",
    }
    let orgIdentifier = ""
    const { employeeDetails } = props
    if (employeeDetails && employeeDetails.length) {
        currentUser.id = employeeDetails[0].user_id
        currentUser.email = employeeDetails[0].user_email_id
        currentUser.uuid = employeeDetails[0].user_hsdp_uuid
        currentUser.orgId = employeeDetails[0].org_id
        orgIdentifier = employeeDetails[0].org_identifier
        currentUser.name = employeeDetails[0].display_name
        currentUser.phoneNumber = employeeDetails[0].user_primary_phone
        currentUser.onBoarded = employeeDetails[0].web_onboarding
        currentUser.kvmUsername = employeeDetails[0].kvmUserName
        if (!currentUser.uuid && prevCurrentUserDetails && prevCurrentUserDetails.uuid) {
            currentUser.uuid = prevCurrentUserDetails.uuid
        }
        const sites: string[] = employeeDetails[0].sites.split(ROW_SEPERATOR)
        const roles: [] = employeeDetails[0].roles.split(",")
        const modalities: string[] = employeeDetails[0].modality.split(",")

        sites && sites.forEach((site: any) => {
            currentUser.siteId.push(site.split(COLUMN_SEPERATOR)[0])
        })

        modalities && modalities.forEach((modality: any) => {
            currentUser.modalities.push(modality.split(COLUMN_SEPERATOR)[1])
        })

        roles && roles.forEach((role: any) => {
            currentUser.allRoles = [...currentUser.allRoles, ...getEClinicalRoleFromDBRole(role.split(COLUMN_SEPERATOR)[1])]
        })
        currentUser.allRoles = [...new Set(currentUser.allRoles)]
        currentUser.clinicalRole = extractClinicalRoleFromAllRoles(currentUser.allRoles)
    }
    return { currentUser, orgIdentifier }
}
