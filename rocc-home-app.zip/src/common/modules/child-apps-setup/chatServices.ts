/*
 * Created on Mon Sep 19 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse } from "@rocc/rocc-client-services"
import { ICommsTokenFunction } from "@rocc/rocc-chat-library"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { API_CONSTANTS, CURRENT_APP_NAME, HTTP_STATUS } from "../../../constants/constants"
import { postService } from "../../helpers/apicall"

export const fetchCommunicationTokenService = async (url: string, token: string, userId: string): Promise<ICommsTokenFunction> => {
    let tokenDetails = { communicationToken: "", channelSid: "" }
    let status = EResponse.ERROR
    try {
        const response = await postService({
            url: `${url}/Token`,
            headers: {
                [API_CONSTANTS.ACCEPT]: API_CONSTANTS.APPLICATION_JSON,
                [API_CONSTANTS.CONTENT_TYPE]: API_CONSTANTS.APPLICATION_JSON,
                [API_CONSTANTS.AUTHORIZATION]: token,
                [API_CONSTANTS.API_VERSION]: API_CONSTANTS.API_VERSION_1_0_0
            },
            body: {
                userId,
                tokenType: "CHAT"
            }
        })
        if (HTTP_STATUS.OK === response.status) {
            tokenDetails = {
                communicationToken: response.data.twillioAccessToken,
                channelSid: response.data.channelSid,
            }
            status = EResponse.SUCCESS
            errorLogger(`For user: ${userId}, in app: ${CURRENT_APP_NAME}, creation of Twilio token is successfull`)
            return { status, tokenDetails }
        }
    } catch (error) {
        errorLogger(`For user: ${userId}, in app: ${CURRENT_APP_NAME}, Twilio token failed with error: ${errorParser(error)}`)
    }
    return { status, tokenDetails }
}
