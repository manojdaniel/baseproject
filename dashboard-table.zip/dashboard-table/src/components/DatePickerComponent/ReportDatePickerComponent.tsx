import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

interface Props {
	handleDateChange: any;
	selectedDate: any;
}

const ReportDatePickerComponent = ({
	selectedDate,
	handleDateChange,
}: Props) => {
	return (
		<DatePicker
			maxDate={new Date()}
			dateFormat={"dd/M/yyyy"}
			selected={selectedDate}
			onChange={handleDateChange}
			inline
		/>
	);
};

export default ReportDatePickerComponent;
