/*
 * Created on Tue May 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { UPDATE_FEATURE_FLAGS, UPDATE_FEATURE_FLAG_CONFIGS, UPDATE_DEFAULT_FLAGS } from "../actions/types"
import featureFlagsReducer, { initialFeatureFlagReducer } from "./featureFlagsReducer"

describe("Feature Flags reducer", () => {

    it("should handle UPDATE_FEATURE_FLAGS", () => {

        const updateFlags = featureFlagsReducer(initialFeatureFlagReducer, {
            type: UPDATE_FEATURE_FLAGS,
            featureFlags: { FLAG_SELF_SERVICE: true }
        })

        expect(updateFlags).toEqual(
            { FLAG_SELF_SERVICE: true, ...initialFeatureFlagReducer }
        )
    })

    it("should handle UPDATE_FEATURE_FLAG_CONFIGS", () => {
        expect(
            featureFlagsReducer(initialFeatureFlagReducer, {
                type: UPDATE_FEATURE_FLAG_CONFIGS,
                featureFlagConfig: { "provider": { "configuration": { "clientId": "60058a077337f70a60e8bbdf" }, "type": "LD" } }
            })
        ).toEqual(
            { ...initialFeatureFlagReducer, "provider": { "configuration": { "clientId": "60058a077337f70a60e8bbdf" }, "type": "LD" } }
        )
    })

    it("should handle UPDATE_DEFAULT_FLAGS", () => {

        const defaultFlags = featureFlagsReducer(initialFeatureFlagReducer, {
            type: UPDATE_DEFAULT_FLAGS,
            defaultFeatureFlags: { "enabledFeatures": ["rocc-web-call"] }
        })

        expect(defaultFlags).toEqual(
            { ...initialFeatureFlagReducer, defaultFeatureFlags: { "rocc-web-call": true } }
        )
    })
})
