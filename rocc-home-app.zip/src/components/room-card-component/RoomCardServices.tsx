import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { postService } from "../../common/helpers/apicall"
import { MANAGE_GRAPHQL_EMPLOYEE_FAVOURITES, CONTENT_TYPE, APPLICATION_JSON } from "../../constants/constants"
import { ISetStarredRoom } from "../../redux/interfaces/types"

export const setStarredRoom = async (params: ISetStarredRoom) => {
    const { roomId, adminServiceUrl, metasiteId, isRoomStarred, userId, token } = params
    try {
        const response = await postService({
            url: `${adminServiceUrl}${MANAGE_GRAPHQL_EMPLOYEE_FAVOURITES}`,
            body: {
                resourceId: roomId,
                orgId: metasiteId,
                starred: isRoomStarred,
                employeeId: userId
            },
            headers: { [CONTENT_TYPE]: APPLICATION_JSON, Authorization: token },
        })
        return response
    } catch (error: any) {
        errorLogger(`Error updating starred attribute for room: ${roomId} : ${errorParser(error)}` )
        if (!error.response) {
            return { status: 500 }
        } else {
            return { status: error.response.status, message: error.response.message }
        }
    }
}
