import { render, screen, fireEvent } from '@testing-library/react';
import "@testing-library/jest-dom/extend-expect";
import Assets from './Assets';
import React from 'react';

jest.mock('react-router-dom', () => ({
  useNavigate: () => jest.fn(),
  Outlet: () => <div>Mocked Outlet</div>,
}));

describe('Assets', () => {
  it('should navigate to the correct URL when a menu item is clicked', () => {
    const navigate = jest.fn();
    jest.spyOn(require('react-router-dom'), 'useNavigate').mockReturnValue(navigate);

    render(<Assets />);

    // Click the "LiveTracking" menu item
    fireEvent.click(screen.getByText('LIVE TRACKING'));

    expect(navigate).toHaveBeenCalledWith('/assets/liveTracking');
  });

  it('should have AssetModel selected by default', () => {
    render(<Assets />);

    expect(screen.getByText('ASSET MODEL')).toHaveClass('active');
  });

  it('should switch the active menu item when a different menu item is clicked', () => {
    render(<Assets />);

    // Click the "LiveTracking" menu item
    fireEvent.click(screen.getByText('LIVE TRACKING'));

    expect(screen.getByText('LIVE TRACKING')).toHaveClass('active');
    expect(screen.getByText('ASSET MODEL')).not.toHaveClass('active');
  });

  it('should render the Outlet component', () => {
    render(<Assets />);

    expect(screen.getByText('Mocked Outlet')).toBeInTheDocument();
  });
});
