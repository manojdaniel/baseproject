import React from "react";
import ReactDOM from "react-dom";

const App = () => (
  <><div>
    <div>Dashboard Components Applications</div>
  </div></>
);
ReactDOM.render(<App />, document.getElementById("app"));
