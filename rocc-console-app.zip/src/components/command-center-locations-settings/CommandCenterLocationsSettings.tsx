/*
 * Created on Tue Nov 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { parseIntBase10 } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Input, InputOnChangeData, Radio } from "semantic-ui-react"
import { COMMAND_CENTER_LOCATION, COMMAND_CENTER_LOCATION_NAME, NO_COMMAND_CENTER_LOCATION } from "../../common/constants/constants"
import { getAnywhereLocationNameText } from "../../common/helpers/helpers"
import { updateCommandCenterSeat } from "../../redux/actions/consoleActions"
import { GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION } from "../../redux/actions/types"
import { ECommandCenterAccessMode, IStore } from "../../redux/interfaces/types"
import { initialStatesForConsole, INIT_WITHOUT_HARDWARE_COMMAND_CENTER_DETAILS } from "../../redux/reducers/consoleReducer"
import { dispatchToParentStore } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import { getCommandCenterLocationName, setLocalStorageItem } from "../command-center-locations-controller/CommandCenterLocationsControllerHelper"
import { clearCommandCenterSeatService, fetchCommandCenterService, fetchReceiverTransformer, getCommandCenterSeatService, getConsoleAccessMode, setCommandCenterSeatService, setConsoleAccessMode } from "./CommandCenterLocationsService"
import styles from "./CommandCenterLocationsSettings.scss"

const CommandCenterLocationsSettingsController = () => {
    const { currentUser, consoleSessions, consoleOperation } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser,
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation
    }))
    const initDefaultAccessMode = getConsoleAccessMode()
    const initLocation = getCommandCenterSeatService(currentUser.orgId)
    const regexWhiteSpace = /^\s*$/
    const { intl } = getIntlProvider()

    /* All command center seats from DB */
    const [commandCenterLocations, setcommandCenterLocations] = useState([])
    /* Access mode */
    const [commandCenter, setCommandCenter] = useState(initDefaultAccessMode)
    /* valid input command center seat object */
    const [inputCommandCenterSeat, setInputCommandCenterSeat] = useState(initLocation)
    const [inputCommandCenterDetails, setInputCommandCenterDetails] = useState(INIT_WITHOUT_HARDWARE_COMMAND_CENTER_DETAILS)
    /* Ongoing inputs for seatName */
    const [inputSeatName, setInputSeatName] = useState(initLocation.seatName)
    /* validation states */
    const [validationMessage, setValidationMessage] = useState(false)
    const [confirm, setConfirm] = useState(false)
    const [disableSubmitBtn, setDisableSubmitBtn] = useState(true)
    const [disableVerifyBtn, setDisableVerifyBtn] = useState(true)
    const [warning, setWarning] = useState(false)
    const [seatSelectConfirmMessage, setseatSelectConfirmMessage] = useState(false)
    const [disabledRadio, setDisabledRadio] = useState(false)

    const dispatch = useDispatch()


    useEffect(() => {
        const initDefaultSeats = async () => {
            const { orgId } = currentUser
            const metasiteId: number = parseIntBase10(orgId)
            setcommandCenterLocations(await fetchCommandCenterService(metasiteId))
        }
        initDefaultSeats()
        return (() => {
            dispatch(updateCommandCenterSeat(initialStatesForConsole.commandCenterDetails, true))
        })
    }, [])

    useEffect(() => {
        setDisabledRadio((consoleSessions && consoleSessions.length > 0) || consoleOperation.operationId !== "")
    }, [consoleSessions, consoleOperation])

    const withHardwareModeClick = () => {
        setConsoleAccessMode(COMMAND_CENTER_LOCATION)
        setCommandCenter(COMMAND_CENTER_LOCATION)
    }

    const withoutHardwareModeClick = () => {
        setConsoleAccessMode(NO_COMMAND_CENTER_LOCATION)
        setCommandCenter(NO_COMMAND_CENTER_LOCATION)
        clearCommandCenterSeatService()
        sendLogsToAzure({ contextData: { component: "Console service", event: `Hardware Settings set to NO Command Center` } })
        dispatch(updateCommandCenterSeat(INIT_WITHOUT_HARDWARE_COMMAND_CENTER_DETAILS, true))
        dispatchToParentStore({ type: GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, userLoggedInLocation: getAnywhereLocationNameText() })
        setLocalStorageItem(COMMAND_CENTER_LOCATION_NAME, getAnywhereLocationNameText())
        setseatSelectConfirmMessage(false)
    }

    const getRecievers = async (orgId: number, inputSeatName: string) => {
        const listRecievers = await fetchReceiverTransformer(orgId, inputSeatName)
        return listRecievers
    }

    const validateSeatName = () => {
        if (commandCenterLocations !== null) {
            commandCenterLocations.forEach(async (sLocation: any) => {
                if (sLocation.seatName === inputSeatName) {
                    const recieversList = await getRecievers(sLocation.orgId, inputSeatName)
                    setDisableSubmitBtn(false)
                    setValidationMessage(true)
                    setWarning(sLocation.registeredCount && sLocation.registeredCount > 0)
                    setInputCommandCenterSeat({ seatName: inputSeatName, dbOrgId: sLocation.orgId })
                    setInputCommandCenterDetails({
                        commandCenterSeat: {
                            seatName: inputSeatName,
                            organizationId: sLocation.orgId,
                            receivers: recieversList
                        },
                        initialised: ECommandCenterAccessMode.WITH_HARDWARE
                    })
                }
                setseatSelectConfirmMessage(false)
                setConfirm(true)
            })
        }
    }

    const onLocationConfirm = async () => {
        if (inputCommandCenterSeat.seatName !== null) {
            const loggedInlocation = getCommandCenterLocationName(commandCenterLocations, inputCommandCenterSeat.seatName)
            if (loggedInlocation) {
                dispatchToParentStore({ type: GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, userLoggedInLocation: loggedInlocation.commandCenterLocation })
                setLocalStorageItem(COMMAND_CENTER_LOCATION_NAME, loggedInlocation.commandCenterLocation)
            }
            setCommandCenterSeatService(inputCommandCenterSeat.seatName, inputCommandCenterSeat.dbOrgId)
            dispatch(updateCommandCenterSeat(inputCommandCenterDetails, true))
            setValidationMessage(false)
            setseatSelectConfirmMessage(true)
            sendLogsToAzure({ contextData: { component: "Console service", event: `ROCC seat confirmed` } })
            setConfirm(false)
        }
    }

    const handleInput = (e: React.ChangeEvent<HTMLInputElement>, data: InputOnChangeData) => {
        setInputSeatName(data.value)
        setValidationMessage(false)
        setDisableSubmitBtn(true)
        setConfirm(false)
        if (data && data.value && data.value !== "" && !regexWhiteSpace.test(data.value)) {
            setDisableVerifyBtn(false)
        } else { setDisableVerifyBtn(true) }
    }


    return (
        <div className={styles.commandCenterLocationSettingsRow}>
            <div className={"headerTitle"} id="headerTitle">
                {intl.formatMessage({ id: "content.commandCenterLocationsSettings.title", defaultMessage: en["content.commandCenterLocationsSettings.title"] })}
            </div>

            <div className={cx(styles.column)} id={"column"}>
                <label htmlFor="locale" className={styles.label}>
                    {intl.formatMessage({ id: "content.commandCenterLocationsSettings.accessMode", defaultMessage: en["content.commandCenterLocationsSettings.accessMode"] })}
                </label>

                {disabledRadio && <div className={styles.disabledMessage} id="disabledMessage">
                    {intl.formatMessage({ id: "content.commandCenterLocationsSettings.accessModeWarningMessage", defaultMessage: en["content.commandCenterLocationsSettings.accessModeWarningMessage"] })}
                </div>}
                <div className={cx(styles.checkBoxSection, disabledRadio ? styles.disabled : "")} id={"checkbox-section"}>
                    <div className={"accessmodecheckbox"} id={"accessmodecheckbox"}>
                        <Radio disabled={disabledRadio}
                            checked={(commandCenter === NO_COMMAND_CENTER_LOCATION) || (commandCenter === null)}
                            label={intl.formatMessage({ id: "content.radio.withoutHardware", defaultMessage: en["content.radio.withoutHardware"] })}
                            onClick={withoutHardwareModeClick}
                        />
                    </div>
                    <div className={"accessmodecheckbox"} id={"accessmodecheckbox"}>
                        <Radio disabled={disabledRadio}
                            checked={commandCenter === COMMAND_CENTER_LOCATION}
                            label={intl.formatMessage({ id: "content.radio.withHardware", defaultMessage: en["content.radio.withHardware"] })}
                            onClick={withHardwareModeClick}
                        />
                    </div>
                </div>
            </div>
            {
                (commandCenter === COMMAND_CENTER_LOCATION) ?
                    <>
                        <div className={cx(styles.column, "seat-selection")} id={"column"}>
                            <label htmlFor="locale" className={styles.label}>
                                {intl.formatMessage({ id: "content.locationSelection.locationLabel", defaultMessage: en["content.locationSelection.locationLabel"] })}
                            </label>
                            <Input
                                className={styles.commandCenterLocation}
                                placeholder={intl.formatMessage({ id: "content.placeholder.location", defaultMessage: en["content.placeholder.location"] })}
                                focus={true}
                                onChange={handleInput}
                                id="commandCenterLocation"
                                defaultValue={inputCommandCenterSeat.seatName}
                                disabled={disabledRadio}
                            />
                            <div className={"locationSubmit"}>
                                <Button
                                    id="submit"
                                    className={styles.proceed}
                                    secondary={true}
                                    onClick={validateSeatName}
                                    disabled={disableVerifyBtn}
                                >
                                    {intl.formatMessage({ id: "content.locationSelection.verify.Btn", defaultMessage: en["content.locationSelection.verify.Btn"] })}
                                </Button>

                                <Button
                                    id="confirm"
                                    className={styles.proceed}
                                    secondary={true}
                                    onClick={() => onLocationConfirm()}
                                    disabled={disableSubmitBtn}
                                >
                                    {intl.formatMessage({ id: "content.locationSelection.accessmode.confirm", defaultMessage: en["content.locationSelection.accessmode.confirm"] })}
                                </Button>
                            </div>
                            {validationMessage === false && confirm &&
                                <span className={styles.invalid} id="invalidLocationMessage">
                                    <span className={styles.invalidIcon}>&#33;</span>
                                    {intl.formatMessage({ id: "content.locationSelection.InvalidLocation", defaultMessage: en["content.locationSelection.InvalidLocation"] })}
                                </span>}
                            {validationMessage === true && confirm && <>
                                {warning ? <span className={styles.warning} id="warningMessage">
                                    <span className={styles.warningIcon}>&#33;</span>
                                    {intl.formatMessage({ id: "content.locationSelection.locationAlreadyInUse", defaultMessage: en["content.locationSelection.locationAlreadyInUse"] })}
                                </span> : <span className={styles.valid} id="validMessage">
                                    <span className={styles.validIcon}>&#10003;</span>
                                    {intl.formatMessage({ id: "content.locationSelection.ValidLocation", defaultMessage: en["content.locationSelection.ValidLocation"] })}
                                </span>}
                            </>}
                            {
                                seatSelectConfirmMessage && <span className={styles.valid} id="locationConfirmed">
                                    <span className={styles.validIcon}>&#10003;</span>
                                    {intl.formatMessage({ id: "content.locationSelection.locationConfirmed", defaultMessage: en["content.locationSelection.locationConfirmed"] })}
                                </span>}
                        </div>
                    </> : null
            }
        </div>
    )
}

export default CommandCenterLocationsSettingsController
