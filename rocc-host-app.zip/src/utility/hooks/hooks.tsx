import { IConsoleSession } from "@rocc/rocc-client-services"
import isEqual from "lodash.isequal"
import { useEffect, useState } from "react"

export const usePrevious = (curValue: any) => {
    const [preValue, setPreValue] = useState([] as IConsoleSession[])

    useEffect(() => {
        if (!isEqual(preValue, curValue))
            setPreValue(curValue)
    }, [curValue])

    return preValue
}
