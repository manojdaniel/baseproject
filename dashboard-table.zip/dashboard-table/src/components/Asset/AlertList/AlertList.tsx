import React, { useEffect, useState } from "react";
import { Table, Layout } from "antd";
import "../../../assets/common/CommonTables.scss";
import moment from "moment";
import Link from "antd/es/typography/Link";

interface Props {
	data: any[];
	loading: any;
	onClickPlotPage: any;
	onClickWorkFlowPage: any;
	userId: any;
}
const AlertList = ({
	data,
	loading,
	onClickPlotPage,
	onClickWorkFlowPage,
	userId,
}: Props) => {
	// Time Formate work :Start
	const [alertlist, setAlertlist] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);

		//userId === item.taskAssignedTo ? <Link onClick={() => takeAction(item.alertId)}>Take Action</Link> : ""
		let mydata = data.map(function (item: any) {
			return {
				TimeStamp: moment(new Date(`${item.timeStamp}`)).format(
					"DD/MM/YYYY HH:MM:SS A"
				),
				AlertId: item.alertId,
				ModelStatus: item.modelStatus,
				AlertStatus: item.alertStatus,
				ModelName: item.modelName,
				InfluencingSensor1: item.influencingSensor1,
				InfluencingSensor2: item.influencingSensor2,
				InfluencingSensor3: item.influencingSensor3,
				InfluencingSensor4: item.influencingSensor4,
				InfluencingSensor5: item.influencingSensor5,
				InfluencingSensor6: item.influencingSensor6,
				AssignedDepartment: item.assignedDepartment,
				TaskAssignedTo: item.taskAssignedTo,
				SensorgroupID: item.sensorGroupId,
				TakeAction:
					userId === item.taskAssignedTo ? (
						<div
							className="cust-button"
							onClick={() =>
								onClickWorkFlowPage(item.alertId, item.currentStage)
							}
						>
							Take Action
						</div>
					) : (
						<button disabled className="cust-button-disabled">
							Take Action
						</button>
					),
				ViewAlert: (
					<div className="cust-button" onClick={() => onClickPlotPage(item)}>
						View Alert
					</div>
				),
			};
		});
		setAlertlist(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "TIME STAMP",
			dataIndex: "TimeStamp",
			key: "TimeStamp",
			width: "8%",
		},
		{
			title: "ALERT ID",
			dataIndex: "AlertId",
			key: "AlertId",
			width: "7%",
			align: "center",
		},
		{
			title: "ALERT STATUS",
			dataIndex: "AlertStatus",
			key: "AlertStatus",
			width: "7%",
			align: "center",
		},
		{
			title: "MODEL DETAILS",
			width: "13%",
			children: [
				{
					title: "MODEL NAME",
					dataIndex: "ModelName",
					key: "ModelName",
				},
				{
					title: "MODEL STATUS",
					dataIndex: "ModelStatus",
					key: "ModelStatus",
				},
			],
		},
		{
			title: "INFLUENCING SENSOR",
			width: "40%",
			children: [
				{
					title: "1",
					dataIndex: "InfluencingSensor1",
					key: "InfluencingSensor1",
				},
				{
					title: "2",
					dataIndex: "InfluencingSensor2",
					key: "InfluencingSensor2",
				},
				{
					title: "3",
					dataIndex: "InfluencingSensor3",
					key: "InfluencingSensor3",
				},
				{
					title: "4",
					dataIndex: "InfluencingSensor4",
					key: "InfluencingSensor4",
				},
				{
					title: "5",
					dataIndex: "InfluencingSensor5",
					key: "InfluencingSensor5",
				},
				{
					title: "6",
					dataIndex: "InfluencingSensor6",
					key: "InfluencingSensor6",
				},
			],
		},
		{
			title: "ASSIGNED DEPARTMENT",
			dataIndex: "AssignedDepartment",
			key: "AssignedDepartment",
			width: "8%",
		},
		{
			title: "TASK ASSIGNED TO",
			dataIndex: "TaskAssignedTo",
			key: "TaskAssignedTo",
			width: "8%",
		},
		{
			title: "TAKE ACTION",
			dataIndex: "TakeAction",
			key: "TakeAction",
			width: "8%",
		},
		{
			title: "VIEW ALERT",
			dataIndex: "ViewAlert",
			key: "ViewAlert",
			width: "8%",
		},
	];
	const mobileColumns = [
		{
			title: "TIME STAMP",
			dataIndex: "TimeStamp",
			key: "TimeStamp",
			width: 100,
		},
		{
			title: "ALERT ID",
			dataIndex: "AlertId",
			key: "AlertId",
			width: 100,
		},
		{
			title: "ALERT STATUS",
			dataIndex: "AlertStatus",
			key: "AlertStatus",
			width: 100,
		},
		{
			title: "MODEL DETAILS",
			children: [
				{
					title: "MODEL NAME",
					dataIndex: "ModelName",
					key: "ModelName",
					width: 100,
				},
				{
					title: "MODEL STATUS",
					dataIndex: "ModelStatus",
					key: "ModelStatus",
					width: 100,
				},
			],
		},
		{
			title: "INFLUENCING SENSOR",
			children: [
				{
					title: "1",
					dataIndex: "InfluencingSensor1",
					key: "InfluencingSensor1",
					width: 150,
				},
				{
					title: "2",
					dataIndex: "InfluencingSensor2",
					key: "InfluencingSensor2",
					width: 150,
				},
				{
					title: "3",
					dataIndex: "InfluencingSensor3",
					key: "InfluencingSensor3",
					width: 150,
				},
				{
					title: "4",
					dataIndex: "InfluencingSensor4",
					key: "InfluencingSensor4",
					width: 150,
				},
				{
					title: "5",
					dataIndex: "InfluencingSensor5",
					key: "InfluencingSensor5",
					width: 150,
				},
				{
					title: "6",
					dataIndex: "InfluencingSensor6",
					key: "InfluencingSensor6",
					width: 150,
				},
			],
		},
		{
			title: "ASSIGNED DEPARTMENT",
			dataIndex: "AssignedDepartment",
			key: "AssignedDepartment",
			width: 150,
		},
		{
			title: "TASK ASSIGNED TO",
			dataIndex: "TaskAssignedTo",
			key: "TaskAssignedTo",
			width: 150,
		},
		{
			title: "TAKE ACTION",
			dataIndex: "TakeAction",
			key: "TakeAction",
			width: 100,
		},
		{
			title: "VIEW ALERT",
			dataIndex: "ViewAlert",
			key: "ViewAlert",
			width: 100,
		},
	];

	return (
		<div id="alretListTable">
			{(() => {
				if (currentScreenWidth > 1300) {
					return (
						<Layout style={{ minHeight: "100%" }}>
							<Table
								loading={loading}
								tableLayout="fixed"
								columns={columns}
								dataSource={alertlist}
								pagination={{ pageSize: 10 }}
							/>
						</Layout>
					);
				} else {
					return (
						<Layout style={{ minHeight: "100%" }}>
							<Table
								loading={loading}
								tableLayout={undefined}
								scroll={{ x: "1800px", y: "100%" }}
								columns={mobileColumns}
								dataSource={alertlist}
								pagination={{ pageSize: 10, showSizeChanger: false }}
							/>
						</Layout>
					);
				}
			})()}
		</div>
	);
};

export default AlertList;
