import os
import unittest
from src.loggers.log import create_logger


class LoggerTestCase(unittest.TestCase):

    def test_create_logger(self):
        log = create_logger("APP")
        log.info("log test")
        self.assertLogs(log, "INFO")


if __name__ == '__main__':
    unittest.main()
