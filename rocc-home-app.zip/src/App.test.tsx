/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { mockedGlobalStore } from "./mocks/mock-data"
import React from "react"
import App from "./App"
import { shallow } from "enzyme"

jest.mock("redux-micro-frontend", () => {
  return mockedGlobalStore
})

describe("App Component", () => {
  let wrapper: any
  beforeEach(() => {
    wrapper = shallow(<App />)
  })
  it("App Component should contain a container", () => {
    const roomsLayout = wrapper.find("RoomsLayout")
    expect(roomsLayout).toHaveLength(1)
  })
  it("App Component should render PersistGate component", () => {
    expect(wrapper.find("PersistGate")).toHaveLength(1)
  })
})
