export const modeltotalalstackbarTransformer = (data: any) => {
  let result = [];
  result = Object.values(
    data.reduce((acc: any, cur: any) => {
      if (!acc[cur.assetId]) {
        acc[cur.assetId] = {
          assetId: cur.assetId,
          "True_Positive": null,
          "False_Positive": null,
          "Unclassified": null
        };
      }
      acc[cur.assetId][cur.state] += cur.count;
      return acc;
    }, {})
  );

  return result;
};
// export const modeltotalalstackbarTransformer = (data: any) => {
//   let result = [];
//   result = Object.values(
//     data.reduce((acc: any, cur: any) => {
//       if (!acc[cur.assetId]) {
//         acc[cur.assetId] = {
//           assetId: cur.assetId,
//           overdue: null,
//           closed: null,
//           "work in progress": null
//         };
//       }
//       acc[cur.assetId][cur.state.toLowerCase()] += cur.count;
//       return acc;
//     }, {})
//   );

//   return result;
// };
