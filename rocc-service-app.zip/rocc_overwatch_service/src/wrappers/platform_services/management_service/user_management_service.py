"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import traceback

import json
import requests
from src.constants.config_keys import VAULT_HSDP_IDM_URL
from src.constants.constants import APPLICATION_JSON, ROCC_PROXY_URL, CONTENT_TYPE, AUTHORIZATION, ORG_CTXT_HEADER, PHILIPS_ROCC_URI, API_VERSION
from src.loggers.log import create_logger
from src.exceptions.RoccException import RoccException
from src.modules.db_operations.insertion_services.user_db_services import update_user_status_in_dict, fetch_email_id_from_employee_id
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import fetch_user_details
from src.wrappers.infrastructure_services.roles_permissions_services.manage_roles_groups import add_user_to_group

LOG = create_logger("UserManagement")


def add_users_in_db(new_users, org_ctxt_header, access_token, emp_dict, transaction_id):
    try:
        successful_userlist = []
        # failed_userlist = [] TODO: Commenting this line for sonar check
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: access_token,
            ORG_CTXT_HEADER: str(org_ctxt_header)
        }
        response = requests.post(f"{os.environ[ROCC_PROXY_URL]}/philips/rocc/usermgmt/Users/bulk",
                                 data=json.dumps(new_users),
                                 headers=headers,
                                 verify=False)
        if response.status_code in [201, 206]:
            if response.status_code == 201:
                # TODO: Need to capture email ID in audit. LOG.info("All Users are added successfully in database : {}".format(response.json()))
                LOG.info(f"All Users are added successfully in database. For transaction id: {transaction_id}")
            else:
                # TODO: Need to capture email ID in audit. LOG.warn("Failed to add some users in database: {}".format(response.json()))
                LOG.warn(f"Failed to add some users in database. For transaction id: {transaction_id}")
            for response_object in response.json():
                if response_object["status"]:
                    emp_dict = update_user_status_in_dict(emp_dict, response_object["emailId"], is_successful=True, employee_id=response_object["userId"])
                    successful_userlist.append(response_object["emailId"])
                else:
                    emp_dict = update_user_status_in_dict(emp_dict, response_object["emailId"])

        else:
            # TODO: Need to capture email ID in audit. LOG.error("Failed to add all users in database: {}".format(json.dumps(response.json())))
            LOG.error(f"Failed to add all users in database. For transaction id: {transaction_id}")
            for new_user in new_users:
                emp_dict = update_user_status_in_dict(emp_dict, new_user["uniqueId"])
        # TODO: Capture in Audit. LOG.info(f"List of users added successfully in database: {successful_userlist}")
        # if len(failed_userlist) > 0:
            # TODO: Need to capture in Audit.
            #LOG.error(f"Failed to add users in database : {failed_userlist}")
        return emp_dict, successful_userlist

    except Exception as ex:
        LOG.exception(f"Failed while adding users with error: {ex}")
        raise RoccException(500, "Failed while adding users") from ex


def send_invitation_mail(request_body, emp_dict, org_ctxt_header, access_token, transaction_id):
    try:
        successful_userlist = []
        failed_userlist = []
        headers = {
            CONTENT_TYPE: APPLICATION_JSON,
            AUTHORIZATION: access_token,
            ORG_CTXT_HEADER: str(org_ctxt_header)
        }
        LOG.info(f"Sending email to users: For transaction id: {transaction_id}")
        try:
            response = requests.post(f"{os.environ[ROCC_PROXY_URL]}/philips/rocc/usermgmt/UserActions/bulk",
                                     data=json.dumps(request_body),
                                     headers=headers,
                                     verify=False)
        except Exception as ex:
            for request in request_body:
                failed_userlist.append(fetch_email_id_from_employee_id(emp_dict, request["userId"]))
            LOG.exception(f"Exception occurred during sending email : {ex}")

        if response.status_code == 201:
            LOG.info(f"Successfully able to send invitation mail to all users. transaction id: {transaction_id}")
            for response_object in response.json():
                successful_userlist.append(fetch_email_id_from_employee_id(emp_dict, response_object["userId"]))
        elif response.status_code == 206:
            LOG.warn(f"Failed to send mail for some users. transaction id: {transaction_id}")
            for response_object in response.json():
                email_address = fetch_email_id_from_employee_id(emp_dict, response_object["userId"])
                if response_object["status"]:
                    successful_userlist.append(email_address)
                else:
                    failed_userlist.append(email_address)
        else:
            LOG.error(f"Unable to send invitation mail to all users. transaction id: {transaction_id}")
            for request in request_body:
                failed_userlist.append(fetch_email_id_from_employee_id(emp_dict, request["userId"]))
        if len(failed_userlist) > 0:
            LOG.error(f"Failed to send mails for users : transaction id: {transaction_id}")

    except Exception as ex:
        LOG.exception(f"Failed to send emails to users with error: {ex}")
    return successful_userlist, failed_userlist


def delete_users(delete_user_list, org_ctxt_header, access_token):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        ORG_CTXT_HEADER: str(org_ctxt_header),
        AUTHORIZATION: access_token
    }
    try:
        # LOG.info("Users to be deleted: {}".format(delete_user_list))
        LOG.info("Deleting users... This might take some time")
        response = requests.delete(f"{os.environ[ROCC_PROXY_URL]}/philips/rocc/mgmt/platform/Users",
                                   headers=headers, verify=False, data=json.dumps(delete_user_list))
        LOG.debug(f"Response in deleting {response}")
        if response.status_code == 200:
            LOG.info("Deletion process complete.")
            # LOG.info({
            #     "Successfully deleted from database": response.json()["databaseDeletedSuccess"],
            #     "Failed to delete from database": response.json()["databaseDeletedFailure"],
            #     "Successfully deleted from HSDP": response.json()["hsdpDeletedSuccess"],
            #     "Failed to delete from HSDP": response.json()["hsdpDeletedFailure"]
            # })
        else:
            LOG.error(f"Error while deleting users: {response.json()}")
            response.raise_for_status()

    except Exception as ex:
        LOG.exception(f"Error while deleting users: {ex}")


def insert_and_invite_user(token, user_list, org_id, url, group_id, profile_configs):
    is_user_data_inserted = False
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token, ORG_CTXT_HEADER: str({"Org-Id": org_id}), API_VERSION: "1.0.1"}
    try:
        for user in user_list:
            email_id = user["emailId"]
            response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/usermgmt/Users/",
                                     data=json.dumps(user),
                                     headers=headers)
            if response.status_code == 201:
                is_user_data_inserted = True
                LOG.info(f"User insertion in DB is successful, its response: {response.json()}")
                new_user_details = response.json()
                new_user_details["action"] = "Invite"
                if user["isfseUserCheck"]:
                    new_user_details["isfseUserCheck"] = True
                LOG.info(f"Sending email invite to user: {new_user_details}")
                response = requests.post(url=f"{url}{PHILIPS_ROCC_URI}/usermgmt/UserActions/",
                                         data=json.dumps(new_user_details),
                                         headers=headers)
                if response.status_code == 201:
                    LOG.info(f"Invitation email is sent to user : {new_user_details}")
                    task_add_fse_user_to_fse_group(token, email_id=email_id, group_id=group_id, profile_configs=profile_configs)
                else:
                    LOG.warn(f"Failed to send email with error: {response.json()}")
            else:
                LOG.info(f"User creation failed with response code : {response.status_code}, {response.json()}")
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding user: {ex}")
        LOG.error(traceback.print_exc())
    return is_user_data_inserted


def edit_fse_user(url, parent_token, user_list, org_id, group_id, profile_configs):
    user_edit_status = False
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: parent_token, ORG_CTXT_HEADER: str({"Org-Id": org_id}), API_VERSION: "1.0.1"}
    try:
        for user in user_list:
            try:
                email_id = user["emailId"]
                response = requests.put(url=f"{url}{PHILIPS_ROCC_URI}/usermgmt/Users/{user['user_id']}",
                                        data=json.dumps(user),
                                        headers=headers)
                if response.status_code == 200:
                    LOG.info("User edited successfully")
                    task_add_fse_user_to_fse_group(token=parent_token, email_id=email_id, group_id=group_id, profile_configs=profile_configs)
                    user_edit_status = True
                else:
                    LOG.error(f"Failed to edit FSE user: with {response.json()}")
            except Exception as ex:
                LOG.error(f"Failed to edit FSE user: with {ex}")
    except Exception as ex:
        LOG.exception(f"Failed to edit FSE user: with {ex}")
        LOG.error(traceback.print_exc())
    return user_edit_status


def task_add_fse_user_to_fse_group(token, email_id, group_id, profile_configs):
    try:
        fse_uuid = fetch_user_details(idm_url=profile_configs[VAULT_HSDP_IDM_URL],
                                      token=token,
                                      email_id=email_id)
        response = add_user_to_group(token=token,
                                     group_id=group_id,
                                     profile_configs=profile_configs,
                                     reference_user_uuid=fse_uuid,
                                     prov_uuid_check=False)
        if response:
            LOG.info(f"User: {fse_uuid} is successfully added to FSE group")
            return True
        else:
            LOG.error(f"User: {fse_uuid} is not added to FSE group")
    except Exception as ex:
        LOG.exception(f"Failed to add user - {fse_uuid} to FSE group - {group_id} with error: {ex}")
    return False
