/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, EClinicalRole, EOutGoingCallStatus } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import OutgoingCall from "./OutgoingCall"

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            customerReducer: {
                locations: [{
                    id: 1,
                    name: "location1",
                    shortName: "location1",
                    address: "",
                    modalityList: [],
                    locationContacts: [],
                    totalRooms: 1,
                    roomsFetched: true,
                }]
            }
        }
    }),
    CreateStore: jest.fn(),
}))

jest.mock("@rocc/rocc-global-components", () => ({
    getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({
        outgoingCall: {
            contextId: "contextId",
            participant: { ...DEFAULT_CONTACT_INFO },
            status: EOutGoingCallStatus.CALLING,
            clinicalRole: EClinicalRole.EXPERTUSER
        },
        currentUser: {
            uuid: "uuid",
            accessToken: "",
            sessionId: ""
        },
        videoCallStatus: [{
            contextId: "contextId",
            callStatus: "connected"
        }]
    }),
    useDispatch: () => void (0),
}))

describe("OutgoingCall tests", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<OutgoingCall callWindowFullscreen={false} />)
    })
    it("should render IntermediateCallWindow and its properties", () => {
        const intermediateCallWindow = wrapper.find("IntermediateCallWindow")
        expect(intermediateCallWindow).toHaveLength(1)
        const additionalComponent = intermediateCallWindow.props("additionalComponent").additionalComponent
        const cancelOutgoingCall = additionalComponent().props.onClick()
        expect(cancelOutgoingCall).toBeDefined()
    })
})
