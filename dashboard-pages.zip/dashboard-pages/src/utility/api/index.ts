// @ts-nocheck

export const BASE_URL = `${process.env.BASE_URL}`; //Base URL
export const BASE_URL1 = `${process.env.GLOBAL_URL}`; //Global service
export const BASE_URL2 = `${process.env.ASSET_URL}`; //Asset service
export const BASE_URL3 = `${process.env.MODEL_URL}`; //Model service
export const BASE_URL4 = `${process.env.LOGIN_URL}`; //Login service

export const Api = {
  /**
   * Dropdown
  */
  getRegionListByUserId: BASE_URL1 + 'Affiliate/getregionlist_byuserid',
  getAffiliateByRegion: BASE_URL1 + 'Plant/getaffiliatelistbyregionId?',
  getPlantListByAffiliate: BASE_URL1 + "AssetModelConfig/getamconfigplantlistby_affilliateId/",
  getApiAssetListByPlantId: BASE_URL2 + "PlantPmt/GetAssetlistByPlantid?",
  // asset model config dropdown
  getAssetModelConfigApiAssetListByPlantId: BASE_URL1 + "AssetModelConfig/getassetmodelconfigassetId?",
  getAssetModelConfigApiAffiliateList: BASE_URL1 + "AssetModelConfig/getaffiliateslistbyuserid",
  getAssetModelConfigApiPlantListByAffiliateId: BASE_URL1 + "AssetModelConfig/getamconfigplantlistby_affilliateId?",
  // dropdowns
  getApiAlertIDDropdownByAssetID: BASE_URL2 + "/AlertManagement/getalertmanagementalertid/",
  getApiAlertManagementAffiliatesDropdown: BASE_URL2 + "AlertManagement/getalertmanagement_affiliatesList",//ALERT MANAGEMENT PAGE->Report Dropdown
  getApiAlertManagementPlantDropdown: BASE_URL2 + "AlertManagement/getalertmanagementplantlist_byaffilliateId?", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApiAlertManagementAssetIdDropdown: BASE_URL2 + "AlertManagement/getalertmanagementassetidlist?", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApiAlertManagementAlertIDDropdown: BASE_URL2 + "AlertManagement/getalertmanagementalertidlist?", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApiCurrentStageDropdown: BASE_URL2 + "AlertManagement/getalertmanagementcurrentstagelist_byuserid", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApiLongLeadActionDropdown: BASE_URL2 + "AlertManagement/getalertmanagementlongleadactionlist_byuserid", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApiStatusDropdown: BASE_URL2 + "AlertManagement/getalertmanagementstatuslist_byuserid", //ALERT MANAGEMENT PAGE->Report Dropdown
  getApimodelstatusDropdown: BASE_URL3 + "LiveTracking/getlivetrackingmodelstatus_bymodelid?", //{modelId}/{userId}",
  getApiModelNameDropdown: BASE_URL3 + "LiveTracking/getlivetrackingmodel_byassetid?", //{assetId}/{userId}",
  /**
   * Home Page
  */
  getApiGlobalTopBarSummaryByUserId: BASE_URL1 + "Global/getGlobalTopBarSummaryByUserId", //{userId}
  getAPIGlobalMapSummaryByUserId: BASE_URL1 + "Global/getGlobalMapSummaryByUserId", //{userId}}
  getAPIGlobalRegionMapSummaryByUserId: BASE_URL1 + "Global/getGlobalRegionMapSummaryByUserId", //{userId}
  /**
   * Affiliate page
  */
  getAffiliateTopBar: BASE_URL1 + 'Affiliate/getaffiliate_topbarsummary?',
  getAffiliateDetails: BASE_URL1 + 'Affiliate/getaffiliatedetails_byregionid?',
  /**
   * Plant page
  */
  getPlantTopBar: BASE_URL1 + 'Plant/getplanttopbarsummary?',
  getPlantDetails: BASE_URL1 + 'Plant/getplantdetailsbyaffiliateid?',
  /**
   * Pmt page
  */
  getApiTopbarsummaryAssetpmtByplantid: BASE_URL2 + "PlantPmt/GetTopBarSummaryAssetPmtByPlantid?",
  getApiTopBarToolTipbyPlantId: BASE_URL2 + "PlantPmt/GetTopBarToolTipbyPlantId?",
  getApiPlantAlertsPmt: BASE_URL2 + "PlantPmt/getplant_alertspmt?",
  getApiAssetcardpmtByplantid: BASE_URL2 + "PlantPmt/getassetcardpmt_byplantid?",
  getApiassetcardpmtByassetid: BASE_URL2 + "PlantPmt/GetAssetCardPmtByAssetId?",
  getApiAssetstatuspmtByplantid: BASE_URL2 + "PlantPmt/GetAssetstatusPmtByPlantId?",
  getApiHeatMapToolTipbyAssetStatus: BASE_URL2 + "PlantPmt/GetHeatMapToolTipbyAssetStatus?",
  /**
   * Alert Satistics
  */
  /**
   * Alert Dashboard
  */
  getAssetAlertStatusByPlantId_alertstatistics: BASE_URL2 + "AlertStatisticsDashboard/getassetalertstatus_byplantid?",
  getTotalAssetAlertStatusByPlantId: BASE_URL2 + "AlertStatisticsDashboard/gettotalassetalertstatus_byplantid?",
  GetDepartmentAlertStatusByPlantId: BASE_URL2 + "AlertStatisticsDashboard/getdepartmentalertstatus_byplantid?",
  getPlantPerformanceTrendByPlantId: BASE_URL2 + "AlertStatisticsDashboard/getplantperformancetrend_byplantid?",
  getPlantUtilizationResponseTime: BASE_URL2 + "PlantUtilizationResponseTime/getplantutilizationreponsetime_byplantid?",
  /**
    * Alert List
  */
  getApiAlertStatisticsAlertListByPlantId: BASE_URL2 + "AlertStatisticsAlertList/getalertstatisticsalertlist_byplantid?",//{modelId}/{userId}",
  /**
    * Plant TimeLine
  */
  getApiPlantTimeLine: BASE_URL2 + "PlantTimeline/getplanttimeline_byplantid?",
  /**
    * Model Performance
  */
  /**
    * Performnace dashboard
  */
  getmodelalertstatusbyassebyplantid: BASE_URL2 + "ModelPerformance/getmodelalertstatusbyasset_byplantid?",
  getmodeltotalalertstatusbyasset_byplantid: BASE_URL2 + "ModelPerformance/getmodeltotalalertstatusbyasset_byplantid?",
  getmodelalertstatusbydepartmentbyplantid: BASE_URL2 + "ModelPerformance/getmodelalertstatusbydepartment_byplantid?",
  /**
    * MonthWise Table
  */
  getplantmodelbasedtabledata_byplantid: BASE_URL2 + "PlantMonthWise/getplantmodelbasedtabledata_byplantid?", //{plantId}/{assetId}/{userId}",
  /**
    * Monthwise Barchart
  */
  getplantmonthwisebarchartdata_byplantid: BASE_URL2 + "PlantMonthWise/getplantmonthwisebarchartdata_byplantid?",//{assetId}/{userId}",
  /**
    * Alert Management Page
  */
  getApiMyTaskTable: BASE_URL2 + "AlertManagement/getmyworklistreport_byuserId",
  getApireporttable: BASE_URL2 + "AlertManagement/getahcreport?",
  getApiutilizationreporttable: BASE_URL2 + "AlertManagement/getutilizationreport?",
  getApimasterdatareportdatatable: BASE_URL2 + "AlertManagement/getmasterdatareport_bydate?",
  getahcalertdetails_byalertid: BASE_URL2 + "AlertManagement/getahcalertdetails_byalertid?",
  getApiAlertManagementRequestLogTable: BASE_URL2 + "AlertManagement/getahcrequestlog_byrequestid?",
  /**
   * Asset Model
  */
  getApiAssetlistOfAssetModelByplantid: BASE_URL3 + "AssetModel/getassetlist_byplantid?",
  getApiAnomalyModelbyAssetId: BASE_URL3 + "AssetModel/getanomalymodel_byassetId?",
  getApiFailurepreDictionByAssetId: BASE_URL3 + "AssetModel/getfailureprediction_byassetid?",
  getApiGraphicalImageByAssetId: BASE_URL3 + "AssetModel/getgraphicalimage_byassetid?",
  getApiAssetKPIForAssetModel: BASE_URL3 + "AssetModel/getassetkpi_byassetid?",
  /**
  /**
  * Livetracking
  */
  getApiLivetrackingtable: BASE_URL3 + "LiveTracking/getlivetrackingdata_byassetid/liveTracking",

  /**
  * ASSET TIMELINE
  */
  getApiAssetHealthIndexByAssetId: BASE_URL3 + "AssetTimeline/getassethealthindex_byassetid?", //{assetId}/{fromDate}/{toDate}/{userId}
  getApiMaintenanceHistoryByAssetId: BASE_URL3 + "AssetTimeline/getmaintenancehistory_byassetid?", //{assetId}/{fromDate}/{toDate}/{userId}
  getApiHanaIncidentByAssetId: BASE_URL3 + "AssetTimeline/gethanaincident_byassetid?", //{assetId}/{fromDate}/{toDate}/{userId}
  /**
   * Asset Alert List
  */
  GetApiAlertStatisticsAlertListByPlantId: BASE_URL2 + "AlertStatisticsAlertList/getalertstatisticsalertlist_byplantid", //ALERTStatusALERTList
  /**
   * Asset Alert List
  */
  getApiAlertListtable: BASE_URL2 + "AssetAlertList/getassetalertlist_byassetid?",//{plantId}/{userId}",
  getApiAlertListTopBarSummary: BASE_URL2 + "AssetAlertList/getassetalertlisttopbar_byassetid?",//{assetId}/{userId}",
  getApiAlertListAssetIDDropdown: BASE_URL3 + "AssetAlertList/getplotsassetlist_byplantid?",//{plantId}/{userId}",
  getApiAlertListModelNameDropdown: BASE_URL3 + "AssetAlertList/getplotsmodel_byassetid?",//{assetId}/{userId}",
  getApiAlertListModelStatusDropdown: BASE_URL3 + "AssetAlertList/getassetalertlistmodelstatus_bymodelid?",//{modelId}/{userId}",
  /**
   * plot Screen
  */
  getplotsmodel_byassetid: BASE_URL3 + "Plots/getplotsmodel_byassetid/", //Model Dropdown
  getplotsassetlist_byplantid: BASE_URL3 + "Plots/getplotsassetlist_byplantid/", //Asset Dropdown
  getplotssensorlist_bysensorgroupId: BASE_URL3 + "Plots/getplotssensorlist_bysensorgroupId?", //Sensor Dropdown
  getplotsdeviationgraph_byassetid: BASE_URL3 + "Plots/getplotsdeviationgraph_byassetid?", //deviation chart
  getplotsstatusgraph_byassetid: BASE_URL3 + "Plots/getplotsstatusgraph_byassetid/", //sensor chart
  getplotSensor_data: BASE_URL3 + "Plots/getplotssensorgraph_bysensorGroupId", //sensor chart
  getplotsmodeldeviation_bymodelid: BASE_URL3 + "Plots/getplotsmodeldeviation_bymodelid?", //sensor chart
  /**
   * ReferenceTablePage 
  */
  getReferenceTableModelData: BASE_URL3 + "Referencetable/getreferencetable_byassetid?",
  getOfflineModelData: BASE_URL3 + "ReferenceTable/getofflinecondition_byassetid?",
  /**
   * Global Search 
  */
  getblobalsearchlist: BASE_URL1 + "Global/getglobalsearchlist",
  /**
     * Admin Configuration  Start
  */
  getAffiliatesRolloutData: BASE_URL1 + "AffiliateRollout/getaffiliaterolloutservice",  //{userId}
  getPlantsRolloutData: BASE_URL1 + "PlantRollOut/getplantrollout",  //{userId}
  updateAffiliateRolloutStatus: BASE_URL1 + "AffiliateRollout/updateaffilliaterollout/inputUpdateAffilliateRollOut", //{affilliateId}/{isRollOut}/{userId}
  updatePlantRolloutStatus: BASE_URL1 + "PlantRollOut/updateplantrollout?", //{plantId}/{isRollOut}/{userId}
  getAssetModelConfigDetails: BASE_URL1 + "AssetModelConfig/getassetmodelconfigassetmodeldetails?",  //{assetId}/{userId}
  updateAssetModelConfigDetails: BASE_URL1 + "AssetModelConfig/updateassetmodelcoordinates",
  getExceptionLogs: BASE_URL1 + "ExceptionLogs/getexceptionlogs?",  //{fromDate}/{toDate}
  getRoleListByUserid: BASE_URL1 + "UserRoleMapping/getrolelistbyuserid", //{userId}
  getplantlistbyaffiliateid: BASE_URL1 + "UserRoleMapping/getplantlistbyaffiliateid?", //{affiliateId}/{userId}
  getaffiliateslistbyuserid: BASE_URL1 + "UserRoleMapping/getaffiliateslistbyuserid", //{userId}
  addUserRoleMapping: BASE_URL1 + "UserRoleMapping/UserRoleMappingDetails/Insert",
  updateUserRoleMapping: BASE_URL1 + "UserRoleMapping/UserRoleMappingDetails/Update",
  getUserRoleMappingWorklist: BASE_URL1 + "UserRoleMapping/getuserrolemappingworklist_byuserid", //{userId}
  getEmployeeWorkList: BASE_URL1 + "UserRoleMapping/GetADUsers?",
  /**
       * Admin Configuration  End
    */
  getAllRegions: BASE_URL1 + "Affiliate/getregions_byuserid/",
  getAllAffiliateByRegion: BASE_URL1 + "Affiliate/getaffiliates_byregionid/",
  getHomeStatusByuid: BASE_URL1 + "Global/getglobalstatus_byuserid/",

  getdeviationplotgraph_byassetid: BASE_URL3 + "DeviationPlot/getdeviationplotgraph_byassetid/",
  getApiAssetStatusListbyPlantId: BASE_URL2 + "PlantPmt/GetAssetStatusListbyPlantId/",
  //pmcompliance
  getPMCompliance_Details: BASE_URL2 + "PMComplianceDetails/getpmcompliancedetails?",
  /**
     * Workflow
  */
  getSearchUserforAlertAssignment: BASE_URL2 + "AlertManagement/searchuserforalertassignment?",
  updateIbmWorkflow: BASE_URL2 + "AlertManagement/submitbpm_ipmworkflow",
  getAhcAttachments: BASE_URL2 + "AlertManagement/getahcattachmentbyalertid?",
  updateAhcAttachement: BASE_URL2 + "AlertManagement/insertahcalertattachments",
  getRoleName: BASE_URL2 + "AlertManagement/getrolename_byuserId",
  /*
   User Profile
   */
  getApiLoggedInUserDetails: BASE_URL4 + "Login/getlogin_userdetails",
  getAPIPlantAlertListStateDropdownList: BASE_URL2 + "AlertStatisticsAlertList/getassetstate_byplantId?",

  getAPIPlantAlertListDepartmentDropdownList: BASE_URL2 + "AlertStatisticsAlertList/GetDepartment_ByPlantId?",
  getExceptionAPILogId: BASE_URL1 + "ExceptionLogs/getexception_bylogid?",
  getPlantsShutdownData: BASE_URL1 + "PlantPlannedShutdown/getplantplanned_shutdowndetails/",
  //{userId}

  getAlertBreadCrumbApi: BASE_URL1 + "Global/getGlobalAlertListByAlertId?",
  // spare Parts
  getSparePartsSAPTableData: BASE_URL3 + "SparePart/getsparepartdetails_byassetId?",
  getSparePartsSensorTableData: BASE_URL3 + "SparePart/getsparepartahcsgdetails_byassetId?",
  getSparePartsSAPTableDropdownData: BASE_URL3 + "SparePart/getsensorgroup_byssetId?",
  UpdateSpareAHCGroupAssignment: BASE_URL3 + "SparePart/UpdateSpareAHCGroupAssignment",

  getAPIIBMAlertDetailsByAlertId: BASE_URL2 + "AlertManagement/getibmalertdetailsbyalertId?",
  alertManagementConsultSomeone: BASE_URL2 + "AlertManagement/consultsomeone?",

   //Utilization Report Year Month
   getAPIAlertManagementYearDropdown: BASE_URL2 + "AlertManagement/getalertmanagementmonthlist", //ALERT MANAGEMENT PAGE->Utilization Report Dropdown
   getAPIAlertManagementMonthDropdown: BASE_URL2 + "AlertManagement/getalertmanagementyearlist", //ALERT MANAGEMENT PAGE->Utilization Report Dropdown
};
