/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

const HtmlWebpackPlugin = require("html-webpack-plugin")
const WebpackBundleAnalyzer = require("webpack-bundle-analyzer").BundleAnalyzerPlugin
const ModuleFederationPlugin = require("webpack").container.ModuleFederationPlugin
const path = require("path")
const NodePolyfillPlugin = require("node-polyfill-webpack-plugin")
const dependencies = require("../../package.json").dependencies
const Dotenv = require("dotenv-webpack")
const styleLoader = "style-loader"
const cssLoader = "css-loader"
const APP_NAME = "roccCCHost"

module.exports = {
  entry: "./src/index",
  devServer: {
    contentBase: path.join(__dirname, "../../", "dist"),
    port: 8080,
  },
  optimization: {
    moduleIds: "deterministic",
    splitChunks: {
      cacheGroups: {
        vendor: {
          name: "cc_node_vendors",
          test: /[\\/]node_modules[\\/]/,
          chunks: "all",
        },
        app: {
          name: "cc_app",
          test: /[\\/]src[\\/]/,
          chunks: "all",
        }
      },
    },
  },
  output: {
    publicPath: "auto",
    filename: "static/js/[name].[contenthash].js",
    chunkFilename: "static/js/[name].[contenthash].chunk.js",
    path: path.resolve(__dirname, "../../", "dist"),
  },
  resolve: {
    extensions: [".ts", ".tsx", ".js", ".json"],
    symlinks: false,
    fallback: {
      "child_process": false,
      "fs": false,
    }
  },
  module: {
    rules: [
      {
        test: /bootstrap\.tsx$/,
        loader: "bundle-loader",
        options: {
          lazy: true,
        },
      },
      {
        test: /\.tsx?$/,
        loader: "babel-loader",
        exclude: /node_modules/,
        options: {
          presets: ["@babel/preset-react", "@babel/preset-typescript"],
        },
      },
      {
        test: /\.css$/,
        use: [
          styleLoader,
          {
            loader: cssLoader,
            options: {
              importLoaders: 1,
              modules: true
            }
          }
        ],
        include: /\.module\.css$/
      },
      {
        test: /\.css$/,
        use: [
          styleLoader,
          cssLoader
        ],
        exclude: /\.module\.css$/
      },
      {
        test: /\.(scss)$/,
        include: [path.resolve("src")],
        use: [
          {
            loader: styleLoader,
          },
          {
            loader: cssLoader,
            options: {
              importLoaders: 1,
              modules: true,
            },
          },
          {
            loader: "sass-loader",
            options: {
              sourceMap: true,
            },
          },
        ],
      },
      {
        test: /\.(png|svg|woff2|woff|ttf|eot)$/,
        use: ["file-loader"]
      },
    ],
  },
  plugins: [
    new WebpackBundleAnalyzer({ analyzerMode: "disabled", openAnalyzer: false }),
    new NodePolyfillPlugin(),
    new Dotenv({ ignoreStub: true, path: path.join(__dirname, "../../", ".env") }),
    new ModuleFederationPlugin({
      name: APP_NAME,
      filename: "remoteEntry.js",
      remotes: {
        roccCalling: "roccCalling@app/calling/remoteEntry.js",
        roccHome: "roccHome@app/home/remoteEntry.js",
        roccConsole: "roccConsole@app/console/remoteEntry.js"
      }, 
      exposes: {
        "./App": "./src/App",
      },
      shared: {
        ...dependencies,
        react: {
          singleton: true,
          requiredVersion: dependencies.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: dependencies["react-dom"],
        },
        "semantic-ui-react": {
          singleton: true,
          requiredVersion: dependencies["semantic-ui-react"],
        },
        "react-intl": {
          singleton: true,
          requiredVersion: dependencies["react-intl"]
        },
        "@dls-pdv/semantic-react-components": {
          singleton: true,
          requiredVersion: dependencies["@dls-pdv/semantic-react-components"],
        },
        "@dls-pdv/semantic-ui-foundation": {
          singleton: true,
          requiredVersion: dependencies["@dls-pdv/semantic-ui-foundation"],
        },
        "@rocc/rocc-logging-module": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-logging-module"],
        },
        "@rocc/rocc-http-client": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-http-client"],
        },
        "@rocc/rocc-client-services": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-client-services"],
        }
      },
    }),
    new HtmlWebpackPlugin({
      template: "./public/index.html",
    })
  ],
}
