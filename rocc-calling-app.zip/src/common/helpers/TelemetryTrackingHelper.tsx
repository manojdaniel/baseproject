/*
 * Created on Mon Sept 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo } from "@rocc/rocc-client-services"

export const detachLocalVideoEvent = (currentUser: IUserInfo, numOfParticipants: number) => {
    if (numOfParticipants > 1) {
        return "Switching to MPC Call from peer to peer video call"
    } else {
        return `${"Logged in Expert User stopped the local video "}${currentUser.uuid}`
    }

}

export const attachLocalVideoEvent = (currentUser: IUserInfo) => {
    return `${"Logged in Expert User started the local video "}${currentUser.uuid}`
}

export const guestUserVideoEvent = (currentUser: IUserInfo) => {
    return `${"Video is enabled for guest user in the room"} ${currentUser.uuid}`
}

export const P2P_TO_MPC_EVENT = "Switching to MPC audio video call"

export const MPC_TO_P2P_EVENT = "Switching to P2P audio video call"

export const videoCallDuration = (currentUser: IUserInfo) => {
    return `${currentUser.uuid} ${"Expert User disabled the local video "}`
}

export const getTrackingEvent = (option: string) => {
    return option.replace("_", " ").toLowerCase().split(" ")
        .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
}
