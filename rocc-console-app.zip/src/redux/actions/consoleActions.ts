/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ADD_WORKFLOW_EVENT, EConnectionMode, EConnectionType, EMutationOperation, ERoccWorkflow, IConsoleSession, IRoomDetails, IWorkflowStateConfig, parseIntBase10, REGISTER_WORKFLOW, WorkflowContext } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { CONSOLE_SESSIONS } from "../../common/constants/constants"
import { checkIfReceiversSorted, filterWithoutIncognitoSession } from "../../common/helpers/consoleUtility"
import { updateCommandCenterRegistrationCountService } from "../../services/consoleService"
import { ICommandCenterDetails, IConsoleOperation, IContextPidMapping, IStore } from "../interfaces/types"
import { INIT_COMMAND_CENTER_SEAT } from "../reducers/consoleReducer"
import { dispatchToParentStore, fetchGlobalURLs, fetchRooms } from "../store/externalAppStates"
import syncSessions from "../store/syncSessions"
import { CONSOLE_OPERATIONS, DECREMENT_KVM_SESSIONS, GLOBAL_SET_ACTIVE_TAB, GLOBAL_UPDATE_ROOMS, INCREMENT_KVM_SESSIONS, RESET_KVM_SESSION, SET_ACTIVE_SEAT, SET_NFCC_APP_PATH, UPDATE_CONTEXT_PID_MAPPINGS } from "./types"

const { VIEW, INCOGNITO_VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT } = EConnectionType

export const registerWorkflow = (
    type: ERoccWorkflow,
    {
        context,
        states,
        actions,
        guards,
        delays
    }: {
        context?: WorkflowContext,
        states?: IWorkflowStateConfig,
        actions?: any,
        guards?: any,
        delays?: any
    } = {}
) => () => {
    dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type, context, states, actions, guards, delays } })
}

export const sendWorkflowEvent = (id: string, eventType: string, payload?: Record<string, any>) => () => {
    dispatchToParentStore({ type: ADD_WORKFLOW_EVENT, payload: { id, event: { type: eventType, ...payload } } })
}

interface IResetConsoleSession {
    consoleSessions: IConsoleSession[]
    isFailed?: boolean
    updateActiveTab?: boolean
}

export const resetConsoleSession = (props: IResetConsoleSession) => (dispatch: Dispatch, getState: any) => {
    const { consoleSessions, isFailed = false, updateActiveTab = true } = props
    dispatch({ type: RESET_KVM_SESSION, consoleSessions })
    if (updateActiveTab) {
        const state: IStore = getState()
        const { activeTabIndex, featureFlags } = state.externalReducer
        let updatedTabIndex = consoleSessions.length
        if (checkIfReceiversSorted(featureFlags) && consoleSessions.length >= 1) {
            const { receivers } = state.consoleReducer.commandCenterDetails.commandCenterSeat
            const sessions = filterWithoutIncognitoSession(consoleSessions)
            syncSessions.postMessage({ type: CONSOLE_SESSIONS, sessions: sessions })
            const receiverName = consoleSessions[consoleSessions.length - 1].receiverName
            const receiver = receivers.find((receiver: any) => receiver.receiverName === receiverName)
            updatedTabIndex = isFailed ? activeTabIndex : parseIntBase10(receiver?.monitorName || activeTabIndex.toString())
        }
        dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: updatedTabIndex } })
    }
}

export const updateRoomCameraAvailability = (roomUuid: string, cameraAvailable: boolean) => () => {
    const rooms = fetchRooms()
    const updatedRooms: IRoomDetails[] = rooms.map((room: IRoomDetails) => {
        if (room.identity.uuid === roomUuid) { room.cameraAvailable = cameraAvailable }
        return room
    })
    dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms: updatedRooms } })
}

export const updateConsoleSession = (consoleSesion: IConsoleSession, active: boolean, updateActiveTab: boolean = true) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const { consoleSessions } = state.consoleReducer
    const { receivers } = state.consoleReducer.commandCenterDetails.commandCenterSeat
    const { featureFlags } = state.externalReducer
    const { connectionType, contextId, receiverName, connectionMode } = consoleSesion
    const { EMERALD } = EConnectionMode
    const setActiveTab = (session: IConsoleSession[], isUpsert: boolean, updateActiveTab: boolean) => {
        if (!updateActiveTab) {
            return
        }
        const currentMonitorName = receivers.find((receiver: any) => receiver.receiverName === receiverName)?.monitorName || "0"
        const sessions = session.length === 0 ? session.length : session.length - 1
        const emeraldSessions = session.filter((consoleSession: IConsoleSession) => consoleSession.connectionMode === EMERALD)
        const prevMonitorName = receivers.find((receiver: any) => receiver.receiverName === session[sessions]?.receiverName)?.monitorName || "0"
        const index = (checkIfReceiversSorted(featureFlags)) ?
            (connectionMode === EMERALD && emeraldSessions.length) ? session.length : //Temporary fix until new designs in place for emerald connections for cctv
                (isUpsert ? parseIntBase10(currentMonitorName) : parseIntBase10(prevMonitorName)) : session.length
        if ([INCOGNITO_VIEW, VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT].includes(connectionType)) {
            dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: index } })
        } else {
            dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: 1 } })
        }
    }
    const index = consoleSessions.findIndex((item: IConsoleSession) => item.contextId === contextId)
    if (active) {
        let mKvmSessions: IConsoleSession[] = []
        if (index === -1) {
            mKvmSessions = [...consoleSessions, { ...consoleSesion }]
            setActiveTab(mKvmSessions, true, updateActiveTab)
        } else {
            consoleSessions[index] = consoleSesion
            mKvmSessions = [...consoleSessions]
            setActiveTab(mKvmSessions, true, updateActiveTab)
        }
        const sessions = filterWithoutIncognitoSession(mKvmSessions)
        syncSessions.postMessage({ type: CONSOLE_SESSIONS, sessions: sessions })
        dispatch({ type: INCREMENT_KVM_SESSIONS, consoleSessions: mKvmSessions })
    } else {
        if (index !== -1) {
            let mKvmSession: IConsoleSession[] = consoleSessions
            mKvmSession = mKvmSession.filter((item: IConsoleSession) => item.contextId !== contextId)
            dispatch({ type: DECREMENT_KVM_SESSIONS, consoleSessions: mKvmSession })
            syncSessions.postMessage({ type: CONSOLE_SESSIONS, sessions: mKvmSession })
            setActiveTab(mKvmSession, false, updateActiveTab)
        }
    }
}

export const setConsoleOperations = (consoleOperation: IConsoleOperation) => (dispatch: Dispatch) => {
    dispatch({ type: CONSOLE_OPERATIONS, consoleOperation })
}

export const updateSpecificDataToTransaction = (key: string, value: any) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const consoleOperation = state.consoleReducer.consoleOperation
    consoleOperation.transactions.forEach((transaction: any) => {
        transaction[key] = value
    })
    dispatch({ type: CONSOLE_OPERATIONS, consoleOperation: { ...consoleOperation } })
}

export const updateSpecificDataToTransactionGroup = (key: string, value: any, groupId: string) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const consoleOperation = state.consoleReducer.consoleOperation
    consoleOperation.transactions.forEach((transaction: any) => {
        if (transaction.groupId === groupId) {
            transaction[key] = value
        }
    })
    dispatch({ type: CONSOLE_OPERATIONS, consoleOperation: { ...consoleOperation } })
}

export const updateCommandCenterSeat = (commandCenterDetails: ICommandCenterDetails, updateDb: boolean = false) => (dispatch: Dispatch, getState: any) => {
    const state: IStore = getState()
    const { id, accessToken } = state.externalReducer.currentUser
    const { MANAGEMENT_SERVICE_URL } = fetchGlobalURLs()

    const previousCommandCenterSeat = state.consoleReducer.commandCenterDetails
    const { INCREMENT_COMMAND_CENTER_COUNT_FLAG, DECREMENT_COMMAND_CENTER_COUNT_FLAG } = EMutationOperation
    if (updateDb && ![INIT_COMMAND_CENTER_SEAT.seatName, commandCenterDetails.commandCenterSeat.seatName].includes(previousCommandCenterSeat.commandCenterSeat.seatName)) {
        /* Call a mutation api to decrement the count of previous seat */
        updateCommandCenterRegistrationCountService({
            userOperationType: DECREMENT_COMMAND_CENTER_COUNT_FLAG,
            managementServiceUrl: MANAGEMENT_SERVICE_URL,
            requesterId: parseIntBase10(id),
            seatName: previousCommandCenterSeat.commandCenterSeat.seatName,
            orgId: previousCommandCenterSeat.commandCenterSeat.organizationId,
            token: accessToken,
        })
    }
    if (updateDb && ![INIT_COMMAND_CENTER_SEAT.seatName, previousCommandCenterSeat.commandCenterSeat.seatName].includes(commandCenterDetails.commandCenterSeat.seatName)) {
        /* Call a mutation api to increment the count of new seat */
        updateCommandCenterRegistrationCountService({
            userOperationType: INCREMENT_COMMAND_CENTER_COUNT_FLAG,
            managementServiceUrl: MANAGEMENT_SERVICE_URL,
            requesterId: parseIntBase10(id),
            seatName: commandCenterDetails.commandCenterSeat.seatName,
            orgId: commandCenterDetails.commandCenterSeat.organizationId,
            token: accessToken,
        })
    }
    dispatch({ type: SET_ACTIVE_SEAT, commandCenterDetails })
}

export const updatePidMapping = (kvmTransactions: any[], contextPidMappings: any[]) => async (dispatch: Dispatch) => {
    try {
        kvmTransactions.forEach((kvmTransaction: any) => {
            const index = contextPidMappings.findIndex((mapping: IContextPidMapping) => mapping.contextId === kvmTransaction.contextId)
            if (index === -1 && kvmTransaction.anywhereAppPid) {
                contextPidMappings.push({ contextId: kvmTransaction.contextId, pid: kvmTransaction.anywhereAppPid })
            }
        })
        dispatch({ type: UPDATE_CONTEXT_PID_MAPPINGS, contextPidMappings })
    } catch (error) {
        errorLogger(`Error: Failed to update PID. Error: ${errorParser(error)}`)
    }

}

export const setNFCCAppPath = (nfccAppPath: string) => (dispatch: Dispatch) => {
    dispatch({ type: SET_NFCC_APP_PATH, nfccAppPath })
}
