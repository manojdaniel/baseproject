/*
 * Created on Tue Nov 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { graphqlClient, parseIntBase10 } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import orderBy from "lodash.orderby"
import { CONSOLE_ACCESS_MODE, LOCATION_NAME, SEP } from "../../common/constants/constants"
import { QUERY_COMMAND_CENTER_SEATS, QUERY_FETCH_ALL_RECEIVERS_FOR_A_SEAT } from "../../graphql/queries/queries"
import { IReceiver } from "../../redux/interfaces/types"

export const fetchCommandCenterService = async (metasiteId: number) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_COMMAND_CENTER_SEATS,
            variables: { orgId: metasiteId },
        })
        return result.data.command_center_seats
    } catch (error) {
        errorLogger(`Error while fetching Expert user seats, error: ${errorParser(error)}`)
        return []
    }
}

export const fetchReceiversForASeatService = async (dbOrgId: number, seatName: string) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_FETCH_ALL_RECEIVERS_FOR_A_SEAT,
            variables: { orgId: dbOrgId, seatName },
        })
        return result.data.receivers
    } catch (error) {
        errorLogger(`Error while fetching receivers for seat ${seatName}, error: ${errorParser(error)}`)
        return []
    }
}

export const fetchReceiverTransformer = async (dbOrgId: number, seatName: string) => {
    let receivers: IReceiver[] = []
    const result = await fetchReceiversForASeatService(dbOrgId, seatName)
    result.forEach((element: Pick<IReceiver, "id" | "receiverName" | "monitorName">) => {
        receivers.push({ id: element.id, receiverName: element.receiverName, monitorName: element.monitorName, isSelected: false })
    })
    if (receivers) {
        receivers = orderBy(receivers, ["monitorName"])
    }
    return receivers
}

export const setConsoleAccessMode = (accessMode: string) => {
    localStorage.setItem(CONSOLE_ACCESS_MODE, accessMode)
}

export const setCommandCenterSeatService = (locationName: string, dbOrgId: number) => {
    const commandCenterSeat = `${locationName}${SEP}${dbOrgId.toString()}`
    localStorage.setItem(LOCATION_NAME, commandCenterSeat)
}

export const clearCommandCenterSeatService = () => {
    localStorage.removeItem(LOCATION_NAME)
}

export const getConsoleAccessMode = () => {
    return localStorage.getItem(CONSOLE_ACCESS_MODE)
}

export const getCommandCenterSeatService = (orgId: string) => {
    let seatName = ""
    let dbOrgId = 0
    const commandCenterSeat = localStorage.getItem(LOCATION_NAME)
    if (commandCenterSeat) {
        seatName = commandCenterSeat.split(SEP)[0]
        dbOrgId = parseIntBase10(orgId)
        /** Setting local storage since existing customers will have seatName mapped with locationId instead of DbOrgId*/
        setCommandCenterSeatService(seatName, dbOrgId)
    }
    return { seatName, dbOrgId }
}
