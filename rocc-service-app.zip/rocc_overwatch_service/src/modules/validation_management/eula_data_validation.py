"""
 Created on Thu Oct 30 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import base64
import os
from src.constants.constants import EULA_DICT

from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_org_db_id_from_identifier
from src.modules.db_operations.validation_service.eula_data_validation_service import verify_if_eula_data_exists
from src.modules.file_operations import file_reader
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("EulaDataValidation")


class EulaDataValidation():

    def __init__(self, service_token, org_infra_uuid):
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)

    def verify_if_data_exists(self, documents, customer_identifier):
        validate_dict = {}
        for doc in documents:
            document_name = os.path.splitext(os.path.basename(doc))[0]
            file_handle = open(doc, "rb")
            data = file_handle.read()
            file_handle.close()
            response = verify_if_eula_data_exists(client=self._client, document_name=document_name, data=base64.b64encode(data).decode("utf-8"))
            if response:
                validate_dict[f"EULA_{customer_identifier}_{document_name}"] = {"document_name": document_name, "isPresent": True}
            else:
                validate_dict[f"EULA_{customer_identifier}_{document_name}"] = {"document_name": document_name, "isPresent": False}
        return validate_dict

    def initiate_data_validation(self, customer_identifier, data_dict, locale):
        org_db_id = fetch_org_db_id_from_identifier(client=self._client, customer_identifier=customer_identifier)
        if org_db_id:
            documents = file_reader.terms_of_service(locale=locale)
            terms_of_service_dict = self.verify_if_data_exists(documents=documents, customer_identifier=customer_identifier)
            data_dict[EULA_DICT] = terms_of_service_dict
        else:
            data_dict[EULA_DICT] = {"isValidSite": False, "metasite": customer_identifier}
        LOG.info("EULA Data validation complete ..!!")
        return data_dict
