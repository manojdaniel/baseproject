import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom";
import { screen } from "@testing-library/react";
import Status from "./Status";

const dataObject = [
	{
		affiliateCount: 1,
		assetCount: 111,
		healthIndex: 28,
		pmCompliance: 0,
		spare: "NA",
		active: 0,
		overdueInvestigation: 0,
		underInvestigation: 0,
	},
];
const healthIndexObject = [
	{
		AssetSapId: 310059910,
		AssetHealthIndex: 0,
		AssetTrend: 0,
		PlantHealth: 28,
		PlantTrend: 1,
		AssetId: "2K-3101",
		PlantId: 18,
		AssetName: "Cycle Gas Compressor 4",
	},
];

// it("Status component should render the correct text", () => {

//   render(
//     <Status data={dataObject} page="PLANT" healthIndex= {healthIndexObject} />
//   );
//   expect(screen.getByRole('img')).toBeInTheDocument();
//   // expect(screen.getByText("HOME")).toBeInTheDocument(); screen.getByRole('dialog')
// });
it("Status component should render the correct no. of images", () => {
	render(
		<Status
			data={dataObject}
			page="PLANT"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	expect(screen.queryAllByRole("img")).toHaveLength(10);
});

it("Status component should render the correct no. of images in All Plant page", () => {
	render(
		<Status
			data={dataObject}
			page="ALLPLANT"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	expect(screen.queryAllByRole("img")).toHaveLength(9);
});

it("Status component should render the correct no. of images in Home page", () => {
	render(
		<Status
			data={dataObject}
			page="HOME"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	expect(screen.queryAllByRole("img")).toHaveLength(10);
});

it("Status component should render the correct no. of images in AFFILIATE page", () => {
	render(
		<Status
			data={dataObject}
			page="AFFILIATE"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	expect(screen.queryAllByRole("img")).toHaveLength(9);
});

it("should render the correct tile names in Plant page", () => {
	render(
		<Status
			data={dataObject}
			page="PLANT"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	// const linkElement = ;
	expect(screen.queryByText(/ACTIVE/i)).toBeInTheDocument();
});
it("should render the correct tile names in Home Page", () => {
	render(
		<Status
			data={dataObject}
			page="HOME"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	// const linkElement = ;
	expect(screen.queryByText(/ACTIVE/i)).toBeInTheDocument();
});
it("should render the correct tile names in all palnt page", () => {
	render(
		<Status
			data={dataObject}
			page="ALLPLANT"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	// const linkElement = ;
	expect(screen.queryByText(/ASSETS/i)).toBeInTheDocument();
});
it("should render the correct tile names in affliate page", () => {
	render(
		<Status
			data={dataObject}
			page="AFFILIATE"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	// const linkElement = ;
	expect(screen.queryByText(/ACTIVE/i)).toBeInTheDocument();
});

it("Alert Status component should not render in case of diffrent page", () => {
	render(
		<Status
			data={dataObject}
			page="ALERT"
			healthIndexToolTip={healthIndexObject}
		/>
	);
	expect(screen.queryByText(/AFFILIATES/i)).toBeNull();
});

it("component should not render in case of no data in plant page", () => {
	render(
		<Status data={[]} page="PLANT" healthIndexToolTip={healthIndexObject} />
	);
	expect(screen.queryByText(/AFFILIATES/i)).toBeNull();
});
it("component should not render in case of no data in AFFILIATE page", () => {
	render(
		<Status data={[]} page="AFFILIATE" healthIndexToolTip={healthIndexObject} />
	);
	expect(screen.queryByText(/AFFILIATES/i)).toBeNull();
});
it("component should not render in case of no data in ALLPLANT page", () => {
	render(
		<Status data={[]} page="ALLPLANT" healthIndexToolTip={healthIndexObject} />
	);
	expect(screen.queryByText(/AFFILIATES/i)).toBeNull();
});
it("component should not render in case of no data in HOME page", () => {
	render(
		<Status data={[]} page="HOME" healthIndexToolTip={healthIndexObject} />
	);
	expect(screen.queryByText(/AFFILIATES/i)).toBeNull();
});
