"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import time

from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import FAILED, FAILED_AT, JOB_LIST, CURRENT_JOB, TRANSACTION_ID, INIT, COMPLETED, JOB_NAME, INDEX, STATUS, ID, TRANSACTION_DATA
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_job_id_from_name, update_service_job_transaction_status, \
    get_service_job_transactions_details, fetch_tasks_for_job, update_tasks_for_transaction
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.job_management.job_handler import JobHandler
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data

LOG = create_logger("TimedWaitJob")


class TimedWaitJob(JobHandler):

    def __init__(self):
        self._success = False

    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            self._transaction_id = self._payload[TRANSACTION_ID]
            self._profile_configs = get_profile_data()
            self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._parent_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                         issuer=self._profile_configs[
                                                                             VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                         private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self._client = get_client_connection(
                self._parent_service_token, org_infra_uuid=self._parent_org_id)
            job_transaction_details = self.fetch_transaction_from_db(
                transaction_id=self._payload[TRANSACTION_ID])
            self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
            self._job_id = fetch_job_id_from_name(
                EJobs.TIMED_WAIT.value, self._client)
            if len(job_transaction_details) != 0:
                # TODO: Update transaction status to complete after wait time
                self.fetch_all_tasks()
                self.update_transaction_in_db_wrt_job(status=INIT,
                                                      task_name=ETasks.TIMED_WAIT.value,
                                                      job_status_update=True,
                                                      update_record_status=False)
            else:
                LOG.info(
                    f"{self._payload[CURRENT_JOB]} Job is completed and transaction details are, {self._payload[TRANSACTION_ID]}")
            self._success = True
            self.post_message(payload=self._payload)
            LOG.info(f"Finished Job: {EJobs.TIMED_WAIT.value}")
        except RoccException as ex:
            LOG.exception(f"Exception occurred in Timed wait job with: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"Exception occurred in Timed wait job with: {ex}")
            raise ex

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(
            job_id=self._job_id, client=self._client)
        LOG.info(
            f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def fetch_transaction_from_db(self, transaction_id):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(
            transaction_id, client=self._client)
        LOG.info(
            f"Fetch job details for transaction_id, {transaction_id} is successful")
        return transaction_details

    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        """Update corresponding transaction from transaction table"""
        if update_record_status:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self._client)
            LOG.info(
                f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._transaction_id,
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[
                                                                  ID],
                                                              transaction_data_object=self._transaction_data,
                                                              status=status,
                                                              client=self._client,
                                                              job_status_update=job_status_update,
                                                              reason=error_reason)

    def execute_tasks(self):
        """
        Tasks:
        - TIMED_WAIT
        """

    def post_message(self, payload):
        """
        1. Post message to RabbitMQ with Payload
        """
        try:
            delay_queue = True
            if self._success:
                current_record = list(filter(
                    lambda item: item[JOB_NAME] == EJobs.TIMED_WAIT.value, payload[JOB_LIST]))[0]
                for job in payload[JOB_LIST]:
                    if job[JOB_NAME] == EJobs.TIMED_WAIT.value:
                        job[STATUS] = COMPLETED
                    if job[INDEX] == current_record[INDEX] + 1:
                        payload[CURRENT_JOB] = job[JOB_NAME]
                        job[STATUS] = INIT
                LOG.info(
                    f"Publishing a rabbitMQ message after completing current Job: {EJobs.TIMED_WAIT.value}")
                LOG.info(
                    f"Customer data insertion job starts at around: {time.ctime(time.time() + 1800)}")
            else:
                delay_queue = False
                self.update_transaction_in_db_wrt_job(
                    FAILED, ETasks.TIMED_WAIT.value, job_status_update=True)
                payload[CURRENT_JOB] = EJobs.FAILED.value
                payload[FAILED_AT] = EJobs.TIMED_WAIT.value
                LOG.warn(
                    f"Publishing FAILED rabbitMQ message, since the current job: {EJobs.TIMED_WAIT.value} is failed")
            publish_message(payload=payload, delay_queue=delay_queue)
        except Exception as ex:
            LOG.exception(f"Failed to post message with error: {ex}")

    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """
