"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask_restful import Resource, reqparse
from flask import request

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION


LOG = create_logger("EULA controller")


class Eula(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("content", type=str, required=True, help="This field cannot be left blank!")

    def put(self, customer_id):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for EULA update is: {api_version}")
            """ TODO: Need to evaluate the token """
        except KeyError:
            return {"message": f"'{API_VERSION}' header is needed to process this request"}, 400
        body = Eula.parser.parse_args()
        LOG.info(f"EULA update with content: {body} is initiated")
        """ TODO: EULA update process """
        return {"message": f"EULA successfully updated for customer: {customer_id}"}, 200
