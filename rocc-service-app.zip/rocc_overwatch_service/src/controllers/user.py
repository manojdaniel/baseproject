"""
 Created on Tue Feb 23 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask_restful import Resource, reqparse
from flask import request, g
from src.exceptions.RoccException import RoccException

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION, AUTHORIZATION
from src.services.user_services import UserManagementService
from src.utility.utility import construct_negative_response
from src.utility.semver import parse_version

LOG = create_logger("UserManagementController")


class User(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("customer_id", type=int, required=True, help="This field cannot be left blank!")
    parser.add_argument("kvm_username", type=str, required=True, help="This field cannot be left blank!")

    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
            """ TODO: Need to evaluate the token """
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        """ TODO: Add new user process initiation """
        return {"message": "This api is coming soon", "user_id": "1234"}, 201

    def put(self, user_id):
        LOG.info(f"Request to update user details for user with id: {user_id}")
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code=400,
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            body = User.parser.parse_args()
            user_token = request.headers[AUTHORIZATION]
            user_management_service = UserManagementService(service_user_uuid=g.userdetails,
                                                            org_db_id=body["customer_id"],
                                                            service_user_token=user_token)
            response = user_management_service.update_user_details_to_map_kvm_role(user_db_id=user_id,
                                                                                   kvm_user_name=body["kvm_username"])
            return response
        except RoccException as ex:
            return {"error": ex.payload}, ex.status_code
        except Exception as ex:
            LOG.error(f"Request to update user details for user with id: {user_id} failed with error: {ex}")
            return {"message": "Internal server error, Please contact administrator"}, 500
