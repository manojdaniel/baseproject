import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import MobileHeader from "./MobileHeader";
import { useNavigate } from "react-router-dom";
// Mock useNavigate from react-router-dom
jest.mock("react-router-dom", () => ({
	useNavigate: jest.fn(),
}));
// Reset the useNavigate mock before each test
describe("MobileHeader", () => {
	beforeEach(() => {
		useNavigate.mockReset();
	});

	test("renders without crashing", () => {
		render(<MobileHeader />);
	});
	test("opens and closes the menu when the burger icon is clicked", () => {
		render(<MobileHeader />);
		const burgerIcon = screen.getByRole("button");
		expect(burgerIcon).toBeInTheDocument();

		fireEvent.click(burgerIcon);
		const menu = screen.getByRole("menu");
		expect(menu).toBeInTheDocument();

		fireEvent.click(burgerIcon);
		const closedMenu = screen.queryByRole("menu");
		expect(closedMenu).not.toBeInTheDocument();
	});
	test("displays the correct menu items", () => {
		render(<MobileHeader />);
		const homeItem = screen.getByText("HOME");
		const affiliatesItem = screen.getByText("AFFILIATES");
		const plantsItem = screen.getByText("PLANTS");
		const assetsItem = screen.getByText("ASSETS");
		const executiveItem = screen.getByText("EXECUTIVE");
		const infoItem = screen.getByText("INFO");

		expect(homeItem).toBeInTheDocument();
		expect(affiliatesItem).toBeInTheDocument();
		expect(plantsItem).toBeInTheDocument();
		expect(assetsItem).toBeInTheDocument();
		expect(executiveItem).toBeInTheDocument();
		expect(infoItem).toBeInTheDocument();
	});

	test("navigates to the correct route when a menu item is clicked", () => {
		render(<MobileHeader />);
		const plantsItem = screen.getByText("PLANTS");
		fireEvent.click(plantsItem);

		const pmtItem = screen.getByText("PMT");
		fireEvent.click(pmtItem);
		// Check that useNavigate was called with the correct route
		expect(useNavigate).toHaveBeenCalledWith("/plant/pmt");
	});

	test("displays user profile information", () => {
		render(<MobileHeader />);
		const profileLink = screen.getByTitle("User");
		const username = screen.getByText("Lorem Bospioum ispum");

		expect(profileLink).toBeInTheDocument();
		expect(username).toBeInTheDocument();
	});

	test("displays settings icon", () => {
		render(<MobileHeader />);
		const settingsIcon = screen.getByAltText("settings");

		expect(settingsIcon).toBeInTheDocument();
	});
});
