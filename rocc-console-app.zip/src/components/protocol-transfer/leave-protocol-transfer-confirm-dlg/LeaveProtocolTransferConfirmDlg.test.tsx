/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import LeaveProtocolTransferConfirmDlg from "./LeaveProtocolTransferConfirmDlg"

jest.mock("react-redux", () => ({
    useDispatch: () => jest.fn(() => {
        return {
            dispatch: jest.fn()
        }
    })
}))

describe("LeaveProtocolTransferConfirmDlg component", () => {
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    const mockUseEffect = () => {
        useEffect.mockImplementationOnce(f => f())
    }
    let wrapper: any

    it("should render Fragment", () => {
        useEffect = jest.spyOn(React, "useEffect")
        mockUseEffect()
        wrapper = shallow(<LeaveProtocolTransferConfirmDlg show={false} postConfirmCallback={jest.fn()} onDialogClosed={jest.fn()} />)
        expect(wrapper.find("Fragment")).toHaveLength(1)
    })

    it("should render ModalComponent and its properties", () => {
        useEffect = jest.spyOn(React, "useEffect")
        mockUseEffect()
        wrapper = shallow(<LeaveProtocolTransferConfirmDlg show={true} postConfirmCallback={jest.fn()} onDialogClosed={jest.fn()} />)
        const modalComponent = wrapper.find("Fragment").find("ModalComponent")
        const actionButton1Onclick = modalComponent.prop("actionButton1Onclick")
        actionButton1Onclick()
        expect(actionButton1Onclick).toBeDefined()
        const actionButton2Onclick = modalComponent.prop("actionButton2Onclick")
        actionButton2Onclick()
        expect(actionButton2Onclick).toBeDefined()
    })
})
