/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import gql from "graphql-tag"

export const QUERY_CURRENT_USER_DETAILS = gql`
query currentUserDetails($uuid: String!) {
  employeeDetails: rocc_get_user_info_function(args: {user_uuid: $uuid}) {
    user_id
    user_hsdp_uuid
    org_id
    org_identifier
    display_name
    user_primary_phone
    user_email_id
    web_onboarding
    modality
    roles
    sites
    kvmUserName: kvm_user_name
  }
}
`

/** For Service Admin users */
export const QUERY_GET_METASITE_ID_FOR_CUSTOMER = gql`
query getMetasiteIdForCustomer($customerName: String!) {
  metasites: rocc_get_organizations_function(where: {org_identifier: {_eq: $customerName}}) {
    id
  }
}
`


export const QUERY_GET_VERSION = gql`
query getVersion($appName: String!) {
  configurationVariable: rocc_rocc_configuration_variables(where: {configuration_key: {_eq: $appName}}) {
    id
    appVersion: configuration_value
  }
}
`

/* On-Boarding Queries */
export const QUERY_GET_TERMS_AND_CONDITIONS = gql`
query fetch_terms_and_conditions($orgId: Int!, $locale: String!) {
  rocc_terms_of_service: rocc_get_seats_receivers_docs_info_function(args: {orgid: $orgId}, where: {locale: {_eq: $locale}}, distinct_on: doc_id) {
    id: doc_id
    data_blob
  }
}
`

export const QUERY_FETCH_SITE_INFO_USER_CURRENT_USER = gql`
query siteInformationRelevantForCurrentUser($uuid: String!) {
  resourcesInfo: rocc_get_all_site_resources_function(args: {user_uuid: $uuid}, where: {device_status: {_eq: "Active"}}) {
    resource_id
    device_uuid
    resource_name
    resource_phone
    org_id
    org_name
    org_uuid: org_hsdp_uuid
    resource_location
    resource_identifier
    modality
    org_identifier
    site_contacts
    sites
    user_favourite
    device_status
    additional_attributes
    modality_connection
  }
}
`
export const QUERY_FETCH_SITE_INFO_IN_PRESIGNED_CONTEXT_CURRENT_USER = gql`
query siteInformationRelevantForCurrentUserInPreSignedContext($uuid: String!, $deviceUuids: [String!]) {
  resourcesInfo: rocc_get_all_site_resources_function(args: {user_uuid: $uuid}, where: {_and: [{device_status: {_eq: "Active"}}, {device_uuid: {_in: $deviceUuids}}]}) {
    resource_id
    device_uuid
    resource_name
    resource_phone
    org_id
    org_name
    org_uuid: org_hsdp_uuid
    resource_location
    resource_identifier
    modality
    org_identifier
    site_contacts
    sites
    user_favourite
    device_status
    additional_attributes
    modality_connection
  }
}
`
