#!/bin/bash

if [ "$#" -ne 5 ]; then
    echo "ERROR: Invalid number of arguments passed! Expected 5 arguments"
    echo """
    Arguments:
    1. DEPLOY_MODE: cloud/local
    2. DOCKER_REPO: Docker Registry name with path
    3. IMAGE_TAG: Image tag that you wish to provide
    4. CF_USERNAME_USR: CF user name
    5. CF_DOCKER_PASSWORD: CF docker password
    Run in the following format:
    bash starter.sh <DEPLOY_MODE> <DOCKER_REPO> <IMAGE_TAG> <CF_USERNAME_USR> <CF_DOCKER_PASSWORD>

    Ex: bash starter.sh cloud docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips manual $CF_USERNAME_USR $CF_DOCKER_PASSWORD
    Ex: bash starter.sh local docker.na1.hsdp.io/client-radiologysolutions-performancebridge_rocc-dev/philips manual $CF_USERNAME_USR $CF_DOCKER_PASSWORD
"""
    exit 1
fi
if [[ $1 != local ]] && [[ $1 != cloud ]]; then
    echo "ERROR: DEPLOY_MODE should be either: 'local' or 'cloud'"
    exit 1
fi

DEPLOY_MODE=$1
DOCKER_REPO=$2
IMAGE_TAG=$3
CF_USERNAME_USR=$4
CF_DOCKER_PASSWORD=$5
IMAGE_NAME=rocc_cpp_image
APP_NAME=rocc-cpp-manual
VARS=vars/vars_clienttest_us-east.yaml
CICD_FOLDER=cicd

SEP="====================================="
set -e
set -x
echo "Building $APP_NAME client"

currentDir=$(pwd)

echo "Processing in directory : {$currentDir}"
cd ../client

echo $SEP
echo "Building $APP_NAME client"
echo $SEP
npm install
rm -rf build
npm run build

echo $SEP
echo "Copying the client build contents to server"
echo $SEP
cp -r build/* ../server/dist

echo $SEP
echo "Building $APP_NAME server"
echo $SEP
cd ../server
npm install
npm run build

echo $SEP
echo "Copying app specific contents into $CICD_FOLDER folder"
echo $SEP
cp -r certificate dist package.json start-server.sh node_modules ../$CICD_FOLDER

echo $SEP
echo "Building $APP_NAME docker image"
echo $SEP

cd ../$CICD_FOLDER
docker build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy -t $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG .

echo "Removing content from $CICD_FOLDER folder"
rm -rf certificate dist package.json start-server.sh node_modules

if [[ $DEPLOY_MODE == local ]]; then
    echo "Staring docker container"
    docker-compose up -d
    echo "You can access app at: https://localhost/"
    echo $SEP
fi
if [[ $DEPLOY_MODE == cloud ]]; then
    echo $SEP
    echo "Pushing docker image"
    docker push $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG
    echo $SEP
    echo "Cleaning up local docker image after push to registry"
    echo $SEP
    docker rmi $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG
    echo $SEP
    echo "Pushing cf app and starting it"
    echo $SEP
    CF_DOCKER_PASSWORD=$CF_DOCKER_PASSWORD cf push $APP_NAME -f manifest.yaml -m 512M --docker-image $DOCKER_REPO/$IMAGE_NAME:$IMAGE_TAG --docker-username "$CF_USERNAME_USR" --vars-file $VARS
    echo $SEP
fi

echo "ROCC $APP_NAME setup completed"
echo $SEP
