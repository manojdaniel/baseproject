// @ts-nocheck
import { put, takeEvery, debounce, select, takeLatest } from "@redux-saga/core/effects";
import { getRequest, postRequest } from "../../utility/request";
import { Api } from "../../utility/api";
import { HTTP_CALL } from "../../constant/constants";
import {
  getassetlistByplantidOfAssetModel,
  getAnomalyModelbyassetidinAssetModel,
  getFailurepredictionbyassetidAssetModel,
  getGraphicalImageForAssetModel,
  getAssetKPIForAssetModel,
} from "../../DataModel/Assets/AssetModel";
import {
  getassetlistByplantid,
  getplantAlertspmt,
  getassetcardpmtByplantid,
  getassetcardpmtByassetid,
  gettopbarsummaryAssetpmtByplantid,
  getassetstatuspmtByplantid,
  getJsonAssetStatusListbyPlantId,
  getJsonHeatMapToolTipbyAssetStatus,
  getJsonTopBarToolTipbyPlantId,
} from "../../DataModel/PMT/PmtList";
import {
  getAssetHealthIndexByAssetIdJson,
  getmaintenancehistoryjson,
  GetHanaIncidentByAssetIdjson,
} from "../../DataModel/Assets/AssetTimeLineList";
import {
  modelstatusdropdowndata,
  livetrackingtableData,
} from "../../DataModel/Livetracking";
import {
  myTaskTableData,getibmalertdetailsbyalertIdJSON,consultSomeoneDataResponse,
} from "../../DataModel/MyTaskDataList";
import { reportData, alertDetailsData, GetAHCRequestLogByRequestIdJSON } from "../../DataModel/ReporsAllList";
import { utilizationReportData, GetAlertManagementYearList, GetAlertManagementMonthList } from "../../DataModel/Utilizationreportlist";
import { masterDataReportData } from "../../DataModel/MasterDataList";
//Pmcompliance
import { getPMComplianceDetail } from "../../DataModel/PMcompliance";
//Asset Alert List
import {
  alertListData,
  topbarData,
  assetIdDropdown,
  modelNameDropdown,
  modelStatusDropdown,
} from "../../DataModel/Assets/AlertList";
import {
  getAlertStatusAsset,
  getPerormanceTrend,
  getStackedBarAsset,
  getStackedBarDepartment,
} from "../../DataModel/AlertDashboard";
import {
  getModelDropdownData,
  getAssetDropdownData,
  getSensorDropdownData,
  getDeviationGraphData,
  getPlotStatusData,
  getPlotDeviationModel,
  getPlotSensorData,
} from "../../DataModel/PlotScreen";
import { AlertStatisticsAlertListByPlantId } from "../../DataModel/AlertStatus/AlertStatusList";
import { getplanttimelinebyplantidjson } from "../../DataModel/PlantTimelineList";
import {
  getOfflineModelDataInput,
  getReferenceTableModelDataInput,
} from "../../DataModel/ReferenceTable";
import { Search } from "../../DataModel/Search";
//modelperformance
import {
  getmodelalertstatusbyassetbyplantid,
  getmodeltotalalertstatusbyasset_byplantid,
  //getmodeltotalalertstatusbyasset_byplantid,
  getmodelalertstatusbydepartmentbyplantid,
} from "../../DataModel/ModelPerformance";

import { affiliateTopBar, affiliateDetailsData } from '../../DataModel/AffiliatePage'
import {
  regionDropdownList, plantDropdownList, affiliateDropdownList, assetDropdownList, modelDropdownList,
  modelStatusDropdownList, sensorDropdownList, alertIDDropdownList, currentstageDropdownList, longLeadActionDropdownList,
  statusDropdownList, GetAlertManagementAffiliatesDropdownJSON, GetAlertManagementPlantListDropdownJSON,
  GetAlertManagementAssetIdDropdownJSON, GetAlertManagementAlertIdDropdownJSON
} from '../../DataModel/DropdownList'

import {
  affiliateDropdownTransformer, assetDropdownTransformer, modelDropdownTransformer,
  modelStatusDropdownTransformer, regionDropdownTransformer,
  SensorDropdownTransformer, AlertIDDropdownTransformer, plantDropdownTransformer,
  currentstageDropdownTransformer, longLeadActionDropdownTransformer,
  statusDropdownTransformer, modelSensorDropdownTransformer, alertManagementAffiliatesTransformer,
  alertManagementPlantDroprdownTransformer, alertManagementAssetIdDroprdownTransformer,
  alertManagementAlertIdDroprdownTransformer,
  roleMappingRoleDropdownTransformer, roleMappingPlantDropdownTransformer,
  roleMappingAffiliateDropdownTransformer, affiliateDropdownTransformerAssetConfig,
  plantAlertListStateDropdownTransformer, plantAlertListDepartmentDropdownTransformer, sparePartsSensorGroupDropdownTransformer,
  getAlertManagementYearDropdownTransformer,getAlertManagementMonthDropdownTransformer,

} from "../../utility/transformer/DropdownTransformer";
import { plantDetailsData, plantTopBar } from '../../DataModel/allPlants'

//monthwise table
import {
  getplantmodelbasedtabledata_byplantid,
  getplantmonthwisebarchartdata_byplantid,
} from "../../DataModel/MonthWise";

//Home Json Data
import { GetGlobalTopBarSummaryByUserIdJSON, GetGlobalMapSummaryByUserIdJSON, GetGlobalRegionMapSummaryByUserIdJSON } from "../../DataModel/HomePageList"
import { plantDetailTransformer } from "../../utility/transformer/PlantTransformer";

//Admin Configuration
import {
  affiliateRolloutData, plantRolloutData, assetModelConfigTableData,
  assetModelConfigTableStatus, roleListData, roleMappingPlantListData, roleMappingAffiliateListData,
  exceptionLogsData, addUserRollmapDataAPIResponse,
  updateUserRollmapDataAPIResponse, userRoleMappingWorklist, employeeDataList, exceptionLogJSON
} from "../../DataModel/Admin/AdminConfiguration";

import {
  WorkflowSearchData,
  getAttachementData,
  WorkflowUserData
} from "../../DataModel/Workflow";
/*
  User Profile
 */
import { getLoggedInUserDetailsJSON } from "../../DataModel/UserProfile";

//Alert Statistics
import { plantUtilizationResponseTime, plantAlertListStateDropdownJSON, plantAlertListDepartmentDropdownJSON } from "../../DataModel/AlertStatistics";
//Plant Shutdown
import { plantShutdownData } from "../../DataModel/Admin/PlantShutdown";
import { AlertBreadCrumbsData } from "../../DataModel/AlertBreadCrumbs";

//Spare Parts
import {
  sparePartsSAPJSON, sparePartsSensorJSON,
  sparePartsSAPDropdownJSON, UpdateSpareAHCGroupAssignmentResponse
} from "../../DataModel/SpareParts";

/**
 * Dropdown
*/
function* getRegionDropdownListSaga(action: any) {

  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getRegionListByUserId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = regionDropdownTransformer(response.data);
        yield put({
          type: "Common/getRegionDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getRegionDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getRegionDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = regionDropdownTransformer(regionDropdownList);
    yield put({
      type: "Common/getRegionDropdownListSuccess",
      payload: data,
    });
  }
}
function* getAffiliateDropdownListSaga(action: any) {
  console.log(`${Api.getAffiliateByRegion}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAffiliateByRegion}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = affiliateDropdownTransformer(response.data)
        yield put({
          type: "Common/getAffiliateDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAffiliateDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAffiliateDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = affiliateDropdownTransformer(affiliateDropdownList)
    yield put({
      type: "Common/getAffiliateDropdownListSuccess",
      payload: data,
    });
  }
}
function* getPlantDropdownListSaga(action: any) {
  console.log(`${Api.getPlantListByAffiliate}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantListByAffiliate}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = plantDropdownTransformer(response.data)
        yield put({
          type: "Common/getPlantDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getPlantDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = plantDropdownTransformer(plantDropdownList)
    yield put({
      type: "Common/getPlantDropdownListSuccess",
      payload: data,
    });
  }
}
function* getAssetDropdownListSaga(action: any) {
  console.log(`${Api.getApiAssetListByPlantId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetListByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = assetDropdownTransformer(response.data)
        yield put({
          type: "Common/getAssetDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAssetDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = assetDropdownTransformer(assetDropdownList)
    yield put({
      type: "Common/getAssetDropdownListSuccess",
      payload: data,
    });
  }
}
function* getModelDropdownListSaga(action: any) {
  console.log(`${Api.getApiModelNameDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiModelNameDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = modelDropdownTransformer(response.data)
        yield put({
          type: "Common/getModelDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getModelDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getModelDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = modelDropdownTransformer(modelDropdownList)
    yield put({
      type: "Common/getModelDropdownListSuccess",
      payload: data,
    });
  }
}
function* getModelSensorDropdownListSaga(action: any) {
  console.log(`${Api.getApiModelNameDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiModelNameDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = modelSensorDropdownTransformer(response.data)
        yield put({
          type: "Common/getModelSensorDropdownListSuccess",
          payload: { data: data, list: response.data },
        });
      } else {
        yield put({
          type: "Common/getModelSensorDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getModelSensorDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = modelSensorDropdownTransformer(modelDropdownList)
    yield put({
      type: "Common/getModelSensorDropdownListSuccess",
      payload: { data: data, list: modelDropdownList },
    });
  }
}
function* getModelStatusDropdownListSaga(action: any) {
  console.log(`${Api.getApimodelstatusDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApimodelstatusDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = modelStatusDropdownTransformer(response.data)
        yield put({
          type: "Common/getModelStatusDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getModelStatusDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getModelStatusDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = modelStatusDropdownTransformer(modelStatusDropdownList)
    yield put({
      type: "Common/getModelStatusDropdownListSuccess",
      payload: data,
    });
  }
}
function* getSensorDropdownListSaga(action: any) {
  console.log(`${Api.getplotssensorlist_bysensorgroupId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotssensorlist_bysensorgroupId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = SensorDropdownTransformer(response.data)
        yield put({
          type: "Common/getSensorDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getSensorDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getSensorDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = SensorDropdownTransformer(sensorDropdownList)
    yield put({
      type: "Common/getSensorDropdownListSuccess",
      payload: data,
    });
  }
}
//getApiAlertIDDropdownByAssetID
function* getAlertIDDropdownListSaga(action: any) {
  console.log(`${Api.getApiAlertIDDropdownByAssetID}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getreporttabledata_byplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = AlertIDDropdownTransformer(response.data)
        yield put({
          type: "Common/getAlertIDDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertIDDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertIDDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = AlertIDDropdownTransformer(alertIDDropdownList)
    yield put({
      type: "Common/getAlertIDDropdownListSuccess",
      payload: data,
    });
  }
}
//Alert management Dropdown : start
function* getAlertManagementAffiliatesDroprdown(action: any) {
  console.log(`${Api.getApiAlertManagementAffiliatesDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementAffiliatesDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = alertManagementAffiliatesTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementAffiliatesDroprdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementAffiliatesDroprdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementAffiliatesDroprdownFailure",
        payload: error,
      });
    }
  } else {
    let data = alertManagementAffiliatesTransformer(GetAlertManagementAffiliatesDropdownJSON)
    yield put({
      type: "Common/getAlertManagementAffiliatesDroprdownSuccess",
      payload: data,
    });
  }
}
function* getAlertManagementPlantDroprdown(action: any) {
  console.log(`${Api.getApiAlertManagementPlantDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementPlantDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = alertManagementPlantDroprdownTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementPlantDroprdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementPlantDroprdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementPlantDroprdownFailure",
        payload: error,
      });
    }
  } else {
    let data = alertManagementPlantDroprdownTransformer(GetAlertManagementPlantListDropdownJSON)
    yield put({
      type: "Common/getAlertManagementPlantDroprdownSuccess",
      payload: data,
    });
  }
}
function* getAlertManagementAssetIdDroprdown(action: any) {
  console.log(`${Api.getApiAlertManagementAssetIdDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementAssetIdDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = alertManagementAssetIdDroprdownTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementAssetIdDroprdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementAssetIdDroprdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementAssetIdDroprdownFailure",
        payload: error,
      });
    }
  } else {
    let data = alertManagementAssetIdDroprdownTransformer(GetAlertManagementAssetIdDropdownJSON)
    yield put({
      type: "Common/getAlertManagementAssetIdDroprdownSuccess",
      payload: data,
    });
  }
}
function* getAlertManagementAlertIdDroprdown(action: any) {
  console.log(`${Api.getApiAlertManagementAlertIDDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementAlertIDDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = alertManagementAlertIdDroprdownTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementAlertIdDroprdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementAlertIdDroprdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementAlertIdDroprdownFailure",
        payload: error,
      });
    }
  } else {
    let data = alertManagementAlertIdDroprdownTransformer(GetAlertManagementAlertIdDropdownJSON)
    yield put({
      type: "Common/getAlertManagementAlertIdDroprdownSuccess",
      payload: data,
    });
  }
}
// currentstage
function* getCurrentStageDropdownListSaga(action: any) {
  console.log(`${Api.getApiCurrentStageDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiCurrentStageDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = currentstageDropdownTransformer(response.data)
        yield put({
          type: "Common/getcurrentstageDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getcurrentstageDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getcurrentstageDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = currentstageDropdownTransformer(currentstageDropdownList)
    yield put({
      type: "Common/getcurrentstageDropdownListSuccess",
      payload: data,
    });
  }
}
function* getLongLeadActionDropdownListSaga(action: any) {
  console.log(`${Api.getApiLongLeadActionDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiLongLeadActionDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = longLeadActionDropdownTransformer(response.data)
        yield put({
          type: "Common/getLongLeadActionDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getLongLeadActionDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getLongLeadActionDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = longLeadActionDropdownTransformer(longLeadActionDropdownList)
    console.log("long", data);
    yield put({
      type: "Common/getLongLeadActionDropdownListSuccess",
      payload: data,
    });
  }
}
function* getStatusDropdownListSaga(action: any) {
  console.log(`${Api.getApiStatusDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiStatusDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = statusDropdownTransformer(response.data)
        yield put({
          type: "Common/getStatusDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getStatusDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getStatusDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = statusDropdownTransformer(statusDropdownList)
    console.log("long", data);
    yield put({
      type: "Common/getStatusDropdownListSuccess",
      payload: data,
    });
  }
}


/**
 * Home Page
*/
function* getGlobalTopBarSummary(action: any) {

  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiGlobalTopBarSummaryByUserId}`,
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getGlobalTopBarSummarySuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getGlobalTopBarSummaryFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getGlobalTopBarSummaryFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getGlobalTopBarSummarySuccess",
      payload: GetGlobalTopBarSummaryByUserIdJSON,
    });
  }
}
function* getGlobalMapSummaryByUserId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIGlobalMapSummaryByUserId}`,
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getGlobalMapSummaryByUserIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getGlobalMapSummaryByUserIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getGlobalMapSummaryByUserIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getGlobalMapSummaryByUserIdSuccess",
      payload: GetGlobalMapSummaryByUserIdJSON,
    });
  }
}
function* getGlobalRegionMapSummaryByUserId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIGlobalRegionMapSummaryByUserId}`,
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getGlobalRegionMapSummaryByUserIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getGlobalRegionMapSummaryByUserIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getGlobalRegionMapSummaryByUserIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getGlobalRegionMapSummaryByUserIdSuccess",
      payload: GetGlobalRegionMapSummaryByUserIdJSON,
    });
  }
}
/**
 * Affiliate page
*/
function* getAffiliateTopBarSaga(action: any) {
  // console.log(`${Api.getAffiliateTopBar}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAffiliateTopBar}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAffiliateTopBarSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAffiliateTopBarFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAffiliateTopBarFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAffiliateTopBarSuccess",
      payload: affiliateTopBar,
    });
  }
}
function* getAffiliateDetailsSaga(action: any) {
  console.log(`${Api.getAffiliateDetails}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAffiliateDetails}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAffiliateDetailsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAffiliateDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAffiliateDetailsFailure",
        payload: error,
      });
    }
  } else {

    yield put({
      type: "Common/getAffiliateDetailsSuccess",
      payload: affiliateDetailsData,
    });
  }
}
/**
 * Plant page
*/
function* getPlantTopBarSaga(action: any) {
  console.log(`${Api.getPlantTopBar}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantTopBar}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantTopBarSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantTopBarFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantTopBarFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantTopBarSuccess",
      payload: plantTopBar,
    });
  }
}
function* getPlantDetailsSaga(action: any) {
  console.log(`${Api.getPlantDetails}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantDetails}${action.payload}`
      );
      if (response.status == 200) {
        let data = plantDetailTransformer(response.data)
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantDetailsSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getPlantDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantDetailsFailure",
        payload: error,
      });
    }
  } else {
    let data = plantDetailTransformer(plantDetailsData)
    yield put({
      type: "Common/getPlantDetailsSuccess",
      payload: data,
    });
  }
}
/**
   * Pmt page
*/
function* getAssetListByPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetListByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetListByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetListByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetListByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetListByPlantIdSuccess",
      payload: getassetlistByplantid,
    });
  }
}
function* getPlantAlertSpmt(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiPlantAlertsPmt}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantAlertSpmtSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantAlertSpmtFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantAlertSpmtFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantAlertSpmtSuccess",
      payload: getplantAlertspmt,
    });
  }
}
function* getAssetCardPmtByPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetcardpmtByplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetCardPmtByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetCardPmtByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetCardPmtByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetCardPmtByPlantIdSuccess",
      payload: getassetcardpmtByplantid,
    });
  }
}
function* getAssetCardPmtByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiassetcardpmtByassetid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetCardPmtByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetCardPmtByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetCardPmtByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetCardPmtByAssetIdSuccess",
      payload: getassetcardpmtByassetid,
    });
  }
}
function* getAssetStatusPmtByPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetstatuspmtByplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetStatusPmtByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetStatusPmtByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetStatusPmtByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetStatusPmtByPlantIdSuccess",
      payload: getassetstatuspmtByplantid,
    });
  }
}
function* getStatusAssetPmtByPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiTopbarsummaryAssetpmtByplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getStatusAssetPmtByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getStatusAssetPmtByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getStatusAssetPmtByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getStatusAssetPmtByPlantIdSuccess",
      payload: gettopbarsummaryAssetpmtByplantid,
    });
  }
}
function* getssetStatusListbyPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetstatuspmtByplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getssetStatusListbyPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getssetStatusListbyPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getssetStatusListbyPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getssetStatusListbyPlantIdSuccess",
      payload: getJsonAssetStatusListbyPlantId,
    });
  }
}
function* getHeatMapToolTipbyAssetStatus(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiHeatMapToolTipbyAssetStatus}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getHeatMapToolTipbyAssetStatusSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getHeatMapToolTipbyAssetStatusFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getHeatMapToolTipbyAssetStatusFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getHeatMapToolTipbyAssetStatusSuccess",
      payload: getJsonHeatMapToolTipbyAssetStatus,
    });
  }
}
function* getTopBarToolTipbyPlantId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiTopBarToolTipbyPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getTopBarToolTipbyPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getTopBarToolTipbyPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getTopBarToolTipbyPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getTopBarToolTipbyPlantIdSuccess",
      payload: getJsonTopBarToolTipbyPlantId,
    });
  }
}
/**
  * Alert Satistics
*/
/**
 * Alert Dashboard
*/
function* getAssetPieChart(action: any) {
  console.log(`${Api.getAssetAlertStatusByPlantId_alertstatistics}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAssetAlertStatusByPlantId_alertstatistics}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetPieChartSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetPieChartFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetPieChartFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetPieChartSuccess",
      payload: getAlertStatusAsset,
    });
  }
}
function* getAssetStackedBar(action: any) {
  console.log(`${Api.getTotalAssetAlertStatusByPlantId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getTotalAssetAlertStatusByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetStackedBarSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetStackedBarFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetStackedBarFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetStackedBarSuccess",
      payload: getStackedBarAsset,
    });
  }
}
function* getDepartementStackedBar(action: any) {
  console.log(`${Api.GetDepartmentAlertStatusByPlantId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.GetDepartmentAlertStatusByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getDepartementStackedBarSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getDepartementStackedBarFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getDepartementStackedBarFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getDepartementStackedBarSuccess",
      payload: getStackedBarDepartment,
    });
  }
}

function* getPerformaceChart(action: any) {
  console.log(`${Api.getPlantPerformanceTrendByPlantId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantPerformanceTrendByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPerformaceChartSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPerformaceChartFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPerformaceChartFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPerformaceChartSuccess",
      payload: getPerormanceTrend,
    });
  }
}
/**
 * Alert List
*/
function* getAlertStatisticsAlertListByPlantId(action: any) {
  console.log(`${Api.getApiAlertStatisticsAlertListByPlantId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertStatisticsAlertListByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAlertStatisticsAlertListByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertStatisticsAlertListByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertStatisticsAlertListByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertStatisticsAlertListByPlantIdSuccess",
      payload: AlertStatisticsAlertListByPlantId,
    });
  }
}
/**
 * PLANT TIMELINE
*/
function* getPlantTimelineByPlantId(action: any) {
  console.log(`${Api.getApiPlantTimeLine}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiPlantTimeLine}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantTimelineByPlantIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantTimelineByPlantIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantTimelineByPlantIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantTimelineByPlantIdSuccess",
      payload: getplanttimelinebyplantidjson,
    });
  }
}
/**
  * Model Performance
*/
/**
  * Performnace dashboard
*/
function* getmodelalertstatuspiechart(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getmodelalertstatusbyassebyplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getmodelalertstatuspiechartSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getmodelalertstatuspiechartFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getmodelalertstatuspiechartFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getmodelalertstatuspiechartSuccess",
      payload: getmodelalertstatusbyassetbyplantid,
    });
  }
}
function* getmodeltotalalertstatusbyasset(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getmodeltotalalertstatusbyasset_byplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getmodeltotalalertstatusbyassetSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getmodeltotalalertstatusbyassetFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getmodeltotalalertstatusbyassetFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getmodeltotalalertstatusbyassetSuccess",
      payload: getmodeltotalalertstatusbyasset_byplantid,
    });
  }
}
function* getmodelalertstatusbydepartmentbyplant(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getmodelalertstatusbydepartmentbyplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getmodelalertstatusbydepartmentbyplantSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getmodelalertstatusbydepartmentbyplantFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getmodelalertstatusbydepartmentbyplantFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getmodelalertstatusbydepartmentbyplantSuccess",
      payload: getmodelalertstatusbydepartmentbyplantid,
    });
  }
}
/**
  * MonthWise Table
*/
function* getplantmodelbasedtabledatabyplant(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplantmodelbasedtabledata_byplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getplantmodelbasedtabledatabyplantidSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getplantmodelbasedtabledatabyplantidFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getplantmodelbasedtabledatabyplantidFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getplantmodelbasedtabledatabyplantidSuccess",
      payload: getplantmodelbasedtabledata_byplantid,
    });
  }
}

//PmCompliance table
function* getpmcompliancedata(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPMCompliance_Details}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPMComplianceSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPMComplianceFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPMComplianceFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPMComplianceSuccess",
      payload: getPMComplianceDetail,
    });
  }
}/**pmcompliance end
/**
 * Monthwise Barchart
*/
function* getplantmonthwisebarchartdata(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplantmonthwisebarchartdata_byplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getplantmonthwisebarchartdata_byplantidSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getplantmonthwisebarchartdata_byplantidFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getplantmonthwisebarchartdata_byplantidFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getplantmonthwisebarchartdata_byplantidSuccess",
      payload: getplantmonthwisebarchartdata_byplantid,
    });
  }
}
/**
  * Alert Management
*/
//getmytasktable
function* getMyTaskTable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiMyTaskTable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getMyTaskTableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getMyTaskTableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getMyTaskTableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getMyTaskTableSuccess",
      payload: myTaskTableData,
    });
  }
}
//report table
function* getreporttable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApireporttable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getreporttableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getreporttableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getreporttableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getreporttableSuccess",
      payload: reportData,
    });
  }
}
//utilization report
function* getutilizationreporttable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiutilizationreporttable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getutilizationreporttableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getutilizationreporttableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getutilizationreporttableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getutilizationreporttableSuccess",
      payload: utilizationReportData,
    });
  }
}
// master data report - getmasterdatareporttable
function* getmasterdatareporttable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApimasterdatareportdatatable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getmasterdatareporttableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getmasterdatareporttableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getmasterdatareporttableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getmasterdatareporttableSuccess",
      payload: masterDataReportData,
    });
  }
}
//Alert Details
function* getAlertDetailsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getahcalertdetails_byalertid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAlertDetailsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertDetailsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertDetailsSuccess",
      payload: alertDetailsData,
    });
  }
}
/*
   Workflow
*/
function* getWorkflowAlertDetailsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getahcalertdetails_byalertid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getWorkflowAlertDetailsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getWorkflowAlertDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getWorkflowAlertDetailsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getWorkflowAlertDetailsSuccess",
      payload: alertDetailsData,
    });
  }
  // yield put({
  //   type: "Common/getWorkflowAlertDetailsSuccess",
  //   payload: alertDetailsData,
  // });
}

function* getWorkflowRequestLogSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementRequestLogTable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getWorkflowRequestLogSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getWorkflowRequestLogFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getWorkflowRequestLogFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getWorkflowRequestLogSuccess",
      payload: GetAHCRequestLogByRequestIdJSON,
    });
  }
  // yield put({
  //   type: "Common/getWorkflowRequestLogSuccess",
  //   payload: GetAHCRequestLogByRequestIdJSON,
  // });
}

function* getWorkflowSearchDataSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getSearchUserforAlertAssignment}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getWorkflowSearchDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getWorkflowSearchDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getWorkflowSearchDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getWorkflowSearchDataSuccess",
      payload: WorkflowSearchData,
    });
  }
  // yield put({
  //   type: "Common/getWorkflowSearchDataSuccess",
  //   payload: WorkflowSearchData,
  // });
}

function* getWorkflowAttachementDetailsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAhcAttachments}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getWorkflowAttachementDetailsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getWorkflowAttachementDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getWorkflowAttachementDetailsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getWorkflowAttachementDetailsSuccess",
      payload: getAttachementData,
    });
  }
  // yield put({
  //   type: "Common/getWorkflowAttachementDetailsSuccess",
  //   payload: getAttachementData,
  // });
}
function* getWorkflowUserRoleSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getRoleName}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getWorkflowUserRoleSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getWorkflowUserRoleFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getWorkflowUserRoleFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getWorkflowUserRoleSuccess",
      payload: WorkflowUserData,
    });
  }
}
/*
Upload Attachements
*/
function* uploadAttachementsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.updateAhcAttachement}`, action.payload);
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/uploadAttachementsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/uploadAttachementsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/uploadAttachementsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/uploadAttachementsSuccess",
      payload: "success",
    });
  }

}
function* updateWorkflowStatusSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.updateIbmWorkflow}`, action.payload);
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateWorkflowStatusSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/updateWorkflowStatusFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/updateWorkflowStatusFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/updateWorkflowStatusSuccess",
      payload: "success",
    });
  }

}
/**
* Asset Model
*/
function* getassetlistOfAssetModelByplantid(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetlistOfAssetModelByplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getassetlistOfAssetModelByplantidSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getassetlistOfAssetModelByplantidFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getassetlistOfAssetModelByplantidFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getassetlistOfAssetModelByplantidSuccess",
      payload: getassetlistByplantidOfAssetModel,
    });
  }
}

function* getAnomalyModelbyAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAnomalyModelbyAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAnomalyModelbyAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAnomalyModelbyAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAnomalyModelbyAssetIdFailure",
        payload: error,
      });
    }
  } else {
    // yield put({
    //   type: "Common/getAnomalyModelbyAssetIdSuccess",
    //   payload: getAnomalyModelbyassetidinAssetModel,
    // });

    if (action.payload.assetId !== 0 || null) {
      yield put({
        type: "Common/getAnomalyModelbyAssetIdSuccess",
        payload: getAnomalyModelbyassetidinAssetModel.filter((item: any) => item.assetId === action.payload.assetId)

      });
    }
    else {
      yield put({
        type: "Common/getAnomalyModelbyAssetIdSuccess",
        payload: getAnomalyModelbyassetidinAssetModel,
      });
    }

  }
}
function* getFailurepreDictionByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiFailurepreDictionByAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getFailurepreDictionByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getFailurepreDictionByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getFailurepreDictionByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getFailurepreDictionByAssetIdSuccess",
      payload: getFailurepredictionbyassetidAssetModel,
    });
  }
}
function* getGraphicalImageByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiGraphicalImageByAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getGraphicalImageByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getGraphicalImageByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getGraphicalImageByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    if (action.payload.assetId !== 0 || null) {
      yield put({
        type: "Common/getGraphicalImageByAssetIdSuccess",
        // payload: getGraphicalImageForAssetModel.filter((item: any) => item.assetId === action.assetId)
        payload: getGraphicalImageForAssetModel,

      });
    }
    else {
      yield put({
        type: "Common/getGraphicalImageByAssetIdSuccess",
        payload: getGraphicalImageForAssetModel,
      });
    }
  }
}
function* getAssetKPI(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetKPIForAssetModel}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetKPISuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetKPIFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetKPIFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetKPISuccess",
      payload: getAssetKPIForAssetModel,
    });
  }
}
/**
 * Livetracking
*/
function* getLivetrackingtable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.getApiLivetrackingtable}`,
        action.payload,
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getLivetrackingtableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getLivetrackingtableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getLivetrackingtableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getLivetrackingtableSuccess",
      payload: livetrackingtableData,
    });
  }
}
/**
 * ASSET TIMELINE
*/
function* getAssetHealthIndexByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAssetHealthIndexByAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetHealthIndexByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetHealthIndexByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetHealthIndexByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetHealthIndexByAssetIdSuccess",
      payload: getAssetHealthIndexByAssetIdJson,
    });
  }
}
function* getMaintenanceHistoryByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiMaintenanceHistoryByAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getMaintenanceHistoryByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getMaintenanceHistoryByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getMaintenanceHistoryByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getMaintenanceHistoryByAssetIdSuccess",
      payload: getmaintenancehistoryjson,
    });
  }
}
function* getHanaIncidentByAssetId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiHanaIncidentByAssetId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getHanaIncidentByAssetIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getHanaIncidentByAssetIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getHanaIncidentByAssetIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getHanaIncidentByAssetIdSuccess",
      payload: GetHanaIncidentByAssetIdjson,
    });
  }
}
/**
  * Asset Alert List
*/
function* getAlertListtable(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertListtable}${action.payload}`
      );

      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);

        yield put({
          type: "Common/getAlertListtableSuccess",

          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertListtableFailure",

          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertListtableFailure",

        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertListtableSuccess",

      payload: alertListData,
    });
  }
}
function* getAlertListTopBarSummary(action: any) {
  console.log(`${Api.getApiAlertListTopBarSummary}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertListTopBarSummary}${action.payload}`
      );

      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);

        yield put({
          type: "Common/getAlertListTopBarSummarySuccess",

          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertListTopBarSummaryFailure",

          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertListTopBarSummaryFailure",

        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertListTopBarSummarySuccess",

      payload: topbarData,
    });
  }
}
function* getAlertListAssetIDDropdown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertListAssetIDDropdown}${action.payload}`
      );

      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);

        yield put({
          type: "Common/getAlertListAssetIDDropdownSuccess",

          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertListAssetIDDropdownFailure",

          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertListAssetIDDropdownFailure",

        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertListAssetIDDropdownSuccess",

      payload: assetIdDropdown,
    });
  }
}
function* getAlertListModelNameDropdown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertListModelNameDropdown}${action.payload}`
      );

      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);

        yield put({
          type: "Common/getAlertListModelNameDropdownSuccess",

          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertListModelNameDropdownFailure",

          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertListModelNameDropdownFailure",

        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertListModelNameDropdownSuccess",

      payload: modelNameDropdown,
    });
  }
}
function* getAlertListModelStatusDropdown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertListModelStatusDropdown}${action.payload}`
      );

      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);

        yield put({
          type: "Common/getAlertListModelStatusDropdownSuccess",

          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertListModelStatusDropdownFailure",

          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertListModelStatusDropdownFailure",

        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertListModelStatusDropdownSuccess",

      payload: modelStatusDropdown,
    });
  }
}
/**
  * plot Screen
*/
function* getPlotModelDropDown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotsmodel_byassetid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotModelDropDownSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotModelDropDownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotModelDropDownFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotModelDropDownSuccess",
      payload: getModelDropdownData,
    });
  }
}
function* getPlotAssetDropDown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotsassetlist_byplantid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotAssetDropDownSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotAssetDropDownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotAssetDropDownFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotAssetDropDownSuccess",
      payload: getAssetDropdownData,
    });
  }
}
function* getPlotSensorDropDown(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotssensorlist_bysensorgroupId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotSensorDropDownSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotSensorDropDownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotSensorDropDownFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotSensorDropDownSuccess",
      payload: getSensorDropdownData,
    });
  }
}
function* getPlotDeviationData(action: any) {
  //console.log(action);
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotsdeviationgraph_byassetid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotDeviationDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotDeviationDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotDeviationDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotDeviationDataSuccess",
      payload: getDeviationGraphData,
    });
  }
}
function* getPlotDeviationModelSaga(action: any) {
  // console.log(action);
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getplotsmodeldeviation_bymodelid}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotDeviationModelSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotDeviationModelFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotDeviationModelFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotDeviationModelSuccess",
      payload: getPlotDeviationModel,
    });
  }
}
function* getPlotSensorDataSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.getplotSensor_data}`,
        action.payload
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlotSensorDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlotSensorDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlotSensorDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlotSensorDataSuccess",
      payload: getPlotSensorData,
    });
  }
}
/**
  * ReferenceTablePage 
*/
function* getReferenceTableModelData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getReferenceTableModelData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getReferenceTableModelDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getReferenceTableModelDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getReferenceTableModelDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getReferenceTableModelDataSuccess",
      payload: getReferenceTableModelDataInput,
    });
  }
}
function* getReferenceOffilineData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getOfflineModelData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getReferenceOffilineDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getReferenceOffilineDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getReferenceOffilineDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getReferenceOffilineDataSuccess",
      payload: getOfflineModelDataInput,
    });
  }
}

// Global Search
function* getGlobalSearch(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(`${Api.getblobalsearchlist}`);
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getGlobalSearchSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getGlobalSearchFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getGlobalSearchFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getGlobalSearchSuccess",
      payload: Search,
    });
  }
}

/**
  * Admin Configuration
*/
function* getAffiliateRolloutData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAffiliatesRolloutData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAffiliateRolloutSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAffiliateRolloutFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAffiliateRolloutFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAffiliateRolloutSuccess",
      payload: affiliateRolloutData,
    });
  }

}

function* getPlantRolloutData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantsRolloutData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantRolloutSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantRolloutFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantRolloutFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantRolloutSuccess",
      payload: plantRolloutData,
    });
  }
}

function* updateAffiliateRolloutData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.updateAffiliateRolloutStatus}`, action.payload
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateAffiliateRolloutSuccess",
          payload: response.data,
        });
      } else if (response.status == 404) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateAffiliateRolloutSuccess",
          payload: response.data,
        });
      }
      else {
        yield put({
          type: "Common/updateAffiliateRolloutFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/updateAffiliateRolloutFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/updateAffiliateRolloutSuccess",
      payload: affiliateRolloutData,
    });

  }

}

function* updatePlantRolloutData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.updatePlantRolloutStatus}${action.payload}`,
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updatePlantRolloutSuccess",
          payload: response.data,
        });
      } else if (response.status == 404) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updatePlantRolloutSuccess",
          payload: response.data,
        });
      }
      else {
        yield put({
          type: "Common/updatePlantRolloutFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/updatePlantRolloutFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/updatePlantRolloutSuccess",
      payload: plantRolloutData,
    });
  }
}

function* getAssetModelConfigTableDataSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAssetModelConfigDetails}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAssetModelConfigTableDataSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAssetModelConfigTableDataFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetModelConfigTableDataFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAssetModelConfigTableDataSuccess",
      payload: assetModelConfigTableData,
    });
  }
}

function* updateAssetModelConfigTableStatusSaga(action: any) {
  console.log("updateAssetModelConfigTableStatusSaga")
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(`${Api.updateAssetModelConfigDetails}`, action.payload);
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateAssetModelConfigTableStatusSuccess",
          payload: response.data,
        });
      } else if (response.status == 404) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateAssetModelConfigTableStatusSuccess",
          payload: response.data,
        });
      }
      else {
        yield put({
          type: "Common/updateAssetModelConfigTableStatusFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/updateAssetModelConfigTableStatusFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/updateAssetModelConfigTableStatusSuccess",
      payload: assetModelConfigTableStatus,
    });
  }
}

function* getExceptionLogsData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getExceptionLogs}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getExceptionLogSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getExceptionLogFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getExceptionLogFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getExceptionLogSuccess",
      payload: exceptionLogsData,
    });
  }
}
function* getRoleMappingRoleDropdownListSaga(action: any) {
  if (HTTP_CALL === 'Active') {

    try {

      const response = yield getRequest(

        `${Api.getRoleListByUserid}${action.payload}`

      );

      if (response.status == 200) {

        console.log("GET POST RESPONSE DATA", response.data);

        let data = roleMappingRoleDropdownTransformer(response.data)

        yield put({

          type: "Common/getRoleMappingRoleDropdownListSuccess",

          payload: data,

        });

      } else {

        yield put({

          type: "Common/getRoleMappingRoleDropdownListFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/getRoleMappingRoleDropdownListFailure",

        payload: error,

      });

    }

  } else {

    let data = roleMappingRoleDropdownTransformer(roleListData)

    yield put({

      type: "Common/getRoleMappingRoleDropdownListSuccess",

      payload: data,

    });

  }

}

function* getRoleMappingPlantDropdownListSaga(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield getRequest(

        `${Api.getplantlistbyaffiliateid}${action.payload}`

      );

      if (response.status == 200) {

        console.log("GET POST RESPONSE DATA", response.data);

        let data = roleMappingPlantDropdownTransformer(response.data)

        yield put({

          type: "Common/getRoleMappingPlantDropdownListSuccess",

          payload: data,

        });

      } else {

        yield put({

          type: "Common/getRoleMappingPlantDropdownListFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/getRoleMappingPlantDropdownListFailure",

        payload: error,

      });

    }

  } else {

    let data = roleMappingPlantDropdownTransformer(roleMappingPlantListData)

    yield put({

      type: "Common/getRoleMappingPlantDropdownListSuccess",

      payload: data,

    });

  }

}

function* getRoleMappingAffiliateDropdownListSaga(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield getRequest(

        `${Api.getaffiliateslistbyuserid}${action.payload}`

      );

      if (response.status == 200) {

        console.log("GET POST RESPONSE DATA", response.data);

        let data = roleMappingAffiliateDropdownTransformer(response.data)

        yield put({

          type: "Common/getRoleMappingAffiliateDropdownListSuccess",

          payload: data,

        });

      } else {

        yield put({

          type: "Common/getRoleMappingAffiliateDropdownListFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/getRoleMappingAffiliateDropdownListFailure",

        payload: error,

      });

    }

  } else {

    let data = roleMappingAffiliateDropdownTransformer(roleMappingAffiliateListData)

    yield put({

      type: "Common/getRoleMappingAffiliateDropdownListSuccess",

      payload: data,

    });

  }

}

function* addRoleMappingData(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield postRequest(

        `${Api.addUserRoleMapping}`, action.payload

      );

      if (response.status == 200) {

        console.log("GET POST RESPONSE DATA", response.data);

        yield put({

          type: "Common/addRoleMappingSuccess",

          payload: response.data,

        });

      } else if (response.status == 404) {

        console.log("GET POST RESPONSE DATA", response.data);

        yield put({

          type: "Common/addRoleMappingSuccess",

          payload: response.data,

        });

      }
      else {

        yield put({

          type: "Common/addRoleMappingFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/addRoleMappingFailure",

        payload: error,

      });

    }

  } else {

    yield put({

      type: "Common/addRoleMappingSuccess",

      payload: addUserRollmapDataAPIResponse,

    });

  }

}


function* updateRoleMappingData(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield postRequest(

        `${Api.updateUserRoleMapping}`, action.payload

      );

      if (response.status == 200) {

        console.log("GET POST RESPONSE DATA", response.data);

        yield put({

          type: "Common/updateRoleMappingSuccess",

          payload: response.data,

        });

      } else if (response.status == 404) {

        console.log("GET POST RESPONSE DATA", response.data);

        yield put({

          type: "Common/updateRoleMappingSuccess",

          payload: response.data,

        });

      }

      else {

        yield put({

          type: "Common/updateRoleMappingFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/updateRoleMappingFailure",

        payload: error,

      });

    }

  } else {

    yield put({

      type: "Common/updateRoleMappingSuccess",

      payload: updateUserRollmapDataAPIResponse,

    });

  }

}

function* getRoleMappingWorklistData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getUserRoleMappingWorklist}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getRoleMappingWorklistSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getRoleMappingWorklistFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getRoleMappingWorklistFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getRoleMappingWorklistSuccess",
      payload: userRoleMappingWorklist,
    });
  }

}

function* getEmployeeListData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getEmployeeWorkList}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getEmployeeListSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getEmployeeListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getEmployeeListFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getEmployeeListSuccess",
      payload: employeeDataList,
    });
  }

}

//Alert management->Report view->Log Table

function* getRequestLogTable(action: any) {
  console.log("getRequestLogTableSaga")
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiAlertManagementRequestLogTable}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getRequestLogTableSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getRequestLogTableFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getRequestLogTableFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getRequestLogTableSuccess",
      payload: GetAHCRequestLogByRequestIdJSON,
    });
  }
}

function* getAlertAttachementDetailsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAhcAttachments}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getAlertAttachementDetailsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertAttachementDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertAttachementDetailsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertAttachementDetailsSuccess",
      payload: getAttachementData,
    });
  }
}
// User Profile Start
function* getLoggedInUserDetails(action: any) {

  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getApiLoggedInUserDetails}${action.payload}`, true
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getLoggedInUserDetailsSuccess",
          payload: response.data,
        });
      } else if (response.status == 404) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getLoggedInUserDetailsSuccess",
          payload: response.data,
        });
      }
      else {
        yield put({
          type: "Common/getLoggedInUserDetailsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getLoggedInUserDetailsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getLoggedInUserDetailsSuccess",
      payload: getLoggedInUserDetailsJSON,
    });
  }
}
//Asset model config dropdown
function* getAssetModelConfigDropdownListSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAssetModelConfigApiAssetListByPlantId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = assetDropdownTransformer(response.data)
        yield put({
          type: "Common/getAssetModelConfigDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAssetModelConfigDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAssetModelConfigDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = assetDropdownTransformer(assetDropdownList)
    yield put({
      type: "Common/getAssetModelConfigDropdownListSuccess",
      payload: data,
    });
  }
}
function* getAssetModelConfigAffiliateDropdownListSaga(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield getRequest(

        `${Api.getAssetModelConfigApiAffiliateList}${action.payload}`

      );

      if (response.status == 200) {

        // console.log("GET POST RESPONSE DATA", response.data);

        let data = affiliateDropdownTransformerAssetConfig(response.data)

        yield put({

          type: "Common/getAssetModelConfigAffiliateDropdownListSuccess",

          payload: data,

        });

      } else {

        yield put({

          type: "Common/getAssetModelConfigAffiliateDropdownListFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/getAssetModelConfigAffiliateDropdownListFailure",

        payload: error,

      });

    }

  } else {

    let data = affiliateDropdownTransformerAssetConfig(affiliateDropdownList)

    yield put({

      type: "Common/getAssetModelConfigAffiliateDropdownListSuccess",

      payload: data,

    });

  }

}

function* getAssetModelConfigPlantDropdownListSaga(action: any) {

  if (HTTP_CALL === 'Active') {

    try {

      const response = yield getRequest(

        `${Api.getAssetModelConfigApiPlantListByAffiliateId}${action.payload}`

      );

      if (response.status == 200) {

        // console.log("GET POST RESPONSE DATA", response.data);

        let data = plantDropdownTransformer(response.data)

        yield put({

          type: "Common/getAssetModelConfigPlantDropdownListSuccess",

          payload: data,

        });

      } else {

        yield put({

          type: "Common/getAssetModelConfigPlantDropdownListFailure",

          payload: "not 200",

        });

      }

    } catch (error) {

      yield put({

        type: "Common/getAssetModelConfigPlantDropdownListFailure",

        payload: error,

      });

    }

  } else {

    let data = plantDropdownTransformer(plantDropdownList)

    yield put({

      type: "Common/getAssetModelConfigPlantDropdownListSuccess",

      payload: data,

    });

  }

}

function* getPlantAlertListStateDropdownListSaga(action: any) {
  //console.log(`${Api.getRegionListByUserId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIPlantAlertListStateDropdownList}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = plantAlertListStateDropdownTransformer(response.data);
        yield put({
          type: "Common/getPlantAlertListStateDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getPlantAlertListStateDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantAlertListStateDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = plantAlertListStateDropdownTransformer(plantAlertListStateDropdownJSON);
    yield put({
      type: "Common/getPlantAlertListStateDropdownListSuccess",
      payload: data,
    });
  }
}

//Alert Statistics
function* getPlantUtilizationTimeData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantUtilizationResponseTime}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantUtilizationTimeSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantUtilizationTimeFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantUtilizationTimeFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantUtilizationTimeSuccess",
      payload: plantUtilizationResponseTime,
    });
  }

}

function* getExceptionLogData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getExceptionAPILogId}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getExceptionLogByIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getExceptionLogByIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getExceptionLogByIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getExceptionLogByIdSuccess",
      payload: exceptionLogJSON,
    });
  }
}


function* getPlantAlertListDepartmentDropdownListSaga(action: any) {
  //console.log(`${Api.getRegionListByUserId}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIPlantAlertListDepartmentDropdownList}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = plantAlertListDepartmentDropdownTransformer(response.data);
        yield put({
          type: "Common/getPlantAlertListDepartmentDropdownListSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getPlantAlertListDepartmentDropdownListFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantAlertListDepartmentDropdownListFailure",
        payload: error,
      });
    }
  } else {
    let data = plantAlertListDepartmentDropdownTransformer(plantAlertListDepartmentDropdownJSON);
    yield put({
      type: "Common/getPlantAlertListDepartmentDropdownListSuccess",
      payload: data,
    });
  }
}

//Plant Shutdown
function* getPlantShutdownData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getPlantsShutdownData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getPlantShutdownSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getPlantShutdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getPlantShutdownFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getPlantShutdownSuccess",
      payload: plantShutdownData,
    });
  }
}

//Spare Parts
function* getSparePartsSAPData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getSparePartsSAPTableData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getSparePartsSAPSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getSparePartsSAPFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getSparePartsSAPFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getSparePartsSAPSuccess",
      payload: sparePartsSAPJSON,
    });
  }
}
function* getSparePartsSensorData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getSparePartsSensorTableData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getSparePartsSensorSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getSparePartsSensorFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getSparePartsSensorFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getSparePartsSensorSuccess",
      payload: sparePartsSensorJSON,
    });
  }
}

function* getSparePartsSAPDropdownSaga(action: any) {
  console.log(`${Api.getSparePartsSAPTableDropdownData}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getSparePartsSAPTableDropdownData}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = sparePartsSensorGroupDropdownTransformer(response.data)
        yield put({
          type: "Common/getSparePartsSAPDropdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getSparePartsSAPDropdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getSparePartsSAPDropdownFailure",
        payload: error,
      });
    }
  } else {
    let data = sparePartsSensorGroupDropdownTransformer(sparePartsSAPDropdownJSON)
    yield put({
      type: "Common/getSparePartsSAPDropdownSuccess",
      payload: data,
    });
  }
}

function* updateSparePartsSapData(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield postRequest(
        `${Api.UpdateSpareAHCGroupAssignment}`, action.payload
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateSparePartsSapSuccess",
          payload: response.data,
        });
      } else if (response.status == 404) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/updateSparePartsSapSuccess",
          payload: response.data,
        });
      }
      else {
        yield put({
          type: "Common/updateSparePartsSapFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/updateSparePartsSapFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/updateSparePartsSapSuccess",
      payload: UpdateSpareAHCGroupAssignmentResponse,
    });
  }
}

//Home Page
function* getregions(action: any) {
  // if (HTTP_CALL ==='Active' ==='true;' ==='true') {
  //     try {
  //         const response = yield getRequest(`${Api.getAllRegions}${action.payload}`);
  //         console.log('GET POST RESPONSE DATA', response);
  //         if (response.status == 200) {
  //             // console.log('GET POST RESPONSE DATA', response.data);
  //             yield put({
  //                 type: "Common/getRegionSuccess",
  //                 payload: response.data

  //             });
  //         } else {
  //             yield put({
  //                 type: "Common/getRegionsFailure",
  //                 payload: "not 200",
  //             });
  //         }
  //     } catch (error) {
  //         yield put({
  //             type: "Common/getRegionsFailure",
  //             payload: error,
  //         });
  //     }
  // }
  // else {
  //     yield put({
  //         type: "Common/getRegionSuccess",
  //         payload: region

  //     });
  // }
  yield put({
    type: "Common/getRegionSuccess",
    payload: ["manoj"],
  });
}

//Plant Shutdown
function* getAlertBreadCrumbsSaga(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAlertBreadCrumbApi}${action.payload}`
      );
      if (response.status == 200) {
        yield put({
          type: "Common/getAlertBreadCrumbsSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getAlertBreadCrumbsFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertBreadCrumbsFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getAlertBreadCrumbsSuccess",
      payload: AlertBreadCrumbsData,
    });
  }
}
//work flow page
function* getIBMAlertDetailsByAlertId(action: any) {
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIIBMAlertDetailsByAlertId}${action.payload}`
      );
      if (response.status == 200) {
        yield put({
          type: "Common/getIBMAlertDetailsByAlertIdSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getIBMAlertDetailsByAlertIdFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getIBMAlertDetailsByAlertIdFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getIBMAlertDetailsByAlertIdSuccess",
      payload: getibmalertdetailsbyalertIdJSON,
    });
  }
}
function* getConsultSomeoneSaga(action: any) {
  console.log("API Called");
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.alertManagementConsultSomeone}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        yield put({
          type: "Common/getConsultSomeoneSuccess",
          payload: response.data,
        });
      } else {
        yield put({
          type: "Common/getConsultSomeoneFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getConsultSomeoneFailure",
        payload: error,
      });
    }
  } else {
    yield put({
      type: "Common/getConsultSomeoneSuccess",
      payload: consultSomeoneDataResponse,
    });
  }
}
//Utilization Report Year Month
function* getAlertManagementYearDropdown(action: any) {
  console.log(`${Api.getAPIAlertManagementYearDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIAlertManagementYearDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = getAlertManagementYearDropdownTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementYearDropdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementYearDropdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementYearDropdownFailure",
        payload: error,
      });
    }
  } else {
    let data = getAlertManagementYearDropdownTransformer(GetAlertManagementYearList)
    yield put({
      type: "Common/getAlertManagementYearDropdownSuccess",
      payload: data,
    });
  }
}
function* getAlertManagementMonthDropdown(action: any) {
  console.log(`${Api.getAPIAlertManagementMonthDropdown}${action.payload}`)
  if (HTTP_CALL === 'Active') {
    try {
      const response = yield getRequest(
        `${Api.getAPIAlertManagementMonthDropdown}${action.payload}`
      );
      if (response.status == 200) {
        console.log("GET POST RESPONSE DATA", response.data);
        let data = getAlertManagementMonthDropdownTransformer(response.data)
        yield put({
          type: "Common/getAlertManagementMonthDropdownSuccess",
          payload: data,
        });
      } else {
        yield put({
          type: "Common/getAlertManagementMonthDropdownFailure",
          payload: "not 200",
        });
      }
    } catch (error) {
      yield put({
        type: "Common/getAlertManagementMonthDropdownFailure",
        payload: error,
      });
    }
  } else {
    let data = getAlertManagementMonthDropdownTransformer(GetAlertManagementMonthList)
    yield put({
      type: "Common/getAlertManagementMonthDropdownSuccess",
      payload: data,
    });
  }
}


export default function* mySaga() {
  yield takeEvery("Common/getRegions", getregions);
  yield takeEvery("Common/getAssetListByPlantId", getAssetListByPlantId);
  yield takeEvery("Common/getPlantAlertSpmt", getPlantAlertSpmt);
  yield takeEvery("Common/getAssetCardPmtByPlantId", getAssetCardPmtByPlantId);
  yield takeEvery("Common/getAssetCardPmtByAssetId", getAssetCardPmtByAssetId);
  yield takeEvery(
    "Common/getAssetStatusPmtByPlantId",
    getAssetStatusPmtByPlantId
  );
  yield takeEvery(
    "Common/getStatusAssetPmtByPlantId",
    getStatusAssetPmtByPlantId
  );
  yield takeEvery(
    "Common/getssetStatusListbyPlantId",
    getssetStatusListbyPlantId
  );
  yield takeEvery(
    "Common/getHeatMapToolTipbyAssetStatus",
    getHeatMapToolTipbyAssetStatus
  );
  yield takeEvery(
    "Common/getTopBarToolTipbyPlantId",
    getTopBarToolTipbyPlantId
  );
  // Asset Model Start
  yield takeEvery(
    "Common/getassetlistOfAssetModelByplantid",
    getassetlistOfAssetModelByplantid
  );
  yield takeEvery("Common/getAnomalyModelbyAssetId", getAnomalyModelbyAssetId);
  yield takeEvery(
    "Common/getFailurepreDictionByAssetId",
    getFailurepreDictionByAssetId
  );
  yield takeEvery(
    "Common/getGraphicalImageByAssetId",
    getGraphicalImageByAssetId
  );
  yield takeEvery("Common/getAssetKPI", getAssetKPI);
  // Plot Screen
  yield takeEvery("Common/getPlotModelDropDown", getPlotModelDropDown);
  yield takeEvery("Common/getPlotAssetDropDown", getPlotAssetDropDown);
  yield takeEvery("Common/getPlotSensorDropDown", getPlotSensorDropDown);
  yield takeEvery("Common/getPlotDeviationData", getPlotDeviationData);
  yield takeEvery("Common/getPlotDeviationModel", getPlotDeviationModelSaga);
  yield takeEvery("Common/getPlotSensorData", getPlotSensorDataSaga);

  //AlertStatus
  yield takeEvery(
    "Common/getAlertStatisticsAlertListByPlantId",
    getAlertStatisticsAlertListByPlantId
  );
  // ASSET TIMELINE Start
  yield takeEvery(
    "Common/getAssetHealthIndexByAssetId",
    getAssetHealthIndexByAssetId
  );
  yield takeEvery(
    "Common/getMaintenanceHistoryByAssetId",
    getMaintenanceHistoryByAssetId
  );
  yield takeEvery("Common/getHanaIncidentByAssetId", getHanaIncidentByAssetId);
  //mytask
  yield takeEvery("Common/getMyTaskTable", getMyTaskTable);
  // report table - getreporttable
  yield takeEvery("Common/getreporttable", getreporttable);
  // utilizationreport - getutilizationreporttable
  yield takeEvery("Common/getutilizationreporttable", getutilizationreporttable);
  // masterdatareporttable
  yield takeEvery("Common/getmasterdatareporttable", getmasterdatareporttable);
  //alert Table
  yield takeEvery("Common/getAlertDetails", getAlertDetailsSaga);
  //LiveTracking
  yield takeEvery("Common/getLivetrackingtable", getLivetrackingtable);
  // yield takeEvery("Common/getmodelstatusdropdown", getmodelstatusdropdown);
  // Alert Dashboard
  yield takeEvery("Common/getAssetPieChart", getAssetPieChart);
  yield takeEvery("Common/getAssetStackedBar", getAssetStackedBar);
  yield takeEvery("Common/getDepartementStackedBar", getDepartementStackedBar);
  yield takeEvery("Common/getPerformaceChart", getPerformaceChart);
  //PLANT TIMELINE
  yield takeEvery(
    "Common/getPlantTimelineByPlantId",
    getPlantTimelineByPlantId
  );
  // Global Search
  yield takeEvery("Common/getGlobalSearch", getGlobalSearch);
  // Reference Table
  yield takeEvery(
    "Common/getReferenceTableModelData",
    getReferenceTableModelData
  );
  yield takeEvery("Common/getReferenceOffilineData", getReferenceOffilineData);
  //monthwise table
  yield takeEvery(
    "Common/getplantmodelbasedtabledatabyplant",
    getplantmodelbasedtabledatabyplant
  );
  //modelperformance monthwise barchart
  yield takeEvery(
    "Common/getplantmonthwisebarchartdata",
    getplantmonthwisebarchartdata
  );
  //Pmcompliance
  yield takeEvery(
    "Common/getpmcompliance",
    getpmcompliancedata
  );//end

  //Modelperformance
  yield takeEvery(
    "Common/getmodelalertstatuspiechart",
    getmodelalertstatuspiechart
  );
  yield takeEvery(
    "Common/getmodeltotalalertstatusbyasset",
    getmodeltotalalertstatusbyasset
  );
  yield takeEvery(
    "Common/getmodelalertstatusbydepartmentbyplant",
    getmodelalertstatusbydepartmentbyplant
  );
  //Asset ALert List

  yield takeEvery("Common/getAlertListtable", getAlertListtable);

  yield takeEvery(
    "Common/getAlertListTopBarSummary",
    getAlertListTopBarSummary
  );

  yield takeEvery(
    "Common/getAlertListAssetIDDropdown",
    getAlertListAssetIDDropdown
  );

  yield takeEvery(
    "Common/getAlertListModelNameDropdown",
    getAlertListModelNameDropdown
  );

  yield takeEvery(
    "Common/getAlertListModelStatusDropdown",
    getAlertListModelStatusDropdown
  );
  // Dropdowns
  yield takeEvery("Common/getRegionDropdownList", getRegionDropdownListSaga);
  yield takeEvery("Common/getAffiliateDropdownList", getAffiliateDropdownListSaga);
  yield takeEvery("Common/getPlantDropdownList", getPlantDropdownListSaga);
  yield takeEvery("Common/getAssetDropdownList", getAssetDropdownListSaga);
  yield takeEvery("Common/getModelDropdownList", getModelDropdownListSaga);
  yield takeEvery("Common/getModelSensorDropdownList", getModelSensorDropdownListSaga);
  yield takeEvery("Common/getModelStatusDropdownList", getModelStatusDropdownListSaga);
  yield takeEvery("Common/getSensorDropdownList", getSensorDropdownListSaga);
  yield takeEvery("Common/getAlertIDDropdownList", getAlertIDDropdownListSaga);
  yield takeEvery("Common/getcurrentstageDropdownList", getCurrentStageDropdownListSaga);
  yield takeEvery("Common/getLongLeadActionDropdownList", getLongLeadActionDropdownListSaga);
  yield takeEvery("Common/getStatusDropdownList", getStatusDropdownListSaga);
  yield takeEvery("Common/getAlertManagementAffiliatesDroprdown", getAlertManagementAffiliatesDroprdown);
  yield takeEvery("Common/getAlertManagementPlantDroprdown", getAlertManagementPlantDroprdown);
  yield takeEvery("Common/getAlertManagementAssetIdDroprdown", getAlertManagementAssetIdDroprdown);
  yield takeEvery("Common/getAlertManagementAlertIdDroprdown", getAlertManagementAlertIdDroprdown);
  //Dropdowns
  // Affiliate Page  
  yield takeEvery("Common/getAffiliateTopBar", getAffiliateTopBarSaga);
  yield takeEvery("Common/getAffiliateDetails", getAffiliateDetailsSaga);
  // Plant Page
  yield takeEvery("Common/getPlantTopBar", getPlantTopBarSaga);
  yield takeEvery("Common/getPlantDetails", getPlantDetailsSaga);

  // Home Page
  yield takeEvery("Common/getGlobalTopBarSummary", getGlobalTopBarSummary);
  yield takeEvery("Common/getGlobalMapSummaryByUserId", getGlobalMapSummaryByUserId);
  yield takeEvery("Common/getGlobalRegionMapSummaryByUserId", getGlobalRegionMapSummaryByUserId);

  //Admin Configuration
  yield takeEvery("Common/getAffiliateRollout", getAffiliateRolloutData);
  yield takeEvery("Common/getPlantRollout", getPlantRolloutData);
  yield takeEvery("Common/updateAffiliateRollout", updateAffiliateRolloutData);
  yield takeEvery("Common/updatePlantRollout", updatePlantRolloutData);
  yield takeEvery("Common/getAssetModelConfigTableData", getAssetModelConfigTableDataSaga);
  yield takeEvery("Common/updateAssetModelConfigTableStatus", updateAssetModelConfigTableStatusSaga);
  yield takeEvery("Common/getExceptionLog", getExceptionLogsData);
  //Alert management-Report view- Logtable
  yield takeEvery("Common/getRequestLogTable", getRequestLogTable);

  yield takeEvery("Common/getRoleMappingRoleDropdownList", getRoleMappingRoleDropdownListSaga);
  yield takeEvery("Common/getRoleMappingPlantDropdownList", getRoleMappingPlantDropdownListSaga);
  yield takeEvery("Common/getRoleMappingAffiliateDropdownList", getRoleMappingAffiliateDropdownListSaga);
  yield takeEvery("Common/addRoleMapping", addRoleMappingData);
  yield takeEvery("Common/updateRoleMapping", updateRoleMappingData);
  yield takeEvery("Common/getRoleMappingWorklist", getRoleMappingWorklistData);
  yield takeEvery("Common/getEmployeeList", getEmployeeListData);
  /*
   Workflow
   */
  yield takeEvery("Common/getWorkflowAlertDetails", getWorkflowAlertDetailsSaga);
  yield takeEvery("Common/getWorkflowRequestLog", getWorkflowRequestLogSaga);
  yield takeLatest("Common/getWorkflowSearchData", getWorkflowSearchDataSaga);
  yield takeEvery("Common/getWorkflowAttachementDetails", getWorkflowAttachementDetailsSaga);
  yield takeEvery("Common/getAlertAttachementDetails", getAlertAttachementDetailsSaga);
  yield takeEvery("Common/getWorkflowUserRole", getWorkflowUserRoleSaga);
  /*
  User Profile
  */
  yield takeEvery("Common/getLoggedInUserDetails", getLoggedInUserDetails);
  //Asset model config dropdown
  yield takeEvery("Common/getAssetModelConfigDropdownList", getAssetModelConfigDropdownListSaga);
  yield takeEvery("Common/getAssetModelConfigAffiliateDropdownList", getAssetModelConfigAffiliateDropdownListSaga);
  yield takeEvery("Common/getAssetModelConfigPlantDropdownList", getAssetModelConfigPlantDropdownListSaga);
  /*
   Alert Statistics
   */
  yield takeEvery("Common/getPlantUtilizationTime", getPlantUtilizationTimeData);
  /*
   Upload Attachements
  */
  yield takeEvery("Common/uploadAttachements", uploadAttachementsSaga);
  yield takeEvery("Common/updateWorkflowStatus", updateWorkflowStatusSaga);

  yield takeEvery("Common/getPlantAlertListStateDropdownList", getPlantAlertListStateDropdownListSaga);

  yield takeEvery("Common/getPlantAlertListDepartmentDropdownList", getPlantAlertListDepartmentDropdownListSaga);
  yield takeEvery("Common/getExceptionLogById", getExceptionLogData);
  //Plant Shutdown
  yield takeEvery("Common/getPlantShutdown", getPlantShutdownData);

  yield takeEvery("Common/getAlertBreadCrumbs", getAlertBreadCrumbsSaga);

  //spareparts
  yield takeEvery("Common/getSparePartsSAP", getSparePartsSAPData);
  yield takeEvery("Common/getSparePartsSensor", getSparePartsSensorData);
  yield takeEvery("Common/getSparePartsSAPDropdown", getSparePartsSAPDropdownSaga);
  yield takeEvery("Common/updateSparePartsSap", updateSparePartsSapData);

  yield takeEvery("Common/getIBMAlertDetailsByAlertId", getIBMAlertDetailsByAlertId);
  yield takeEvery("Common/getConsultSomeone", getConsultSomeoneSaga);

  //Utilization Report Year Month
  yield takeEvery("Common/getAlertManagementYearDropdown", getAlertManagementYearDropdown);
  yield takeEvery("Common/getAlertManagementMonthDropdown", getAlertManagementMonthDropdown);

}
