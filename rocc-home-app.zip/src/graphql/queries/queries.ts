/*
 * Created on Tue Jun 29 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import gql from "graphql-tag"

export const FETCH_ROOMS_STATUS =  gql`
subscription fetch_room_status($roomIds: [Int!]) {
    rocc_camera_status(where: {scanner_resource_id: {_in: $roomIds}}, distinct_on: scanner_resource_id, order_by: [{scanner_resource_id: desc},{event_time: desc}]) {
        id
        resourceId: scanner_resource_id
        cameraEvent: camera_event
        eventTime: event_time
    }
}
`
