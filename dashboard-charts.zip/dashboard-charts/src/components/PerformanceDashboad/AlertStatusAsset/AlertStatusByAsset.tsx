// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import * as am5percent from "@amcharts/amcharts5/percent";
interface Props {
	data: any[];
}
const AlertStatusByAsset = ({ data }: Props) => {
	useLayoutEffect(() => {
		// Create root and chart
		if (data.length > 0) {
			var root = am5.Root.new("chartdiv");
			/* remove amchart logo */

			root._logo.dispose();

			root.setThemes([am5themes_Animated.new(root)]);

			var chart = root.container.children.push(
				am5percent.PieChart.new(root, {
					layout: root.horizontalLayout,
					radius: am5.percent(90),
					innerRadius: am5.percent(85),
				})
			);

			// Create series
			var series = chart.series.push(
				am5percent.PieSeries.new(root, {
					name: "Series",
					valueField: "countofAlerts",
					categoryField: "state",
				})
			);
			var tooltip = series.set(
				"tooltip",
				am5.Tooltip.new(root, {
					getFillFromSprite: true,
					labelText: "[bold]{value}",
				})
			);

			tooltip.get("background").setAll({
				fill: am5.color(0x000000),
			});
			series.get("colors").set("colors", [
				am5.color(0xe35205), //red
				am5.color(0x3BB44A), //green
				am5.color(0x929292), //Gray
			]);

			series.labels.template.set("forceHidden", true);
			series.ticks.template.set("forceHidden", true);
			series.set("tooltip", tooltip);
			var label = series.children.push(
				am5.Label.new(root, {
					text: "{valueSum.formatNumber('#,###.')}",
					fontSize:"1.5rem",
					centerX: am5.percent(50),
					centerY: am5.percent(50),
					populateText: true,
				})
			);

			series.data.setAll(data);
			series.onPrivate("valueSum", function () {
				label.text.markDirtyText();
			});
			// Add legend
			var legend = chart.children.push(
				am5.Legend.new(root, {
					centerY: am5.percent(50),
					y: am5.percent(50),
					x: am5.percent(50),
					fontSize:"0.9rem",
					layout: root.verticalLayout,
					//tooltipText: "{category}: {value}",
				})
			);
			legend.itemContainers.template.setup = function (item) {
				item.events.disableType("pointerover");
			};
			legend.markerRectangles.template.setAll({
				width: 25,
				height: 10,
				cornerRadiusTL: 8,
				cornerRadiusTR: 7,
				cornerRadiusBL: 7,
				cornerRadiusBR: 7,
				fontSize:"0.9rem",
				y: 4,
				x: -5,
			});
			legend.labels.template.setAll({
				fontSize:"0.9rem",
				marginLeft: 20
			});
			legend.valueLabels.template.setAll({
				fontSize: 0,
				fontWeight: "0",
			});

			legend.data.setAll(series.dataItems);
			return () => {
				root.dispose();
			};
		}
	}, [data]);

	return <div id="chartdiv" style={{ width: "100%", height: "180px" }}></div>;
};

export default AlertStatusByAsset;
