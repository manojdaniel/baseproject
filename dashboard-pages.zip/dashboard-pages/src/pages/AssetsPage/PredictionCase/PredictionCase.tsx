import React, { useRef, useEffect, useState } from "react";
import AlertStatusByAsset from "charts/AlertStatusByAsset";
import StackBarChart from "charts/StackBarChart";
import AlertStatusDepartment from "charts/AlertStatusDepartment";
import {
  
  getmodelalertstatusbydepartmentbyplant,
} from "../../../redux/reducers/CommonReducer";
import { useDispatch, useSelector } from "react-redux";
const PredictionCase = () => {
  let dispatch = useDispatch();
  const [assetBarData, setAssetBarData] = useState<any>([]);
  // const [assetstackBarData, setAssetstackBarData] = useState<any>([]);


  const {
    
    modelalertstatusbydepartmentbyplant,
    globalSelecetedPlant,
    modelPerformanceAssetDropdownChangedValue
  } = useSelector((state: any) => ({
    
    modelalertstatusbydepartmentbyplant:
      state.Common.modelalertstatusbydepartmentbyplant,
    globalSelecetedPlant: state.Common.globalSelecetedPlant,
    modelPerformanceAssetDropdownChangedValue: state.Common.modelPerformanceAssetDropdownChangedValue,
  }));

  // useEffect(() => {
  //   // Initially loaded with Plant Id
  //   if (Object.keys(globalSelecetedPlant).length > 0) {
  //     dispatch(getmodelalertstatuspiechart(`${globalSelecetedPlant.value}/18`)); //Pie Chart//{plantId}/{userid}
  //     dispatch(getmodeltotalalertstatusbyasset(`${globalSelecetedPlant.value}/18`)); //Stacked Asset Bar//{plantId}/{userid}
  //     dispatch(getmodelalertstatusbydepartmentbyplant(`${globalSelecetedPlant.value}/18`));//{plantId}/{userid}
  //   }
  // }, []);

  useEffect(() => {
    // Loading with asset Id
    if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
      if (modelPerformanceAssetDropdownChangedValue.label === "All") {
        dispatch(getmodelalertstatusbydepartmentbyplant(`${modelPerformanceAssetDropdownChangedValue.value}/0/18`)); ////plant id/{asset Id}/{ userid }
      }
      else {
        dispatch(getmodelalertstatusbydepartmentbyplant(`0/${modelPerformanceAssetDropdownChangedValue.value}/18`)); ////plant id/{asset Id}/{ userid }
      }

    } else {
      if (Object.keys(globalSelecetedPlant).length > 0) {
        dispatch(getmodelalertstatusbydepartmentbyplant(`${globalSelecetedPlant.value}/0/18`));//{plantId}/{userid}
      }
    }
  }, [modelPerformanceAssetDropdownChangedValue]);


  return (
    <div>
      <div className="pd-dashboard-box">
        <div className="common-box-inner">
          <div className="common-box-filter">
            <div className="title">PREDICTION CASE</div>
          </div>
          <div className="common-box-content">
            <AlertStatusDepartment data={modelalertstatusbydepartmentbyplant} />
          </div>
        </div>
      </div>
    </div>
  );
};
export default PredictionCase;
