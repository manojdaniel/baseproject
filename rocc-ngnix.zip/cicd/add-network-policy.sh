#!/bin/bash
set -e
set -x

for ARGUMENT in "$@"
do
    KEY=$(echo $ARGUMENT | cut -f1 -d=)
    VALUE=$(echo $ARGUMENT | cut -f2 -d=)

    case "$KEY" in
            -app_name)         app_name=${VALUE} ;;
            *)
    esac
done


cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-graphql-internal-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-iam-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-communication-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-management-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-twilio-pool-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-rbac-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-monitoring-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-audit-gateway-service-$TARGET_ENV --protocol tcp --port 8080
# cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-service-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-service-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-scheduler-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-calendar-service-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-generic-services-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-tech-host-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-cc-host-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-tech-main-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-radconnect-service-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-radconnect-rad-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-radconnect-tech-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app pdv-key-management-service-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app pdv-key-management-service-node-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-tech-host-v2-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-pharma-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-learning-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-service-home-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-service-host-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-self-service-report-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-tech-login-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-admin-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-calling-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-console-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-cc-home-app-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-authorization-service-$TARGET_ENV --protocol tcp --port 8080
cf add-network-policy $app_name-$TARGET_ENV --destination-app rocc-client-router-app-$TARGET_ENV --protocol tcp --port 8080
