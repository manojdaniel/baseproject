/*
 * Created on Mon Oct 18 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, EConnectionMode } from "@rocc/rocc-client-services"

export const T_USER_UUID = "<USER_UUID>"

export const COMPONENT = {
    SESSION: {
        name: "SESSION",
        events: {
            trackerSetup: `App tracker setup for User: ${T_USER_UUID}`,
            userLogin: `User: ${T_USER_UUID} logged in successfully`,
            userLogout: `User: ${T_USER_UUID} logged out successfully`,
            sessionExpired: `Session expired: User ${T_USER_UUID} is logged out`,
            sessionDuration: `EntireSessionDuration`,
            serverLoginTime: `Server Login Time`,
            twilioTokenCreationTime: `Twilio Token Creation`,
            chatClientLoadTime: `Chat Client Creation`,
            customerDataLoadTime: `Customer Data Load`,
            contactsLoadTime: `Contacts Load`,
            homePageTime: `Home Page Load`,
        }
    },
    RECOVERY: {
        name: "RECOVERY",
        events: {
            retryClick: `Session recovered from SomethingWentWrong component based on user click for user: ${T_USER_UUID}`,
            retryAuto: `Session recovered from SomethingWentWrong component automatically for user: ${T_USER_UUID}`,
        }
    }
}

export const transformSessionTypeForAnalytics = (sessionType: EConnectionType | EConnectionMode) => {
    const { FULL_CONTROL, FULL_CONTROL_USB, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, VIEW } = EConnectionType
    const { EMERALD, CC } = EConnectionMode
    switch (sessionType) {
        case VIEW:
            return "View Console"
        case FULL_CONTROL:
            return "Edit Console"
        case INCOGNITO_VIEW:
            return "Incognito-View Console"
        case PROTOCOL_MANAGEMENT:
            return "Protocol Management Console"
        case FULL_CONTROL_USB:
            return "Edit Console With USB Redirection Enabled As A Private Connection"
        case EMERALD:
            return "Non fixed command center connection"
        case CC:
            return "Fixed command center connection"
        default:
            return "Console"
    }
}


export const TRACK = {
    LOGIN: {
        component: "Login",
        event: {
            homePageLoad: "Home Page Load",
            sessionExtended: "Session Modal: Extend session clicked"
        }
    },
    LOGOUT: {
        component: "Logout",
        event: {
            admin: "Admin Logout",
            expertUser: "Expert User Logout",
            sessionEndClicked: "End session clicked",
            sessionExpired: "Session Expired",
            entireSessionDuration: "EntireSessionDuration"
        }
    },
    HOME_COMPONENT: {
        component: "HomeComponent",
        event: {
            demoEnvVideo: "Demo environment: video enabled for __REPLACE__  connection"
        }
    },
    NAV_BAR: {
        component: "NavBar",
        event: {
            home: "home Menu Clicked",
            scheduling: "Schedling Menu Clicked",
            userManual: "User Manual Clicked",
            adminManual: "AdminManual Clicked",
            NFCC_dwonload: "NFCC download clicked",
            NFCC_upgrade: "NFCC upgrade clicked",
            contactUs: "ContactUs Clicked",
            protocol: "Clicked on protocol transfer",
            support: "Support icon clicked",
            cctv: "CCTV icon clicked",
            callPanel: "Call Panel: Expert User View ",
            aboutDesktopHome: "About: Desktop Home",
            settings: "Page : Settings",
        }
    },
    EXPERT_USER_VIEW: {
        component: "Call Panel: Expert User View ",
        tab: {
            contacts: "Contacts"
        }
    },
    PROTOCOL: {
        component: "NavBar",
        event: {
            stay: "Stay on protocol transfer mode",
            leave: "Confirmed leave protocol transfer"
        }
    },
    SOMETHING_WENT_WRONG: {
        component: "SomethingWentWrong",
        event: {
            retry: "retry"
        }
    },
    CONSOLE_INFO: {
        component: "ConsoleInfo",
        event: {
            tabSwitch: "Console Tab Switched",
            endedConsole: "__REPLACE__ stopped"
        }
    },
    CONTACT_US: {
        component: "Contact Us",
        event: {
            roccHelplineNo: "Clicked on ROCC helpline number"
        }
    },
    SESSION: {
        component: "Session",
        event: {
            sessionClosed: "Application interrupted or closed"
        }
    },
    LIVE_VIDEO: {
        component: "LiveVideo",
        event: {
            open: "Live Video Window opened",
            close: "Live Video Window closed"
        }
    },
    BUNDLE_UPGRADE_MODAL: {
        component: "BundleUpgradeModal",
        event: {
            accept: "Clicked accept for NFCC upgrade",
            denied: "Clicked no for NFCC upgrade"
        }
    }
}
