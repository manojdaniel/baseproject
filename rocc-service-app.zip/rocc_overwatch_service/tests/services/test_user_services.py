"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import unittest
from unittest.mock import patch
from src.constants.config_keys import VAULT_PARENT_ORG_ID

from src.services.user_services import UserManagementService


class TestUserServices(unittest.TestCase):
    @patch("src.services.user_services.get_profile_data", side_effect=lambda: json.loads(json.dumps({VAULT_PARENT_ORG_ID: "org_infra_uuid", "test": "test1"})))
    @patch("src.services.user_services.get_client_connection", side_effect=lambda access_token, org_infra_uuid, is_fse:  None)
    @patch("src.services.user_services.UserManagementService.populate_service_token", side_effect=lambda a: None)
    def test_populate_service_token(self, m_profile, m_client, m_st):
        UserManagementService(service_user_uuid="", org_db_id=0, service_user_token="")
        m_profile.assert_called()
        m_client.assert_called()
        m_st.assert_called()
