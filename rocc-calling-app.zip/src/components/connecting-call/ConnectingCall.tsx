/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import "@dls-pdv/semantic-ui-foundation/dist/semantic.min.css"
import { EClinicalRole, IContactInfo } from "@rocc/rocc-client-services"
import React from "react"
import { getRoleName, getSiteName } from "../../common/helpers/helpers"
import { DEVICE } from "../../constants/constants"
import IntermediateCallWindow from "../intermediate-call-window/IntermediateCallWindow"

interface IConnectingCallProps {
    callWindowFullscreen: boolean
    participant: IContactInfo
    callMessage: string
    additionalComponent?: () => JSX.Element
}

const ConnectingCall = ({ callWindowFullscreen, participant, callMessage, additionalComponent }: IConnectingCallProps) => {

    const isSecondaryUser = participant.secondaryName ? true : false
    const { name, secondaryName, clinicalRole, description, siteId, loggedInLocation } = participant
    return <IntermediateCallWindow
        displayName={isSecondaryUser ? secondaryName : name}
        metaData={isSecondaryUser ? getRoleName(EClinicalRole.TECHNOLOGIST) : getRoleName(clinicalRole)}
        description={(clinicalRole == DEVICE) ? getSiteName(description, siteId) : loggedInLocation || ""}
        callMessage={callMessage}
        callWindowFullscreen={callWindowFullscreen}
        additionalComponent={additionalComponent}
    />

}

export default ConnectingCall
