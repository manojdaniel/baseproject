/*
 * Created on Fri Nov 12 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IWorkflow } from "@rocc/rocc-client-services"
import { SYNC_CALL_REDUCERS_CALL_DETAILS, SYNC_PARENT_REDUCERS } from "../actions/types"
import { getRoomInfoDetails, getWorkflowInfo } from "../transformer/consoleTransformer"
import externalReducer, { initialStateForExternalReducer } from "./externalReducer"

describe("App Component", () => {
  it("should handle external reducer empty action", () => {
    const value = externalReducer({ initialStateForExternalReducer }, { type: "" })
    expect(value).toBeDefined()
  })

  it("should handle external reducer SYNC_PARENT_REDUCERS action", () => {
    const rooms = [
      {
        identity: {
          uuid: "uuid",
          name: "name",
          address: "address",
        },
        locationId: "locationId",
        phoneNumber: "phoneNumber",
        loggedInTech: "loggedInTech",
        cameraAvailable: "cameraAvailable",
      },
      {
        identity: {
          uuid: "uuid2",
          name: "name2",
        },
        locationId: "locationId2",
        phoneNumber: "phoneNumber2",
        loggedInTech: "loggedInTech2",
        additionalAttributes: { someAttr: "someAttr" },
        cameraAvailable: undefined,
      }
    ]

    const workflows = [
      { id: "1", type: "WTYPE1", workflow: {}, state: {}, eventQueue: [], service: {} },
      { id: "2", type: "WTYPE2", workflow: {}, state: {}, eventQueue: [], service: {} },
    ] as unknown as IWorkflow[]

    const value = externalReducer({ initialStateForExternalReducer }, {
      type: SYNC_PARENT_REDUCERS, payload: { rooms, workflows }
    })
  
    expect(value).toEqual(expect.objectContaining({
      rooms: getRoomInfoDetails(rooms),
      workflows: getWorkflowInfo(workflows),
    }))

  })

  it("should handle external reducer SYNC_CALL_REDUCERS_VIDEO_CALL_STATUS action", () => {
    const value = externalReducer({ initialStateForExternalReducer }, { type: SYNC_CALL_REDUCERS_CALL_DETAILS, payload: "" })
    expect(value).toBeDefined()
  })
})
