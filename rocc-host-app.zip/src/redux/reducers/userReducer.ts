/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Reducer } from "redux"
import { EUserPresence } from "../../types/types"
import { LOGIN_SUCCESS, SET_USER_DETAILS_STATE, SET_USER_DETAILS, SET_USER_DETAILS_FAILURE, LOGIN_FAILURE, GLOBAL_REFRESH_TOKEN, GLOBAL_REFRESH_TOKEN_FAILED, RENDER_ONBOARDING, SET_APPSTATE, GLOBAL_FORCE_CLEAN_UP, UPDATE_CURRENT_USER, SET_SESSION_DETAILS, UPDATE_ONBOARDING_STATUS, EXPERTUSER_LOGOUT_INIT, EXPERTUSER_LOGOUT_RESPONSE, FETCH_CONTACTS, UPDATE_PRESENCE, UPDATE_SELF_PRESENCE, SET_PERMISSIONS, GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION, } from "../actions/types"
import { EClinicalRole, IUserInfo, EResponse, IUserReducer, EAppStates, DEFAULT_PERMISSION_LIST } from "@rocc/rocc-client-services"


const { DEFAULT, INIT } = EResponse

export const INIT_CURRENT_USER_PROFILE: IUserInfo = {
    accessToken: "", accessTokenExpiryTime: new Date().toDateString(), allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
    orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "",
    clinicalRole: EClinicalRole.DEFAULT, secondaryUUID: "", secondaryName: "", description: ""
}
export const initialStatesForUser: IUserReducer = {
    appState: EAppStates.INIT,
    userState: INIT,
    loginMessage: "",
    currentUser: INIT_CURRENT_USER_PROFILE,
    unauthorised: false,
    contactsFetched: false,
    expertUserTransitionState: DEFAULT,
    contacts: [],
    forceCleanUp: false,
    permissions: DEFAULT_PERMISSION_LIST
}

const userReducer: Reducer = (state: IUserReducer = initialStatesForUser, action: any) => {
    const mCurrentUser = state.currentUser
    const defaultCurrentUser = { ...INIT_CURRENT_USER_PROFILE }
    switch (action.type) {
        case SET_SESSION_DETAILS: {
            const returnState = {
                ...INIT_CURRENT_USER_PROFILE,
                accessToken: action.sessionDetails.accessToken,
                accessTokenExpiryTime: action.sessionDetails.accessTokenExpiryTime,
                sessionId: action.sessionDetails.sessionId,
                email: action.sessionDetails.userName,
                uuid: action.sessionDetails.uuid,
            }

            return { ...state, currentUser: returnState }
        }

        case LOGIN_SUCCESS: {
            return { ...state, appState: action.appState, userState: action.userState ? action.userState : DEFAULT }
        }

        case UPDATE_SELF_PRESENCE: {
            const { status } = action
            const updateSelfPresence = { ...state.currentUser, status }
            return { ...state, currentUser: updateSelfPresence }
        }

        case GLOBAL_UPDATE_USER_LOGGEDIN_LOCATION: {
            const { userLoggedInLocation } = action
            const updatedUserLoggedInLocation = { ...state.currentUser, loggedInLocation: userLoggedInLocation }
            return { ...state, currentUser: updatedUserLoggedInLocation }
        }


        case FETCH_CONTACTS:
            if (action.contacts) {
                return { ...state, contacts: action.contacts, contactsFetched: action.contactsFetched }
            } else {
                return { ...state, contactsFetched: action.contactsFetched }
            }
        case SET_USER_DETAILS_STATE:
            return { ...state, userState: action.userState }
        case SET_USER_DETAILS: {
            let appendedState = null
            if (action.userInfo) {
                const {
                    id, siteId, orgId, status, name, phoneNumber, clinicalRole, email, uuid, onBoarded, allRoles, roccContext, modalities, kvmUsername, orgIdentifier
                } = action.userInfo
                appendedState = {
                    ...state.currentUser,
                    id, siteId, orgId, status, name, phoneNumber, clinicalRole, email, uuid, onBoarded, allRoles, roccContext, modalities, kvmUsername, orgIdentifier
                }
            }
            return { ...state, currentUser: appendedState, userState: action.userState }
        }
        case SET_USER_DETAILS_FAILURE:
            return {
                ...state,
                currentUser: defaultCurrentUser, userState: action.userState, appState: action.appState, loginMessage: action.errorMessage,
            }
        case LOGIN_FAILURE:
            return {
                ...state,
                currentUser: defaultCurrentUser, appState: action.appState, loginMessage: action.errorMessage,
            }
        case GLOBAL_REFRESH_TOKEN: {
            const { refreshAccessToken, expiryTime } = action
            const newAccessToken = { ...state.currentUser, accessToken: refreshAccessToken, accessTokenExpiryTime: expiryTime }
            return { ...state, currentUser: newAccessToken }
        }
        case GLOBAL_REFRESH_TOKEN_FAILED:
            return { ...state, appState: action.appState }
        case RENDER_ONBOARDING:
            return { ...state, unauthorised: action.unauthorised, appState: action.appState }
        case SET_APPSTATE:
            return { ...state, appState: action.appState, currentUser: mCurrentUser }
        case GLOBAL_FORCE_CLEAN_UP:
            return { ...state, forceCleanUp: action.forceCleanUp }
        case UPDATE_CURRENT_USER:
            return { ...state, currentUser: action.currentUser }
        case UPDATE_ONBOARDING_STATUS:
            return { ...state, currentUser: action.currentUser }
        case EXPERTUSER_LOGOUT_INIT:
            return { ...state, expertUserTransitionState: INIT }
        case EXPERTUSER_LOGOUT_RESPONSE:
            return { ...state, expertUserTransitionState: action.expertUserTransitionState }
        case UPDATE_PRESENCE:
            return { ...state, contacts: action.contacts }
        case SET_PERMISSIONS:
            return { ...state, permissions: action.permissions }
        default:
    }
    return { ...state }
}

export default userReducer
