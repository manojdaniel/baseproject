# ROCC - Calling Application

[![Master-Build](https://github.com/philips-internal/rocc-calling-app/actions/workflows/master.yml/badge.svg)](https://github.com/philips-internal/rocc-calling-app/actions/workflows/master.yml)
[![Tag-Build](https://github.com/philips-internal/rocc-calling-app/actions/workflows/tag.yml/badge.svg)](https://github.com/philips-internal/rocc-calling-app/actions/workflows/tag.yml)
[![Blackduck-Scanning](https://github.com/philips-internal/rocc-calling-app/actions/workflows/blackduck.yml/badge.svg)](https://github.com/philips-internal/rocc-calling-app/actions/workflows/blackduck.yml)
[![UI-Sanity](https://github.com/philips-internal/rocc-calling-app/actions/workflows/ui-sanity.yml/badge.svg)](https://github.com/philips-internal/rocc-calling-app/actions/workflows/ui-sanity.yml)
<a href=https://codescene.ta.philips.com/1607/analyses/latest/dashboard> <img src="https://codescene.com/status/analyzed-by-codescene-badge.svg" width="130"></a>
This MFE is the container for calling application in ROCC. This application can be used to initiate WebCall and Phone calls.

This repo comes with the following features
 - Linting Per ROCC
 - Unit tests
 - Husky
 - MS Application Insights
 - PDV Toolkit
 - Cloud/PR Scripts
 - Webpack Module Federation https://webpack.js.org/concepts/module-federation/ 

# Setting up in local


 ## Pre-requisites
  - node (v14.17.3)
  - npm (6.14.13)
  - nginx (latest)
  - A Host application like rocc-cc-host
  
 ## Cloning
 - Create a Personal Access Token (PAT) - https://github.com/settings/tokens  (one time activity)
 - Use the following command to clone the repo
   - `git clone --recursive https://<<PAT>>:x-oauth-basic@github.com/philips-internal/rocc-self-service-home-app.git`

 ## Update npm config

 - `npm config set @vip:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @dls-pdv:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @rocc:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`

 ## Install

 - `npm install`

 ## Running

 - `npm start`. This will build and serve the app on port 8080.
  
 - Alternatively,
    - `npm build`
    - `npm serve`

 ## Nginx Config

 - download and install Nginx in your local (http://nginx.org/en/download.html)
 - Sample config 
        
        server {
            listen       9090;
            server_name  localhost;

            location ~^/app/calling(.*) {
                proxy_pass "http://localhost:7773/$1";
                proxy_http_version 1.1;
                proxy_redirect     off;
                
            }

            location / {
                gzip_static on;
                proxy_pass "http://localhost:3001";
                proxy_http_version 1.1;
            }
        }

    -   Note: Running all child MFEs in local is not required. Child MFEs can be referred with the dev URLs


### Run the application in the browser http://localhost:9090
