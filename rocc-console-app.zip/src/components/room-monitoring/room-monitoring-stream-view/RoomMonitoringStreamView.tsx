/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, EConnectionState, EConnectionType, ERoomMoinitorRenderState, FeatureFlagHelper, IConsoleSession, parseIntBase10, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { RoomBannerCameraControls } from "@rocc/rocc-console-components"
import { getIntlProvider, ModalComponent } from "@rocc/rocc-global-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch } from "react-redux"
import { ROOM_MONITORING_TRACKING } from "../../../common/constants/constants"
import { toggleCameraState } from "../../../common/helpers/multiCameraUtility"
import { fetchGlobalConfigs, fetchGlobalFeatureFlags } from "../../../redux/store/externalAppStates"
import en from "../../../resources/translations/en-US"
import RoomMonitoringCameraController from "../room-monitoring-camera-controller/RoomMonitoringCameraController"
import RoomMonitoringDefaultView from "../room-monitoring-default-view/RoomMonitoringDefaultView"
import styles from "./RoomMonitoringStreamView.scss"
import cx from "classnames"

const FILENAME = "RoomMonitoringStreamView.tsx"

interface IRoomMonitoringStreamView {
    singleRecieverView: boolean
    consoleSession: IConsoleSession
    consoleSessions: IConsoleSession[]
    currentUserUuid: string
    accessToken: string
    roomCameraAvailable: any
    rightSidePanel?: boolean
}

const RoomMonitoringStreamView = ({ singleRecieverView, consoleSession, consoleSessions, currentUserUuid, accessToken, rightSidePanel }: IRoomMonitoringStreamView) => {

    const { intl } = getIntlProvider()
    const configs = fetchGlobalConfigs()
    const dispatch = useDispatch()
    const { DEVICE_DISCONNECTED, AUTO_DISCONNECTED, MEDIA_ROOM_FAILED, NOT_AVAILABLE, IDLE, CAMERA_STREAM_DISCONNECTED } = ECameraStreamAvailable
    const { MESSAGE, LOADING } = ERoomMoinitorRenderState
    const { contextId, mediaRoomDetails, displayCameraToggle, connectionStatus, connectionType } = consoleSession
    const { mediaRoomId, cameraStreamAvailable } = mediaRoomDetails
    const [isSwitchingConsoleSession, setIsSwitchingConsoleSession] = useState(false)
    const previousMediaRoomId = useRef(mediaRoomId)
    const maxSupportedCameras = parseIntBase10(configs.MAX_SUPPORTED_DEVICE_USB_CAMERAS)
    const streamDisconnected = [DEVICE_DISCONNECTED, AUTO_DISCONNECTED, MEDIA_ROOM_FAILED, NOT_AVAILABLE].includes(cameraStreamAvailable)
    const noConsoleSessionCheck = contextId === ""
    const noMediaRoomCheck = mediaRoomId === ""
    const stopStreamingCheck = noConsoleSessionCheck || streamDisconnected || isSwitchingConsoleSession
    const showToggle = !noConsoleSessionCheck && !streamDisconnected && !noMediaRoomCheck
    const cameraPPFeatureState = FeatureFlagHelper.isFeatureEnabled(fetchGlobalFeatureFlags(), ROCC_FEATURES.ROCC_PP_CAMERA_MODE)
    const [showModal, setShowModal] = useState(false)
    const loggerInitialMessage = `${FILENAME}: For user: ${currentUserUuid} - Console session ${consoleSession.contextId}`

    const getRoomMonitorMessage = () => {
        let message
        if (noConsoleSessionCheck) {
            message = intl.formatMessage({ id: "content.tabInfo.noRoomSelected", defaultMessage: en["content.tabInfo.noRoomSelected"] })
        } else if ([IDLE, CAMERA_STREAM_DISCONNECTED].includes(cameraStreamAvailable) && !noMediaRoomCheck) {
            message = <div>
                {intl.formatMessage({ id: "content.room.toggleDisplayCameraMessage1", defaultMessage: en["content.room.toggleDisplayCameraMessage1"] })}
                <span
                    className={styles.displayCameraControl}
                    onClick={() => toggleCameraState(consoleSession, true, singleRecieverView, dispatch)}
                >
                    {intl.formatMessage({ id: "content.room.displayCameras", defaultMessage: en["content.room.displayCameras"] })}
                </span>
                {intl.formatMessage({ id: "content.room.toggleDisplayCameraMessage2", defaultMessage: en["content.room.toggleDisplayCameraMessage2"] })}
            </div>
        } else {
            message = intl.formatMessage({ id: "content.room.noCameraAvailable", defaultMessage: en["content.room.noCameraAvailable"] })
        }
        return message
    }

    const renderToggleButton = () => {
        return <div className={cx(styles.ppCameraToggle, singleRecieverView ? rightSidePanel ? styles.singleRecieverNarrowStyle : styles.singleRecieverWideStyle : styles.roomMonitorWindow)}>
            <RoomBannerCameraControls
                displayCamerasState={displayCameraToggle}
                showCameraSettings={false}
                isDisabled={isSwitchingConsoleSession}
                handleCameraSliderClick={() => {
                    toggleCameraState(consoleSession, !displayCameraToggle, singleRecieverView, dispatch)
                    infoLogger(`${loggerInitialMessage} Slider control: Turning off display camera toggle for user ${consoleSession.requester} and room ${consoleSession.roomUuid}`)
                }}
                handleCameraSettingsClick={() => ""}
            />
        </div>
    }

    useEffect(() => {
        if (cameraPPFeatureState) {
            if (mediaRoomId !== previousMediaRoomId.current && !displayCameraToggle && connectionStatus === EConnectionState.CONNECTED) {
                infoLogger(`${loggerInitialMessage} P2P: Turning on display camera toggle for user ${consoleSession.requester} and room ${consoleSession.roomUuid}`)
                toggleCameraState(consoleSession, true, singleRecieverView, dispatch)
                setIsSwitchingConsoleSession(false)
                previousMediaRoomId.current = mediaRoomId
            }
        } else {
            if (connectionStatus === EConnectionState.CONNECTED && !displayCameraToggle) {
                infoLogger(`${loggerInitialMessage} Group: Turning on display camera toggle for user ${consoleSession.requester} and room ${consoleSession.roomUuid}`)
                toggleCameraState(consoleSession, true, singleRecieverView, dispatch)
                setIsSwitchingConsoleSession(false)
            }
        }
    }, [mediaRoomId, connectionStatus])

    useEffect(() => {
        if (!noMediaRoomCheck && cameraStreamAvailable === IDLE && connectionStatus === EConnectionState.CONNECTED) {
            infoLogger(`${loggerInitialMessage} -  Updating console switching statues to false`)
            setIsSwitchingConsoleSession(false)
        }
    }, [cameraStreamAvailable])

    useEffect(() => {
        if (stopStreamingCheck) {
            infoLogger(`${loggerInitialMessage} - Twillio stream not available`)
            toggleCameraState(consoleSession, false, singleRecieverView, dispatch)
            infoLogger(`${isSwitchingConsoleSession ? "Switching" : "Disconnect"}: Turning off display camera toggle for user ${consoleSession.requester} and room ${consoleSession.roomUuid}`)
        }
    }, [streamDisconnected, isSwitchingConsoleSession, contextId])

    useEffect(() => {
        if (connectionStatus === EConnectionState.IN_TRANSITION_STATE) {
            infoLogger(`${loggerInitialMessage} - Updating console switching statues to true`)
            setIsSwitchingConsoleSession(true)
            sendLogsToAzure({
                contextData: {
                    component: ROOM_MONITORING_TRACKING,
                    event: `${connectionType === EConnectionType.VIEW ? "changing from View to Edit Session"
                        : connectionType === EConnectionType.FULL_CONTROL ? "changing from Edit to View Session" : ""}`
                }
            })
        }
    }, [connectionStatus])

    return (
        <div className={styles.roomMonitoringStreamView} id="roomMonitoringStreamView">
            {showToggle && renderToggleButton()}
            {displayCameraToggle ? <RoomMonitoringCameraController
                maxSupportedCameras={maxSupportedCameras}
                singleRecieverView={singleRecieverView}
                consoleSession={consoleSession}
                consoleSessions={consoleSessions}
                currentUserUuid={currentUserUuid}
                accessToken={accessToken}
                isSwitchingConsoleSession={isSwitchingConsoleSession}
                setIsSwitchingConsoleSession={setIsSwitchingConsoleSession}
                setShowModal={setShowModal}
                rightSidePanel={rightSidePanel}
            />
                : <RoomMonitoringDefaultView
                    roomMonitorMessage={getRoomMonitorMessage()}
                    maxSupportedCameras={maxSupportedCameras}
                    singleRecieverView={singleRecieverView}
                    renderState={isSwitchingConsoleSession ? LOADING : MESSAGE}
                    isSwitchingConsoleSession={isSwitchingConsoleSession}
                    currentUserUuid={currentUserUuid}
                />}
            {showModal && <ModalComponent
                header={""}
                showModal={showModal}
                modalContent={`
                    ${intl.formatMessage({ id: "content.room.toggleDisplayCameraWarningMessage1", defaultMessage: en["content.room.toggleDisplayCameraWarningMessage1"] })} 
                    ${intl.formatMessage({ id: "content.room.toggleDisplayCameraWarningMessage2", defaultMessage: en["content.room.toggleDisplayCameraWarningMessage2"] })}
                `}
                showCloseIcon={false}
                actionButton1Onclick={() => setShowModal(false)}
                actionButton1Text={intl.formatMessage({ id: "content.ok.btn", defaultMessage: en["content.ok.btn"] })}
                onClose={() => setShowModal(false)}
                modalStyles={"errorModal"}
            />}
        </div>

    )
}

export default RoomMonitoringStreamView
