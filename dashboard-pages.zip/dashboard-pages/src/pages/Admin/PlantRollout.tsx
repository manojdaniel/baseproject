import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import PlantRolloutTable from "table/PlantRolloutTable";
import {
	getPlantRollout,
	updatePlantRollout,
	updatePlantRolloutStatus,
} from "../../redux/reducers/CommonReducer";
import PushNotification from "components/PushNotification";
import Loader from "components/Loader";
import { encryptRSAData } from "../../utility/rsa";

const PlantRollout = () => {
	let dispatch = useDispatch();
	const [loading, setLoading] = useState<any>(false);
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);
	const { plantRolloutData, loadingPlantRollout, plantRolloutStatus } =
		useSelector((state: any) => ({
			plantRolloutData: state.Common.plantRollout,
			loadingPlantRollout: state.Common.loadingPlantRollout,
			plantRolloutStatus: state.Common.plantRolloutStatus,
		}));

	useEffect(() => {
		if (plantRolloutData.length > 0) {
			setParentData(plantRolloutData);
			setData(plantRolloutData);
		}
	}, [plantRolloutData]);

	useEffect(() => {
		if (plantRolloutStatus.length > 0) {
			if (!plantRolloutStatus.hasOwnProperty("Succeeded")) {
				if (plantRolloutStatus[0].retVal === 1) {
					PushNotification("success", plantRolloutStatus[0].retMsg);
				} else {
					PushNotification("error", plantRolloutStatus[0].retMsg);
				}
			} else {
				PushNotification("error", plantRolloutStatus.Message);
			}
			const emptyObj = [];
			dispatch(updatePlantRolloutStatus(emptyObj));
		} else {
			if (plantRolloutStatus.hasOwnProperty("Succeeded")) {
				PushNotification("error", plantRolloutStatus.Message);
			}
		}
		dispatch(getPlantRollout(""));
	}, [plantRolloutStatus]);

	const handleUpdate = (plantID, isRollout) => {
		setLoading(true);
		let plantdata = {
			plantId: plantID,
			isRollout: isRollout,
		};
		dispatch(
			updatePlantRollout(
				encryptRSAData(`plantId=${plantID}&isRollOut=${isRollout}`)
			)
		);
		dispatch(getPlantRollout(""));
		setLoading(false);
	};

	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.affiliateName !== null &&
				item.affiliateName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.plantName !== null &&
				item.plantName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.countryName !== null &&
				item.countryName
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.abbreviation !== null &&
				item.abbreviation
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.lattitude !== null &&
				item.lattitude
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.longitude !== null &&
				item.longitude
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};

	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9- ]+$/i.test(keyValue)) event.preventDefault();
	};
	return (
		<div id="plant-rollout">
			{loading ? <Loader /> : null}
			<div id="new-filter" className="mt0">
				<div className="nf-left">
					<div className="title">PLANT ROLLOUT</div>
					<div className="asset-name"></div>
				</div>
				<div className="nf-right">
					<div className="rightsearch">
						<input
							type="search"
							value={query}
							onChange={handleChange}
							placeholder="Search..."
							onKeyPress={handleKeyPress}
							onPaste={handleKeyPress}
						/>
					</div>
				</div>
			</div>
			<div className="common-box-content">
				{loadingPlantRollout ? (
					<Loader />
				) : (
					<PlantRolloutTable data={data} handleUpdate={handleUpdate} />
				)}
			</div>
		</div>
	);
};
export default PlantRollout;
