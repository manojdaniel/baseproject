import os
from ssl import get_default_verify_paths
from src.constants.constants import RABBIT_RETRY_MAX_TRIES, RABBIT_RETRY_DELAY, RABBIT_RETRY_MAX_JITTER
from src.loggers.log import create_logger


LOG = create_logger("Retry")

# TODO: Shift this to a better place
FALLBACK = {
    RABBIT_RETRY_MAX_TRIES: 3,
    RABBIT_RETRY_DELAY: 30,
    RABBIT_RETRY_MAX_JITTER: 3
}

def get_retrying_options(option_list):
    try:
        options = [int(os.environ.get(option, FALLBACK[option])) for option in option_list]
        LOG.info(f"Providing retrying options: {list(zip(option_list, options))}")
        return options
    
    except Exception as ex:
        LOG.exception(f"Exception occurred while fetching options for retry: {ex}")
        raise ex
