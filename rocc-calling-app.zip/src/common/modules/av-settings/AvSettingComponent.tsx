/*
 * Created on Tue Sept 21 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, EClinicalRole } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import cx from "classnames"
import React, { MutableRefObject } from "react"
import { useSelector } from "react-redux"
import { Container, Dropdown, Input } from "semantic-ui-react"
import CameraAndMicrophoneAccess from "../../../assets/images/videoSourceBrowserControl.png"
import volumeOff from "../../../assets/images/volumeOff.png"
import volumeUp from "../../../assets/images/volumeUp.png"
import { EAvSettingsType, IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/translations/en-US"
import { filterCallStatus } from "../../helpers/callUtility"
import styles from "./AvSettingComponent.scss"
import { MediaOptions } from "./AvSettingsController"

interface IAvSettingProps {
    active: boolean
    customLoader: boolean
    audioCameraAccessError: boolean
    audioInputOptions: MediaOptions[]
    audioOutputOptions: MediaOptions[]
    videoInputOptions: MediaOptions[]
    handleSettings: (type: EAvSettingsType, data: any) => void
    handleVolume: (data: any) => void
    videoRef: MutableRefObject<any>
    webCamAvailable: boolean
}

const AvSetting = (props: IAvSettingProps) => {
    const { intl } = getIntlProvider()
    const {
        audioOutput, audioSource, videoSource, volume, currentUser, videoCallStatus, connectedCallDetails, desktopCallWindowFullScreen,
    } = useSelector((state: IStore) => ({
        audioSource: state.callReducer.audioSource,
        videoSource: state.callReducer.videoSource,
        audioOutput: state.callReducer.audioOutput,
        volume: state.callReducer.volume,
        currentUser: state.externalReducer.currentUser,
        videoCallStatus: state.callReducer.videoCallStatus,
        connectedCallDetails: state.callReducer.callDetails.connectedCallDetails,
        desktopCallWindowFullScreen: state.callReducer.desktopCallWindowFullScreen,
    }))

    const { active, audioCameraAccessError, handleSettings, handleVolume, audioInputOptions, audioOutputOptions, videoInputOptions, videoRef, webCamAvailable } = props
    const avDeviceSettingsClassName = (currentUser.clinicalRole === EClinicalRole.DEVICE || desktopCallWindowFullScreen) ? styles.avDeviceSettings : ""
    const hideVideoOptionClassName = filterCallStatus(videoCallStatus, ECallStatus.CONNECTED, true).length && connectedCallDetails.numOfParticipants > 1 ? styles.hideVideoOption : ""
    const settingsTitleId = hideVideoOptionClassName ? "content.av.titleAudio" : "content.av.titleAudioVideo"

    const displayUserMediaBlockMessage = (customHeader1: string, customHeader2: string) => {
        return (
            <div className={cx(styles.row, (active) ? styles.active : "")}>
                <div className={styles.customLoader}>
                    <div className={styles.customMessage}>
                        <p className={styles.customHeader}>
                            {intl.formatMessage({ id: customHeader1, defaultMessage: en["content.AvSettingPage.customHeader1"] })}
                            <span>
                                {intl.formatMessage({ id: customHeader2, defaultMessage: en["content.AvSettingPage.customHeader2"] })}
                            </span>
                            <p>
                                <img
                                    src={CameraAndMicrophoneAccess}
                                    className={styles.CameraAndMicrophoneAccess}
                                    alt="Camera and microphone access"
                                />
                            </p>
                        </p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <>
            <div id="avSetting" className={cx(styles.row, (active) ? styles.active : "", avDeviceSettingsClassName)}>
                <div className={styles.headerTitle}>
                    {intl.formatMessage({ id: settingsTitleId, defaultMessage: en[settingsTitleId] })}
                </div>
                {!audioCameraAccessError ?
                    <>
                        <div className={styles.column} >
                            <label htmlFor="audioSource" className={styles.label}>
                                {intl.formatMessage({ id: "content.audio.input", defaultMessage: en["content.audio.input"] })}
                            </label>
                            <Dropdown
                                id={"audioInputSource"}
                                className={styles.selectDropdown}
                                options={audioInputOptions}
                                onChange={(e, data) => handleSettings(EAvSettingsType.AUDIO_INPUT, data)}
                                placeholder={intl.formatMessage({ id: "content.placeholder.audioInput", defaultMessage: en["content.placeholder.audioInput"] })}
                                fluid={true}
                                selection={true}
                                defaultValue={audioSource}
                                upward={false}
                            />
                        </div>

                        <div className={styles.column} >
                            <label htmlFor="audioOutput" className={styles.label}>
                                {intl.formatMessage({ id: "content.audio.output", defaultMessage: en["content.audio.output"] })}
                            </label>
                            <Dropdown
                                id={"audioOutputSource"}
                                className={styles.selectDropdown}
                                options={audioOutputOptions}
                                onChange={(e, data) => handleSettings(EAvSettingsType.AUDIO_OUTPUT, data)}
                                placeholder={intl.formatMessage({ id: "content.placeholder.audioOutput", defaultMessage: en["content.placeholder.audioOutput"] })}
                                fluid={true}
                                selection={true}
                                defaultValue={audioOutput}
                                upward={false}
                            />
                            <div id={"volumeSlider"}>
                                <span className={styles.volumeOff}>
                                    <img src={volumeOff} alt="volume off" />
                                </span>
                                <span className={styles.volumeControl}>
                                    <Input
                                        type="range"
                                        id="vol-control"
                                        min="0"
                                        max="100"
                                        step="1"
                                        onChange={(e, data) => handleVolume(data)}
                                        defaultValue={volume}
                                    />
                                </span>
                                <span className={styles.volumeUp}>
                                    <img src={volumeUp} alt="volume Up" />
                                </span>
                            </div>
                        </div>

                        <div className={cx(styles.column, styles.fullWidth, hideVideoOptionClassName)}>
                            <label htmlFor="videoSource" className={styles.label}>
                                {intl.formatMessage({ id: "content.video", defaultMessage: en["content.video"] })}
                            </label>
                            {webCamAvailable ? <>
                                <Dropdown
                                    id={"videoSource"}
                                    className={styles.selectDropdown}
                                    options={videoInputOptions}
                                    onChange={(e, data) => handleSettings(EAvSettingsType.VIDEO_INPUT, data)}
                                    placeholder={intl.formatMessage({ id: "content.placeholder.videoSource", defaultMessage: en["content.placeholder.videoSource"] })}
                                    fluid={true}
                                    selection={true}
                                    value={videoSource}
                                    upward={false}
                                />
                                <Container className={cx(styles.previewVideo)}>
                                    <video ref={videoRef} autoPlay={true} playsInline={true} muted={true} />
                                </Container>
                            </> : displayUserMediaBlockMessage("content.AvSettingPage.webcamHeader1", "content.AvSettingPage.webcamHeader2")}
                        </div>
                    </>
                    : displayUserMediaBlockMessage("content.AvSettingPage.customHeader1", "content.AvSettingPage.customHeader2")
                }
            </div>
        </>
    )
}

export default AvSetting
