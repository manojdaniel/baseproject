import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import LiveModel from "./LiveModel";

describe("LiveModel", () => {
	test("renders without crashing", () => {
		const { getByTestId } = render(
			<LiveModel
				FailurepreDictionByAssetId={[]}
				AnomalyModelbyAssetId={[]}
				setSensorGroupId={undefined}
				selectedAssetIdGlobal={undefined}
			/>
		);
		const liveModelComponent = getByTestId("live-model-component");
		expect(liveModelComponent).toBeInTheDocument();
	});

	test("initial showPopup state is false", () => {
		const { getByTestId } = render(
			<LiveModel
				FailurepreDictionByAssetId={[]}
				AnomalyModelbyAssetId={[]}
				setSensorGroupId={undefined}
				selectedAssetIdGlobal={undefined}
			/>
		);
		const showPopupState = getByTestId("show-popup-state");
		expect(showPopupState.textContent).toBe("false");
	});
	describe("getTopPosition", () => {
		it("returns the correct value for data between 0 and 30", () => {
			const data = 15;
			const expected = 145;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		it("returns the correct value for data between 31 and 33", () => {
			const data = 32;
			const expected = 60;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		it("returns the correct value for data between 34 and 36", () => {
			const data = 35;
			const expected = 50;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		// add more test cases for other data ranges
	});

	describe("LiveModel", () => {
		describe("getSelectedclassName", () => {
			it("should return 'getactive' when showToggle is true and selectedsensorGroupId is equal to id", () => {
				const showToggle = true;
				const selectedsensorGroupId = "1";
				const id = "1";
				const result = render(
					<LiveModel
						showToggle={showToggle}
						selectedsensorGroupId={selectedsensorGroupId}
					/>
				).getSelectedclassName(id);
				expect(result).toEqual("getactive");
			});
		});
		it("should return 'setactive' when showToggle is true and selectedsensorGroupId is not equal to id", () => {
			const showToggle = true;
			const selectedsensorGroupId = "2";
			const id = "1";
			const result = render(
				<LiveModel
					showToggle={showToggle}
					selectedsensorGroupId={selectedsensorGroupId}
				/>
			).getSelectedclassName(id);
			expect(result).toEqual("setactive");
		});

		it("should return an empty string when showToggle is false", () => {
			const showToggle = false;
			const selectedsensorGroupId = "1";
			const id = "1";
			const result = render(
				<LiveModel
					showToggle={showToggle}
					selectedsensorGroupId={selectedsensorGroupId}
				/>
			).getSelectedclassName(id);
			expect(result).toEqual("");
		});
	});
	describe("getTopPosition", () => {
		it("returns the correct value for data between 0 and 30", () => {
			const data = 15;
			const expected = 145;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		it("returns the correct value for data between 31 and 33", () => {
			const data = 32;
			const expected = 60;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		it("returns the correct value for data between 34 and 36", () => {
			const data = 35;
			const expected = 50;
			const result = LiveModel.prototype.getTopPosition(data);
			expect(result).toBe(expected);
		});

		// add more test cases for other data ranges
	});

	describe("LiveModel", () => {
		const AnomalyModelbyAssetId = [
			{
				sensorGroupId: "1",
				sensorGroup: "Sensor Group 1",
				healthIndex: 75,
				healthIndexTrend: true,
			},
			{
				sensorGroupId: "2",
				sensorGroup: "Sensor Group 2",
				healthIndex: 50,
				healthIndexTrend: false,
			},
		];

		const FailurepreDictionByAssetId = [
			{
				modelName: "Model 1",
				rul: 20,
				confidenceFactor: 0.85,
			},
			{
				modelName: "Model 2",
				rul: 15,
				confidenceFactor: 0.75,
			},
		];

		const mockOpenAssetPopup = jest.fn();
		const mockGetFunctionAnomalyid = jest.fn();
		const mockGetSelectedclassName = jest.fn();

		it("should render the Anomaly Model and Failure Prediction accordions", () => {
			const { getByText } = render(
				<LiveModel
					selectedAssetIdGlobal="Asset 1"
					AnomalyModelbyAssetId={AnomalyModelbyAssetId}
					FailurepreDictionByAssetId={FailurepreDictionByAssetId}
					openAssetPopup={mockOpenAssetPopup}
					getFunctionAnomalyid={mockGetFunctionAnomalyid}
					getSelectedclassName={mockGetSelectedclassName}
				/>
			);

			expect(getByText("Anomaly Model")).toBeInTheDocument();
			expect(getByText("Failure Prediction")).toBeInTheDocument();
		});

		it("should call the openAssetPopup function when an Failure Prediction model row is clicked", () => {
			const { getByText } = render(
				<LiveModel
					selectedAssetIdGlobal="Asset 1"
					AnomalyModelbyAssetId={AnomalyModelbyAssetId}
					FailurepreDictionByAssetId={FailurepreDictionByAssetId}
					openAssetPopup={mockOpenAssetPopup}
					getFunctionAnomalyid={mockGetFunctionAnomalyid}
					getSelectedclassName={mockGetSelectedclassName}
				/>
			);

			fireEvent.click(getByText("Model 1"));

			expect(mockOpenAssetPopup).toHaveBeenCalledWith({
				modelName: "Model 1",
				rul: 20,
				confidenceFactor: 0.85,
			});
		});
		describe("LiveModel", () => {
			const selectedAssetIdGlobal = "Asset123";

			const AnomalyModelbyAssetId = [
				{
					sensorGroupId: "Sensor1",
					sensorGroup: "Sensor Group 1",
					healthIndex: 75,
					healthIndexTrend: true,
				},
				{
					sensorGroupId: "Sensor2",
					sensorGroup: "Sensor Group 2",
					healthIndex: 50,
					healthIndexTrend: false,
				},
			];

			const FailurepreDictionByAssetId = [
				{ modelName: "Model1", rul: 40, confidenceFactor: 0.8 },
				{ modelName: "Model2", rul: 20, confidenceFactor: 0.6 },
			];

			it("renders LiveModel component with data", () => {
				render(
					<LiveModel
						selectedAssetIdGlobal={selectedAssetIdGlobal}
						AnomalyModelbyAssetId={AnomalyModelbyAssetId}
						FailurepreDictionByAssetId={FailurepreDictionByAssetId}
						setSensorGroupId={undefined}
					/>
				);

				// check if LiveModel component renders correctly
				expect(screen.getByText("LIVE MODELS")).toBeInTheDocument();
				expect(screen.getByText(selectedAssetIdGlobal)).toBeInTheDocument();

				// check if Anomaly Model accordian section renders correctly
				const anomalyModelAccordionTitle = screen.getByText("Anomaly Model");
				expect(anomalyModelAccordionTitle).toBeInTheDocument();
				fireEvent.click(anomalyModelAccordionTitle);
				expect(screen.getByText("Model Name")).toBeInTheDocument();
				expect(screen.getByText("Health Index %")).toBeInTheDocument();
				expect(screen.getAllByTestId("amhi-row").length).toEqual(2);

				// check if Failure Prediction accordian section renders correctly
				const failurePredictionAccordionTitle =
					screen.getByText("Failure Prediction");
				expect(failurePredictionAccordionTitle).toBeInTheDocument();
				fireEvent.click(failurePredictionAccordionTitle);
				expect(screen.getByText("MODEL NAME")).toBeInTheDocument();
				expect(screen.getByText("RUL")).toBeInTheDocument();
				expect(screen.getByText("CONFIDENCE FACTOR")).toBeInTheDocument();
				expect(screen.getAllByTestId("amfp-row").length).toEqual(2);
			});

			it("renders asset popup when clicking on Failure Prediction row", () => {
				render(
					<LiveModel
						selectedAssetIdGlobal={selectedAssetIdGlobal}
						AnomalyModelbyAssetId={AnomalyModelbyAssetId}
						FailurepreDictionByAssetId={FailurepreDictionByAssetId}
						setSensorGroupId={undefined}
					/>
				);

				const failurePredictionAccordionTitle =
					screen.getByText("Failure Prediction");
				fireEvent.click(failurePredictionAccordionTitle);

				const failurePredictionRow = screen.getAllByTestId("amfp-row")[0];
				fireEvent.click(failurePredictionRow);

				// check if asset popup renders correctly
				expect(screen.getByText("P-F-CURVE")).toBeInTheDocument();
				expect(
					screen.getByText(FailurepreDictionByAssetId[0].modelName)
				).toBeInTheDocument();
				expect(screen.getByText("Model1")).toBeInTheDocument();
				expect(screen.getByTestId("ap-dropdown")).toBeInTheDocument();
				expect(screen.getByTestId("ap-heatmap")).toBeInTheDocument();
			});
		});

		// Add more tests as needed
	});
});
