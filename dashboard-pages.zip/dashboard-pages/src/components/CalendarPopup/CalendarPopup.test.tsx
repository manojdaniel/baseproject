import React from "react";
import { render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import moment from "moment";
import CalendarPopup from "./index";

// Mock the react-redux library
jest.mock("react-redux", () => ({
	useDispatch: () => jest.fn(),
	useSelector: () => ({
		commonFromDate: "",
		commonToDate: "",
		commonFromDateFormat: "",
		commonToDateFormat: "",
	}),
}));

//   // Mock the DatePickerComponent
//   jest.mock('./DatePickerComponent', () => {
//     return (props) => {
//       const { value, onChange } = props;
//       return (
//         <input
//           type="text"
//           value={value}
//           onChange={(e) => {
//             const newDate = new Date(e.target.value);
//             onChange(newDate);
//           }}
//         />
//       );
//     };
//   });

describe("CalendarPopup", () => {
	it("renders without crashing", () => {
		// Render the component
		render(<CalendarPopup title="common" />);
	});

	it('updates the "From" date when a new date is selected', () => {
		// Mock the dispatch function
		const dispatchMock = jest.fn();
		jest.spyOn(React, "useDispatch").mockReturnValue(dispatchMock);

		// Render the component
		const { getByText, getByDisplayValue } = render(
			<CalendarPopup title="common" />
		);

		// Click on the "From" label to show the date picker
		const fromDateLabel = getByText("From");
		fireEvent.click(fromDateLabel);

		// Select a new date
		const newDate = new Date(2023, 4, 5);
		fireEvent.change(getByDisplayValue(""), {
			target: { value: moment(newDate).format("MM/DD/YYYY") },
		});

		// Check that the dispatch function was called with the correct action
		expect(dispatchMock).toHaveBeenCalledWith({
			type: "SET_COMMON_FROM_DATE",
			payload: newDate,
		});
	});

	it('updates the "To" date when a new date is selected', () => {
		// Mock the dispatch function
		const dispatchMock = jest.fn();
		jest.spyOn(React, "useDispatch").mockReturnValue(dispatchMock);

		// Render the component
		const { getByText, getByDisplayValue } = render(
			<CalendarPopup title="common" />
		);

		// Click on the "To" label to show the date picker
		const toDateLabel = getByText("To");
		fireEvent.click(toDateLabel);

		// Select a new date
		const newDate = new Date(2023, 4, 6);
		fireEvent.change(getByDisplayValue(""), {
			target: { value: moment(newDate).format("MM/DD/YYYY") },
		});

		// Check that the dispatch function was called with the correct actions
		expect(dispatchMock).toHaveBeenCalledWith({
			type: "SET_COMMON_TO_DATE",
			payload: newDate,
		});
		expect(dispatchMock).toHaveBeenCalledWith({
			type: "SET_BREADCRUMB_DATE",
			payload: { id: "", updatedDate: "" },
		});
		expect(dispatchMock).toHaveBeenCalledWith({
			type: "SET_TODAY_DATE",
			payload: "",
		});
	});
});
