/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import "@dls-pdv/semantic-ui-foundation/dist/semantic.min.css"
import { CallEnd } from "@rocc/rocc-calling-components"
import { DEFAULT_CONTACT_INFO, ECallStatus, EClinicalRole, EOutGoingCallStatus } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import { useDispatch, useSelector } from "react-redux"
import { putService } from "../../common/helpers/apiUtility"
import { upsertCallStatus } from "../../common/helpers/callUtility"
import { getRoleName, getSiteName, getTranslatedCallType } from "../../common/helpers/helpers"
import { createUrlCall } from "../../common/modules/avmessages/messageService"
import { CALL_CANCELLED, CALL_REJECT, DEVICE } from "../../constants/constants"
import { AV_CALL_EP } from "../../constants/endpoints"
import { setCallMessage, setOutgoingCallDetails, setVideoCallStatus } from "../../redux/actions/callActions"
import { IStore } from "../../redux/interfaces/types"
import { DEFAULT_OUTGOING_CALL_DEATILS } from "../../redux/reducers/callReducer"
import { fetchGlobalURLs } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import IntermediateCallWindow from "../intermediate-call-window/IntermediateCallWindow"
import { postMissedCallService } from "../missed-call-panel/MissedCallServices"

interface IOutgoingCallProps {
    callWindowFullscreen: boolean
}

const OutgoingCall = (props: IOutgoingCallProps) => {

    const { intl } = getIntlProvider()
    const dispatch = useDispatch()

    const { outgoingCall, currentUser } = useSelector((state: IStore) => ({
        outgoingCall: state.callReducer.callDetails.outgoingCall,
        currentUser: state.externalReducer.currentUser,
    }))

    const cancelOutgoingCall = async () => {
        const { contextId, participant } = outgoingCall
        const urls = fetchGlobalURLs()
        const { accessToken, sessionId, uuid } = currentUser
        const { intl } = getIntlProvider()
        if (contextId) {
            dispatch(setVideoCallStatus(upsertCallStatus(contextId, ECallStatus.CALLREJECT)))
            dispatch(setCallMessage({
                messageType: getTranslatedCallType(CALL_CANCELLED),
                message: intl.formatMessage({ id: "content.callMessages.youCancelledCall", defaultMessage: en["content.callMessages.youCancelledCall"] }),
                contact: { ...DEFAULT_CONTACT_INFO }
            }))
            if (contextId && participant && participant.uuid) {
                postMissedCallService(currentUser, urls.COMMUNICATION_SERVICES_URL, contextId, participant.uuid, uuid)
            }
            const params: any = createUrlCall({
                accessToken,
                sessionId,
                userUuid: uuid,
                communicationServiceUrl: `${urls.COMMUNICATION_SERVICES_URL}${AV_CALL_EP}`,
                contextId,
                callStatus: CALL_REJECT,
                state: false,
            })
            await putService(params)
            dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
        }
    }

    if (outgoingCall.status === EOutGoingCallStatus.CALLING) {
        const participant = outgoingCall.participant
        const { name, secondaryName, clinicalRole, description, siteId, loggedInLocation } = participant
        const isSecondaryUser = secondaryName ? true : false
        const callMessage = intl.formatMessage({ id: "content.outgoingCall.calling", defaultMessage: en["content.outgoingCall.calling"] })

        return <IntermediateCallWindow
            displayName={isSecondaryUser ? secondaryName : name}
            metaData={isSecondaryUser ? getRoleName(EClinicalRole.TECHNOLOGIST) : getRoleName(clinicalRole)}
            description={(clinicalRole == DEVICE) ? getSiteName(description, siteId) : (loggedInLocation || "")}
            callMessage={callMessage}
            callWindowFullscreen={props.callWindowFullscreen}
            additionalComponent={() => <CallEnd onClick={cancelOutgoingCall} />}
        />
    }
    return <></>

}

export default OutgoingCall
