"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.constants.headers import EXCEL_USER_ROLES, EXCEL_USER_ADDITIONAL_ROLES, EXCEL_USER_EMAIL_ID, EXCEL_USER_HOSPITAL_IDENTIFIER, EXCEL_USER_MODALITY, \
    EXCEL_USER_ROOM_IDENTIFIER, EXCEL_USER_FIRST_NAME, EXCEL_USER_LAST_NAME, EXCEL_USER_PHONE
from src.constants.constants import ROCC_USERS, ROCC_APPLICATION_ROLES, ROCC_SITES, ROCC_MODALITY_TYPES, ROCC_SCANNER_RESOURCES, IS_SUCCESSFULL, IS_NEW
from src.wrappers.graphql.queries.queries import check_if_unique_ids_exist, fetch_required_info_for_user_creation
from src.constants.enums import EDBRoles, EExcelRoles, ESummaryStates
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity


LOG = create_logger("UserInsertionServices")


def compute_user_roles(user):
    roles = []
    for user_role in user[EXCEL_USER_ROLES].split(","):
        user_role = user_role.strip()
        if user_role == EExcelRoles.ADMIN:
            roles.append(EDBRoles.ADMINROLE)
        elif user_role == EExcelRoles.EXPERTUSER:
            roles.append(EDBRoles.EXPERTUSERROLE)
            roles.extend(compute_user_additional_role(user))
        elif user_role == EExcelRoles.TECHNOLOGIST:
            roles.append(EDBRoles.TECHNOLOGISTROLE)
    return roles


def compute_user_additional_role(user):
    roles = []
    additional_roles = user[EXCEL_USER_ADDITIONAL_ROLES].split(",")
    for additional_role in additional_roles:
        if additional_role == EExcelRoles.PROTOCOLMANAGER:
            roles.append(EDBRoles.PROTOCOLMANAGERROLE)
        if additional_role == EExcelRoles.INCOGNITO:
            roles.append(EDBRoles.INCOGNITOROLE)
    return roles


def check_if_new_user(emp_dict, client, transaction_data):
    all_unique_ids = []
    existing_unique_ids = {}
    try:
        for key, employee in emp_dict.items():
            all_unique_ids.append(employee[EXCEL_USER_EMAIL_ID])

        query_result = client.execute(check_if_unique_ids_exist, variable_values={"unique_ids": all_unique_ids})

        for unique_id in query_result[ROCC_USERS]:
            existing_unique_ids[unique_id["unique_identity"]] = unique_id["id"]

        for key, employee in emp_dict.items():
            if employee[EXCEL_USER_EMAIL_ID] in existing_unique_ids:
                employee[IS_NEW] = False
                employee["employee_id"] = existing_unique_ids[key]
                transaction_data = update_summary_for_entity(transaction_data, "users", key, ESummaryStates.EXISTING)
            else:
                # TODD: Capture in Audit. LOG.info(f"New user:  {employee[EXCEL_USER_EMAIL_ID]}")
                employee[IS_NEW] = True
                employee["employee_id"] = None
                transaction_data = update_summary_for_entity(transaction_data, "users", key, ESummaryStates.NEW)
    except Exception as ex:
        LOG.exception(f"Error while fetching existing unique Ids : {ex}")
        raise ex
    return emp_dict, transaction_data


# Fetches new user list to insert
def fetch_userlist(emp_dict, client, org_db_id):
    new_user_list = []  # List of new users to be passed in add user API
    for employee in emp_dict.values():
        if employee[IS_NEW]:
            employee_info = {"roles": compute_user_roles(employee), "sites": employee[EXCEL_USER_HOSPITAL_IDENTIFIER].split(","),
                             "modalities": employee[EXCEL_USER_MODALITY].split(","), "resources": employee[EXCEL_USER_ROOM_IDENTIFIER].split(",")}
            db_response = extract_employee_info_from_db(employee_info, client)

            user_obj = {
                "metasiteId": org_db_id,
                "firstName": employee[EXCEL_USER_FIRST_NAME],
                "lastName": employee[EXCEL_USER_LAST_NAME],
                "phoneNumber": employee[EXCEL_USER_PHONE],
                "uniqueId": employee[EXCEL_USER_EMAIL_ID].lower(),
                "emailId": employee[EXCEL_USER_EMAIL_ID].lower(),
                "clinicalRoles": db_response["roles"],
                "sites": db_response["sites"],
                "modalities": db_response["modalities"],
                "resources": db_response["resources"],
            }
            new_user_list.append(user_obj)
    return new_user_list


def extract_employee_info_from_db(user, client):
    try:
        query_result = client.execute(fetch_required_info_for_user_creation,
                                      variable_values={"roles": user["roles"],
                                                       "sites": user["sites"],
                                                       "modalities": user["modalities"],
                                                       "resources": user["resources"]})
        role_list = [role["application_role_id"] for role in query_result[ROCC_APPLICATION_ROLES]]
        site_list = query_result[ROCC_SITES]
        modality_list = query_result[ROCC_MODALITY_TYPES]
        resource_list = query_result[ROCC_SCANNER_RESOURCES]
        return {"roles": role_list, "sites": site_list, "modalities": modality_list, "resources": resource_list}
    except Exception as ex:
        LOG.exception(f"extract_employee_info_from_db failed with error : {ex}")
        raise RoccException(500, "Error while extracting employee data from DB") from ex


def update_user_status_in_dict(emp_dict, unique_id, is_successful=False, employee_id=None):
    emp_dict[unique_id]["employee_id"] = employee_id
    emp_dict[unique_id][IS_SUCCESSFULL] = is_successful
    return emp_dict


def prepare_invitation_mail_object(successfully_added_list, emp_dict):
    request_body = []
    #pylint: disable=unused-variable
    for key, employee in emp_dict.items():
        roles = compute_user_roles(employee)
        # Constants
        if employee[EXCEL_USER_EMAIL_ID] in successfully_added_list and not (len(roles) == 1 and ("technologistrole" in roles)):
            request_body.append({"userId": employee["employee_id"], "action": "Invite"})
    return request_body


def fetch_email_id_from_employee_id(emp_dict, employee_id):
    #pylint: disable=unused-variable
    for key, employee in emp_dict.items():
        if employee["employee_id"] and employee["employee_id"] == employee_id:
            return employee[EXCEL_USER_EMAIL_ID]
    return None
