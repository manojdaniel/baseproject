/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import EmptyScanner from "../../../common/modules/empty-scanner/EmptyScanner"
import ScannerCard from "../../../common/modules/scanner-card/ScannerCard"
import { getLocationDetailsForId } from "@rocc/rocc-client-services"
import { fetchGlobalLocations } from "../../../redux/store/externalAppStates"
import { useSelector } from "react-redux"
import { IStore } from "../../../redux/interfaces/types"

const locations = fetchGlobalLocations()

export const sourceContent = (isHighlighted: boolean) => {
    const { selectedSource } = useSelector((state: IStore) => ({
        selectedSource: state.protocolTransferReducer.selectedSource,
    }))
    const sourceHospital = getLocationDetailsForId(locations, selectedSource.locationId).name
    return (selectedSource.identity ?
        <ScannerCard hospitalLoc={sourceHospital} isHighlighted={isHighlighted} room={selectedSource} /> :
        <EmptyScanner messageId={"content.scannerEmpty.source"} defaultMessage={"Source"} isHighlighted={isHighlighted} />)
}

export const destinationContent = (isHighlighted: boolean) => {
    const { selectedDestination } = useSelector((state: IStore) => ({
        selectedDestination: state.protocolTransferReducer.selectedDestination
    }))
    const destHospital = getLocationDetailsForId(locations, selectedDestination.locationId).name
    return (selectedDestination.identity ?
        <ScannerCard hospitalLoc={destHospital} isHighlighted={isHighlighted} room={selectedDestination} /> :
        <EmptyScanner messageId={"content.scannerEmpty.destination"} defaultMessage={"Destination"} isHighlighted={isHighlighted} />)
}
