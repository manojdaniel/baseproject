import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import PerformanceTrend from "./index";

//Mock data for the chart component
const data = [
	{
		plantId: 14,
		utilization: 0,
		overdueAlerts: 12,
		newAlerts: 0,
		averageResponseTime: 0,
		datee: "11-1-2022",
	},
	{
		plantId: 14,
		utilization: 0,
		overdueAlerts: 37,
		newAlerts: 0,
		averageResponseTime: 0,
		datee: "12-1-2022",
	},
	{
		plantId: 14,
		utilization: 50,
		overdueAlerts: 1,
		newAlerts: 1,
		averageResponseTime: 0,
		datee: "1-1-2023",
	},
	{
		plantId: 14,
		utilization: 100,
		overdueAlerts: 0,
		newAlerts: 5,
		averageResponseTime: 0,
		datee: "2-1-2023",
	},
];

//Test Case to check chart exist in the component.
describe("PerformanceTrend", () => {
	it("renders the chart with data", () => {
		const { container } = render(<PerformanceTrend data={data} />);
		expect(container.querySelector("#chartdiv3")).toBeInTheDocument();
	});
});
