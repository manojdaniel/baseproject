
declare module "roccCalling/WebCallFeature"
declare module "roccCalling/PhoneCallFeature"
