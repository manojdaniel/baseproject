"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import os
import traceback

import requests

from src.constants.constants import CONTENT_TYPE, AUTHORIZATION, APPLICATION_JSON
from src.loggers.log import create_logger
from datetime import datetime

LOG = create_logger("AuditService")


def prepare_audit_message(event_type, event_subtype, action, outcome, source, user_id, org_id, extension_obj):
    # TODO: Object Array Needs to contain Additional Data on what data or object was the action performed on
    """
    1. Event: What Happened
        1.1 EventType: What's the event Type (Ex: Bulk Import)
        1.2 Event-Subtype: What's the sub event type (Ex: Customer Onboarding)
    2. Action: Whats the Action that happened
               It can be Create Record, Update Record, Delete Record, Read Record, Execute API call
            *Code*   |    *Display*      |     *Definition*
            C        |       Create      |   Create a new database object, such as placing an order.
            R        |   Read/View/Print |   Display or print data, such as a doctor census.
            U        |       Update      |   Update data, such as revise patient information.
            D        |       Delete      |   Delete items, such as a doctor master file record.
            E        |       Execute     |   Perform a system or application function such as log-on, program execution or use of an object's method, or perform a query/search operation.
    3. Outcome: What's the outcome of the event
                0: Success
                4: Minor Failre
                8: Serious Failure
                12: Major Failure
    4. UserId: The Actor/Participant who initiated the process.
    5. Source: Which system generated the event
    6. Tenant: Organization Details
    7. Object: What data or objects the action was performed
    """
    audit_message = {
        "eventType": event_type,
        "eventSubType": event_subtype,
        "action": action,
        "dateTime": str(datetime.utcnow().isoformat()[:-3] + 'Z'),
        "outcome": outcome,
        "userId": user_id,
        "source": source,
        "sourceType": "1",
        "extension": {
            "applicationVersion": "1",
            "componentName": source,
            "tenant": org_id
        },
        "object": extension_obj
    }
    return audit_message


def post_audit_message(access_token, audit_message):
    api_endpoint = os.environ.get("ROCC_PROXY_URL")
    org_id_header = {"Org-Id": audit_message["extension"]["tenant"]}
    headers = {AUTHORIZATION: access_token, CONTENT_TYPE: APPLICATION_JSON, "org_ctxt_header": str(json.dumps(org_id_header))}
    try:
        response = requests.post(url=f"{api_endpoint}/philips/rocc/Audit", data=json.dumps(audit_message), headers=headers)
        if response.status_code == 200:
            LOG.info("Audit Message posted successfully ..!!")
            return {"message": "Success", "status": response.status_code}
        else:
            LOG.info(f"Posting Audit Message failed, {response} : {response.json()}")
            return {"message": "Failed", "status": response.status_code}
    except requests.exceptions.RequestException as re:
        LOG.info("Exception occured while posting audit Message, {}".format(re))
        LOG.info(traceback.print_exc())
    except Exception as ex:
        LOG.info("Exception occured while posting audit Message, {}".format(ex))
        LOG.info(traceback.print_exc())
    return {"message": "Failed"}


def prepare_and_post_audit(event_type, event_subtype, action, outcome, user_detail, org_id, token, **kwargs):
    obj = []
    for key, value in kwargs.items():
        obj.append({"code": key, "value": value})
    audit_msg = prepare_audit_message(event_type=event_type,
                                      event_subtype=event_subtype,
                                      action=action,
                                      outcome=outcome,
                                      source="ServiceTool",
                                      user_id=user_detail,
                                      org_id=org_id,
                                      extension_obj=obj)
    post_audit_message(access_token=token, audit_message=audit_msg)
