/*
 * Created on Fri Jan 28 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import DemoEnvConsoleVideo from "../demo-env-console-video/DemoEnvConsoleVideo"
import { shallow } from "enzyme"
import React from "react"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        selectedContact: {
            name: "Test Name",
            clinicalRole: "Technologist",
            id: "1",
            uuid: "123",
            status: "Available",
            currentUserPresence: "Available",
            videoCallStatus: "Idle",
            phoneCallStatus: "Idle",
            phoneNumber: "+918789666081",
            allRoles: ["ExpertUser"],
        },
    }),
    connect: (stateToProps: any) => (connectComponent: any) => ({
        stateToProps,
        connectComponent,
    }),
    useDispatch: () => void (0),
}))

describe("<DemoEnvConsoleVideo />", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<DemoEnvConsoleVideo />)
    })
    it("should render page with a 'match' prop set", () => {
        expect(wrapper.props("match")).toBeDefined()
    })
})
