/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import gql from "graphql-tag"

export const QUERY_FETCH_ALL_RECEIVERS_FOR_A_SEAT = gql`
query fetch_all_receivers_for_a_seat($orgId: Int!, $seatName: String!) {
  receivers: rocc_get_seats_receivers_docs_info_function(args: {orgid: $orgId}, where: {seat_name: {_eq: $seatName}}, distinct_on: receiver_id) {
    id: receiver_id
    receiverName: receiver_connection_name
    monitorName: monitor_name
  }
}
`
export const QUERY_COMMAND_CENTER_SEATS = gql`
query fetchCommandCenterSeatsByMetasiteId($orgId: Int!) {
  command_center_seats: rocc_get_seats_receivers_docs_info_function(args: {orgid: $orgId}, distinct_on: cc_seat_id) {
    seatId: cc_seat_id
    seatName: seat_name
    registeredCount: registered_count
    orgId: org_id
    commandCenterLocation: seat_info
  }
}
`

export const SUBSCRIPTION_PID_ACTIVE_EMERALD_CONNECTIONS_FOR_USER = gql`
subscription fetchActiveConsoleSessionForRequester($requester: String!) {
  rocc_kvm_receiver_transaction: rocc_get_kvm_transactions_function(where: {_and: [
    {connection_mode: {_in: ["RDP", "VNC", "EMERALD"]}},
    {console_status: {_in: ["ASSOCIATE_INITIATED", "ASSOCIATE_COMPLETED"]}},
    {requester_uuid: {_eq: $requester}}]}) {
    contextId: context_uuid
    anywhereAppPid: anywhere_app_pid
  }
}
`
