/*
 * Created on Thu Oct 28 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EClinicalRole, FeatureFlagHelper, IParentStore, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { CustomLoader, ErrorBoundary, getIntlProvider } from "@rocc/rocc-global-components"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { Container, Grid } from "semantic-ui-react"
import TechAppDownload from "../../../components/tech-app-download/TechAppDownload"
import { TRACK } from "../../../constants/tracking"
import en from "../../../resources/translations/en-US"
import { trackEvent } from "../../../utility/helpers/helpers"
import styles from "./Settings.scss"

const AvSettingsFeature = React.lazy(() => import("roccCalling/AvSettingsFeature").catch(() => false))
const CommandCenterSettingsFeature = React.lazy(() => import("roccConsole/CommandCenterSettingsFeature").catch(() => false))

const Settings = () => {
    const { intl } = getIntlProvider()

    const { currentUser, featureFlags } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        featureFlags: state.featureFlagsReducer.featureFlags,
    }))

    const [isTechAppDownloadAvailable, setIsTechAppDownloadAvailable] = useState(false)
    const { allRoles } = currentUser
    const isAdminOnly = allRoles.length === 1 && allRoles[0] === EClinicalRole.ADMIN

    useEffect(() => {
        const { component, event: { settings } } = TRACK.NAV_BAR
        trackEvent(component, `${settings}`)
    }, [])

    useEffect(() => {
        setIsTechAppDownloadAvailable(
            FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_TECH_APP_DOWNLOAD)
            && currentUser.allRoles.includes(EClinicalRole.ADMIN)
        )
    }, [featureFlags])

    return (
        <Container fluid={true} style={{ margin: "20px 0" }}>
            <Grid padded={true}>
                <Grid.Row>
                    <Grid.Column stretched={true}>
                        <div className={styles.title}>
                            {intl.formatMessage({ id: "content.settings.title", defaultMessage: en["content.settings.title"] })}
                        </div>
                    </Grid.Column>
                </Grid.Row>
                <Grid className={styles.gridContaint}>
                    {!isAdminOnly && <>
                    <Grid.Row className={styles.gridRow}>
                        <Grid.Column stretched={true}>
                            <ErrorBoundary>
                                <React.Suspense fallback={<CustomLoader
                                    content={intl.formatMessage({ id: "content.loadingSettings.text", defaultMessage: en["content.loadingSettings.text"] })}
                                    inverted={true}
                                    customStyle={{ top: "50%", fontSize: ".85em" }}
                                    dimmer={false}
                                    inline={true}
                                    size={"normal"} />}>
                                    <AvSettingsFeature active={true} component={"Global Settings"} />
                                </React.Suspense>
                            </ErrorBoundary>
                        </Grid.Column>
                    </Grid.Row>

                    <Grid.Row className={styles.gridRow}>
                        <Grid.Column stretched={true}>
                            <ErrorBoundary>
                                <React.Suspense fallback={"Loading CommandCenterSettings"}>
                                    <CommandCenterSettingsFeature />
                                </React.Suspense>
                            </ErrorBoundary>
                        </Grid.Column>
                    </Grid.Row></>}

                     {isTechAppDownloadAvailable && <Grid.Row className={styles.gridRow}>
                        <Grid.Column stretched={true}>
                            <ErrorBoundary>
                                <React.Suspense fallback={"Loading Desktop Download"}>
                                    <TechAppDownload />
                                </React.Suspense>
                            </ErrorBoundary>
                        </Grid.Column>
                    </Grid.Row>}
                </Grid>
            </Grid>
        </Container>
    )
}

export default Settings
