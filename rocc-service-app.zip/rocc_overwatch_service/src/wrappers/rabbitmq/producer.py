"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

import pika

from tenacity import retry
from tenacity.retry import retry_if_exception_type
from tenacity.stop import stop_after_attempt
from tenacity.wait import wait_fixed, wait_random
from pika.exceptions import AMQPConnectionError

from src.constants.constants import DELAY_MESSAGE_TIME_IN_SECONDS, DELAY_QUEUE_EXPIRY_TIME_IN_SECONDS, RABBIT_RETRY_DELAY, RABBIT_RETRY_MAX_JITTER, RABBIT_RETRY_MAX_TRIES, ROCC_DELAYED_QUEUE
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.utility.retry import get_retrying_options
from src.wrappers.rabbitmq.rabbitmq_utility import check_if_queue_should_auto_delete, compute_rmq_queue_name

"""
Usage:
    server = Producer(ProducerConfig(host="localhost",
                                    queue=BULK_UPLOAD_QUEUE,
                                    routing_key=BULK_UPLOAD_QUEUE,
                                    exchange=""))
    server.publish(payload={"message": "sample data"})    # payload -> JSON/Dict data
"""

LOG = create_logger("Producer")


class ProducerConfig():
    """
    :param host: RabbitMq hostname/IP
    :return exchange: exchange name
    :param routing_key: routing_key name
    :param queue: queue name
    :return None
    """

    def __init__(self, host, routing_key, exchange, queue, delay_queue):
        self.host = host
        self.queue = queue
        self.routing_key = routing_key
        self.exchange = exchange
        self.delay_queue = delay_queue


class Producer():
    _max_tries, _delay, _max_jitter = get_retrying_options([RABBIT_RETRY_MAX_TRIES, RABBIT_RETRY_DELAY, RABBIT_RETRY_MAX_JITTER])

    def __init__(self, configs):
        try:
            self.configs = configs
            self._connection = pika.BlockingConnection(pika.URLParameters(self.configs.host))
            self._channel = self._connection.channel()
            if not self.configs.delay_queue:
                self._channel.queue_declare(queue=self.configs.queue,
                                            auto_delete=check_if_queue_should_auto_delete())
            else:
                arguments = {"x-dead-letter-exchange": self.configs.exchange,
                             "x-dead-letter-routing-key": self.configs.routing_key,
                             "x-message-ttl": int(os.environ.get(DELAY_MESSAGE_TIME_IN_SECONDS, "1800"))*1000}
                if check_if_queue_should_auto_delete():
                    """ Cleaning up of Queue if there are no consumers for provided expiry time """
                    arguments["x-expires"] = int(os.environ.get(DELAY_QUEUE_EXPIRY_TIME_IN_SECONDS, "1860"))*1000
                self._channel.queue_declare(queue=compute_rmq_queue_name(ROCC_DELAYED_QUEUE),
                                            durable=True,
                                            auto_delete=check_if_queue_should_auto_delete(),
                                            arguments=arguments)
            self._channel.queue_bind(exchange=self.configs.exchange, queue=self.configs.queue)
        except Exception as ex:
            LOG.exception(f"RabbitMQ Producer setup failed while declaring queue with: {ex}")
            raise RoccException(title="RabbitMQ Producer setup failed", payload="Exception occurred while setting up RabbitMQ Producer connection") from ex

    @retry(retry=retry_if_exception_type(AMQPConnectionError), stop=stop_after_attempt(_max_tries), wait=wait_fixed(_delay) + wait_random(0, _max_jitter))
    def publish(self, payload={}):
        try:
            if not self.configs.delay_queue:
                self._channel.basic_publish(exchange=self.configs.exchange,
                                            routing_key=self.configs.routing_key,
                                            properties=pika.BasicProperties(delivery_mode=2),
                                            body=str(payload))
            else:
                self._channel.basic_publish(exchange="",
                                            routing_key=compute_rmq_queue_name(ROCC_DELAYED_QUEUE),
                                            properties=pika.BasicProperties(delivery_mode=2),
                                            body=str(payload))
            LOG.info(f"[*] Published message: {payload}")
            self._connection.close()

        except AMQPConnectionError as ex:
            LOG.exception(f"Producer connection threw an error: {ex}")
            LOG.info(f"""Producer connection failed. Retrying. (Attempt #{self.listener.retry.statistics["attempt_number"]} of {self._max_tries})""")
            raise ex

        except Exception as ex:
            LOG.exception(f"Producer threw an error while publishing: {ex}")
            raise ex
