"""
 Created on Thu Sep 10 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask import request, g
from flask_restful import Resource

from src.constants.constants import API_VERSION
from src.constants.http_status_string import http_status_string_registry
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.services.raw_data_insertion_service.file_upload_service import FileUploadService
from src.utility.dict_utils import exract_file_from_immutable_object
from src.utility.utility import construct_negative_response
from src.utility.semver import parse_version

LOG = create_logger("FileController")


class File(Resource):
    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported are 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400

        try:
            file_content = exract_file_from_immutable_object(files=request.files, form_field="file")
            # TODO: Remove the customer_identifier field from input body, since it is going to be consumed from excel sheet data
            if not file_content:
                LOG.error("File upload failed as file was not provided!")
                raise RoccException(status_code=400, title="file field cannot be left blank!")
            upload_service = FileUploadService(service_user_uuid=g.userdetails)
            response = upload_service.process_raw_data(file_content=file_content)
            customer_identifier = response["customer_identifier"]
            LOG.info(f"File upload is successful for customer: {customer_identifier}")
            return {"message": "Uploaded file successfully validated", "file_identifier": response["file_identifier"], "customer_identifier": customer_identifier}, response["status"]

        except RoccException as ex:
            return construct_negative_response(code=http_status_string_registry[ex.status_code],
                                               title=ex.title,
                                               error_message=ex.payload,
                                               additional_info=ex.additional_info), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to parse the File upload response, error: {ex}")
            return construct_negative_response(code=500,
                                               title="Upload failed",
                                               error_message="Failed to upload data, please contact administrator"), 500

    def delete(self, record_id):
        try:
            if not record_id:
                return {"RecordId is mandatory"}, 400
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported are 1.0.0"), 400
        except KeyError as ex:
            LOG.error(f"{API_VERSION} is neccessary to process this request: {ex}")
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        except Exception as ex:
            LOG.error(f"Could not process this request: {ex}")
            return {"error": "Could not process this request"}, 500
        upload_service = FileUploadService(service_user_uuid=g.userdetails)
        response = upload_service.cleanup_record(record_id=record_id)
        try:
            if response["success"]:
                LOG.info(f"Raw data with record_id: {record_id} cleaned up successfully")
                return {"message": "Raw data cleaned up successfully"}, 204
            else:
                return {"message": response["message"]}, response["status"]
        except Exception as ex:
            LOG.exception(f"Failed to clean up File upload record, error: {ex}")
            return {"message": "Failed to clean up File upload record, please contact administrator"}, 500
