/*
 * Created on Fri Dec 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { setupLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { defineMessages, IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import { EN_LOCALE, EN_LANGUAGE } from "./common/constants/constants"
import { isDev } from "./common/helpers/helpers"
import MultiCameraSettingsPanel from "./common/modules/multi-camera/settings-panel/MultiCameraSettingsPanel"
import store, { persistor } from "./redux/store/store"
import messages from "./resources/translations/messages"

const MultiCameraSettingsFeature = () => {
	const locale = sessionStorage.getItem("locale")
	const language = sessionStorage.getItem("language")
	const defaultLocale = language || EN_LOCALE
	const defaultMessage = (locale: string) => defineMessages(messages[locale])
	useEffect(() => {
		setupLogger({ isDev: isDev() })
	}, [])

	return <>
		<Provider store={store}>
			<PersistGate loading={null} persistor={persistor}>
				<IntlProvider
					defaultLocale={defaultLocale}
					locale={defaultLocale}
					messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
				>
					<MultiCameraSettingsPanel />
				</IntlProvider>
			</PersistGate>
		</Provider>
	</>
}

export default MultiCameraSettingsFeature
