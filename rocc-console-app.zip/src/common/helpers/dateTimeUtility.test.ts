/*
 * Created on Wed Nov 2 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getDurationInFormat, sleep } from "./dateTimeUtility"

describe("Unit tests for DateTime utility", () => {
    let lesserDate: Date
    let largerDate: Date
    beforeEach(() => {
        lesserDate = new Date(1970, 1, 1)
        largerDate = new Date(1970, 1, 1)
    })
    
    it("should sleep for less than a second (~500 ms)", async () => {
        const c1 = new Date()
        await sleep(550)
        const diff = (new Date()).getTime() - c1.getTime()
        expect(diff).toBeGreaterThanOrEqual(500)
        expect(diff).toBeLessThan(1000)
    })

    it("Test date time difference in miliseconds", () => {
        largerDate.setMinutes(lesserDate.getMinutes() + 1)
        const diffInMiliSec = getDurationInFormat(largerDate, lesserDate, "miliseconds")
        expect(diffInMiliSec === 60000).toBeTruthy()
    })

    it("Test date time difference in seconds ", () => {
        largerDate.setMinutes(lesserDate.getMinutes() + 90)
        const diffInSeconds = getDurationInFormat(lesserDate, largerDate)
        expect(diffInSeconds === 5400).toBeTruthy()
    })
    it("Test date time difference in minutes ", () => {
        largerDate.setMinutes(lesserDate.getMinutes() + 90)
        const diffInMins = getDurationInFormat(lesserDate, largerDate, "minutes")
        expect(diffInMins === 90).toBeTruthy()
    })
    it("Test date time difference in hours ", () => {
        largerDate.setMinutes(lesserDate.getMinutes() + 90)
        const diffInHours = getDurationInFormat(lesserDate, largerDate, "hours")
        expect(diffInHours === 1).toBeTruthy()
    })

    it("Test date time difference in hours ", () => {
        largerDate.setMinutes(lesserDate.getMinutes() + 90)
        const data: any = undefined
        const diffInHours = getDurationInFormat(data, largerDate, "hours")
        expect(diffInHours === 0).toBeTruthy()
    })
})
