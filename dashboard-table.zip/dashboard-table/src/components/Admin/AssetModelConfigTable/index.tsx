import React from "react";
import { Table } from "antd";
import "../../../assets/common/CommonTables.scss";

interface Props {
	data: any[];
}
const AssetModelConfigTable = ({ data }: Props) => {
	const columns = [
		{
			title: "NAME",
			dataIndex: "modelName",
			key: "modelName",
			width:'33%'
		},
		{
			title: "X CO-ORDINATE",
			dataIndex: "x",
			key: "x",
			width:'33%'
		},
		{
			title: "Y CO-ORDINATE",
			dataIndex: "y",
			key: "y",
			width:'33%'
		},
	];

	return (
		<div id="acr-table">
			<Table
				columns={columns}
				dataSource={data}
				pagination={false}
				scroll={{ x: true, y: '100%' }}
			/>
		</div>
	);
};

export default AssetModelConfigTable;
