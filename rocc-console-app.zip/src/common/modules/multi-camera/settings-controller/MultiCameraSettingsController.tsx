/*
 * Created on Fri Dec 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import sortBy from "lodash.sortby"
import { Button } from "semantic-ui-react"
import { useDispatch, useSelector } from "react-redux"
import styles from "./MultiCameraSettingsController.scss"
import en from "../../../../resources/translations/en-US"
import { IMultiCameraListItem, IStore } from "../../../../redux/interfaces/types"
import { updateConsoleSession } from "../../../../redux/actions/consoleActions"
import MultiCameraSettingsItem from "../settings-item/MultiCameraSettingsItem"
import { GLOBAL_LEFTSIDE_PANEL } from "../../../../redux/actions/types"
import { dispatchToParentStore } from "../../../../redux/store/externalAppStates"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"

const componentName = "MultiCameraSettingsController"

const MultiCameraSettingsController = () => {

    const {
        consoleSessions,
        displayLeftSidePanel,
        currentUserUuid,
    } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        displayLeftSidePanel: state.externalReducer.displayLeftSidePanel,
        currentUserUuid: state.externalReducer.currentUser.uuid,
    }))

    const [multiCameraStreams, setMultiCameraStreams] = useState([] as IMultiCameraListItem[])
    const [applySettingsLoader, setApplySettingsLoader] = useState(false)

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const getActiveMultiCameraStreamList = () => {
        const activeMultiCameraSession = consoleSessions.find((consoleSession) => consoleSession.multiCameraList.length > 0)
        return activeMultiCameraSession ? [...activeMultiCameraSession.multiCameraList] : []
    }

    useEffect(() => {
        if (displayLeftSidePanel) {
            const cameraList = getActiveMultiCameraStreamList()
            setMultiCameraStreams([...cameraList])
        }
    }, [displayLeftSidePanel])

    const sortedCameraStreamList = sortBy(multiCameraStreams, (cameras: any) => cameras.cameraStreamName)

    const getSelectedCameraCount = () => {
        return multiCameraStreams.filter((cameraStream) => cameraStream.selected).length
    }

    const handleApplyCameraSettings = () => {
        setApplySettingsLoader(true)
        const activeMultiCameraSession = consoleSessions.find((consoleSession) => consoleSession.multiCameraList.length)
        if (activeMultiCameraSession) {
            activeMultiCameraSession.multiCameraList = multiCameraStreams
            dispatch(updateConsoleSession({ ...activeMultiCameraSession }, true, false))
            dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: false,
                    activeLeftPanel: "",
                    desktopFullScreen: false,
                }
            })
            sendLogsToAzure({ contextData: { component: componentName, event: `${getSelectedCameraCount()} Cameras selected`, Event_By: currentUserUuid } })
        }
        setApplySettingsLoader(false)
    }

    const checkIfAtleastOneSelectedStream = () => {
        return !multiCameraStreams.some((cameraStream) => cameraStream.selected)
    }

    const selectCamera = (name: string, state: boolean) => {
        const index = multiCameraStreams.findIndex((camera: any) => camera.cameraStreamName === name)
        multiCameraStreams[index] = { ...multiCameraStreams[index], selected: state }
        const newCameraList = [...multiCameraStreams]
        setMultiCameraStreams(newCameraList)
    }

    return <div id={"multiCameraSettingsController"} className={styles.multiCameraSettingsController}>
        {
            sortedCameraStreamList.map((camera) =>
                <MultiCameraSettingsItem key={camera.cameraStreamName} cameraStreamItem={camera} selectCamera={selectCamera} />)
        }
        <Button
            className={styles.applyButton}
            onClick={() => handleApplyCameraSettings()}
            primary={true}
            disabled={checkIfAtleastOneSelectedStream()}
            loading={applySettingsLoader}
        >
            {intl.formatMessage({ id: "content.apply.btn", defaultMessage: en["content.apply.btn"] })}
        </Button>
    </div>
}

export default MultiCameraSettingsController
