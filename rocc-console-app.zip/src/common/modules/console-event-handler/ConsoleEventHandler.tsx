/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

<<<<<<< HEAD
import { EConnectionMode, EConnectionType, EOperationStatus, ETransactionStatus, IConsoleSession, TransactionValue } from "@rocc/rocc-client-services"
=======
import { EConnectionMode, EConnectionState, EConnectionType, EOperationStatus, ETransactionStatus, FeatureFlagHelper, getLocationDetailsForId, getRoomDetailFromUuid, IConsoleSession, ROCC_FEATURES, TransactionValue } from "@rocc/rocc-client-services"
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { setConsoleOperations } from "../../../redux/actions/consoleActions"
<<<<<<< HEAD
import { IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/translations/en-US"
import { disconnectConsoleService } from "../../../services/consoleService"
import { getConnectionAdapter } from "../../helpers/connection"
import {  handleAppUri } from "../../helpers/consoleUtility"
import { checkCallStatus, checkIfCallIsGoingOn, displayErrorModal, displayNotificationMessage, fetchActiveTransactionIndex, fetchTransactionForSpecificState, getAllActiveSessionsForConnectionMode } from "../../helpers/helpers"
=======
import { IConsoleTransaction, IStore } from "../../../redux/interfaces/types"
import { DEFAULT_CONSOLE_OPERATIONS } from "../../../redux/reducers/consoleReducer"
import { fetchLocations, fetchRooms } from "../../../redux/store/externalAppStates"
import en from "../../../resources/translations/en-US"
import { disconnectConsoleService, updateConsoleAuthorizationService } from "../../../services/consoleService"
import { API_TIMEOUT, INIT_MEDIA_ROOM_DETAILS } from "../../constants/constants"
import { checkIfPresignedJwtFeatureEnabled, consoleRequestTimeout, handleAppUri, handleConsoleSwitch, handleConsoleTransition, handleSuspendedStates } from "../../helpers/consoleUtility"
import { checkCallStatus, checkIfAnyActiveTransaction, checkIfCallIsGoingOn, checkIfOperationIsFailed, displayErrorModal, displayNotificationMessage, fetchActiveTransactionIndex, fetchCallContextForRoomUuid, fetchFirstWaitingTransactionIndex, fetchTransactionForSpecificState, fetchTransactionIndexById, fetchTransactionIndexForState, fetchTransactionIndexForStatus, getAllActiveSessionsForConnectionMode, getConsoleSessionByContextId, requestRejectModal } from "../../helpers/helpers"
import { transformSessionTypeForAnalytics } from "../../helpers/TelemetryTrackingHelper"
import { sendMessage } from "../consolemessages/messageService"
import { handleAuthorizationRequest } from "./authorizationTaskHandler"
import { handleCommandCenterConnection, handleConsoleDisconnection, handleConsoleDisconnectionAll, handleEmeraldConnection } from "./connectionTaskHandler"
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c

// const COMPONENT_NAME = "ConsoleEventHandler"

const ConsoleEventHandler = () => {

    const {
        currentUser,
        consoleSessions,
        consoleOperation,
        videoCallStatus,
        connectedCallDetails,
        featureFlags
    } = useSelector((state: IStore) => ({
        consoleOperation: state.consoleReducer.consoleOperation,
        currentUser: state.externalReducer.currentUser,
        seatName: state.consoleReducer.commandCenterDetails.commandCenterSeat.seatName,
        consoleSessions: state.consoleReducer.consoleSessions,
        videoCallStatus: state.externalReducer.callDetails.videoCallStatus,
        connectedCallDetails: state.externalReducer.callDetails.connectedCallDetails,
        featureFlags: state.externalReducer.featureFlags
    }))

    const dispatch = useDispatch()

    const [isCallWaitTransaction, setCallWaitTransaction] = useState(false)

    useEffect(() => {
        window.onbeforeunload = () => {
            const activeEmeraldSessions = getAllActiveSessionsForConnectionMode(consoleSessions, EConnectionMode.EMERALD)
            if (activeEmeraldSessions.length > 0) {
                handleAppUri({
                    roomUuid: "", connectionState: TransactionValue.STOP_ALL_EMERALD_APP, contextId: "",
                    consoleSessions: activeEmeraldSessions, accessToken: currentUser.accessToken
                })
                activeEmeraldSessions.forEach(async (session: IConsoleSession) => {
                    const { contextId, connectionMode } = session
                    const params = {
                        accessToken: currentUser.accessToken, contextId,
                        shouldUpdateForceDelete: true, connectionMode
                    }
                    await disconnectConsoleService(params)
                })
            }
        }
    }, [consoleSessions])

    useEffect(() => {
        const { transactions } = consoleOperation
        const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
        if (activeTransactionIndex > -1 && isCallWaitTransaction) {
            const callStatus = checkCallStatus(videoCallStatus, transactions[activeTransactionIndex].roomUuid)
            switch (callStatus) {
                case ETransactionStatus.STOP:
                case ETransactionStatus.FAILED:
                    transactions[activeTransactionIndex].transactionStatus = callStatus
                    consoleOperation.operationStatus = callStatus
                    dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
                    setCallWaitTransaction(false)
                    break
                case ETransactionStatus.FINISHED:
                    transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
                    dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
                    setCallWaitTransaction(false)
                    break
                default:
            }
        }
    }, [videoCallStatus])

    useEffect(() => {
        const { transactions } = consoleOperation
        const fullControlConsoleTransaction = fetchTransactionForSpecificState(transactions, TransactionValue.CONNECTING, EConnectionType.FULL_CONTROL)
        if (consoleOperation.operationStatus === EOperationStatus.RUNNING && fullControlConsoleTransaction) {
            if (!checkIfCallIsGoingOn(isCallWaitTransaction, transactions, fullControlConsoleTransaction.roomUuid)) {
                // Set transaction Status to failed
                dispatch(setConsoleOperations({ ...consoleOperation, operationStatus: EOperationStatus.FAILED, transactions: [...transactions] }))
            }
        }
    }, [consoleOperation, connectedCallDetails])
    

    useEffect(()=>{
        // Experimental
        getConnectionAdapter().onTransactionWaitStateChange = (state: boolean) =>{
            setCallWaitTransaction(state)
        }
    },[])


<<<<<<< HEAD
    useEffect(()=>{
        getConnectionAdapter().setOperation(consoleOperation)
        const { operationStatus, operationId } = consoleOperation
=======
        if (!contextId) {
            return ETransactionStatus.FAILED
        }

        const roomUuid = getConsoleSessionByContextId(contextId, consoleSessions)?.roomUuid

        if (!roomUuid) {
            return ETransactionStatus.FAILED
        }

        try {
            await sendMessage({
                userId: roomUuid,
                consoleData: {
                    contextId: contextId,
                    consoleStatus: EConnectionState.CONNECTED,
                }
            })

            return ETransactionStatus.FINISHED
        } catch (error) {
            return ETransactionStatus.FAILED
        }
    }

    const handleSwitchTransactionState = async (transaction: IConsoleTransaction) => {
        const { contextId, connectionType, connectionStatus } = transaction
        if (contextId) {
            const currentSession = consoleSessions.find(session => session.contextId === contextId)
            if (currentSession) {
                return await handleConsoleSwitch({
                    currentSession, newConnectionType: connectionType, accessToken: currentUser.accessToken, dispatch,
                    newConnectionStatus: connectionStatus === TransactionValue.PARKED ? EConnectionState.PARKED : EConnectionState.CONNECTED
                })
            }
        }
        infoLogger(`Failed to perform switch operation for transaction ${transaction.transactionId}`)
        return ETransactionStatus.FAILED
    }

    const handleEmeraldStopState = (transaction: IConsoleTransaction) => {
        /**
         * Check if there is any pending START_EMERALD_APP transaction
         * If yes, then mark this transaction as suspended and append START_EMERALD_APP transaction's groupIds with current transaction groupId
         * If no, then perform STOP_EMERALD_APP transaction
         */
        const { transactions, operationStatus } = consoleOperation
        const { roomUuid, connectionStatus, contextId } = transaction
        const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
        const startEmeraldIndex = fetchTransactionIndexForStatus(transactions, TransactionValue.START_EMERALD_APP, ETransactionStatus.WAITING)
        if (checkIfOperationIsFailed(operationStatus) || startEmeraldIndex > -1) {
            transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.SUSPENDED
            if (transactions[startEmeraldIndex].groupedTasks) {
                transactions[startEmeraldIndex].groupedTasks?.push(transactions[activeTransactionIndex].transactionId)
            } else {
                transactions[startEmeraldIndex].groupedTasks = [transactions[activeTransactionIndex].transactionId]
            }
            dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
        } else {
            handleAppUri({
                roomUuid, connectionState: connectionStatus, contextId,
                consoleSessions, accessToken: currentUser.accessToken
            })
            transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
            dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
        }
    }

    const handleEmeraldStopAllState = (transaction: IConsoleTransaction) => {
        const { roomUuid, connectionStatus, contextId } = transaction
        handleAppUri({
            roomUuid, connectionState: connectionStatus, contextId,
            consoleSessions, accessToken: currentUser.accessToken
        })
        return ETransactionStatus.FINISHED
    }

    const handleEmeraldStartState = (transaction: IConsoleTransaction) => {
        /**
         * Check if there is any groupedTask
         * if Yes, then fetch the data relevant to first groupTasks, use that as contextId and update connectionState to RESTART_EMERALD_APP
         * if No, then call handleAppUri
         */
        let connectionState: any = TransactionValue.START_EMERALD_APP
        const contextId = transaction.contextId
        const { transactions } = consoleOperation
        const activeTransactionIndex = fetchActiveTransactionIndex(transactions)
        let previousContextId: string | undefined = ""
        if (transaction.groupedTasks?.length) {
            connectionState = TransactionValue.RESTART_EMERALD_APP
            const suspendTransactionIndex = fetchTransactionIndexById(transactions, transaction.groupedTasks[0])
            if (suspendTransactionIndex > -1 && suspendTransactionIndex < transactions.length) {
                previousContextId = transactions[suspendTransactionIndex].contextId
                transactions[suspendTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
            }
        }
        transactions[activeTransactionIndex].transactionStatus = ETransactionStatus.FINISHED
        dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
        handleAppUri({
            roomUuid: transaction.roomUuid, connectionState, contextId,
            consoleSessions, accessToken: currentUser.accessToken
        }, previousContextId)

    }

    const handleDisconnectingTransactionState = async (transaction: IConsoleTransaction) => {
        const { connectionMode } = transaction
        const { CC, EMERALD, VNC } = EConnectionMode
        const props = { consoleSessions, consoleTransaction: transaction, dispatch, currentUser, seatName, componentName: COMPONENT_NAME }
        switch (connectionMode) {
            case CC:
            case EMERALD:
                return await handleConsoleDisconnection(props)
            case VNC:
                /** TODO: In future this connection mode may come */
                infoLogger("VNC connection mode is not handled by Rocc currently.")
                return ETransactionStatus.FAILED
            default:
                infoLogger("Requested connection mode is not handled by Rocc currently.")
                return ETransactionStatus.FAILED
        }
    }

    const handleDisconnectingAllTransactionState = async (transaction: IConsoleTransaction) => {
        return await handleConsoleDisconnectionAll({
            consoleSessions,
            consoleTransaction: transaction,
            dispatch,
            currentUser,
            seatName,
            componentName: COMPONENT_NAME
        })
    }

    const initiateAuthorizationRequest = async (transaction: IConsoleTransaction) => {
        setTimeout(() => {
            consoleRequestTimeout(consoleOperation.operationId, dispatch)
            sendLogsToAzure({ contextData: { component: COMPONENT_NAME, event: `${transformSessionTypeForAnalytics(transaction.connectionType)} request is timed out`, source: transformSessionTypeForAnalytics(transaction.connectionMode), Call_From: currentUser.uuid, Call_To: transaction.roomUuid } })
        }, API_TIMEOUT)
        infoLogger(`${transaction.connectionType} console request with contextId ${transaction.contextId} and 
        transactionId ${transaction.transactionId} for the roomUuid  ${transaction.roomUuid}  has been initiated`)
        return await handleAuthorizationRequest({ consoleTransaction: transaction, auth: !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_VIEW_AUTHORIZATION), currentUser, dispatch, seatName })
    }

    const initiateAuthorizationApprovalWait = () => {
        infoLogger(`Update approval state to ${ETransactionStatus.RUNNING} for OperationId ${consoleOperation.operationId}`)
        return ETransactionStatus.RUNNING
    }

    const handleAvCallWait = () => {
        infoLogger(`Wait for Call to establish then initiate console events for OperationId ${consoleOperation.operationId}`)
        setCallWaitTransaction(true)
        return ETransactionStatus.RUNNING
    }

    const handleUpdateSessionDetails = (transaction: IConsoleTransaction) => {
        const { receiverName, contextId = "", connectionMode, connectionType, roomUuid } = transaction
        const callContextId = fetchCallContextForRoomUuid(roomUuid)?.contextId
        const currentSession: IConsoleSession = {
            requester: currentUser.uuid, receiverName, contextId, connectionMode: connectionMode,
            connectionType, roomUuid, mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS, connectionStatus: EConnectionState.CONNECTED,
            displayCameraToggle: false, multiCameraList: [], consoleStartTime: new Date().toString(), additionalData: { callContextId }
        }
        handleConsoleTransition({ transactionStatus: TransactionValue.CONNECTING, dispatch, currentSession })
        return ETransactionStatus.FINISHED
    }
    const displayRejected = () => {
        const { intl } = getIntlProvider()
        const header = intl.formatMessage({ id: "content.consoleBanner.consoleRequestRejected", defaultMessage: en["content.consoleBanner.consoleRequestRejected"] })
        const content = ""
        const message = [{
            header: header, content: content
        }]
        const customStyle = { top: "1rem", right: "1rem", width: "28rem" }
        const roomDetails = fetchRoomDetails()
        const { VIEW } = EConnectionType
        consoleOperation.transactions[0].connectionType === VIEW ? requestRejectModal(roomDetails) : displayNotificationMessage(message, customStyle)
    }


    const taskExecutor = async (transaction: IConsoleTransaction) => {
        const { connectionStatus } = transaction

        const taskActions = {
            CONNECTING: handleConnectingTransactionState,
            DISCONNECTING: handleDisconnectingTransactionState,
            DISCONNECTING_ALL: handleDisconnectingAllTransactionState,
            PARKED: handleSwitchTransactionState,
            RESUMED: handleSwitchTransactionState,
            AUTHORIZATION_REQUEST: initiateAuthorizationRequest,
            AUTHORIZATION_APPROVAL_WAIT: initiateAuthorizationApprovalWait,
            AV_CALL_WAIT: handleAvCallWait,
            ASSOCIATE_COMPLETED: () => ETransactionStatus.RUNNING,
            START_EMERALD_APP: handleEmeraldStartState,
            STOP_EMERALD_APP: handleEmeraldStopState,
            STOP_ALL_EMERALD_APP: handleEmeraldStopAllState,
            RESTART_EMERALD_APP: handleEmeraldStartState,
            UPDATE_SESSION: handleUpdateSessionDetails,
            SEND_CONNECTED_MESSAGE: (checkIfPresignedJwtFeatureEnabled() ? sendConnectedMessageToDevice : () => {
                // TODO: [MARKER] Remove this conditional on merge to master
                throw new Error("Unsupported state reached. No action will be taken. ROCC_PRESIGNED_JWT flag needs to be enabled")
            }),
        }

        if (Object.prototype.hasOwnProperty.call(taskActions, connectionStatus)) {
            return await taskActions[connectionStatus](transaction)
        } else {
            return ETransactionStatus.FAILED
        }
    }

    const handleActiveOperationState = async () => {
        /**
         * 1. Check if there is any active(RUNNING) operation
         * 2. If no, then execute first available operation and update the status to RUNNING
         * 3. Once the operation is done successfully, update the transaction status to FINISHED
         * 4. If operation fails, then update the transaction and operation status to FAILED
         * 5. Display suitable error message and clear the operation details
         */
        const { transactions, operationId } = consoleOperation
        if (checkIfAnyActiveTransaction(transactions)) {
            infoLogger(`An active transaction is already in progress for operationId ${operationId}`)
            return
        }
        const transactionIndex = fetchFirstWaitingTransactionIndex(transactions)
        if (transactionIndex === -1) {
            infoLogger(`There are no waiting transactions, so either all transactions are completed or No transaction was provided for the operationId ${operationId}`)
            consoleOperation.operationStatus = EOperationStatus.FINISHED
            dispatch(setConsoleOperations({ ...consoleOperation }))
            return
        }
        transactions[transactionIndex].transactionStatus = ETransactionStatus.RUNNING
        dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
        const transactionStatus = await taskExecutor(transactions[transactionIndex])
        if (transactionStatus) {
            transactions[transactionIndex].transactionStatus = transactionStatus
            if (transactionStatus === ETransactionStatus.FAILED) {
                consoleOperation.operationStatus = EOperationStatus.FAILED
            }

            dispatch(setConsoleOperations({ ...consoleOperation, transactions: [...transactions] }))
        }
    }

    const handleCancelledConsoleOperation = async () => {
        /**
         * 1. Fetch Cancelled transaction
         * 2. Check if contextId is present if yes, then call canncel request
         * 3. If no, then wait for contextId and then perform the task
         */
        const { operationId } = consoleOperation
        const cancelledTransactionIndex = fetchTransactionIndexForState(consoleOperation.transactions, ETransactionStatus.CANCELLED)
        if (cancelledTransactionIndex < 0) {
            // Couldn't find cancelled transaction in the transaction list, setting the status back to FINISHED
            dispatch(setConsoleOperations({ ...consoleOperation, operationStatus: EOperationStatus.FINISHED }))
        }
        const cancelledTransaction = consoleOperation.transactions[cancelledTransactionIndex]
        if (cancelledTransaction.contextId) {
            // Perform Cancelled transaction steps
            await updateConsoleAuthorizationService({ contextId: cancelledTransaction.contextId, token: currentUser.accessToken, consoleStatus: ETransactionStatus.CANCELLED.toString() })
            const suspendedTransactions = consoleOperation.transactions.filter(transaction =>
                transaction.transactionStatus === ETransactionStatus.SUSPENDED && transaction.connectionStatus === TransactionValue.STOP_EMERALD_APP)
                .map(transaction => ({ ...transaction, transactionStatus: ETransactionStatus.WAITING }))
            handleConsoleTransition({ transactionStatus: ETransactionStatus.CANCELLED, dispatch, suspendedTransactions })
            sendLogsToAzure({ contextData: { component: COMPONENT_NAME, event: `${transformSessionTypeForAnalytics(cancelledTransaction.connectionType)} request is cancelled`, source: transformSessionTypeForAnalytics(cancelledTransaction.connectionMode), Call_From: currentUser.uuid, Call_To: cancelledTransaction.roomUuid } })
            infoLogger(`Console connection request for contextId ${cancelledTransaction.contextId} is cancelled for operationId ${operationId} for user ${currentUser.uuid}`)
        }
    }

    const fetchRoomDetails = () => {
        const rooms = fetchRooms()
        const locations = fetchLocations()
        const result = getRoomDetailFromUuid(rooms, consoleOperation.transactions[0].roomUuid)
        const roomDetails = {
            name: result.identity.name,
            address: result.address,
            location: getLocationDetailsForId(locations, result.locationId).name,
            modality: result.modality
        }

        return roomDetails
    }

    useEffect(() => {
        const { operationStatus, operationId, postTransactionHook } = consoleOperation
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
        const { intl } = getIntlProvider()
        switch (operationStatus) {
            case EOperationStatus.FAILED:   // Can be a candidate
                displayErrorModal()
                break
            case EOperationStatus.REJECTED:
                {
                    infoLogger(`OperationId ${operationId} is cancelled for user ${currentUser.uuid}`)
<<<<<<< HEAD
                    const header = intl.formatMessage({ id: "content.consoleBanner.consoleRequestRejected", defaultMessage: en["content.consoleBanner.consoleRequestRejected"] })
                    const content = ""
                    const message = [{
                        header: header, content: content
                    }]
                    const customStyle = { top: "1rem", right: "1rem", width: "28rem" }
                    displayNotificationMessage(message, customStyle)
=======
                    displayRejected()
                    handleSuspendedStates()
                    handleConsoleTransition({ transactionStatus: ETransactionStatus.REJECTED, dispatch })
                    postTransactionHook?.(false, EOperationStatus.REJECTED)
>>>>>>> ca3a0a9c558f599e2a5b94138de73fd97163c37c
                }
                break
            case EOperationStatus.TIMEOUT:
                {
                    infoLogger(`OperationId ${operationId} is timed out for user ${currentUser.uuid}`)
                    const content = intl.formatMessage({ id: "content.consoleMessages.connectionTimeout", defaultMessage: en["content.consoleMessages.connectionTimeout"] })
                    displayErrorModal(content, false)
                }
                break
            default:
                infoLogger(`Requested operation status ${operationStatus} is currently not supported by Rocc`)
                return
        }
    },[consoleOperation])

    return <></>
}

export default ConsoleEventHandler
