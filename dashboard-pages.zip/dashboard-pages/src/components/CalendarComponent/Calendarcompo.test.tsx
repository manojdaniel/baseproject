import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import "@testing-library/jest-dom/extend-expect";
import configureMockStore from "redux-mock-store";
import CalendarComponent from "./CalendarComponent";

const mockStore = configureMockStore();

describe("CalendarComponent", () => {
	let store;

	beforeEach(() => {
		store = mockStore({
			Common: {
				commonFromDate: "2022-01-01",
				commonToDate: "2022-01-31",
				commonFromDateFormat: "Jan-01-2022",
				commonToDateFormat: "Jan-31-2022",
				selectedBreadCrumbDate: "",
				todayDate: "",
			},
		});
	});

	it("renders the component with default props", () => {
		render(
			<Provider store={store}>
				<CalendarComponent />
			</Provider>
		);

		expect(screen.getByText("Today:")).toBeInTheDocument();
		expect(screen.getByText("Jan-01-2022")).toBeInTheDocument();
		expect(screen.getByText("Jan-31-2022")).toBeInTheDocument();
		expect(screen.getByText("1D")).toBeInTheDocument();
		expect(screen.getByText("1W")).toBeInTheDocument();
		expect(screen.getByText("1M")).toBeInTheDocument();
		expect(screen.getByText("3M")).toBeInTheDocument();
		expect(screen.getByText("1Y")).toBeInTheDocument();
		expect(screen.getByText("5Y")).toBeInTheDocument();
	});

	it("opens the calendar popup when clicking the customdate link", () => {
		render(
			<Provider store={store}>
				<CalendarComponent />
			</Provider>
		);

		fireEvent.click(screen.getByText("Today:"));
		expect(screen.getByText("Select Date Range")).toBeInTheDocument();
	});

	it("updates the selected bread crumb date when clicking a filter link", () => {
		render(
			<Provider store={store}>
				<CalendarComponent />
			</Provider>
		);

		fireEvent.click(screen.getByText("1M"));
		expect(store.getActions()).toEqual([
			{
				type: "Common/GET_BREADCRUMB_DATE",
				payload: { id: "1M", updatedDate: expect.any(Date) },
			},
			{
				type: "Common/GET_TODAY_DATE",
				payload: expect.any(Date),
			},
		]);
	});
});
