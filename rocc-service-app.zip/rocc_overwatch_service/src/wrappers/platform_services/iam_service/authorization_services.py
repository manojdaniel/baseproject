"""
 Created on Fri Sep 18 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json

import requests
from flask import jsonify, g

from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, ORG_CTXT_HEADER, PHILIPS_ROCC_URI, AUTHORIZATION
from src.loggers.log import create_logger

LOG = create_logger("Authorization service")


def evaluate_token(token, url, req, org_ctxt=None):
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    if org_ctxt:
        headers[ORG_CTXT_HEADER] = org_ctxt
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/authorize/evaluateToken",
                                 data=json.dumps({"host": req.url, "httpMethod": req.method}),
                                 headers=headers)
        LOG.debug(f"response: {response}")
        """ TODO: Need to add resource and permission policy, to enable evaluate properly """
        if response.status_code == 200:
            return True
        else:
            return jsonify({"error": "Evaluate token failed"}), 403

    except requests.exceptions.Timeout as ex:
        LOG.info(f"Request Timedout while evaluating token: {ex}")
    except requests.exceptions.TooManyRedirects as ex:
        LOG.info(f"Evaluate token failed with TooManyRedirects Exception: {ex}")
    except requests.exceptions.RequestException as ex:
        LOG.info(f"Evaluate token failed with RequestException Exception: {ex}")
    return None


def validate_token(token, url):
    headers = {CONTENT_TYPE: APPLICATION_JSON}
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/authorize/validate",
                                 data=json.dumps({"accessToken": token}),
                                 headers=headers)
        if response.status_code == 200 and response.json()["active"]:
            g.userdetails = response.json()["sub"] if response.json()["identity_type"] == "Service" else response.json()["userInstanceIdentity"]
            LOG.info("Validation of token passed!")
            return None
        else:
            LOG.error("Validation of token failed!")
            return jsonify({"error": "Validation of token failed!"}), 401
    except requests.exceptions.Timeout as ex:
        LOG.error(f"Request Timedout while validating token: {ex}")
    except requests.exceptions.TooManyRedirects as ex:
        LOG.error(f"Validate token failed with TooManyRedirects Exception: {ex}")
    except requests.exceptions.RequestException as ex:
        LOG.error(f"Validate token failed with RequestException Exception: {ex}")
    except Exception as ex:
        LOG.error(f"Validate token failed with General Exception: {ex}")
    return None


def create_allowed_org_mapping(token, url, org_id, use_org_context=False):
    headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    if use_org_context:
        headers[ORG_CTXT_HEADER] = str({"Org-Id": org_id})
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/authorize/AllowedOrg",
                                 data=json.dumps({"identityOrgId": org_id, "instanceId": org_id}),
                                 headers=headers)
        if response.status_code == 201:
            LOG.info("Successfully created AllowedOrg mapping")
            return True
        else:
            LOG.error(f"Failed to create AllowedOrg mapping: {response}")
            return False

    except Exception as ex:
        LOG.error(f"Error while creating AllowedOrg mapping. Error {ex}")
    return None
