"""
 Created on Mon Sep 21 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import ast
from flask import request, g
from flask_restful import Resource, reqparse
from src.services.scanner_services import ScannerDetailsService

from src.constants.constants import API_VERSION, AUTHORIZATION, HELP_MESSAGE
from src.loggers.log import create_logger
from src.services.scanner_services import ScannerService
from src.utility.semver import parse_version
from src.utility.utility import construct_negative_response

LOG = create_logger("Scanner controller")


class Scanner(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("modality", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("location", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("short_name", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("display_name", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("transmitters", action="append", required=True, help=HELP_MESSAGE)
    parser.add_argument("primary_phone", type=str, required=True, help=HELP_MESSAGE)
    parser.add_argument("secondary_phone", type=str, required=False)
    parser.add_argument("manufacturer", type=str, required=False)
    parser.add_argument("model", type=str, required=False)
    parser.add_argument("serial_number", type=str, required=False)
    parser.add_argument("dicom_ae_title", type=str, required=False)
    parser.add_argument("software_version", type=str, required=False)
    parser.add_argument("os_type", type=str, required=False)
    parser.add_argument("os_version", type=str, required=False)
    parser.add_argument("notes", type=str, required=False)
    parser.add_argument("nccEdit", type=bool, required=False)
    parser.add_argument("start_date", type=str, required=False)
    parser.add_argument("end_date", type=str, required=False)
    parser.add_argument("modality_connection", action="append", required=False, help=HELP_MESSAGE)
    parser.add_argument("isPharmaEnabled", type=bool, required=False)

    def post(self, customer_id, site_id):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for Scanner onboarding is: {api_version}")
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        user_token = request.headers[AUTHORIZATION]
        request_data = self.parser.parse_args()
        if request_data["modality_connection"]:
            request_data["modality_connection"] = [ast.literal_eval(data) for data in
                                                   request_data["modality_connection"]]
        LOG.info(f"Hospital/DIC - Scanner: {request_data} onboarding initiated")
        service = ScannerService(g.userdetails, customer_id, user_token)
        service.create_scanner_tablet_transmitters_mapping(site_id, request_data)
        return {"message": f"Scanner with short_name {request_data['short_name']} created successfully."}, 200

    def put(self, customer_id, site_id, scanner_id):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400
        user_token = request.headers[AUTHORIZATION]
        request_data = Scanner.parser.parse_args()
        if request_data["modality_connection"]:
            request_data["modality_connection"] = [ast.literal_eval(data) for data in
                                                   request_data["modality_connection"]]
        service = ScannerService(service_user_uuid=g.userdetails, customer_id=customer_id, user_token=user_token)
        return service.update_scanner_transmitter_mapping(scanner_details=request_data, scanner_id=scanner_id,
                                                          site_id=site_id), 200


class ScannerOffboard(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("room_identifier", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("site_identifier", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("customer_identifier", type=str, required=True, help="This field cannot be left blank!")

    def delete(self):
        try:
            api_version = request.headers[API_VERSION]
            LOG.info(f"API version for Scanner offboarding is: {api_version}")
            """ TODO: Need to evaluate the token """
        except KeyError:
            return {"message": f"{API_VERSION} header is needed to process this request"}, 400
        body = ScannerOffboard.parser.parse_args()
        LOG.info(f"Hospital/DIC - Scanner: {body} offboarding initiated")
        """ TODO: Scanner offboarding process initiation """
        return {"message": "Scanner offboarding is initiated", "job_identifier": "1234"}, 202


class ScannerDetails(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("device_name", type=str, required=True, help=HELP_MESSAGE)

    def get(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is required to process this request."), 400

        request_data = ScannerDetails.parser.parse_args()
        service = ScannerDetailsService()
        return service.get_device_details_by_scanner_identifier(scanner_identifier=request_data["device_name"])
