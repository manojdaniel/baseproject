/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useState } from "react"
import { attachTrack, detachTracks } from "../../../common/helpers/multiCameraUtility"
import { RoomMonitoringExpandHeader, RoomMonitoringItem } from "@rocc/rocc-console-components"
import { ERoomMoinitorRenderState, IConsoleSession } from "@rocc/rocc-client-services"
import { IMultiCamVideoTrack } from "../../../common/modules/multi-camera/MultiCameraTypes"
import styles from "./RoomMonitoringFullscreen.scss"
import { getRoomDetails } from "../../../common/helpers/helpers"
import { IReceiver, IStore } from "../../../redux/interfaces/types"
import { useSelector } from "react-redux"
import cx from "classnames"
import { infoLogger } from "@rocc/rocc-logging-module"

interface IRoomMonitoringFullscreen {
    consoleSession: IConsoleSession
    videoTrackItem: IMultiCamVideoTrack | any
    handlefullscreenClick: (trackName: string) => void
    rightSidePanel?: boolean
}

const RoomMonitoringFullscreen = ({
    videoTrackItem, consoleSession, rightSidePanel, handlefullscreenClick
}: IRoomMonitoringFullscreen) => {

    const { receivers } = useSelector((state: IStore) => ({
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
    }))

    const { RENDER_VIDEO } = ERoomMoinitorRenderState
    const [renderStatus, setRenderStatus] = useState(RENDER_VIDEO)
    const { videoTrack, fullScreen } = videoTrackItem

    const sessionInfo = {
        isSessionGoingOn: true,
        connectionType: consoleSession.connectionType,
        roomModality: getRoomDetails(consoleSession).modality,
        roomName: getRoomDetails(consoleSession).name,
        roomLocation: getRoomDetails(consoleSession).location,
        roomDepartment: getRoomDetails(consoleSession).address
    }

    const consoleMonitorName = receivers.find((receiver: IReceiver) => receiver.receiverName === consoleSession.receiverName)?.monitorName

    const singleRecieverView = receivers.length === 1

    const handleVideoStart = () => {
        setRenderStatus(RENDER_VIDEO)
    }

    const getFullScreenHeight = singleRecieverView ? styles.singleReceiverHeight : styles.multiReceiverHeight
    const getFullScreenWidth = rightSidePanel ? styles.narrowWidth : styles.wideWidth

    return <div className={cx(getFullScreenHeight, getFullScreenWidth, styles.roomMonitoringFullscreen)} id="roomMonitoringFullscreen">
        {!singleRecieverView && <div className={styles.fullscreenHeader}>
            <RoomMonitoringExpandHeader
                sessionInfo={sessionInfo}
                receiverName={consoleMonitorName ?? ""}
            />
        </div>}
        <div className={cx(styles.fullscreenBody, singleRecieverView ? styles.singleRecieverfullscreen : styles.multiRecieverfullscreen)}>
            <RoomMonitoringItem
                cameraName={videoTrack ? videoTrack.name.replace(":", "") : ""}
                videoTrackItem={videoTrackItem}
                message={""}
                cameraState={true}
                fullscreenState={fullScreen}
                hideFullscreenControl={false}
                hideCameraControl={true}
                renderState={renderStatus}
                currentUserUuid={consoleSession.requester}
                consoleContextId={consoleSession.contextId}
                infoLogger={infoLogger}
                onFullScreenClick={handlefullscreenClick}
                onVideoStart={handleVideoStart}
                attachTrack={attachTrack}
                detachTracks={detachTracks}
            
            />
        </div>
    </div>
}

export default RoomMonitoringFullscreen
