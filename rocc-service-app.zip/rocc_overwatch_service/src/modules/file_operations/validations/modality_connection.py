"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import itertools
from operator import itemgetter
from xlrd.timemachine import xrange

from src.constants.headers import EXCEL_MOD_CONN_IP, EXCEL_MOD_CONN_PRIORITY, EXCEL_MOD_CONN_CONNECTION_MODE, EXCEL_MOD_CONN_ROOM_IDENTIFIER, EXCEL_MOD_CONN_USERNAME, EXCEL_ROOM_MODALITY_CONNECTION
from src.loggers.log import create_logger
from src.utility.utility import check_ip_format
from src.constants.enums import EConnectionMode
from src.constants.constants import CONNECTION_IP, CONNECTION_PRIORITY, CONNECTION_MODE, CONNECTION_USERNAME, CONNECTION_PROPERTIES, PRIORITIES, ROOMS_DICT, MODALITY_DICT

LOG = create_logger("ModalityConnectionSheetReader")


def modality_connection_sheet(book, sheet_name, errors):
    """
    Reading the Modality Connection sheet rows.
    Checking mandatory columns in Modality Connection sheet, if column is not present the respective errors is captured.
    """
    try:
        sheet = book.sheet_by_name(sheet_name)
        keys = [sheet.cell(0, col_index).value for col_index in xrange(sheet.ncols)]
        modality_data_list = []
        if sheet.nrows > 1:
            mandatory_columns = [EXCEL_MOD_CONN_IP, EXCEL_MOD_CONN_PRIORITY, EXCEL_MOD_CONN_CONNECTION_MODE, EXCEL_MOD_CONN_ROOM_IDENTIFIER, EXCEL_MOD_CONN_USERNAME]
            excel_data = [keys[col_index] for col_index in xrange(sheet.ncols)]
            difference_column = list(set(mandatory_columns) - set(excel_data))
            if len(difference_column) > 0:
                errors.append(f"Mandatory columns {difference_column} is not in modality_connection sheet")
            grouped_modality_data, errors = validating_modality_connection_rows(keys, sheet, modality_data_list, errors)
            validated_modality_dict, errors = validate_grouped_modality_connection(grouped_modality_data, errors)
            return validated_modality_dict, errors
        else:
            return {}, []
    except Exception as ex:
        LOG.exception(f"Exception occurred while reading modality connection sheet: {ex}")


def validating_modality_connection_rows(keys, sheet, modality_data_list, errors):
    """
    Validating Ip_address, Priority and Properties in Modality Connection sheet(rows, columns)
    """
    try:
        for row_index in xrange(1, sheet.nrows):
            errors = validate_modality_connection_ip_and_priority(keys, sheet, row_index, errors)
            modality_data_list = adding_extra_columns_to_properties(keys, sheet, row_index, modality_data_list)
        modality_data_list = sorted(modality_data_list, key=itemgetter(EXCEL_MOD_CONN_ROOM_IDENTIFIER))
        meta_sites = sorted(modality_data_list, key=itemgetter(EXCEL_MOD_CONN_ROOM_IDENTIFIER))
        return appending_modality_connection_rows(meta_sites, errors)
    except Exception as ex:
        LOG.exception(f"Exception occurred while validating modality connection rows: {ex}")


def validate_modality_connection_ip_and_priority(keys, sheet, row_index, errors):
    """
    Validating IP_address format and Priority in Modality Connection sheet
    """
    try:
        excel_data = {keys[col_index]: sheet.cell(row_index, col_index).value
                      for col_index in xrange(sheet.ncols)}
        if excel_data[EXCEL_MOD_CONN_CONNECTION_MODE] == EConnectionMode.VNC.value or excel_data[EXCEL_MOD_CONN_CONNECTION_MODE] == EConnectionMode.RDP.value:
            ip_addr = check_ip_format(str(excel_data[EXCEL_MOD_CONN_IP]))
            if excel_data[EXCEL_MOD_CONN_IP] == "" or not ip_addr:
                errors.append(f"IP field is incorrect for room {excel_data[EXCEL_MOD_CONN_ROOM_IDENTIFIER]}")
        if excel_data[EXCEL_MOD_CONN_PRIORITY] not in PRIORITIES:
            errors.append(f"Priority value is incorrect for room {excel_data[EXCEL_MOD_CONN_ROOM_IDENTIFIER]}")
        expected_connection_modes = [types.value for types in EConnectionMode]
        if excel_data[EXCEL_MOD_CONN_CONNECTION_MODE] not in expected_connection_modes:
            errors.append(f"Connection type is wrong for room {excel_data[EXCEL_MOD_CONN_ROOM_IDENTIFIER]}")
        return errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while validating the IP field and priority in modality_connection sheet: {ex}")


def adding_extra_columns_to_properties(keys, sheet, row_index, modality_data_list):
    """
    Adding additional columns as Properties(key and value pairs) in Modality Connection sheet
    """
    try:
        excel_data = {keys[col_index]: sheet.cell(row_index, col_index).value
                      for col_index in xrange(sheet.ncols)}
        extra_columns = dict(list(excel_data.items())[5:])
        excel_data[CONNECTION_PROPERTIES] = extra_columns
        for key in list(extra_columns.keys()):
            excel_data.pop(key)
        modality_data_list.append(excel_data)
        return modality_data_list
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding additional columns as Properties in modality_connection sheet: {ex}")


def appending_modality_connection_rows(meta_sites, errors):
    """
    Appending Modality connection rows as values to room identifier
    """
    try:
        modality_row_data = []
        priority_values = [0, 1, 2]
        priority_dictionary = dict(zip(PRIORITIES, priority_values))
        for key, value in itertools.groupby(meta_sites, key=itemgetter(EXCEL_MOD_CONN_ROOM_IDENTIFIER)):
            for i in value:
                modality_row_data.append({key: [{CONNECTION_IP: i.get(EXCEL_MOD_CONN_IP), CONNECTION_PRIORITY: priority_dictionary[i.get(EXCEL_MOD_CONN_PRIORITY)],
                                          CONNECTION_MODE: i.get(EXCEL_MOD_CONN_CONNECTION_MODE),
                                          CONNECTION_USERNAME: i.get(EXCEL_MOD_CONN_USERNAME), CONNECTION_PROPERTIES: i.get(CONNECTION_PROPERTIES)}]})
        grouped_modality_dict, errors = group_modality_rows(modality_row_data, errors)
        return grouped_modality_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while grouping modality connection rows: {ex}")


def group_modality_rows(modality_row_data, errors):
    """
    Calling function to group Modality connection rows based on room identifier
    """
    try:
        grouped_modality_dict = {}
        for room_identifier in modality_row_data:
            for value in room_identifier:
                grouped_modality_dict, errors = grouped_rows(grouped_modality_dict, room_identifier, value, errors)
        return grouped_modality_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while grouping modality connection rows: {ex}")


def grouped_rows(grouped_modality_dict, room_identifier, value, errors):
    """
    Grouping Modality connection rows based on room identifier
    """
    try:
        if value in grouped_modality_dict:
            room_identifier[value], errors = checking_connection_mode_and_priority(room_identifier, grouped_modality_dict, value, errors)
            if room_identifier[value]:
                grouped_modality_dict[value] += (room_identifier[value])
        else:
            grouped_modality_dict[value] = room_identifier[value]
        return grouped_modality_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while grouping modality connection rows: {ex}")


def checking_connection_mode_and_priority(room_identifier, grouped_modality_dict, room_name, errors):
    """
    Calling function to validate connection type and priority for room identifier
    """
    try:
        for existing_row in grouped_modality_dict[room_name]:
            for new_row in room_identifier[room_name]:
                room_identifier[room_name], errors = validated_connection_mode_and_priority(room_identifier, existing_row, new_row, room_name, errors)
            return room_identifier[room_name], errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while checking connection type and priority: {ex}")


def validated_connection_mode_and_priority(room_identifier, existing_row, new_row, room_name, errors):
    """
    Checking connection type and priority for room identifier, if duplicate data exists then errors are captured
    """
    try:
        if existing_row[CONNECTION_MODE] == new_row[CONNECTION_MODE]:
            errors.append(f"Duplicate connection type exists for room {room_name}")
        if existing_row[CONNECTION_PRIORITY] == new_row[CONNECTION_PRIORITY]:
            errors.append(f"Duplicate Priority exists for room {room_name}")
        elif existing_row[CONNECTION_MODE] == new_row[CONNECTION_MODE] and existing_row[CONNECTION_PRIORITY] == new_row[CONNECTION_PRIORITY] and existing_row[CONNECTION_IP] == new_row[CONNECTION_IP]:
            LOG.exception(f"Duplicate row exists for room {room_name}")
        else:
            return room_identifier[room_name], errors
        return {}, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while validating connection type and priority: {ex}")


def add_default_connections(grouped_modality_dict, errors):
    """
    Adding default connection types to grouped dictionary
    """
    try:
        default_modality_conn = {EXCEL_ROOM_MODALITY_CONNECTION: [{CONNECTION_IP: "",CONNECTION_PRIORITY: 0, CONNECTION_MODE: EConnectionMode.KVM.value, CONNECTION_USERNAME: "", CONNECTION_PROPERTIES: {}}]}
        for value in grouped_modality_dict.values():
            for data in default_modality_conn[EXCEL_ROOM_MODALITY_CONNECTION]:
                present_dict = {(d[CONNECTION_MODE]) for d in value}
                if (data[CONNECTION_MODE]) not in present_dict:
                    value.append(data)
        return grouped_modality_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding default connection types to grouped dictionary: {ex}")


def validate_grouped_modality_connection(grouped_modality_dict, errors):
    """
    Reading and validating the priority for connection type
    """
    try:
        hardware_connection_modes = [EConnectionMode.KVM.value]
        properties = [0, 1, 2]
        for value in grouped_modality_dict.values():
            value = get_types_and_priority_list(value, properties, hardware_connection_modes)
            empty_data = [data for data in value if data[CONNECTION_PRIORITY] == ""]
            if len(empty_data) > 0:
                empty_data, diff_priority = assign_values_to_empty_priority(value, empty_data, PRIORITIES, hardware_connection_modes)
                for index, data in enumerate(empty_data):
                    data[CONNECTION_PRIORITY] = diff_priority[index]
        return grouped_modality_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while reading and validating the priority for connection type: {ex}")


def get_types_and_priority_list(value, priority_list, types):
    """
    Getting the connection types and priority difference lists
    """
    try:
        present_dict = {(d[CONNECTION_MODE]) for d in value}
        priority_dict = [(d[CONNECTION_PRIORITY]) for d in value if d[CONNECTION_PRIORITY] != ""]
        diff_types = list(set(types) - set(present_dict))
        diff_priority = list(set(priority_list) - set(priority_dict))
        if len(diff_types) > 1:
            diff_types.sort()
            value = append_connection_mode(value, diff_priority, diff_types)
        else:
            value = append_connection_mode(value, diff_priority, diff_types)
        return value
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding default connection types to grouped dictionary: {ex}")


def append_connection_mode(value, diff_priority, diff_types):
    """
    Appending default connection types and priority to modality dictionary
    """
    try:
        for (pri, conn_type) in zip(diff_priority, diff_types):
            value.append({CONNECTION_IP: "", CONNECTION_PRIORITY: pri, CONNECTION_MODE: conn_type, CONNECTION_USERNAME: "", CONNECTION_PROPERTIES: {}})
        return value
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding default connection types dictionary: {ex}")


def assign_values_to_empty_priority(value, empty_data, priority_list, types):
    """
    Adding values to empty priority
    """
    try:
        priority_dict = [(d[CONNECTION_PRIORITY]) for d in value if d[CONNECTION_PRIORITY] != ""]
        diff_priority = list(set(priority_list) - set(priority_dict))
        present_dict = {(d[CONNECTION_MODE]) for d in empty_data}
        diff_types = list(set(types) - set(present_dict))
        if "" in diff_priority:
            diff_priority.remove("")
        if len(diff_types) >= 1:
            for data in empty_data:
                data.update({CONNECTION_PRIORITY: min(diff_priority)})
        return empty_data, diff_priority
    except Exception as ex:
        LOG.exception(f"Exception occurred while adding default connection types dictionary: {ex}")


def append_modality_connection_to_room_dict(modality_dict, data_dict, errors):
    """
    Appending Modality_connection key to room_dict
    """
    try:
        default_modality_dict = {EXCEL_ROOM_MODALITY_CONNECTION: [
            {CONNECTION_IP: "", CONNECTION_PRIORITY: 0, CONNECTION_MODE: EConnectionMode.KVM.value,
             CONNECTION_USERNAME: "", CONNECTION_PROPERTIES: {}}]}
        if modality_dict:
            validated_rooms_dict, errors = validate_room_identifier(modality_dict, default_modality_dict, data_dict[ROOMS_DICT], errors)
        else:
            validated_rooms_dict = assign_default_modality_connection_data(default_modality_dict, data_dict[ROOMS_DICT])
        data_dict[ROOMS_DICT] = validated_rooms_dict
        data_dict[MODALITY_DICT] = modality_dict
        return data_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while appending Modality_connection key to room_dict: {ex}")


def assign_default_modality_connection_data(default_modality_dict, rooms_dict):
    """
    If Modality Connection data not present, assigning default modality_connection values for room_identifier
    """
    try:
        for room_key in rooms_dict.items():
            rooms_dict[room_key[0]].update({EXCEL_ROOM_MODALITY_CONNECTION: default_modality_dict})
        return rooms_dict
    except Exception as ex:
        LOG.exception(f"Exception occurred while assigning default modality_connection values for room_identifier: {ex}")


def validate_room_identifier(modality_dict, default_modality_dict, rooms_dict, errors):
    """
    Validating Room identifier in Modality Connection sheet
    """
    try:
        validated_rooms_dict, errors = append_modality_to_rooms(modality_dict, default_modality_dict, rooms_dict, errors)
        if not validated_rooms_dict:
            errors.append("Room not exists in Scanner Details table")
        return validated_rooms_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while validating Room identifier in Modality Connection sheet: {ex}")


def add_default_modality_conn(rooms_dict, not_common_room, default_modality_dict):
    """
    Appending a default modality connection value for a room identifier when one is missing from the Modality Connection sheet
    """
    try:
        if not_common_room:
            for room_key in not_common_room:
                rooms_dict[room_key].update({EXCEL_ROOM_MODALITY_CONNECTION: default_modality_dict})
        return rooms_dict
    except Exception as ex:
        LOG.exception(f"Exception occurred while appending default modality_connection: {ex}")


def append_modality_to_rooms(modality_dict, default_modality_dict, rooms_dict, errors):
    """
    Appending modality_connection to room_dict
    """
    try:
        room_list = list(rooms_dict.keys())
        modality_list = list(modality_dict.keys())
        not_common_room = list(set(room_list) - set(modality_list))
        rooms_dict = add_default_modality_conn(rooms_dict, not_common_room, default_modality_dict)
        for modality_key, modality_value in modality_dict.items():
            if modality_key in room_list:
                rooms_dict[modality_key].update({EXCEL_ROOM_MODALITY_CONNECTION: modality_value})
            else:
                errors.append(f"Room {modality_key} not exists in Scanner Details table")
        return rooms_dict, errors
    except Exception as ex:
        LOG.exception(f"Exception occurred while appending modality column to room_dict: {ex}")
