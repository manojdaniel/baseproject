/*
 * Created on Mon July 27 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import { ExampleFileupload } from "./FileUpload"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        version: "",
    })
}))

describe("Upload component", () => {
    let wrapper: any
    let props: any
    beforeEach(() => {
        props = {
            fileObject: null,
            handleFileSelect: () => { },
            uploadFormat: ".xlsx",
            deleteUploadedFile: jest.fn(),
            errorMessage: ""
        }
        wrapper = shallow(<ExampleFileupload {...props} />)
    })
    it("should render Modal", () => {
        expect(wrapper).toHaveLength(1)
    })
    it("should render Modal with success", () => {
        props = {
            fileObject: { name: "bulk-upload", size: 10 },
            handleFileSelect: () => { },
            uploadFormat: "SUCCESS",
            deleteUploadedFile: jest.fn(),
            errorMessage: ""
        }
        wrapper = shallow(<ExampleFileupload {...props} />)
        expect(wrapper.find("#file")).toHaveLength(1)
    })

    it("should render Modal with LOADING", () => {
        props = {
            fileObject: { name: "bulk-upload", size: 100000 },
            handleFileSelect: () => { },
            uploadFormat: "LOADING",
            deleteUploadedFile: jest.fn(),
            errorMessage: ""
        }
        wrapper = shallow(<ExampleFileupload {...props} />)
        expect(wrapper.find("#file")).toHaveLength(1)
    })


    it("should render Modal with FAILED", () => {
        props = {
            fileObject: { name: "bulk-upload", size: 0 },
            handleFileSelect: () => { },
            uploadFormat: "FAILED",
            deleteUploadedFile: jest.fn(),
            errorMessage: "error found in excel"
        }
        wrapper = shallow(<ExampleFileupload {...props} />)
        expect(wrapper).toHaveLength(1)
    })


})
