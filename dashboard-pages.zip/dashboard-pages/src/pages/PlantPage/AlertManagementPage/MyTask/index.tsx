import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
	getMyTaskTable,
	setRefreshMyTaskPage,
} from "../../../../redux/reducers/CommonReducer";
import MyTaskTable from "table/MyTaskTable";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { encryptRSAData } from "../../../../utility/rsa";
import Workflow from "../Workflow";

interface Props {
	buttonName: string;
	onClickHandler: any;
}
const MyTask = () => {
	let dispatch = useDispatch();
	let navigate = useNavigate();
	const location = useLocation();
	const [query, setquery] = useState("");
	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>([]);

	const [showWorkflow, setShowWorkflow] = useState<boolean>(false);
	const [alertId, setAlertId] = useState<any>("");
	const [currentStage, setCurrentStage] = useState<any>("");

	const { myTaskTable, refreshMyTaskPage,
		loadingMyTaskTable } = useSelector((state: any) => ({
			myTaskTable: state.Common.myTaskTable,
			refreshMyTaskPage: state.Common.refreshMyTaskPage,

			loadingMyTaskTable: state.Common.loadingMyTaskTable,
		}));

	useEffect(() => {
		dispatch(getMyTaskTable(""));
	}, []);
	//encryptRSAData(`
	useEffect(() => {
		if (myTaskTable.length > 0) {
			setParentData(myTaskTable);
			setData(myTaskTable);
		}
	}, [myTaskTable]);

	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9- ]+$/i.test(keyValue)) event.preventDefault();
	};

	const handleChange = (e: any) => {
		const results = parentData.filter((item: any) => {
			if (e.target.value === "") return item;
			if (
				item.alertId
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.affiliate
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.plant
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			if (
				item.assetId
					.toString()
					.toLowerCase()
					.includes(e.target.value.toLowerCase())
			) {
				return item;
			}
			// return item.AlertID.toString().toLowerCase().includes(e.target.value.toLowerCase())
		});
		setquery(e.target.value);
		setData(results);
	};

	const onClickWorkFlowPage = (alertId: any, currentStage: string) => {
		// setAlertId(alertId)
		// setCurrentStage(currentStage)
		// setShowWorkflow(true)

		setShowWorkflow(true);
		if (location.pathname === "/ampMyTask") {
			navigate(`/ampMyTask/workFlow`, {
				state: {
					alertId: alertId,
					currentStage: currentStage,
					pageName: "myTask",
				},
			});
		} else {
			navigate(`/plant/alertManagementPage/ampMyTask/workFlow`, {
				state: {
					alertId: alertId,
					currentStage: currentStage,
					pageName: "myTask",
				},
			});
		}
	};

	useEffect(() => {
		try {
			if (
				location.pathname === "/plant/alertManagementPage/ampMyTask" ||
				location.pathname === "/ampMyTask"
			) {
				setShowWorkflow(false);
				if (refreshMyTaskPage) {
					dispatch(getMyTaskTable(""));
					dispatch(setRefreshMyTaskPage(false));
				}
			}
		} catch (error) { }
	}, [location]);

	return (
		<div id="mytasks">
			{!showWorkflow ? (
				<div className="common-box-inner">
					<div id="new-filter" className="mt0">
						<div className="nf-left">
							<div className="title">MY WORKLIST</div>
						</div>
						<div className="nf-right">
							<div className="rightsearch">
								<input
									type="search"
									value={query}
									onChange={handleChange}
									placeholder="Search..."
									onKeyPress={handleKeyPress}
									onPaste={handleKeyPress}
								/>
							</div>
						</div>
					</div>
					<div className="common-box-content">
						<MyTaskTable
							data={data}
							onClickWorkFlowPage={onClickWorkFlowPage}
							loading={loadingMyTaskTable}
						/>
					</div>
				</div>
			) : (
				<>
					{/* <Workflow
                        alertId={alertId}
                        currentStage={currentStage}
                        setShowWorkflow={setShowWorkflow}
                    /> */}
					<Outlet />
				</>
			)}
		</div>
	);
};
export default MyTask;
