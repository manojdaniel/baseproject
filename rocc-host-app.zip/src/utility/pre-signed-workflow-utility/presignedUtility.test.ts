/*
 * Created on Tue Aug 2 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EPresignedStatus } from "@rocc/rocc-client-services"
import { addOrUpdatePresignedWorkflow, computeMessageAndStatusBasedOnVerification, computePresignedErrorIfAny, updatePresignedWorkflowStatus } from "./presignedUtility"

const mockPresignedData = {
    id: "id",
    resourceId: "",
    startTime: "",
    expiryTime: "",
    hashCode: "",
    subject: "CONSOLE",
    status: EPresignedStatus.NOT_STARTED_YET,
    additionalAttributes: {}
}

const mockResponse = (httpStatusCode: number, customStatusCode: number = 410) => ({
    status: httpStatusCode,
    data: {
        statusCode: customStatusCode
    }
})

describe("Presigned Utility functions", () => {
    it("add new presigned workflow tests", () => {
        expect(addOrUpdatePresignedWorkflow([], mockPresignedData).length).toBe(1)
    })

    it("update existing presigned workflow tests", () => {
        expect(addOrUpdatePresignedWorkflow([mockPresignedData], mockPresignedData).length).toBe(1)
    })

    it("update existing presigned workflow status tests", () => {
        expect(updatePresignedWorkflowStatus([mockPresignedData], "id", EPresignedStatus.VALID).length).toBe(1)
    })
    it("computePresignedErrorIfAny negative test", () => {
        expect(computePresignedErrorIfAny([mockPresignedData]).length).toBeGreaterThan(1)
    })
    it("computePresignedErrorIfAny postive test", () => {
        mockPresignedData.status = EPresignedStatus.VALID
        expect(computePresignedErrorIfAny([mockPresignedData]).length).toBe(0)
    })
    it("computeMessageAndStatusBasedOnVerification 200 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(200)).presignedInitialStatus).toBe(EPresignedStatus.VALID)
    })
    it("computeMessageAndStatusBasedOnVerification 206 - 410 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(206, 410)).presignedInitialStatus).toBe(EPresignedStatus.EXPIRED)
    })
    it("computeMessageAndStatusBasedOnVerification 206 - 425 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(206, 425)).presignedInitialStatus).toBe(EPresignedStatus.NOT_STARTED_YET)
    })
    it("computeMessageAndStatusBasedOnVerification 403 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(403)).presignedInitialStatus).toBe(EPresignedStatus.FORBIDDEN)
    })
    it("computeMessageAndStatusBasedOnVerification 401 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(401)).presignedInitialStatus).toBe(EPresignedStatus.REVOKED)
    })
    it("computeMessageAndStatusBasedOnVerification 400 test", () => {
        expect(computeMessageAndStatusBasedOnVerification(mockResponse(400)).presignedInitialStatus).toBe(EPresignedStatus.FAILED)
    })
})
