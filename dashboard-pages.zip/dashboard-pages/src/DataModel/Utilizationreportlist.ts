export const utilizationReportData = [
  {
    "affiliate": "ARRAZI",
    "plant": "ARRAZI-V",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "IBNSINA",
    "plant": "MEOH",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "KAYAN",
    "plant": "OLEFINS",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "KEMYA",
    "plant": "KOP",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "SHARQ",
    "plant": "OLEFIN",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "UNITED",
    "plant": "ETHYLENE",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANPET",
    "plant": "OLF1",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANPET",
    "plant": "OLF2",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANSAB",
    "plant": "OLEFINS",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "IBN ZAHR",
    "plant": "PP2",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "KEMYA",
    "plant": "LLDPE",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "SAUDI KAYAN",
    "plant": "PP",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "UNITED",
    "plant": "LAO",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANSAB",
    "plant": "LLDPE",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANSAB",
    "plant": "PP",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANPET",
    "plant": "POLY1",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANPET",
    "plant": "POLY2",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "GELEEN",
    "plant": "OLF4",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "MTVERNON",
    "plant": "BRN",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "MTVERNON",
    "plant": "COG",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "MTVERNON",
    "plant": "LEXR",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "SABIC Agri-Nutrients",
    "plant": "AN4",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "SABIC AGRI-NUTRIENTS",
    "plant": "AN5",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "PETROKEMYA",
    "plant": "POLYETHYLENE",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "IBN ZAHR",
    "plant": "PP-3",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  },
  {
    "affiliate": "YANSAB",
    "plant": "HDPE",
    "countS_Overdue": 0,
    "countS_workInProgress": 0,
    "countS_NotAssigned": 0,
    "countS_Closed": 0,
    "utilization": null
  }
]
export const GetAlertManagementYearList = [
  {
    "yearName": "2019",
    "yearValue": "2019"
  },
  {
    "yearName": "2020",
    "yearValue": "2020"
  },
  {
    "yearName": "2021",
    "yearValue": "2021"
  },
  {
    "yearName": "2022",
    "yearValue": "2022"
  },
  {
    "yearName": "2023",
    "yearValue": "2023"
  }
]
export const GetAlertManagementMonthList = [
  {
    "monthName": "JANUARY",
    "monthValue": "JANUARY"
  },
  {
    "monthName": "FEBRUARY",
    "monthValue": "FEBRUARY"
  },
  {
    "monthName": "MARCH",
    "monthValue": "MARCH"
  },
  {
    "monthName": "APRIL",
    "monthValue": "APRIL"
  },
  {
    "monthName": "MAY",
    "monthValue": "MAY"
  },
  {
    "monthName": "JUNE",
    "monthValue": "JUNE"
  },
  {
    "monthName": "JULY",
    "monthValue": "JULY"
  },
  {
    "monthName": "AUGUST",
    "monthValue": "AUGUST"
  },
  {
    "monthName": "SEPTEMBER",
    "monthValue": "SEPTEMBER"
  },
  {
    "monthName": "OCTOBER",
    "monthValue": "OCTOBER"
  },
  {
    "monthName": "NOVEMBER",
    "monthValue": "NOVEMBER"
  },
  {
    "monthName": "DECEMBER",
    "monthValue": "DECEMBER"
  }
]