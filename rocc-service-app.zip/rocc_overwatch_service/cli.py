"""
 Created on Thu Nob 19 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
from argparse import ArgumentParser
import warnings
import urllib3

from cli_utility.scripts.fse_user_setup import add_fse_user
from cli_utility.scripts.parent_org_setup import setup_parent_org
from cli_utility.scripts.service_tools_setup import setup_service_tools
from cli_utility.scripts.utility import fetch_config_value, fetch_profile_configs_for_cli, fetch_service_token
from src.constants.constants import ENV, LOG_INGESTER_URL, SEP
from src.loggers.log import create_logger
from src.utility.starters import load_envs
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_access_token_from_hsdp
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_HSDP_IDM_URL, VAULT_PARENT_ORG_ID
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import fetch_user_details

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# pylint: skip-file
parser = ArgumentParser()

parser.add_argument("-u", help="Username")
parser.add_argument("-p", help="Password")

args = parser.parse_args()
arg_username = args.u
arg_pwd = args.p

LOG = create_logger("CLI")
NAME = "ROCC Customer Provisioning Portal service CLI"

WELCOME_MSG = f"""\n{'=' * 55}\n\n\t\t\tWelcome to\n\t\t{NAME}\n\n{'=' * 55}\n"""

END_MSG = f"""\n{'=' * 10}END: {NAME}{'=' * 10}\n"""

MAIN_OPTIONS = f"""Choose the operation you want to proceed with:
                   1. Generate configs
                   2. Parent org setup
                   3. Enable Service tool for Parent org
                   4. Create FSE users
                   q. Quit [q]
{SEP}\nEnter ["1" / "2" / "3" / "4" or "q"]: """


def initialize_logger():
    url = fetch_config_value(LOG_INGESTER_URL)
    if url:
        os.environ[LOG_INGESTER_URL] = url
    profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
    response = load_envs(profile_configs=profile_configs)
    if response:
        LOG.info("Successfully initialized logging!")
    else:
        LOG.warn("Kibana logging initalization failed!")
    return profile_configs


def starter(user_details, profile_configs):
    print(WELCOME_MSG)
    try:
        while True:
            option = input(MAIN_OPTIONS)
            if option == "1":
                """ TODO: Need to clean up """
                print("This option is deprecated")
            elif option.lower() == "2":
                setup_parent_org(user_details=user_details)
            elif option.lower() == "3":
                setup_service_tools(user_details=user_details)
            elif option.lower() == "4":
                add_fse_user(user_details=user_details)
            elif option.lower() == "service_token":
                fetch_service_token()
            elif option.lower() == "q":
                break
            else:
                print("Invalid choice!")
            print(SEP)
    except Exception as ex:
        LOG.error(f"An error occurred in ROCC Customer Provisioning Portal service CLI: {ex}")
    finally:
        LOG.info(END_MSG)


def validate_user(profile_configs):
    LOG.info("Generating access token for user")
    user_name = arg_username if arg_username else fetch_config_value("USERNAME")
    password = arg_pwd if arg_pwd else fetch_config_value("PASSWORD")
    token = create_access_token_from_hsdp(iam_url=profile_configs[VAULT_HSDP_IAM_URL],
                                          username=user_name,
                                          password=password,
                                          client_id=fetch_config_value("ROOT_ORG_IAM_CLIENT_ID"),
                                          client_secret=fetch_config_value("ROOT_ORG_IAM_CLIENT_SECRET"))
    if token:
        user_uuid = fetch_user_details(idm_url=profile_configs[VAULT_HSDP_IDM_URL],
                                       token=token,
                                       email_id=user_name)
        return {"userId": user_uuid, "orgId": profile_configs[VAULT_PARENT_ORG_ID], "token": token}
    else:
        LOG.info("Invalid user credentials!")
        return False


ENTRY_PROMPT = f"""\nYou are executing in environment: {fetch_config_value(ENV)}
\n
==============
Proceed: [Y/n] """

if __name__ == "__main__":
    response = input(ENTRY_PROMPT)
    if response.lower() not in ["yes", "y"]:
        LOG.info("Exiting the script!")
        exit(1)
    profile_configs = initialize_logger()
    login_response = validate_user(profile_configs)
    if login_response:
        starter(user_details=login_response, profile_configs=profile_configs)
    else:
        LOG.info("Not a valid user ..!!")
