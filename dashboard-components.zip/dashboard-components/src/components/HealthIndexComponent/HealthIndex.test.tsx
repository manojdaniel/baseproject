import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import HealthIndexComponent from "./index";

describe("HealthIndexComponent", () => {
	const item = {
		image: "https://example.com/image.png",
		name: "Example Item",
		healthIndex: 50,
	};
	const title = "AFFILIATE";

	it('renders the component with an image when the title is "AFFILIATE"', () => {
		const { getByAltText } = render(
			<HealthIndexComponent item={item} title={title} />
		);
		expect(getByAltText("affiliate image")).toBeInTheDocument();
	});

	it('renders the component with a name when the title is not "AFFILIATE"', () => {
		const { getByText } = render(
			<HealthIndexComponent item={item} title="EXAMPLE" />
		);
		expect(getByText("Example Item")).toBeInTheDocument();
	});

	it("renders the component with a blue bar indicating the health index", () => {
		const { getByTestId } = render(
			<HealthIndexComponent item={item} title={title} />
		);
		expect(getByTestId("blue-bar")).toBeInTheDocument();
		expect(getByTestId("health-index")).toHaveTextContent("50%");
	});
});
