/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import en from "../../../resources/translations/en-US"
import { getIntlProvider, ModalComponent } from "@rocc/rocc-global-components"
import { fetchGlobalCurrentUser } from "../../../redux/store/externalAppStates"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { EButtonDirection } from "@rocc/rocc-client-services"
import { IConfirmModal, ILeaveProtocolTransferConfirmProps } from "../../../redux/interfaces/types"
import { setProtocolTransferStatus, setProtocolTransferExitInProgress, setInitiationRoute } from "../../../redux/actions/protocolTransferActions"
import { useDispatch } from "react-redux"
import { initConfirmModal } from "../../../common/constants/constants"

const componentName = "LeaveProtocolTransferConfirmDlg"

const LeaveProtocolTransferConfirmDlg = (props: ILeaveProtocolTransferConfirmProps) => {
    const [confirmModal, setConfirmModal] = useState(initConfirmModal)
    const { intl } = getIntlProvider()
    const dispatch = useDispatch()

    const currentUser = fetchGlobalCurrentUser()

    const constructDialogModal = () => {
        if (props.show) {
            const confirmModalObject: IConfirmModal = {
                show: true,
                onCancel: () => {
                    sendLogsToAzure({ contextData: { component: componentName, event: "Stay on protocol transfer", Event_By: currentUser.uuid } })
                    setConfirmModal(initConfirmModal)
                    props.onDialogClosed()
                },
                onConfirm: () => {
                    sendLogsToAzure({ contextData: { component: componentName, event: "Confirmed leave protocol transfer", Event_By: currentUser.uuid } })
                    setConfirmModal(initConfirmModal)
                    dispatch(setProtocolTransferStatus(false))
                    dispatch(setProtocolTransferExitInProgress(true))
                    dispatch(setInitiationRoute(""))
                    props.postConfirmCallback()
                    props.onDialogClosed()
                }
            }
            setConfirmModal(confirmModalObject)
        } else {
            setConfirmModal(initConfirmModal)
        }
    }

    useEffect(() => {
        constructDialogModal()
    }, [])

    const { show, onCancel, onConfirm } = confirmModal

    return <>
        {show &&
            <ModalComponent
                showModal={show}
                showCloseIcon={false}
                closeOnDimmerClick={false}
                buttonDirection={EButtonDirection.RIGHT}
                actionButton1Text={intl.formatMessage({ id: "content.admin.closeUserModal.secondaryBtn", defaultMessage: en["content.admin.closeUserModal.secondaryBtn"] })}
                actionButton2Text={intl.formatMessage({ id: "content.admin.closeUserModal.primaryBtn", defaultMessage: en["content.admin.closeUserModal.primaryBtn"] })}
                actionButton1Onclick={() => onConfirm()}
                actionButton2Onclick={() => onCancel()}
                modalContent={intl.formatMessage({ id: "content.protocolTransfer.protocolManagerExitMessage", defaultMessage: en["content.protocolTransfer.protocolManagerExitMessage"] })}
                modalStyles="ptLeaveModal"
            />
        }
    </>
}

export default LeaveProtocolTransferConfirmDlg
