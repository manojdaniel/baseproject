/*
 * Created on Wed May 11 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ERoomType } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import * as helpers from "../../helpers/helpers"
import * as callUtility from "../../helpers/callUtility"
import { WorkflowController } from "./WorkflowController"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        workflows: [{ state: { value: "", matches: () => undefined }, type: "PARK_AND_START_EDITING" }],
        currentUser: {
            accessToken: "accessToken",
            onBoarded: true,
            sessionId: "sessionId",
            locale: "locale",
        },
        connectedCallDetails: {
            contextId: "contextId",
            roomName: "roomName",
            roomType: ERoomType.PEER_TO_PEER,
            twilioToken: "twilioToken",
            userDetails: "",
            participants: [],
            numOfParticipants: 0,
            isMuted: false,
            isDeafened: false,
            isFirstParticipant: false,
            callAcceptedTime: "callAcceptedTime",
            callStatus: ECallStatus.IDLE
        },
        videoCallStatus: { contextId: "contextId", callStatus: ECallStatus.IDLE }
    }),
    useDispatch: jest.fn().mockReturnValue(jest.fn)
}))

describe("WorkflowController tests", () => {
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }

    it("should render workflowcontroller component", () => {
        withHooks(() => {
            useEffect = jest.spyOn(React, "useEffect")
            const mockUseEffect = () => {
                useEffect.mockImplementationOnce(f => f())
            }
            jest.spyOn(helpers, "getStateValueDependency").mockImplementation(jest.fn()).mockReturnValue("")
            jest.spyOn(callUtility, "findCallStatusByContextId").mockImplementation(jest.fn()).mockReturnValue({contextId: "contextId", callStatus: ECallStatus.IDLE})
            mockUseEffect()
            const wrapper = shallow(<WorkflowController />)
            expect(wrapper).toBeDefined()
        })
    })
})
