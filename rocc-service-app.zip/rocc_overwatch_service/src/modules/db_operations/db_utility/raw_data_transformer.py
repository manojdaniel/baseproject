"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.constants.constants import TEMPLATE_DETAILS
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.wrappers.graphql.queries.queries import fetch_raw_details_from_transaction_id
from src.utility.semver import parse_version

LOG = create_logger("RawDataTransformer")


def fetch_dict_from_transaction_id(transaction_id, client):
    try:
        variables = {"transaction_id": transaction_id}
        response = client.execute(
            fetch_raw_details_from_transaction_id, variable_values=variables)
        if len(response["raw_data"]):
            data = response["raw_data"][0]["data"]
            id = response["raw_data"][0]["id"]
            return data, id
        LOG.error(f"Raw data for transaction: {transaction_id} not found")
        raise RoccException(404, f"Raw data for transaction: {transaction_id} not found")
    except RoccException as e:
        LOG.error(f"Exception occured while fetching raw data for transaction {transaction_id}. Error: {e}")
        raise RoccException(e.status_code, str(e.payload))


def extract_table_name_from_schema_table_name(table_name, schema_name):
    try:
        matcher = f"{schema_name}_"
        if table_name.startswith(matcher):
            new_table_name = table_name[len(matcher):]
            return new_table_name
    except Exception as ex:
        LOG.exception(f"Failed to extract table name with error: {ex}")
    return table_name
