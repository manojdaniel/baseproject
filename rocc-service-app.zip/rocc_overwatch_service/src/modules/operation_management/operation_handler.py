"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from abc import ABC, abstractmethod

from src.constants.constants import ROUTING_KEY, OPERATION, JOB_LIST, CURRENT_JOB, TARGET_QUEUE, TRANSACTION_ID, ENTITY_ID, \
    ENTITY_TYPE, JOB_NAME, INDEX, STATUS, NOT_STARTED, COMPLETED, USER_UUID

""" Structure of New Customer onboard payload in message """
payload = {
    TRANSACTION_ID: "",
    OPERATION: "",
    CURRENT_JOB: "INFRA_SETUP",
    JOB_LIST: [
        {INDEX: 0, JOB_NAME: "INFRA_SETUP", STATUS: NOT_STARTED},
        {INDEX: 1, JOB_NAME: "ROUTE_SETUP", STATUS: NOT_STARTED},
        {INDEX: 2, JOB_NAME: "TWILIO_SETUP", STATUS: NOT_STARTED},
        {INDEX: 3, JOB_NAME: "CUSTOMER_DATA_SETUP", STATUS: NOT_STARTED},
    ],
    ROUTING_KEY: "",
    TARGET_QUEUE: "",
    ENTITY_TYPE: "",
    ENTITY_ID: "",
    USER_UUID: ""
}
""" Structure of Existing Customer onboard payload in message """
payload = {
    TRANSACTION_ID: "",
    OPERATION: "",
    CURRENT_JOB: "ROUTE_SETUP",
    JOB_LIST: [
        {INDEX: 0, JOB_NAME: "INFRA_SETUP", STATUS: COMPLETED},
        {INDEX: 1, JOB_NAME: "ROUTE_SETUP", STATUS: NOT_STARTED},
        {INDEX: 2, JOB_NAME: "TWILIO_SETUP", STATUS: NOT_STARTED},
        {INDEX: 3, JOB_NAME: "CUSTOMER_DATA_SETUP", STATUS: NOT_STARTED},
    ],
    ROUTING_KEY: "",
    TARGET_QUEUE: "",
    ENTITY_TYPE: "",
    ENTITY_ID: "",
    USER_UUID: ""
}


class OperationHandler(ABC):
    """
    This needs to act like an interface/abstract class to trigger long running operations
    """

    def __init__(self):
        """ 
        1. Create a new transaction in transaction table
        2. Post message to RabbitMQ with Payload
        3. Return transaction_id (operation_id) to the caller
        """
        pass

    @abstractmethod
    def create_transaction(self, entity_identifier, entity_name, file_identifier, entity_type):
        """
        1. Create a new transaction in transaction table
        2. Return transaction_id (operation_id) to the caller
        """
        pass

    @abstractmethod
    def post_message(self, transaction_id, entity_type, entity_identifier):
        """
        1. Post message to RabbitMQ with Payload
        """
        pass

    @abstractmethod
    def initiate_operation(self, entity_identifier, entity_name, file_identifier):
        pass
