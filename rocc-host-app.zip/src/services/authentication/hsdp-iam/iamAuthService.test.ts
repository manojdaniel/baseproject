/*
* Created on Fri Aug 05 2022
*
* Copyright (c) 2022 Philips
* (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
* Reproduction or transmission in whole or in part, in any form or by any
* means, electronic, mechanical or otherwise, is prohibited without the prior
* written consent of the copyright owner.
*/

import { IAuthConfigs } from "@rocc/rocc-client-services"
import { authorizeCallback, iamAuthLoginHandler, initAuthentication, validateCredentials, validateDeviceInfo, validateOtp } from "./iamAuthServices"
import { EAuthState, EIamResponseStatus } from "./iamAuthTypes"

jest.mock("../AuthenticationService", () => ({
    loginHandler: jest.fn(),
}))

describe("iam test cases", () => {
    const doAuthMock = jest.fn()
    const dispatch = jest.fn()
    const authConfigs: IAuthConfigs = {
        appClientId: "asd",
        authId: "asda",
        authState: EAuthState.ERROR,
        authUrl: "",
        otpAllowTrustDevice: false,
        redirectUrl: "",
        identityProviderConfigName: "",
    }
    beforeEach(() => {
        jest.clearAllMocks()
    })
    it("iamAuthHandler error state", () => {
        iamAuthLoginHandler(authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
    })
    it("initAuthentication error", () => {
        initAuthentication({ status: EIamResponseStatus.ERROR, content: {} as any }, authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
    })
    it("initAuthentication success with show login", () => {
        (window as any).doAuthentication = doAuthMock
        initAuthentication({ status: EIamResponseStatus.SUCCESS, content: { hint: "SHOW_LOGIN", data: [{ value: "" }] } as any }, authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
        expect(doAuthMock).toBeCalled()
    })
    it("initAuthentication success with call auth", () => {
        (window as any).doAuthorization = doAuthMock
        initAuthentication({ status: EIamResponseStatus.SUCCESS, content: { hint: "CALL_AUTHORIZE", data: [{ value: "" }] } as any }, authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
        expect(doAuthMock).toBeCalled()
    })
    it("initAuthentication success with ERROR", () => {
        (window as any).doAuthentication = doAuthMock
        initAuthentication({ status: EIamResponseStatus.SUCCESS, content: { hint: "ERROR", data: [{ value: "" }] } as any }, authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
    })
    it("initAuthentication parse error", () => {
        initAuthentication({ status: EIamResponseStatus.SUCCESS, content: { hint: "ERROR", data: {} } as any }, authConfigs, { usename: "", password: "" }, dispatch)
        expect(dispatch).toBeCalled()
    })

    it("validateCredentials success", () => {
        (window as any).doAuthentication = doAuthMock
        validateCredentials({ status: EIamResponseStatus.SUCCESS, content: { hint: "COLLECT_DEVICE_INFO", data: {} } as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalled()
        expect(dispatch).toBeCalled()
    })
    it("validateCredentials unauth", () => {
        (window as any).doAuthentication = doAuthMock
        validateCredentials({ status: EIamResponseStatus.ERROR, content: {} as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })
    it("validateCredentials parse error", () => {
        (window as any).doAuthentication = doAuthMock
        validateCredentials({ status: EIamResponseStatus.SUCCESS, content: [] as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })


    it("validateDeviceInfo success", () => {
        (window as any).doAuthentication = doAuthMock
        validateDeviceInfo({ status: EIamResponseStatus.SUCCESS, content: { hint: "SHOW_SERVER_OTP" } as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })
    it("validateDeviceInfo error", () => {
        (window as any).doAuthentication = doAuthMock
        validateDeviceInfo({ status: EIamResponseStatus.SUCCESS, content: [] as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })

    it("validateOtp success", () => {
        (window as any).doAuthorization = doAuthMock
        validateOtp({ status: EIamResponseStatus.SUCCESS, content: { hint: "CALL_AUTHORIZE" } as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(1)
        expect(dispatch).toBeCalled()
    })
    it("validateOtp  with wrong otp", () => {
        (window as any).doAuthentication = doAuthMock
        validateOtp({ status: EIamResponseStatus.SUCCESS, content: { hint: "SHOW_SERVER_OTP" } as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })
    it("validateOtp  with parse error", () => {
        (window as any).doAuthentication = doAuthMock
        validateOtp({ status: EIamResponseStatus.SUCCESS, content: [] as any }, authConfigs, dispatch)
        expect(doAuthMock).toBeCalledTimes(0)
        expect(dispatch).toBeCalled()
    })

    it("authorizeCallback  success", () => {
        authorizeCallback({ status: EIamResponseStatus.SUCCESS, content: { hint: "REDIRECT", data: [{ value: "http://asd.com?code=sadsad" }] } as any }, dispatch)
        expect(dispatch).toBeCalled()
    })
    it("authorizeCallback  error", () => {
        authorizeCallback({ status: EIamResponseStatus.ERROR, content: { hint: "SHOW_LOGIN" } as any }, dispatch)
        expect(dispatch).toBeCalled()
    })
    it("authorizeCallback  error parsing", () => {
        authorizeCallback({ status: EIamResponseStatus.SUCCESS, content: [] as any }, dispatch)
        expect(dispatch).toBeCalled()
    })

})
