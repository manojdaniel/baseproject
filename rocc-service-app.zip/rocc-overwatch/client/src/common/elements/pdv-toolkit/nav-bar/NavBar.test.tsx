/*
 * Created on Wed Nov 30 2020
 *
 * Copyright (c) 2020 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mount } from "enzyme"
import React from "react"
import NavBar from "./NavBar"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        navData: {},
        customers: [],
    }),
    useDispatch: () => jest.fn()
}))

describe("Navbar component", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = mount(
            <NavBar
                appName="MyApp"
                useAppNameLink={true}
                appNameLink={"/"}
                appVersion={"1.0.0"}
                userName="Myname"
                primaryMenuItems={[]}
                secondaryMenuItems={[]}
                appSwitcher={true}
                searchIcon={false}
                statusIcon={false}
                notificationIcon={false}
                notificationValue={"1"}
                settingsIcon={false}
                aboutIcon={false}
                isMobile={false}
            />
        )
    })
    it("should render with the menu item", () => {
        expect(wrapper.find("Menu")).toHaveLength(1)
    })


})
