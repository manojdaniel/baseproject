/*
 * Created on Mon Jan 24 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"

import { shallow } from "enzyme"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import SomethingWentWrongBanner from "./SomethingWentWrongBanner"
import { EConnectionStatus } from "@rocc/rocc-client-services"

const testState = {
    configReducer: {
        configs: {
            DEVICE_RECOVERY_TIME_IN_MINS: ""
        }
    },
    clientStatusReducer: {
        applicationConnectionState: EConnectionStatus.ONLINE
    },
    userReducer: {
        currentUser: {},
        forceCleanUp: true
    }
}

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: () => jest.fn(),
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

describe("Something Went Wrong component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    let useRefSpy: any
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        mockUseEffect()
        useSelectorMock(testState)
        useRefSpy = jest.spyOn(React, 'useRef').mockReturnValueOnce({ current: true })
        wrapper = shallow(<SomethingWentWrongBanner onRetry={jest.fn()} />)
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })

    it("should render something went wrong component", () => {
        expect(useRefSpy).toBeCalledTimes(1)
        const component = wrapper.find("SomethingWentWrong")
        component.props().handleClick()
        expect(component.exists()).toBeTruthy()
    })
})
