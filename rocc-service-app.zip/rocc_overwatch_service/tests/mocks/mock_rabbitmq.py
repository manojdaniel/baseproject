"""
 Created on Mon May 23 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.loggers.log import create_logger

LOG = create_logger("MockRabbitmqModules")


class MockURLParameters:
    def __init__(self, host):
        self.host = host


class MockChannel:
    @property
    def consumer_tags(self):
        return []

    def __init__(self):
        pass

    def exchange_declare(self, exchange, exchange_type, auto_delete=False, durable=False):
        LOG.debug(f"Log to consume mock params: {exchange, exchange_type, auto_delete, durable}")

    def queue_declare(self, queue, auto_delete=False, durable=False, arguments=None):
        LOG.debug(f"Log to consume mock params: {queue, auto_delete, durable, arguments}")

    def queue_bind(self, queue, exchange, routing_key=None):
        LOG.debug(f"Log to consume mock params: {queue, exchange, routing_key}")

    def basic_consume(self, queue, auto_ack, on_message_callback):
        LOG.debug(f"Log to consume mock params: {queue, auto_ack, on_message_callback}")

    def basic_publish(self, exchange, routing_key, properties, body):
        LOG.debug(f"Log to consume mock params: {exchange, routing_key, properties, body}")

    def start_consuming(self):
        pass


class MockBlockingConnection:
    def __init__(self, data):
        LOG.debug(f"Log to consume mock params: {data}")

    def channel(self):
        return MockChannel()

    def close(self):
        pass
