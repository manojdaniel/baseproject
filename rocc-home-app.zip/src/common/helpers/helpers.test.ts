/*
 * Created on Wed Oct 13 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mockedGlobalStore } from "../../mocks/mock-data"
import * as externalAppStates from "../../redux/store/externalAppStates"
import { getCustomrReducerFromGlobalStore, getConfigReducerFromGlobalStore, getFeatureFlagsReducerFromGlobalStore } from "./helpers"

jest.mock("../../redux/store/externalAppStates")

jest.mock("redux-micro-frontend", () => {
    return mockedGlobalStore
})

describe("test helper functions", () => {
    it("should return customerReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            rooms: []
        })
        expect(getCustomrReducerFromGlobalStore().rooms).toEqual([])
    })
    it("should return configreducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            featureFlags: []
        })
        expect(getFeatureFlagsReducerFromGlobalStore().featureFlags).toEqual([])
    })
    it("should return featureFlagReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            isProxy: false
        })
        expect(getConfigReducerFromGlobalStore().isProxy).toBeFalsy()
    })
})
