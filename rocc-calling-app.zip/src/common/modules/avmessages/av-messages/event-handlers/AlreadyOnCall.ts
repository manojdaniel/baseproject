/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { ACTIVE_CALL_MESSAGE, TIMEOUT_10 } from "../../../../../constants/constants"
import { setCallMessage, updateCallTimeout } from "../../../../../redux/actions/callActions"
import store from "../../../../../redux/store/store"
import en from "../../../../../resources/translations/en-US"
import { updateCallDetails } from "../../../av/AudioVideoHelper"
import { TRACKING_VALUES } from "../types"

interface IAlreadyOnCall {
    contextId: string
    participant: string
    dispatch: Dispatch<any>
}

export const alreadyOnCall = async (props: IAlreadyOnCall) => {
    const { contextId, participant, dispatch } = props
    const { connectedCallDetails, incomingCall, currentUser, onHoldCallDetails } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES

    const { intl } = getIntlProvider()
    if (contextId !== incomingCall.contextId) {
        dispatch(updateCallTimeout({ contextId, timeoutId: setTimeout(() => "", TIMEOUT_10) }, false))
    }
    sendLogsToAzure({ contextData: { component, event: `${event} Already On call`, Call_To: currentUser.uuid, Call_From: participant, contextId } })
    const activeCall = [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
    if (activeCall?.participants?.length) {
        const participantIndex = activeCall.participants.findIndex((user) => user.uuid === participant)
        if (participantIndex > -1) {
            const participantDetails = activeCall.participants[participantIndex]
            activeCall.participants.splice(participantIndex, 1)
            updateCallDetails(activeCall, dispatch, true)
            dispatch(setCallMessage({
                messageType: ACTIVE_CALL_MESSAGE, contact: DEFAULT_CONTACT_INFO,
                message: `${intl.formatMessage({ id: "content.callMessages.user", defaultMessage: en["content.callMessages.user"] })} ${participantDetails.name} ${intl.formatMessage({ id: "content.callMessages.alreadyOnCall", defaultMessage: en["content.callMessages.alreadyOnCall"] })}`
            }))
        }
    }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const { connectedCallDetails, incomingCall, onHoldCallDetails } = state.callReducer.callDetails
    const { currentUser } = state.externalReducer
    return { connectedCallDetails, incomingCall, currentUser, onHoldCallDetails }
}
