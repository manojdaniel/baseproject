/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import thunk from "redux-thunk"
import rootReducer from "../reducers/rootReducer"
import globalStore from "./globalStore"
import { persistStore, persistReducer } from "redux-persist"
import storageSession from "redux-persist/lib/storage/session"
import hardSet from "redux-persist/lib/stateReconciler/hardSet"
import { IStore } from "../interfaces/types"
import { Store } from "redux"
import { APP_NAME, STORAGE_KEY } from "../../common/constants/constants"
import { GLOBAL_CLEAR_DESTINATIONS, GLOBAL_SET_DESTINATION_SCANNER, GLOBAL_SET_INITIATION_ROUTE, GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, GLOBAL_SET_PROTOCOL_TRANSFER_STEP, GLOBAL_SET_SOURCE_SCANNER } from "../actions/types"

const persistConfig = {
    key: `${APP_NAME}_${STORAGE_KEY}`,
    storage: storageSession,
    stateReconciler: hardSet,
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store: Store<IStore> = globalStore.CreateStore(APP_NAME, persistedReducer, [thunk], [
    GLOBAL_SET_PROTOCOL_TRANSFER_STATUS,
    GLOBAL_SET_INITIATION_ROUTE,
    GLOBAL_SET_PROTOCOL_TRANSFER_EXIT,
    GLOBAL_SET_SOURCE_SCANNER,
    GLOBAL_SET_DESTINATION_SCANNER,
    GLOBAL_SET_PROTOCOL_TRANSFER_STEP,
    GLOBAL_CLEAR_DESTINATIONS
])

export const persistor = persistStore(store)

export default store
