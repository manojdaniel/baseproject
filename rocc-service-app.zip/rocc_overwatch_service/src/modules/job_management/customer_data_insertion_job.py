"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

from src.constants.constants import FAILED, JOB_LIST, CURRENT_JOB, OPERATION, TRANSACTION_ID, ENTITY_ID, INIT, \
    COMPLETED, JOB_NAME, INDEX, STATUS, HSDP_IAM_URL, DATA, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, ID, TRANSACTION_DATA, \
    FAILED_AT
from src.constants.constants import HSDP_ORGANIZATION_ID, USER_UUID
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.insertion_management.cc_data_services import CcDataServices
from src.modules.db_operations.db_utility.raw_data_transformer import fetch_dict_from_transaction_id
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_job_id_from_name, get_infra_configs, update_service_job_transaction_status, \
    get_service_job_transactions_details, fetch_tasks_for_job, update_tasks_for_transaction
from src.modules.event_management.event_enums import EJobs, EOperations, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.job_management.job_handler import JobHandler
from src.modules.insertion_management.manage_org_metadata_site_data import ManageOrgMetadataAndSiteDataTask
from src.modules.insertion_management.manage_rooms import ManageRooms
from src.modules.insertion_management.manage_users import ManageUsers
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit

LOG = create_logger("CustomerDataInsertionJob")


class CustomerDataInsertionJob(JobHandler):
    def __init__(self):
        self._success = False
        self._org_db_id = False
        self._payload = None
        self._user_uuid = None
        self._org_infra_uuid = None
        self._transaction_id = None
        self._customer_vault_values = None
        self._token = None
        self._client = None
        self._data_dict = None
        self._upload_record_id = None
        self._job_id = None
        self._transaction_data = None
        self._tasks_list = None
        self._infra_configs = None
        self._kvm_config_id = None

    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        5. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            self._user_uuid = self._payload[USER_UUID]
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            self._transaction_id = self._payload[TRANSACTION_ID]
            self._customer_vault_values = get_path_specific_vault_values(
                path_name=self._payload[ENTITY_ID])
            self._org_infra_uuid = self._customer_vault_values[DATA][HSDP_ORGANIZATION_ID]
            self._token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                          issuer=self._customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                          private_key=self._customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            self._client = get_client_connection(
                access_token=self._token, org_infra_uuid=self._org_infra_uuid)
            # Use this dict to perform all tasks
            self._data_dict, self._upload_record_id = fetch_dict_from_transaction_id(
                self._transaction_id, self._client)
            job_transaction_details = self.fetch_transaction_from_db()
            self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
            # Update Task in TimedWait Job
            self.update_taks_if_timed_wait_task_exists()
            self._job_id = fetch_job_id_from_name(
                EJobs.CUSTOMER_DATA_INSERTION.value, self._client)
            self.load_infra_configs(
                customer_id=job_transaction_details[0]["entity_id"])
            if len(job_transaction_details) != 0:
                self.fetch_all_tasks()
                self.update_transaction_in_db_wrt_job(status=INIT,
                                                      task_name=ETasks.SITE_DATA_INSERTION.value,
                                                      job_status_update=True,
                                                      update_record_status=True)
                self.execute_tasks()
                prepare_and_post_audit(event_type="Customer Data Insertion", event_subtype=EJobs.CUSTOMER_DATA_INSERTION.value, action="E", outcome=0,
                                       user_detail=self._user_uuid, org_id=self._org_infra_uuid, token=self._token,
                                       **{EJobs.CUSTOMER_DATA_INSERTION.value: COMPLETED},
                                       **{TRANSACTION_ID: self._transaction_id})
            else:
                LOG.info(
                    f"{self._payload[CURRENT_JOB]} Job is completed and transaction details are, {self._transaction_id}")

            self.post_message(payload=self._payload)
            LOG.info(f"Finished Job: {EJobs.CUSTOMER_DATA_INSERTION.value}")
        except RoccException as ex:
            LOG.error(
                f"Customer data insertion job failed with RoccException error: {ex}")
            self.post_message(payload=self._payload)
            raise RoccException(ex.status_code, str(ex.payload)) from ex
        except Exception as ex:
            LOG.error(
                f"Customer data insertion job failed with general error: {ex}")
            self.post_message(payload=self._payload)
            raise RoccException(
                500, "Customer data insertion job failed") from ex

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(
            job_id=self._job_id, client=self._client)
        LOG.info(
            f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def fetch_transaction_from_db(self):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(
            self._transaction_id, client=self._client)
        LOG.info(
            f"Fetch job details for transaction_id, {self._transaction_id} is successful")
        return transaction_details

    #pylint: disable=arguments-differ
    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        """Update corresponding transaction from transaction table"""
        if update_record_status and self._payload[OPERATION] == EOperations.UPDATE_EXISTING_CUSTOMER:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self._client)
            LOG.info(
                f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._transaction_id,
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[
                                                                  ID],
                                                              transaction_data_object=self._transaction_data,
                                                              status=status,
                                                              client=self._client,
                                                              job_status_update=job_status_update,
                                                              reason=error_reason)

    def update_taks_if_timed_wait_task_exists(self):
        for job in self._transaction_data["jobs"]:
            if job["name"] == EJobs.TIMED_WAIT.value:
                LOG.info(f"Updating Task in job {EJobs.TIMED_WAIT.value}")
                job_id = fetch_job_id_from_name(
                    EJobs.TIMED_WAIT.value, self._client)
                tasks_list = fetch_tasks_for_job(
                    job_id=job_id, client=self._client)
                self._transaction_data = update_tasks_for_transaction(transaction_id=self._transaction_id,
                                                                      job_id=job_id,
                                                                      task_id=(
                                                                          [x for x in tasks_list if x["task_name"] == ETasks.TIMED_WAIT.value][0])[ID],
                                                                      transaction_data_object=self._transaction_data,
                                                                      status=COMPLETED,
                                                                      client=self._client,
                                                                      job_status_update=True)

    def load_infra_configs(self, customer_id):
        """Fetch corresponding transaction from transaction table"""
        response = get_infra_configs(self._client, customer_id)
        if response and len(response) > 0:
            self._infra_configs = response[0]
        else:
            LOG.warn(
                f"Could not retrieve infrastructure configs for customer_id: {customer_id} with transaction: {self._transaction_id}")

    #pylint: disable=arguments-differ
    def execute_tasks(self):
        """
        TASKS:
        - SITE_DATA_INSERTION -> [Org data, Sites, EULA, KVM configs]
        - CC_DATA_INSERTION
        - MANAGE_ROOMS
        - MANAGE_USERS
        """
        try:
            self.task_manage_org_metadata_and_sites()
            self.task_manage_cc()
            self.task_manage_rooms()
            self.task_manage_users()
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.MANAGE_USERS.value, job_status_update=True)
            self._success = True
        except Exception as ex:
            LOG.error(
                f"Error while executing JOB {EJobs.CUSTOMER_DATA_INSERTION.value}. Error {ex}")

    def post_message(self, payload):
        """
        1. Post message to RabbitMQ with Payload
        """
        try:
            if self._success:
                current_record = list(filter(
                    lambda item: item[JOB_NAME] == EJobs.CUSTOMER_DATA_INSERTION.value, payload[JOB_LIST]))[0]
                for job in payload[JOB_LIST]:
                    if job[JOB_NAME] == EJobs.CUSTOMER_DATA_INSERTION.value:
                        job[STATUS] = COMPLETED
                    if job[INDEX] == current_record[INDEX] + 1:
                        payload[CURRENT_JOB] = job[JOB_NAME]
                        job[STATUS] = INIT
                LOG.info(
                    "Publishing a rabbitMQ message after completing current Job: CustomerDataInsertionJob")
            else:
                payload[CURRENT_JOB] = EJobs.FAILED.value
                payload[FAILED_AT] = EJobs.CUSTOMER_DATA_INSERTION.value
                LOG.warn(
                    f"Publishing FAILED rabbitMQ message, since the current job: {EJobs.CUSTOMER_DATA_INSERTION.value} is failed")
            publish_message(payload=payload)
        except Exception as ex:
            LOG.exception(f"Failed to post message with error: {ex}")

    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """

    def task_manage_org_metadata_and_sites(self):
        error_reasn = ""
        try:
            manage_org = ManageOrgMetadataAndSiteDataTask(client=self._client,
                                                          data_dict=self._data_dict,
                                                          customer_short_name=self._payload[ENTITY_ID],
                                                          transaction_data=self._transaction_data,
                                                          org_hsdp_uuid=self._org_infra_uuid,
                                                          user_uuid=self._user_uuid,
                                                          locale=self._customer_vault_values[DATA]["locale"])
            self._data_dict, self._transaction_data, self._kvm_config_id, self._org_db_id = manage_org.execute(
                upload_record_id=self._upload_record_id)
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.SITE_DATA_INSERTION.value, action="C", outcome=0,
                                   user_detail=self._user_uuid, org_id=self._org_infra_uuid, token=self._token, **{ETasks.SITE_DATA_INSERTION.value: COMPLETED},
                                   **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.SITE_DATA_INSERTION.value)
        except Exception as ex:
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype="Bulk Upload Customer", action="C", outcome=12, user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.SITE_DATA_INSERTION.value: FAILED}, **{TRANSACTION_ID: self._transaction_id})
            error_reasn = f"Exception while executing task {ETasks.SITE_DATA_INSERTION.value}. Error: {repr(ex.args)}"
            self.update_transaction_in_db_wrt_job(
                FAILED, task_name=ETasks.SITE_DATA_INSERTION.value, job_status_update=True, error_reason=error_reasn)
            LOG.exception(
                f"Exception while executing task {ETasks.SITE_DATA_INSERTION.value}")
            raise RoccException(
                500, f"Exception {ex} while executing task {ETasks.SITE_DATA_INSERTION.value}") from ex

    def task_manage_cc(self):
        error_reasn = ""
        try:
            manage_cc = CcDataServices(client=self._client,
                                       org_db_id=self._org_db_id,
                                       data_dict=self._data_dict,
                                       transaction_data=self._transaction_data,
                                       user_uuid=self._user_uuid)
            self._data_dict, self._transaction_data = manage_cc.execute()
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.CC_DATA_INSERTION.value, action="C", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.CC_DATA_INSERTION.value: COMPLETED}, **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.CC_DATA_INSERTION.value)
        except Exception as ex:
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.CC_DATA_INSERTION.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.CC_DATA_INSERTION.value: FAILED}, **{TRANSACTION_ID: self._transaction_id})
            error_reasn = f"Exception while executing task {ETasks.CC_DATA_INSERTION.value}. Error: {repr(ex.args)}"
            self.update_transaction_in_db_wrt_job(
                FAILED, task_name=ETasks.CC_DATA_INSERTION.value, job_status_update=True, error_reason=error_reasn)
            LOG.exception(
                f"Exception while executing task {ETasks.CC_DATA_INSERTION.value}")
            raise RoccException(
                500, f"Exception {ex} while executing task {ETasks.CC_DATA_INSERTION.value}") from ex

    def task_manage_rooms(self):
        error_reasn = ""
        try:
            manage_rooms = ManageRooms(data_dict=self._data_dict,
                                       transaction_data=self._transaction_data,
                                       token=self._token,
                                       user_uuid=self._user_uuid,
                                       customer_name=self._payload[ENTITY_ID],
                                       org_db_id=self._org_db_id,
                                       kvm_config_id=self._kvm_config_id)

            self._data_dict, self._transaction_data, self._client = manage_rooms.execute()
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.MANAGE_ROOMS.value, action="C", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.MANAGE_ROOMS.value: COMPLETED}, **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.MANAGE_ROOMS.value)
        except Exception as ex:
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.MANAGE_ROOMS.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.MANAGE_ROOMS.value: FAILED}, **{TRANSACTION_ID: self._transaction_id})
            error_reasn = f"Exception while executing task {ETasks.MANAGE_ROOMS.value}. Error: {repr(ex.args)}"
            self.update_transaction_in_db_wrt_job(
                FAILED, task_name=ETasks.MANAGE_ROOMS.value, job_status_update=True, error_reason=error_reasn)
            LOG.exception(
                f"Exception while executing task {ETasks.MANAGE_ROOMS.value}")
            raise RoccException(
                500, f"Exception {ex} while executing task {ETasks.MANAGE_ROOMS.value}") from ex

    def task_manage_users(self):
        error_reasn = ""
        try:
            manage_users = ManageUsers(data_dict=self._data_dict,
                                       client=self._client,
                                       token=self._token,
                                       transaction_data=self._transaction_data,
                                       org_infra_uuid=self._org_infra_uuid,
                                       org_db_id=self._org_db_id,
                                       transaction_id=self._transaction_id)

            self._data_dict, self._transaction_data = manage_users.execute()

            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.MANAGE_USERS.value, action="C", outcome=0,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.MANAGE_USERS.value: COMPLETED}, **{TRANSACTION_ID: self._transaction_id})
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.MANAGE_USERS.value)
        except Exception as ex:
            prepare_and_post_audit(event_type="Initiate Customer Data Insertion", event_subtype=ETasks.MANAGE_USERS.value, action="C", outcome=12,
                                   user_detail=self._user_uuid,
                                   org_id=self._org_infra_uuid, token=self._token,
                                   **{ETasks.MANAGE_USERS.value: FAILED}, **{TRANSACTION_ID: self._transaction_id})
            error_reasn = f"Exception while executing task {ETasks.MANAGE_USERS.value}. Error: {repr(ex.args)}"
            self.update_transaction_in_db_wrt_job(
                FAILED, task_name=ETasks.MANAGE_USERS.value, job_status_update=True, error_reason=error_reasn)
            LOG.exception(
                f"Exception while executing task {ETasks.MANAGE_USERS.value}")
            raise RoccException(
                500, f"Exception {ex} while executing task {ETasks.MANAGE_USERS.value}") from ex
