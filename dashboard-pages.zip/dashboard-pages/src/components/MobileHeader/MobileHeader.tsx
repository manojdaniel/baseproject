import React, { useEffect, useState } from "react";
import { slide as BurgerMenu } from "react-burger-menu";
import { useNavigate } from "react-router-dom";
import iconSearch from "../../assets/images/icon_Search.svg";
import iconAlerts from "../../assets/images/icon_Alerts.svg";
import iconProfile from "../../assets/images/icon_Profile.svg";
import icon_info from "../../assets/images/icon_Settings.svg";
import type { MenuProps } from "antd";
import { Menu } from "antd";
import "./MobileHeader.scss";
import { useDispatch, useSelector } from "react-redux";
import { AutoComplete } from "antd";
import {
	getHeaderSearch,
	getGlobalSearch,
	getGlobalSelecetedRegion,
	getGlobalSelecetedAffiliate,
	getGlobalSelecetedPlant,
	getGlobalSelecetedAsset,
	updateLoggedInUserDetails,
} from "../../redux/reducers/CommonReducer";

type MenuItem = Required<MenuProps>["items"][number];

function getItem(
	label: React.ReactNode,
	key: React.Key,
	icon?: React.ReactNode,
	children?: MenuItem[],
	type?: "group"
): MenuItem {
	return {
		key,
		icon,
		children,
		label,
		type,
	} as MenuItem;
}

const MobileHeader = () => {
	let navigate = useNavigate();
	let dispatch = useDispatch();
	const [showSearch, setShowSearch] = useState(false);
	const [searchData, setSearchData] = useState<any>();
	const [searchValue, setSearchValue] = useState<any>();
	const [searchButton, setSearchButton] = useState<any>(false);
	const [isOpen, setOpen] = useState(false);
	const [assetEnabled, setAssetEnabled] = useState(false);

	const handleIsOpen = () => {
		setOpen(!isOpen);
	};

	const {
		globalSearchData,
		globalSelecetedAsset,
		loggedInUserDetails,
		userName,
		userRole,
	} = useSelector((state: any) => ({
		globalSearchData: state.Common.globalSearchData,
		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		userName: state.Common.userName,
		userRole: state.Common.userRole,
		loggedInUserDetails: state.Common.loggedInUserDetails,
	}));

	const items: MenuProps["items"] = [
		getItem("HOME", "/"),
		getItem("AFFILIATES", "affiliates"),
		getItem("PLANTS", "allPlants", null, [
			getItem("PMT", "plant/pmt"),
			getItem("ALERT SATISTICS", "plant/alertSatistics", null, [
				getItem("ALERT DASHBOARD", "plant/alertSatistics/alertDashboard"),
				getItem("ALERT LIST", "plant/alertSatistics/alertList"),
				getItem("PLANT TIMELINE", "plant/alertSatistics/plantTimeline"),
			]),
			getItem("MODEL PERFORMANCE", "plant/modelPerformance"),
			getItem("ALERT MANAGEMENT PAGE", "plant/alertManagementPage"),
			getItem("PM COMPLIANCE", "plant/pmCompliance"),
		]),
		getItem("ASSETS", "assets", null, [
			getItem("ASSET MODEL", "assets/assetModel"),
			getItem("LIVE TRACKING", "assets/liveTracking"),
			getItem("ASSET TIMELINE", "assets/assetTimeLine"),
			getItem("ALERT LIST", "assets/alertList"),
			getItem("PLOT", "assets/plots"),
			getItem("REFERENCE TABLE", "assets/referenceTable"),
			getItem("SPARE PARTS", "assets/spareParts"),
		]),
		// getItem("EXECUTIVE", "executive"),
		getItem("INFO", "info"),
		getItem("USER PROFILE", "profile"),
	];
	const itemsAdmin: MenuProps["items"] = [
		getItem("HOME", "/"),
		getItem("AFFILIATES", "affiliates"),
		getItem("PLANTS", "allPlants", null, [
			getItem("PMT", "plant/pmt"),
			getItem("ALERT SATISTICS", "plant/alertSatistics", null, [
				getItem("ALERT DASHBOARD", "plant/alertSatistics/alertDashboard"),
				getItem("ALERT LIST", "plant/alertSatistics/alertList"),
				getItem("PLANT TIMELINE", "plant/alertSatistics/plantTimeline"),
			]),
			getItem("MODEL PERFORMANCE", "plant/modelPerformance"),
			getItem("ALERT MANAGEMENT PAGE", "plant/alertManagementPage"),
			getItem("PM COMPLIANCE", "plant/pmCompliance"),
		]),
		getItem("ASSETS", "assets", null, [
			getItem("ASSET MODEL", "assets/assetModel"),
			getItem("LIVE TRACKING", "assets/liveTracking"),
			getItem("ASSET TIMELINE", "assets/assetTimeLine"),
			getItem("ALERT LIST", "assets/alertList"),
			getItem("PLOT", "assets/plots"),
			getItem("REFERENCE TABLE", "assets/referenceTable"),
			getItem("SPARE PARTS", "assets/spareParts"),
		]),
		//getItem("EXECUTIVE", "executive"),
		getItem("INFO", "info"),
		getItem("USER PROFILE", "profile"),
		getItem("ADMIN CONFIGURATION", "admin"),
	];

	const onMenuClick: MenuProps["onClick"] = (e) => {
		navigate(`/${e.key}`);
		setOpen(false);
	};
	const [roleName, setRoleName] = useState("");
	const [userName1, setUserName1] = useState("");

	useEffect(() => {
		if (Object.keys(loggedInUserDetails).length > 0) {
			if (!loggedInUserDetails.hasOwnProperty("Succeeded")) {
				if (loggedInUserDetails.result !== null) {
					setRoleName(userRole);
					setUserName1(userName);
				}
				// if (globalSearchData.length < 1) {
				//     dispatch(getGlobalSearch(""));
				// }
			}
		}
	}, [loggedInUserDetails]);

	// useEffect(() => {
	//     /* Api call for getting serach vale */
	//     dispatch(getGlobalSearch(""));
	// }, []);

	useEffect(() => {
		/* Only when asset is selected Asset selectio in header will be enabled */
		if (Object.keys(globalSelecetedAsset).length > 0) {
			setAssetEnabled(true);
		} else {
			setAssetEnabled(false);
		}
	}, [globalSelecetedAsset]);
	useEffect(() => {
		if (globalSearchData.length > 0) {
			let value = globalSearchData.map(function (item: any) {
				// adding id to value to avoid warning in ant library Autocomplete
				return {
					value: `${item.value} ? ${item.id}`,
					label: renderTitle(
						item.value,
						item.identifier,
						item.color,
						item.assetId
					),
				};
			});
			setSearchData(value);
		}
	}, [globalSearchData]);

	const handleSearch = (searchId) => {
		/**
		 * getting filtered object from all json data
		 */
		let obj = getFilteredById(globalSearchData, searchId);
		/**
		 * passing filtered object to get page Navigation name
		 */
		let pageDetail = getPageIdentifier(obj);
		/**
		 * sending object back to HeaderWrapper to update redux store
		 */
		handleSearchBack(obj);
		/**
		 * Navigating
		 */
		onClickFunction(pageDetail, true);

		setSearchValue("");
	};
	const onSelect = (val: any, option: any) => {
		setSearchButton(true);
		var afterQueString = option.value.split("?")[1];
		var beforeQuesString = option.value.split("?")[0];
		setSearchValue(beforeQuesString.trim());
		handleSearch(afterQueString.trim());
		setShowSearch(false);
		handleIsOpen();
	};
	const getFilteredById = (data: any, searchId: any) => {
		let value = data.find((item: any) => item.id == searchId);
		return value;
	};

	const getPageIdentifier = (obj: any) => {
		let navigateTo = "";
		switch (obj.identifier) {
			case "Region":
				navigateTo = "affiliates";
				break;
			case "Affiliate":
				navigateTo = "allPlants";
				break;
			case "Plant":
				navigateTo = "plant/pmt";
				break;
			case "Asset":
				navigateTo = "assets";
				break;
		}
		return navigateTo;
	};

	const onClickFunction = (key: any, searchFunc?: boolean) => {
		if (key === "assets") {
			if (assetEnabled || searchFunc) {
				navigate(`/${key}`);
			}
		} else {
			navigate(`/${key}`);
		}
	};
	const handleSearchBack = (obj: any) => {
		switch (obj.identifier) {
			case "Region":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				break;
			case "Affiliate":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				break;
			case "Plant":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				dispatch(
					getGlobalSelecetedPlant({ value: obj.plantId, label: obj.plantName })
				);
				break;
			case "Asset":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				dispatch(
					getGlobalSelecetedPlant({ value: obj.plantId, label: obj.plantName })
				);
				dispatch(
					getGlobalSelecetedAsset({ value: obj.assetId, label: obj.assetId })
				);
				break;
		}
	};
	const onChange = (data: string) => {
		setSearchValue(data);
		setSearchButton(false);
	};
	const renderTitle = (
		title: string,
		identifier: string,
		color: string,
		assetId: any
	) => (
		<div className="search-row-option">
			<div className="search-row-title">{title}</div>
			<div className="search-row-assetid">
				{identifier === "Asset" ? assetId : null}
			</div>
			<div className="search-row-tag" style={{ backgroundColor: color }}>
				{identifier}
			</div>
		</div>
	);

	return (
		<BurgerMenu isOpen={isOpen} onOpen={handleIsOpen} onClose={handleIsOpen}>
			<div className="mobile-menu-header">
				<div className="username">
					<a href="#">
						<span>
							<img src={iconProfile} title="User" />
						</span>
						<span>{userName1}</span>
					</a>
				</div>
				<div className="icons">
					<a onClick={() => setShowSearch(true)}>
						<img src={iconSearch} />
					</a>

					<a href="#">
						<img src={iconAlerts} alt="notification" />
					</a>
					<a href="#">
						<img src={icon_info} alt="settings" />
					</a>
				</div>
			</div>
			{showSearch ? (
				<div className="search-popup">
					<AutoComplete
						autoFocus
						value={searchValue}
						style={{ width: 200 }}
						placeholder="Search Here"
						options={searchData}
						filterOption={true}
						onSelect={(val, option) => onSelect(val, option)}
						onChange={onChange}
						onBlur={() => setShowSearch(false)}
						dropdownMatchSelectWidth={340}
						clearIcon
					/>
					{/* <button disabled={!searchButton} onClick={() => handleSearch()}>GO</button> */}
					{/* <button disabled={!searchButton}>GO</button> */}
				</div>
			) : null}
			{roleName === "Plant Admin" || roleName === "Super Admin" ? (
				<Menu
					onClick={onMenuClick}
					style={{ width: 256 }}
					defaultSelectedKeys={["1"]}
					defaultOpenKeys={["sub1"]}
					mode="inline"
					items={itemsAdmin}
				/>
			) : (
				<Menu
					onClick={onMenuClick}
					style={{ width: 256 }}
					defaultSelectedKeys={["1"]}
					defaultOpenKeys={["sub1"]}
					mode="inline"
					items={items}
				/>
			)}
		</BurgerMenu>
	);
};

export default MobileHeader;
