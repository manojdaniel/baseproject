import unittest
from unittest.mock import Mock, patch

from src.constants.enums import ESummaryStates
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import get_service_job_transactions_details, update_service_job_transaction_status, update_summary_for_entity, fetch_job_id_from_name, fetch_task_id_from_name, fetch_task_id_and_order_from_task_name, \
    create_update_existing_customer_transaction_data, insert_job_transaction_object, update_transaction_data_object, update_transaction_object_in_db
from tests.mocks.random import rand_string


class UpdateSummaryForEntityTestCase(unittest.TestCase):
    def setUp(self):
        self.transaction_data = {
            "summary": {
                # A full dict may be needed to further test
                "rooms": {state.value: [] for state in ESummaryStates}
            }
        }

    """ NOTE: These test cases mimic the current behavior rather than desired. Optimally, these errors must be explicitly passed up the chain """

    def test_empty_transaction_data(self):
        transaction_data = None
        self.assertRaises(TypeError, update_summary_for_entity, transaction_data, "", "", ESummaryStates.NEW)

    def test_invalid_entity_type(self):
        self.assertRaises((KeyError, AttributeError), update_summary_for_entity, self.transaction_data, rand_string(10), "", ESummaryStates.NEW)

    def test_invalid_summary_state(self):
        self.assertRaises((KeyError, AttributeError), update_summary_for_entity, self.transaction_data, "rooms", "", rand_string(10))

    def test_valid_summary_update(self):
        summary = rand_string(10)
        transaction_data = self.transaction_data
        returned_transaction_data = update_summary_for_entity(transaction_data, "rooms", summary, ESummaryStates.NEW)

        self.assertTrue(summary in returned_transaction_data["summary"]["rooms"][ESummaryStates.NEW])
        self.assertDictEqual(returned_transaction_data, transaction_data)

    def test_fetch_job_id_from_name(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "job": [
                {"id": 100}
            ]
        }
        response = fetch_job_id_from_name("job_name", mock_client)
        self.assertEqual(response, 100)

    def test_fetch_job_id_from_name_exception(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "job": []
        }
        self.assertRaises(Exception, fetch_job_id_from_name, 1, mock_client)

    def test_fetch_task_id_from_name(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
                {"id": 100}
            ]
        }
        response = fetch_task_id_from_name("job_name", mock_client)
        self.assertEqual(response, 100)

    def test_fetch_task_id_from_name_exception(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": []
        }
        self.assertRaises(Exception, fetch_task_id_from_name, 1, mock_client)

    def test_fetch_task_id_and_order_from_task_name(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
                {"id": 100, "execution_order": "execution_order"}
            ]
        }
        response = fetch_task_id_and_order_from_task_name("task_name", "job_name", mock_client)
        self.assertEqual(response, (100, 'execution_order'))

    def test_fetch_task_id_and_order_from_task_name_fail(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
            ]
        }
        self.assertRaises(Exception, fetch_task_id_and_order_from_task_name, "task_name", "job_name", mock_client)

    @patch("src.modules.db_operations.management_data_insertion.mgmt_data_insertion.fetch_job_id_from_name", side_effect=lambda job_name, client: "job_id")
    @patch("src.modules.db_operations.management_data_insertion.mgmt_data_insertion.fetch_task_id_from_name", side_effect=lambda job_name, client: "task_id")
    def test_create_update_existing_customer_transaction_data(self, mock_fn1, mock_fn2):
        mock_fn1.return_value = "job_id"
        mock_fn2.return_value = "task_id"
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
            ]
        }
        returned_val = create_update_existing_customer_transaction_data(mock_client)
        self.assertIsNotNone(returned_val)

    def test_insert_job_transaction_object_fail(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
            ]
        }
        self.assertRaises(Exception, insert_job_transaction_object, "operation_type", "job_id", "task_id", "entity_id", "", "idenifier", "transaction_data", "user_uuid", mock_client)

    def test_get_service_job_transactions_details(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "task": [
            ]
        }
        self.assertRaises(Exception, get_service_job_transactions_details, 1, mock_client)

    def test_update_service_job_transaction_status(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "update_rocc_overwatch_service_job_transactions": "success"
        }
        update_status = update_service_job_transaction_status(transaction_id=1, status="active", client=mock_client)
        self.assertRaises(Exception, update_service_job_transaction_status, 1, "abc", {})
        self.assertEqual(update_status, "success")

    def test_update_transaction_data_object(self):
        transaction_data_object = {"jobs": [{"job_id": 1, "status": "status", "tasks": [{"task_id": 100, "status": "", "reason": ""}]}]}
        transaction_data_object = update_transaction_data_object(transaction_data_object, 1, 100, "active", "reason", job_status_update=True)
        self.assertIsNotNone(transaction_data_object)

    def test_update_transaction_object_in_db(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "update_rocc_overwatch_service_job_transactions": "success"
        }
        update_status = update_transaction_object_in_db(1, 100, mock_client, 1)
        self.assertIsNone(update_status)
