/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EConnectionType, EOperationStatus, EPosition } from "@rocc/rocc-client-services"
import { MultiCameraGalleryMessage, RoomBannerUserDetails } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import cx from "classnames"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Icon, Popup } from "semantic-ui-react"
import { displayLoader, initiateNormalConsoleSession } from "../../../common/helpers/consoleUtility"
import { checkIfViewConsoleEnabled, } from "../../../common/helpers/helpers"
import ConsoleTrigger from "../../../ConsoleTrigger"
import { IActiveConsoleSession, IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/translations/en-US"
import styles from "../console-view-banner/ViewConsoleBanner.scss"

const IncognitoConsoleBanner = (props: IActiveConsoleSession) => {
    const {
        consoleSessions, consoleOperation, receivers, permissions
    } = useSelector((state: IStore) => ({
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        permissions: state.externalReducer.permissions
    }))

    const { roomUuid, currentSession, technologistName, rightSidePanel } = props

    const [switchingToView, setSwitchingToView] = useState(false)
    const [loading, setLoading] = useState(false)
    const [enableSwitchToViewButton, setEnableSwitchToViewButton] = useState(true)

    const { intl } = getIntlProvider()
    const consoleSessionsRef = useRef(consoleSessions)

    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    useEffect(() => {
        const { operationStatus, transactions } = consoleOperation
        if (!checkIfViewConsoleEnabled(permissions, receivers)) {
            setEnableSwitchToViewButton(false)
        }
        if (permissions.CONSOLE_VIEW) {
            setEnableSwitchToViewButton(true)
        }
        if (operationStatus !== EOperationStatus.IDLE && transactions.length) {
            setEnableSwitchToViewButton(false)
        } else {
            setLoading(false)
            setEnableSwitchToViewButton(true)
        }
    }, [consoleOperation])

    const dispatch = useDispatch()

    const switchToView = () => {
        setSwitchingToView(true)
        setLoading(true)
        const { receiverName, roomUuid, connectionMode } = currentSession
        const props = {
            consoleSessions, receiverName, roomUuid,
            connectionType: EConnectionType.VIEW, connectionMode, dispatch,
        }
        initiateNormalConsoleSession(props)
    }

    return (
        <div id={"sessionContainer"} className={cx(styles.mainContainer, rightSidePanel && styles.sideBarOpenStyles)}>
            <div className={styles.roomBannerContainer} id="incognitoBannerContainer">
                {loading && displayLoader(false)}
                <RoomBannerUserDetails name={technologistName} />
                <div className={cx(styles.incognitoOptions, switchingToView && styles.disabled)} id="switchToView">
                    <Popup
                        inverted
                        position="bottom right"
                        trigger={
                            <Button className={styles.switchToViewButton} onClick={switchToView} disabled={!enableSwitchToViewButton}>
                                <Icon className="TransferArrows" />
                                <span>{intl.formatMessage({ id: "content.roomBanner.switchToViewMode", defaultMessage: en["content.roomBanner.switchToViewMode"] })}</span>
                            </Button>
                        }
                        content={intl.formatMessage({ id: "content.roomBanner.switchToViewModeDescription", defaultMessage: en["content.roomBanner.switchToViewModeDescription"] })}

                    />
                    <span id="bannerButtons">
                        <ConsoleTrigger
                            connectionType={EConnectionType.INCOGNITO_VIEW}
                            roomUuid={roomUuid}
                            showTitle={true}
                            iconPosition={EPosition.VERTICAL}
                        />
                    </span>

                </div>
            </div>
            <div className={styles.cameraContainer}>
                <MultiCameraGalleryMessage
                    message={<span>{intl.formatMessage({ id: "content.room.noMultiCamera", defaultMessage: en["content.room.noMultiCamera"] })}</span>}
                />
            </div>
        </div>
    )
}

export default IncognitoConsoleBanner
