"""
 Created on Thu Sep 17 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import unittest
from unittest import mock

from src.wrappers.platform_services.iam_service.session_services import fetch_access_token, fetch_device_access_token, revoke_access_token
from tests.mocks.mock_requests import MockResponse


def mocked_requests(*args, **kwargs):
    switcher = {
        "/session_url/philips/rocc/sessionmgmt/Session": MockResponse({"key1": "value1"}, 200),
        "/session_url/philips/rocc/sessionmgmt/Session/session_id": MockResponse(None, 200),
        "/session_url/philips/rocc/sessionmgmt/DeviceSession": MockResponse(None, 200)
    }

    return switcher.get(args[0], MockResponse(None, 200))


class TestSessionServices(unittest.TestCase):

    @mock.patch("src.wrappers.platform_services.iam_service.session_services.requests.post", side_effect=mocked_requests)
    def test_fetch_access_token(self, mock_post):
        response = fetch_access_token("/session_url", "user", "pwd")
        self.assertEqual(response["status"], 200)

    @mock.patch("src.wrappers.platform_services.iam_service.session_services.requests.delete", side_effect=mocked_requests)
    def test_revoke_access_token(self, mock_post):
        response = revoke_access_token("/session_url", "session_id", "token")
        self.assertEqual(response, "204")
    
    @mock.patch("src.wrappers.platform_services.iam_service.session_services.requests.post", side_effect=mocked_requests)
    def test_fetch_device_access_token(self, mock_post):
        response = fetch_device_access_token("/session_url", "device_id")
        self.assertEqual(response["status"], 200)


suite = unittest.TestSuite()

suite.addTest(TestSessionServices("test_fetch_access_token"))
suite.addTest(TestSessionServices("test_revoke_access_token"))
suite.addTest(TestSessionServices("test_fetch_device_access_token"))

unittest.TextTestRunner(verbosity=0).run(suite)
