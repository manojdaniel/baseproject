import { ModalityConnection, IModalityConnectionParam, IModalityConnection, ConnectionUtility, EModalityConnectionMode } from '@rocc/rocc-rconnect-common-js-sdk'
import { FeatureFlagHelper, ROCC_FEATURES, EConnectionMode, IConsoleSession, ETransactionStatus, getRoomDetailFromUuid } from "@rocc/rocc-client-services"
import { IConsoleOperation } from "../../redux/interfaces/types"
import store from "../../redux/store/store"
import { displayEditToViewSwitchMessage, displayErrorModal, displayNotificationMessage, fetchCallContextForRoomUuid, getCallContextByContactUuid, getPidFromContextMapping, hasActiveVidoCallWithRoom, messageViewToEdit, shouldUsePID } from "./helpers"
import { dispatchToParentStore, fetchGlobalConfigs, fetchGlobalFeatureFlags, fetchGlobalOrgUUID, fetchGlobalURLs, fetchRooms } from "../../redux/store/externalAppStates"
import { resetConsoleSession, setConsoleOperations, updateConsoleSession, updateSpecificDataToTransactionGroup } from "../../redux/actions/consoleActions"
import { ThunkDispatch } from "redux-thunk"
import { AnyAction } from "redux"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { checkIfMultiEditFeatureExist, checkIfPresignedJwtFeatureEnabled, checkToAllowMultiEdit, checkToAllowParkResume, handleMaxLimitNFCCConnectionReached, registerMultiEditWorkflow, registerSeamlessEditWorkflow } from "./consoleUtility"
import { getIntlProvider } from '@rocc/rocc-global-components'
import en from 'react-intl/locale-data/en'


const getCurrentUser = () => {
    return store.getState().externalReducer.currentUser
}

const getOperation = () => {
    return store.getState().consoleReducer.consoleOperation
}

const onOperationChange = (operation: IConsoleOperation) => {
    const thunkDispatch = store.dispatch as ThunkDispatch<{}, {}, AnyAction>
    thunkDispatch(setConsoleOperations(operation))
}

const onLogUpdate = (data: any) => {
    sendLogsToAzure(data)
}

const getSessions = () => {
    return store.getState().consoleReducer.consoleSessions
}

const onSessionReset = (data: any) => {
    const thunkDispatch = store.dispatch as ThunkDispatch<{}, {}, AnyAction>
    thunkDispatch(resetConsoleSession(data))
}

const onSessionUpdate = (data: any, state: boolean, state2?: boolean) => {
    const thunkDispatch = store.dispatch as ThunkDispatch<{}, {}, AnyAction>
    thunkDispatch(updateConsoleSession(data, state, state2))
}

const getSeatName = () => {
    return store.getState().consoleReducer.commandCenterDetails.commandCenterSeat.seatName
}

const onError = (message?: string, isHeaderRequired?: boolean) => {
    // Here localization requires to be added for the message
    let transformedMessage = message
    if (message) {
        const { intl } = getIntlProvider()
        transformedMessage = intl.formatMessage({
            id: message,
            defaultMessage: en[message as any]
        })
    }
    displayErrorModal(transformedMessage, isHeaderRequired)
}

const isMultiVendorEnabled = () => {
    return FeatureFlagHelper.isFeatureEnabled(fetchGlobalFeatureFlags(), ROCC_FEATURES.ROCC_MULTI_KVM_VENDOR, true)
}

const getCallContextForRoomUuid = (roomUuid: string) => fetchCallContextForRoomUuid(roomUuid)

const onUpdateAllActiveTransactionGroup = (key: any, value: any, groupId: any) => {
    const thunkDispatch = store.dispatch as ThunkDispatch<{}, {}, AnyAction>
    thunkDispatch(updateSpecificDataToTransactionGroup(key, value, groupId))
}

const getReceivers = () => {
    return store.getState().consoleReducer.commandCenterDetails.commandCenterSeat.receivers
}

const onGlobalUserEvents = (data: any) => {
    dispatchToParentStore(data)
    return true
}


const onIsSwitchConsole = () => {
    displayEditToViewSwitchMessage()
}

interface IHandleStartEditing {
    consoleSessions: IConsoleSession[]
    roomUuid: string
    componentName: string
    connectionMode: EConnectionMode
    receiverName: string
    postTransactionHook?: (isSuccess: boolean, failStatus?: ETransactionStatus) => any
}

const handleStartEditingWrapper = (props: IHandleStartEditing) => {
    if (checkToAllowMultiEdit()) {
        registerMultiEditWorkflow(props)
    } else if (checkToAllowParkResume()) {
        registerSeamlessEditWorkflow(props)
    } else {
        return true
    }
    return false
}


const onActiveSessionWithSameRoom = (roomUuid: string, hasActiveVideoCall: boolean) => {
    const message = messageViewToEdit()
    if (hasActiveVideoCall) {
        message.splice(1, 1)
    }
    const customStyle = { top: "1rem", right: "1rem", width: "29.25rem", height: message.length > 1 && "18.063rem" }
    displayNotificationMessage(message, customStyle, false, true, false)
}

const getConnectionInfoForRoom = (roomUuid: string, connectionMode: EModalityConnectionMode) => {
    const availableConnections = connectionUtility.createConnectionList(getRoomDetailFromUuid(fetchRooms(), roomUuid), {
        username: store.getState().externalReducer.currentUser.kvmUsername,
        seatname: store.getState().consoleReducer.commandCenterDetails.commandCenterSeat.seatName
    })
    console.log("prathik:imp available connection",availableConnections,roomUuid ,connectionMode)
    const conn = availableConnections.filter((connection) => connection.connectionMode == connectionMode)[0]
    console.log("prathik:imp filtered connection",conn)
    return conn
}

let connection: IModalityConnection

export const connectionUtility = new ConnectionUtility()

export const initConnectionAdapter = () => {
    const { MAX_NUM_OF_CONSOLE_SESSION, MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE } = fetchGlobalConfigs()
    const params: IModalityConnectionParam = {
        getUrls: fetchGlobalURLs,
        getPidFromContextMapping: getPidFromContextMapping,
        onOperationChange: onOperationChange,
        getOperation: getOperation,
        onLogUpdate: onLogUpdate,
        // Sessions
        getSessions: getSessions,
        onSessionReset: onSessionReset,
        onSessionUpdate: onSessionUpdate,
        // User
        getCurrentUser: getCurrentUser,
        getSeatName: getSeatName,
        onError: onError,
        isMultiVendorEnabled: isMultiVendorEnabled,
        getCallContextForRoomUuid: getCallContextForRoomUuid,
        getCallContextByContactUuid: getCallContextByContactUuid,
        onUpdateAllActiveTransactionGroup: onUpdateAllActiveTransactionGroup,
        shouldUsePID: shouldUsePID,
        checkIfPresignedJwtFeatureEnabled: checkIfPresignedJwtFeatureEnabled,
        onTransactionWaitStateChange: undefined,
        getGlobalOrgUUID: fetchGlobalOrgUUID,
        multiEditFeatureExist: checkIfMultiEditFeatureExist(),
        getReceivers: getReceivers,
        maxNumOfConsoleSessions: MAX_NUM_OF_CONSOLE_SESSION,
        maxNumofNFCCSessionWithHardware: MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE,
        maxNumofNFCCSessionWithoutHardware: MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE,
        onMaximumNFCCConnectionReached: handleMaxLimitNFCCConnectionReached,
        onHandlePreEditConnection: handleStartEditingWrapper,
        hasActiveVideoCallWithRoom: (roomUuid: string) => hasActiveVidoCallWithRoom(roomUuid) as boolean,
        onActiveSessionWithSameRoom: onActiveSessionWithSameRoom,
        onGlobalUserEvents: onGlobalUserEvents,
        onIsSwitchConsole: onIsSwitchConsole,
        getConnectionInfoForRoom: getConnectionInfoForRoom
    }
    connection = new ModalityConnection(params) as IModalityConnection
    return connection
}

export const getConnectionAdapter = () => {
    return connection
}
