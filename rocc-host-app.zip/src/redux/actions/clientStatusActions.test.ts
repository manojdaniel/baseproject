/*
 * Created on Thu May 26 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import { SET_APPILICATION_CONNECTION_STATE, GLOBAL_UPDATE_CHAT_CLIENT_STATUS, VERIFY_CURRENT_USER_PRESENCE } from "./types"
import { initialStatesForClientStatus } from "../reducers/clientStatusReducer"
import { checkInternetConnectionState, setChatClientStatus, verifyCurrentUserPresence } from "./clientStatusActions"
import { EConnectionStatus, EUserPresence } from "@rocc/rocc-client-services"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

describe("Client status actions", () => {
    const store = mockStore(initialStatesForClientStatus)

    afterEach(() => {
        store.clearActions()
    })

    it("should dispatch an action to SET_APPILICATION_CONNECTION_STATE", () => {
        store.dispatch(checkInternetConnectionState(EConnectionStatus.AVAILABLE) as any)
        expect(String(store.getActions()[0].type)).toBe(SET_APPILICATION_CONNECTION_STATE)
    })
    it("should dispatch an action to SET_CHAT_CLIENT_STATUS", () => {
        store.dispatch(setChatClientStatus(EConnectionStatus.AVAILABLE) as any)
        expect(String(store.getActions()[0].type)).toBe(GLOBAL_UPDATE_CHAT_CLIENT_STATUS)
    })
    it("should dispatch an action to VERIFY_CURRENT_USER_PRESENCE", () => {
        store.dispatch(verifyCurrentUserPresence(EUserPresence.AVAILABLE) as any)
        expect(String(store.getActions()[0].type)).toBe(VERIFY_CURRENT_USER_PRESENCE)
    })
})
