"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import traceback

from gql import Client
from gql.transport.requests import RequestsHTTPTransport

from src.loggers.log import create_logger
from src.constants.constants import APPLICATION_JSON, AUTHORIZATION, CONTENT_TYPE, ORG_CTXT_HEADER, ROCC_PROXY_URL

LOG = create_logger("Connection")


def generate_org_ctxt_header(org_infra_uuid):
    if org_infra_uuid is None:
        return None
    return '{"Org-Id": "' + org_infra_uuid + '"}'


def get_client_connection(access_token, org_infra_uuid, url=None, is_fse=False):
    org_ctxt = generate_org_ctxt_header(org_infra_uuid)
    try:
        url = url if url else os.environ.get(ROCC_PROXY_URL, "")
        headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: access_token, ORG_CTXT_HEADER: org_ctxt}
        if is_fse:
            headers["FSE"] = "true"
        client = Client(
            transport=RequestsHTTPTransport(
                url=f"{url}/v1/graphql",
                use_json=True,
                headers=headers,
            ),
            fetch_schema_from_transport=True,
        )
        return client
    except Exception as ex:
        LOG.error(f"Failed to setup graphql client with error: {ex}")
        LOG.error(traceback.print_exc())


def get_client_local_connection(access_token, url=None):
    try:
        client = Client(
            transport=RequestsHTTPTransport(
                url="{}/v1/graphql".format("http://host.docker.internal:8081"),
                use_json=True,
                headers={"X-Hasura-Access-Key": "1234"},
            ),
            fetch_schema_from_transport=True,
        )
        return client
    except Exception as ex:
        LOG.error(ex)
        LOG.error(traceback.print_exc())