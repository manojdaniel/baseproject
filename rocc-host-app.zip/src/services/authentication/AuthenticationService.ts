/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { CONTENT_TYPE, APPLICATION_JSON, HTTP_STATUS, AUTHORIZATION, API_VERSION, API_VERSION_2, DEFAULT_API_VERSION, displayLoginErrorMessages } from "../../constants/constants"
import { isDev } from "../../utility/storage/storageUtility"
import { SERVER_LOGIN, PHILIPS_API_URI, FORGOT_PWD_EP, SET_PWD_EP, LOGIN_ACCESS_URI } from "../../constants/endpoints"
import { IForgotPasswordWrapper, ILoginWrapper } from "@rocc/rocc-authentication-components"
import { ELoadTimes, ELOGIN_STATUS, ILoginState } from "../../types/types"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { setForceCleanUp, setPermissionlist, setSessionDetails, updateAppState, updateRefreshToken } from "../../redux/actions/userAction"
import { getReduxState, loginErrorMessages } from "../../utility/helpers/helpers"
import { postCall, putCall } from "../../utility/api/apiUtility"
import { captureLoadTimes, setFseMode } from "../../redux/actions/appActions"
import { LOGIN_SUCCESS, SET_APPSTATE } from "../../redux/actions/types"
import { EAppStates, EResponse } from "@rocc/rocc-client-services"
import { setCustomerOrgId } from "../../redux/actions/customerActions"
import { setConfigs, setUrls } from "../../redux/actions/configActions"
import { setDefaultFeatureFlags, setFeatureFlagConfig } from "../../redux/actions/featureFlagsActions"
import { loginTransformer } from "../../transformers/loginTransformer"
import store from "../../redux/store/store"

export const loginService = async (props: ILoginWrapper): Promise<ILoginState> => {
    const { loginUserName, loginUserKey, codeGrant, redirectUrl } = props
    const loginUrl = isDev() ? `${process.env.ROCC_PROXY_URL}${SERVER_LOGIN}` : SERVER_LOGIN
    try {
        const params = {
            url: loginUrl,
            body: {
                loginUserName,
                loginUserKey,
                codeGrant,
                redirectUrl,
            },
            headers: {
                [CONTENT_TYPE]: APPLICATION_JSON,
                [API_VERSION]: codeGrant ? API_VERSION_2 : DEFAULT_API_VERSION
            }
        }
        const response = await postCall(params)
        if ([HTTP_STATUS.OK, HTTP_STATUS.CREATED].includes(response.status)) {
            response.data.loginResponse.username = loginUserName
            return {
                status: ELOGIN_STATUS.SUCCESS,
                statusCode: response.status,
                data: response.data
            }
        }
        else {
            return {
                status: ELOGIN_STATUS.FAILED,
                statusCode: response.status,
                data: response.data
            }
        }
    } catch (error: any) {
        errorLogger(`User failed to login with error: ${errorParser(error)}`)
        return error.response
    }
}

export const forgotPasswordService = async (props: IForgotPasswordWrapper): Promise<any> => {
    let url = isDev() ? `${process.env.ROCC_PROXY_URL}` : ""
    url = `${url}${PHILIPS_API_URI}${FORGOT_PWD_EP}`
    const { email } = props
    try {
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
        }
        const response = await postCall({
            headers,
            url,
            body: { emailId: email },
        })
        infoLogger(`Triggered reset password flow.`)
        return response
    } catch (error: any) {
        errorLogger(`Failed to reset password for the user with Error: ${errorParser(error)}`)
        return error.response
    }
}

export const setPasswordService = async (email: string, password: string, confirmationCode: any, context: string): Promise<any> => {
    let url = `${isDev() ? process.env.ROCC_PROXY_URL : ""}`
    url = `${url}${PHILIPS_API_URI}${SET_PWD_EP}`
    try {
        const headers = {
            [CONTENT_TYPE]: APPLICATION_JSON,
        }
        const response = await postCall({
            headers,
            url,
            body: { emailId: email, confirmationCode, newPwd: password, context },
        })
        infoLogger(`Password set successfully.`)
        return response
    } catch (error: any) {
        errorLogger(`Failed to set password with Error: ${errorParser(error)}`)
        return error.response
    }
}

export const getUserAccessToken = () => {
    const state = store.getState()
    return state.userReducer.currentUser.accessToken
}

export const checkAndRefreshToken = async (props: IRefreshTokenProps) => {
    const currentAccessToken = getUserAccessToken()
    if (currentAccessToken !== props.token) {
        infoLogger(`Provided token doesn't match with existing token`)
        return currentAccessToken
    }
    return refreshAccessToken(props)

}

interface IRefreshTokenProps {
    token: string
    sessionId: string
    authUrl: string
    dispatch: Dispatch<any>
}

const refreshAccessToken = async (props: IRefreshTokenProps) => {
    const { token, sessionId, authUrl, dispatch } = props
    try {
        const response: any = await putCall({
            url: `${authUrl}${LOGIN_ACCESS_URI}${sessionId}`,
            data: {},
            headers: {
                [CONTENT_TYPE]: APPLICATION_JSON,
                [AUTHORIZATION]: token,
            },
        })
        const { accessToken, expiryTime } = response.data
        dispatch(updateRefreshToken(accessToken, expiryTime))
        updateForceCleanUp(false, dispatch)
        return accessToken
    } catch (error) {
        errorLogger(`Refresh token failed with: ${errorParser(error)}`)
        // Check if token is refreshed by any other request or not. If yes, then don't update forceCleanUp and return updated Access token
        const currentAccessToken = getUserAccessToken()
        if (currentAccessToken !== token) {
            infoLogger(`AuthenticationService: Provided access token was not latest, returning latest token to the caller`)
            return currentAccessToken
        }
        updateForceCleanUp(true, dispatch)
    }
}

const updateForceCleanUp = (value: boolean, dispatch: Dispatch<any>) => {
    const { forceCleanUp } = getReduxState().userReducer
    if (forceCleanUp !== value) {
        dispatch(setForceCleanUp(value))
    }
}

export const loginHandler = async (props: ILoginWrapper, dispatch: any) => {
    const { WRONG_USER_CREDENTIALS, DEFAULT_MESSAGE, NETWORK_CONNECTIVITY, FORBIDDEN } = displayLoginErrorMessages
    dispatch(captureLoadTimes(ELoadTimes.LOGIN_CLICK))
    dispatch({ type: SET_APPSTATE, appState: EAppStates.LOADING })
    const response = await loginService(props)
    if (response && response.data && response.data.loginResponse) {
        const { session, configs, urls, computedUserPermissions, featureFlagConfig, defaultFeatureFlags, allOrgList, isProxy } = loginTransformer(response)
        dispatch(setSessionDetails(session))
        let fseData = { isFse: false, customerName: "", customerOrgId: "" }
        if (allOrgList && allOrgList.length > 1) {
            fseData = setFseMode(allOrgList, isProxy, dispatch)
        }
        const orgInfraUuid = fseData && fseData.customerOrgId ? fseData.customerOrgId : session.orgInfraUuid
        setCustomerOrgId(orgInfraUuid, dispatch)
        dispatch(setUrls(urls))
        dispatch(setConfigs(configs))
        dispatch(setPermissionlist(computedUserPermissions))
        dispatch(setDefaultFeatureFlags(defaultFeatureFlags))
        dispatch(setFeatureFlagConfig(featureFlagConfig))
        dispatch({ type: LOGIN_SUCCESS, appState: EAppStates.LOGIN_SUCCESS })
    } else {
        let errorMessage = loginErrorMessages(DEFAULT_MESSAGE)
        if (response && response.status && response.data.httpStatusCode === HTTP_STATUS.BAD_REQUEST) {
            errorMessage = loginErrorMessages(WRONG_USER_CREDENTIALS)
        } else if (response && response.status && response.data.httpStatusCode === HTTP_STATUS.FORBIDDEN) {
            errorMessage = loginErrorMessages(FORBIDDEN)
        } else {
            errorMessage = (response && response.data && response.data.defaultMessage) ?
                response.data.defaultMessage :
                (window.navigator.onLine ? errorMessage : loginErrorMessages(NETWORK_CONNECTIVITY))
        }
        dispatch(updateAppState(EAppStates.LOGIN_FAILED, EResponse.ERROR, errorMessage))
        infoLogger(`Failed to login for the user`)
    }
    return response
}
