# ROCC - Home Micro Frontend (MFE)

![master](https://github.com/philips-internal/rocc-cc-home-app/actions/workflows/master.yml/badge.svg)
![tag](https://github.com/philips-internal/rocc-cc-home-app/actions/workflows/tag.yml/badge.svg)
![pr-apps-deletion](https://github.com/philips-internal/rocc-cc-home-app/actions/workflows/pr-apps-deletion.yml/badge.svg)
![blackduck](https://github.com/philips-internal/rocc-cc-home-app/actions/workflows/blackduck.yml/badge.svg)
<a href=https://codescene.ta.philips.com/1608/analyses/latest/dashboard> <img src="https://codescene.com/status/analyzed-by-codescene-badge.svg" width="130"></a>
This repo is one of the child MFE app which has the IDN list and its corresponding Rooms view with Room card.
It includes Web call, Phone call, Console session viewing, incognito viewing and protocol mangement features for both fixed command center and non fixed command center connection types integrated into the Room card.

The following Child MFE features are integrated with Home
 - Calling App
 - Console App

This repo comes with the following features
 - Linting Per ROCC
 - Unit tests
 - Husky
 - MS Application Insights
 - PDV Toolkit
 - Cloud/PR Scripts
 - Webpack Module Federation https://webpack.js.org/concepts/module-federation/ 

# Setting up in local

 ## Pre-requisites
  - node (v14.17.3)
  - npm (6.14.13)
  - nginx (latest)
  
 ## Cloning
 - Create a Personal Access Token (PAT) - https://github.com/settings/tokens  (one time activity)
 - Use the following command to clone the repo
   - `git clone --recursive https://<<PAT>>:x-oauth-basic@github.com/philips-internal/rocc-cc-home-app.git`

 ## Update npm config

 - `npm config set @vip:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @dls-pdv:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @rocc:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`

 ## Install

 - `npm install`

 ## Running

 - `npm start`. This will build and serve the app on port 8080.
  
 - Alternatively,
    - `npm build`
    - `npm serve`

## Nginx Config for local development

 - donwload and install Nginx in your local (http://nginx.org/en/download.html)
 - Sample config 
        
        server {
            listen       9090;
            server_name  localhost;
            
            location ~^/app/scheduler/(.*) {
                proxy_pass  http://127.0.0.1:7776/$1;
                proxy_http_version 1.1;
            }

            location ~^/app/self-service-home/(.*) {
                proxy_pass  http://127.0.0.1:7775/$1;
                proxy_http_version 1.1;
            }

            location ~^/app/home/(.*) {
                proxy_pass  http://127.0.0.1:7774/$1;
                proxy_http_version 1.1;
            }

            location ~^/app/console/(.*) {
                proxy_pass  http://127.0.0.1:7773/$1;
                proxy_http_version 1.1;
            }

            location ~^/app/calling/(.*) {
                proxy_pass  http://127.0.0.1:7772/$1;
                proxy_http_version 1.1;
            }

            location ~^/app/admin/(.*) {
                proxy_pass  http://127.0.0.1:7771/$1;
                proxy_http_version 1.1;
            }

            location / {
                gzip_static on;
                proxy_pass "http://localhost:8080";
                proxy_http_version 1.1;
            }
        }

If you are testing the CC host MFE with all the child MFE applications locally, please make sure to update the "port" property inside the "devServer" object of the individual MFE applications.

For example, as per the above nginx local config, to test the home MFE application locally, update the port in the webpack.config.js file like below:
    
        devServer: {
            contentBase: path.join(__dirname, "dist"),
            port: 7774,
        },

        Note : Running ROCC CC HOST app is required, as its the parent app but all other child MFEs in local are not mandatory. Child MFEs can be refered with the dev urls
  

### Run the applicaiton in the browser http://localhost:9090

