/*
 * Created on Tue Sept 21 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mount } from "enzyme"
import * as reactTimerHook from "react-timer-hook"
import RoccTimer from "./RoccTimer"
import React from "react"

describe("Rocctimer tests", () => {
    let wrapper: any
    const timerResult = { hours: 1, minutes: 10, seconds: 2, days: 0, isRunning: true, start: jest.fn(), pause: jest.fn(), reset: jest.fn() }
    it("display Timer with hour", () => {
        jest.spyOn(reactTimerHook, "useStopwatch").mockReturnValue(timerResult)
        wrapper = mount(<RoccTimer />)
        expect(wrapper.find("span")).toHaveLength(1)
    })

    it("display Timer without hour", () => {
        timerResult.hours = 0
        jest.spyOn(reactTimerHook, "useStopwatch").mockReturnValue(timerResult)
        wrapper = mount(<RoccTimer />)
        expect(wrapper.find("span")).toHaveLength(1)
    })
})
