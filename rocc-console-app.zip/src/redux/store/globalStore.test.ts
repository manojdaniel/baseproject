/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import globalStore from "./globalStore"

describe("Unit tests for Global Store", () => {

    it("Should initialize global store", () => {
        expect(globalStore).toBeDefined()
    })
})
