/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as externalAppStates from "../../redux/store/externalAppStates"
import { getRoomCardProps } from "./RoomCardHelper"
import * as helpers from "../../common/helpers/helpers"
import { EUserPresence } from "@rocc/rocc-client-services"

jest.mock("@rocc/rocc-client-services", () => ({
    ...jest.requireActual("@rocc/rocc-client-services"),
    getUserByUUID: jest.fn().mockReturnValue({
        id: "id", name: "name"
    })
}))

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        externalReducer: {
            permissions: {
                RESOURCE_STARRED_ROOMS: true
            }
        }
    })
}))

const room: any = {
    identity: { id: 1, uuid: "uuid", name: "name" },
    loggedInTech: "loggedInTech",
    isRoomStarred: true,
    modality: "mr",
    presenceData: { presence: EUserPresence.OFFLINE }
}

describe("getRoomCardProps tests", () => {
    const props: any = {
        rooms: [room],
        flags: {
            "rocc-multi-console": true, "rocc-protocol-transfer": true, "rocc-cc-star-room": true,
        },
        activeSessions: [{ roomUuid: "roomUuid", connectionType: "VIEW", connectionMode: "CC", receiverName: "receiverName" }],
        protocolTransferStatus: true,
        ptCompletedDestinations: "",
        phoneCallStatus: "calling",
        videoCallStatus: []
    }
    it("should return roomsList", () => {
        const spy = jest.spyOn(externalAppStates, "fetchGlobalContacts").mockReturnValue([])
        jest.spyOn(externalAppStates, "fetchGlobalAppVersion").mockReturnValue("")
        jest.spyOn(helpers, "checkIfMultiEditWithoutParkResumeFeatureEnabled").mockReturnValue(false)
        jest.spyOn(externalAppStates, "fetchGlobalReceivers").mockReturnValue([
            {
                id: 248,
                receiverName: 'receiverName',
                monitorName: '2',
                isSelected: false
            },
            {
                id: 249,
                receiverName: 'Test_VER_RX',
                monitorName: 'Monitor 1',
                isSelected: false
            }
        ])
        getRoomCardProps(props)
        expect(spy).toBeDefined()
    })
})
