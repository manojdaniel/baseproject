/*
 * Created on Mon May 02 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { defineMessages, IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import { EN_LOCALE, EN_LANGUAGE } from "./common/constants/constants"
import { isDev } from "./common/helpers/helpers"
import RoomMonitoringWindow from "./components/room-monitoring/RoomMonitoringWindow"

import store, { persistor } from "./redux/store/store"
import messages from "./resources/translations/messages"

const RoomMonitoringWindowFeature = () => {
    useEffect(() => {
        setupLogger({ isDev: isDev() })
    }, [])
    const httpClient = useRoccHttpClient()

    const componentToLoad = () => {
        const locale = sessionStorage.getItem("locale")
        const language = sessionStorage.getItem("language")
        const defaultMessage = (locale: string) => defineMessages(messages[locale])
        const defaultLocale = language || EN_LOCALE
        return (
            <HttpClientProvider client={httpClient}>
                <IntlProvider
                    defaultLocale={defaultLocale}
                    locale={defaultLocale}
                    messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
                >
                    <>
                        <RoomMonitoringWindow />
                    </>
                </IntlProvider>
            </HttpClientProvider>
        )
    }
    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                {componentToLoad()}
            </PersistGate>
        </Provider>
    </>
}

export default RoomMonitoringWindowFeature
