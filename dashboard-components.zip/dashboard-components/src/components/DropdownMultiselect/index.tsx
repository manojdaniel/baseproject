import React from "react";
import { default as ReactSelect } from "react-select";
import { components } from "react-select";

interface Props {
	options?: any;
	handleChange?: any;
	value?: any;
	defaultValue?: any;
	multi?: any;
	name?: any;
	loading?: any
}

const Option = (props: any) => {
	return (
		<>
			<components.Option {...props}>
				<input
					type="checkbox"
					checked={props.isSelected}
					onChange={() => null}
				/>{" "}
				<label>{props.label}</label>
			</components.Option>
		</>
	);
};

const DropdownMultiselect = ({ options, handleChange, value, name, loading }: Props) => {
	return (
		<>
			<ReactSelect
				id="sd_plot_multiselect"
				styles={{
					option: (provided) => ({
						...provided,
						color: "black",
					}),
					valueContainer: (provided) => ({
						...provided,
						height: "30px",
						width: "70px",
						padding: "0 6px",
					}),
				}}
				placeholder={name}
				options={options}
				isMulti
				closeMenuOnSelect={true}
				//menuIsOpen={true}
				hideSelectedOptions={false}
				components={{
					Option,
				}}
				onChange={handleChange}
				// allowSelectAll={true}
				value={value}
				isLoading={loading}
			/>
		</>
	);
};

export default DropdownMultiselect;
