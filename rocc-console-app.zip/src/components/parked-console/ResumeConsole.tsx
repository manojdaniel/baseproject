/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionState, EPosition, IConsoleSession, REGISTER_WORKFLOW, ERoccWorkflow } from "@rocc/rocc-client-services"
import { ConsoleOperations, EIconType } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { TRACKED_WORKFLOWS } from "../../common/constants/constants"
import { getConnectionAdapter } from "../../common/helpers/connection"
import { checkIfParkedConsoleEnabled } from "../../common/helpers/helpers"
import { transformSessionTypeForAnalytics } from "../../common/helpers/TelemetryTrackingHelper"
import { IReceiverSelectionModal, IStore, IWorkflowInfo } from "../../redux/interfaces/types"
import { dispatchToParentStore } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"

interface IResumeConsole {
    roomUuid: string
    showTitle?: boolean
    iconPosition?: EPosition
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    component?: string
}

const ResumeConsole = (props: IResumeConsole) => {

    const { roomUuid, showTitle, iconPosition } = props
    const {
        featureFlags,
        consoleSessions,
        commandCenterSeat,
        consoleOperation,
        protocolTransferStatus,
        workflows,
        currentUser,
    } = useSelector((state: IStore) => ({
        commandCenterSeat: state.consoleReducer.commandCenterDetails.commandCenterSeat,
        featureFlags: state.externalReducer.featureFlags,
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        workflows: state.externalReducer.workflows.filter(
            (workflow: IWorkflowInfo) => TRACKED_WORKFLOWS.includes(workflow.type)
        ),
        currentUser: state.externalReducer.currentUser,
    }))

    const { intl } = getIntlProvider()

    const [dropdownOptions, setDropdownOptions] = useState([] as any)
    const [loading, setLoading] = useState(false)
    const [disabled, setDisabled] = useState(false)
    const [connectionState, setConnectionState] = useState(false)
    const consoleSessionsRef = useRef(consoleSessions)
    const currentSessionRef = useRef(undefined as IConsoleSession | undefined)

    const componentName = "Parked Console"
    const { PARKED } = EConnectionState
    const { HORIZONTAL } = EPosition
    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
        currentSessionRef.current = consoleSessions.find(session => session.roomUuid === props.roomUuid && session.connectionStatus === PARKED)
    }, [consoleSessions])

    const handleParkedConsoleSession = () => {
        if (currentSessionRef.current) {
            const { contextId, requester, connectionMode } = currentSessionRef.current
            infoLogger(`${componentName} Resume console session ${contextId} for user ${requester}`)
            const context = getConnectionAdapter().getParkedConnectionContext({ currentSession: currentSessionRef.current, consoleSessions: consoleSessionsRef.current })
            dispatchToParentStore({ type: REGISTER_WORKFLOW, payload: { type: ERoccWorkflow.PARK_AND_RESUME, context, } })
            sendLogsToAzure({ contextData: { component: componentName, event: `Edit Console: Park and Resume Console`, source: transformSessionTypeForAnalytics(connectionMode), eventBy: currentUser.uuid, Call_To: roomUuid, Call_From: currentUser.uuid } })
            return
        }
        errorLogger(`Failed to resume session since there is no active parked session for room ${roomUuid}`)
    }

    useEffect(() => {
        const getParkedOptions = []
        if (checkIfParkedConsoleEnabled(currentSessionRef.current)) {
            getParkedOptions.push({
                key: getParkedOptions.length,
                value: intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] }),
                className: "About",
                handlerFunction: handleParkedConsoleSession
            })
        }

        setDropdownOptions(getParkedOptions)
    }, [featureFlags, commandCenterSeat, currentSessionRef.current])

    useEffect(() => {
        const { connectionState, loading, disabled } = getConnectionAdapter().getResumeConsoleStatus({
            consoleOperation, roomUuid, workflows,
        })
        setLoading(loading)
        setDisabled(disabled)
        setConnectionState(connectionState)
    }, [consoleOperation, consoleSessionsRef.current, protocolTransferStatus, workflows])

    const startViewing = intl.formatMessage({ id: "content.consoleMessages.resumeEditing", defaultMessage: en["content.consoleMessages.resumeEditing"] })
    if (!currentSessionRef.current) {
        return <></>
    }
    return (
        <ConsoleOperations
            consoleOperationProps={{
                start: {
                    icon: EIconType.RESUME_ICON,
                    type: PARKED,
                    title: startViewing
                },
                stop: {
                    icon: EIconType.RESUME_ICON,
                    type: PARKED,
                    title: startViewing
                }
            }}
            loading={loading}
            disabled={disabled}
            connectionState={connectionState}
            dropdownOptions={dropdownOptions}
            iconPosition={iconPosition ? iconPosition : HORIZONTAL}
            showTitle={showTitle ?? false}
            stopConsoleOperationHandler={handleParkedConsoleSession} showToolTip={false} tooltipMessage={""}
        />
    )
}

export default ResumeConsole
