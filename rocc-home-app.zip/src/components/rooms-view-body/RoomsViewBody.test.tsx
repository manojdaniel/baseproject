/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { mockedGlobalStore } from "../../mocks/mock-data"
import { shallow } from "enzyme"
import React from "react"
import { RoomsViewBody } from "./RoomsViewBody"
import { IRoomCard } from "../../lib/types"
import { EUserPresence, ERoomStatus } from "@rocc/rocc-client-services"

const roomCard: IRoomCard = {
  roomIdentity: {
    uuid: "e404fb07-1e53-4183-ad8b-5e6a48271234",
    name: "CT Scanner-018",
    address: "Oncology Department",
    id: 4
  },
  isStarred: true,
  modalityProps: {
    modalityName: "MR",
    modalityStyles: "",
  },
  userNameProps: {
    techUserName: "Sunita Chawla",
    techUserId: "2651258a-66d4-4721-ba54-a8e85667db11"
  },
  flags: {
    isMultiConsoleFlagEnabled: false,
    isRoomActiveSession: false,
    protocolTransferFlagEnabled: true,
    isStarredFlagEnabled: true
  },
  connectionProps: {
    connectionType: "VIEW",
    connectionMode: "COMMANDCENTER"
  },
  protocolTransferReducerProps: {
    protocolTransferStatus: false,
    completedDestinations: false
  },
  monitorName: "1",
  roomStatus: ERoomStatus.IDLE,
  footerProps: {
    phoneNumbers: [
      "1234567890"
    ],
    roomUuid: "1",
    isDisabled: false,
    modalityName: "CT",
    presence: EUserPresence.OFFLINE,
    roomName: "",
  }
}
const starredRoomsList: IRoomCard[] = [roomCard]

const room1 = roomCard
room1.roomIdentity = { ...roomCard.roomIdentity, uuid: "e404fb07-1e53-4183-ad8b-5e6a4827abcd", name: "MRI Scanner-020", }
room1.isStarred = false
room1.flags.isStarredFlagEnabled = false

const room2 = roomCard
room2.roomIdentity = { ...roomCard.roomIdentity, uuid: "e404fb07-1e53-4183-ad8b-5e6a4827abe1", name: "MRI Scanner-018", }
room2.isStarred = false

const otherRoomsList: IRoomCard[] = [room1, room2]

jest.mock("redux-micro-frontend", () => {
  return mockedGlobalStore
})
jest.mock("react-redux", () => ({
  useSelector: () => ({
    permissions: {
      RESOURCE_STARRED_ROOMS: true
    }
  }),
}))

describe("Rooms View Body", () => {
  let wrapper: any
  it("should render rooms view body with starred and unstarred rooms", () => {
    wrapper = shallow(<RoomsViewBody allRoomsList={[]} starredRoomsList={starredRoomsList} otherRoomsList={otherRoomsList} />)
    expect(wrapper.find(".roomViewBodyWrapper").exists()).toBeTruthy()
  })
})
