/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { UPDATE_FEATURE_FLAGS, UPDATE_FEATURE_FLAG_CONFIGS, UPDATE_DEFAULT_FLAGS } from "../actions/types"
import { Reducer } from "redux"
import { IFeatureFlagsReducer } from "@rocc/rocc-client-services"

export const initialFeatureFlagReducer: IFeatureFlagsReducer = {
    defaultFeatureFlags: {},
    featureFlagConfig: {},
    featureFlags: {}
}

const featureFlagsReducer: Reducer<IFeatureFlagsReducer> = (state: IFeatureFlagsReducer = initialFeatureFlagReducer, action: any) => {
    const defaultFeatureFlags: any = {}
    switch (action.type) {
        case UPDATE_FEATURE_FLAGS:
            return { ...state, ...action.featureFlags }
        case UPDATE_FEATURE_FLAG_CONFIGS:
            return { ...state, ...action.featureFlagConfig }
        case UPDATE_DEFAULT_FLAGS:
            action.defaultFeatureFlags.enabledFeatures.forEach((item: any) => {
                defaultFeatureFlags[item] = true
            })
            return { ...state, defaultFeatureFlags }
        default:
            return { ...state }
    }
}

export default featureFlagsReducer
