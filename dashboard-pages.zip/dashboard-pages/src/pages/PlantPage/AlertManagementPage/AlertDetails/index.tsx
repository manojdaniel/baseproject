// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import RequestLogTable from "table/RequestLogTable";
import {
	getAlertDetails,
	getRequestLogTable,
	getAlertAttachementDetails,
	uploadAttachements,
} from "../../../../redux/reducers/CommonReducer";
import moment from "moment";
import "../AlertManagementPage.scss";
import axios from "axios";
import { Api } from "../../../../utility/api";
import Loader from "components/Loader";

interface Props {
	setShowAlertDetails: any;
	alertId: any;
	currentStage: string;
}
const AlertDetails = ({
	setShowAlertDetails,
	alertId,
	currentStage,
}: Props) => {
	const location = useLocation();
	let dispatch = useDispatch();
	const [finishStatus, setfinishStatus] = useState(false);
	const [selectedImage, setSelectedImage] = useState<any>("");
	const inputRef = useRef<any>();
	const [loading, setLoading] = useState<any>(false);

	const {
		alertDetails,
		loadingrequestLogTable,
		requestLogTable,
		alertAttachementDetails,
		loadingAlertAttachementDetails,
		uploadAttachementStatus,
		loadingUploadAttachementStatus,
	} = useSelector((state: any) => ({
		alertDetails: state.Common.alertDetails,
		loadingrequestLogTable: state.Common.loadingrequestLogTable,
		requestLogTable: state.Common.requestLogTable,

		alertAttachementDetails: state.Common.alertAttachementDetails,
		loadingAlertAttachementDetails: state.Common.loadingAlertAttachementDetails,

		uploadAttachementStatus: state.Common.uploadAttachementStatus,
		loadingUploadAttachementStatus: state.Common.loadingUploadAttachementStatus,
	}));

	useEffect(() => {
		alert(currentStage);
		if (alertId !== "") {
			dispatch(getAlertDetails(alertId));
			dispatch(getRequestLogTable(alertId));
			dispatch(getAlertAttachementDetails(alertId));
		}
	}, [alertId]);

	useEffect(() => {
		window.history.pushState(
			null,
			null,
			"#/plant/alertManagementPage/ampReports"
		);
		window.addEventListener("popstate", onBackButtonEvent);
		return () => {
			window.removeEventListener("popstate", onBackButtonEvent);
		};
	}, []);

	const onBackButtonEvent = (e: any) => {
		e.preventDefault();
		if (!finishStatus) {
			setShowAlertDetails(false);
			setfinishStatus(false);
		}
	};

	const AttacheMentComponent = ({ data }: any) => {
		return (
			<div className="w-attach-table">
				<div className="w-tablehead">
					<HeaderText label="FileName" />
					<HeaderText label="FileType" />
					<HeaderText label="View" />
				</div>
				<div className="w-tablebody">
					{data.length > 0 &&
						data.map((item: any) => (
							<List
								data={item.attachment_File}
								name={item.file_Name}
								type={item.file_Type}
							/>
						))}
				</div>
			</div>
		);
	};

	const handleImageOnChange = async (e) => {
		// let value = URL.createObjectURL(e.target.files[0]);
		// alert(value)
		setSelectedImage(e.target.files[0]);
	};

	// useEffect(() => {
	//     dispatch(getAlertAttachementDetails(alertId));
	//     dispatch(resetUploadAttachements(""));

	// }, [loadingUploadAttachementStatus]);

	const uploadImage = async () => {
		if (selectedImage !== "") {
			setSelectedImage("");
			if (inputRef.current !== null) {
				inputRef.current.value = "";
			}

			let base64Transform = await toBase64(selectedImage);

			setLoading(true);
			let date = moment(new Date()).format("YYYY-MM-DD");
			let data = {
				alertId: alertId,
				submittedBy: "18",
				submittedOn: date,
				modifiedBy: "18",
				modifiedOn: date,
				currentStage: currentStage,
				attachmentFile: base64Transform,
				attachmentURL: selectedImage?.name,
				file_Name: selectedImage?.name,
				file_Type: selectedImage?.type,
			};
			dispatch(uploadAttachements(data));
			// axios({
			//     method: 'post',
			//     url: Api.updateAhcAttachement,
			//     headers: {
			//         'Content-Type': 'application/json',
			//     },
			//     data: data
			// }).then((response) => {
			//     dispatch(getAlertAttachementDetails(alertId));
			//     setLoading(false)

			// }).catch((error) => {
			//     setLoading(false)

			// })
		}
	};

	const toBase64 = (file: any) =>
		new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onload = () => resolve(reader.result.split(",")[1]);
			reader.onerror = reject;
		});

	const downloadFile = (base64Data, contentType, fileName) => {
		const linkSource = `data:${contentType};base64,${base64Data}`;
		const downloadLink = document.createElement("a");

		downloadLink.href = linkSource;
		downloadLink.download = fileName;
		downloadLink.click();
	};

	const Card = ({ label, value }) => {
		return (
			<React.Fragment>
				<div>{label}</div>
				<div>{value}</div>
			</React.Fragment>
		);
	};

	const HeaderText = ({ label }) => {
		return <div>{label}</div>;
	};

	const List = ({ data, name, type }) => {
		return (
			<div
				style={{
					display: "flex",
					flexDirection: "row",
					justifyContent: "space-between",
				}}
			>
				<div>{name}</div>
				<div>{type}</div>
				<div onClick={() => downloadFile(data, type, name)}>View</div>
			</div>
		);
	};

	return (
		<React.Fragment>
			<div id="report-details">
				<div className="common-box-inner">
					<div id="altd-alertdetail">
						<div className="title">ALERT DETAILS</div>
						<div className="add-alert-details">
							{alertDetails !== undefined &&
							Object.keys(alertDetails).length > 0 ? (
								<>
									<div>
										<Card label={"Alert ID"} value={alertDetails.alertId} />
									</div>
									<div>
										<Card
											label={"Alert Description"}
											value={alertDetails.alertDescription}
										/>
									</div>
									<div>
										<Card
											label={"Anomaly Category"}
											value={alertDetails.anomalyCategory}
										/>
									</div>
									<div>
										<Card
											label={"Alert TimeStamp"}
											value={alertDetails.alertTimestamp}
										/>
									</div>
									<div>
										<Card label={"Asset Id"} value={alertDetails.assetId} />
									</div>
									<div>
										<Card
											label={"Asset Description"}
											value={alertDetails.assetDescription}
										/>
									</div>
									<div className="tableau">
										<Card label={"Tableau Url"} value={alertDetails.tableUrl} />
									</div>
									<div>
										<Card
											label={"Alert Class"}
											value={alertDetails.alertClass}
										/>
									</div>
									<div>
										<Card
											label={"AHc Sytem first to predict?"}
											value={alertDetails.ahcSystemFirstToPredict}
										/>
									</div>
									<div>
										<Card
											label={"Alert Requires Long Lead Action"}
											value={alertDetails.alertRequiresLongLeadAction}
										/>
									</div>
									<div>
										<Card
											label={"Traget Date"}
											value={alertDetails.tragetDate}
										/>
									</div>
									<div>
										<Card
											label={"Action Details"}
											value={alertDetails.actionDetails}
										/>
									</div>
								</>
							) : null}
						</div>
					</div>
				</div>
				<div className="ald-attachments">
					<div className="common-box-inner">
						<div id="altd-attach">
							<div className="title">ATTACHMENTS</div>
							<div className="w-attach">
								<label>File Name</label>
								<input
									type="file"
									name="myImage"
									className="custom-file-input"
									// value={selectedImage}
									onChange={(event) => handleImageOnChange(event)}
									ref={inputRef}
								/>
								<button onClick={() => uploadImage()}> Upload </button>
							</div>
							{loading ? <Loader /> : null}
							{loadingAlertAttachementDetails ? (
								<Loader />
							) : (
								<AttacheMentComponent data={alertAttachementDetails} />
							)}
						</div>
					</div>
				</div>
				<div className="common-box-inner">
					<div id="altd-requestlog">
						<div className="title">REQUEST LOG</div>
						<RequestLogTable
							data={requestLogTable}
							loading={loadingrequestLogTable}
						/>
					</div>
				</div>
			</div>
		</React.Fragment>
	);
};

export default AlertDetails;

// useEffect(() => {
//     try {
//         alert(location.state.alertId)
//     } catch (error) {

//     }
// }, [location]);
