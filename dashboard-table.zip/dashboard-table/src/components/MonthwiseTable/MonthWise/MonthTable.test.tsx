import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import MonthWiseTable from "./MonthWiseTable";
import { Table } from "antd";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});

describe("MonthWiseTable", () => {
	const data = [
		{
			month: "January 2022",
			truePositive: 10,
			falsePositive: 2,
			precision: 0.8,
			unClassified: 5,
		},
		{
			month: "February 2022",
			truePositive: 15,
			falsePositive: 3,
			precision: 0.7,
			unClassified: 2,
		},
	];
	it("should render the component without errors", () => {
		render(<MonthWiseTable data={data} />);

		expect(Table).toHaveBeenCalled(); // Verify that Antd Table was called
	});
	it("should render table columns", () => {
		render(<MonthWiseTable data={data} />);
		expect(screen.getByText("MONTH")).toBeInTheDocument();
		expect(screen.getByText("TRUE POSITIVE")).toBeInTheDocument();
		expect(screen.getByText("FALSE POSITIVE")).toBeInTheDocument();
		expect(screen.getByText("PRECISION")).toBeInTheDocument();
		expect(screen.getByText("UNCLASSIFIED")).toBeInTheDocument();
	});

	it("should render table data", () => {
		render(<MonthWiseTable data={data} />);
		expect(screen.getByText("January 2022")).toBeInTheDocument();
		expect(screen.getByText("10")).toBeInTheDocument();
		expect(screen.getByText("2")).toBeInTheDocument();
		expect(screen.getByText("0.8")).toBeInTheDocument();
		expect(screen.getByText("5")).toBeInTheDocument();
		expect(screen.getByText("February 2022")).toBeInTheDocument();
		expect(screen.getByText("15")).toBeInTheDocument();
		expect(screen.getByText("3")).toBeInTheDocument();
		expect(screen.getByText("0.7")).toBeInTheDocument();
		expect(screen.getByText("2")).toBeInTheDocument();
	});

	it("should not render pagination", () => {
		render(<MonthWiseTable data={data} />);
		expect(screen.queryByText("1")).toBeNull();
		expect(screen.queryByText("2")).toBeNull();
	});

	it("should render table rows with correct styles", () => {
		render(<MonthWiseTable data={data} />);
		const unclassifiedCell = screen.getByText("5");
		expect(unclassifiedCell).toHaveStyle({ color: "inherit" });
		const activeUnclassifiedCell = screen.getByText("2");
		expect(activeUnclassifiedCell).toHaveStyle({ color: "red" });
	});
});
