/*
 * Created on Wed Nov 09 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, EConnectionType, EROCC_CONTEXT, FeatureFlagHelper, IContactInfo, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { CustomSideBar, ErrorBoundary, ESideBarDirection, ESideBarWidth } from "@rocc/rocc-global-components"
import React, { useState } from "react"
import { useSelector } from "react-redux"
import { SIDEBAR_CONSTANTS } from "../../../constants/constants"
import { ESidePanelTabs } from "../../../lib/types"
import { IChatContact, IStore } from "../../../redux/interfaces/types"
import { isExpert } from "../../helpers/listUtility"
import ContactsList, { contactCardActions } from "../contacts/ContactList"
import styles from "./SidebarContent.module.scss"

const CallFeatures = React.lazy(() => import("roccCalling/CallFeatures").catch(() => false))
const TelepresencePanelFeature = React.lazy(() => import("roccCalling/TelepresencePanelFeature").catch(() => false))
const ConsoleApp = React.lazy(() => import("roccConsole/App").catch(() => false))
const ConsoleTrigger = React.lazy(() => import("roccConsole/ConsoleTrigger").catch(() => false))
const MultiCameraSettingsFeature = React.lazy(() => import("roccConsole/MultiCameraSettingsFeature").catch(() => false))
const ChatInCallControlsTrigger = React.lazy(() => import("roccChat/ChatTriggerFeature").catch(() => false))

export interface ISidebarContent {
    contacts: IContactInfo[]
}

const SidebarContent = (props: ISidebarContent) => {

    const { MULTI_CAMERA_SETTINGS_SIDEBAR, TELEPRESENCE_SIDEBAR } = SIDEBAR_CONSTANTS

    const [activeItem, setActiveItem] = useState(ESidePanelTabs.Active)

    const { sideBar, currentUser, connectedCallDetails, featureFlags, permissions, } = useSelector((state: IStore) => ({
        sideBar: state.externalReducer.sideBar,
        currentUser: state.externalReducer.currentUser,
        connectedCallDetails: state.externalReducer.callingDetails.connectedCallDetails,
        featureFlags: state.externalReducer.featureFlags,
        permissions: state.externalReducer.permissions,
    }))
    const telePresenceVisibility = sideBar.activeRightPanel === TELEPRESENCE_SIDEBAR

    const toggleChatFromCallControls = () => {
        const chatContacts: IChatContact[] = []
        connectedCallDetails.participants.forEach(p => {
            chatContacts.push({ uuid: p.uuid, clinicalRole: p.clinicalRole, name: p.name, presence: p.status, type: p.clinicalRole === EClinicalRole.DEVICE ? "room" : "user" })
        })
        return <React.Suspense fallback="">
            <ErrorBoundary>
                <ChatInCallControlsTrigger theme="controlsButton" chatContacts={chatContacts} />
            </ErrorBoundary>
        </React.Suspense >
    }

    const getViewConsoleOption = (contactUuid: string) => (
        <React.Suspense fallback="Loading view console...">
            <ErrorBoundary>
                <div id={"viewButton"} className={styles.consoleWrapperView}>
                    <ConsoleTrigger showTitle={false} roomUuid={contactUuid} connectionType={EConnectionType.VIEW} key={`${contactUuid}_view`} />
                </div>
            </ErrorBoundary>
        </React.Suspense >
    )

    const getEditConsoleOption = (contactUuid: string) => (
        <React.Suspense fallback="Loading edit console...">
            <ErrorBoundary>
                <div id={"editButton"} className={styles.consoleWrapperEdit}>
                    <ConsoleTrigger showTitle={false} roomUuid={contactUuid} connectionType={EConnectionType.FULL_CONTROL} key={`${contactUuid}_edit`} />
                </div>
            </ErrorBoundary>
        </React.Suspense >
    )

    const getSpokeNotificationMessage = (contactUuid: string) => (
        <React.Suspense fallback="Loading edit console...">
            <ErrorBoundary>
                <ConsoleTrigger showTitle={false} roomUuid={contactUuid} connectionType={EConnectionType.DEFAULT} key={`${contactUuid}_edit`} callPanelEvent={true} />
            </ErrorBoundary>
        </React.Suspense >
    )

    const renderCameraSettingsPanel = () => (
        <React.Suspense fallback="">
            <ErrorBoundary>
                <MultiCameraSettingsFeature />
            </ErrorBoundary>
        </React.Suspense>
    )

    const getConnectedCallOptions = () => {
        /* TODO: Merge participantCards & additionalCallControls into featureMap using injector */
        const connectedCallProps: any = {
            participantCards: { components: [getViewConsoleOption, getEditConsoleOption, getSpokeNotificationMessage] },
            additionalCallControls: { components: [] }
        }
        if (!!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_CHAT, false) && permissions.CHAT_CREATE) {
            connectedCallProps.additionalCallControls.components.push(toggleChatFromCallControls)
        }
        return connectedCallProps
    }

    const renderCallingFeatures = () => {
        if (currentUser.onBoarded && isExpert(currentUser)) {
            return (<React.Suspense fallback="">
                <ErrorBoundary>
                    <CallFeatures deviceType={EROCC_CONTEXT.DESKTOP} />
                </ErrorBoundary>
            </React.Suspense>)
        }
        return <></>
    }

    const renderBasicConsoleFeatures = () => {
        if (currentUser.onBoarded && isExpert(currentUser)) {
            return (<React.Suspense fallback="">
                <ErrorBoundary>
                    <ConsoleApp />
                </ErrorBoundary>
            </React.Suspense>)
        }
        return <></>
    }

    const renderTelepresenceContent = () => <React.Suspense fallback="">
        <ErrorBoundary>
            <TelepresencePanelFeature {...props}
                connectedCallProps={getConnectedCallOptions()}
                visible={telePresenceVisibility}
                ContactListComponentTab={() => <ContactsList {...props} activeItem={activeItem} />}
                activeItem={activeItem}
                setActiveItem={setActiveItem}
                contactCardActions={contactCardActions}
            />
        </ErrorBoundary>
    </React.Suspense>

    const renderBasicFeatures = () => <>
        {renderCallingFeatures()}
        {renderBasicConsoleFeatures()}
    </>

    return <div id={"SidebarContent"}>
        {renderBasicFeatures()}
        <CustomSideBar
            animation="overlay"
            componentToDisplay={{
                left: sideBar.activeLeftPanel === MULTI_CAMERA_SETTINGS_SIDEBAR && renderCameraSettingsPanel(),
                right: renderTelepresenceContent()
            }}
            direction={ESideBarDirection.BOTH}
            visibility={{
                left: sideBar.displayLeftSidePanel,
                right: sideBar.displayRightSidePanel
            }}
            width={{
                left: sideBar.desktopFullScreen ? ESideBarWidth.VERY_WIDE : ESideBarWidth.WIDE,
                right: sideBar.desktopFullScreen ? ESideBarWidth.VERY_WIDE : ESideBarWidth.WIDE
            }}
        />
    </div>
}

export default SidebarContent
