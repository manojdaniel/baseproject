// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import { default as ReactSelect } from "react-select";
import { components } from "react-select";
import CompressorSensor from "table/CompressorSensor";
import { Button } from "antd";
import "../SpareParts.scss";
import asset_model_accordian_minus from "../../../../assets/images/asset_model_accordian_minus.svg";
import asset_model_accordian_plus from "../../../../assets/images/asset_model_accordian_plus.svg";
import { useNavigate } from "react-router-dom";
import { encryptRSAData } from "../../../../utility/rsa";
import { useDispatch, useSelector } from "react-redux";
import Loader from "components/Loader";
import {
    getSparePartsSensor
} from "../../../../redux/reducers/CommonReducer";


interface Props {
    // data: any[];
}

const SensorGroup = () => {
    let dispatch = useDispatch();

    const [unique, setUnique] = useState<any>([]);
    const [counter, setCounter] = useState<any>(1);

    const { globalSelecetedAsset, globalSelecetedPlant, sparePartsSensor, loadingSparePartsSensor } = useSelector((state: any) => ({
        globalSelecetedAsset: state.Common.globalSelecetedAsset,
        globalSelecetedPlant: state.Common.globalSelecetedPlant,
        sparePartsSensor: state.Common.sparePartsSensor,
        loadingSparePartsSensor: state.Common.loadingSparePartsSensor,

    }));

    useEffect(() => {
        dataPrep();
        dispatch(getSparePartsSensor(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`)));
        setCounter(Math.random);
    }, [globalSelecetedAsset])

    // STOCK DETAILS Table width Setting=======================Start:
    const ref = useRef(null);
    useEffect(() => {
        const myWidth = ref.current ? ref.current.offsetWidth : 0;

        var elements = document.getElementsByClassName('ant-table-wrapper');
        Array.from(elements).forEach(function (element) {
            element.style.maxWidth = `${myWidth - 4}px`;
        });
    }, [ref.current]);

    

    const accord = () => {
        const accordionTitles = document.querySelectorAll(".accordionTitle");
        accordionTitles.forEach((accordionTitle) => {
            accordionTitle.addEventListener("click", () => {
                if (accordionTitle.classList.contains("is-open")) {
                    accordionTitle.classList.remove("is-open");
                } else {
                    const accordionTitlesWithIsOpen = document.querySelectorAll(".is-open");
                    accordionTitlesWithIsOpen.forEach((accordionTitleWithIsOpen) => {
                        accordionTitleWithIsOpen.classList.remove("is-open");
                    });
                    accordionTitle.classList.add("is-open");
                }
            });
        });
       }

    useEffect(() => {
        accord();
    }, [counter]);

    useEffect(() => {
        accord();
    }, [sparePartsSensor]);
     
    const dataPrep = () => {
        setUnique([...new Set(sparePartsSensor.map(item => item.ahcGroupAssignment))])
    }
    const accordian = (item) =>{
        let sparePartData = sparePartsSensor.filter(x => x.ahcGroupAssignment === item);
        // console.log("sparepartdata", sparePartData)
        return ( <div>
        <div ref={ref}  className="accordian-title accordionTitle">{item}<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
        <div className="accordian-body">
            <div className="spare-model-health-index">
                <CompressorSensor 
                data = {sparePartData}
                />
            </div>
        </div>
        </div>)
    }

    return (
        <div>
            {loadingSparePartsSensor ? (<Loader />) : (
                <>
                    {unique.map(item=> accordian(item))}
                </>
            )}


            {/* <div ref={ref} className="accordian-title accordionTitle">COMPRESSOR PERFORMANCE<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div>
            <div ref={ref} className="accordian-title accordionTitle">TURBINE PERFORMANCE<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div>
            <div ref={ref} className="accordian-title accordionTitle">LUBE OIL SYSTEM<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div>
            <div ref={ref} className="accordian-title accordionTitle">THURST BEARING<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div> */}
        </div>
    );
};

export default SensorGroup;