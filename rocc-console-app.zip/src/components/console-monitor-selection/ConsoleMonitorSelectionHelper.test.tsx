/*
 * Created on Thu Dec 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { mount } from "enzyme"
import { shallow } from "enzyme"
import { getHeaderForCC, getRoomNameAndAddress, getActiveSessionMessageForCC } from "./ConsoleMonitorSelectionHelper"

describe("ConsoleMonitorSelectionHelper tests", () => {
    const receiverName = "receiverName"
    const roomName = "roomName"
    const address = "address"
    it("get Header for CC", () => {
        const wrapper = shallow(getHeaderForCC(receiverName))
        expect(wrapper.text()).toContain(receiverName)
    })
    it("get room name and address", () => {
        const wrapper = mount(getRoomNameAndAddress(roomName, address))
        let printedString = wrapper.at(0).text()
        expect(printedString).toContain(roomName)
        printedString = wrapper.at(1).text()
        expect(printedString).toContain(address)
    })
    it("get Header for CC", () => {
        const oldRoom = {
            roomUuid: "1",
            roomName: roomName,
            address: address,
            locationId: 1,
            phoneNumber: "12",
            loggedInTech: { techUuid: "", techName: "" },
        }
        const newRoom = {
            roomUuid: "2",
            roomName: roomName + "2",
            address: address + "2",
            locationId: 2,
            phoneNumber: "34",
            loggedInTech: { techUuid: "", techName: "" },
        }
        const wrapper = shallow(getActiveSessionMessageForCC(receiverName, newRoom, oldRoom))
        expect(wrapper.text()).toContain(roomName)
    })
})
