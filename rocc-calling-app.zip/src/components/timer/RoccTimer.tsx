/*
 * Created on Tue Sept 21 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect, useState } from "react"
import { useStopwatch } from "react-timer-hook"

interface IRoccTimerProps {
    initialHour?: number
    initialMinutes?: number
    initialSeconds?: number
    autoStart?: boolean
}

const RoccTimer = ({ initialHour = 0, initialMinutes = 0, initialSeconds = 0, autoStart = true }: IRoccTimerProps) => {
    const [offsetTime, setOffsetTime] = useState(new Date())

    useEffect(() => {
        const newOffset = new Date(offsetTime.setHours(initialHour, initialMinutes, initialSeconds))
        setOffsetTime(newOffset)
    }, [])

    const { seconds, minutes, hours, } = useStopwatch({ autoStart })

    const formatTime = (num: number) => {
        return num < 10 ? `0${num}` : num
    }

    if (hours > 0) {
        return <span>{`${formatTime(hours)}:${formatTime(minutes)}:${formatTime(seconds)}`}</span>
    } else {
        return <span>{`${formatTime(minutes)}:${formatTime(seconds)}`}</span>
    }
}

export default RoccTimer
