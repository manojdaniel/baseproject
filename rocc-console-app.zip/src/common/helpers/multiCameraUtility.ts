/*
 * Created on Wed Dec 08 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, IConsoleSession } from "@rocc/rocc-client-services"
import { infoLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "react"
import { Participant, Room } from "twilio-video"
import { updateConsoleSession } from "../../redux/actions/consoleActions"
import syncSessions from "../../redux/store/syncSessions"
import en from "../../resources/translations/en-US"
import { UPDATE_DISPLAY_CAMERA_TOGGLE } from "../constants/constants"
import { checkMultiCameraDeviceDisconnected } from "../modules/multi-camera/MultiCameraHelper"

export const attachTrack = (track: any, container: any, muteAudio: boolean, deviceId?: string,) => {
    infoLogger(`Initializing attaching track ${track.name} to the container.`)
    if (container) {
        const audioElement = track.attach()
        audioElement.muted = muteAudio
        if (deviceId) {
            infoLogger(`Appending track element with device ${deviceId} for track ${track.name} into the container.`)
            audioElement.setSinkId(deviceId).then(() => {
                container.appendChild(audioElement)
            })
        } else {
            infoLogger(`Appending track element for track ${track.name} into the container.`)
            container.appendChild(audioElement)
        }
    }
}

export const detachTracks = (tracks: any) => {
    infoLogger("Initializing detaching tracks.")
    for (const track of tracks) {
        infoLogger(`Detaching track ${track.name}.`)
        detachTrack(track)
    }
}

export const detachTrack = (track: any) => {
    infoLogger(`Initializing removal of track ${track.name} from DOM.`)
    for (const detachedElement of track.detach()) {
        infoLogger(`Removing track ${track.name} from DOM.`)
        detachedElement.remove()
        detachedElement.srcObject = null
    }
}

export const getTracks = (participant: Participant) => {
    return Array.from(participant.tracks.values()).filter((publication: any) => {
        return publication.track
    }).map((publication: any) => {
        return publication.track
    })
}

export const detachParticipantTracks = (participant: Participant) => {
    detachTracks(getTracks(participant))
}

export const checkIfRoomAvailableInRoom = (room: Room, roomUuid: string) => {
    let roomAvailable = false
    if (room) {
        room.participants.forEach(participant => {
            if (participant.identity === roomUuid) {
                roomAvailable = true
            }
        })
    }
    return roomAvailable
}

export const cameraName = (index: number, intl: any) => `${intl.formatMessage({ id: "content.room.cameraName2", defaultMessage: en["content.room.cameraName2"] })} ${+index + +1}`

export const toggleCameraState = (consoleSession: IConsoleSession, state: boolean, singleRecieverView: boolean, dispatch: any) => {
    infoLogger(`For user: ${consoleSession.requester} - Console session ${consoleSession.contextId} - Setting display camera state to ${state}.`)
    if (singleRecieverView) {
        setDisplayCamera(consoleSession, state, dispatch)
    } else {
        syncSessions.postMessage({ type: UPDATE_DISPLAY_CAMERA_TOGGLE, sessionDetails: { contextId: consoleSession.contextId, cameraState: state } })
    }
}

export const setDisplayCamera = (consoleSession: IConsoleSession, state: boolean, dispatch: Dispatch<any>) => {
    const updatedSession = { ...consoleSession }
    const { CAMERA_STREAM_DISCONNECTED, INITIATED, NOT_AVAILABLE } = ECameraStreamAvailable
    const { cameraStreamAvailable, mediaRoomId } = consoleSession.mediaRoomDetails
    updatedSession.displayCameraToggle = state
    updatedSession.multiCameraList = []
    updatedSession.mediaRoomDetails.cameraStreamAvailable = mediaRoomId === "" ? NOT_AVAILABLE : checkMultiCameraDeviceDisconnected(cameraStreamAvailable, state ? INITIATED : CAMERA_STREAM_DISCONNECTED)
    dispatch(updateConsoleSession(updatedSession, true, false))
}
