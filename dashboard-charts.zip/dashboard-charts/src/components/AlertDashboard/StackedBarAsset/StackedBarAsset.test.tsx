import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import StackedBarAsset from "./index";

//Mock data for the chart component
const data = [
	{
		count: 6,
		state: "Closed",
		assetID: "2K-3101",
	},
	{
		count: 3,
		state: "Overdue",
		assetID: "2K-3101",
	},
	{
		count: 5,
		state: "Closed",
		assetID: "2K-3201",
	},
	{
		count: 4,
		state: "Overdue",
		assetID: "2K-3201",
	},
	{
		count: 4,
		state: "Closed",
		assetID: "2K-4101",
	},
	{
		count: 3,
		state: "Overdue",
		assetID: "2K-4101",
	},
	{
		count: 1,
		state: "Closed",
		assetID: "2K-4103",
	},
	{
		count: 1,
		state: "Closed",
		assetID: "2Y-3013B",
	},
	{
		count: 1,
		state: "Overdue",
		assetID: "2Y-3013B",
	},
	{
		count: 17,
		state: "Closed",
		assetID: "2Y-3606",
	},
	{
		count: 9,
		state: "Overdue",
		assetID: "2Y-3606",
	},
	{
		count: 10,
		state: "Closed",
		assetID: "2Y-3607",
	},
	{
		count: 7,
		state: "Overdue",
		assetID: "2Y-3607",
	},
	{
		count: 8,
		state: "Closed",
		assetID: "2Y-3608",
	},
	{
		count: 7,
		state: "Overdue",
		assetID: "2Y-3608",
	},
	{
		count: 2,
		state: "Closed",
		assetID: "2Y-4123A",
	},
	{
		count: 2,
		state: "Closed",
		assetID: "2Y-4123B",
	},
	{
		count: 1,
		state: "Overdue",
		assetID: "2Y-4123B",
	},
];

//Test Case to check chart exist in the component.
describe("StackedBarAsset", () => {
	it("renders the chart with data", () => {
		const { container } = render(<StackedBarAsset data={data} />);
		expect(container.querySelector("#chartdiv1")).toBeInTheDocument();
	});
});
