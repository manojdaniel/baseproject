import unittest
from unittest.mock import Mock
from src.modules.db_operations.raw_data_insertion.raw_data_insertion_exec import insert_existing_customer_information, check_if_customer_exists


class RawDataInsertionExecTest(unittest.TestCase):
    def test_insert_existing_customer_information(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "data": {
                "rocc_overwatch_customers": [
                    {"id": 100}
                ]
            }
        }
        self.assertRaises(
            Exception, insert_existing_customer_information, 1, mock_client, {}, {}, {})

    def test_check_if_customer_exists(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "rocc_overwatch_customers": [
                {"id": 100}
            ]
        }
        returned_data = check_if_customer_exists(
            mock_client, "customer_identifier", "uuid")
        self.assertIsNotNone(returned_data)
