import React, { useRef, useState, useEffect } from "react";
import "./AssetTimeLine.scss";
import AssetHealthIndex from "charts/AssetHealthIndex";
import MaintenanceHistory from "charts/MaintenanceHistory";
import HanaIncident from "charts/HanaIncident";
import Dropdown from "components/Dropdown";
import Loader from "components/Loader";
import NoData from "components/NoData";
import { useDispatch, useSelector } from "react-redux";
import {
	getPlotAssetDropDown,
	getAssetHealthIndexByAssetId,
	getMaintenanceHistoryByAssetId,
	getHanaIncidentByAssetId,
	getAssetDropdownList,
	getGlobalSelecetedAsset,
} from "../../../redux/reducers/CommonReducer";
import moment from "moment";
import { encryptRSAData } from "../../../utility/rsa";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const AssetTimeLine = () => {
	let dispatch = useDispatch();
	const [assetData, setAssetData] = useState<any>("");
	const [selectedAsset, setSelectedAsset] = useState<any>("");

	const {
		plotAssetDropDown,
		assetHealthIndex,
		maintenanceHistory,
		hanaIncident,
		commonFromDateFormat,
		commonToDateFormat,
		selectedBreadCrumbDate,
		breadCrumbDateFormated,
		breadCrumbDate,
		commonToDate,
		commonFromDate,
		assetDropdownList,
		globalSelecetedAsset,
		globalSelecetedPlant,
		loadingAssetHealthIndex,
		loadingMaintenanceHistory,
		loadingHanaIncident,
	} = useSelector((state: any) => ({
		plotAssetDropDown: state.Common.plotAssetDropDown,
		assetHealthIndex: state.Common.assetHealthIndex,
		maintenanceHistory: state.Common.maintenanceHistory,
		hanaIncident: state.Common.hanaIncident,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		commonToDate: state.Common.commonToDate,
		commonFromDate: state.Common.commonFromDate,

		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
		breadCrumbDate: state.Common.breadCrumbDate,
		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,

		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		assetDropdownList: state.Common.assetDropdownList,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,

		loadingAssetHealthIndex: state.Common.loadingAssetHealthIndex,
		loadingMaintenanceHistory: state.Common.loadingMaintenanceHistory,
		loadingHanaIncident: state.Common.loadingHanaIncident,
	}));

	const userId = 18;

	useEffect(() => {
		let today = moment(new Date()).format("YYYY-MM-DD");
		if (
			Object.keys(globalSelecetedPlant).length > 0 &&
			Object.keys(globalSelecetedAsset).length > 0
		) {
			setSelectedAsset(globalSelecetedAsset);
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
		}
	}, []);

	useEffect(() => {
		let today = moment(new Date()).format("YYYY-MM-DD");
		if (
			breadCrumbDateFormated !== "" &&
			Object.keys(selectedAsset).length > 0
		) {
			dispatch(
				getAssetHealthIndexByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
			dispatch(
				getMaintenanceHistoryByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
			dispatch(
				getHanaIncidentByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
		} else if (
			commonToDateFormat !== "" &&
			Object.keys(selectedAsset).length > 0
		) {
			dispatch(
				getAssetHealthIndexByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
			dispatch(
				getMaintenanceHistoryByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
			dispatch(
				getHanaIncidentByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{userId}
		}
	}, [breadCrumbDateFormated, selectedAsset, commonToDateFormat]);

	const handleAssetDropDown = (e: any) => {
		setSelectedAsset(e);
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
	};

	return (
		<div id="AssetTimeLineWrapper">
			<div id="asset-timeline">
				<div id="asset-timeline-full">
					<div id="asset-timeline-plot">
						<div id="new-filter" className="mt0">
							<div className="nf-left">
								<div className="title">ASSET HEALTH INDEX</div>
								<div className="asset-name"></div>
							</div>
							<div className="nf-right">
								<div>
									<label className="cus-label">Asset ID</label>
									<Dropdown
										name={"Asset ID"}
										options={assetDropdownList}
										handleChange={handleAssetDropDown}
										value={selectedAsset}
										defaultValue={""}
									/>
								</div>
							</div>
						</div>

						<div className="asset-timeline-plot-graph">
							{loadingAssetHealthIndex ? (
								<div className="tc-loaderpd-200"><Loader /></div>
							) : assetHealthIndex.length === 0 ? (
								<div className="tc-loaderpd-200"><NoData /></div>
							) : (
								<AssetHealthIndex assetHealthIndexData={assetHealthIndex} />
							)}
						</div>
					</div>
				</div>
				{/* <div id="asset-timeline-right">
                    <div id="asset-timeline-names">
                        <div className="right-title">MODEL STATUS</div>
                        <div className="asset-timeline-list">
                            <div><span style={{background: '#E35205'}}></span><span>Anomaly Alert</span></div>
                            <div><span style={{background:'#F28E2B'}}></span><span>Warning</span></div>
                            <div><span style={{background:'#3BB44A'}}></span><span>Normal</span></div>
                        </div>
                    </div>
                </div> */}
			</div>
			{loadingMaintenanceHistory ? (
				<div id="asset-timeline">
				<div id="asset-timeline-left">
					<div className="tc-loaderpd-200"><Loader /></div>
				</div>
				<div id="asset-timeline-right">
					<div className="tc-loaderpd-200"><Loader /></div>
				</div>
			</div>
			) : maintenanceHistory.length === 0 ? (
				<div id="asset-timeline">
					<div id="asset-timeline-left">
						<div className="tc-loaderpd-200"><NoData /></div>
					</div>
					<div id="asset-timeline-right">
						<div className="tc-loaderpd-200"><NoData /></div>
					</div>
				</div>
			) : (
				<MaintenanceHistory maintenanceHistoryData={maintenanceHistory} />
				
			)}

			{loadingHanaIncident ? (
				<div id="asset-timeline">
				<div id="asset-timeline-left">
					<div className="tc-loaderpd-200"><Loader /></div>
				</div>
				<div id="asset-timeline-right">
					<div className="tc-loaderpd-200"><Loader /></div>
				</div>
			</div>
			) : hanaIncident.length === 0 ? (
				<div id="asset-timeline">
					<div id="asset-timeline-left">
						<div className="tc-loaderpd-200"><NoData /></div>
					</div>
					<div id="asset-timeline-right">
						<div className="tc-loaderpd-200"><NoData /></div>
					</div>
				</div>
			) : (
				<HanaIncident hanaIncidentData={hanaIncident} />
				
			)}
		</div>
	);
};

export default AssetTimeLine;

// useEffect(() => {
//     let data = plotAssetDropDown.map(function (item: any) {
//         return { value: item.assetId, label: item.assetId };
//     });
//     setAssetData(data);
// }, [plotAssetDropDown]);

// useEffect(() => {
//     if (Object.keys(globalSelecetedPlant).length > 0 && Object.keys(globalSelecetedAsset).length > 0) {

//     }
// }, []);
