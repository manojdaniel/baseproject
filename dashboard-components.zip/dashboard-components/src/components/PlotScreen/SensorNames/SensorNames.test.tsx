import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import SensorNames from "./index";

describe("SensorNames", () => {
	const data = [
		{ label: "Sensor 1" },
		{ label: "Sensor 2" },
		{ label: "Sensor 3" },
	];

	it("should render the component without errors", () => {
		const { container } = render(<SensorNames data={data} />);
		expect(container).toBeDefined();
	});

	it("should render the correct sensor names", () => {
		const { getByText } = render(<SensorNames data={data} />);
		expect(getByText("Sensor 1")).toBeInTheDocument();
		expect(getByText("Sensor 2")).toBeInTheDocument();
		expect(getByText("Sensor 3")).toBeInTheDocument();
	});
});
