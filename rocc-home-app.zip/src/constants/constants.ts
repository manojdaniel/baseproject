/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoccWorkflow } from "@rocc/rocc-client-services"

/* App Constants */
export const CURRENT_APP_NAME = "CC_HOME"
export const STORAGE_KEY = "REDUX_STATE"
export const PARENT_STORE = "CC_HOST"
export const CONSOLE_STORE = "CC_CONSOLE"
export const CALLING_STORE = "CC_CALLING"

/* API Constants */
export const ACCEPT = "Accept"
export const POST = "POST"
export const CONTENT_TYPE = "Content-Type"
export const APPLICATION_JSON = "application/json"
export const AUTHORIZATION = "Authorization"
export const API_VERSION = "api-version"
export const ORG_CONTEXT_HEADER = "org_ctxt_header"
export const ORG_ID = "Org-Id"
export const DEFAULT_API_VERSION = "1.0.0"


export const API_CONSTANTS = {
    ACCEPT: "Accept",
    AUTHORIZATION: "Authorization",
    APPLICATION_JSON: "application/json",
    CONTENT_TYPE: "Content-Type",
    ORG_ID_HEADER_TEXT: "Org-Id",
    ORG_CONTEXT_TEXT: "org_ctxt_header",
    X_VAULT_TOKEN: "X-Vault-Token",
    API_VERSION: "api-version",
    API_VERSION_1_0_0: "1.0.0",
    API_VERSION_2_0_0: "2.0.0",
}

export enum HTTP_STATUS {
    OK = 200,
    CREATED = 201,
    UNAUTHORIZED = 401,
    INTERNAL_SERVER_ERROR = 500,
}

export const SIDEBAR_CONSTANTS = {
    TELEPRESENCE_SIDEBAR: "TelepresenceSidebar",
    MULTI_CAMERA_SETTINGS_SIDEBAR: "MultiCameraSettingsSidebar",
}
export const DEVICE = "device"
export const DEVICE_ROLE_ROOM = "Room"
export const REMOTE_LOAD_FAIL_MSG_SUB_STR = `In app: ${CURRENT_APP_NAME}, failed to load`

/* Reducer Constants */
export const CUSTOMER_REDUCER = "customerReducer"
export const FEATURE_FLAG_REDUCER = "featureFlagsReducer"
export const USER_REDUCER = "userReducer"
export const CONFIG_REDUCER = "configReducer"
export const APP_REDUCER = "appReducer"

export const INFO = "INFO"

export const MANAGE_GRAPHQL_MUTATION_EP = "/data/Graphql"
export const MANAGE_GRAPHQL_EMPLOYEE_FAVOURITES = `${MANAGE_GRAPHQL_MUTATION_EP}/Employee/favourites`

export const ROOM_CARD = "Room Card"
export const ALL_TEXT = "All"

export const EN_LOCALE = "en"
export const EN_LANGUAGE = "en-US"

export const TRACKED_HOME_WORKFLOWS = [
    ERoccWorkflow.MULTI_EDIT_INITIATE_CALL,
    ERoccWorkflow.MULTI_EDIT_START_EDITING,
    ERoccWorkflow.PARK_AND_INITIATE_CALL,
    ERoccWorkflow.PARK_AND_START_EDITING,
    ERoccWorkflow.PARK_AND_RESUME,
    ERoccWorkflow.DISCONNECT_CALL,
    ERoccWorkflow.DISCONNECT_CONSOLE_SESSION,
]
