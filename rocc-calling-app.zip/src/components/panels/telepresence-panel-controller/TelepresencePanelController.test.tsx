/*
 * Created on Tue Aug 31 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import TelepresencePanelController from "./TelepresencePanelController"
import { shallow } from "enzyme"
import { EClinicalRole } from "@rocc/rocc-client-services"
import { EUserPresence } from "@dls-pdv/semantic-react-components"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { withHooks } from "jest-react-hooks-shallow"
import { ESidePanelTabs } from "../../../types/types"

jest.mock("react-redux", () => ({
    useSelector: jest.fn()
}))

jest.mock("../../../common/helpers/helpers", () => ({
    isAdmin: () => false
}))

jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))
let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const mockAppState: any = {
    callReducer: {
        videoCallStatus: [],
        phoneCallStatus: "idle",
        missedCalls: [],
    },
    externalReducer: {
        sideBar: {
            desktopFullScreen: true,
        },
        currentUser: {
            clinicalRole: EClinicalRole.EXPERTUSER
        }
    }
}
const props = {
    visible: true,
    currentUser: {
        accessToken: "accessToken",
        onBoarded: true,
        sessionId: "1",
        locale: "en-US",
        id: "1",
        uuid: "1",
        siteId: ["site1"],
        orgId: "org1",
        status: EUserPresence.AVAILABLE,
        name: "demo user",
        phoneNumber: "1234567890",
        clinicalRole: EClinicalRole.EXPERTUSER,
        email: "demo@yopmail.com",
        roomName: "room1",
        allRoles: [EClinicalRole.EXPERTUSER],
        secondaryUUID: "sUuid1",
        secondaryName: "demo 1",
        modalities: ["CT"],
        description: ""
    },
    contacts: [],
    activeItem: ESidePanelTabs.Active,
    setActiveItem: jest.fn(),
    ContactListComponentTab: () => <>Sample</>,
    contactCardActions: jest.fn(),
}

const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}
const getShallowWrapper = () => { return shallow(<TelepresencePanelController {...props} />) }

describe("TelepresencePanelController Component", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })
    it("should render TelepresencePanelController component", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("TabLayout")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("TelepresencePanelController Component when fullscreen is false", () => {
    beforeEach(() => {
        mockAppState.externalReducer.sideBar.desktopFullScreen = false
        useSelectorMock(mockAppState)
    })
    it("should render TelepresencePanelController component in window", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("TabLayout")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
