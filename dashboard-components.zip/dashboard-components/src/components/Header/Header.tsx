import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Header.scss";
import iconSearch from "../../assets/images/icon_Search.svg";
import iconAlerts from "../../assets/images/icon_Alerts.svg";
import iconSettings from "../../assets/images/icon_Settings.svg";
import iconProfile from "../../assets/images/icon_Profile.svg";
import imageSabicLogo from "../../assets/images/image_Sabic_Logo.svg";
import dropdown_arrow from "../../assets/images/dropdown_arrow.svg";
import { AutoComplete } from "antd";
import useOnClickOutside from "../../hooks/useOnClickOutside";
import { matchRoutes, useLocation } from "react-router-dom";

interface Props {
	data: any[];
	handleSearchBack: any;
	assetEnabled: Boolean;
	userData: any;
	onePlantUser: any;
	name: any;
	userRole: any;
	userEmail: any;
	userProfileActiveOn:any;
}

const Header = ({
	data,
	handleSearchBack,
	assetEnabled,
	userData,
	onePlantUser,
	name,
	userRole,
	userEmail,
	userProfileActiveOn,
}: Props) => {
	let navigate = useNavigate();
	const [searchData, setSearchData] = useState<any>();
	const [searchValue, setSearchValue] = useState<any>();
	const [searchButton, setSearchButton] = useState<any>(false);
	const location = useLocation();

	const ref = useRef(null);
	const [title, setTitle] = useState<any>("ASSET HEALTH CARE");
	// State for our modal
	const [showSearch, setShowSearch] = useState(false);
	useOnClickOutside(ref, () => setShowSearch(false));
	// const [oneplantUser, setOnePlantUser] = useState(true)

	useEffect(() => {
		if (data.length > 0) {
			let value = data.map(function (item: any) {
				// adding id to value to avoid warning in ant library Autocomplete
				return {
					value: `${item.value} ? ${item.id}`,
					label: renderTitle(
						item.value,
						item.identifier,
						item.color,
						item.assetId
					),
				};
			});
			setSearchData(value);
		}
	}, [data]);

	useEffect(() => {
		try {
			if (location.pathname === "/plant/pmt") {
				setTitle("PMT DASHBOARD");
			} else if (location.pathname === "/plant/alertSatistics") {
				setTitle("PLANT ALERT STATISTICS");
			} else if (location.pathname === "/plant/modelPerformance") {
				setTitle("MODEL PERFORMANCE");
			} else if (location.pathname === "/plant/alertManagementPage") {
				setTitle("ALERT MANAGEMENT");
			} else if (location.pathname === "/plant/pmCompliance") {
				setTitle("PM COMPLIANCE");
			} else {
				setTitle("ASSET HEALTH CARE");
			}
		} catch (error) { }
	}, [location]);

	const onChange = (data: string) => {
		setSearchValue(data);
		setSearchButton(false);
	};

	const [roleName, setRoleName] = useState("");
	const [userName, setUserName] = useState("");
	const [userAlertCount, setUserAlertCount] = useState("");
	const[activeUserProfile,setActiveUserProfile]=useState("");

	useEffect(() => {
		try {
			if (Object.keys(userData).length > 0) {
				setUserAlertCount(
					userData.result.alertCount !== null &&
						userData.result.alertCount !== "" &&
						userData.result.alertCount !== undefined
						? userData.result.alertCount
						: "0"
				);

				if (!userData.hasOwnProperty("Succeeded")) {
					if (userData.result !== null) {
						// alert(name)
						setRoleName(userRole);
						setUserName(name);
					}
				}
			}
		} catch (error) { }
	}, [roleName, userData]);

	const handleSearch = (searchId) => {
		/**
		 * getting filtered object from all json data
		 */
		let obj = getFilteredById(data, searchId);
		/**
		 * passing filtered object to get page Navigation name
		 */
		let pageDetail = getPageIdentifier(obj);
		/**
		 * sending object back to HeaderWrapper to update redux store
		 */
		handleSearchBack(obj);
		/**
		 * Navigating
		 */
		onClickFunction(pageDetail, true);

		setSearchValue("");
	};

	const onSelect = (val: any, option: any) => {
		setSearchButton(true);
		var afterQueString = option.value.split("?")[1];
		var beforeQuesString = option.value.split("?")[0];
		setSearchValue(beforeQuesString.trim());
		handleSearch(afterQueString.trim());
		setShowSearch(false);
	};

	const getFilteredById = (data: any, searchId: any) => {
		let value = data.find((item: any) => item.id == searchId);
		return value;
	};

	const getPageIdentifier = (obj: any) => {
		let navigateTo = "";
		switch (obj.identifier) {
			case "Region":
				navigateTo = "affiliates";
				break;
			case "Affiliate":
				navigateTo = "allPlants";
				break;
			case "Plant":
				navigateTo = "plant/pmt";
				break;
			case "Asset":
				navigateTo = "assets";
				break;
		}
		return navigateTo;
	};

	const onClickFunction = (key: any, searchFunc?: boolean) => {
		if (key === "assets") {
			if (assetEnabled || searchFunc) {
				navigate(`/${key}`);
			}
		} else {
			navigate(`/${key}`);
		}
	};

	const navFunction = (key: any, searchFunc?: boolean) => {
		navigate(`/${key}`);
	};

	const onClickUserProfile = (key: any, data: any) => {
		navigate(`/${key}`, { state: { data } });
		setActiveUserProfile(data);
	};

	const getSelectedClass = (id: string) => {
		location.pathname.split("/")[1] === id ? "active" : "";
	};
	const Logout = () => {
		localStorage.clear();
		sessionStorage.clear();
		navigate("/logout", { replace: true });
	};
	const checkSpecialChar = (e) => {
		if (!/[0-9a-zA-Z- ]/.test(e.key)) {
			e.preventDefault();
		}
	};
	const renderTitle = (
		title: string,
		identifier: string,
		color: string,
		assetId: any
	) => (
		<div className="search-row-option">
			<div className="search-row-title">{title}</div>
			<div className="search-row-assetid">
				{identifier === "Asset" ? assetId : null}
			</div>
			<div className="search-row-tag" style={{ backgroundColor: color }}>
				{identifier}
			</div>
		</div>
	);

	useEffect(() => {
		setActiveUserProfile(userProfileActiveOn);
	}, [userProfileActiveOn]);

	

	return (
		// <HeaderParent>
		<div id="header">
			<div className="header-inner">
				<div className="logoname">{title}</div>
				<div className="middle">
					<div className="navigation">
						<a
							onClick={() => {
								onePlantUser === 1 ? {} : onClickFunction("home");
							}}
							className={
								location.pathname.split("/")[1] === "home" || location.pathname.split("/")[1] === ""  ? "home active" : ""
							}
						>
							HOME
						</a>
						<a
							onClick={() => {
								onePlantUser === 1 ? {} : onClickFunction("affiliates");
							}}
							className={
								location.pathname.split("/")[1] === "affiliates"
									? "affiliates active"
									: ""
							}
						>
							AFFILIATES
						</a>
						<a
							onClick={() => {
								onePlantUser === 1
									? onClickFunction("plant/pmt")
									: onClickFunction("allPlants");
							}}
							className={
								location.pathname.split("/")[1] === "allPlants" ||
									location.pathname.split("/")[1] === "plant"
									? "plants active"
									: ""
							}
						>
							PLANTS
						</a>
						{/* , pointerEvents: "none" */}
						<a
							style={{ cursor: "default" }}
							onClick={() => { }}
							className={
								location.pathname.split("/")[1] === "assets"
									? "assets active"
									: ""
							}
						>
							ASSETS
						</a>
						{/* <a>EXECUTIVE</a> */}
						<a
							className={
								location.pathname.split("/")[1] === "info" ? "info active" : ""
							}
							onClick={() => {
								onClickFunction("info");
							}}
						>
							INFO
						</a>
					</div>
				</div>
				<div className="rightside">
					<div className="icons">
						<div id="global-search">
							<a onClick={() => setShowSearch(true)}>
								<img src={iconSearch} />
							</a>
							{showSearch ? (
								<div className="search-popup">
									<AutoComplete
										autoFocus
										value={searchValue}
										style={{ width: 200 }}
										placeholder="Search Here"
										options={searchData}
										filterOption={true}
										onSelect={(val, option) => onSelect(val, option)}
										onChange={onChange}
										onBlur={() => setShowSearch(false)}
										dropdownMatchSelectWidth={340}
										clearIcon
										onInputKeyDown={(e) => checkSpecialChar(e)}
									/>
									{/* <button disabled={!searchButton} onClick={() => handleSearch()}>GO</button> */}
									{/* <button disabled={!searchButton}>GO</button> */}
								</div>
							) : null}
						</div>

						<a>
							{userAlertCount !== 0 ? (
								<div id="notificationcount">{userAlertCount}</div>
							) : (
								""
							)}
							<img
								onClick={() => navFunction("ampMyTask")}
								src={iconAlerts}
								alt="notification"
							/>
						</a>

						<a href="https://ai.sabic.com/AHC" target="_blank">
							<img src={iconSettings} alt="settings" />
						</a>
					</div>
					<div className="username hovermeyaar">
						<a>
							<span>
								{/* <img src={iconProfile} title="User" /> */}
								<img
									src={`https://mail.sabic.com/ews/exchange.asmx/s/GetUserPhoto?email=${userEmail}&size=HR240x240`}
									onError={({ currentTarget }) => {
										currentTarget.onerror = null; // prevents looping
										currentTarget.src = `${iconProfile}`;
									}}
								/>
							</span>
							<span>
								<i>Welcome </i>
								{/* <i className={userName.length > 15 ? 'extradot' : ''}>{userName}</i> */}
								<i>{userName}</i>
								<i>
									<img src={dropdown_arrow} />
								</i>
							</span>
						</a>

						{/* //User Profile Drop Down : Start */}
						<div className="userprofile-tooltip centerarr">
							<div className="userprofile-tooltip-text">
								<div
									className="userbox"
									onClick={() => onClickFunction("profile")}
								>
									<span>
										<img
											src={`https://mail.sabic.com/ews/exchange.asmx/s/GetUserPhoto?email=${userEmail}&size=HR240x240`}
											onError={({ currentTarget }) => {
												currentTarget.onerror = null; // prevents looping
												currentTarget.src = `${iconProfile}`;
											}}
										/>
									</span>
									<span>{userName}</span>
								</div>
								<div
									className={`userprof-row ${activeUserProfile === "INBOX" && location.pathname.split("/")[1] === "profile" ? "active" : ""}`}
									onClick={() => onClickUserProfile("profile", "INBOX")}
								>
									<span>Inbox</span>
								</div>
								<div
									className={`userprof-row ${activeUserProfile === "ACTIVE" && location.pathname.split("/")[1] === "profile" ? "active" : ""}`}
									onClick={() => onClickUserProfile("profile", "ACTIVE")}
								>
									<span>Active</span>
								</div>
								<div
									className={`userprof-row ${activeUserProfile === "PENDING" && location.pathname.split("/")[1] === "profile" ? "active" : ""}`}
									onClick={() => onClickUserProfile("profile", "PENDING")}
								>
									<span>Pending</span>
								</div>
								<div className="userprof-row" onClick={() => Logout()}>
									<span>Logout</span>
								</div>
								{roleName === "Plant Admin" || roleName === "Super Admin" ? (
									<div
										className="userprof-row nonum"
										onClick={() => onClickUserProfile("admin", "Admin")}
									>
										<span>Admin Configuration</span>
									</div>
								) : (
									""
								)}
							</div>
						</div>
						{/* //User Profile Drop Down : End */}
					</div>
					<div className="logo">
						<img src={imageSabicLogo} alt="Sabic Logo" />
					</div>
				</div>
			</div>
		</div>
	);
};

export default Header;
