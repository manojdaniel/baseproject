/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ReactDOM from "react-dom"
import { Provider } from "react-redux"
import store from "./redux/store/store"
import { register, unregister } from "@rocc/rocc-push-notifications"
import swPackageJson from "@rocc/rocc-push-notifications/package.json"

import App from "./App"
import { PUSH_NOTIFICATION_SERVER_KEY } from "./constants/constants"
ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById("root")
)

/**
 * HACK: Reinstalls service workers. Better/safer updation implementations exist. Consider deprecating as soon as possible
 */
{
    const SW_VERSION = "SW_VERSION"
    if ((sessionStorage.getItem(SW_VERSION) ?? "0").localeCompare(swPackageJson.version, undefined, { numeric: true, sensitivity: 'base' }) === -1) {
        unregister()
        sessionStorage.setItem(SW_VERSION, swPackageJson.version)
    }
}

register({
    applicationServerKey: PUSH_NOTIFICATION_SERVER_KEY,
})
