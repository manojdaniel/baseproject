/*
 * Created on Tue Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import CallEventHandler from "./CallEventHandler"

jest.mock("../../../services/callServices", () => ({
    enableWebToWebCallWrapper: jest.fn(),
    enableBrowserToPhoneCall: jest.fn()
}))

jest.mock("react-redux", () => ({
    useDispatch: jest.fn().mockReturnValue(jest.fn),
    useSelector: () => ({
        initiateWebCall: { contactUuid: "contactUuid" },
        currentUser: { uuid: "uuid" },
        initiatePhoneCall: { contactUuid: "contactUuid", phoneNumber: "+91 9000000000" }
    }),
}))

describe("CallEventHandler component", () => {
    let wrapper: any

    it("should render Fragment", () => {
        withHooks(() => {
            wrapper = shallow(<CallEventHandler />)
            expect(wrapper).toHaveLength(1)
        })
    })
})
