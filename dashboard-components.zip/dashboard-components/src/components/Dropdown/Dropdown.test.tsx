import React from "react"; //// Importing necessary dependencies
import "@testing-library/jest-dom/extend-expect";
import Dropdown from "./Dropdown";
// Creating an array of options to use in the tests
const options = [
	{ label: "Option 1", value: "option1" },
	{ label: "Option 2", value: "option2" },
	{ label: "Option 3", value: "option3" },
];
// Describing a group of tests for the Dropdown component
describe("Dropdown component", () => {
	it("renders without crashing", () => {
		const { getByRole } = render(<Dropdown />);
		const dropdown = getByRole("combobox");
		expect(dropdown).toBeInTheDocument();
	});
	// Testing that the loading indicator is not displayed when loading prop is false
	it("does not display loading indicator when loading prop is false", () => {
		const { queryByTestId } = render(
			<Dropdown options={options} loading={false} />
		);
		const loadingIndicator = queryByTestId("loading-indicator");
		expect(loadingIndicator).toBeNull();
	});
});

it("displays the placeholder when no value is selected", () => {
	const { getByRole, getByText } = render(
		<Dropdown options={options} defaultValue={""} name={"Select an option"} />
	);
	const dropdown = getByRole("combobox");
	expect(getByText("Select an option")).toBeInTheDocument();
	expect(dropdown).toHaveValue("");
});
