/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import * as messageHelper from "../MessageHelper"
import { callMissed } from "./CallMissed"

const dispatch = jest.fn()

jest.mock("../../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.spyOn(messageHelper, "storeCallDetailsInRedux").mockImplementation(jest.fn())

jest.mock("../../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))

jest.mock("../../../../../redux/store/store", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/store")
    return {
        ...actualFn,
        getState: jest.fn().mockImplementation(() => ({
            callReducer: {
                videoCallStatus: [{ callStatus: ECallStatus.RINGING, contextId: "contextId" }],
                callDetails: {
                    connectedCallDetails: {
                        contextId: "contextId",
                        callAcceptedTime: Date.now(),
                    },
                    incomingCall: {
                        contextId: "contextId",
                        participant: {
                            uuid: "uuid",
                        }
                    },
                    outgoingCall: {}
                }
            },
            externalReducer: {
                currentUser: {
                    uuid: "uuid",
                }
            }

        }))
    }
})

describe("callMissed tests", () => {
    it("should able to handle incoming call missed", () => {
        callMissed({ contextId: "contextId", dispatch })
        expect(dispatch).toBeDefined()
    })
})
