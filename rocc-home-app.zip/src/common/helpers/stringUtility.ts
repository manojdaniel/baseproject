/*
 * Created on Mon Oct 17 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, ERbacRole } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { DEVICE, DEVICE_ROLE_ROOM } from "../../constants/constants"
import en from "../../resources/translations/en-US"

const { FRONTDESK, SCHEDULER, EXPERTUSER, TECHNOLOGIST, ADMIN } = EClinicalRole

export const getRoleName = (role: string | EClinicalRole | ERbacRole) => {
    const { intl } = getIntlProvider()
    switch (role) {
        case ERbacRole.EXPERTUSER_ROLE:
        case EXPERTUSER:
            return intl.formatMessage({ id: "content.roles.expertUser", defaultMessage: en["content.roles.expertUser"] })
        case ADMIN:
            return intl.formatMessage({ id: "content.roles.Admin", defaultMessage: en["content.roles.Admin"] })
        case TECHNOLOGIST:
            return intl.formatMessage({ id: "content.roles.technologist", defaultMessage: en["content.roles.technologist"] })
        case DEVICE_ROLE_ROOM:
            return intl.formatMessage({ id: "content.roles.room", defaultMessage: en["content.roles.room"] })
        case FRONTDESK:
            return intl.formatMessage({ id: "content.roles.frontdesk", defaultMessage: en["content.roles.frontdesk"] })
        case SCHEDULER:
            return intl.formatMessage({ id: "content.roles.scheduler", defaultMessage: en["content.roles.scheduler"] })
        case ERbacRole.PROTOCOL_MANAGER_ROLE:
            return intl.formatMessage({ id: "content.roles.protocolManager", defaultMessage: en["content.roles.protocolManager"] })
        case ERbacRole.EXPERTUSER_WITH_INCOGNITO_ROLE:
            return intl.formatMessage({ id: "content.roles.euIncognito", defaultMessage: en["content.roles.euIncognito"] })
        case DEVICE:
            return intl.formatMessage({ id: "content.roles.Device", defaultMessage: en["content.roles.Device"] })
        default:
            return role
    }
}

export const renderHTMLCd = (str: string) => {
    return str.replace(/(&#(\d+);)/g, function (match, capture, charCode) {
        return String.fromCharCode(charCode)
    })
}
