"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import base64
import os

from src.constants.constants import CONTACT_TYPE, KVM_CONFIGURATION_DICT, ROCC_CONTACT_TYPES, SITES_DICT
from src.constants.enums import EDBRoles, ESummaryStates
from src.constants.headers import EXCEL_CUSTOMER_NAME, EXCEL_CUSTOMER_DISPLAY_NAME, EXCEL_HOSPITAL_FRONTDESK_PHONE, EXCEL_HOSPITAL_SCHEDULER_PHONE, \
    EXCEL_KVM_BOXILLA_IP, EXCEL_KVM_BOXILLA_REST_USER_NAME, EXCEL_KVM_BOXILLA_USER_NAME, EXCEL_STREET_ADDRESS, EXCEL_HOSPITAL_DISPLAY_NAME, \
    EXCEL_HOSPITAL_IDENTIFIER, EXCEL_HOSPITAL_CITY, EXCEL_HOSPITAL_POSTAL_CODE, EXCEL_HOSPITAL_PROVINCE
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_site_id_from_db_with_site_short_name
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.file_operations import file_reader
from src.utility.utility import get_str_value
from src.wrappers.graphql.queries.queries import fetch_contact_type_id_from_rocc_contact_types
from src.wrappers.graphql.mutations.mutations import insert_contact_type_id

LOG = create_logger("OrgMetadataAndSitesDataServices")


def construct_front_desk_object(site_details_list, organization_id, site_id, data, client, user_uuid):
    try:
        if len(data[EXCEL_HOSPITAL_FRONTDESK_PHONE] and data[EXCEL_HOSPITAL_FRONTDESK_PHONE].strip()):
            site_details_list.append({
                "site_id": site_id,
                "organization_id": organization_id,
                "contact_type_id": fetch_contact_type_id(client, user_uuid, EDBRoles.FRONTDESKROLE),
                "primary_contact_number": data[EXCEL_HOSPITAL_FRONTDESK_PHONE],
                "contact_name": "Front desk",
                "modified_by": user_uuid,
                "created_by": user_uuid
            })

            return site_details_list

    except RoccException as e:
        LOG.error(f"Exception occurred while fetching front desk contact {e}")
        raise RoccException(e.status_code, str(e.payload))


def construct_scheduler_object(site_details_list, organization_id, site_id, data, client, user_uuid):
    try:
        if len(data[EXCEL_HOSPITAL_SCHEDULER_PHONE] and data[EXCEL_HOSPITAL_SCHEDULER_PHONE].strip()):
            site_details_list.append({
                "site_id": site_id,
                "organization_id": organization_id,
                "contact_type_id": fetch_contact_type_id(client, user_uuid, EDBRoles.SCHEDULERROLE),
                "primary_contact_number": data[EXCEL_HOSPITAL_SCHEDULER_PHONE],
                "contact_name": "Scheduler",
                "modified_by": user_uuid,
                "created_by": user_uuid
            })

    except RoccException as e:
        LOG.error(f"Exception occurred while fetching scheduler contact {e}")
        raise RoccException(e.status_code, str(e.payload))
    return site_details_list


def fetch_contact_type_id(client, user_uuid, role):
    try:
        variables = {CONTACT_TYPE: role}
        contact_type_id = check_if_id_is_present(client.execute(
            fetch_contact_type_id_from_rocc_contact_types, variable_values=variables), ROCC_CONTACT_TYPES)
        if contact_type_id:
            return contact_type_id
        variables = {CONTACT_TYPE: role, "user_uuid": user_uuid}
        client.execute(insert_contact_type_id, variables_values=variables)
        response = client.execute(fetch_contact_type_id_from_rocc_contact_types, variable_values=variables)
        return response[ROCC_CONTACT_TYPES][0]["id"]
    except Exception as ex:
        LOG.exception(f"Failed to insert/query contact types with error {ex}")
        raise ex


def construct_sites(sites_dict, client, transaction_data, user_uuid, org_db_id=None):
    sites = []
    for site_identifier, sites_details in sites_dict.items():
        site_id = fetch_site_id_from_db_with_site_short_name(client=client, site_short_name=site_identifier)
        sites_details["site_id"] = site_id
        if site_id:
            transaction_data = update_summary_for_entity(transaction_data, "sites", site_identifier, ESummaryStates.EXISTING)
            LOG.info(f"Skipping insertion of data for site {site_identifier} since it is already present")
            continue
        LOG.info(f"Inserting data for new site {site_identifier}")
        transaction_data = update_summary_for_entity(transaction_data, "sites", site_identifier, ESummaryStates.NEW)
        site_obj = {
            "identifier": sites_details[EXCEL_HOSPITAL_IDENTIFIER],
            "name": sites_details[EXCEL_HOSPITAL_DISPLAY_NAME],
            "address": sites_details[EXCEL_STREET_ADDRESS],
            "city": sites_details[EXCEL_HOSPITAL_CITY],
            "state_or_province": sites_details[EXCEL_HOSPITAL_PROVINCE],
            "postal_code": get_str_value((sites_details[EXCEL_HOSPITAL_POSTAL_CODE])),
            "modified_by": user_uuid,
            "created_by": user_uuid,
        }
        if org_db_id is not None:
            site_obj["organization_id"] = org_db_id
        sites.append(site_obj)

    return sites


def construct_kvm_boxilla_object(kvm_dict, user_uuid, transaction_data, org_db_id=None):
    kvm_configs = []
    for kvm_details in kvm_dict.values():
        kvm_obj = {
            "boxilla_ip": kvm_details[EXCEL_KVM_BOXILLA_IP],
            "boxilla_user_name": kvm_details[EXCEL_KVM_BOXILLA_USER_NAME],
            "rest_user_name":  kvm_details[EXCEL_KVM_BOXILLA_REST_USER_NAME],
            "boxilla_machine_name": "",
            "created_by": user_uuid,
            "modified_by": user_uuid
        }
        summary_state = ESummaryStates.NEW
        if org_db_id is not None:
            kvm_obj["organization_id"] = org_db_id
            summary_state = ESummaryStates.EXISTING

        transaction_data = update_summary_for_entity(transaction_data, "kvm", kvm_details[EXCEL_KVM_BOXILLA_IP], summary_state)
        kvm_configs.append(kvm_obj)
    return kvm_configs


def construct_site_contacts_object(organization_id, site_id, data, client, user_uuid):
    try:
        site_details_list = []
        site_details_list = construct_front_desk_object(site_details_list, organization_id, site_id, data, client, user_uuid)
        site_details_list = construct_scheduler_object(site_details_list, organization_id, site_id, data, client, user_uuid)
    except RoccException as e:
        LOG.error("Exception occurred while creating site details object {e}")
        raise RoccException(e.status_code, str(e.payload))
    return site_details_list


def construct_eula_documents(locales, user_uuid, customer_short_name, org_db_id=None):
    try:
        eula_docs = []
        for locale in locales:
            documents = file_reader.terms_of_service(locale=locale)
            for doc in documents:
                file_handle = open(doc, "rb")
                data = base64.b64encode(file_handle.read()).decode("utf-8")
                document_name = os.path.splitext(os.path.basename(doc))[0]
                file_handle.close()
                eula_obj = {
                    "web_consent_document_name": document_name,
                    "locale": locale,
                    "data_blob": data,
                    "created_by": user_uuid,
                    "modified_by": user_uuid
                }
                if org_db_id is not None:
                    eula_obj["organization_id"] = org_db_id
                eula_docs.append(eula_obj)
        return eula_docs
    except Exception as e:
        LOG.exception(f"Failed to create EULA data for customer: {customer_short_name} with error: {e}")
        raise RoccException(500, "Failed to create EULA object")


def construct_new_org_details_object(data_dict, client, transaction_data, org_hsdp_uuid, user_uuid, locales, customer_short_name):
    try:
        sites = data_dict[SITES_DICT]
        kvm_dict = data_dict[KVM_CONFIGURATION_DICT]
        org_insert_object = {
            "org_identifier": list(sites.values())[0][EXCEL_CUSTOMER_NAME],
            "name": list(sites.values())[0][EXCEL_CUSTOMER_DISPLAY_NAME],
            "status": "Active",
            "modified_by": user_uuid,
            "created_by": user_uuid,
            "org_hsdp_uuid": org_hsdp_uuid,
            "integrator": {
                "data": {
                    "organizational": False,
                    "name": list(sites.values())[0][EXCEL_CUSTOMER_NAME],
                    "modified_by": user_uuid,
                    "created_by": user_uuid,

                }
            },
            "sites": {
                "data": construct_sites(sites, client, transaction_data, user_uuid)
            },
            "rocc_organization_documents": {
                "data": construct_eula_documents(locales, user_uuid, customer_short_name)
            },
            "rocc_kvm_configurations": {
                "data": construct_kvm_boxilla_object(kvm_dict, user_uuid, transaction_data)
            }
        }
        return org_insert_object

    except RoccException as e:
        LOG.exception(f"Failed to create customer org metadata object with error: {e}")
        raise RoccException(e.status_code, str(e.payload))
    except Exception as e:
        LOG.exception(f"Failed to create customer org metadata object with error: {e}")
        raise RoccException(500, "Failed to create customer org metadata object")
