/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import ProtocolTransferWizardContent from "./ProtocolTransferWizardContent"

jest.mock("react-redux", () => ({
    useSelector: () => ({}),
    useDispatch: () => void (0),
}))

describe("ProtocolTransferWizardContent component", () => {
    let wrapper: any
    it("should render 2 Grids", () => {
        wrapper = shallow(<ProtocolTransferWizardContent sourceScannerContent={"Source"} destinationScannerContent={"Destination"} />)
        expect(wrapper.find("Grid")).toHaveLength(2)
    })
})
