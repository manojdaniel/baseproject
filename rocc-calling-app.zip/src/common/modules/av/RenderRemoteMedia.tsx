/*
* Created on Thu Sept 23 2021
*
* Copyright (c) 2019 Philips
* (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
* Reproduction or transmission in whole or in part, in any form or by any
* means, electronic, mechanical or otherwise, is prohibited without the prior
* written consent of the copyright owner.
*/

import { CallWindowBody } from "@rocc/rocc-calling-components"
import { EClinicalRole, IAVCallDetails, IParticipantInfo } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React, { MutableRefObject, ReactFragment, useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { ACTIVE_CALL_MESSAGE, DEVICE } from "../../../constants/constants"
import { setCallMessage } from "../../../redux/actions/callActions"
import { IStore } from "../../../redux/interfaces/types"
import { DEFAULT_CALL_MESSAGE } from "../../../redux/reducers/callReducer"
import en from "../../../resources/translations/en-US"
import { getRoleName } from "../../helpers/helpers"

interface IRenderRemoteMedia {
    remoteMediaRef: MutableRefObject<any>
    dominantSpeaker: IParticipantInfo
    signalStrength: number
    remoteUserVideoStatus: boolean
    callDuration: ReactFragment
    isDesktopFullScreen: boolean
    activeCall: IAVCallDetails
}

const RenderRemoteMedia = (props: IRenderRemoteMedia) => {
    const { remoteMediaRef, dominantSpeaker, signalStrength, remoteUserVideoStatus, callDuration, isDesktopFullScreen, activeCall } = props
    const [message, setMessage] = useState("")
    const { callMessage } = useSelector((state: IStore) => ({
        callMessage: state.callReducer.callMessage,
    }))
    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const fetchSignalStrengthMessage = () => {
        switch (signalStrength) {
            case 0: return intl.formatMessage({ id: "content.callMessage.networkUnavailable", defaultMessage: en["content.callMessage.networkUnavailable"] })
            case 1:
            case 2: return intl.formatMessage({ id: "content.callMessage.slowInternet", defaultMessage: en["content.callMessage.slowInternet"] })
            case 3:
            case 4:
            case 5: return ""
            default: return ""
        }
    }

    useEffect(() => {
        const { numOfParticipants } = activeCall
        if (callMessage.messageType === ACTIVE_CALL_MESSAGE) {
            setTimeout(() => dispatch(setCallMessage(DEFAULT_CALL_MESSAGE)), 10000)
            setMessage(callMessage.message)
        } else if (numOfParticipants === -1) {
            setMessage(intl.formatMessage({ id: "content.callMessage.waitingForOtherParticipant", defaultMessage: en["content.callMessage.waitingForOtherParticipant"] }))
        } else if (numOfParticipants === 0) {
            setMessage(intl.formatMessage({ id: "content.callMessage.oneParticipant", defaultMessage: en["content.callMessage.oneParticipant"] }))
        } else if (numOfParticipants) {
            setMessage(fetchSignalStrengthMessage())
        }
    }, [callMessage, activeCall.numOfParticipants, signalStrength])

    if (activeCall.numOfParticipants <= 0) {
        return <CallWindowBody
            remoteMediaRef={undefined}
            displayName={""}
            metaData={""}
            description={""}
            callWindowFullscreen={isDesktopFullScreen}
            remoteVideoStatus={false}
            callMessage={message}
            weakSignalMessageStyle={false}
        />
    }

    const isGuest = (dominantSpeaker: any) => {
        const { secondaryUUID, clinicalRole } = dominantSpeaker
        return dominantSpeaker && secondaryUUID === "" && clinicalRole === DEVICE
    }

    const getUserDetails = (dominantSpeaker: any) => {
        const { TECHNOLOGIST } = EClinicalRole
        const details = {
            name: "",
            role: "",
            loggedInLocation: ""
        }
        if (dominantSpeaker) {
            const { secondaryUUID, name, secondaryName, clinicalRole, loggedInLocation } = dominantSpeaker
            const guest = intl.formatMessage({ id: "content.room.guest", defaultMessage: en["content.room.guest"] })
            if (dominantSpeaker) {
                details.name = secondaryUUID !== "" ? secondaryName : isGuest(dominantSpeaker) ? guest : name
                details.role = secondaryUUID !== "" ? getRoleName(TECHNOLOGIST) : getRoleName(clinicalRole)
                details.loggedInLocation = loggedInLocation
            }
        }
        return details
    }

    return (
        <CallWindowBody
            remoteMediaRef={remoteMediaRef}
            displayName={getUserDetails(dominantSpeaker).name}
            metaData={getRoleName(getUserDetails(dominantSpeaker).role)}
            description={getUserDetails(dominantSpeaker).loggedInLocation}
            callWindowFullscreen={isDesktopFullScreen}
            remoteVideoStatus={remoteUserVideoStatus}
            callMessage={message}
            weakSignalMessageStyle={true}
            callDuration={callDuration}
        />
    )
}

export default RenderRemoteMedia
