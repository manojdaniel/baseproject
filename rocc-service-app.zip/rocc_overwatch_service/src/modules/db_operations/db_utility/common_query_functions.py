"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from src.constants.constants import ROCC_APPLICATION_ROLES, ROCC_ORGANIZATIONS, ROCC_SITES, ID, CUSTOMER_NAME, ROCC_OVERWATCH_CUSTOMERS, INSERT, ROCC_USER_ORGANIZATION_MAPPINGS
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present, extract_id_from_mutation_response, extract_id_from_query_response, get_aggregate_count
from src.wrappers.graphql.mutations.mutations import insert_roles, update_user_org_mappings, assign_fse_to_customer, update_onboarding_fse_user_status
from src.wrappers.graphql.queries.queries import fetch_site_id_from_site_short_name, check_if_customer_exists_in_db, fetch_clinical_role_id_from_name, check_if_organization_present, fetch_organization_mappings_by_user, check_if_fse_is_assigned_to_org, fetch_user_db_id_from_uuid

LOG = create_logger("CommonQueryFunctions")


def get_site_id_from_site_short_name(client, site_short_name, sites):
    try:
        for site_key, site in sites.items():
            if site_key == site_short_name and site.get("site_id", False):
                return site.get("site_id")
        # Checking if site name is present in DB since it is not in Dictionary.
        site_id = fetch_site_id_from_db_with_site_short_name(client=client, site_short_name=site_short_name)
        if site_id:
            return site_id

    except KeyError as ex:
        LOG.exception(f"Failed to fetch site id from site short name - '{site_short_name}' with KeyError: {ex}")
        LOG.error(traceback.print_exc())
    except Exception as ex:
        LOG.exception(f"Failed to fetch site id from site short name - '{site_short_name}' with error: {ex}")
        LOG.error(traceback.print_exc())
    return False


def fetch_site_id_from_db_with_site_short_name(client, site_short_name):
    try:
        response = client.execute(fetch_site_id_from_site_short_name, variable_values={"identifier": site_short_name})
        return check_if_id_is_present(response, ROCC_SITES)
    except Exception as ex:
        LOG.exception(f"Failed to fetch site id for site short name - '{site_short_name}' with Error: {ex}")
    return False


def fetch_overwatch_customer_id_from_name(customer_name, client):
    variables = {CUSTOMER_NAME: customer_name}
    try:
        response = client.execute(check_if_customer_exists_in_db, variable_values=variables)
        if len(response[ROCC_OVERWATCH_CUSTOMERS]):
            LOG.info(f"Customer: {customer_name} exists in database.")
            return response[ROCC_OVERWATCH_CUSTOMERS][0][ID]

        LOG.error(f"Customer {customer_name} not found")
        raise RoccException(404, f"Customer: {customer_name} not found")

    except Exception as ex:
        LOG.exception(f"Exception while checking Customer in DB: {ex}")
        raise RoccException(status_code=500, payload="Exception while checking Customer in DB") from ex


def fetch_org_db_id_from_identifier(client, customer_identifier):
    try:
        org_db_id = check_if_id_is_present(client.execute(check_if_organization_present, variable_values={"customer_identifier": customer_identifier}), ROCC_ORGANIZATIONS)
        LOG.info(f"Org DB id: {org_db_id}")
        return org_db_id
    except Exception as ex:
        LOG.exception(f"Failed to fetch org_db_id for customer identifier: {customer_identifier} with error: {ex}")
    return False


def fetch_clinical_role_id(role, client, user_uuid):
    try:
        if not role:
            return None
        role = role.lower()
        query_response = client.execute(fetch_clinical_role_id_from_name, variable_values={"role": role})
        role_id = check_if_id_is_present(query_response, ROCC_APPLICATION_ROLES)
        if role_id:
            return role_id
        db_result = client.execute(insert_roles, variable_values={"role": role, "user_uuid": user_uuid})
        return extract_id_from_mutation_response(db_result, f"{INSERT}{ROCC_APPLICATION_ROLES}")
    except Exception as ex:
        LOG.exception(f"Failed to add roles in DB with error: {ex}")


def get_organization_user_mappings(client, variable_values):
    try:
        query_response = client.execute(fetch_organization_mappings_by_user, variable_values=variable_values)
        return query_response[ROCC_USER_ORGANIZATION_MAPPINGS]
    except Exception as ex:
        LOG.exception(f"Failed to fetch user organization mappings from DB with error: {ex}")


def update_user_org_mapping(client, variable_values):
    try:
        client.execute(update_user_org_mappings, variable_values=variable_values)
        LOG.info("Updated org_user_mapping.")
    except Exception as ex:
        LOG.exception(f"Failed to update user organization mappings in DB with error: {ex}")


def check_and_add_fse_to_org_mapping(client, fse_user_uuid, org_db_id):
    try:
        fse_user_db_id = extract_id_from_query_response(data=client.execute(fetch_user_db_id_from_uuid, variable_values={"user_uuid": fse_user_uuid}),
                                                        table_name="rocc_users")
        response = client.execute(check_if_fse_is_assigned_to_org, variable_values={
            "org_db_id": org_db_id,
            "fse_user_db_id": fse_user_db_id
        })
        count = get_aggregate_count(response, "rocc_rocc_user_organization_mappings_aggregate")
        if count == 0:
            client.execute(assign_fse_to_customer, variable_values={
                "org_db_id": org_db_id,
                "user_db_id": fse_user_db_id,
                "fse_user_uuid": fse_user_uuid,
            })
    except Exception as ex:
        LOG.exception(f"Failed to add user organization mappings for Fse user: {fse_user_uuid} and org: {org_db_id} in DB with error: {ex}")


def update_fse_user_status(client, fse_user_email_id):
    update_status = False
    try:
        client.execute(update_onboarding_fse_user_status, variable_values={
            "email": fse_user_email_id
        })
        LOG.info("Updated Fse user status")
        update_status = True
    except Exception as ex:
        LOG.exception(f"Failed to update user organization mappings in DB with error: {ex}")
    return update_status
