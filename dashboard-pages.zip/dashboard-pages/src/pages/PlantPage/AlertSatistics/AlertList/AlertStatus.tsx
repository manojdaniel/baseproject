import React, { useRef, useEffect, useState } from "react";
import AlertStatusList from "table/AlertStatusList";
import { useDispatch, useSelector } from "react-redux";
import {
  getAlertStatisticsAlertListByPlantId,
  getPlantAlertListStateDropdownList,
  getPlantAlertStatus,
  getPlotDeviationModel,
  getGlobalSelecetedAsset,
  getPlantAlertListDepartmentDropdownList
} from "../../../../redux/reducers/CommonReducer";
import Loader from "components/Loader";
import Dropdown from "components/Dropdown";
import { useNavigate } from "react-router-dom";
import { encryptRSAData } from "../../../../utility/rsa";

interface Props {
  buttonName: string;
  onClickHandler: any;
}

const AlertList = () => {
  let dispatch = useDispatch();
  let navigate = useNavigate();
  const [selectedState, setSelectedState] = useState<any>({ "value": 0, "label": "All" });
  const [selectedDepartment, setSelectedDepartment] = useState<any>({ "value": 0, "label": "All" });

  const { StatisticsAlertListByPlantId, globalSelecetedPlant, loadingStatisticsAlertListByPlantId,
    plantAlertStatus, plantAlertListStateDropdown, loadingPlantAlertListStateDropdown,
    plantAlertListDepartmentDropdown,
    plantDepartmentStatus, loadingPlantAlertListDepartmentDropdown } = useSelector((state: any) => ({
      StatisticsAlertListByPlantId: state.Common.StatisticsAlertListByPlantId,
      globalSelecetedPlant: state.Common.globalSelecetedPlant,
      loadingStatisticsAlertListByPlantId: state.Common.loadingStatisticsAlertListByPlantId,
      plantAlertStatus: state.Common.plantAlertStatus,
      plantAlertListStateDropdown: state.Common.plantAlertListStateDropdown,
      loadingPlantAlertListStateDropdown: state.Common.loadingPlantAlertListStateDropdown,

      plantDepartmentStatus: state.Common.plantDepartmentStatus,
      plantAlertListDepartmentDropdown: state.Common.plantAlertListDepartmentDropdown,
      loadingPlantAlertListDepartmentDropdown: state.Common.loadingPlantAlertListDepartmentDropdown,
    }));

  const handleStateDropDown = (e: any) => {
    setSelectedState(e);
    setSelectedDepartment({ "value": 0, "label": "All" });
    dispatch(getAlertStatisticsAlertListByPlantId(encryptRSAData(`plantId=${globalSelecetedPlant.value}&state=${e.value}&department=0&assetId=0`)));
  }

  useEffect(() => {
    try {
      document.body.style.cursor = "default";
    } catch (error) {

    }
    if (Object.keys(plantAlertStatus).length > 0 && Object.keys(plantDepartmentStatus).length > 0) {
      setSelectedState(plantAlertStatus);
      setSelectedDepartment(plantDepartmentStatus);
      dispatch(getPlantAlertListStateDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=0`)));
      dispatch(getPlantAlertListDepartmentDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}`)));
      dispatch(getAlertStatisticsAlertListByPlantId(encryptRSAData(`plantId=${globalSelecetedPlant.value}&state=${plantAlertStatus.value}&department=${plantDepartmentStatus.value}&assetId=0`)));
    }

    else if (Object.keys(plantAlertStatus).length > 0) {
      setSelectedState(plantAlertStatus);
      dispatch(getPlantAlertListStateDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=0`)));
      dispatch(getPlantAlertListDepartmentDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}`)));
      dispatch(getAlertStatisticsAlertListByPlantId(encryptRSAData(`plantId=${globalSelecetedPlant.value}&state=${plantAlertStatus.value}&department=0&assetId=0`)));
    }
    else {
      dispatch(getPlantAlertListStateDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=0`)));
      dispatch(getPlantAlertListDepartmentDropdownList(encryptRSAData(`plantId=${globalSelecetedPlant.value}`)));
      dispatch(getAlertStatisticsAlertListByPlantId(encryptRSAData(`plantId=${globalSelecetedPlant.value}&state=0&department=0&assetId=0`)));
    }
  }, [plantAlertStatus, plantDepartmentStatus]);

  // useEffect(() => {
  //   if (Object.keys(plantDepartmentStatus).length > 0) {
  //     setSelectedDepartment(plantDepartmentStatus);
  //     dispatch(getPlantAlertListStateDropdownList(`${globalSelecetedPlant.value}/0/30757062`));
  //     dispatch(getPlantAlertListDepartmentDropdownList(`${globalSelecetedPlant.value}/30757062`));
  //     dispatch(getAlertStatisticsAlertListByPlantId(`${globalSelecetedPlant.value}/18/0/${plantDepartmentStatus.value}/0`));
  //   }
  //   else {
  //     dispatch(getPlantAlertListStateDropdownList(`${globalSelecetedPlant.value}/0/30757062`));
  //     dispatch(getPlantAlertListDepartmentDropdownList(`${globalSelecetedPlant.value}/30757062`));
  //     dispatch(getAlertStatisticsAlertListByPlantId(`${globalSelecetedPlant.value}/18/0/0/0`));
  //   }
  // }, [plantDepartmentStatus]);


  const handleDepartmentDropDown = (e: any) => {
    setSelectedDepartment(e);
    dispatch(getAlertStatisticsAlertListByPlantId(encryptRSAData(`plantId=${globalSelecetedPlant.value}&state=0&department=${e.value}&assetId=0`)));
  }

  const handleUpdate = (action: any, data: any, data1?: any, data2?: any, data3?: any, data4?: any) => {
    if (action === 'assetModel') {
      dispatch(getGlobalSelecetedAsset({ value: data, label: data }));
      navigate(`/assets/assetModel`);
    }
    else if (action === 'assetModel') {
      dispatch(getGlobalSelecetedAsset({ value: data, label: data }));
      navigate(`/assets/assetModel`);
    }
    else if (action === 'plots') {
      dispatch(getPlotDeviationModel({ valu: data, label: data }));
      dispatch(getGlobalSelecetedAsset({ value: data, label: data }));
      navigate(`/assets/plots`, { state: { data: data, data2: data1, data3: data2 } });
    }
    else if (action === 'alertlist') {
      dispatch(getGlobalSelecetedAsset({ value: data, label: data }));
      navigate(`/assets/alertList`, {
        state: { data: data, data2: data1, data3: data2, alertState: data3, alertId: data4},
      });
    }
  }

  return (
    <>
      {loadingStatisticsAlertListByPlantId ?
        <Loader /> :
        <>
          <div className="nf-right">
            <div id="new-filter" className="mt0 pb25">
              <div className="nf-left">
                <div className="title">PLANT ALERT STATUS</div>
              </div>
              <div className="nf-right">
                <div>
                  <label className="cus-label">State</label>
                  <Dropdown
                    name={"State"}
                    options={plantAlertListStateDropdown}
                    handleChange={handleStateDropDown}
                    value={selectedState}
                    defaultValue={""}
                    loading={loadingPlantAlertListStateDropdown}
                  />
                </div>
                <div>
                  <label className="cus-label">Department</label>
                  <Dropdown
                    name={"Department"}
                    options={plantAlertListDepartmentDropdown}
                    handleChange={handleDepartmentDropDown}
                    value={selectedDepartment}
                    defaultValue={""}
                    loading={loadingPlantAlertListDepartmentDropdown}
                  />
                </div>
              </div>
            </div>

          </div>
          <AlertStatusList
            data={StatisticsAlertListByPlantId}
            handleUpdate={handleUpdate}
          />
        </>
      }
    </>
  )
};
export default AlertList;
