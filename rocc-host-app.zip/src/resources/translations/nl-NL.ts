/*
* Created on Wed May 30 2022
*
* Copyright (c) 2019 Philips
* (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
* Reproduction or transmission in whole or in part, in any form or by any
* means, electronic, mechanical or otherwise, is prohibited without the prior
* written consent of the copyright owner.
*/


import nlJSON from "../locales/nl_NL.json"

const nl_NL = { ...nlJSON }

export default nl_NL
