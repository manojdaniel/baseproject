/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoccWorkflow } from "@rocc/rocc-client-services"

/* Global Store */
export const APP_NAME = "CC_CALLING"
export const STORAGE_KEY = "REDUX_STATE"

export const TELEPRESENCE_SIDEBAR = "TelepresenceSidebar"

export const PARENT_STORE = "CC_HOST"
export const CONSOLE_STORE = "CC_CONSOLE"
export const DEVICE_MISSED_CALL_SIDEBAR = "deviceMissedCallSidebar"
export const GUEST = "Guest"
export const DEVICE_ROLE_ROOM = "Room"
export const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
export const COMMANDCENTER = "Command Center"
export const CONSOLE_REDUCER = "consoleReducer"
export const COMMUNICATION_VENDOR_NAME_UNAVAILABLE = "COMMUNICATION_VENDOR_NAME_UNAVAILABLE"

/* API Constants */
export const ACCEPT = "Accept"
export const POST = "POST"
export const CONTENT_TYPE = "Content-Type"
export const APPLICATION_JSON = "application/json"
export const AUTHORIZATION = "Authorization"
export const API_VERSION = "api-version"
export const ORG_CONTEXT_HEADER = "org_ctxt_header"
export const ORG_ID = "Org-Id"
export const DEFAULT_API_VERSION = "1.0.0"
export const API_VERSION_110 = "1.1.0"

export enum HTTP_STATUS {
    OK = 200,
    CREATED = 201,
    UNAUTHORIZED = 401,
    INTERNAL_SERVER_ERROR = 500,
}

/** Conversation Constants */
export const CHAT = "CHAT"

/** Set Call MediaType */
export const VIDEO_CALL_MEDIATYPE = ["AUDIO", "VIDEO"]
export const AUDIO_CALL_MEDIATYPE = ["AUDIO"]

/** Generic constants */
export const TABID = "tabId"
export const CALLTYPE = "INAPP_CALL"
export const CONTEXT_ID = "contextId"

/** Call Contants */
export const CALL_TYPE = "CALL_TYPE"
export const ADD_PARTICIPANT = "ADD_PARTICIPANT"
export const CALLING = "CALLING"
export const INCOMING_CALL = "INCOMING_CALL"
export const OUTGOING_CALL = "OUTGOING_CALL"
export const RINGING = "RINGING"
export const CALL_ACCEPT = "CALL_ACCEPT"
export const CALL_REJECT = "CALL_REJECT"
export const CALL_END = "CALL_END"
export const CALL_HOLD = "CALL_HOLD"
export const CALL_RESUME = "CALL_RESUME"
export const CALL_INFO = "CALL_INFO"
export const CALL_DISCONNECTED = "CALL_DISCONNECTED"
export const CALL_NOTANSWERED = "CALL_NOT_ANSWERED"
export const DEVICE_CONSOLE_DISCONNECT = "DEVICE_CONSOLE_DISCONNECT"
export const CALL_MISSED = "CALL_MISSED"
export const CALL_FAILED = "CALL_FAILED"
export const CALL_CANCELLED = "CALL_CANCELLED"
export const ALREADY_ON_CALL = "ALREADY_ON_CALL"
export const ACTIVE_CALL_MESSAGE = "ACTIVE_CALL_MESSAGE"

export const EVENT_SUBSCRIBED = "subscribed"
export const EVENT_UNSUBSCRIBED = "unsubscribed"
export const EVENT_TRACK_SUBSCRIBED = "trackSubscribed"
export const EVENT_TRACK_UNSUBSCRIBED = "trackUnsubscribed"
export const EVENT_TRACK_ENABLED = "trackEnabled"
export const EVENT_TRACK_DISABLED = "trackDisabled"
export const EVENT_TRACK_PUBLISHED = "trackPublished"
export const EVENT_TRACK_UNPUBLISHED = "trackUnpublished"
export const EVENT_NETWORK_QUALITY_CHANGED = "networkQualityLevelChanged"
export const EVENT_DOMINANT_SPEAKER_CHANGED = "dominantSpeakerChanged"
export const EVENT_PARTICIPANT_CONNECTED = "participantConnected"
export const EVENT_PARTICIPANT_DISCONNECTED = "participantDisconnected"
export const EVENT_RECONNECTING = "reconnecting"
export const EVENT_RECONNECTED = "reconnected"
export const EVENT_DISCONNECTED = "disconnected"
export const EVENT_TRACK_STARTED = "started"
export const EVENT_TRACK_STOPPED = "stopped"

/** Logger */
/* Log constants */
export const ERROR = "ERROR"
export const WARNING = "WARNING"
export const INFO = "INFO"
export const DEBUG = "DEBUG"

export const CALL_MESSAGES = {
    CALLDECLINED: "Call declined",
    CALLMISSED: "Missed call",
    CALLUNANSWERED: "Call not answered",
    CALL_FAILED: "Call failed",
    CALL_CANCELLED: "Call cancelled",
    CALL_REJECTED: "Call rejected",
    LAST_PARTICIPANT_ON_CALL: "Looks like you're the only one on the call",

}

/** Track priority */
export const TRACK_PRIORITY = {
    LOW: "low",
    HIGH: "high",
    STANDARD: "standard",
}

export const INIT_AV_MESSAGE = { contextId: "", eventType: "", participant: "" }
export const INIT_RIGHTSIDE_PANEL = { activeRightPanel: "", displayRightSidePanel: false, desktopFullScreen: false }

/** Use a common seperator */
export const ROW_SEPERATOR = "~"
export const COLUMN_SEPERATOR = ":"

/** Reducer names */
export const USER_REDUCER = "userReducer"
export const CONFIG_REDUCER = "configReducer"
export const APP_REDUCER = "appReducer"
export const CUSTOMER_REDUCER = "customerReducer"
export const MODAL_REDUCER = "modalReducer"

/** Timeout constants */
export const TIMEOUT_10 = 10
export const TIMEOUT_1000 = 1000
export const TIMEOUT_3000 = 3000
export const TIMEOUT_30000 = 30000
export const TIMEOUT_40000 = 40000
export const TIMEOUT_60000 = 60000

export const BANDWIDTH_PROFILE_MODE = {
    COLLABORATION: "collaboration",
    GRID: "grid",
}

export const AUDIO = "audio"
export const VIDEO = "video"
export const DATA = "data"
export const AUDIO_INPUT = "audioinput"
export const AUDIO_OUTPUT = "audiooutput"
export const VIDEO_INPUT = "videoinput"
export const LOCAL_VIDEO = "localVideo"
export const DEFAULT = "default"

export const DEVICE = "device"
export const EN_LOCALE = "en"
export const EN_LANGUAGE = "en-US"
export const DE_LOCALE = "de"
export const FR_LOCALE = "fr"

export const PUTTING_CALL_ON_HOLD = "PUTTING_CALL_ON_HOLD"
export const PLACING_CALL = "PLACING_CALL"
export const HOLD_CALL_SUCCESS = "HOLD_CALL_SUCCESS"
export const HOLD_CALL_FAILED = "HOLD_CALL_FAILED"
export const PLACE_CALL_SUCCESS = "PLACE_CALL_SUCCESS"
export const PLACE_CALL_FAILED = "PLACE_CALL_FAILED"
export const DAEMONIZE_CALL_SUCCESS = "DAEMONIZE_CALL_SUCCESS"
export const DAEMONIZE_CALL_FAILED = "DAEMONIZE_CALL_FAILED"
export const RESUME_CALL_SUCCESS = "RESUME_CALL_SUCCESS"
export const RESUME_CALL_FAILED = "RESUME_CALL_FAILED"
export const CALL_DISCONNECT_SUCCESS = "CALL_DISCONNECT_SUCCESS"
export const CALL_DISCONNECT_FAILED = "CALL_DISCONNECT_FAILED"
export const TOGGLE_FAILED = "TOGGLE_FAILED"
export const TOGGLE_SUCCESS = "TOGGLE_SUCCESS"
export const MFE_LOGOUT_ELECT = "MFE_LOGOUT_ELECT"
export const MFE_LOGGED_OUT = "MFE_LOGGED_OUT"

export const TRACKED_WORKFLOWS = [
    ERoccWorkflow.MULTI_EDIT_INITIATE_CALL,
    ERoccWorkflow.MULTI_EDIT_START_EDITING,
    ERoccWorkflow.PARK_AND_INITIATE_CALL,
    ERoccWorkflow.PARK_AND_START_EDITING,
    ERoccWorkflow.PARK_AND_RESUME,
    ERoccWorkflow.DISCONNECT_CALL,
    ERoccWorkflow.DISCONNECT_CALL_WITHOUT_MODAL,
    ERoccWorkflow.DISCONNECT_CONSOLE_SESSION,
    ERoccWorkflow.TOGGLE_CALL_CONTROL,
    ERoccWorkflow.LOGOUT,
]
