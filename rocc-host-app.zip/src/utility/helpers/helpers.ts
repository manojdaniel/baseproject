/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {
    ACCESS_TOKEN, APP_NAME, APP_URI_ARGS, closeGraphQLConnection, DEFAULT_CONTACT_INFO, EClinicalRole, EConnectionType, EResponse,
    ERoccWorkflow, FeatureFlagHelper, getLocationDetailsForId, IAVCallDetails, ICallStatus, IConfigsDataType, IConsoleSession, IContactInfo,
    IFseData, ILocationInfo, IParentStore, IParticipantInfo, ISiteContact, IUrls, IUserInfo, NATIVE_APP_URI, NATIVE_APP_URI_START, ROCC_FEATURES
} from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "react"
import { updatePresenceService } from "../../common/presence/presenceService"

import {
    API_METHOD, API_VERSION_STRING, BUNDLE_NAME, CALLING_APP_STORE, CCTV_WINDOW_FEATURES, CC_PATH, COLUMN_SEPERATOR, CONSOLE_APP_STORE, DEFAULT_API_VERSION, DOWNLOAD_URL, FOURTH_POSITION,
    GE, LOCALHOST, MANAGE_GRAPHQL_BUNDLE_INFOS_EP, ONBOARDING_STEPS, ORG_ID, RAD_CONNECT_RAD_APP, RAD_CONNECT_RAD_APP_REMOTE_ENTRY, RAD_CONNECT_TECH_APP, RAD_CONNECT_TECH_APP_REMOTE_ENTRY, SECOND_POSITION,
    SIEMENS, THIRD_POSITION, UPDATER_NAME, applicationName, companyName, BUNDLE_VERSION, API_ENDPOINT
} from "../../constants/constants"

import { ADMIN_ROUTE, LOGIN_ROUTE, REGISTER_ROUTE, UNAUTHORIZED_ROUTE } from "../../constants/routes"
import { TRACK, transformSessionTypeForAnalytics } from "../../constants/tracking"
import { updateFseMode } from "../../redux/actions/appActions"
import { updateLocale } from "../../redux/actions/configActions"
import { GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../redux/actions/types"
import { updateMetasiteIdForCurrentUser } from "../../redux/actions/userAction"
import { fetchDefaultConfiguration } from "../../redux/services/appServices"
import { closeSessionFromServer } from "../../redux/services/userServices"
import globalStore from "../../redux/store/globalStore"
import store, { persistor } from "../../redux/store/store"
import { convertContact } from "../../redux/transformer/customerTransformer"
import en from "../../resources/locales/en_US.json"
import { EUserPresence } from "../../types/types"
import { determineRoute } from "../feature-flags/featureFlag"
import { getDurationInFormat } from "../math/mathUtility"

export let cctvWindow: Window | null = null

export const populateSiteContactsForLocation = (siteContacts: string[], location: ILocationInfo) => {
    siteContacts && siteContacts.forEach((siteContact: any) => {
        location.locationContacts.push({
            id: convertContact(siteContact.split(COLUMN_SEPERATOR)[FOURTH_POSITION], siteContact.split(COLUMN_SEPERATOR)[0]).contact_id,
            name: siteContact.split(COLUMN_SEPERATOR)[SECOND_POSITION],
            phoneNumber: siteContact.split(COLUMN_SEPERATOR)[THIRD_POSITION],
            clinicalRole: convertContact(siteContact.split(COLUMN_SEPERATOR)[FOURTH_POSITION], siteContact.split(COLUMN_SEPERATOR)[0]).clinicalRole
        })
    })
}

export const getApplicationName = () => {
    return applicationName
}

export const getFullApplicationName = () => {
    return `${companyName} ${applicationName}`
}

export const getAnywhereLocationNameText = () => {
    const { intl } = getIntlProvider()
    return intl.formatMessage({ id: "content.locations.anywhere", defaultMessage: en["content.locations.anywhere"] })
}

export const cleanUpTasks = async (user: IUserInfo, urls: IUrls) => {
    closeGraphQLConnection(true)
    //post offline status 
    await updatePresenceService(user, EUserPresence.OFFLINE, urls.COMMUNICATION_SERVICES_URL, user.uuid, "", false)
    await closeSessionFromServer(user, urls.PROXY_URL)
    return EResponse.SUCCESS
}

export const cacheCleaner = (hardStop: boolean = false) => {
    closeGraphQLConnection(hardStop)
    persistor.purge()
}

export const getSteps = (steps: string) => {
    const { intl } = getIntlProvider()
    const { WELCOME, AGREEMENT, COMPLETE } = ONBOARDING_STEPS
    switch (steps) {
        case WELCOME:
            return intl.formatMessage({ id: "content.eu.welcome", defaultMessage: en["content.eu.welcome"] })
        case AGREEMENT:
            return intl.formatMessage({ id: "content.terms.title", defaultMessage: en["content.terms.title"] })
        case COMPLETE:
            return intl.formatMessage({ id: "content.eu.complete", defaultMessage: en["content.eu.complete"] })
        default:
            return steps
    }
}

export const getMappedDependency = <T>(listOfObjects: T[], key: keyof T) => JSON.stringify(listOfObjects.map((entry: T) => entry[key]))

export const loginErrorMessages = (errorMessage: string) => {
    const { intl } = getIntlProvider()
    const wrongUserCredentialsCodegrant = "content.displayErrorMessages.wrongUserCredentialsCodegrant"
    switch (errorMessage) {
        case "WRONG_USER_CREDENTIALS":
            return intl.formatMessage({ id: "content.displayErrorMessages.wrongUserCredentials", defaultMessage: en["content.displayErrorMessages.wrongUserCredentials"] })
        case "WRONG_USER_CREDENTIALS_CODEGRANT":
            return intl.formatMessage({ id: wrongUserCredentialsCodegrant, defaultMessage: en[wrongUserCredentialsCodegrant] })
        case "FORBIDDEN":
            return intl.formatMessage({ id: "content.displayErrorMessages.deactivated", defaultMessage: en["content.displayErrorMessages.deactivated"] })
        case "DEFAULT_MESSAGE":
            return intl.formatMessage({ id: "content.displayErrorMessages.defaultMessage", defaultMessage: en["content.displayErrorMessages.defaultMessage"] })
        case "NETWORK_CONNECTIVITY":
            return intl.formatMessage({ id: "content.displayErrorMessages.networkConnectivity", defaultMessage: en["content.displayErrorMessages.networkConnectivity"] })
        case "REQUEST_PROCESSING_FAILED":
            return intl.formatMessage({ id: "content.displayErrorMessages.requestProcessignFailed", defaultMessage: en["content.displayErrorMessages.requestProcessignFailed"] })
        default:
            return ""
    }
}

export const getLandingPageRoute = (currentUser: IUserInfo, fseData: IFseData, featureFlags: any, history: any, dispatch: Dispatch<any>, location?: any) => {
    if (currentUser && currentUser.clinicalRole) {
        if (!currentUser.onBoarded) {
            history.push(REGISTER_ROUTE)
        } else {
            let role = currentUser.clinicalRole
            if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_RADCONNECT)) {
                /* Note: If radConnect flag is enabled landing page should be consults */
                role = currentUser.allRoles.includes(EClinicalRole.TECHNOLOGIST) ? EClinicalRole.TECHNOLOGIST : role
                role = currentUser.allRoles.includes(EClinicalRole.RADIOLOGIST) ? EClinicalRole.RADIOLOGIST : role
            }
            if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_PHARMA)) {
                /* Note: If pharma flag is enabled landing page should be pharma app for pharma admin and specialists */
                role = currentUser.allRoles.includes(EClinicalRole.PHARMA_SPECIALIST) ? EClinicalRole.PHARMA_SPECIALIST : role
                role = currentUser.allRoles.includes(EClinicalRole.PHARMA_ADMIN) ? EClinicalRole.PHARMA_ADMIN : role
            }
            const navigateTo = location?.state?.referer ? location.state.referer : determineRoute(role)

            history.push(navigateTo)
        }
    } else {
        if (fseData.customerName) {
            dispatch(updateFseMode(true))
            dispatch(updateMetasiteIdForCurrentUser(fseData.customerName, EClinicalRole.ADMIN))
            history.push(ADMIN_ROUTE)
        } else {
            history.push(UNAUTHORIZED_ROUTE)
        }
    }
}

export const validateStore = (currentUser?: IUserInfo) => {
    let userInfo = currentUser
    if (!currentUser) {
        const state: IParentStore = store.getState()
        userInfo = state.userReducer.currentUser
    }
    return userInfo?.accessToken
}

export const fetchRenderPage = () => {
    const state: IParentStore = store.getState()
    const { currentUser } = state.userReducer
    const { featureFlags } = state.featureFlagsReducer
    let navigateTo = UNAUTHORIZED_ROUTE
    if (currentUser && currentUser.id && !currentUser.onBoarded) {
        navigateTo = REGISTER_ROUTE
    } else if (currentUser && currentUser.clinicalRole) {
        let role = currentUser.clinicalRole
        if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_RADCONNECT)) {
            /* Note: If radConnect flag is enabled landing page should be consults */
            role = currentUser.allRoles.includes(EClinicalRole.TECHNOLOGIST) ? EClinicalRole.TECHNOLOGIST : role
            role = currentUser.allRoles.includes(EClinicalRole.RADIOLOGIST) ? EClinicalRole.RADIOLOGIST : role
        }
        navigateTo = determineRoute(role)
    }
    return validateStore(currentUser) ? navigateTo : LOGIN_ROUTE
}

export const fetchConsultRoutes = () => {
    const state: IParentStore = store.getState()
    const { currentUser } = state.userReducer
    const { featureFlags } = state.featureFlagsReducer
    const flag = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_RADCONNECT)
    let response = undefined
    if (flag) {
        if (currentUser.allRoles.includes(EClinicalRole.TECHNOLOGIST)) {
            response = { url: RAD_CONNECT_TECH_APP_REMOTE_ENTRY, scope: RAD_CONNECT_TECH_APP, module: "./App", props: { mode: "CC" } }
        } else {
            if (currentUser.allRoles.includes(EClinicalRole.RADIOLOGIST)) {
                response = { url: RAD_CONNECT_RAD_APP_REMOTE_ENTRY, scope: RAD_CONNECT_RAD_APP, module: "./App" }
            }
        }
    }
    return response
}

export const isDev = () => {
    const state: IParentStore = store.getState()
    const { ROCC_DEV } = state.configReducer.configs
    return ROCC_DEV === "true"
}

export const isExpert = (currentUser: IUserInfo) => {
    return currentUser.allRoles.includes(EClinicalRole.EXPERTUSER)
}

export const getReduxState = () => {
    const state: IParentStore = store.getState()
    return state
}

export const filterCurrentUserFromContacts = (contacts: IContactInfo[], currentUser: IUserInfo) => {
    const filteredContacts = contacts.filter((contact: IContactInfo) => contact.uuid !== currentUser.uuid)
    return filteredContacts
}

export const convertSiteContactToContactInfo = (site: ILocationInfo): IContactInfo[] => {
    const state: IParentStore = store.getState()
    const { locations } = state.customerReducer
    const contacts: IContactInfo[] = site.locationContacts.map((siteContact: ISiteContact) =>
    ({
        ...DEFAULT_CONTACT_INFO, id: siteContact.id, name: siteContact.name, description: getLocationDetailsForId(locations, site.id).name,
        phoneNumber: siteContact.phoneNumber, clinicalRole: siteContact.clinicalRole, allRoles: [siteContact.clinicalRole], siteId: [site.id.toString()]
    })
    )
    return contacts
}

export const getSingleKeyListFromList = (items: any[], key: string) => {
    const itemIdList: string[] = []
    if (items) {
        items.forEach((item: any) => {
            if (item[key] !== "") {
                itemIdList.push(item[key])
            }
        })
    }
    return itemIdList
}

export const checkCallStatus = (videoCallStatus: ICallStatus[], status: string[]) => {
    return videoCallStatus.some((x) => status.includes(x.callStatus))
}

export const isEmptyObject = (value: Object) => {
    return Object.keys(value).length === 0 && value.constructor === Object
}

export const checkIfParticularSessionGoingOn = (activeSessions: any[], sessionType: EConnectionType[]) => {
    return activeSessions.findIndex(session => sessionType.includes(session.connectionType)) > -1
}

export const isDemoEnv = () => {
    const state: IParentStore = store.getState()
    const { DEMO_ENV } = state.configReducer.configs
    return DEMO_ENV === "true"
}

export const fetchDemoVideoUrl = (roomName: string, connectionType: EConnectionType) => {
    let demoVideoUrl = ""
    const state: IParentStore = store.getState()
    const {
        SIEMENS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO,
        GE_MR_VIEWCONSOLE_DEMO_ENV_VIDEO,
        PHILIPS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO,
        SIEMENS_MR_EDITCONSOLE_DEMO_ENV_VIDEO,
        GE_MR_EDITCONSOLE_DEMO_ENV_VIDEO,
        PHILIPS_MR_EDITCONSOLE_DEMO_ENV_VIDEO
    } = state.configReducer.configs.DEMO_CONSOLE_VIDEOS
    const { VIEW, INCOGNITO_VIEW, FULL_CONTROL, PROTOCOL_MANAGEMENT } = EConnectionType
    if (roomName && connectionType) {
        if (roomName.includes(SIEMENS)) {
            if ([VIEW, INCOGNITO_VIEW].includes(connectionType)) {
                demoVideoUrl = SIEMENS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO
            } else if ([FULL_CONTROL, PROTOCOL_MANAGEMENT].includes(connectionType)) {
                demoVideoUrl = SIEMENS_MR_EDITCONSOLE_DEMO_ENV_VIDEO
            }
        } else if (roomName.includes(GE)) {
            if ([VIEW, INCOGNITO_VIEW].includes(connectionType)) {
                demoVideoUrl = GE_MR_VIEWCONSOLE_DEMO_ENV_VIDEO
            } else if ([FULL_CONTROL, PROTOCOL_MANAGEMENT].includes(connectionType)) {
                demoVideoUrl = GE_MR_EDITCONSOLE_DEMO_ENV_VIDEO
            }
        } else {
            if ([VIEW, INCOGNITO_VIEW].includes(connectionType)) {
                demoVideoUrl = PHILIPS_MR_VIEWCONSOLE_DEMO_ENV_VIDEO
            } else if ([FULL_CONTROL, PROTOCOL_MANAGEMENT].includes(connectionType)) {
                demoVideoUrl = PHILIPS_MR_EDITCONSOLE_DEMO_ENV_VIDEO
            }
        }
    }
    return demoVideoUrl
}

export const isAnyOfEmeraldEnabled = (permissions: any) => {
    return (!!permissions.CONSOLE_EDIT || !!permissions.CONSOLE_VIEW)
}

export const hideNotificationModal = (dispatch: Dispatch<any>) => {
    const notificationModal = { showModal: false }
    dispatch({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}
export const getLoggedSessionTime = () => {
    const state = store.getState().appReducer.loadTimes
    const loginClickTime: Date = new Date(state.loginClick)
    const currentTime = new Date()
    return getDurationInFormat(currentTime, loginClickTime)
}
export const getApplicationDefaultConfig = async (dispatch: Dispatch<any>) => {
    const defaultConfig = await fetchDefaultConfiguration()
    const locales = defaultConfig.locale.split(",")
    const defaultLocale: IConfigsDataType = {
        language: locales[0].substring(0, 2),
        locales,
        preferredLocale: locales[0],
        theme: "Default"
    }
    sessionStorage.setItem("language", defaultLocale.language)
    sessionStorage.setItem("locale", defaultLocale.preferredLocale)
    dispatch(updateLocale(defaultLocale))
    return defaultLocale
}

export const getCurrentUserData = () => {
    const state = store.getState()
    const currentUser = state.userReducer.currentUser
    const { id, uuid, clinicalRole, onBoarded, allRoles, accessToken, kvmUsername } = currentUser
    return { id, uuid, clinicalRole, onBoarded, allRoles, accessToken, kvmUsername }
}

export const getAppReducerData = () => {
    const state = store.getState()
    const appReducer = state.appReducer
    const { nfccUpgradeAvailable, fseData } = appReducer
    return { nfccUpgradeAvailable, fseData }
}

export const getCustomerReducerData = () => {
    const state = store.getState()
    const { orgId } = state.customerReducer.metaData
    return { orgId }
}

export const getConFigs = () => {
    const state = store.getState()
    return state.configReducer.configs
}

export const getUrls = () => {
    const state = store.getState()
    return state.configReducer.urls
}

export const getPreSignedUrls = () => {
    const state = store.getState()
    return state.configReducer.preSignedUrls
}

export const getFeatureFlags = () => {
    const state = store.getState()
    return state.featureFlagsReducer.featureFlags
}
export const sendActiveConsoleEndLog = () => {
    const gstate = globalStore.GetGlobalState()
    const consoleSessions = gstate[CONSOLE_APP_STORE].consoleReducer.consoleSessions
    consoleSessions.forEach((session: IConsoleSession) => {
        const { connectionType, connectionMode, roomUuid, requester, consoleStartTime } = session

        const { component, event: { endedConsole } } = TRACK.CONSOLE_INFO
        trackEvent(
            component,
            getEvent(
                endedConsole,
                transformSessionTypeForAnalytics(connectionType)
            ),
            {
                source: transformSessionTypeForAnalytics(connectionMode), Call_To: roomUuid, Call_From: requester,
                Event_By: requester, ...(consoleStartTime && { duration: getDurationInFormat(new Date(), new Date(consoleStartTime)) })
            }
        )
    })
}

export const isFlagEnabled = (featureFlags: any, flag: string) => {
    return !!featureFlags[flag]
}

export const trackEvent = (component: string, event: string, moreInfo: Object = {}) => sendLogsToAzure({ contextData: { component: component, event: event, ...moreInfo } })

export const getEvent = (event: string, subString: string = ""): string => event.replace("__REPLACE__", subString)

export const cctvClose = () => {
    cctvWindow?.close()
    if (cctvWindow) {
        const { component, event: { close } } = TRACK.LIVE_VIDEO
        trackEvent(component, close)
    }
}

export const openLiveWindow = (link: any) => {
    const url = window.location.hostname === LOCALHOST ? `/#${link}` : `${CC_PATH}#${link}`
    cctvWindow = window.open(url, "Live videos", CCTV_WINDOW_FEATURES)
    const { component, event: { open } } = TRACK.LIVE_VIDEO
    trackEvent(component, open)
    if (cctvWindow) {
        cctvWindow.addEventListener("resize", function () {
            if (cctvWindow !== null) {
                cctvWindow.resizeTo(1920, 1080)
            }
        })
    }
    if (cctvWindow !== null) {
        cctvWindow.focus()
    }
}

export const isLogoutInProgress = () => {
    const state: IParentStore = store.getState()
    const { workflows } = state.workflowReducer
    return !!workflows.find(workflow => workflow.type === ERoccWorkflow.LOGOUT)
}

export const constructAppUriForBundleUpgrade = (bundleName: string, bundleVersion: string, downloadUrl: string) => {
    const apiEndpoint = `${getUrls().MANAGEMENT_SERVICE_URL}${MANAGE_GRAPHQL_BUNDLE_INFOS_EP}/${getCurrentUserData().id}`
    const config = {
        [APP_NAME]: UPDATER_NAME,
        [APP_URI_ARGS]: {
            [ACCESS_TOKEN]: getCurrentUserData().accessToken, [API_ENDPOINT]: apiEndpoint, [API_METHOD]: "PUT", [API_VERSION_STRING]: DEFAULT_API_VERSION,
            [ORG_ID]: getCustomerReducerData().orgId, [BUNDLE_NAME]: bundleName, [BUNDLE_VERSION]: bundleVersion, [DOWNLOAD_URL]: downloadUrl
        }
    }
    return `${NATIVE_APP_URI}${NATIVE_APP_URI_START}?config=${JSON.stringify(config)}`
}

export const fetchCallContextForRoomUuid = (roomUuid: string) => {
    const callDetails = globalStore.GetGlobalState()[CALLING_APP_STORE]?.callReducer?.callDetails

    if (!callDetails) {
        return
    }
    const { connectedCallDetails, onHoldCallDetails } = callDetails
    return [...onHoldCallDetails, connectedCallDetails].find((callDetails: IAVCallDetails) => callDetails.participants.some((participant: IParticipantInfo) => participant.uuid === roomUuid))
}
