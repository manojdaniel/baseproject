// import react from 'react';
// import { Spin } from 'antd';
// import { LoadingOutlined } from '@ant-design/icons';

// const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;

// // Return value should be component
// const Loader = () => <Spin indicator={antIcon} />

// export default Loader;

import React from "react";
import { Spin } from "antd";

const App: React.FC = () => <Spin />;

export default App;
