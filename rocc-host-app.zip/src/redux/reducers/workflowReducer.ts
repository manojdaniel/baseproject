/*
 * Created on Mon Apr 18 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {
    ADD_WORKFLOW_EVENT, generateUuid, IWorkflow, IWorkflowReducer, REGISTER_WORKFLOW, WorkflowContext, WorkflowEvent, WorkflowTypestate, generateWorkflow
} from "@rocc/rocc-client-services"
import { errorLogger } from "@rocc/rocc-logging-module"
import isEqual from "lodash.isequal"
import pick from "lodash.pick"
import { AnyAction, Reducer } from "redux"
import { createMachine, State } from "xstate"
import { addOrUpdatePresignedWorkflow, updatePresignedWorkflowStatus } from "../../utility/pre-signed-workflow-utility/presignedUtility"
import { ADD_PRESIGNED_WORKFLOW, REMOVE_WORKFLOW_EVENT, SET_WORKFLOWS, SET_WORKFLOW_STATE, UPDATE_PRESIGNED_WORKFLOW, UPDATE_PRESIGNED_WORKFLOW_STATUS, UPDATE_WORKFLOW_SERVICE } from "../actions/types"

const findWorkflowAndUpdateKey = <K extends keyof IWorkflow>(id: string, key: K, newValue: IWorkflow[K], state: IWorkflowReducer,) => {
    const workflowIdx = state.workflows.findIndex((workflow: IWorkflow) => workflow.id === id)
    state.workflows[workflowIdx][key] = newValue
    return { ...state }
}

export const initialStatesForWorkflowReducer: IWorkflowReducer = {
    workflows: [],
    presignedWorkflows: []
}

export const workflowReducer: Reducer<IWorkflowReducer> =
    (state: IWorkflowReducer = initialStatesForWorkflowReducer, action: AnyAction) => {
        const { workflows, presignedWorkflows } = state

        switch (action.type) {
            case REGISTER_WORKFLOW:
                {
                    // TODO: Test against unpredicted type, context and states inputs.
                    const { workflowConfig, workflowOptions } = action.payload.workflowConfig ? {
                        workflowConfig: action.payload.workflowConfig,
                        workflowOptions: action.payload.workflowOptions
                    } : generateWorkflow(
                        action.payload.type,
                        pick(action.payload, ["context", "states", "actions", "guards", "delays"])
                    )

                    const newMachine: IWorkflow["workflow"] = createMachine<WorkflowContext, WorkflowEvent, WorkflowTypestate>(workflowConfig).withConfig(workflowOptions)

                    const newWorkflow: IWorkflow = {
                        id: generateUuid(),
                        type: action.payload.type,
                        workflow: newMachine,
                        // TODO: Weird unknown cast required to bypass typegen. Check if it can be globally disabled
                        state: newMachine.initialState as unknown as State<WorkflowContext, WorkflowEvent, any, WorkflowTypestate>,
                        eventQueue: [],
                    }
                    return { ...state, workflows: [...workflows, newWorkflow] }
                }
            case SET_WORKFLOWS:
                {
                    return { ...state, workflows: action.payload.workflows }
                }
            case SET_WORKFLOW_STATE:
                {
                    const { id, workflowState } = action.payload
                    return findWorkflowAndUpdateKey(id, "state", workflowState, state)
                }
            case UPDATE_WORKFLOW_SERVICE:
                {
                    const { id, service } = action.payload
                    return findWorkflowAndUpdateKey(id, "service", service, state)
                }
            case ADD_WORKFLOW_EVENT:
                {
                    const { id, event }: { id: string, event: WorkflowEvent } = action.payload
                    const workflowIdx = state.workflows.findIndex((workflow: IWorkflow) => workflow.id === id)
                    if(workflowIdx < 0) {
                        errorLogger(`Failed to find requested workflow in redux for workflowId: ${id} and event: ${event} for action type ${action.type}`)
                        return { ...state }
                    }
                    state.workflows[workflowIdx].eventQueue.push(event)
                    return { ...state }
                }
            case REMOVE_WORKFLOW_EVENT:
                {
                    const { id, event }: { id: string, event: WorkflowEvent } = action.payload
                    const workflowIdx = state.workflows.findIndex((workflow: IWorkflow) => workflow.id === id)
                    if(workflowIdx < 0) {
                        errorLogger(`Failed to find requested workflow in redux for workflowId: ${id} and event: ${event} for action type ${action.type}`)
                        return { ...state }
                    }
                    state.workflows[workflowIdx].eventQueue = state.workflows[workflowIdx].eventQueue.filter((entry) => !isEqual(entry, event))
                    return { ...state }
                }
            // TODO: Implement batch event queueing
            // case ADD_WORKFLOW_EVENTS_BATCH:
            //     {
            //         return action.payload.events.reduce(
            //             (updatedState: IWorkflow, event: EventObject) => workflowMachineReducer(updatedState, event),
            //             state
            //         )
            //     }

            case ADD_PRESIGNED_WORKFLOW:
                return { ...state, presignedWorkflows: [...presignedWorkflows, action.payload.presignedWorkflow] }
            
            case UPDATE_PRESIGNED_WORKFLOW: {
                const updatedPresignedWorkflows = addOrUpdatePresignedWorkflow(presignedWorkflows, action.payload.presignedWorkflow)
                return { ...state, presignedWorkflows: updatedPresignedWorkflows }
            }
            
            case UPDATE_PRESIGNED_WORKFLOW_STATUS: {
                const { presignedId, presignedStatus } = action.payload
                const updatedPresignedWorkflows = updatePresignedWorkflowStatus(presignedWorkflows, presignedId, presignedStatus)
                return { ...state, presignedWorkflows: updatedPresignedWorkflows }
            }
            default:
        }

        return { ...state }
    }

export default workflowReducer
