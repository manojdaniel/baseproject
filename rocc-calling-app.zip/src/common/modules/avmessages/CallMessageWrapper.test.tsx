/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import CallMessageWrapper from "./CallMessageWrapper"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

const implement = jest.fn().mockReturnValue("initializeClient")
jest.mock("@rocc/rocc-chat-library", () => ({
    ChatHeader: () => <></>,
    RoccChatClient: jest.fn().mockImplementation(
        () => ({ initializeClient: implement, communicationOnEvent: jest.fn() })
    )
}))

jest.mock("react-redux", () => ({
    useSelector: jest.fn().mockReturnValue({
        currentUser: { accessToken: "accessToken" }
    }),
    useDispatch: jest.fn().mockReturnValue(jest.fn)
}))

jest.mock("../../../redux/actions/callActions", () => ({
    setConversationClientStatus: jest.fn(),
    setVideoCallStatus: jest.fn(),
    updateTokenStatus: jest.fn(),
}))

jest.mock("../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({ COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" })
}))

jest.mock("../../helpers/apiUtility", () => ({ refreshToken: jest.fn() }))

jest.mock("./messageService", () => ({
    fetchCommunicationClientDetails: jest.fn().mockReturnValue({
        status: "SUCCESS", tokenDetails: { communicationToken: "communicationToken" }
    })
}))

describe("CallMessageWrapper tests", () => {
    it("should render MessageHandler", () => {
        withHooks(()=> {
            const wrapper = shallow(<CallMessageWrapper />)
            expect(wrapper.find("MessageHandler")).toBeDefined()
        })
    })
})
