/*
 * Created on Thu Aug 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo, EResponse } from "@rocc/rocc-client-services"
import { IManagedAxios } from "@rocc/rocc-http-client"
import { ACCEPT, API_VERSION, APPLICATION_JSON, AUTHORIZATION, CALL_ACCEPT, CALL_REJECT, CHAT, CONTENT_TYPE, DEFAULT_API_VERSION, HTTP_STATUS, OUTGOING_CALL, RINGING, TABID } from "../../../constants/constants"
import { COMMUNICATION_TOKEN_EP, AV_CALL_EP, VENDOR_SERVICE_API_URI } from "../../../constants/endpoints"
import { getService, postService } from "../../helpers/apiUtility"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { ICreateUrlCallFunction, IRequester, IParticipant, ICallDetails } from "./av-messages/types"

export const fetchCommunicationClientDetails = async (url: string, token: string, userId: string) => {
    let tokenDetails = { communicationToken: "", channelSid: "" }
    let status = EResponse.ERROR
    try {
        const params: IManagedAxios = {
            url: `${url}${COMMUNICATION_TOKEN_EP}`,
            headers: {
                [ACCEPT]: APPLICATION_JSON,
                [CONTENT_TYPE]: APPLICATION_JSON,
                [AUTHORIZATION]: token,
                [API_VERSION]: DEFAULT_API_VERSION
            },
            data: {
                userId,
                tokenType: CHAT
            }
        }
        const response = await postService(params)
        if (HTTP_STATUS.OK === response.status) {
            tokenDetails = {
                communicationToken: response.data.twillioAccessToken,
                channelSid: response.data.channelSid,
            }
            status = EResponse.SUCCESS
            return { status, tokenDetails }
        }
    } catch (error) {
        errorLogger(`Twilio token failed with error: ${errorParser(error)}`)
    }
    return { status, tokenDetails }
}

const REQUEST_UUID = "?userId="

export const createUrlCall = (params: ICreateUrlCallFunction) => {
    const { callStatus, contextId, communicationServiceUrl, state, accessToken, userUuid, sessionId } = params
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        Authorization: accessToken,
    }
    const data = {
        callStatus,
        requester: {
            primaryUuid: userUuid,
            userContext: {
                sessionTabId: `${sessionId}_${sessionStorage.getItem(TABID)}`,
            },
        },
    }
    return {
        url: `${communicationServiceUrl}${contextId}`, headers, data, state,
    }
}

export const getContextDetails = async (contextId: string, currentUser: IUserInfo, communicationServiceUrl: string) => {
    /* TODO: catch appropriate exception */
    const url = `${communicationServiceUrl}${AV_CALL_EP}${contextId}${REQUEST_UUID}${currentUser.uuid}`
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        Authorization: currentUser.accessToken,
    }
    const params = {
        url,
        headers,
    }
    return await getService(params)
}

export const getUserVideoAcceptedTab = (data: any) => {
    if (data.requester || data.requester.userContext) {
        return data.requester.userContext
    }
    return null
}

export const getCallerID = (requester: IRequester, participants: IParticipant[]) => {
    return (requester.userContext && requester.userContext.callerId) ? getCallerActualUUID(requester.userContext.callerId, participants) : getRequesterActualUUID(requester)
}

export const getCallerActualUUID = (callerUuid: string, participants: IParticipant[]) => {
    const participant = participants.find((participant: IParticipant) => (participant.primaryUuid === callerUuid))
    if (participant) {
        return getParticipantActualUUID(participant)
    }
    return callerUuid
}

export const getParticipantActualUUID = (participant: IParticipant) => {
    if (participant) {
        return (participant.secondaryUUID && participant.secondaryUUID.length) ? participant.secondaryUUID[0] : participant.primaryUuid
    }
    return ""
}

export const getRequesterActualUUID = (requester: IRequester) => {
    if (requester) {
        return (requester.secondaryUuid && requester.secondaryUuid.length) ? requester.secondaryUuid[0] : requester.primaryUuid
    }
    return ""
}

export const checkCurrentCallRejected = (callDetails: ICallDetails) => {
    const { requester, participants } = callDetails
    const callInitiator = requester.userContext.callerId ? false : true
    if (requester.callStatus === CALL_REJECT) {
        return {
            isRejectedByMe: true,
            shouldCallDisconnect: true,
            callInitiator,
            callerId: getCallerID(requester, participants),
            rejectedParticipantID: getRequesterActualUUID(requester)
        }
    } else {
        for (const participant of participants) {
            if ([RINGING, OUTGOING_CALL, CALL_ACCEPT, CALL_REJECT].includes(participant.callStatus)) {
                return {
                    isRejectedByMe: false,
                    shouldCallDisconnect: participant.callStatus === CALL_REJECT,
                    callInitiator,
                    callerId: getCallerID(requester, participants),
                    rejectedParticipantID: getCallerActualUUID(participant.primaryUuid, participants)
                }
            }
        }
        return { isRejectedByMe: false, shouldCallDisconnect: true, callInitiator, callerId: getCallerID(requester, participants), rejectedParticipantID: { primaryUuid: "" } }
    }
}

export const getVendorServiceName = async (currentUser: IUserInfo, communicationServiceUrl: string) => {
    const url = `${communicationServiceUrl}${VENDOR_SERVICE_API_URI}`
    const headers = {
        [CONTENT_TYPE]: APPLICATION_JSON,
        Authorization: currentUser.accessToken,
    }
    const params = {
        url,
        headers,
    }
    return await getService(params)
}
