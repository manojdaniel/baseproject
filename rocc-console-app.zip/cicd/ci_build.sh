#!/bin/bash
set -e
set -x
export no_proxy=artifactory.pic.philips.com,artifactory-ehv.ta.philips.com
CICD_FOLDER=cicd
APP_NAME=rocc-console-app

echo "Building $APP_NAME"
build_type=$1
currentDir=$(pwd)

echo "Processing in directory : {$currentDir}"
echo "====================================="
echo "Building $APP_NAME"
echo "====================================="
npm install
npm run build
# if [ "$build_type" = "tag_build" ]; then
#     npm run build
# else
#     npm run build:dev
# fi
npm run test:coverage
echo "====================================="
echo "Copying required content to $CICD_FOLDER folder"
echo "====================================="

cp -r dist ./$CICD_FOLDER
