import React, { useRef, useEffect, useState } from "react";


const Pmt = () => {

  return (
    <div>

    </div>
  );
};
export default Pmt;
