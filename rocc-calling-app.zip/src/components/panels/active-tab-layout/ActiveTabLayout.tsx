/*
 * Created on Tue May 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ActiveCallList, IActiveCallList, IActiveCallSection } from "@rocc/rocc-calling-components"
import { DEFAULT_CONTACT_INFO, IAVCallDetails } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { checkIfMultiAudioEnabled, checkIfMultiEditWithoutParkResumeFeatureEnabled, fetchDisplayableContact } from "../../../common/helpers/helpers"
import { disconnectCall, setDeafenCall, setMuteCall } from "../../../redux/actions/callActions"
import { IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/translations/en-US"
import { registerCallDisconnectWorkflow } from "../../../services/callServices"
import { ESidePanelTabs } from "../../../types/types"

const componentName = "Active Tab Layout"

interface IActiveTabLayout {
    handleActiveTabClick: (tabName: ESidePanelTabs) => void
}

const component = "Active Tab Layout"

const ActiveTabLayout = ({ handleActiveTabClick }: IActiveTabLayout) => {

    const {
        onHoldCallDetails,
        featureFlags,
    } = useSelector((state: IStore) => ({
        onHoldCallDetails: state.callReducer.callDetails.onHoldCallDetails,
        featureFlags: state.externalReducer.featureFlags,
    }))

    const { intl } = getIntlProvider()
    const dispatch = useDispatch()

    const [activeTab, setActiveTab] = useState({} as IActiveCallList)
    const [multiAudioStatus, setMultiAudioStatus] = useState(true)
    const callEndEvent = (callDetails: IAVCallDetails) => {
        disconnectCallWrapper(callDetails.contextId)
        sendLogsToAzure({ contextData: { component, event: `${" Call ended with Participant with uuid"} ${callDetails.participants[0].uuid}` } })

    }
    const callMuteEvent = (callDetails: IAVCallDetails) => {
        dispatch(setMuteCall(callDetails, !callDetails.isMuted))
        const muted = !callDetails.isMuted ? "muted" : "unmuted"
        sendLogsToAzure({ contextData: { component, event: `${"Participant with uuid"} ${callDetails.participants[0].uuid} ${muted}` } })
    }

    const disconnectCallWrapper = (contextId: string) => {
        if (checkIfMultiEditWithoutParkResumeFeatureEnabled()) {
            registerCallDisconnectWorkflow({ contextId, componentName })
        } else {
            dispatch(disconnectCall(contextId))
        }
    }

    const callDeafenEvent = (callDetails: IAVCallDetails) => {
        dispatch(setDeafenCall(callDetails, !callDetails.isDeafened))
        const deafened = !callDetails.isDeafened ? "deafened" : "undeafended"
        sendLogsToAzure({ contextData: { component, event: `${"Participant with uuid"} ${callDetails.participants[0].uuid} ${deafened}` } })

    }

    useEffect(() => {
        const activeTabData: IActiveCallList = {
            title: intl.formatMessage({ id: "content.tabs.active", defaultMessage: en["content.tabs.active"] }),
            activeCallSections: [],
            showCounter: onHoldCallDetails.length > 0,
            defaultDropdownState: true,
            onDropdownClick: () => handleActiveTabClick(ESidePanelTabs.Active)
        }

        if (onHoldCallDetails.length) {
            const activeCallSection: IActiveCallSection = {
                title: intl.formatMessage({ id: "content.activeTab.ActiveCallSessions", defaultMessage: en["content.activeTab.ActiveCallSessions"] }),
                activeCalls: []
            }

            activeCallSection.activeCalls = onHoldCallDetails.map(callDetails => {
                const { participants, isMuted, isDeafened } = callDetails
                const contact = participants.length ? participants[0] : DEFAULT_CONTACT_INFO
                const contactDesc = fetchDisplayableContact(contact)
                return {
                    title: contactDesc.title,
                    metaData: contactDesc.metaData,
                    description: contactDesc.description,
                    modalityType: contact.modalities[0],
                    isMuted: isMuted,
                    isDeafen: isDeafened,
                    onCallEnd: () => callEndEvent(callDetails),
                    onMicrophoneClick: () => callMuteEvent(callDetails),
                    onDeafenClick: () => callDeafenEvent(callDetails),
                }
            })
            activeTabData.activeCallSections = [activeCallSection]
        }
        setActiveTab(activeTabData)
    }, [JSON.stringify(onHoldCallDetails)])

    useEffect(() => {
        setMultiAudioStatus(checkIfMultiAudioEnabled(featureFlags))
    }, [featureFlags])

    if (multiAudioStatus && activeTab?.activeCallSections?.length) {
        return (
            <ActiveCallList {...activeTab} />
        )
    }
    return <a className="activeTab">{intl.formatMessage({ id: "content.tabs.active", defaultMessage: en["content.tabs.active"] })}</a>
}

export default ActiveTabLayout
