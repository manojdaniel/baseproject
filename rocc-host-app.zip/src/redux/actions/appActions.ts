/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { EResponse, EAppContext, IParentStore, IConsoleSession, IParticipantInfo, IAVCallDetails } from "@rocc/rocc-client-services"
import { errorLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { CALLING_APP_STORE, CONSOLE_APP_STORE } from "../../constants/constants"
import { TRACK } from "../../constants/tracking"
import { ELoadTimes } from "../../types/types"
import { roccHttpClient } from "../../utility/api/apiUtility"
import { fetchCallContextForRoomUuid, trackEvent } from "../../utility/helpers/helpers"
import { getDurationInFormat } from "../../utility/math/mathUtility"
import { fetchVersionService, setFseModeService } from "../services/appServices"
import globalStore from "../store/globalStore"
import store from "../store/store"
import { setCustomerOrgId } from "./customerActions"
import {
    FETCH_VERSION,
    FORCE_APP_REFRESH, GLOBAL_RIGHTSIDE_PANEL, GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL, GLOBAL_SET_ACTIVE_TAB, LOAD_TIMES_HOME_PAGE_LOAD, LOAD_TIMES_LOGIN_CLICK, ROOM_MONITORING_WINDOW, SET_APP_CONTEXT, SET_FSE_MODE, SET_IDLE_PERMISSION_STATE
} from "./types"


export const fetchVersion = (appName: string) => async (dispatch: Dispatch) => {
    try {
        const data = await fetchVersionService(appName)
        dispatch({ type: FETCH_VERSION, version: data })
    } catch (error) {
        errorLogger(`Fetching Version failed with: ${error}`)
    }
}

export const setRightSidePanel = (displayRightSidePanel: boolean, activeRightPanel: string) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { displayRightSidePanel, activeRightPanel } })
}

export const setFseMode = (allOrgList: any[], isProxy: string = "false", dispatch: Dispatch) => {
    let fseData = { isFse: false, customerName: "", customerOrgId: "" }
    if (allOrgList.length) {
        fseData = setFseModeService(allOrgList, isProxy)
        if (fseData.customerName) {
            dispatch({ type: SET_FSE_MODE, fseData })
            setCustomerOrgId(fseData.customerOrgId, dispatch)
        }
    }
    return fseData
}

export const updateFseMode = (isFse: boolean) => (dispatch: Dispatch, getState: any) => {
    const state: IParentStore = getState()
    const fseData = state.appReducer.fseData
    dispatch({ type: SET_FSE_MODE, fseData: { ...fseData, isFse } })
}

export const appRefresh = () => async () => {
    await roccHttpClient.refreshToken()
}

export const setIdlePermissionState = (idlePermissionState: string) => (dispatch: Dispatch) => {
    dispatch({ type: SET_IDLE_PERMISSION_STATE, idlePermissionState })
}

export const setAppRefreshState = (appRefreshState: EResponse, dispatch: Dispatch) => {
    dispatch({ type: FORCE_APP_REFRESH, appRefreshState })
}

export const setActiveTab = (index: number) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: index } })
}

export const setRoomMonitoringWindow = (roomMonitoringWindow: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: ROOM_MONITORING_WINDOW, roomMonitoringWindow })
}

export const captureLoadTimes = (eventType: ELoadTimes) => (dispatch: Dispatch, getState: any) => {
    const state: IParentStore = getState()
    const mLoadTimes = state.appReducer.loadTimes
    let totalTimeToLoad = 0
    if (eventType === ELoadTimes.HOME_PAGE_LOADED && mLoadTimes.homePageLoaded === mLoadTimes.initDate) {
        const loginClick = new Date(mLoadTimes.loginClick)
        if (loginClick !== mLoadTimes.initDate && (loginClick) instanceof Date) {
            const currentTime = new Date()
            totalTimeToLoad = getDurationInFormat(currentTime, loginClick)
        }
        const { component, event: { homePageLoad } } = TRACK.LOGIN
        trackEvent(component, homePageLoad, { duration: totalTimeToLoad })
        const loadTimes = { ...mLoadTimes, homePageLoaded: new Date(), totalTime: totalTimeToLoad }
        dispatch({ type: LOAD_TIMES_HOME_PAGE_LOAD, loadTimes })
    } else {
        captureLoadTimesAction(eventType, dispatch)
    }
}

export const captureLoadTimesAction = (eventType: ELoadTimes, dispatch: Dispatch) => {
    const { LOGIN_CLICK } = ELoadTimes
    switch (eventType) {
        case LOGIN_CLICK:
            dispatch({ type: LOAD_TIMES_LOGIN_CLICK })
            break
        default:
    }
}

export const updateAppContext = (appContext: EAppContext) => (dispatch: Dispatch) => {
    dispatch({ type: SET_APP_CONTEXT, appContext })
}

export const updateFocusedConsoleSession = (consoleContextId: string) => (dispatch: Dispatch) => {
    const gState = globalStore.GetGlobalState()
    const consoleSessions = gState[CONSOLE_APP_STORE]?.consoleReducer?.consoleSessions
    if (!consoleSessions || !consoleSessions.length) {
        return
    }
    const consoleSession: IConsoleSession = consoleSessions.find((consoleSession: IConsoleSession) => consoleSession.contextId === consoleContextId)

    const callContextId = fetchCallContextForRoomUuid(consoleSession?.roomUuid ?? "")?.contextId

    dispatch({ type: GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL, consoleContextId, callContextId: callContextId ?? "" })
}

export const updateFocusedCallAndConsole = () => (dispatch: Dispatch) => {
    const { focusedCallAndConsole } = store.getState().appReducer
    const gState = globalStore.GetGlobalState()
    const connectedCallDetails = gState[CALLING_APP_STORE]?.callReducer?.callDetails?.connectedCallDetails
    const consoleSessions = gState[CONSOLE_APP_STORE]?.consoleReducer?.consoleSessions

    /* Skipping if global redux is not initialized*/
    if (!consoleSessions || !connectedCallDetails) {
        return
    }
    const consoleSession = consoleSessions.find((consoleSession: IConsoleSession) => connectedCallDetails.participants.some((participant: IParticipantInfo) => participant.uuid === consoleSession.roomUuid))

    /* Guarding againts repeated updates*/
    if (consoleSession?.contextId === focusedCallAndConsole?.consoleContextId && connectedCallDetails?.contextId === focusedCallAndConsole?.callContextId) {
        return
    }
    dispatch({ type: GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL, consoleContextId: consoleSession?.contextId ?? "", callContextId: connectedCallDetails?.contextId ?? "" })

}

export const resetFocusedConsoleSession = () => (dispatch: Dispatch) => {
    const gState = globalStore.GetGlobalState()
    const consoleSessions = gState[CONSOLE_APP_STORE].consoleReducer.consoleSessions

    if (!consoleSessions) {
        return
    }
    const { connectedCallDetails, onHoldCallDetails } = gState[CALLING_APP_STORE]?.callReducer?.callDetails
    const callWithoutSession = [connectedCallDetails, ...onHoldCallDetails].find((callDetails: IAVCallDetails) =>
        !callDetails.participants.some((participant: IParticipantInfo) => consoleSessions.map((consoleSession: IConsoleSession) =>
            consoleSession.roomUuid).includes(participant.uuid)))

    dispatch({ type: GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL, consoleContextId: "", callContextId: callWithoutSession?.contextId ?? "" })
}
