"""
 Created on Mon Apr 25 2022
 Copyright (c) 2022 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import unittest
from unittest.mock import patch
from unittest.mock import Mock
from src.exceptions.RoccException import RoccException
from src.constants.constants import ROCC_MODALITY_TYPES,ROCC_SCANNER_RESOURCES,ROCC_TABLETS,ROCC_ORGANIZATIONS
from src.constants.headers import EXCEL_ROOM_SCANNER_DICOM_AE_TITLE, EXCEL_ROOM_SCANNER_MANUFACTURER, EXCEL_ROOM_SCANNER_MODEL, EXCEL_ROOM_SCANNER_NOTES, EXCEL_ROOM_SCANNER_OS, EXCEL_ROOM_SCANNER_OS_VERSION, EXCEL_ROOM_SCANNER_SERIAL_NUMBER, EXCEL_ROOM_SCANNER_SOFTWARE_VERSION, EXCEL_ROOM_VIEW_CONNECTION, EXCEL_ROOM_EDIT_CONNECTION, EXCEL_ROOM_MODALITY, EXCEL_ROOM_IDENTIFIER, EXCEL_ROOM_QUALIFY_NCC_EDIT

from src.modules.db_operations.insertion_services.room_db_services import check_if_device_present, check_if_communication_mappings_are_created_for_room, check_if_kvm_connections_present, update_rooms_eligibility, extend_with_additional_attributes, insert_modalities, \
    extend_with_scanner_details, check_and_insert_transmitter, handle_existing_rooms, check_if_data_present_in_a_given_table,insert_room_data_in_db,handle_insertion_of_devices_for_existing_rooms,handle_insertion_of_kvm_connections_for_existing_rooms,check_if_scanner_exists, \
    get_org_db_id_by_uuid


class RoomDbServices(unittest.TestCase):
    @patch("src.modules.db_operations.insertion_services.room_db_services.check_if_data_present_in_a_given_table")
    def test_check_if_device_present_present_in_db(self, mock_fn):
        mock_fn.return_value = "device_id"
        device_id, number_of_devices_required, room = check_if_device_present(
            client={}, number_of_devices_required=1, room={"eligibility": {}}, room_id=1)
        self.assertEqual(device_id, "device_id")
        self.assertEqual(number_of_devices_required, 1)
        self.assertEqual(room["eligibility"]["new_device"], False)

    @patch("src.modules.db_operations.insertion_services.room_db_services.check_if_data_present_in_a_given_table")
    def test_check_if_device_present_not_present_in_db(self, mock_fn):
        mock_fn.return_value = False
        device_id, number_of_devices_required, room = check_if_device_present(
            client={}, number_of_devices_required=1, room={"eligibility": {}}, room_id=1)
        self.assertEqual(device_id, False)
        self.assertEqual(number_of_devices_required, 2)
        self.assertEqual(room["eligibility"]["new_device"], True)

    def test_check_if_communication_mappings_are_created_for_room_not_present(self):
        room = {"instance_id": "",
                "communication_profile": "", "rbac_mapping": ""}
        response1, response2 = check_if_communication_mappings_are_created_for_room(
            room)
        expected = ["Instance identity mapping is not created.",
                    "Communication profile mapping is not created.", "Rbac role mapping is not created."]
        self.assertEqual(response1, False)
        self.assertEqual(response2, expected)

    def test_check_if_communication_mappings_are_created_for_room_present(self):
        room = {"instance_id": "abc",
                "communication_profile": "efg", "rbac_mapping": "ijk"}
        response1, response2 = check_if_communication_mappings_are_created_for_room(
            room)
        expected = []
        self.assertEqual(response1, True)
        self.assertEqual(response2, expected)

    def test_extend_with_scanner_details(self):
        room = {"eligibility": {"new_view": "new_view", "new_edit": "new_edit"}}
        room[EXCEL_ROOM_SCANNER_MANUFACTURER] = "manufacturer"
        room[EXCEL_ROOM_SCANNER_MODEL] = "scanner"
        room[EXCEL_ROOM_SCANNER_SERIAL_NUMBER] = "slno"
        room[EXCEL_ROOM_SCANNER_DICOM_AE_TITLE] = "dicom"
        room[EXCEL_ROOM_SCANNER_SOFTWARE_VERSION] = "v1"
        room[EXCEL_ROOM_SCANNER_OS] = "os"
        room[EXCEL_ROOM_SCANNER_OS_VERSION] = "10"
        room[EXCEL_ROOM_SCANNER_NOTES] = "notes"
        room[EXCEL_ROOM_VIEW_CONNECTION] = "1.1.1.1"
        room[EXCEL_ROOM_EDIT_CONNECTION] = "2.2.2.2"
        mock_client = Mock()
        edit_connection_id, view_connection_id, room_returned = check_if_kvm_connections_present(
            client=mock_client, room=room, room_id=1)
        self.assertEqual(edit_connection_id, False)
        self.assertEqual(view_connection_id, False)
        self.assertEqual(room_returned, room)

    @patch("src.modules.db_operations.insertion_services.room_db_services.check_if_data_present_in_a_given_table")
    @patch("src.modules.db_operations.insertion_services.room_db_services.insert_modalities")
    def test_update_rooms_eligibility(self, mock_fn, mock_fn_fir):
        mock_fn.return_value = False
        mock_fn_fir.return_value = False
        room_param = {"eligibility": {
            "new_view": "new_view", "new_edit": "new_edit",
            EXCEL_ROOM_MODALITY: "abc",
            "eligibility": {"new_room": "xxx"},
            EXCEL_ROOM_IDENTIFIER: "ppp", "new_room": "abc", "resource_id": 12}}
        rooms, number_of_devices_required = update_rooms_eligibility(
            client={}, rooms=room_param, org_db_id=1)
        self.assertEqual(number_of_devices_required, 1)
        self.assertIsNotNone(rooms)

    def test_extend_with_additional_attributes(self):
        room = {EXCEL_ROOM_QUALIFY_NCC_EDIT: "YES"}
        room_dict1 = extend_with_additional_attributes({}, room)
        room_dict2 = extend_with_additional_attributes({}, {})
        self.assertIsNotNone(room_dict1)
        self.assertIsNotNone(room_dict2)

    def test_insert_modalities(self):
        modality_insertion_status = insert_modalities({}, {})
        self.assertIsNotNone(modality_insertion_status)

    def test_extend_with_scanner_details_fail(self):
        modality_insertion_status = extend_with_scanner_details({}, {})
        self.assertIsNotNone(modality_insertion_status)

    def test_extend_with_scanner_details_pass(self):
        room = {EXCEL_ROOM_SCANNER_MANUFACTURER: "manufacturer", EXCEL_ROOM_SCANNER_MODEL: "scanner", EXCEL_ROOM_SCANNER_SERIAL_NUMBER: "serial"}
        room[EXCEL_ROOM_SCANNER_DICOM_AE_TITLE] = "dicom"
        room[EXCEL_ROOM_SCANNER_SOFTWARE_VERSION] = "1.0.0"
        room[EXCEL_ROOM_SCANNER_OS] = "scanner os"
        room[EXCEL_ROOM_SCANNER_OS_VERSION] = "os version"
        room[EXCEL_ROOM_SCANNER_NOTES] = "notes"
        modality_insertion_status = extend_with_scanner_details(base_details_dict={"abc": "efg"}, room=room)
        self.assertIsNotNone(modality_insertion_status)

    def test_check_and_insert_transmitter(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "rocc_rocc_transmitters": [{"id": "1"}]
        }
        tx_id = check_and_insert_transmitter(client=mock_client, room_name="abc",
                                             transmitter_ip="1.1.1.1", transmitter_name="abc transmitter",
                                             kvm_config_id="1", user_uuid="1234")
        self.assertIsNotNone(tx_id)
        self.assertRaises(Exception, check_and_insert_transmitter, {}, "abc", "1.1.1.1", "abc transmitter", "1", "1234")

    def test_insert_modalities_pass(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "insert_rocc_modality_types": {"returning": [{"id": "1"}]}
        }
        modality_insertion_status = insert_modalities(client=mock_client, modality="abc")
        self.assertIsNotNone(modality_insertion_status)

    def test_handle_existing_rooms(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "insert_rocc_modality_types": {"returning": [{"id": "1"}]}
        }
        rooms = [{"eligibility": {"new_device": "new dev", "new_view": "new"}}]
        existing_rooms = [{"eligibility": {"new_device": "new dev","device_id":"device id", "new_view": "new", EXCEL_ROOM_IDENTIFIER: "room_id","resource_id":"resource id"}}]
        received_room = handle_existing_rooms(client=mock_client,
                                              rooms=rooms, existing_rooms=existing_rooms, user_uuid="123")
        self.assertIsNotNone(received_room)

    def test_handle_existing_rooms_with_zero(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "insert_rocc_modality_types": {"returning": [{"id": "1"}]}
        }
        received_room = handle_existing_rooms(client=mock_client,
                                              rooms=[], existing_rooms=[], user_uuid="123")
        self.assertIsNotNone(received_room)

    def test_check_if_data_present_in_a_given_table(self):
        mock_client = Mock()
        mock_client.execute.return_value = {ROCC_MODALITY_TYPES: [{"id": "1"}]}
        self.assertIsNotNone(check_if_data_present_in_a_given_table(client=mock_client,table_name=ROCC_MODALITY_TYPES))
        mock_client.execute.return_value = {ROCC_SCANNER_RESOURCES: [{"id": "1"}]}
        self.assertIsNotNone(check_if_data_present_in_a_given_table(client=mock_client,table_name=ROCC_SCANNER_RESOURCES))
        mock_client.execute.return_value = {ROCC_TABLETS: [{"id": "1"}]}
        self.assertIsNotNone(check_if_data_present_in_a_given_table(client=mock_client,table_name=ROCC_TABLETS))
        mock_client.execute.return_value = False
        self.assertFalse(check_if_data_present_in_a_given_table(client=mock_client,table_name=""))

    @patch("src.modules.db_operations.insertion_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_insert_room_data_in_db(self,mock_fn1):
        mock_client = Mock()
        mock_fn1.return_value = True, "message"
        mock_client.execute.return_value = {
            "insert_rocc_modality_types": {"returning": [{"id": "1"}]}
        }
        rooms = [{"eligibility": {"new_device": "new dev", "new_view": "new"}}]
        response = insert_room_data_in_db(client=mock_client,rooms=rooms, user_uuid="", kvm_config_id="", transaction_data={}, scanner_data_support="", org_db_id="", additional_attributes_support="")
        self.assertEqual(response,False)

    @patch("src.modules.db_operations.insertion_services.room_db_services.extract_response_from_mutation_response")
    def test_handle_insertion_of_devices_for_existing_rooms_exception(self,mock_fn):
        mock_client = Mock()
        mock_fn.return_value = "results"
        mock_client.execute.return_value = {
            "insert_rocc_modality_types": {"returning": [{"id": "1"}]}
        }
        rooms = [{"eligibility": {"new_device": "new dev", "new_view": "new"}}]
        response = handle_insertion_of_devices_for_existing_rooms(client=mock_client,rooms=rooms, device_rooms=rooms)
        self.assertIsNotNone(response)

    def test_handle_insertion_of_devices_for_existing_rooms_sucess(self):
        response = handle_insertion_of_devices_for_existing_rooms(client="",rooms=[], device_rooms=[])
        self.assertIsNotNone(response)

    def test_handle_insertion_of_kvm_connections_for_existing_rooms_exception(self):
        mock_client = Mock()
        mock_client.execute.return_value = {
            "insert_rocc_rocc_transmitter_mappings": {"returning": [{"scanner_resource_id":"id","transmitter_connection_type":"view"}]}
        }
        room_param = {"eligibility": {
            "new_view": "new_view", "new_edit": "new_edit",
            EXCEL_ROOM_MODALITY: "abc",
            "eligibility": {"new_room": "xxx"},
            EXCEL_ROOM_IDENTIFIER: "id", "new_room": "abc", "resource_id": 12}}
        response = handle_insertion_of_kvm_connections_for_existing_rooms(client=mock_client,rooms=room_param, kvm_conn_rooms=room_param)
        self.assertIsNotNone(response)

    def test_handle_insertion_of_kvm_connections_for_existing_rooms_sucess(self):
        response = handle_insertion_of_kvm_connections_for_existing_rooms(client="",rooms=[], kvm_conn_rooms=[])
        self.assertIsNotNone(response)

    def test_check_if_scanner_exists_success(self):
        mock_client=Mock()
        mock_client.execute.return_value = {ROCC_SCANNER_RESOURCES:[{"id":"1"}]}
        self.assertRaises(RoccException, check_if_scanner_exists, client=mock_client,identifier="1", site_id="1")
        mock_client.execute.return_value = {ROCC_SCANNER_RESOURCES:[]}
        self.assertIsNone(check_if_scanner_exists(client=mock_client,identifier="1", site_id="1"))

    def test_get_org_db_id_by_uuid_success(self):
        mock_client=Mock()
        mock_client.execute.return_value = {ROCC_ORGANIZATIONS:[{"id":"1"}]}
        response = get_org_db_id_by_uuid(client=mock_client, org_infra_uuid="1")
        self.assertEqual(response,"1")

    def test_get_org_db_id_by_uuid_exception(self):
        mock_client=Mock()
        mock_client.execute.return_value = {ROCC_ORGANIZATIONS:[{"id":False}]}
        self.assertRaises(RoccException, get_org_db_id_by_uuid, client=mock_client, org_infra_uuid="1")
