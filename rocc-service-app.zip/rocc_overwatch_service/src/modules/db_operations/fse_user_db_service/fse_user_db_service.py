"""
 Created on Mon Nov 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import ROCC_APPLICATION_ROLES, ROCC_USERS
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import (
    extract_data_from_table, extract_id_from_mutation_response)
from src.wrappers.graphql.mutations.mutations import insert_fse_user
from src.wrappers.graphql.queries.queries import (
    fetch_fse_roles_and_ids, fetch_user_details_with_email, fetch_all_customers)

LOG = create_logger("FseUserSetup")


def get_roles_identifiers_for_fse_roles(client):
    try:
        LOG.info("Fetching clinical roles id for all roles like FSE%")
        response = client.execute(fetch_fse_roles_and_ids)
        return extract_data_from_table(data=response, table_name=ROCC_APPLICATION_ROLES)
    except Exception as ex:
        LOG.exception(f"Fetching clinical role id for FSE roles failed with error: {ex}")
    return False


def check_if_user_exists(client, email_id):
    try:
        # TODO: Needs to be captured in Audit. LOG.info(f"Checking if user with emailId, {email_id} already exists")
        response = client.execute(fetch_user_details_with_email, variable_values={"email_id": email_id})
        return extract_data_from_table(response, ROCC_USERS)
    except Exception as ex:
        LOG.exception(f"Exception occurred while checking if user exists with error: {ex}")
    return False


def insert_fse_user_into_db(client, new_user_details, current_user_uuid):
    try:
        application_role_mappings = []
        for role_id in new_user_details["role_ids"]:
            application_role_mappings.append({
                "application_role_id": role_id,
                "created_by": current_user_uuid,
                "modified_by": current_user_uuid
            })
        query_variables = {
            "objects": [{
                "user_hsdp_uuid": new_user_details["id"],
                "first_name": new_user_details["name"]["given"],
                "last_name": new_user_details["name"]["family"],
                "display_name": new_user_details["name"]["given"] + " " + new_user_details["name"]["family"],
                "user_email_id": new_user_details["emailAddress"],
                "user_primary_phone":"",
                "web_onboarding": False,
                "device_onboarding": False,
                "unique_identity": new_user_details["emailAddress"],
                "status": "Active",
                "locale": new_user_details["preferredLanguage"],
                "applicationRoleMappingsByUserId": {"data": application_role_mappings},
                "created_by": current_user_uuid,
                "modified_by": current_user_uuid,
            }]
        }
        response = client.execute(insert_fse_user, variable_values=query_variables)
        return extract_id_from_mutation_response(response, "insert_rocc_users")
    except Exception as ex:
        LOG.exception(f"Exception occurred while inserting user with error: {ex}")
    return False


def get_all_customers(client):
    try:
        response = client.execute(fetch_all_customers)
        return response
    except Exception as ex:
        LOG.exception(f"Exception occurred while fetching all customer data with error: {ex}")
    return False
