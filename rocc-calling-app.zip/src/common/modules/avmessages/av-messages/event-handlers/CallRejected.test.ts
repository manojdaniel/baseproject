/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HTTP_STATUS } from "../../../../../constants/constants"
import { ECallStatus } from "@rocc/rocc-client-services"
import { callRejected } from "./CallRejected"
import * as messageService from "../../messageService"

jest.mock("../../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("../../../../../redux/actions/callActions", () => {
    const actualFn = jest.requireActual("../../../../../redux/actions/callActions")
    return {
        ...actualFn,
        setVideoCallStatus: jest.fn(),
        updateCallTimeout: jest.fn(),
        setCallRingStatus: jest.fn(),
        setCallMessage: jest.fn(),
    }
})

jest.mock("../../../../helpers/helpers", () => {
    const actualFn = jest.requireActual("../../../../helpers/helpers")
    return {
        ...actualFn,
        getUserReducerFromGlobalStore: jest.fn().mockReturnValue({
            contacts: [],
        }),
        getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
            rooms: [],
        })
    }
})

jest.mock("../../../../../redux/store/externalAppStates", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/externalAppStates")
    return {
        ...actualFn,
        fetchGlobalURLs: () => ({
            COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl"
        })
    }
})

jest.mock("../../../../../redux/store/store", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/store")
    return {
        ...actualFn,
        getState: jest.fn().mockImplementation(() => ({
            callReducer: {
                videoCallStatus: [{ callStatus: ECallStatus.RINGING, contextId: "contextId" }],
                callDetails: {
                    connectedCallDetails: {
                        contextId: "contextId",
                        callAcceptedTime: Date.now(),
                    },
                }
            },
            externalReducer: {
                currentUser: {
                    uuid: "uuid"
                },
            }

        }))
    }
})

jest.mock("@rocc/rocc-global-components", () => {
    const actualFn = jest.requireActual("@rocc/rocc-global-components")
    return {
        ...actualFn,
        getIntlProvider: jest.fn(() => { return { intl: { formatMessage: jest.fn() } } })
    }
})

const dispatch = jest.fn()

jest.spyOn(messageService, "getContextDetails").mockReturnValue(Promise.resolve({
    status: HTTP_STATUS.OK,
    statusText: "OK",
    headers: {},
    config: {},
    data: {
        requester: {
            primaryUuid: "primaryUuid",
            callStatus: "INCOMING_CALL",
            userContext: {
                twilioToken: "twilioToken",
                callerId: "callerId",
            }
        },
        participants: [{
            primaryUuid: "primaryUuid",
            callStatus: "INCOMING_CALL",
        }],
    }
}))

describe("callRejected tests", () => {
    it("should able to update callRejected message", () => {
        jest.spyOn(messageService, "checkCurrentCallRejected").mockReturnValue({
            isRejectedByMe: true, shouldCallDisconnect: true,
            callInitiator: true, callerId: "callerId", rejectedParticipantID: "rejectedParticipantId"
        })
        callRejected({ contextId: "contextId", dispatch })
        expect(dispatch).toBeDefined()
    })

    it("should able to update callRejected message when callInitiator is false", () => {
        jest.spyOn(messageService, "checkCurrentCallRejected").mockReturnValue({
            isRejectedByMe: true, shouldCallDisconnect: true,
            callInitiator: false, callerId: "callerId", rejectedParticipantID: "rejectedParticipantId"
        })
        callRejected({ contextId: "contextId", dispatch })
        expect(dispatch).toBeDefined()
    })

    it("should able to update callRejected message when call is not rejected by me", () => {
        jest.spyOn(messageService, "checkCurrentCallRejected").mockReturnValue({
            isRejectedByMe: false, shouldCallDisconnect: true,
            callInitiator: false, callerId: "callerId", rejectedParticipantID: "rejectedParticipantId"
        })
        callRejected({ contextId: "contextId", dispatch })
        expect(dispatch).toBeDefined()
    })

    it("should able to update callRejected message when call is not rejected by me but user is initiator", () => {
        jest.spyOn(messageService, "checkCurrentCallRejected").mockReturnValue({
            isRejectedByMe: false, shouldCallDisconnect: true,
            callInitiator: true, callerId: "callerId", rejectedParticipantID: "rejectedParticipantId"
        })
        callRejected({ contextId: "contextId", dispatch })
        expect(dispatch).toBeDefined()
    })
})
