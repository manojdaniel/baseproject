import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

interface Props {
    handleDateChange: any;
    selectedDate?: any;
}

const AlertMangementDatePicker = ({ selectedDate, handleDateChange }: Props) => {
    return (
        <DatePicker
            minDate={new Date()}
            maxDate={new Date(new Date().setFullYear(new Date().getFullYear() + 2))}
            dateFormat={"dd/M/yyyy"}
            selected={selectedDate}
            onChange={handleDateChange}
            inline
        />
    );
};

export default AlertMangementDatePicker;