/*
 * Created on Fri Sept 03 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getDurationInFormat } from "./dateTimeUtility"

describe("Date time utility tests", () => {
    const greaterDate = new Date(1)
    const lesserDate = new Date(2)

    it("should return seconds", () => {
        expect(getDurationInFormat(greaterDate, lesserDate, "seconds")).toBe(0)
    })

    it("should return hours", () => {
        expect(getDurationInFormat(greaterDate, lesserDate, "hours")).toBe(0)
    })

    it("should return milliseconds", () => {
        expect(getDurationInFormat(greaterDate, lesserDate, "miliseconds")).toBe(-1)
    })

    it("should return minutes", () => {
        expect(getDurationInFormat(greaterDate, lesserDate, "minutes")).toBe(0)
    })
    it("should throw error", () => {
        expect(getDurationInFormat("date" as any, lesserDate)).toBe(0)

    })

})
