#!/bin/bash
echo "Reading config...."
. graphql.cfg #note the space between the dot and the leading slash of /etc.cfg

status_code=$(curl --write-out %{http_code} \
 --request POST \
 --header "Content-Type:application/json" \
 --header "X-Hasura-Role:$graphql_role" \
 --header "X-Hasura-Access-Key:$graphql_secret_key" \
 -d @track_overwatch_tables.json \
 --url $graphql_api \
 -so "track_overwatch_tables.log" \
 --noproxy "*")

if [[ "$status_code" == 200 ]] ; then
  echo "Successfully imported all tables in overwatch schema to GraphQL-Engine"
else
  echo "Error while importing tables in overwatch schema into GraphQL-Engine"
  echo "Please refer to log file track_overwatch_tables.log!"
fi

status_code=$(curl --write-out %{http_code} \
 --request POST \
 --header "Content-Type:application/json" \
 --header "X-Hasura-Role:$graphql_role" \
 --header "X-Hasura-Access-Key:$graphql_secret_key" \
 -d @track_overwatch_relations.json \
 --url $graphql_api \
 -so "track_overwatch_relations.log" \
 --noproxy "*")

if [[ "$status_code" == 200 ]] ; then
  echo "Successfully imported all relations in overwatch schema to GraphQL-Engine"
else
  echo "Error while importing all relations in overwatch schema into GraphQL-Engine"
   echo "Please refer to log file track_overwatch_relations.log!"
fi

status_code=$(curl --write-out %{http_code} \
 --request POST \
 --header "Content-Type:application/json" \
 --header "X-Hasura-Role:$graphql_role" \
 --header "X-Hasura-Access-Key:$graphql_secret_key" \
 -d @track_overwatch_permissions.json \
 --url $graphql_api \
 -so "track_overwatch_permissions.log" \
 --noproxy "*")

if [[ "$status_code" == 200 ]] ; then
  echo "Successfully assigned permissions in overwatch schema to GraphQL-Engine"
else
  echo "Error while assigning permissions in overwatch schema into GraphQL-Engine"
   echo "Please refer to log file track_overwatch_permissions.log!"
fi
