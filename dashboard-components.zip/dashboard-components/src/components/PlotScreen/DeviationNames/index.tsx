import React from "react";

const DeviationNames = () => {
	return (
		<div id="sensor-plot-right" className="noBack">
			<div id="measure-names">
				<div className="measure-filter">
					<div className="right-title">MEASURE</div>
					{/* <a href="#" className="sensor-calendar">
                        <span>Date:</span> <span className="calen-date">{measureFromDateFormat} {measureToDateFormat}</span> <span className="calen-icon">
                            <img src={iconCalendar} title="calendar" onClick={() => setShowPicker(!showPicker)} /></span></a> */}
				</div>
				<div className="sensor-plot-list">
					<div>
						<span style={{ background: "#009FDF" }}></span>
						<span>Distance</span>
					</div>
					<div>
						<span style={{ background: "#FFCD00" }}></span>
						<span>Warning Level</span>
					</div>
					<div>
						<span style={{ background: "#e35205" }}></span>
						<span>Alert Level</span>
					</div>
				</div>
			</div>
			<div id="bar-chart-names">
				<div className="sensor-plot-list">
					<span>
						<span style={{ background: "#e35205" }}></span>
						<span>Anomaly Alert</span>
					</span>
					<span>
						<span style={{ background: "#ffcd00" }}></span>
						<span>Warning</span>
					</span>
					<span>
						<span style={{ background: "#3BB44A" }}></span>
						<span>Normal</span>
					</span>
					<span>
						<span style={{ background: "#929292" }}></span>
						<span>Poor data / State Change / Pi data disconnection</span>
					</span>
					<span>
						<span style={{ background: "#4e79a7" }}></span>
						<span>Asset off</span>
					</span>
				</div>
			</div>
		</div>
	);
};

export default DeviationNames;
