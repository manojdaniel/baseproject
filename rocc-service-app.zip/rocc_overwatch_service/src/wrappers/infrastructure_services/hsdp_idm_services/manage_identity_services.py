"""
 Created on Wed Oct 28 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import uuid
import requests

from src.loggers.log import create_logger
from src.constants.constants import CF_DOMAIN, CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, API_VERSION, ACCEPT

LOG = create_logger("ManageHSDPIdentitityServices")


def create_proposition_service(idm_url, token, org_id, name, description):
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1"}
    proposition_id = 0
    error_reasn = ""
    data = {"name": name,
            "description": description,
            "organizationId": org_id,
            "globalReferenceId": str(uuid.uuid4())}
    try:
        response = requests.post(f"{idm_url}/authorize/identity/Proposition",
                                 data=json.dumps(data),
                                 headers=iam_headers)

        if response.status_code == 201:
            proposition_id = response.headers["Location"].split("/")[-1]
            LOG.info(
                f"Proposition identity created Successfully, proposition_id: {proposition_id}")

        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Proposition identity is already present, hence not creating: {response.json()}")
            error_reasn = f"Proposition identity is already present, hence not creating: {response.json()}"
        else:
            LOG.error(
                f"Error While creating Proposition {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While creating Proposition1 - {ex.args}")
        error_reasn = f"Error While creating Proposition {repr(ex.args)}"
    return proposition_id, error_reasn


def create_application_service(idm_url, token, proposition_id, name, description):
    application_id = 0
    error_resn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": name,
            "description": description,
            "propositionId": proposition_id,
            "globalReferenceId": str(uuid.uuid4())}
    try:
        response = requests.post(f"{idm_url}/authorize/identity/Application",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            application_id = response.headers["Location"].split("/")[-1]
            LOG.info(
                f"Application identity created successfully, application_id: {application_id} ")
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Application identity is already present, hence not creating: {json.dumps(response.json())}")
            error_resn = f"Application identity is already present, hence not creating: {json.dumps(response.json())}"
        else:
            LOG.error(
                f"Error While creating Application {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While creating Application - {ex}")
        error_resn = f"Error While creating Application -{repr(ex.args)}"
    return application_id, error_resn


def create_service_identity(idm_url, token, application_id, name, description):
    create_service_identity_response = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"name": name,
            "description": description,
            "applicationId": application_id}
    try:
        response = requests.post(f"{idm_url}/authorize/identity/Service",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info(
                f"Service identity created successfully, response: {response.json()}")
            create_service_identity_response = response.json()
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"Service identity is already present, hence not creating: {json.dumps(response.json())}")
            error_reasn = f"Service identity is already present, hence not creating: {json.dumps(response.json())}"
        else:
            LOG.error(
                f"Error while creating Service identity: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error While creating service identity - {ex}")
        error_reasn = f"Error While creating service identity - {repr(ex.args)}"
    return create_service_identity_response, error_reasn


def create_oauth_client_service(idm_url, token, application_id, name, description, client_id, password, org_name):
    oauth_client_id = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"clientId": client_id,
            "password": password,
            "type": "Confidential",
            "name": name,
            "description": description,
            "responseTypes": ["code", "id_token"],
            "applicationId": application_id,
            "globalReferenceId": str(uuid.uuid4()),
            "redirectionURIs": [
                f"https://{org_name}-rocc.{os.environ[CF_DOMAIN]}" + "/cc/"
            ],
            "consentImplied": "true"}
    try:
        response = requests.post(f"{idm_url}/authorize/identity/Client/",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            oauth_client_id = response.headers["Location"].split("/")[-1]
            LOG.info(
                f"OAuthClient Created Successfully, oauth_client_id: {oauth_client_id}")
        elif response.status_code == 409:
            """ TODO: Check response """
            LOG.warning(
                f"OAuthClient is already present, hence not creating: {json.dumps(response.json())}")
            error_reasn = f"OAuthClient is already present, hence not creating: {json.dumps(response.json())}"
        else:
            LOG.error(
                f"Error while creating OAuthClient: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating OAuthClient: {ex}")
        error_reasn = f"Error while creating OAuthClient: {repr(ex.args)}"
    return oauth_client_id, error_reasn


def update_client_scope_service(idm_url, token, oauth_client_id):
    is_updated = False
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"defaultScopes": ["cn", "sn", "mail", "auth_iam_policy_evaluation", "auth_iam_introspect",
                              "auth_iam_organization", "auth_iam_create_refresh", "auth_iam_oidc"],
            "scopes": ["cn", "sn", "mail", "auth_iam_policy_evaluation", "auth_iam_introspect", "auth_iam_organization",
                       "auth_iam_create_refresh", "auth_iam_oidc"]}
    try:
        response = requests.put(f"{idm_url}/authorize/identity/Client/{oauth_client_id}/$scopes",
                                data=json.dumps(data),
                                headers=iam_headers)
        if response.status_code == 204:
            LOG.info("Client Scope updated Successfully ")
            is_updated = True
        else:
            LOG.error(
                f"Error while updating clientScope: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while updating clientScope: {ex}")
        error_reasn = f"Error while updating clientScope: {repr(ex.args)}"
    return is_updated, error_reasn


def fetch_user_details(idm_url, token, email_id):
    try:
        iam_headers = {AUTHORIZATION: f"Bearer {token}",
                       API_VERSION: "2", ACCEPT: APPLICATION_JSON}
        response = requests.get(f"{idm_url}/authorize/identity/User?profileType=membership&userId={email_id}",
                                headers=iam_headers)
        if response.status_code == 200:
            LOG.info("Retrived user details Successfully")
            user_uuid = response.json()["entry"][0]["id"]
            return user_uuid
        else:
            LOG.error(
                f"Failed to retrive user's information with error: {response.json()}")
    except Exception as ex:
        LOG.exception(f"Failed to retrive user's information with error: {ex}")
    return False


def fetch_user_details_from_hsdp(idm_url, token, email_id):
    try:
        iam_headers = {AUTHORIZATION: f"Bearer {token}",
                       API_VERSION: "2", ACCEPT: APPLICATION_JSON}
        response = requests.get(f"{idm_url}/authorize/identity/User?profileType=membership&userId={email_id}",
                                headers=iam_headers)
        if response.status_code == 200:
            LOG.info("Retrived user details Successfully")
            return response.json()["entry"] if len(response.json()["entry"]) == 1 else []
        else:
            LOG.error(
                f"Failed to retrive user's information with error: {response.json()}")
    except Exception as ex:
        LOG.exception(f"Failed to retrive user's information with error: {ex}")
    return False
