"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from gql import gql

""" Overwatch schema mutations """
insert_rocc_overwatch_customers_raw_data = gql("""
mutation insert_rocc_overwatch_raw_upload_data($objects: [rocc_overwatch_raw_upload_data_insert_input!]!){
    insert_rocc_overwatch_raw_upload_data(objects:$objects){
      returning{
        id
        customer_id
      }
    }
}
""")

update_rocc_overwatch_customers_raw_data = gql("""
mutation update_raw_data($upload_record_id: uuid!, $data: json!) {
  update_rocc_overwatch_raw_upload_data(where: {id: {_eq: $upload_record_id}}, _set: {data: $data}) {
    affected_rows
    returning {
      id
    }
  }
}
""")

cleanup_raw_data_with_record_id = gql("""
mutation cleanup_file_record($record_id: uuid!) {
  delete_rocc_overwatch_raw_upload_data(where: {id: {_eq: $record_id}}) {
    affected_rows
    returning {
      id
    }
  }
}
""")

insert_rocc_overwatch_customers = gql("""
mutation insert_rocc_overwatch_customers($objects: [rocc_overwatch_customers_insert_input!]!) {
  insert_rocc_overwatch_customers(objects: $objects) {
    returning {
      name
      id
    }
  }
}
""")

insert_rocc_overwatch_service_jobs = gql("""
mutation insert_rocc_overwatch_service_jobs($objects: [rocc_overwatch_service_jobs_insert_input!]!){
    job: insert_rocc_overwatch_service_jobs(objects:$objects){
      returning{
        id
        job_name
      }
    }
}
""")

insert_rocc_overwatch_service_tasks = gql("""
mutation insert_rocc_overwatch_service_tasks($objects: [rocc_overwatch_service_tasks_insert_input!]!){
    task: insert_rocc_overwatch_service_tasks(objects:$objects){
      returning{
        id
        task_name
      }
    }
}
""")

insert_rocc_overwatch_service_job_transactions = gql("""
mutation insert_rocc_overwatch_service_job_transactions($objects: [rocc_overwatch_service_job_transactions_insert_input!]!){
    transactions: insert_rocc_overwatch_service_job_transactions(objects:$objects){
      returning{
        id
      }
    }
}
""")

update_status_service_job_transactions_to_init = gql("""
mutation update_rocc_overwatch_service_job_transactions($transaction_id: uuid!, $status: String!) {
  update_rocc_overwatch_service_job_transactions(where: {id: {_eq: $transaction_id}}, _set: {status: $status}){
    affected_rows
    returning{
        id
        entity_id
        entity_type
        current_task_id
        operation_type
        status
        current_job_id
      }
    }
  }
""")


update_job_and_task_for_transaction = gql("""
mutation update_service_job_transaction($transaction_id: uuid!, $job_id: Int!, $task_id: Int!, $transaction_data: json!) {
  update_rocc_overwatch_service_job_transactions(where: {id: {_eq: $transaction_id}}, _set: {current_job_id: $job_id, current_task_id: $task_id, transaction_data: $transaction_data}) {
    affected_rows
    returning {
      id
      transaction_data
    }
  }
}

""")

update_transaction_details = gql("""
mutation update_service_jobs($transaction_id: uuid!, $job_id:Int!, $task_id: Int!) {
  update_rocc_overwatch_service_job_transactions(where: {id: {_eq: $transaction_id}}, _set: {current_job_id: $job_id, current_task_id: $task_id}){
    affected_rows
    returning {
        id
        current_job_id
        current_task_id
        entity_id
        entity_type
        operation_type
        status
        transaction_data
        upload_record_id
    }
  }
}
""")

upsert_customers = gql("""
mutation upsert_customer($name: String!, $status: String!) {
  insert_rocc_overwatch_customers(objects: {name: $name, status: $status},
    on_conflict: {constraint: customers_name_key, update_columns: [status]}) {
    affected_rows
    returning {
      id
      name
      status
    }
  }
}
""")

upsert_customer_configurations = gql("""
mutation upsert_customer_configurations($object: rocc_overwatch_infrastructure_configurations_insert_input!) {
  insert_rocc_overwatch_infrastructure_configurations(objects: [$object], 
    on_conflict: {constraint: infrastructure_configurations_customer_id_key, update_columns: [profile, infra_configs, proxy_url]}) {
    affected_rows
    returning {
      id
    }
  }
}
""")

upsert_customers_in_bulk = gql("""
mutation upsert_customers($objects: [rocc_overwatch_customers_insert_input!]!){
  insert_rocc_overwatch_customers(objects:$objects , on_conflict:{
    constraint: customers_name_key,
    update_columns: [],
  }){
    affected_rows
    returning{
      id
      name
      status
    }
  }
}
""")


cleanup_rocc_overwatch_customer_data = gql("""
mutation delete_customer_data($customer_id: Int!) {
  delete_rocc_overwatch_raw_upload_data(where: {customer_id: {_eq: $customer_id}}){
    returning {
      id
    }
  }
  delete_rocc_overwatch_infrastructure_configurations(where: {customer_id: {_eq: $customer_id}}) {
    returning {
      id
    }
  }
  delete_rocc_overwatch_customers(where: {id: {_eq: $customer_id}}) {
    returning{
      id
    }
  }
}
""")

update_customer_status_from_raw_upload_record_id = gql("""
mutation update_customer_through_raw_upload_id($record_id: uuid!, $status: String!) {
  update_rocc_overwatch_customers(where: {rawUploadDataByCustomerId: {id: {_eq: $record_id}}},
  _set: {status: $status}) {
    returning {
      id
    }
  }
}
""")

################################################

""" Common ROCC mutations """

insert_new_customer_data = gql("""
mutation insert_new_customer_data($objects: [rocc_organizations_insert_input!]!) {
    insert_rocc_organizations(objects: $objects) {
        returning {
            id
            sites{
                id
                organization_id
                identifier
            }
            rocc_kvm_configurations{
              id
            }
        }
    }
}

""")
insert_new_sites_data = gql("""
mutation insert_rocc_sites($objects: [rocc_sites_insert_input!]!) {
  insert_rocc_sites(objects: $objects) {
    returning {
      id
      identifier
    }
  }
}
""")
insert_rocc_site_contacts = gql("""
mutation insert_org_site_contacts($objects: [rocc_rocc_site_contacts_insert_input!]!) {
    insert_rocc_rocc_site_contacts(objects: $objects) {
        returning {
            id
           
        }
    }
}
""")

insert_fse_user = gql("""
mutation insert_fse_user($objects : [rocc_users_insert_input!]!) {
  insert_rocc_users(objects: $objects){
    returning{
      id
    }
  }
}""")

upsert_eula_docs = gql("""
mutation upsert_eula_docs($objects: [rocc_rocc_organization_documents_insert_input!]!) {
  insert_rocc_rocc_organization_documents(objects: $objects, on_conflict: {constraint: rocc_organization_documents_organization_document_locale, update_columns: [data_blob, modified_by]}) {
    returning {
      id
    }
  }
}
""")

upsert_kvm_configs = gql("""
mutation upsert_kvm_configs($objects: [rocc_rocc_kvm_configurations_insert_input!]!) {
  insert_rocc_rocc_kvm_configurations(objects: $objects, on_conflict: {constraint: rocc_kvm_configurations_organization_id_key, update_columns: [boxilla_ip, boxilla_machine_name, modified_by, boxilla_user_name, rest_user_name]}) {
    returning {
      id
    }
  }
}
""")

insert_transmitter = gql("""
mutation insert_transmitter($objects: [rocc_rocc_transmitters_insert_input!]!) {
  insert_rocc_rocc_transmitters(objects: $objects) {
    returning {
      id
    }
  }
}
""")

insert_roles = gql("""
mutation insert_roles($role: String!, $user_uuid: String!){
  insert_rocc_rocc_application_roles(objects: {role: $role, created_by: $user_uuid, modified_by: $user_uuid}){
    affected_rows
    returning{
      id
    }
  }
}
""")

insert_contact_type_id = gql("""
mutation insert_contact_type_id($contact_type: String!,$user_uuid:String!){
  insert_rocc_rocc_contact_types(objects:{contact_type:$contact_type,created_by:$user_uuid,modified_by:$user_uuid}){
    returning{
      id
    }
  }
  }
""")


insert_single_modality = gql("""
mutation insert_single_modality($modality: String!) {
  insert_rocc_modality_types(objects: {modality: $modality}) {
    affected_rows
    returning {
      id
    }
  }
}
""")

insert_new_scanner_resources = gql("""
mutation insert_new_scanners($objects: [rocc_scanner_resources_insert_input!]!) {
    insert_rocc_scanner_resources(objects: $objects) {
    returning {
      id
      identifier
    }
  }
}
""")

insert_seats_receivers = gql("""
mutation insert_seats_receivers($objects: [rocc_rocc_command_centre_seats_insert_input!]!) {
  insert_rocc_rocc_command_centre_seats(objects: $objects) {
    returning {
      id
      seat_info
      seat_name
      registered_count
      organization {
        id
        name
      }
      rocc_command_centre_receiver_mappings {
        id
        receiver_id
        command_centre_seat_id
        rocc_receiver {
          id
          receiver_ip
          receiver_connection_name
          monitor_name
        }
      }
    }
  }
}
""")

insert_receivers_for_existing_cc = gql("""
mutation insert_receivers_and_mappings($objects: [rocc_rocc_receivers_insert_input!]!) {
    insert_rocc_rocc_receivers(objects: $objects) {
    returning {
      id
      receiver_connection_name
      receiver_ip
      rocc_command_centre_receiver_mappings {
        id
        receiver_id
        command_centre_seat_id
      }
    }
  }
}
""")

update_command_center_details = gql("""
mutation update_cc($cc_id: Int!, $cc_details: rocc_rocc_command_centre_seats_set_input!, $del_receivers: [Int!]!, $updated_receivers: [rocc_rocc_receivers_insert_input!]!, $new_receiver_mappings: [rocc_rocc_command_centre_receiver_mappings_insert_input!]!) {
  update_rocc_rocc_command_centre_seats(_set: $cc_details, where: {id: {_eq: $cc_id}}) {
    returning {
      organization {
        id
        name
      }
    }
  }
  insert_rocc_rocc_receivers(objects: $updated_receivers, on_conflict: {constraint: rocc_receivers_pkey, update_columns: [receiver_ip, monitor_name, receiver_connection_name, modified_at, modified_by]}) {
    returning {
      rocc_command_centre_receiver_mappings {
        id
        receiver_id
        command_centre_seat_id
        rocc_receiver {
          id
          receiver_ip
          receiver_connection_name
          monitor_name
        }
      }
    }
  }
  delete_rocc_rocc_command_centre_receiver_mappings(where: {_and: [{command_centre_seat_id: {_eq: $cc_id}}, {receiver_id: {_in: $del_receivers}}]}) {
    affected_rows
  }
  delete_rocc_rocc_receivers(where: {id: {_in: $del_receivers}}) {
    affected_rows
  }
  insert_rocc_rocc_command_centre_receiver_mappings(objects: $new_receiver_mappings) {
    returning {
      id
      receiver_id
      command_centre_seat_id
      rocc_receiver {
        id
        receiver_ip
        receiver_connection_name
        monitor_name
      }
    }
  }
}
""")

soft_update_command_center_details = gql("""
mutation soft_update_cc($cc_id: Int!, $cc_details: rocc_rocc_command_centre_seats_set_input!, $del_receivers: [Int!]!, $updated_receivers: [rocc_rocc_receivers_insert_input!]!, $new_receiver_mappings: [rocc_rocc_command_centre_receiver_mappings_insert_input!]!) {
  update_rocc_rocc_command_centre_seats(_set: $cc_details, where: {id: {_eq: $cc_id}}) {
    returning {
      organization {
        id
        name
      }
    }
  }
  insert_rocc_rocc_receivers(objects: $updated_receivers, on_conflict: {constraint: rocc_receivers_pkey, update_columns: [receiver_ip, monitor_name, receiver_connection_name, modified_at, modified_by]}) {
    returning {
      rocc_command_centre_receiver_mappings {
        id
        receiver_id
        command_centre_seat_id
        rocc_receiver {
          id
          receiver_ip
          receiver_connection_name
          monitor_name
        }
      }
    }
  }
  delete_rocc_rocc_command_centre_receiver_mappings(where: {_and: [{command_centre_seat_id: {_eq: $cc_id}}, {receiver_id: {_in: $del_receivers}}]}) {
    affected_rows
  }
  insert_rocc_rocc_command_centre_receiver_mappings(objects: $new_receiver_mappings) {
    returning {
      id
      receiver_id
      command_centre_seat_id
      rocc_receiver {
        id
        receiver_ip
        receiver_connection_name
        monitor_name
      }
    }
  }
}
""")

delete_command_center = gql("""
mutation delete_cc($cc_id: Int!,$receiver_ids: [Int!]!) {
  delete_rocc_rocc_command_centre_receiver_mappings(where: {command_centre_seat_id: {_eq: $cc_id}}) {
    affected_rows
  }
  delete_rocc_rocc_receivers(where: {id: {_in: $receiver_ids}}) {
    affected_rows
  }
  delete_rocc_rocc_command_centre_seats(where: {id: {_eq: $cc_id}}) {
    affected_rows
  }
}
""")

soft_delete_command_center = gql("""
mutation soft_delete_cc($cc_id: Int!) {
  delete_rocc_rocc_command_centre_receiver_mappings(where: {command_centre_seat_id: {_eq: $cc_id}}) {
    affected_rows
  }
  delete_rocc_rocc_command_centre_seats(where: {id: {_eq: $cc_id}}) {
    affected_rows
  }
}
""")

update_receiver = gql("""
mutation update_receiver($id: Int!, $objects: rocc_rocc_receivers_set_input!) {
  update_rocc_rocc_receivers(where: {id: {_eq: $id}} _set: $objects) {
    returning {
      id
    }
  }
}
""")

insert_devices_for_existing_rooms = gql("""
mutation insert_devices_for_existing_rooms($device_objects: [rocc_rocc_tablets_insert_input!]!) {
  insert_rocc_rocc_tablets(objects: $device_objects) {
    returning {
      id
      device_name
    }
  }
}
""")

insert_tx_mappings_for_existing_rooms = gql("""
mutation insert_tx_mappings_for_existing_rooms($objects: [rocc_rocc_transmitter_mappings_insert_input!]!) {
  insert_rocc_rocc_transmitter_mappings(objects: $objects) {
    returning {
      id
      scanner_resource_id
    }
  }
}
""")

update_rocc_kvm_employee_user = gql("""
mutation update_rocc_kvm_user_details($user_db_id: Int!, $kvm_user_name: String!) {
  update_rocc_users(where: {id: {_eq: $user_db_id}}, _set: {kvm_user_name: $kvm_user_name}) {
    affected_rows
    returning {
      id
    }
  }
}
""")


update_scanner_transmitter_mappings = gql("""
mutation update_scanner_details($display_name: String!, $modality_id: Int!, $primary_phone: String!, $location: String!, $secondary_phone: String, $manufacturer: String, $model: String, $serial_number: String, $dicom_ae_title: String, $software_version: String, $os_type: String, $os_version: String, $notes: String, $additional_attributes:jsonb, $modified_by: String!, $resource_id: Int!, $transmitter_mapping_objects: [rocc_rocc_transmitter_mappings_insert_input!]!, $modality_connection: jsonb) {
  update_rocc_scanner_resources(where: {id: {_eq: $resource_id}}, _set: {name: $display_name, modality_id: $modality_id, primary_phone: $primary_phone, location: $location, secondary_phone: $secondary_phone, manufacturer: $manufacturer, serial_number: $serial_number, model: $model, dicom_ae_title: $dicom_ae_title, scanner_software_version: $software_version, scanner_os_type: $os_type, scanner_os_version: $os_version, notes: $notes, additional_attributes: $additional_attributes, modified_by: $modified_by, modality_connection: $modality_connection}) {
    affected_rows
    returning {
      id
    }
  }
  delete_rocc_rocc_transmitter_mappings(where: {scanner_resource_id: {_eq: $resource_id}}) {
    returning {
      id
    }
  }
  delete_rocc_rocc_transmitters(where: {rocc_transmitter_mappings: {scanner_resource_id: {_eq: $resource_id}}}) {
    returning {
      id
    }
  }
  insert_rocc_rocc_transmitter_mappings(objects: $transmitter_mapping_objects) {
    returning {
      id
    }
  }
}
""")

insert_scanner_tablet_transmitters = gql("""
mutation insertData($scanner_objects: [rocc_scanner_resources_insert_input!]!){
  insert_rocc_scanner_resources(objects: $scanner_objects) {
    returning {
      id
      rocc_tablets{
        id
      }
      rocc_transmitter_mappings {
        id
      }
    }
  }
}
""")

update_user_org_mappings = gql("""
mutation update_user_org_mappings($delete_org_ids: [Int!], $org_mappings: [rocc_rocc_user_organization_mappings_insert_input!]!, $user_id: Int!) {
  delete_rocc_rocc_user_organization_mappings(where: {_and: [{organization_id: { _in: $delete_org_ids}}, {user_id: {_eq: $user_id}}]}) {
    affected_rows
  }
  
  insert_rocc_rocc_user_organization_mappings(objects: $org_mappings) {
    returning{
      id
    }
  }
}
""")

assign_fse_to_customer = gql("""
mutation assign_fse_to_customer($fse_user_uuid: String!, $org_db_id: Int!, $user_db_id: Int!) {
  insert_rocc_rocc_user_organization_mappings(objects: {created_by: $fse_user_uuid, modified_by: $fse_user_uuid, organization_id: $org_db_id, user_id: $user_db_id}) {
    affected_rows
    returning {
      id
    }
  }
}
""")

update_onboarding_fse_user_status = gql("""
mutation update_article($email: String) {
  update_rocc_users(
    where: {_and: [{user_email_id: {_eq: $email}},{status:{_eq:"Invited"}}]},
    _set: {
      status: "Active"
    }
  ) {
    affected_rows
    returning {
      id
      first_name
      last_name
      user_email_id
      status
    }
  }
}
""")


#####################################################################
