import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import AlertStatusDepartment from "./AlertStatusDepartment";

//Mock data for the chart component
const data = [
	{ state: "Overdue", countofAlerts: 35 },
	{ state: "Closed", countofAlerts: 56 },
	{ state: "Under Investigation", countofAlerts: 42 },
];

//Test Case to check chart exist in the component.
describe("AlertStatusByAsset", () => {
	it("renders the chart with data", () => {
		const { container } = render(<AlertStatusDepartment data={data} />);
		expect(container.querySelector("#chartdiv2")).toBeInTheDocument();
	});
});
