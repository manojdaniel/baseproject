// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

interface Props {
	plotData: any;
	assetName: string;
}

const DeviationChart = ({ plotData, assetName }: Props) => {
	useLayoutEffect(() => {
		if (plotData.length > 0) {
			let Topdata = [];
			plotData.forEach((device, index) => {
				Topdata[index] = { ...device };
			});

			const root = am5.Root.new("chartdiv");

			root.setThemes([am5themes_Animated.new(root)]);
			var container = root.container.children.push(
				am5.Container.new(root, {
					width: am5.percent(100),
					height: am5.percent(140),
					layout: root.verticalLayout,
				})
			);

			let chart1 = container.children.push(
				am5xy.XYChart.new(root, {
					width: am5.percent(95),
					height: am5.percent(100),
					panX: false,
					panY: false,
					wheelY: "zoomX",
					layout: root.verticalLayout,
					pinchZoomX: true,
				})
			);
			chart1.get("colors").set("colors", [
				am5.color(0xe35205), //red
				am5.color(0xffcd00), //yellow

				am5.color(0x009fdf), //sky blue
				am5.color(0x2eb541), //green
				am5.color(0x4e79a7), //Light sky blue
				am5.color(0x929292), //Gray
			]);
			//Zoom in zoom out

			chart1.set(
				"scrollbarX",

				am5.Scrollbar.new(root, {
					orientation: "horizontal",
				})
			); //zoom
			var XAxis1 = chart1.xAxes.push(
				am5xy.DateAxis.new(root, {
					groupData: true,
					width: am5.percent(80),
					height: am5.percent(120),
					marginTop: 45,
					maxDeviation: 0.5,
					startLocation: 1,
					endLocation: 3,
					baseInterval: { timeUnit: "minute", count: 10 },
					markUnitChange: true,
					renderer: am5xy.AxisRendererX.new(root, {
						minGridDistance: 50,
						pan: "zoom",
					}),
				})
			);
			XAxis1.get("renderer").labels.template.setAll({
				fontSize: "0.9rem"
			});
			let YAxis1 = chart1.yAxes.push(
				am5xy.ValueAxis.new(root, {
					renderer: am5xy.AxisRendererY.new(root, {}),
				})
			);
			YAxis1.get("renderer").labels.template.set("forceHidden", false);
			XAxis1.get("renderer").labels.template.set("forceHidden", false);
			let yRenderer = YAxis1.get("renderer");
			yRenderer.labels.template.setAll({
				fontSize: "0.9rem"
			});
			function createSeries(name, field) {
				let Series1 = chart1.series.push(
					am5xy.LineSeries.new(root, {
						name,
						height: am5.percent(100),
						width: am5.percent(95),
						marginRight: 40,
						paddingRight: 20,
						xAxis: XAxis1,
						yAxis: YAxis1,
						valueYField: field,
						valueXField: "localTime",
						tooltip: am5.Tooltip.new(root, {
							pointerOrientation: "horizontal",
							labelText:
								"{name} {valueY} {valueX.formatDate('yyyy-MM-dd')} {time}",
						}),
					})
				);
				Series1.strokes.template.set("templateField", "strokeSettings");
				Series1.strokes.template.setAll({ strokeWidth: 2 });

				Series1.data.processor = am5.DataProcessor.new(root, {
					dateFormat: "yyyy-MM-dd HH:mm:ss",
					dateFields: ["localTime"],
				});

				// Series1.bullets.push(function (root) {
				// 	return am5.Bullet.new(root, {
				// 		sprite: am5.Circle.new(root, {
				// 			radius: 4,
				// 			fill: Series1.get("fill")
				// 		})
				// 	});
				// });

				Series1.data.setAll(Topdata);

				chart1.set(
					"cursor",
					am5xy.XYCursor.new(root, {
						behavior: "zoomXY",
						xAxis: XAxis1,
					})
				);
			}

			createSeries("Alert", "alertThreshold");
			createSeries("Warning", "warningThreshold");
			createSeries("Distance", "distance");

			let Chart2 = container.children.push(
				am5xy.XYChart.new(root, {
					width: am5.percent(93),
					marginBottom: 70,
					marginTop: -100,
				})
			);
			var xRenderer = am5xy.AxisRendererX.new(root, {
				minGridDistance: 50,
			});

			xRenderer.labels.template.setAll({
				centerY: am5.p100,
				centerX: am5.p100,
			});
			xRenderer.grid.template.setAll({
				location: 11.5,
				strokeDasharray: [1, 5],
			});

			Chart2.get("colors").set("colors", [
				am5.color(0xe35205), //red
				am5.color(0xffcd00), //yellow
				am5.color(0x2eb541), //green
			]);

			chart1.zoomOutButton.get("background").setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart1.zoomOutButton.get("background").states.create("hover", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart1.zoomOutButton.get("background").states.create("down", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			let data = [];

			for (var i = 0; i < Topdata.length; i++) {
				if (
					Topdata[i].status === "AssetOff" ||
					Topdata[i].status === "Asset-Off"
				) {
					let localdata = {
						category: "",
						from: new Date(Topdata[i].localTime).getTime(),
						to:
							Topdata[i + 1] == undefined
								? new Date(Topdata[i].localTime).getTime()
								: new Date(Topdata[i + 1].localTime).getTime(),
						columnSettings: {
							fill: am5.color(0x4e79a7), //Light sky blue
						},
					};
					data.push(localdata);
				} else if (
					Topdata[i].status === "Pi disconnection" ||
					Topdata[i].status === "Poor data" ||
					Topdata[i].status === "Pi Data Disconnection" ||
					Topdata[i].status === "State Change" ||
					Topdata[i].status === "Poor Data" ||
					Topdata[i].status === "Pi-Disconnected"
				) {
					let localdata = {
						category: "",
						from: new Date(Topdata[i].localTime).getTime(),
						to:
							Topdata[i + 1] == undefined
								? new Date(Topdata[i].localTime).getTime()
								: new Date(Topdata[i + 1].localTime).getTime(),
						columnSettings: {
							fill: am5.color(0x939598), //Grey
						},
					};
					data.push(localdata);
				} else if (
					Topdata[i].status === "warning" ||
					Topdata[i].status === "Warning"
				) {
					let localdata = {
						category: "",
						from: new Date(Topdata[i].localTime).getTime(),
						to:
							Topdata[i + 1] == undefined
								? new Date(Topdata[i].localTime).getTime()
								: new Date(Topdata[i + 1].localTime).getTime(),
						columnSettings: {
							fill: am5.color(0xffcd00), //Orange
						},
					};
					data.push(localdata);
				} else if (
					Topdata[i].status === "Alert" ||
					Topdata[i].status === "Anomaly"
				) {
					let localdata = {
						category: "",
						from: new Date(Topdata[i].localTime).getTime(),
						to:
							Topdata[i + 1] == undefined
								? new Date(Topdata[i].localTime).getTime()
								: new Date(Topdata[i + 1].localTime).getTime(),
						columnSettings: {
							fill: am5.color(0xe35205), //red
						},
					};
					data.push(localdata);
				} else if (
					Topdata[i].status === "Normal" ||
					Topdata[i].status === "Asset-ON"
				) {
					let localdata = {
						category: "",
						from: new Date(Topdata[i].localTime).getTime(),
						to:
							Topdata[i + 1] == undefined
								? new Date(Topdata[i].localTime).getTime()
								: new Date(Topdata[i + 1].localTime).getTime(),
						columnSettings: {
							fill: am5.color(0x2eb541), //green
						},
					};
					data.push(localdata);
				}
			}
			let YAxis2 = Chart2.yAxes.push(
				am5xy.CategoryAxis.new(root, {
					categoryField: "category",
					marginLeft: 9,
					renderer: am5xy.AxisRendererY.new(root, {}),
				})
			);

			function YscalePositionSet(val) {
				let count = 0;
				if (val !== undefined) {
					let temp1 = val.toString().split(".")[0];
					let temp2 = val.toString().split(".")[1];
					if (temp1 !== undefined)
						for (let index = 0; index < temp1.length; index++) {
							count++;
						}
					if (temp2 !== undefined)
						for (let index = 0; index < temp2.length; index++) {
							if (temp2[index] != 0) {
								count++;
								break;
							} else count++;
						}
				} else {
					count++;
				}
				return count * 10;
			}

			YAxis2.data.setAll([{ category: "" }]);
			YAxis2.get("renderer").labels.template.set("forceHidden", false);

			let XAxis2 = chart1.xAxes.push(
				am5xy.DateAxis.new(root, {
					groupData: true,
					width: am5.percent(80),
					startLocation: 1,
					endLocation: 3,
					marginTop: 0,
					maxDeviation: 0.5,
					baseInterval: { timeUnit: "minute", count: 10 },
					renderer: xRenderer,
				})
			);
			XAxis2.get("renderer").labels.template.set("forceHidden", true);

			let Series2 = Chart2.series.push(
				am5xy.ColumnSeries.new(root, {
					name: "displayName",
					xAxis: XAxis2,
					width: am5.percent(100),
					marginBottom: 0,
					yAxis: YAxis2,
					valueXField: "to",
					openValueXField: "from",
					categoryYField: "category",
					position: "absolute",
				})
			);

			Series2.columns.template.setAll({
				strokeWidth: 0,
				strokeOpacity: 0,
				height: am5.percent(20),
				templateField: "columnSettings",
				position: "absolute",
			});

			Series2.data.setAll(data);

			Chart2.appear(1000, 100);

			return () => {
				root.dispose();
			};
		}
	}, [plotData]);

	return (
		<div id="sensor-plot-left">
			<div id="deviation-plot">
				<div className="sensor-filter">
					<div className="title">DEVIATION PLOT</div>
				</div>
				<div className="common-box-asset-name"><div className="asset-name">{assetName}</div></div>
				{plotData.length > 0 ?
					<div className="sensor-plot-graph">
						<div id="chartdiv" style={{ width: "100%", height: "350px" }}></div>
					</div>
					:
					null}
			</div>
		</div>
	);
};

export default DeviationChart;
