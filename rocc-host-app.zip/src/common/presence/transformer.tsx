/*
 * Created on The Oct 19 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole } from "@rocc/rocc-client-services"
import { IPresenceMap } from "./types"

export const getSubscriptionsTransformer = (data: any) => {
    const response: IPresenceMap[] = []
    data.data.map((item: any) => {
        response.push({
            uuid: item.interested_identity,
            syncMapId: item.syncMapId,
            type: EClinicalRole.DEFAULT,
            subscribed: false,
        })
    })
    return response
}
