import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import MonthWiseChart from "./MonthWiseChart";

//Mock data for the chart component
const data = [
	{ date: "2022-0-1", truePositive: 629, falsePositive: 49, unClassified: 0 },
	{ date: "2022-5-1", truePositive: 2618, falsePositive: 99, unClassified: 6 },
	{ date: "2022-6-1", truePositive: 1857, falsePositive: 25, unClassified: 6 },
	{ date: "2022-8-1", truePositive: 0, falsePositive: 0, unClassified: 0 },
	{ date: "2022-9-1", truePositive: 0, falsePositive: 0, unClassified: 6 },

	{ date: "2022-10-1", truePositive: 0, falsePositive: 0, unClassified: 5 },
	{ date: "2022-11-1", truePositive: 0, falsePositive: 0, unClassified: 17 },
	{ date: "2022-12-1", truePositive: 0, falsePositive: 0, unClassified: 1 },
	{ date: "2023-1-1", truePositive: 0, falsePositive: 0, unClassified: 0 },
];

//Test Case to check chart exist in the component.
describe("MonthWiseChart", () => {
	it("renders the chart with data", () => {
		const { container } = render(<MonthWiseChart data={data} />);
		expect(container.querySelector("#chartdiv4")).toBeInTheDocument();
	});
});
