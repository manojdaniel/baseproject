CREATE SCHEMA IF NOT EXISTS rocc_overwatch;

GRANT ALL ON SCHEMA rocc_overwatch TO harbinger;
-- Add Extension to generate UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE FUNCTION rocc_overwatch.set_current_timestamp_updated_at()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
DECLARE
  _new record;
BEGIN
  _new := NEW;
  _new."updated_at" = NOW();
  RETURN _new;
END;
$BODY$;
ALTER FUNCTION rocc_overwatch.set_current_timestamp_updated_at()
    OWNER TO harbinger;


-- Table: rocc_overwatch.customers

-- DROP TABLE rocc_overwatch.customers;

CREATE TABLE rocc_overwatch.customers
(
    id serial NOT NULL,
    name text COLLATE pg_catalog."default" NOT NULL UNIQUE,
    status text COLLATE pg_catalog."default" NOT NULL,
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT customers_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_customers_updated_at ON rocc_overwatch.customers CASCADE;
CREATE TRIGGER set_rocc_overwatch_customers_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.customers
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_customers_updated_at ON rocc_overwatch.customers
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';

GRANT ALL ON TABLE rocc_overwatch.customers TO harbinger;

-- Table: rocc_overwatch.raw_upload_data

-- DROP TABLE rocc_overwatch.raw_upload_data;

CREATE TABLE rocc_overwatch.raw_upload_data
(
    id uuid DEFAULT uuid_generate_v4 () NOT NULL,
    customer_id integer NOT NULL,
    data json,
    template_version text COLLATE pg_catalog."default" NOT NULL,
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT raw_upload_data_pkey PRIMARY KEY (id),
    CONSTRAINT customer_id_fk FOREIGN KEY (customer_id)
        REFERENCES rocc_overwatch.customers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_raw_upload_data_updated_at ON rocc_overwatch.raw_upload_data CASCADE;
CREATE TRIGGER set_rocc_overwatch_raw_upload_data_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.raw_upload_data
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_raw_upload_data_updated_at ON rocc_overwatch.raw_upload_data
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';


GRANT ALL ON TABLE rocc_overwatch.raw_upload_data TO harbinger;

-- Table: rocc_overwatch.infrastructure_configurations

-- DROP TABLE rocc_overwatch.infrastructure_configurations;

CREATE TABLE rocc_overwatch.infrastructure_configurations
(
    id serial NOT NULL,
    profile text COLLATE pg_catalog."default" NOT NULL,
    customer_id integer NOT NULL UNIQUE,
    proxy_url text COLLATE pg_catalog."default",
    infra_configs json,
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT infrastructure_configurations_pkey PRIMARY KEY (id),
    CONSTRAINT customer_id_fk FOREIGN KEY (customer_id)
        REFERENCES rocc_overwatch.customers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_infrastructure_configurations_updated_at ON rocc_overwatch.infrastructure_configurations CASCADE;
CREATE TRIGGER set_rocc_overwatch_infrastructure_configurations_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.infrastructure_configurations
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_infrastructure_configurations_updated_at ON rocc_overwatch.infrastructure_configurations
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';

GRANT ALL ON TABLE rocc_overwatch.infrastructure_configurations TO harbinger;

-- Table: rocc_overwatch.service_jobs

-- DROP TABLE rocc_overwatch.service_jobs;

CREATE TABLE rocc_overwatch.service_jobs
(
    id serial NOT NULL,
    job_name text COLLATE pg_catalog."default" NOT NULL UNIQUE,
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT service_jobs_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_service_jobs_updated_at ON rocc_overwatch.service_jobs CASCADE;
CREATE TRIGGER set_rocc_overwatch_service_jobs_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.service_jobs
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_service_jobs_updated_at ON rocc_overwatch.service_jobs
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';

GRANT ALL ON TABLE rocc_overwatch.service_jobs TO harbinger;

-- Table: rocc_overwatch.service_tasks

-- DROP TABLE rocc_overwatch.service_tasks;

CREATE TABLE rocc_overwatch.service_tasks
(
    id serial NOT NULL,
    task_name text COLLATE pg_catalog."default" NOT NULL,
    job_id integer NOT NULL,
    execution_order integer NOT NULL,
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT service_tasks_pkey PRIMARY KEY (id),
    CONSTRAINT service_tasks_task_name_job_id_key UNIQUE (task_name, job_id),
    CONSTRAINT job_id_fk FOREIGN KEY (job_id)
        REFERENCES rocc_overwatch.service_jobs (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_service_tasks_updated_at ON rocc_overwatch.service_tasks CASCADE;
CREATE TRIGGER set_rocc_overwatch_service_tasks_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.service_tasks
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_service_tasks_updated_at ON rocc_overwatch.service_tasks
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';

GRANT ALL ON TABLE rocc_overwatch.service_tasks TO harbinger;

-- Table: rocc_overwatch.service_job_transactions

-- DROP TABLE rocc_overwatch.service_job_transactions;

CREATE TABLE rocc_overwatch.service_job_transactions
(
    id uuid DEFAULT uuid_generate_v4 () NOT NULL,
    operation_type text COLLATE pg_catalog."default" NOT NULL,
    current_job_id integer NOT NULL,
    current_task_id integer NOT NULL,
    entity_type text COLLATE pg_catalog."default" NOT NULL,
    entity_id integer NOT NULL,
    transaction_data json,
    status text COLLATE pg_catalog."default" NOT NULL,
    upload_record_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    created_by text COLLATE pg_catalog."default",
    modified_by text COLLATE pg_catalog."default",
    CONSTRAINT service_job_transactions_pkey PRIMARY KEY (id),
    CONSTRAINT current_job_id_fk FOREIGN KEY (current_job_id)
        REFERENCES rocc_overwatch.service_jobs (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT current_task_id_fk FOREIGN KEY (current_task_id)
        REFERENCES rocc_overwatch.service_tasks (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT upload_record_id_fk FOREIGN KEY (upload_record_id)
        REFERENCES rocc_overwatch.raw_upload_data (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

DROP TRIGGER IF EXISTS set_rocc_overwatch_service_job_transactions_updated_at ON rocc_overwatch.service_job_transactions CASCADE;
CREATE TRIGGER set_rocc_overwatch_service_job_transactions_updated_at
    BEFORE UPDATE
    ON rocc_overwatch.service_job_transactions
    FOR EACH ROW
    EXECUTE PROCEDURE rocc_overwatch.set_current_timestamp_updated_at();
COMMENT ON TRIGGER set_rocc_overwatch_service_job_transactions_updated_at ON rocc_overwatch.service_job_transactions
    IS 'trigger to set value of column "updated_at" to current timestamp on row update';

GRANT ALL ON TABLE rocc_overwatch.service_job_transactions TO harbinger;
