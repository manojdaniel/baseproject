"""
 Created on Thu Sep 10 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os

from flask import Flask, jsonify, request
from flask_restful import Api
from flask_cors import CORS
from gevent.pywsgi import WSGIServer

from src.controllers.customer import Customer
from src.controllers.command_center import CommandCenter
from src.controllers.org_role import OrgRole
from src.controllers.site import Site, SiteOffboard
from src.controllers.scanner import Scanner, ScannerOffboard, ScannerDetails
from src.controllers.email_template import EmailTemplate
from src.controllers.eula import Eula
from src.controllers.file import File
from src.controllers.vault import Vault
from src.controllers.user import User
from src.controllers.fse_user import FseUser, ReactivateFseUser
from src.controllers.fse_user import ReInviteFseUser
from src.controllers.mfa_policy import MfaPolicy
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.utility.interceptor import interceptor
from src.constants.constants import PHILIPS_OVERWATCH_URI, CONTENT_TYPE, CORS_HEADERS
from src.utility.starters import initialize_server
from opencensus.ext.azure.trace_exporter import AzureExporter
from opencensus.ext.flask.flask_middleware import FlaskMiddleware
from opencensus.trace.samplers import ProbabilitySampler

app = Flask(__name__)
middleware = FlaskMiddleware(
    app,
    exporter=AzureExporter(
        connection_string=os.environ["APPINSIGHTS_CONNECTION_STRING"]),
    sampler=ProbabilitySampler(rate=1.0)
)
CORS(app,
     origins=["http:\/\/localhost:3000$",
              "http:\/\/localhost:3001$",
              "http:\/\/localhost:3002$",
              "https:\/\/localhost",
              "https:\/\/rocc-cpp-.*"],
     send_wildcard=True,
     methods=["GET", "PUT", "POST", "DELETE", "OPTIONS", "PATCH"],
     allow_headers=["Origin", "X-Requested-With", "Content-Type", "Accept", "Authorization", "api-version", "Access-Control-Allow-Origin"],
     supports_credentials=True)
app.config[CORS_HEADERS] = CONTENT_TYPE
api = Api(app)

api.add_resource(File,
                 f"{PHILIPS_OVERWATCH_URI}/File",
                 f"{PHILIPS_OVERWATCH_URI}/File/<string:record_id>",
                 endpoint="File")
api.add_resource(Customer,
                 f"{PHILIPS_OVERWATCH_URI}/Customer/$bulkOnboard",
                 f"{PHILIPS_OVERWATCH_URI}/Customer/$bulkUpdate",
                 f"{PHILIPS_OVERWATCH_URI}/Customer/<string:customer_identifier>/<string:customer_org_infra_uuid>",
                 endpoint="Customer")
api.add_resource(Site,
                 f"{PHILIPS_OVERWATCH_URI}/Site",
                 endpoint="Site")
api.add_resource(SiteOffboard,
                 f"{PHILIPS_OVERWATCH_URI}/Site/$offboard",
                 endpoint="SiteOffboard")
api.add_resource(Scanner,
                 f"{PHILIPS_OVERWATCH_URI}/Customer/<int:customer_id>/Site/<int:site_id>/Scanner",
                 f"{PHILIPS_OVERWATCH_URI}/Customer/<int:customer_id>/Site/<int:site_id>/Scanner/<int:scanner_id>",
                 endpoint="Scanner")
api.add_resource(ScannerDetails,
                 f"{PHILIPS_OVERWATCH_URI}/Scanner/$details",
                 endpoint="ScannerDetails")
api.add_resource(ScannerOffboard,
                 f"{PHILIPS_OVERWATCH_URI}/Scanner/$offboard",
                 endpoint="ScannerOffboard")
api.add_resource(Vault,
                 f"{PHILIPS_OVERWATCH_URI}/Configs/<string:vault_path>",
                 endpoint="Configs")
api.add_resource(OrgRole,
                 f"{PHILIPS_OVERWATCH_URI}/OrgRole/<string:org_name>",
                 endpoint="OrgRole")
api.add_resource(Eula,
                 f"{PHILIPS_OVERWATCH_URI}/Eula/<string:customer_id>",
                 endpoint="Eula")
api.add_resource(EmailTemplate,
                 f"{PHILIPS_OVERWATCH_URI}/EmailTemplate/<string:customer_id>",
                 endpoint="EmailTemplate")
api.add_resource(User,
                 f"{PHILIPS_OVERWATCH_URI}/User",
                 f"{PHILIPS_OVERWATCH_URI}/User/<string:user_id>",
                 endpoint="User")
api.add_resource(CommandCenter,
                 f"{PHILIPS_OVERWATCH_URI}/CommandCenter",
                 f"{PHILIPS_OVERWATCH_URI}/CommandCenter/<int:seat_id>",
                 f"{PHILIPS_OVERWATCH_URI}/CommandCenter/<int:customer_id>/<int:seat_id>",
                 endpoint="CommandCenter")
api.add_resource(FseUser,
                 f"{PHILIPS_OVERWATCH_URI}/FseUser",
                 f"{PHILIPS_OVERWATCH_URI}/FseUser/<string:user_uuid>",
                 f"{PHILIPS_OVERWATCH_URI}/FseUser/Deactivate/<string:user_id>",
                 endpoint="FseUser")

api.add_resource(MfaPolicy,
                 f"{PHILIPS_OVERWATCH_URI}/MfaPolicy",
                 endpoint="MfaPolicy")

api.add_resource(ReInviteFseUser,
                 f"{PHILIPS_OVERWATCH_URI}/ReInviteFseUser",
                 endpoint="ReInviteFseUser")

api.add_resource(ReactivateFseUser,
                 f"{PHILIPS_OVERWATCH_URI}/ReactivateFseUser/<string:user_id>/<string:uuid>",
                 f"{PHILIPS_OVERWATCH_URI}/ActivateFseUser",
                 endpoint="ReactivateFseUser")

LOG = create_logger("APP")


@app.errorhandler(RoccException)
def handle_rocc_exception(error):
    # TODO: Need to define error code when failure is not because of HttpRequests
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response


@app.errorhandler(Exception)
def handle_unexpected_exception(error):
    status_code = 500
    # TODO: Need to check how to pass message in case of default exception
    LOG.exception(f"An exception has occurred while processing the request: {error}.")
    response = {
        "message": "Exception Occurred"
    }
    return jsonify(response), status_code


@app.before_request
def before_request():
    proto = request.headers["X-Forwarded-Proto"]
    if not proto == "https":
        LOG.error(f"Following request {request.url} was not a secure one has the protocol: {proto}")
        return jsonify({"error": "Request is not using secure protocol, please use HTTPS"}), 400
    return interceptor()


@app.before_first_request
def init():
    initialize_server()


if __name__ == "__main__":
    http_server = WSGIServer((os.environ["FLASK_RUN_HOST"], int(os.environ["FLASK_RUN_PORT"])), app)
    app.debug = True if (os.environ["LOG_LEVEL"] == "DEBUG") else False
    http_server.serve_forever()
