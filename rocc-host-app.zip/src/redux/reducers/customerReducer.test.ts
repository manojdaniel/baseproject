/*
 * Created on Mon May 23 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { FETCH_LOCATION_DATA, FETCH_LOCATION_DATA_FAILED, FETCH_ROOMS_DATA, SELECT_HOSPITAL_CARD, UPDATE_CUSTOMER_METADATA, UPDATE_CUSTOMER_ORG_ID, UPDATE_ROOMS_DATA, UPDATE_ROOM_DETAILS, UPDATE_ROOM_PRESENCE } from "../actions/types"
import customerReducer, { initialStatesForCustomer } from "./customerReducer"

describe("Customer Reducer tests", () => {
  it("should handle call reducer action", () => {
    const value = customerReducer(initialStatesForCustomer, {type: FETCH_ROOMS_DATA})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: UPDATE_CUSTOMER_METADATA})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: SELECT_HOSPITAL_CARD})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: UPDATE_ROOM_DETAILS})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: UPDATE_ROOMS_DATA})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: UPDATE_ROOM_PRESENCE})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: FETCH_LOCATION_DATA_FAILED})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: UPDATE_CUSTOMER_ORG_ID})
    expect(value).toBeDefined()
  })
  it("should handle call reducer empty action", () => {
    const value = customerReducer(initialStatesForCustomer,{type: FETCH_LOCATION_DATA})
    expect(value).toBeDefined()
  })
})
