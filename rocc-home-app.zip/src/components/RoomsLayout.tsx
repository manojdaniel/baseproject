/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import "@dls-pdv/semantic-ui-foundation/dist/semantic.css"
import { ILocationInfo } from "@rocc/rocc-client-services"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { IdnComponent } from "@rocc/rocc-rooms-components"
import escapeRegExp from "lodash.escaperegexp"
import filter from "lodash.filter"
import React, { useEffect, useRef } from "react"
import { useSelector } from "react-redux"
import { Grid } from "semantic-ui-react"
import { EGridWidth } from "../lib/types"
import { GLOBAL_RIGHTSIDE_PANEL, GLOBAL_UPDATE_ACTIVE_LOCATION } from "../redux/actions/types"
import { IStore } from "../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalMetaSite } from "../redux/store/externalAppStates"
import RoomsComponent from "./rooms-component/RoomsComponent"
import styles from "./RoomsLayout.module.scss"
import cx from "classnames"
import { CustomLoader, getIntlProvider } from "@rocc/rocc-global-components"
import en from "../resources/translations/en-US"
import { checkIfCallMessageDisplayed, checkIfConnectedCallIsTransitioning } from "../common/helpers/helpers"

interface IIdnData {
    id: number
    name: string
    location: string
    icon: string
    rooms?: string
}

const RoomsLayout = () => {
    const {
        sideBar, locations, activeLocationId, focusedCallAndConsole, videoCallStatus, connectedCallDetails, onHoldCallDetails
    } = useSelector((state: IStore) => ({
        sideBar: state.externalReducer.sideBar,
        locations: state.externalReducer.locations,
        activeLocationId: state.externalReducer.activeLocationId,
        focusedCallAndConsole: state.externalReducer.focusedCallAndConsole,
        videoCallStatus: state.externalReducer.callingDetails.videoCallStatus,
        connectedCallDetails: state.externalReducer.callingDetails.connectedCallDetails,
        onHoldCallDetails: state.externalReducer.callingDetails.onHoldCallDetails
    }))
    const searchResult = useRef(locations)
    const { intl } = getIntlProvider()
    useEffect(() => {
        searchResult.current = locations
        if (activeLocationId === -1 && locations.length > 0) {
            dispatchToParentStore({ type: GLOBAL_UPDATE_ACTIVE_LOCATION, activeLocationId: locations[0].id })
        }
    }, [locations])

    useEffect(() => {
        sendLogsToAzure({ contextData: { Page: "Desktop Home" } })
    }, [])
    useEffect(() => {
        const isInitialState = connectedCallDetails.contextId === "" && !onHoldCallDetails.length
        if (isInitialState) {
            return
        }

        if (focusedCallAndConsole?.callContextId === "" && !checkIfConnectedCallIsTransitioning(videoCallStatus) && !checkIfCallMessageDisplayed(videoCallStatus)) {
            dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: "", displayRightSidePanel: false, desktopFullScreen: false } })
        }
        else {
            dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: "", displayRightSidePanel: true, desktopFullScreen: false } })
        }

    }, [focusedCallAndConsole])

    const siteName = fetchGlobalMetaSite()
    const getIdnData = () => {
        const idnDataList: IIdnData[] = []
        searchResult.current.forEach((location: any) => {
            idnDataList.push(
                {
                    id: location.id,
                    name: location.name,
                    location: location.address,
                    icon: "HospitalLocation big"
                }
            )
        })
        return idnDataList
    }

    const updateActiveLocation = (location: any) => {
        if (location) {
            sendLogsToAzure({ contextData: { component: "IDN:Site Panel", event: `Active location: ${location.name}` } })
            dispatchToParentStore({ type: GLOBAL_UPDATE_ACTIVE_LOCATION, activeLocationId: location.id })
        }
    }

    const handleIdnSearch = (value: any) => {
        infoLogger(`IDN Search completed`)
        sendLogsToAzure({ contextData: { component: "Search:Expert User View:Site Search Panel", SearchEvent: value } })
        if (value.length < 1) {
            searchResult.current = locations
        } else {
            const re = new RegExp(escapeRegExp(value), "i")
            const isMatch = (location: ILocationInfo) => re.test(location.name)
            searchResult.current = filter(locations, isMatch)
        }
    }

    return (
        <>
            {getIdnData().length > 0 ?
                <div id="roomContainer" className={styles.roomContainer}>
                    <Grid columns={EGridWidth.TWO} className={styles.roomContainerGrid}>
                        <Grid.Column className={styles.idnWrapper}>
                            {getIdnData().length > 0 && <IdnComponent idnData={getIdnData()} idnName={siteName} activeLocationId={activeLocationId}
                                getActiveLocation={updateActiveLocation} handleIdnSearch={(value) => handleIdnSearch(value)}
                            />}
                        </Grid.Column>
                        <Grid.Column className={cx(sideBar.displayRightSidePanel ? styles.roomLayoutWithSideBar : styles.roomLayoutWithoutSideBar)}>
                            <div className={styles.roomComponentWrapper}>
                                <RoomsComponent />
                            </div>
                        </Grid.Column>
                    </Grid >
                </div> :
                <div id="homeAppLoader">
                    <CustomLoader
                        content={`${intl.formatMessage({ id: "content.loading.text", defaultMessage: en["content.loading.text"] })}`}
                        dimmer={true}
                        inverted={true}
                        inline={true}
                        size={"normal"}
                        customStyle={{ top: "400px" }} />
                </div>

            }
        </>
    )
}

export default RoomsLayout
