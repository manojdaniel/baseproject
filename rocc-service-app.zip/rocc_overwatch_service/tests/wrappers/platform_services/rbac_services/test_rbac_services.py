"""
 Created on Tue Mar 15 2022
 Copyright (c) 2022 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest import mock
from src.wrappers.platform_services.rbac_services.rbac_services import create_roles_in_rbac, create_user_role_mapping, delete_roles_for_organization, fetch_rbac_role_for_devices, get_available_permissions, get_existing_permission_list_for_org, get_rolelist_for_organization, get_roles_for_organization, update_user_role_mapping
from tests.mocks.mock_requests import DUMMY_PRIVATE_KEY, MockResponse


class TestRbacServices(unittest.TestCase):

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse([
                    {
                        "id": 22,
                        "role": "EXPERTUSERINCOGNITOROLE",
                        "usersMapped": 0,
                        "organization": "1234"
                    }], 200))
    def test_rolelist_for_organization_200(self, m_get):
        m_get.return_value = {}
        response = get_rolelist_for_organization(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, org_id="1234")
        self.assertEqual(response, {'EXPERTUSERINCOGNITOROLE'})

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_rolelist_for_organization_400(self, m_get, m_log):
        m_get.return_value = {}
        get_rolelist_for_organization(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, org_id="1234")
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse([
                    {
                        "id": 2948,
                        "role": "EXPERTUSERINCOGNITOROLE",
                        "usersMapped": 0,
                        "organization": "adcd563c-e5b3-4abd-b7f0-deaf4937616d"
                    }], 200))
    def test_get_roles_for_organization_200(self, m_get):
        m_get.return_value = {}
        dummy_output = [
            {
                "id": 2948,
                "role": "EXPERTUSERINCOGNITOROLE",
                        "usersMapped": 0,
                        "organization": "adcd563c-e5b3-4abd-b7f0-deaf4937616d"
            }]
        response = get_roles_for_organization(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY)
        self.assertEqual(response, dummy_output)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_get_roles_for_organization_400(self, m_get, m_log):
        m_get.return_value = {}
        get_roles_for_organization(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY)
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse([{"roles": "protocol", "userId": 9}], 200))
    def test_fetch_rbac_role_for_devices_200(self, m_post):
        m_post.return_value = {}
        response = fetch_rbac_role_for_devices(
            url="/rbac_url", device_ids={}, token=DUMMY_PRIVATE_KEY, org_ctxt_header="test")
        self.assertEqual(response, [{'userId': 9, 'role': 'DEVICEROLE'}])

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_fetch_rbac_role_for_devices_400(self, m_post, m_log):
        m_post.return_value = {}
        fetch_rbac_role_for_devices(
            url="/rbac_url", device_ids={}, token=DUMMY_PRIVATE_KEY, org_ctxt_header="test")
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"status_code ": "201"}, 201))
    def test_create_user_role_mapping_200(self, m_post):
        m_post.return_value = {}
        response = create_user_role_mapping(
            url="/rbac_url", user_role_mapping={}, token=DUMMY_PRIVATE_KEY, org_ctxt_header="test")
        self.assertEqual(response, True)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_create_user_role_mapping_400(self, m_post, m_log):
        m_post.return_value = {}
        create_user_role_mapping(
            url="/rbac_url", user_role_mapping={}, token=DUMMY_PRIVATE_KEY, org_ctxt_header="test")
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.put",
                side_effect=lambda *args, **kwargs: MockResponse({"status_code ": "200"}, 200))
    def test_update_user_role_mapping_200(self, m_put):
        m_put.return_value = {}
        response = update_user_role_mapping(
            url="/rbac_url", user_role_mapping={}, token=DUMMY_PRIVATE_KEY, user_uuid="", org_ctxt_header="test")
        self.assertEqual(response, True)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.put",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_update_user_role_mapping_400(self, m_put, m_log):
        m_put.return_value = {}
        update_user_role_mapping(
            url="/rbac_url", user_role_mapping={}, token=DUMMY_PRIVATE_KEY, user_uuid="", org_ctxt_header="test")
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.delete",
                side_effect=lambda *args, **kwargs: MockResponse({"status_code ": "200"}, 200))
    def test_delete_roles_for_organization_200(self, m_delete):
        m_delete.return_value = {}
        response = delete_roles_for_organization(
            url="/rbac_url", deleted_roles=[{"id": 12, "role": "test"}], token=DUMMY_PRIVATE_KEY)
        self.assertEqual(response, True)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.delete",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_delete_roles_for_organization_400(self, m_delete, m_log):
        m_delete.return_value = {}
        delete_roles_for_organization(
            url="/rbac_url", deleted_roles=[{"id": 12, "role": "test"}], token=DUMMY_PRIVATE_KEY)
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"permissions": [{"data": "READ"}]}, 200))
    def test_get_available_permissions_200(self, m_get):
        m_get.return_value = {}
        dummy_output = []
        response = get_available_permissions(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY)
        self.assertEqual(response, dummy_output)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_get_available_permissions_400(self, m_get, m_log):
        m_get.return_value = {}
        get_available_permissions(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY)
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"permissions": [{"data": "READ"}]}, 200))
    def test_get_existing_permission_list_for_org_200(self, m_get):
        m_get.return_value = {}
        dummy_output = [{'data': 'READ'}]
        response = get_existing_permission_list_for_org(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, infra_role="test", org_id="testOrg")
        self.assertEqual(response, dummy_output)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.get",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_get_existing_permission_list_for_org_400(self, m_get, m_log):
        m_get.return_value = {}
        get_existing_permission_list_for_org(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, infra_role="test", org_id="testOrg")
        m_log.assert_called()

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"permissions": [{"data": "READ"}]}, 200))
    def test_create_roles_in_rbac_200(self, m_post):
        m_post.return_value = {}
        response = create_roles_in_rbac(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, org_id="testOrg", rbac_roles=["ADMIN"])
        self.assertEqual(response, False)

    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.requests.post",
                side_effect=lambda *args, **kwargs: MockResponse({"mock_error": "mocked_access_token_failed"}, 400))
    @mock.patch("src.wrappers.platform_services.rbac_services.rbac_services.create_logger.error")
    def test_create_roles_in_rbac_400(self, m_post, m_log):
        m_post.return_value = {}
        create_roles_in_rbac(
            url="/rbac_url", token=DUMMY_PRIVATE_KEY, org_id="testOrg", rbac_roles=["ADMIN"])
        m_log.assert_called()


suite = unittest.TestSuite()

suite.addTest(TestRbacServices("test_rolelist_for_organization_200"))
suite.addTest(TestRbacServices("test_rolelist_for_organization_400"))
suite.addTest(TestRbacServices("test_get_roles_for_organization_200"))
suite.addTest(TestRbacServices("test_get_roles_for_organization_400"))
suite.addTest(TestRbacServices("test_fetch_rbac_role_for_devices_200"))
suite.addTest(TestRbacServices("test_fetch_rbac_role_for_devices_400"))
suite.addTest(TestRbacServices("test_create_user_role_mapping_200"))
suite.addTest(TestRbacServices("test_create_user_role_mapping_400"))
suite.addTest(TestRbacServices("test_delete_roles_for_organization_200"))
suite.addTest(TestRbacServices("test_delete_roles_for_organization_400"))
suite.addTest(TestRbacServices("test_get_available_permissions_200"))
suite.addTest(TestRbacServices("test_get_available_permissions_400"))
suite.addTest(TestRbacServices("test_create_roles_in_rbac_200"))
suite.addTest(TestRbacServices("test_create_roles_in_rbac_400"))
suite.addTest(TestRbacServices(
    "test_get_existing_permission_list_for_org_200"))
suite.addTest(TestRbacServices(
    "test_get_existing_permission_list_for_org_400"))

unittest.TextTestRunner(verbosity=1).run(suite)
