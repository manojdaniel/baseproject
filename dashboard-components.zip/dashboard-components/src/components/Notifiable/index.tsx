import React, { useEffect, memo } from 'react';
import { notification } from 'antd';

const Notifiable = ({ message, description, onClose, visible }) => {
    useEffect(() => {
        if (visible) {
            // Open the notification
            const key = `open${Date.now()}`;
            notification.open({
                message: message,
                description: description,
                duration: 0,
                key,
                onClose: () => {
                    onClose && onClose();
                },
                btn: null, // Can be a custom button if required
                style: { marginTop: "200px" },
            });

            // If the prop changes to not visible, close the notification
            return () => {
                notification.destroy(key);
            };
        }
    }, [visible, message, description, onClose]);

    return null;
};

export default React.memo(Notifiable);
