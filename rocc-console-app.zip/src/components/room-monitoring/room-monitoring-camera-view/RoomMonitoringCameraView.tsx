/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoomMoinitorRenderState, IConsoleSession } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger } from "@rocc/rocc-logging-module"
import cx from "classnames"
import times from "lodash.times"
import React, { useEffect, useState } from "react"
import { Grid, GridColumn, GridRow } from "semantic-ui-react"
import { NO_VIDEO_PROP } from "../../../common/constants/constants"
import { cameraName, detachTracks } from "../../../common/helpers/multiCameraUtility"
import { IMultiCamVideoTrack } from "../../../common/modules/multi-camera/MultiCameraTypes"
import en from "../../../resources/translations/en-US"
import RoomMonitoringCameraItem from "../room-monitoring-camera-item/RoomMonitoringCameraItem"
import RoomMonitoringDefaultView from "../room-monitoring-default-view/RoomMonitoringDefaultView"
import styles from "../room-monitoring-stream-view/RoomMonitoringStreamView.scss"
import { IRoomMonitorStream } from "../RoomMonitoringTypes"

const FILENAME = "RoomMonitoringCameraView.tsx : "

interface IRoomMonitoringCameraView {
    singleRecieverView: boolean
    maxSupportedCameras: number
    videoTracks: IMultiCamVideoTrack[]
    videoStarted: boolean
    isSwitchingConsoleSession: boolean
    setIsSwitchingConsoleSession: (state: boolean) => void
    setVideoStarted: (state: boolean) => void
    handlefullscreenClick: (trackName: string) => void
    consoleSession: IConsoleSession
}

const RoomMonitoringCameraView = ({
    singleRecieverView, videoTracks, maxSupportedCameras, videoStarted, isSwitchingConsoleSession,
    handlefullscreenClick, setVideoStarted, setIsSwitchingConsoleSession, consoleSession
}: IRoomMonitoringCameraView) => {

    const { LOADING, MESSAGE, RENDER_VIDEO } = ERoomMoinitorRenderState
    const { intl } = getIntlProvider()
    const loggerInitialMessage = `${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId}`

    const [roomMonitorStreams, setRoomMonitorStreams] = useState([] as IRoomMonitorStream[])

    const getTrack = (trackName: string) => videoTracks.find((videoTrackItem: IMultiCamVideoTrack) => videoTrackItem.videoTrack && videoTrackItem.videoTrack.name.replace(":", "") === trackName)

    const getRenderState = (trackName: string) => {
        infoLogger(`${loggerInitialMessage} - Determining render state for track ${trackName}`)
        const track = getTrack(trackName)
        let returnValue: ERoomMoinitorRenderState
        if (videoTracks.length === 1) {
            returnValue = track?.videoTrack ? videoStarted ? RENDER_VIDEO : LOADING : MESSAGE
        } else {
            returnValue = videoStarted ? RENDER_VIDEO : LOADING
        }
        infoLogger(`${loggerInitialMessage} - Setting render state for track ${trackName} to ${returnValue}`)
        return returnValue
    }

    const getCameraAndFullscreenControlState = (trackName: string) => {
        const track = getTrack(trackName)
        if (videoTracks.length === 1) {
            return track?.videoTrack ? !videoStarted : true
        } else {
            return !videoStarted
        }
    }

    const getVideoTrack = (trackName: string) => {
        infoLogger(`${loggerInitialMessage} - Check if track ${trackName} is received from twillio`)
        const track = getTrack(trackName)
        if (track) {
            if (track.videoTrack) {
                detachTracks([track.videoTrack])
            }
            infoLogger(`${loggerInitialMessage} - Track ${trackName} is received from twillio`)
            return { ...track }
        } else {
            infoLogger(`${loggerInitialMessage} - Track ${trackName} is not received from twillio`)
            return { ...NO_VIDEO_PROP }
        }
    }

    useEffect(() => {
        infoLogger(`${loggerInitialMessage} - Preparing video tracks for rendering`)
        const localRoomMonitorStreams = times(maxSupportedCameras, (num: number) => {
            const trackName = cameraName(num, intl)
            const controlsState = getCameraAndFullscreenControlState(trackName)
            const roomMonitorStreamObj: IRoomMonitorStream = {
                cameraName: trackName,
                cameraState: true,
                hideCameraControl: true,
                hideFullscreenControl: controlsState,
                message: intl.formatMessage({ id: "content.room.noCameraAvailable", defaultMessage: en["content.room.noCameraAvailable"] }),
                renderState: getRenderState(trackName),
                videoTrackItem: getVideoTrack(trackName),
                isSwitchingConsoleSession: isSwitchingConsoleSession,
                handlefullscreenClick,
                setVideoStarted,
                setIsSwitchingConsoleSession,
                consoleSession
            }
            return roomMonitorStreamObj
        })
        setRoomMonitorStreams(localRoomMonitorStreams)
    }, [videoTracks])

    const renderCameraGrid = () => {
        return <Grid className={cx(styles.roomMonitorStreamGrid, singleRecieverView ? styles.singleReceiverGrid : styles.multiReceiverGrid)} id={"roomMonitorCameraView"}>
            {roomMonitorStreams.map((roomMonitoringProps: any, index: number) => {
                return singleRecieverView ? <GridColumn className={styles.roomMonitorStreamColumn} key={index}>
                    <RoomMonitoringCameraItem {...roomMonitoringProps} />
                </GridColumn>
                    : <GridRow className={styles.roomMonitorStreamRow} key={index}>
                        <RoomMonitoringCameraItem {...roomMonitoringProps} />
                    </GridRow>
            })}
        </Grid>
    }

    const renderLoadingView = () => {
        return <RoomMonitoringDefaultView
            roomMonitorMessage={""}
            maxSupportedCameras={maxSupportedCameras}
            singleRecieverView={singleRecieverView}
            renderState={LOADING}
            isSwitchingConsoleSession={isSwitchingConsoleSession}
            currentUserUuid={consoleSession.requester}
        />
    }

    return <>
        {videoTracks.length === 0 ? renderLoadingView()
            : renderCameraGrid()
        }
    </>
}

export default RoomMonitoringCameraView
