/*
 * Created on Tue Dec 17 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import React from "react"
import NetworkDetector from "./NetworkDetector"
import { shallow } from "enzyme"
import * as Redux from "react-redux"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import { EConnectionStatus } from "@rocc/rocc-client-services"
import { withHooks } from "jest-react-hooks-shallow"

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: () => jest.fn(),
}))

jest.mock("../../utility/api/apiUtility", () => ({
    ...jest.requireActual("../../utility/api/apiUtility"),
    refreshToken: jest.fn().mockImplementation(() => new Promise((resolve) => { resolve("") })),
}))

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const mockAppState: any = {
    userReducer: { currentUser: { accessToken: "token", sessionId: "sessionId" } },
    configReducer: {
        urls: { IAM_SERVICES_URL: "http://localhost" },
        isProxy: "false",
        configs: { PING_URL: "http://localhost" }
    },
    clientStatusReducer: {
        applicationConnectionState: EConnectionStatus.AVAILABLE,
    }

}

let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")

const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

const getShallowWrapper = () => { return shallow(<NetworkDetector />) }
const findElement = () => {
    wrapper = getShallowWrapper()
    expect(wrapper.find("#NetworkDetector")).toHaveLength(1)
}


describe("NetworkDetector tests", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })
    it("should render div with NetworkDetector", () => {
        withHooks(() => {
            findElement()
            window.dispatchEvent(new Event('online'))
        })
    })

    it("should trigger offline event with NetworkDetector", () => {
        withHooks(() => {
            findElement()
            window.dispatchEvent(new Event('offline'))
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })

})
