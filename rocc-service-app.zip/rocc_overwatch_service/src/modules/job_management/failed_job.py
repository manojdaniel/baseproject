"""
 Created on Fri Nov 20 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import traceback

from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import CURRENT_JOB, FAILED, ENTITY_ID, FAILED_AT, HSDP_IAM_URL, OPERATION, TRANSACTION_ID, ID
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import check_for_parallel_transactions_and_update_customer_status, \
    get_service_job_transactions_details, update_customers_table, update_service_job_transaction_status
from src.modules.event_management.event_enums import EJobs, EOperations
from src.modules.job_management.job_handler import JobHandler
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data

LOG = create_logger("FailedJob")


class FailedJob(JobHandler):
    def start_job(self, payload):
        """ 
        Orchestrate all tasks in Job
        1. Fetch all tasks under this job
        2. Fetch corresponding transaction from transaction table
        3. Initiate execution of tasks in order
        4. After completion of all tasks in the Job send a RabbitMQ message
        """
        try:
            LOG.info(f"Starting Job: {EJobs.FAILED.value}")

            self._payload = payload
            self.load_vault_configs()
            self._token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                          issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                          private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._client = get_client_connection(self._token, org_infra_uuid=self._parent_org_id)
            job_transaction_details = self.fetch_transaction_from_db(transaction_id=self._payload[TRANSACTION_ID])

            LOG.debug("Initiating failed Job. !!")
            self.update_transaction_in_db_wrt_job(transaction_id=job_transaction_details[0][ID],
                                                  status=FAILED)
            self.update_database()

            LOG.info(f"Finished Job: {self._payload[CURRENT_JOB]}")
        except Exception as ex:
            LOG.error("Encountered error in failed job: {}".format(ex))
            LOG.error(traceback.print_exc())

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        pass

    def fetch_transaction_from_db(self, transaction_id):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(transaction_id, client=self._client)
        LOG.info("Fetch job details for transaction_id, {} is successful".format(transaction_id))
        return transaction_details

    def update_transaction_in_db_wrt_job(self, transaction_id, status):
        """Update corresponding transaction from transaction table"""
        update_status = update_service_job_transaction_status(transaction_id=transaction_id, status=status, client=self._client)
        LOG.info("Job Status transaction_id, {} updated and status is, {}".format(transaction_id, status))
        return update_status

    def execute_tasks(self, tasks):
        """
        Initiate execution of tasks in order
        """
        pass

    def post_message(self, payload):
        """
        1. After completion of all tasks in the Job send a RabbitMQ message
        """
        pass

    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """
        pass

    def load_vault_configs(self):
        """Fetch vault data from corresponding vault profile"""
        try:
            self._profile_configs = get_profile_data()
        except Exception as ex:
            LOG.error(f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}, with error: {ex}")
            raise RoccException(status_code=500, payload=f"Could not retrieve vault profile configs for transaction: {self._payload[TRANSACTION_ID]}")

    def update_database(self):
        try:
            if self._payload[OPERATION] == EOperations.NEW_CUSTOMER_ONBOARD.value and self._payload[FAILED_AT] and self._payload[FAILED_AT] == EJobs.CUSTOMER_ORG_SETUP.value:
                LOG.info(f"Failed at first JOB {EJobs.CUSTOMER_ORG_SETUP.value}. Hence updating customer status to FAILED")
                update_customers_table(client=self._client, name=self._payload[ENTITY_ID], status="FAILED")
            elif self._payload[OPERATION] == EOperations.NEW_CUSTOMER_ONBOARD.value:
                LOG.info(f"Operation {EOperations.NEW_CUSTOMER_ONBOARD.value} failed but org is created in HSDP. Hence updating customer status to PARTIALLY COMPLETE")
                update_customers_table(client=self._client, name=self._payload[ENTITY_ID], status="PARTIALLY COMPLETE")
            else:
                check_for_parallel_transactions_and_update_customer_status(customer_name=self._payload[ENTITY_ID], status="IDLE", client=self._client)
        except Exception as e:
            LOG.exception(f"Exception occured while updating the data in database in FAILED Job.: {e}")
