"""
 Created on Mon Aug 1 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import unittest
from unittest.mock import patch

from src.services.mfa_org_policy_services import MfaOrgPolicyServices


class TestUserServices(unittest.TestCase):
    @patch("src.services.mfa_org_policy_services.get_profile_data", side_effect=lambda: json.loads(
        json.dumps({"HSDP_IAM_URL": "org_infra_uuid", "PARENT_ORG_ID": "test1", "PARENT_SERVICE_AUTH_ISSUER": "111", "PARENT_SERVICE_AUTH_PRIVATE_KEY": "xyz"})))
    @patch("src.services.mfa_org_policy_services.get_path_specific_vault_values", side_effect=lambda iam_url: None)
    def test_populate_service_token(self, m_profile, m_vault_value):
        body = {"org_hsdp_id": "orgid"}
        mfa_org_policy_services = MfaOrgPolicyServices(customer_name="customer_name", service_user_uuid="1234abc", customer_org_uuid="xyz", service_user_token="1234")
        with self.assertRaises(Exception):
            mfa_org_policy_services.populate_customer_service_tokens()

        mfa_org_policy_services._profile_configs["HSDP_IDM_URL"] = "iam/url"
        mfa_org_policy_services.service_token = "1234"
        mfa_org_policy_services.request = body
        req_detail = mfa_org_policy_services.create_mfa_invoke_param()
        self.assertIsNotNone(req_detail)

        result, result_code = mfa_org_policy_services.add_mfa_policy(url="test.url.com", body={"org_name": "xyx"}, header={"Authorization": ""})
        self.assertEqual(result, False)
        self.assertEqual(result_code, 500)

        mfa_org_policy_services._profile_configs = True
        mfa_org_policy_services.safe_audit(event_subtype="Add mfaOrgPolicy", action="C", outcome=0, code="Add mfaOrgPolicy post operation", value="failure")

        m_profile.assert_called()
        m_vault_value.assert_called()

    def test_initialize_mfa_org_policy(self):
        with self.assertRaises(Exception):
            MfaOrgPolicyServices(customer_name="customer_name", service_user_uuid="1234abc", customer_org_uuid="xyz", service_user_token="1234")
