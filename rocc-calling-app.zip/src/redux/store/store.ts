/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import thunk from "redux-thunk"
import rootReducer from "../reducers/rootReducer"
import globalStore from "./globalStore"
import { persistStore, persistReducer } from "redux-persist"
import storageSession from "redux-persist/lib/storage/session"
import hardSet from "redux-persist/lib/stateReconciler/hardSet"
import { APP_NAME, STORAGE_KEY } from "../../constants/constants"
import { IStore } from "../interfaces/types"
import { Store } from "redux"
import { GLOBAL_SET_INITIATE_PHONE_CALL, GLOBAL_SET_INITIATE_WEB_CALL } from "../actions/types"

const persistConfig = {
    key: `${APP_NAME}_${STORAGE_KEY}`,
    storage: storageSession,
    stateReconciler: hardSet,
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store: Store<IStore> = globalStore.CreateStore(APP_NAME, persistedReducer, [thunk], [
    GLOBAL_SET_INITIATE_WEB_CALL,
    GLOBAL_SET_INITIATE_PHONE_CALL,
])

export const persistor = persistStore(store)

export default store
