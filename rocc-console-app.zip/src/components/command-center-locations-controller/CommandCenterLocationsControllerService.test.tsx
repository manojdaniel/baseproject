/*
 * Created on Mon Nov 22 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { fetchCommandCenterService, fetchReceiversForASeatService } from "./CommandCenterLocationsControllerService"

describe("CommandCenterLocationsControllerService", () => {
    it("should fetch CommandCenterService", () => {
        const res = fetchCommandCenterService(1)
        expect(res).toBeTruthy()
        
    })
    it("should  fetch ReceiversForASeatService", () => {
        const res = fetchReceiversForASeatService("1", "PHSEAT01")
        expect(res).toBeTruthy()
        
    })
})
