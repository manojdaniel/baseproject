/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { ForgotPassword, IForgotPasswordWrapper } from "@rocc/rocc-authentication-components"
import React from "react"
import { getFullApplicationName } from "../../utility/helpers/helpers"
import { forgotPasswordService } from "../../services/authentication/AuthenticationService"

const ForgotPasswordComponent = () => {
    const forgotPasswordHandler = async (props: IForgotPasswordWrapper) => {
        const response = await forgotPasswordService(props)
        return response
    }
    return (
        <ForgotPassword forgotPasswordHandler={forgotPasswordHandler} applicationName={getFullApplicationName()} />
    )
}
export default ForgotPasswordComponent
