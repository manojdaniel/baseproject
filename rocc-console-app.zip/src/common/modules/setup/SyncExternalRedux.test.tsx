/*
 * Created on Mon Aug 30 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EAppStates } from "@rocc/rocc-client-services"
import { mount } from "enzyme"
import React from "react"
import SyncExternalRedux from "./SyncExternalRedux"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            userReducer: {
                currentUser: {},
                appState: EAppStates.INIT
            },
            customerReducer: {
                orgId: "123",
                metaData: {
                    name: "testName",
                    orgId: ""
                },
                locations: [],
                rooms: [],
                permissions: {},
            },
            featureFlagsReducer: {
                featureFlags: []
            },
            modalReducer: {
                notificationMessage: {},
                notificationModal: {},
            },
            appReducer: {
                activeTabIndex: -1,
                sideBar: {
                    displayLeftSidePanel: false,
                    displayRightSidePanel: false,
                    desktopFullScreen: false,
                }
            },
            clientStatusReducer: {
                applicationConnectionState: true
            },
            workflowReducer: {
                workflows: []
            },
        },
        CC_CALLING: {
            callReducer: {
                videoCallStatus: [{ callStatus: "idle", contextId: "" }],
                callDetails: {
                    connectedCallDetails: {
                        participants: []
                    }
                }
            }
        }
    }),
    DispatchAction: jest.fn(),
    SubscribeToPartnerState: jest.fn(),
    GetPartnerState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {}
        }
    }),
}))

jest.mock("react-redux", () => ({
    useDispatch: () => jest.fn()
}))

describe("SyncExternalRedux tests", () => {
    it("should render the fragment", () => {
        const wrapper = mount(<SyncExternalRedux />)
        expect(wrapper.find("Fragment")).toBeDefined()
    })
})
