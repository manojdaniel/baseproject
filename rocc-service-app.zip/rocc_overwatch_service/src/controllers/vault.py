"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask import request, g
from flask_restful import Resource, reqparse

from src.constants.constants import API_VERSION
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.services.config_services import ConfigService
from src.utility.utility import construct_negative_response

LOG = create_logger("Vault controller")


class Vault(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("key", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("value", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("redis_path", type=str, required=False)

    def put(self, vault_path):
        try:
            api_version = request.headers[API_VERSION]
            if api_version != "1.0.0":
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        body = Vault.parser.parse_args()
        try:
            config_service = ConfigService(vault_path=vault_path,
                                           service_user_uuid=g.userdetails)
            redis_path = None
            if body["redis_path"] and body["redis_path"].lower() != "na":
                redis_path = "AuthCredentials" if body["redis_path"].lower() == "global" else body["redis_path"]
            response = config_service.update_config_data(key=body["key"], value=body["value"], redis_path=redis_path)
            return response
        except RoccException as ex:
            LOG.exception(f"Failed to parse the config data response with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title,
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to parse the config data response with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to update config data, please contact administrator"), 500

    def get(self, vault_path):
        try:
            api_version = request.headers[API_VERSION]
            if api_version != "1.0.0":
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            config_service = ConfigService(vault_path=vault_path,
                                           service_user_uuid=g.userdetails)
            response = config_service.fetch_config_data_for_path()
            return response
        except RoccException as ex:
            LOG.exception(f"Failed to parse the config data response with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title,
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to parse the config data response with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to fetch data, please contact administrator"), 500
