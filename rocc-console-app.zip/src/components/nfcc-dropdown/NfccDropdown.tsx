/*
 * Created on Wed Nov 24 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { getIntlProvider } from "@rocc/rocc-global-components"
import { EModalityConnectionMode, EModalitySubConnectionMode, IConnectionSpecification } from "@rocc/rocc-rconnect-common-js-sdk"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { Dropdown, Icon } from "semantic-ui-react"
import en from "../../resources/translations/en-US"
import styles from "./NfccDropdown.scss"

interface INfccDropdown {
    text: any
    showMenu: boolean
    commandCenterDetails: IConnectionSpecification | null   //ICommandCenterDetails | IConnectionSpecification | null
    featureFlags: any
    handleClick: (connectionMode: EModalityConnectionMode, subConnectionMode: EModalitySubConnectionMode | null) => void
}

const NfccDropdown = (props: INfccDropdown) => {

    const { text, commandCenterDetails, featureFlags, handleClick } = props
    const [dropdownOptions, setDropdownOptions] = useState([] as any)
    const { intl } = getIntlProvider()
    const labelFixedCC = intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] })
    const labelNonFixedCC = intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] })

    useEffect(() => {
        const updatedDropdownOptions = []
        if(!commandCenterDetails) return
        if (commandCenterDetails.connectionMode == EModalityConnectionMode.KVM) {
            if (commandCenterDetails.subConnectionMode.includes(EModalitySubConnectionMode.CC)) {
                const optionDetail = {
                    key: commandCenterDetails.connectionMode,
                    value: EModalitySubConnectionMode.CC,
                    content: <>
                        <Icon className={cx("About", "emeraldIcon")} />
                        <span>{intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] })}</span>
                    </>,
                    onClick: () => handleClick(commandCenterDetails.connectionMode, EModalitySubConnectionMode.CC),
                    text: labelFixedCC,
                    selected: false
                }
                updatedDropdownOptions.push(optionDetail)

            }
            if (commandCenterDetails.connectionMode == EModalityConnectionMode.KVM) {
                if (commandCenterDetails.subConnectionMode.includes(EModalitySubConnectionMode.EMERALD)) {
                    const optionDetail = {
                        key: EModalitySubConnectionMode.CC,
                        value: EModalitySubConnectionMode.EMERALD,
                        content: <>
                            <Icon className={cx("LinkExternal", "emeraldIcon")} />
                            <span>{intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] })}</span>
                        </>,
                        onClick: () => handleClick(commandCenterDetails.connectionMode, EModalitySubConnectionMode.EMERALD),
                        text: labelNonFixedCC,
                        selected: false
                    }
                    updatedDropdownOptions.push(optionDetail)
                }
            }
        }else{
            const optionDetail = {
                key: commandCenterDetails.connectionMode,
                value: commandCenterDetails.connectionMode,
                content: <>
                    <Icon className={cx("LinkExternal", "emeraldIcon")} />
                    <span>{intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] })}</span>
                </>,
                onClick: () => handleClick(commandCenterDetails.connectionMode, null),
                text: labelNonFixedCC,
                selected: false
            }
            updatedDropdownOptions.push(optionDetail)
        }
        setDropdownOptions(updatedDropdownOptions)
    }, [commandCenterDetails, featureFlags])

    return (
        <Dropdown
            item
            text={text}
            options={dropdownOptions}
            className={styles.nfccDropdown}
        />
    )
}

export default NfccDropdown
