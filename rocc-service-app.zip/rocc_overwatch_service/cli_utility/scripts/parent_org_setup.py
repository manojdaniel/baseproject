"""
 Created on Thu Nov 19 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
from src.modules.parent_org_setup.communication_region_config_setup import RegionConfigSetup
import time
from cli_utility.scripts.utility import fetch_config_value, fetch_profile_configs_for_cli, prompt_and_get_rocc_url
from src.constants.config_keys import VAULT_PARENT_APP_NAME, VAULT_PARENT_AUTH_SERVICE_NAME, VAULT_PARENT_OAUTH_CLIENT_ID, VAULT_PARENT_OAUTH_NAME, \
    VAULT_PARENT_OAUTH_PASSWORD, VAULT_PARENT_POLICY_NAME, VAULT_PARENT_PROPOSITION_NAME
from src.constants.constants import ENV, ROCC_PROXY_URL, SEP
from src.loggers.log import create_logger
from src.modules.parent_org_setup.parent_org_infra_setup import ParentOrgInfraSetup
from src.modules.parent_org_setup.rbac_infra_setup import RBACInfraSetup
from src.utility.utility import generate_random_string, generate_random_string_with_special_character
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import post_vault_values_for_path

LOG = create_logger("ParentOrgSetup")
BACKUP_FILE = f"cli_utility/output/back_up_ignore_.txt"


def check_and_update_vault(profile_configs):
    env = fetch_config_value(ENV)
    file_handler = open(BACKUP_FILE, "+a")
    file_handler.write(f"Starting the backup at: {time.ctime(time.time())}\n")
    file_handler.write(f"Backed up - profile_configs: \n{profile_configs}\n")
    profile_configs[VAULT_PARENT_AUTH_SERVICE_NAME] = generate_random_string(inp=f"{env}ASN", length=8)
    profile_configs[VAULT_PARENT_PROPOSITION_NAME] = generate_random_string(inp=f"{env}PROP", length=8)
    profile_configs[VAULT_PARENT_APP_NAME] = generate_random_string(inp=f"{env}APP", length=8)
    profile_configs[VAULT_PARENT_POLICY_NAME] = generate_random_string(inp=f"{env}PLCY", length=8)
    profile_configs[VAULT_PARENT_OAUTH_CLIENT_ID] = generate_random_string(inp=f"{env}OACID", length=16)
    profile_configs[VAULT_PARENT_OAUTH_PASSWORD] = generate_random_string_with_special_character(inp=f"{env}OACPWD",
                                                                                                 length=16,
                                                                                                 special_characters_set=["-", "@", "?"])
    profile_configs[VAULT_PARENT_OAUTH_NAME] = generate_random_string(inp=f"{env}OACNAME", length=16)
    file_handler.write(f"\n{SEP}\n")
    file_handler.close()
    return profile_configs


OVERWRITE_MSG = f"""
{SEP}{SEP}{SEP}{SEP}\n\n
CAUTION: This script will create a new Proposition, application, parent level policies etc. Proceed with caution!!!
\n{SEP}\nDo you want to continue ? [Yes]"""

POLICY_PROMPT = f"""\nDo you want to also create policies for Parent org?\n
Note: This will create 7 new polices for parent org, it is recommended to run this only on a new environment
{SEP}{SEP}\nType 'create' to create new policies [create/no]: """


def compute_default_configs():
    policy_create = False
    profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
    if profile_configs and vault_credentials_response:
        response = input(OVERWRITE_MSG)
        proceed = True if response.lower() == "yes" else False
        if not proceed:
            LOG.warn("Exiting parent org setup !")
            exit(0)
        policy_response = input(POLICY_PROMPT)
        policy_create = True if policy_response.lower() == "create" else False
        profile_configs = check_and_update_vault(profile_configs)
        LOG.warn(f"Adding parent org configs in Vault path: {profile_path}")
        post_vault_values_for_path(path=profile_path,
                                   body=profile_configs,
                                   vault_credentials_response=vault_credentials_response)

    return profile_configs, vault_credentials_response, policy_create


def task_parent_org_setup(profile_configs, url, vault_credentials_response, policy_create, user_details):
    ob = ParentOrgInfraSetup()
    status = ob.start_job(profile_configs=profile_configs,
                          rocc_proxy_url=url,
                          vault_credentials_response=vault_credentials_response,
                          policy_create=policy_create, user_details=user_details)
    return status


def task_rbac_infra_setup(profile_configs, url, vault_credentials_response, user_details):
    ob = RBACInfraSetup()
    status = ob.start_job(profile_configs=profile_configs,
                          rocc_proxy_url=url,
                          vault_credentials_response=vault_credentials_response, user_details=user_details)
    return status


def task_region_config_setup(profile_configs, url, user_details):
    ob = RegionConfigSetup()
    status = ob.start_job(profile_configs=profile_configs,
                          rocc_proxy_url=url,
                          user_details=user_details)
    return status


def setup_parent_org(user_details):
    success = False
    profile_configs, vault_credentials_response, policy_create = compute_default_configs()
    if profile_configs:
        url = prompt_and_get_rocc_url()
        os.environ[ROCC_PROXY_URL] = url
        parent_org_setup_status = task_parent_org_setup(profile_configs,
                                                        url,
                                                        vault_credentials_response=vault_credentials_response,
                                                        policy_create=policy_create,
                                                        user_details=user_details)
        if parent_org_setup_status:
            profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
            rbac_infra_setup_status = task_rbac_infra_setup(profile_configs, url, vault_credentials_response=vault_credentials_response, user_details=user_details)
            region_config_setup_status = task_region_config_setup(profile_configs, url, user_details=user_details)
            if rbac_infra_setup_status and region_config_setup_status:
                success = True
    if success:
        LOG.info(f"Parent org setup completed successfully\n{SEP}")
    else:
        LOG.error(f"Parent org setup failed !\n{SEP}")
