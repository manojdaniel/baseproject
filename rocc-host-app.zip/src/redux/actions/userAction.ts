/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { getContactsRelevantForCurrentUserTransformer, parseIntBase10, EClinicalRole, IUserInfo, EResponse, IContactInfo, EAppStates, IParentStore, IUserPermissions, IUrls, EAppContext, NFCC_BUNDLE_NOT_INSTALLED, NFCC_BUNDLE, DownloadUtility } from "@rocc/rocc-client-services"
import { AnyAction, Dispatch } from "redux"
import { updatePresenceService } from "../../common/presence/presenceService"
import { LOGOUT_ROUTE } from "../../constants/routes"
import { initializeFeatureFlagClient } from "../../utility/feature-flags/featureFlag"
import { cleanUpTasks, cacheCleaner, filterCurrentUserFromContacts, loginErrorMessages, sendActiveConsoleEndLog, cctvClose, getPreSignedUrls, getAnywhereLocationNameText } from "../../utility/helpers/helpers"
import { errorLogger, errorParser, flushBufferedLogs } from "@rocc/rocc-logging-module"
import { getMetasiteIdForCustomer, getCurrentUserInfoService, fetchContactsRelevantToCurrentUserService, subscribeToCurrentUserBundleInfos } from "../services/userServices"
import {
    SET_USER_DETAILS_STATE, GLOBAL_FORCE_CLEAN_UP, SET_APPSTATE, UPDATE_CURRENT_USER, SET_USER_DETAILS, RENDER_ONBOARDING, SET_SESSION_DETAILS, UPDATE_ONBOARDING_STATUS,
    EXPERTUSER_LOGOUT_RESPONSE, LOGOUT, FETCH_CONTACTS, GLOBAL_REFRESH_TOKEN, SET_USER_DETAILS_FAILURE, UPDATE_PRESENCE, UPDATE_SELF_PRESENCE, ROOM_MONITORING_WINDOW, SET_PERMISSIONS, UPDATE_NFCC_UPGRADE_AVAILABLE
} from "./types"
import { displayLoginErrorMessages, NFCC_BUNDLE_VERSION, TRUE } from "../../constants/constants"
import { updatePresignedUrls } from "./configActions"
import { isEmpty } from "lodash"
import { roccHttpClient } from "../../utility/api/apiUtility"

const { REQUEST_PROCESSING_FAILED, DEFAULT_MESSAGE } = displayLoginErrorMessages

export const getCurrentUserInfo = (userEmail: string, uuid: string) => async (dispatch: any, getState: any) => {
    dispatch({ type: SET_USER_DETAILS_STATE, userState: EResponse.INIT })
    await populateUserInfo(userEmail, uuid, dispatch, getState)
}

export const setForceCleanUp = (forceCleanUp: boolean) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_FORCE_CLEAN_UP, forceCleanUp })
}
export const setCurrentAppState = (appState: EAppStates) => (dispatch: any) => {
    dispatch({ type: SET_APPSTATE, appState })
}

export const updateRefreshToken = (refreshAccessToken: string, expiryTime: string) => (dispatch: Dispatch) => {
    dispatch({ type: GLOBAL_REFRESH_TOKEN, refreshAccessToken, expiryTime })
}

export const updateMetasiteIdForCurrentUser = (customerName: string, clinicalRole: EClinicalRole) => async (dispatch: Dispatch, getState: any) => {
    const state: IParentStore = getState()
    const currentUser = state.userReducer.currentUser
    const metasiteId = await getMetasiteIdForCustomer(customerName)
    dispatch({ type: UPDATE_CURRENT_USER, currentUser: { ...currentUser, orgId: metasiteId, clinicalRole, onBoarded: true, allRoles: [clinicalRole] } })
}

export const updateAccessToken = (token: string, sessionId: string, currentUser: IUserInfo, dispatch: Dispatch) => {
    dispatch({ type: UPDATE_CURRENT_USER, currentUser: { ...currentUser, accessToken: token, sessionId } })
}

const populateUserInfo = async (userEmail: string, uuid: string, dispatch: Dispatch, getState: any) => {
    const prevState: IParentStore = getState()
    const { configs, urls } = prevState.configReducer
    const ffConfig = prevState.featureFlagsReducer.featureFlagConfig.provider
    const defaultFeatureFlags = prevState.featureFlagsReducer.defaultFeatureFlags
    const prevCurrentUserDetails = prevState.userReducer.currentUser
    try {
        const { currentUser, orgIdentifier } = await getCurrentUserInfoService(userEmail, uuid, prevCurrentUserDetails)
        initializeFeatureFlagClient({
            currentUser,
            defaultFeatureFlags,
            dispatch,
            ffConfig,
            orgIdentifier,
            urls,
        })
        dispatch({ type: SET_USER_DETAILS, userInfo: currentUser, userState: EResponse.SUCCESS, loginMessage: "" })
        if (currentUser && currentUser.orgId === "") {
            dispatch({ type: RENDER_ONBOARDING, unauthorised: true, appState: EAppStates.FF_SETUP })
        } else {
            setAppStateToFFSetup(dispatch, getState)
        }
    } catch (error: any) {
        if (error.response && error.response.data) {
            const errorMessage = (error.response.data.defaultMessage && configs.CUSTOMER_ANALYTICS_LOG_CONSENT) ?
                loginErrorMessages(DEFAULT_MESSAGE) : loginErrorMessages(REQUEST_PROCESSING_FAILED)
            dispatch({ type: SET_USER_DETAILS_FAILURE, userState: EResponse.ERROR, appState: EAppStates.LOGIN_FAILED, errorMessage })
        }
        errorLogger(`Failed to compute post login activities with error: ${errorParser(error)}`)
    }
}

export const setSessionDetails = (sessionDetails: any) => (dispatch: Dispatch) => {
    dispatch({ type: SET_SESSION_DETAILS, sessionDetails })
}

export const logout = (postTransactionHook: () => void, postLogoutRoute: string = LOGOUT_ROUTE) => async (dispatch: Dispatch, getState: any) => {
    const store: IParentStore = getState()
    try {
        sendActiveConsoleEndLog()
        flushBufferedLogs()
        const expertUserTransitionState = await cleanUpTasks(store.userReducer.currentUser, store.configReducer.urls)
        dispatch({ type: ROOM_MONITORING_WINDOW, roomMonitoringWindow: false })
        dispatch({ type: EXPERTUSER_LOGOUT_RESPONSE, expertUserTransitionState })
        cctvClose()
    } catch (ex) {
        errorLogger(`Failed to logout...... : ${errorParser(ex)}`)
    } finally {
        postTransactionHook()
        cacheCleaner(true)
        dispatch({ type: LOGOUT })
        window.location.hash = postLogoutRoute
        window.location.reload()
    }
}

export const updateOnBoardingStatus = (state: boolean, uuid: string) => (dispatch: any, getState: any) => {
    const prevState = getState()
    const {
        currentUser,
    } = prevState.userReducer
    const updatedCurrentUser: IUserInfo = currentUser
    updatedCurrentUser.onBoarded = state
    updatedCurrentUser.uuid = uuid
    dispatch({ type: UPDATE_ONBOARDING_STATUS, currentUser: updatedCurrentUser })
}

export const fetchContacts = (userInfo: IUserInfo, limit: number) => (dispatch: any, getState: any) => {
    const { id } = userInfo
    try {
        const state: IParentStore = getState()
        if (state.appReducer.appContext === EAppContext.PRE_SIGNED) {
            dispatch({ type: FETCH_CONTACTS, contacts: [], contactsFetched: true })
            return
        }
        fetchContactsRelevantToCurrentUserService(parseIntBase10(id), limit)
            .subscribe((result: any) => {
                if (result.error) {
                    errorLogger(`Exception occured while fetching Contact Information: ${result.error}`)
                    dispatch({ type: FETCH_CONTACTS, contactsFetched: false })
                } else if (result.data) {
                    const prevState: IParentStore = getState()
                    const contacts = prevState.userReducer.contacts
                    let data = getContactsRelevantForCurrentUserTransformer(result.data.employees, contacts)
                    data = filterCurrentUserFromContacts(data, userInfo)

                    dispatch({ type: FETCH_CONTACTS, contacts: data, contactsFetched: true })
                }
            })
    } catch (error) {
        errorLogger(`Exception occured while fetching Contact Information:  ${errorParser(error)}`)
        dispatch({ type: FETCH_CONTACTS, contactsFetched: false })
    }
}


const setAppStateToFFSetup = (dispatch: Dispatch, getState: any) => {
    const currentAppState = getState().userReducer.appState
    if (currentAppState !== EAppStates.READY) {
        dispatch({ type: SET_APPSTATE, appState: EAppStates.FF_SETUP })
    }
}
export const updatePresenceForContactWithId = (uuid: string, status: EUserPresence) => (dispatch: any, getState: any) => {
    const prevState: IParentStore = getState()
    const {
        contacts,
    } = prevState.userReducer
    const updatedContactIndex = contacts.findIndex((contact: IContactInfo) => contact.uuid === uuid)
    if (updatedContactIndex > -1) {
        const updatedContacts = contacts.splice(0)
        updatedContacts[updatedContactIndex].status = status
        dispatch({ type: UPDATE_PRESENCE, contacts: updatedContacts })
    }
}

export const updateAllContactsPresence = (contacts: IContactInfo[]) => (dispatch: Dispatch) => {
    contacts = contacts.map(contact => {
        if (!contact.loggedInLocation && contact.status !== EUserPresence.OFFLINE) {
            contact.loggedInLocation = getAnywhereLocationNameText()
        }
        return contact
    })

    dispatch({ type: UPDATE_PRESENCE, contacts })
}

export const updateCurrentUserPresence = (status: EUserPresence, isInit: boolean = false, isLocationUpdated: boolean = false) => async (dispatch: any, getState: any) => {
    const prevState: IParentStore = getState()
    const { currentUser } = prevState.userReducer
    let { loggedInLocation } = prevState.userReducer.currentUser
    const { COMMUNICATION_SERVICES_URL } = prevState.configReducer.urls
    loggedInLocation = (status !== EUserPresence.OFFLINE && isEmpty(loggedInLocation)) ? getAnywhereLocationNameText() : loggedInLocation
    await updatePresenceService(currentUser, status, COMMUNICATION_SERVICES_URL, currentUser.uuid, loggedInLocation, isInit, isLocationUpdated)
    dispatch({ type: UPDATE_SELF_PRESENCE, status })
}

export const updateAppState = (appState: EAppStates, userState: EResponse, errorMessage: string) => (dispatch: Dispatch) => {
    dispatch({ type: SET_USER_DETAILS_FAILURE, userState, appState, errorMessage })
}

export const setPermissionlist = (permissions: IUserPermissions) => (dispatch: Dispatch) => {
    dispatch({ type: SET_PERMISSIONS, permissions })
}

export const fetchBundleUpdateNotification = (currentUser: IUserInfo, urls: IUrls) => (dispatch: Dispatch) => {
    let isSubscriptionStarted = false
    try {
        subscribeToCurrentUserBundleInfos(parseIntBase10(currentUser.id), NFCC_BUNDLE).subscribe(async (result: any) => {
            if (result.error) {
                errorLogger(`Error while getting user bundle data ${errorParser(result.error)}`)
            } else if (result.data.bundle_infos.length > 0) {
                if (!localStorage.getItem(NFCC_BUNDLE_VERSION)) {
                    sessionStorage.removeItem(NFCC_BUNDLE_NOT_INSTALLED)
                    localStorage.setItem(NFCC_BUNDLE_VERSION, result.data.bundle_infos[0].version)
                }
                isSubscriptionStarted && localStorage.setItem(NFCC_BUNDLE_VERSION, result.data.bundle_infos[0].version)
                checkIfLatestNFCCVersionExists(currentUser, urls, dispatch)
            }
            else {
                //If 2 EU uses same machine
                if (!localStorage.getItem(NFCC_BUNDLE_VERSION)) {
                    sessionStorage.setItem(NFCC_BUNDLE_NOT_INSTALLED, TRUE)
                }
                else {
                    checkIfLatestNFCCVersionExists(currentUser, urls, dispatch)
                }
            }
            isSubscriptionStarted = true
        })
    } catch (error) {
        errorLogger(`Error while getting user bundle infos ${errorParser(error)}`)
    }
}

export const checkIfLatestNFCCVersionExists = async (currentUser: IUserInfo, urls: IUrls, dispatch: Dispatch<AnyAction>) => {
    const { url, version: latestVersion, mandatory } = await DownloadUtility.getPresignedUrl(roccHttpClient, currentUser.accessToken, urls.MANAGEMENT_SERVICE_URL, NFCC_BUNDLE)
    const preSignedUrls = getPreSignedUrls()
    preSignedUrls.nfccBundle.createdAt = new Date()
    preSignedUrls.nfccBundle.url = url
    preSignedUrls.nfccBundle.version = latestVersion
    preSignedUrls.nfccBundle.mandatory = mandatory
    updatePresignedUrls(getPreSignedUrls())

    const isLatestVesrionExists = (latestVersion === localStorage.getItem(NFCC_BUNDLE_VERSION))
    dispatch({ type: UPDATE_NFCC_UPGRADE_AVAILABLE, nfccUpgradeAvailable: !isLatestVesrionExists })
}
