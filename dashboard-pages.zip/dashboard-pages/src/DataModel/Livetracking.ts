export const livetrackingtableData = [
  {
    "timeStamp": "2023-03-29T23:32:48",
    "modelName": "Compressor Performance",
    "status": "Alert",
    "sensorGroupId": 955,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor3": "Motor Current 231II400",
    "influencingSensor4": "CG Discharge Pressure 231PI496",
    "influencingSensor5": "CG Discharge Temp 231TI408",
    "influencingSensor6": "CG Flow 231FI423B",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:32:45",
    "modelName": "Compressor Seal Gas Performance",
    "status": "Alert",
    "sensorGroupId": 957,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "Seal Gas Vent To Flare 231FI414",
    "influencingSensor3": "CG Discharge Pressure 231PI496",
    "influencingSensor4": "CG Suction Pressure 231PI495",
    "influencingSensor5": "CG Seal Gas DP 231PDI417",
    "influencingSensor6": "N/A",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:19:01",
    "modelName": "Compressor Performance_FE",
    "status": "Alert",
    "sensorGroupId": 2881,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "2K_3101_Polytropic_Head_Analysis_Output",
    "influencingSensor3": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor4": "2K_3101_Polytropic_Efficiency_Analysis_Output",
    "influencingSensor5": "2K_3101_Work_Analysis_Output",
    "influencingSensor6": "2K_3101_Stage_Power_Analysis_Output",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:19",
    "modelName": "Compressor Thrust Bearing",
    "status": "Alert",
    "sensorGroupId": 958,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "CG Lube Oil Pressure 231PI497",
    "influencingSensor3": "Comp Inactive Thrust Bearing 231TI475A",
    "influencingSensor4": "Comp Inactive Thrust Bearing 231TI475B",
    "influencingSensor5": "Comp Shaft Axial Pos 231ZI472BB",
    "influencingSensor6": "Comp Active Thrust Bearing 231TI475F",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:13",
    "modelName": "Compressor Journal Bearing",
    "status": "Alert",
    "sensorGroupId": 956,
    "influencingSensor1": "Comp Shaft Y-Axis 231VI474B",
    "influencingSensor2": "Comp Shaft X-Axis 231VI474A",
    "influencingSensor3": "CG Suction Pressure 231PI495",
    "influencingSensor4": "CG Lube Oil Pressure 231PI497",
    "influencingSensor5": "Comp Inboard Journal Bearing 231TI476A",
    "influencingSensor6": "CG Lube Oil Pressure 231PI489",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:10",
    "modelName": "Motor Journal Bearing",
    "status": "Alert",
    "sensorGroupId": 954,
    "influencingSensor1": "Motor Shaft X-Axis 231VI476A",
    "influencingSensor2": "Motor Shaft Y-Axis 231VI476B",
    "influencingSensor3": "Motor Shaft X-Axis 231VI475A",
    "influencingSensor4": "Motor Shaft Y-Axis 231VI475B",
    "influencingSensor5": "CG Lube Oil Pressure 231PI497",
    "influencingSensor6": "Motor Bearing Temp 1 231TI409",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:04",
    "modelName": "Compressor Performance",
    "status": "Alert",
    "sensorGroupId": 955,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor3": "CG Discharge Pressure 231PI496",
    "influencingSensor4": "CG DP 231PDI450",
    "influencingSensor5": "CG Discharge Temp 231TI408",
    "influencingSensor6": "CG Suction Pressure 231PI495",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:04",
    "modelName": "Compressor Seal Gas Performance",
    "status": "Alert",
    "sensorGroupId": 957,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "Seal Gas Vent To Flare 231FI414",
    "influencingSensor3": "CG Suction Pressure 231PI495",
    "influencingSensor4": "CG Discharge Pressure 231PI496",
    "influencingSensor5": "CG Seal Gas DP 231PDI417",
    "influencingSensor6": "N/A",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:03:08",
    "modelName": "Compressor Performance_FE",
    "status": "Alert",
    "sensorGroupId": 2881,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "2K_3101_Polytropic_Head_Analysis_Output",
    "influencingSensor3": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor4": "2K_3101_Polytropic_Efficiency_Analysis_Output",
    "influencingSensor5": "CG Discharge Pressure 231PI496",
    "influencingSensor6": "2K_3101_Work_Analysis_Output",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:02:42",
    "modelName": "Compressor Thrust Bearing",
    "status": "Alert",
    "sensorGroupId": 958,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "CG Lube Oil Pressure 231PI497",
    "influencingSensor3": "Comp Inactive Thrust Bearing 231TI475A",
    "influencingSensor4": "Comp Inactive Thrust Bearing 231TI475B",
    "influencingSensor5": "Comp Shaft Axial Pos 231ZI472BB",
    "influencingSensor6": "Comp Active Thrust Bearing 231TI475F",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
   {
    "timeStamp": "2023-03-29T23:32:48",
    "modelName": "Compressor Performance",
    "status": "Alert",
    "sensorGroupId": 955,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor3": "Motor Current 231II400",
    "influencingSensor4": "CG Discharge Pressure 231PI496",
    "influencingSensor5": "CG Discharge Temp 231TI408",
    "influencingSensor6": "CG Flow 231FI423B",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:32:45",
    "modelName": "Compressor Seal Gas Performance",
    "status": "Alert",
    "sensorGroupId": 957,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "Seal Gas Vent To Flare 231FI414",
    "influencingSensor3": "CG Discharge Pressure 231PI496",
    "influencingSensor4": "CG Suction Pressure 231PI495",
    "influencingSensor5": "CG Seal Gas DP 231PDI417",
    "influencingSensor6": "N/A",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:19:01",
    "modelName": "Compressor Performance_FE",
    "status": "Alert",
    "sensorGroupId": 2881,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "2K_3101_Polytropic_Head_Analysis_Output",
    "influencingSensor3": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor4": "2K_3101_Polytropic_Efficiency_Analysis_Output",
    "influencingSensor5": "2K_3101_Work_Analysis_Output",
    "influencingSensor6": "2K_3101_Stage_Power_Analysis_Output",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:19",
    "modelName": "Compressor Thrust Bearing",
    "status": "Alert",
    "sensorGroupId": 958,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "CG Lube Oil Pressure 231PI497",
    "influencingSensor3": "Comp Inactive Thrust Bearing 231TI475A",
    "influencingSensor4": "Comp Inactive Thrust Bearing 231TI475B",
    "influencingSensor5": "Comp Shaft Axial Pos 231ZI472BB",
    "influencingSensor6": "Comp Active Thrust Bearing 231TI475F",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:13",
    "modelName": "Compressor Journal Bearing",
    "status": "Alert",
    "sensorGroupId": 956,
    "influencingSensor1": "Comp Shaft Y-Axis 231VI474B",
    "influencingSensor2": "Comp Shaft X-Axis 231VI474A",
    "influencingSensor3": "CG Suction Pressure 231PI495",
    "influencingSensor4": "CG Lube Oil Pressure 231PI497",
    "influencingSensor5": "Comp Inboard Journal Bearing 231TI476A",
    "influencingSensor6": "CG Lube Oil Pressure 231PI489",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:10",
    "modelName": "Motor Journal Bearing",
    "status": "Alert",
    "sensorGroupId": 954,
    "influencingSensor1": "Motor Shaft X-Axis 231VI476A",
    "influencingSensor2": "Motor Shaft Y-Axis 231VI476B",
    "influencingSensor3": "Motor Shaft X-Axis 231VI475A",
    "influencingSensor4": "Motor Shaft Y-Axis 231VI475B",
    "influencingSensor5": "CG Lube Oil Pressure 231PI497",
    "influencingSensor6": "Motor Bearing Temp 1 231TI409",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:04",
    "modelName": "Compressor Performance",
    "status": "Alert",
    "sensorGroupId": 955,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor3": "CG Discharge Pressure 231PI496",
    "influencingSensor4": "CG DP 231PDI450",
    "influencingSensor5": "CG Discharge Temp 231TI408",
    "influencingSensor6": "CG Suction Pressure 231PI495",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:18:04",
    "modelName": "Compressor Seal Gas Performance",
    "status": "Alert",
    "sensorGroupId": 957,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "Seal Gas Vent To Flare 231FI414",
    "influencingSensor3": "CG Suction Pressure 231PI495",
    "influencingSensor4": "CG Discharge Pressure 231PI496",
    "influencingSensor5": "CG Seal Gas DP 231PDI417",
    "influencingSensor6": "N/A",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:03:08",
    "modelName": "Compressor Performance_FE",
    "status": "Alert",
    "sensorGroupId": 2881,
    "influencingSensor1": "CG Suction Temperature 231TI431",
    "influencingSensor2": "2K_3101_Polytropic_Head_Analysis_Output",
    "influencingSensor3": "H2 Flow To Cycle Gas 231FC410",
    "influencingSensor4": "2K_3101_Polytropic_Efficiency_Analysis_Output",
    "influencingSensor5": "CG Discharge Pressure 231PI496",
    "influencingSensor6": "2K_3101_Work_Analysis_Output",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  },
  {
    "timeStamp": "2023-03-29T07:02:42",
    "modelName": "Compressor Thrust Bearing",
    "status": "Alert",
    "sensorGroupId": 958,
    "influencingSensor1": "Comp Shaft Axial Pos 231ZI472AA",
    "influencingSensor2": "CG Lube Oil Pressure 231PI497",
    "influencingSensor3": "Comp Inactive Thrust Bearing 231TI475A",
    "influencingSensor4": "Comp Inactive Thrust Bearing 231TI475B",
    "influencingSensor5": "Comp Shaft Axial Pos 231ZI472BB",
    "influencingSensor6": "Comp Active Thrust Bearing 231TI475F",
    "influencingSensor7": "",
    "influencingSensor8": "",
    "influencingSensor9": "",
    "influencingSensor10": ""
  }
]
export const modelstatusdropdowndata = [
  {
    "status": "Alert"
  },
  {
    "status": "Asset-ON"
  },
  {
    "status": "Normal"
  },
  {
    "status": "Pi Data Disconnection"
  },
  {
    "status": "Poor Data"
  }
]
export const assetiddropdowndata = [
  {
    "assetId": "41 K101",
    "assetName": "Natural Gas Compressor"
  },
  {
    "assetId": "41 K101",
    "assetName": "Natural Gas Compressor"
  },
  {
    "assetId": "41 K701",
    "assetName": "Refrigeration Gas Compressor"
  },
  {
    "assetId": "41 K601",
    "assetName": "Syn Gas Compressor"
  },
  {
    "assetId": "41 P301A",
    "assetName": "Semi Lean Solution Pump  A"
  },
  {
    "assetId": "41 P301B",
    "assetName": "Semi Lean Solution Pump  B"
  },
  {
    "assetId": "41 P301C",
    "assetName": "Semi Lean Solution Pump  C"
  },
  {
    "assetId": "41 P302A",
    "assetName": "Lean Solution Pump A"
  },
  {
    "assetId": "41 P302B",
    "assetName": "Lean Solution Pump B"
  },
  {
    "assetId": "41-R-103",
    "assetName": "Secondary Reformer"
  },
  {
    "assetId": "42-E-201",
    "assetName": "High Pressure Stripper"
  },
  {
    "assetId": "42-E-205",
    "assetName": "High Pressure Pool Condensor"
  },
  {
    "assetId": "42-E-302",
    "assetName": "Rectifying Column Recirculation Heater"
  },
  {
    "assetId": "42 K102",
    "assetName": "CO2 Compressor Turbine"
  },
  {
    "assetId": "42 P102A",
    "assetName": "Ammonia Pump A"
  },
  {
    "assetId": "42 P102B",
    "assetName": "Ammonia Pump B"
  },
  {
    "assetId": "42 P301A",
    "assetName": "HP Carbomate Pump A"
  },
  {
    "assetId": "42 P301B",
    "assetName": "HP Carbomate Pump B"
  },
  {
    "assetId": "42-R-201",
    "assetName": "High Pressure Reactor"
  }
]