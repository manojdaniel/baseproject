/*
 * Created on Fri Oct 1 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { mount } from "enzyme"
import SyncExternalRedux from "./SyncExternalRedux"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CC_HOST: {
            userReducer: {
                currentUser: {},
                forceCleanUp: false,
            },
            customerReducer: {
                rooms: [],
                locations: [],
                activeLocationId: 0,
            },
            modalReducer: {
                notificationMessage: "",
            },
            featureFlagsReducer: {
                featureFlags: [],
            },
            appReducer: {
                sideBar: {},
                version: ""
            },
            workflowReducer: {
                workflow: [],
            },
            clientStatusReducer: {
                applicationConnectionState: "ONLINE",
            },
        },
        CC_CONSOLE: {
            consoleReducer: {
                consoleOperation: {
                    transactions: []
                },
                consoleSessions: [{
                    contextId: "contextId", roomUuid: "roomUuid", connectionMode: "EMERALD", connectionType: "VIEW",
                }]
            },
            protocolTransferReducer: {
                protocolTransferStatus: false,
                selectedSource: "",
                selectedDestination: "",
                currentStep: 0
            }
        },
        CC_CALLING: {
            callReducer: {
                phoneCallStatus: "idle",
                videoCallStatus: [],
                callDetails: {
                    connectedCallDetails: {},
                    onHoldCallDetails: [],
                }
            }
        }
    }),
    DispatchAction: jest.fn(),
    SubscribeToPartnerState: jest.fn(),
    GetPartnerState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {}
        },
        customerReducer: {
            rooms: [],
            locations: []
        }
    }),
}))

describe("SyncExternalRedux tests", () => {
    it("should render the fragment", () => {
        const wrapper = mount(<SyncExternalRedux />)
        expect(wrapper.find("Fragment")).toBeDefined()
    })
})
