/*
 * Created on Fri Sept 03 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { DEFAULT_CONTACT_INFO, ECallStatus, EClinicalRole, ERbacRole, EROCC_CONTEXT } from "@rocc/rocc-client-services"
import * as globalComponent from "@rocc/rocc-global-components"
import { CALL_MESSAGES, DEVICE_ROLE_ROOM } from "../../constants/constants"
import { IWorkflowInfo } from "../../redux/interfaces/types"
import * as externalAppStates from "../../redux/store/externalAppStates"
import {
    checkIfConsoleAvailable,
    checkIfMultiEditWithoutParkResumeFeatureEnabled,
    checkIfMultiEditWithParkResumeFeatureEnabled,
    checkIfParticipantIsGuest, fetchActiveEditSession, fetchConsoleReducer, generateInitials, getAppReducerFromGlobalStore, getConfigReducerFromGlobalStore, getCurrentUserAndUrlsReduxState, getCustomrReducerFromGlobalStore, getModalReducerFromGlobalStore, getRoleName, getSiteName, getStateValueDependency, getTranslatedCallType, getUserReducerFromGlobalStore, isAdmin, prepareIncomingCallModal, renderHTMLCd,
    sortContacts, updateCallDeafenStatus, updateCallMuteStatus
} from "./helpers"

const dispatch = jest.fn()

jest.mock("../modules/avmessages/av-messages/MessageHelper", () => ({
    onCallAccept: jest.fn(),
    onCallReject: jest.fn(),
}))

jest.mock("../../redux/store/externalAppStates")

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        callReducer: {
            callDetails: {
                connectedCallDetails: {
                    contextId: "contextId",
                    callAcceptedTime: new Date(),
                    participants: [{ uuid: "uuid" }]
                }
            },
            videoCallStatus: [{ contextId: "contextId", callStatus: "connected" }]
        },
        externalReducer: {
            featureFlags: {},
        }
    })
}))
describe("isAdmin tests", () => {
    it("should return true for admin", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            currentUser: { clinicalRole: EClinicalRole.ADMIN }
        })
        expect(isAdmin()).toBe(true)
    })

    it("should return false for expert user", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            currentUser: { clinicalRole: EClinicalRole.EXPERTUSER }
        })
        expect(isAdmin()).toBe(false)
    })
})

describe("getAppReducerFromGlobalStore tests", () => {
    it("should return appreducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            version: "1.0.0"
        })
        expect(getAppReducerFromGlobalStore().version).toBe("1.0.0")
    })
})

describe("getConfigReducerFromGlobalStore tests", () => {
    it("should return configreducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            isProxy: false
        })
        expect(getConfigReducerFromGlobalStore().isProxy).toBeFalsy()
    })
})

describe("getUserReducerFromGlobalStore tests", () => {
    it("should return userReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            userState: "test"
        })
        expect(getUserReducerFromGlobalStore().userState).toBe("test")
    })
})

describe("getCustomrReducerFromGlobalStore  tests", () => {
    it("should return customerReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            initRoomsFetched: false
        })
        expect(getCustomrReducerFromGlobalStore().initRoomsFetched).toBe(false)
    })
})

describe("getStateValueDependency  tests", () => {
    it("should return getStateValueDependency", () => {
        const workflows: IWorkflowInfo[] = []
        expect(getStateValueDependency(workflows)).toHaveLength(2)
    })
})

describe("getModalReducerFromGlobalStore  tests", () => {
    it("should return modalReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            notificationModal: {}
        })
        expect(getModalReducerFromGlobalStore().notificationModal).toStrictEqual({})
    })
})
describe("fetchConsoleReducer  tests", () => {
    it("should return consoleReducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            consoleSessions: {}
        })
        expect(fetchConsoleReducer().consoleSessions).toStrictEqual({})
    })
})

describe("sortContacts tests", () => {
    it("should able to sort by presence", () => {
        const contacts = [
            { ...DEFAULT_CONTACT_INFO, status: EUserPresence.OFFLINE, uuid: "uuid1", name: "name1" },
            { ...DEFAULT_CONTACT_INFO, status: EUserPresence.AVAILABLE, uuid: "uuid2", name: "name2" },
        ]
        expect(sortContacts(contacts)[0].name).toBe("name2")
    })
})

describe("prepareIncomingCallModal tests", () => {
    it("should return incomingModal object", () => {
        const incomingCall = {
            contextId: "contextId",
            participant: {
                ...DEFAULT_CONTACT_INFO,
                uuid: "uuid",
                name: "name",
                secondaryName: "secondaryName",
                description: "description"
            },
            requester: {
                primaryUuid: "primaryUuid",
                secondaryUuid: ["secondaryUuid"],
                callStatus: ECallStatus.RINGING,
                userContext: {}
            }
        }

        const { header } = prepareIncomingCallModal(incomingCall, EROCC_CONTEXT.DESKTOP, () => { "" }, dispatch)
        expect(header).toBe("secondaryName - name")
    })
})

describe("getRoleName tests", () => {
    it("should get expert user role name", () => {
        expect(getRoleName(EClinicalRole.EXPERTUSER)).toBe("Expert user")
    })
    it("should get admin role name", () => {
        expect(getRoleName(EClinicalRole.ADMIN)).toBe("Admin")
    })
    it("should get technologist role name", () => {
        expect(getRoleName(EClinicalRole.TECHNOLOGIST)).toBe("Technologist")
    })
    it("should get front desk role name", () => {
        expect(getRoleName(EClinicalRole.FRONTDESK)).toBe("Frontdesk")
    })
    it("should get scheduler role name", () => {
        expect(getRoleName(EClinicalRole.SCHEDULER)).toBe("Scheduler")
    })
    it("should get protocol manager role name", () => {
        expect(getRoleName(ERbacRole.PROTOCOL_MANAGER_ROLE)).toBe("Expert user (Protocol Manager Function)")
    })
    it("should get expert user with incognito role name", () => {
        expect(getRoleName(ERbacRole.EXPERTUSER_WITH_INCOGNITO_ROLE)).toBe("Expert user (Incognito Function)")
    })
    it("should get room role name", () => {
        expect(getRoleName(DEVICE_ROLE_ROOM)).toBe("Room")
    })
    it("should get default role name", () => {
        expect(getRoleName("defaultRole")).toBe("defaultRole")
    })
})

describe("checkIfParticipantIsGuest tests", () => {
    it("should check if participant is guest", () => {
        const participant = {
            callStatus: "", modality: "",
            id: "",
            uuid: "",
            siteId: [],
            orgId: "",
            status: EUserPresence.AVAILABLE,
            name: "Juno Bravo",
            phoneNumber: "12345678902",
            clinicalRole: EClinicalRole.DEVICE,
            email: "junobravo@yopmail.com",
            roomName: "MRI Scanner- 010",
            allRoles: [EClinicalRole.DEVICE],
            secondaryUUID: "",
            secondaryName: "",
            modalities: ["MR"],
            description: ""
        }
        expect(checkIfParticipantIsGuest(participant)).toBe(true)
    })
})

describe("generateInitials tests", () => {
    it("should generate initials", () => {
        const displayUser = "John Doe"
        expect(generateInitials(displayUser)).toBe("JD")
    })
})

describe("getSiteName tests", () => {
    jest.spyOn(externalAppStates, "fetchGlobalLocations").mockReturnValue([{
        id: 1,
        name: "location1",
        shortName: "location1",
        address: "",
        modalityList: [],
        locationContacts: [],
        totalRooms: 1,
        roomsFetched: true,
    }])
    it("should return site name", () => {
        expect(getSiteName("", ["1"])).toBe("location1")
    })
})

describe("render Special character of html tests", () => {
    it("should return special character", () => {
        expect(renderHTMLCd('&#8226;')).toBe(String.fromCharCode(8226))
    })
})

describe("getTranslatedCallType tests", () => {
    beforeEach(() => {
        jest.spyOn(globalComponent, "getIntlProvider").mockReturnValue({
            intl: {
                formatMessage: jest.fn().mockReturnValue("CallMessage")
            }
        })
    })
    it("should able to handle missed call", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALLMISSED)).toBe("CallMessage")
    })

    it("should able to handle CALLDECLINED", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALLDECLINED)).toBe("CallMessage")
    })
    it("should able to handle CALL_REJECTED", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALL_REJECTED)).toBe("CallMessage")
    })
    it("should able to handle CALLUNANSWERED", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALLUNANSWERED)).toBe("CallMessage")
    })
    it("should able to handleCALL_FAILED", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALL_FAILED)).toBe("CallMessage")
    })
    it("should able to handle CALL_CANCELLED", () => {
        expect(getTranslatedCallType(CALL_MESSAGES.CALL_CANCELLED)).toBe("CallMessage")
    })

    it("should able to handle normal string", () => {
        expect(getTranslatedCallType("CallMessage")).toBe("CallMessage")
    })
})

describe("updateCallMuteStatus tests", () => {
    const props: any = {
        connectedCallDetails: {
            contextId: "contextId",
            isMuted: false,
        },
        onHoldCallDetails: [{
            contextId: "contextId",
            isMuted: false,
        }],
    }
    it("should update call mute status", () => {
        expect(updateCallMuteStatus("contextId", true, props).connectedCallDetails.isMuted).toBe(true)
    })
})

describe("updateCallDeafenStatus tests", () => {
    const props: any = {
        connectedCallDetails: {
            contextId: "contextId",
            isDeafened: false,
        },
        onHoldCallDetails: [{
            contextId: "contextId",
            isDeafened: false,
        }],
    }
    it("should update call mute status", () => {
        expect(updateCallDeafenStatus("contextId", true, props).connectedCallDetails.isDeafened).toBe(true)
    })
})

describe("getCurrentUserAndUrlsReduxState  tests", () => {
    it("should return appreducer", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            currentUser: "currentUser"
        })
        jest.spyOn(externalAppStates, "fetchGlobalURLs").mockReturnValue({
            urls: "urls"
        })
        expect(getCurrentUserAndUrlsReduxState().urls).toEqual({ "urls": "urls" })
    })
})

describe("fetchActiveEditSession  tests", () => {
    it("should  fetchActiveEditSession", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            consoleSessions: [{}
            ]
        })
        expect(fetchActiveEditSession()).toBeCalled
    })
})

describe("checkIfConsoleAvailable  tests", () => {
    it("should return checkIfConsoleAvailable", () => {
        jest.spyOn(externalAppStates, "getGlobalStoreDetails").mockReturnValue({
            consoleSessions: [{}
            ]
        })
        expect(checkIfConsoleAvailable("contextId")).toBeCalled
    })
})

describe("checkIfMultiEditWithParkResumeFeatureEnabled tests", () => {
    it("should return false for checkIfMultiEditWithParkResumeFeatureEnabled", () => {
        expect(checkIfMultiEditWithParkResumeFeatureEnabled()).toBe(false)
    })
})

describe("checkIfMultiEditWithoutParkResumeFeatureEnabled tests", () => {
    it("should return false for checkIfMultiEditWithoutParkResumeFeatureEnabled", () => {
        expect(checkIfMultiEditWithoutParkResumeFeatureEnabled()).toBe(false)
    })
})
