/*
 * Created on Mon Aug 1 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType } from "@rocc/rocc-client-services"

export const convertConnectionModeFromString = (connectionMode: string) => {
    const {VNC, EMERALD, CC} = EConnectionMode
    switch(connectionMode.toUpperCase()) {
        case VNC: return VNC
        case EMERALD: return EMERALD
        case CC: return CC
    }
    return
}

export const convertConnectionTypeFromString = (connectionType: string) => {
    const {FULL_CONTROL, INCOGNITO_VIEW, PROTOCOL_MANAGEMENT, VIEW} = EConnectionType
    switch(connectionType.toUpperCase()) {
        case FULL_CONTROL: return FULL_CONTROL
        case VIEW: return VIEW
        case INCOGNITO_VIEW: return INCOGNITO_VIEW
        case PROTOCOL_MANAGEMENT: return PROTOCOL_MANAGEMENT
        default: 
    }
    return
}
