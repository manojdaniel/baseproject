/*
 * Created on Fri Nov 19 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { SET_APPSTATE, SET_USER_DETAILS_STATE, GLOBAL_FORCE_CLEAN_UP, GLOBAL_REFRESH_TOKEN, SET_SESSION_DETAILS, UPDATE_ONBOARDING_STATUS, UPDATE_PRESENCE, SET_USER_DETAILS_FAILURE, SET_PERMISSIONS } from "./types"
import { setCurrentAppState, getCurrentUserInfo, setForceCleanUp, updateRefreshToken, setSessionDetails, updateMetasiteIdForCurrentUser, logout, updateOnBoardingStatus, fetchContacts, updatePresenceForContactWithId, updateCurrentUserPresence, updateAllContactsPresence, updateAppState, setPermissionlist } from "./userAction"
import { EAppStates, EClinicalRole, EResponse, EUserPresence, IContactInfo, IUserInfo } from "@rocc/rocc-client-services"

describe("User actions", () => {
    const dispatch = jest.fn()
    const mockState = jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {
                onBoarded: false,
                uuid: ""
            },
            contacts: [{
                uuid: "wewe-uas730-eaersd"
            }]
        },
        appReducer: {
            loadTimes: {
                loginClick: Date
            }
        }
    })

    beforeEach(() => {
        dispatch.mockClear()
    })

    it("should dispatch an action to UPDATE_PRESENCE", () => {
        updateAllContactsPresence([] as any)(dispatch)
        expect(dispatch.mock.calls[0][0].type).toEqual(UPDATE_PRESENCE)
    })

    it("should dispatch an action to SET_USER_DETAILS_FAILURE", () => {
        updateAppState(EAppStates.INIT, EResponse.DEFAULT, "")(dispatch)
        expect(dispatch.mock.calls[0][0].type).toEqual(SET_USER_DETAILS_FAILURE)
    })

    it("should dispatch an action to SET_PERMISSIONS", () => {
        setPermissionlist([] as any)(dispatch)
        expect(dispatch.mock.calls[0][0].type).toEqual(SET_PERMISSIONS)
    })

    it("should dispatch an action to GLOBAL_REFRESH_TOKEN", () => {
        const expectedAction = [{
            type: GLOBAL_REFRESH_TOKEN,
            refreshAccessToken: "token",
            expiryTime: ""
        }]

        updateRefreshToken("token", "")(dispatch)
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })

    it("should dispatch an action to GLOBAL_FORCE_CLEAN_UP", () => {
        const expectedAction = [{
            type: GLOBAL_FORCE_CLEAN_UP,
            forceCleanUp: true
        }]

        setForceCleanUp(true)(dispatch)
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })

    it("should dispatch an action to SET_USER_DETAILS_STATE", () => {
        const expectedAction = [{
            type: SET_USER_DETAILS_STATE,
            userState: EResponse.INIT
        }]

        getCurrentUserInfo("testemail", "testuuid")(dispatch, () => void (0))
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })

    it("should dispatch an action to SET_APPSTATE", () => {
        const expectedAction = [{
            type: SET_APPSTATE,
            appState: EAppStates.READY
        }]

        setCurrentAppState(EAppStates.READY)(dispatch)
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })

    it("should dispatch an action to UPDATE_CURRENT_USER", () => {
        expect(updateMetasiteIdForCurrentUser("testName", EClinicalRole.EXPERTUSER)(dispatch, mockState)).toBeDefined()
    })

    it("should dispatch an action to SET_SESSION_DETAILS", () => {
        const expectedAction = [{
            type: SET_SESSION_DETAILS,
            sessionDetails: ""
        }]

        setSessionDetails("")(dispatch)
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })

    it("should dispatch an action to EXPERTUSER_LOGOUT_RESPONSE", () => {
        logout(() => { "" })(dispatch, mockState)
    })
    it("should should fetch contacts", () => {
        const a: EClinicalRole = EClinicalRole.EXPERTUSER
        const b: EUserPresence = EUserPresence.AVAILABLE
        const user: IUserInfo = {
            accessToken: "",
            accessTokenExpiryTime: new Date().toISOString(),
            onBoarded: false,
            sessionId: "",
            locale: "",
            id: "",
            uuid: "",
            siteId: [],
            orgId: "",
            status: b,
            name: "",
            phoneNumber: "",
            clinicalRole: a,
            email: "",
            roomName: "",
            allRoles: [],
            secondaryUUID: "",
            secondaryName: "",
            modalities: [],
            description: ""
        }
        fetchContacts(user, 1)(dispatch, jest.fn)

        updatePresenceForContactWithId("wewe-uas730-eaersd", EUserPresence.AVAILABLE)(dispatch, mockState)
        updateCurrentUserPresence(EUserPresence.AVAILABLE)(dispatch, mockState)
        expect(dispatch).toBeCalled()
    })

    it("should dispatch an action to UPDATE_ONBOARDING_STATUS", () => {
        const expectedAction = [{
            type: UPDATE_ONBOARDING_STATUS,
            currentUser: {
                onBoarded: true,
                uuid: "uuid"
            }
        }]
        updateOnBoardingStatus(true, "uuid")(dispatch, mockState)
        expect(dispatch.mock.calls.length).toBe(1)
        expect(dispatch.mock.calls[0]).toEqual(expectedAction)
    })
    it("should dispatch an action to UPDATE_PRESENCE", () => {
        const contacts = [{
            status: EUserPresence.AWAY
        }]
        updateAllContactsPresence(contacts as IContactInfo[])(dispatch)
        expect(dispatch).toBeCalled()

    })
})
