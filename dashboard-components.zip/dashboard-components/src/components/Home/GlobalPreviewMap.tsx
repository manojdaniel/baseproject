// @ts-nocheck
import React, { useState } from "react";
import {
	MapContainer,
	TileLayer,
	LayerGroup,
	Tooltip,
	SVGOverlay,
	CircleMarker,
} from "react-leaflet";
import "./GlobalPreviewMap.scss";

interface Props {
	setGetSelectedRegion: any;
	regionData: any[];
}

const GlobalPreviewMap = ({ setGetSelectedRegion, regionData }: Props) => {
	const [getSelectedActive, setGetSelectedActive] = useState<any>();

	//==================Region filter data without NULL in longitude & latitude======
	let GlobalRegionGetData = [];
	regionData.forEach((device: any, index: any) => {
		GlobalRegionGetData[index] = { ...device };
	});
	let getRegionFilterData = [];
	for (var i = 0; i < GlobalRegionGetData.length; i++) {
		if (
			GlobalRegionGetData[i].latitude !== null ||
			GlobalRegionGetData[i].longitude !== null
		) {
			let localdata = {
				affiliateCount: GlobalRegionGetData[i].affiliateCount,
				regionId: GlobalRegionGetData[i].regionId,
				name: GlobalRegionGetData[i].name,
				abrv: GlobalRegionGetData[i].abrv,
				latitude: GlobalRegionGetData[i].latitude,
				longitude: GlobalRegionGetData[i].longitude,
			};
			getRegionFilterData.push(localdata);
		}
	}
	//======================END===============================================================

	const onClickRegionPreview = (data: any) => {
		setGetSelectedRegion(data);
		setGetSelectedActive(data.regionId);
	};

	const activeColor = { color: "#FFCD00" };
	const defaultColor = { color: "#009fdf" };

	const getReadiousOfCircle = (count: any) => {
		if (count <= 5) {
			const mycount = Number(count) + 18;
			return mycount;
		} else if (count > 5) {
			const mycount = Number(count) + 30;
			return mycount;
		} else if (count > 15) {
			const mycount = Number(count) + 20;
			return mycount;
		}
	};
	const getWidthOfCircle = (count: any) => {
		if (count <= 5) {
			const mycount = Number(count) + 15;
			return mycount;
		} else if (count > 5) {
			const mycount = Number(count) + 30;
			return mycount;
		} else if (count > 15) {
			const mycount = Number(count) + 20;
			return mycount;
		}
	};

	return (
		<MapContainer
			center={[51.505, 35.09]}
			zoom={1}
			scrollWheelZoom={false}
			style={{ width: "100%", height: "100%" }}
		>
			<TileLayer
				attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
				url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
			/>
			<LayerGroup>
				{getRegionFilterData.map((data: any) => (
					<div key={data.regionId}>
						<CircleMarker
							center={[data.latitude, data.longitude]}
							pathOptions={{ color: "#009fdf", fillColor: "#009fdf" }}
							eventHandlers={{ click: () => onClickRegionPreview(data) }}
							pathOptions={
								getSelectedActive === data.regionId ? activeColor : defaultColor
							}
							radius={getReadiousOfCircle(data.affiliateCount)}
							weight={getWidthOfCircle(data.affiliateCount)}
							opacity={0.6}
							fillOpacity={0.0}
							className="marker-cluster"
						>
							<Tooltip direction="top">{data.name.toUpperCase()}</Tooltip>
						</CircleMarker>
						<SVGOverlay
							attributes={{ stroke: "red" }}
							bounds={[
								[data.latitude, data.longitude],
								[data.latitude, data.longitude],
							]}
						>
							{data.affiliateCount > 9 ? (
								<text x="42%" y="50%" stroke="#58595b">
									{data.affiliateCount}
								</text>
							) : (
								<text x="50%" y="51%" stroke="#58595b">
									{data.affiliateCount}
								</text>
							)}
						</SVGOverlay>
					</div>
				))}
			</LayerGroup>
		</MapContainer>
	);
};

export default GlobalPreviewMap;
