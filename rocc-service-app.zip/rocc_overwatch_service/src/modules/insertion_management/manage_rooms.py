"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os

from src.constants.headers import EXCEL_ROOM_SITE_IDENTIFIER, EXCEL_ROOM_MODALITY, EXCEL_ROOM_IDENTIFIER
from src.constants.constants import ROCC_PROXY_URL, HSDP_IAM_URL, ROOMS_DICT, SITES_DICT, TEMPLATE_DETAILS, TEMPLATE_VERSION_1_0_4, TEMPLATE_VERSION_1_0_6
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import get_site_id_from_site_short_name
from src.modules.db_operations.insertion_services.room_db_services import update_rooms_eligibility, insert_room_data_in_db
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.device_mdm_services.device_mdm_services import provision_devices_service
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_device_provision_token
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values
from src.wrappers.platform_services.communication_services.communication_profile_services import create_communication_profile_for_device_api
from src.wrappers.platform_services.iam_service.session_services import fetch_device_access_token
from src.wrappers.platform_services.iam_service.device_mgmt_services import create_instance_identity_mapping
from src.wrappers.platform_services.rbac_services.rbac_services import create_user_role_mapping
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.constants.enums import ESummaryStates
from src.utility.semver import parse_version

LOG = create_logger("ManageRoomsTask")


class ManageRooms(object):
    def __init__(self, data_dict, token, user_uuid, customer_name, kvm_config_id, transaction_data, org_db_id):
        self._data_dict = data_dict
        self._user_uuid = user_uuid
        self._org_db_id = org_db_id
        self._transaction_data = transaction_data
        self._rooms = data_dict[ROOMS_DICT]
        self._sites = data_dict[SITES_DICT]
        self._kvm_config_id = kvm_config_id
        self._vault_response = get_path_specific_vault_values(path_name=customer_name)
        self._token = token
        self._org_infra_uuid = self._vault_response["data"]["hsdpOrganizationId"]
        LOG.info("Recreating graphQl client before beginning Room data insertion")
        self._client = get_client_connection(access_token=self._token, org_infra_uuid=self._org_infra_uuid)

    def execute(self):
        """
        1. Populate eligible room records with site_ids
        2. For every room in rooms, Check if room record is eligible for update [mark record ]
            a. resources
            b. resource_uuid
            c. kvm_connection_details
            d. resource_device
        3. Compute number of HSDP devices required
            a. If number_of_devices_required > 0
                1. create devices
                2. Update eligible room records with device_ids
        4. Insert data in DB
            a. Collated check and insert modalities [Do not loop through dictionary]
            b. for every room in rooms, insert data in table:
                1. resources
                2. resource_demos
                3. rocc_kvm_connection_details
                4. rocc_device_details
                5. rocc_resource_device
                6. rocc_resource_uuid
            c. Update dicts with inserted values
        5. Create communication profile for rooms(devices)
            a. for every room in eligible roomsuser_token      1. Creating Instance identity mapping for room
                2. Creating Communication profile mapping for room
        6. Create R-BAC roles for rooms
            a. for every room in eligible rooms,
                1. Creating user-role mapping with "DEVICEROLE"
        """
        LOG.info("Initiating TASK - ManageRooms")

        LOG.debug("Updating rooms dictionary with site_ids")
        self.update_rooms_dict_with_sites()

        LOG.debug("Checking for new rooms to insert")
        number_of_devices_required = self.compute_eligible_rooms_to_insert()
        if number_of_devices_required > 0:
            LOG.info(f"Number of HSDP devices that will be provisioned: {number_of_devices_required}")
            new_device_ids = self.provision_new_hsdp_devices(number_of_devices_required, self._vault_response, self._token)
            self.update_rooms_dict_with_device_ids(new_device_ids)
        else:
            LOG.info("There are no new rooms/devices to be added, so checking if there are any updates required for existing rooms")

        self.setup_communication_infra_for_rooms()

        self.create_rbac_roles_for_rooms()

        LOG.debug("Inserting data in Rooms data tables")

        # scanner_data_support guard allows template version >= 1.0.4
        scanner_data_support = parse_version(self._data_dict[TEMPLATE_DETAILS]["version"]) >= parse_version(TEMPLATE_VERSION_1_0_4)
        additional_attributes_support = parse_version(self._data_dict[TEMPLATE_DETAILS]["version"]) >= parse_version(TEMPLATE_VERSION_1_0_6)
        self._rooms, transaction_data = insert_room_data_in_db(client=self._client,
                                                               rooms=self._rooms,
                                                               user_uuid=self._user_uuid,
                                                               kvm_config_id=self._kvm_config_id,
                                                               transaction_data=self._transaction_data,
                                                               scanner_data_support=scanner_data_support,
                                                               org_db_id=self._org_db_id,
                                                               additional_attributes_support=additional_attributes_support)

        self._data_dict[ROOMS_DICT] = self._rooms
        if number_of_devices_required > 10:
            LOG.info("Recreating graphQl client after completing Room data insertion")
            self._client = get_client_connection(access_token=self._token, org_infra_uuid=self._org_infra_uuid)
        LOG.info("TASK - ManageRooms completed !")
        return self._data_dict, transaction_data, self._client

    def update_rooms_dict_with_sites(self):
        try:
            for key, room in self._rooms.items():
                room[EXCEL_ROOM_MODALITY] = room[EXCEL_ROOM_MODALITY].upper()
                site_id = get_site_id_from_site_short_name(client=self._client,
                                                           site_short_name=room[EXCEL_ROOM_SITE_IDENTIFIER],
                                                           sites=self._sites)
                if site_id:
                    room["site_id"] = site_id
                    room["eligibility"] = {"status": True, "new_room": False, "new_device": False, "view": False, "edit": False}
                else:
                    self._transaction_data = update_summary_for_entity(self._transaction_data, "rooms", key, ESummaryStates.SKIPPED)
                    room["eligibility"] = {"status": False}
                    LOG.error(f"Following site: {room[EXCEL_ROOM_SITE_IDENTIFIER]} is not present in the DB/Excel.\
                              Hence, skipping the insertion of room: {room[EXCEL_ROOM_IDENTIFIER]}")
        except Exception as ex:
            LOG.error("Error while updating room data with sites: {}".format(ex))
            raise RoccException(500, "Error while updating room data with sites: {}".format(ex))

    def compute_eligible_rooms_to_insert(self):
        self._rooms, number_of_devices_required = update_rooms_eligibility(self._client, self._rooms, self._org_db_id)
        return number_of_devices_required

    @staticmethod
    def provision_new_hsdp_devices(number_of_devices_required, vault_response, token):
        provision_token = create_device_provision_token(os.environ[HSDP_IAM_URL], vault_response)
        new_device_ids = provision_devices_service(number_of_devices=number_of_devices_required,
                                                   vault_response=vault_response,
                                                   provision_token=provision_token,
                                                   token=token)
        return new_device_ids

    def update_rooms_dict_with_device_ids(self, hsdp_device_ids):
        for key, room in self._rooms.items():
            if room["eligibility"]["new_device"]:
                room["device_id"] = hsdp_device_ids.pop()

    def setup_communication_infra_for_rooms(self):
        LOG.info("Starting Process of setting Communication infrastructure for rooms")
        org_ctxt_header = {"Org-Id": self._org_infra_uuid}
        for key, room in self._rooms.items():
            room["instance_id"] = None
            room["communication_profile"] = None
            if room["device_id"] and room["eligibility"]["new_device"]:
                instance_id, communication_profile = self.create_communication_profile(self._token, room["device_id"], room[EXCEL_ROOM_IDENTIFIER], org_ctxt_header)
                room["instance_id"] = instance_id
                room["communication_profile"] = communication_profile

            else:
                room["communication_profile"] = "Skipping communication profile creation as there is no device_id or it is an existing device"
        LOG.info("Process of setting Communication infrastructure for rooms is completed")

    @staticmethod
    def create_communication_profile(token, device_id, short_name, org_ctxt_header):
        LOG.info("Creating Instance identity mapping for room: {}".format(short_name))
        token_response = fetch_device_access_token(os.environ[ROCC_PROXY_URL], device_id)
        communication_profile = None
        instance_id = None
        if token_response["status"] == 200:
            device_token = token_response["data"]["accessToken"]
            instance_id = create_instance_identity_mapping(url=os.environ[ROCC_PROXY_URL],
                                                           user_uuid=device_id,
                                                           user_token=device_token,
                                                           service_token=token,
                                                           org_ctxt_header=org_ctxt_header)

            LOG.info("Creating communication profile for room: {}".format(short_name))
            communication_profile = create_communication_profile_for_device_api(url=os.environ[ROCC_PROXY_URL],
                                                                                device_id=device_id,
                                                                                device_token=device_token,
                                                                                org_ctxt_header=org_ctxt_header)
        else:
            LOG.error(f"Could not create Device token for Room: {short_name}, hence skipping instance_identity and communication profile creation")
        return instance_id, communication_profile

    def create_rbac_roles_for_rooms(self):
        user_role_mapping = []
        for key, room in self._rooms.items():
            room["rbac_mapping"] = False
            user_role_mapping.append({"userId": room["device_id"], "role": "DEVICEROLE"})

        if len(user_role_mapping) > 0:
            if self.create_rbac_roles_for_room(self._token, self._org_infra_uuid, user_role_mapping):
                for key, room in self._rooms.items():
                    room["rbac_mapping"] = True

    @staticmethod
    def create_rbac_roles_for_room(token, org_infra_uuid, user_role_mapping):
        LOG.debug("Device role mapping : {}".format(user_role_mapping))
        org_ctxt_header = {"Org-Id": org_infra_uuid}
        return create_user_role_mapping(url=os.environ[ROCC_PROXY_URL],
                                        user_role_mapping=user_role_mapping,
                                        token=token,
                                        org_ctxt_header=org_ctxt_header)
