// @ts-nocheck
import React, { useRef, useState, useEffect } from "react";
import { default as ReactSelect } from "react-select";
import { components } from "react-select";
import Compressor from "table/Compressor";
import { Button } from "antd";
import "../SpareParts.scss";
import asset_model_accordian_minus from "../../../../assets/images/asset_model_accordian_minus.svg";
import asset_model_accordian_plus from "../../../../assets/images/asset_model_accordian_plus.svg";
import { useNavigate } from "react-router-dom";
import { encryptRSAData } from "../../../../utility/rsa";
import { useDispatch, useSelector } from "react-redux";
import PushNotification from "components/PushNotification";
import Loader from "components/Loader";
import {
    getSparePartsSAP, getSparePartsSAPDropdown, updateSparePartsSap,
    updateSparePartsSapResponse,
} from "../../../../redux/reducers/CommonReducer";


interface Props {
    // buttonName: string;
    // onClickHandler: any;
    // data: any[];
    // modelDropdown: any;
    // handleUpdate: any;
    // userrole: any;
}

const Sap = () => {

    let dispatch = useDispatch();

    const { globalSelecetedAsset, globalSelecetedPlant, sparePartsSAP, loadingSparePartsSAP,
        sparePartsSAPDropdown, userRole, updateSparePartsSapStatus } = useSelector((state: any) => ({
            globalSelecetedAsset: state.Common.globalSelecetedAsset,
            globalSelecetedPlant: state.Common.globalSelecetedPlant,
            sparePartsSAP: state.Common.sparePartsSAP,
            loadingSparePartsSAP: state.Common.loadingSparePartsSAP,
            sparePartsSAPDropdown: state.Common.sparePartsSAPDropdown,
            userRole: state.Common.userRole,
            updateSparePartsSapStatus: state.Common.updateSparePartsSapStatus,

        }));

    useEffect(() => {
        const accordionTitles = document.querySelectorAll(".accordionTitle");
        accordionTitles.forEach((accordionTitle) => {
            accordionTitle.addEventListener("click", () => {
                if (accordionTitle.classList.contains("is-open")) {
                    accordionTitle.classList.remove("is-open");
                } else {
                    const accordionTitlesWithIsOpen = document.querySelectorAll(".is-open");
                    accordionTitlesWithIsOpen.forEach((accordionTitleWithIsOpen) => {
                        accordionTitleWithIsOpen.classList.remove("is-open");
                    });
                    accordionTitle.classList.add("is-open");
                }
            });
        });

    }, []);

    useEffect(() => {
        dispatch(getSparePartsSAP(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`)));
        dispatch(getSparePartsSAPDropdown(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`)));    //{assetId}/{userId}
    }, [globalSelecetedAsset])

    const handleUpdate = (updateData) => {
        const newData = Object.assign(updateData, { "assetId": globalSelecetedAsset.value })
        dispatch(updateSparePartsSap(newData));
        console.log('Update Data', newData);
    }
    useEffect(() => {
        if (updateSparePartsSapStatus?.length > 0) {
            if (!updateSparePartsSapStatus?.hasOwnProperty("Succeeded")) {
                if (updateSparePartsSapStatus[0].retVal === 1) {
                    PushNotification("success", updateSparePartsSapStatus[0].retMsg);

                    dispatch(getSparePartsSAP(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`)));
                    dispatch(getSparePartsSAPDropdown(encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`)));    //{assetId}/{userId}
                } else {
                    PushNotification("error", updateSparePartsSapStatus[0].retMsg);
                }
            } else {
                PushNotification("error", updateSparePartsSapStatus.Message);
            }
            const emptyObj = [];
            dispatch(updateSparePartsSapResponse(emptyObj));
        } else {
            if (updateSparePartsSapStatus?.hasOwnProperty("Succeeded")) {
                console.log("updateSparePartsSapStatus" + updateSparePartsSapStatus);
                PushNotification("error", updateSparePartsSapStatus.Message);
            }
        }
    }, [updateSparePartsSapStatus]);

    // STOCK DETAILS Table width Setting=======================Start:
    // const ref = useRef(null);
    // useEffect(() => {
    //     const myWidth = ref.current ? ref.current.offsetWidth : 0;

    //     var elements = document.getElementsByClassName('ant-table-wrapper');
    //     Array.from(elements).forEach(function (element) {
    //         element.style.maxWidth = `${myWidth - 4}px`;
    //     });
    // }, [ref.current]);

    return (
        <div className="sparetables">
            {loadingSparePartsSAP ? (<Loader />) : (
                <Compressor
                    data={sparePartsSAP}
                    modelDropdown={sparePartsSAPDropdown}
                    userrole={userRole}
                    handleUpdate={handleUpdate}
                />
            )}


            {/* <div ref={ref} className="accordian-title accordionTitle">COMPRESSOR<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
            <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div>
            <div ref={ref} className="accordian-title accordionTitle">TURBINE<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div>
            <div ref={ref} className="accordian-title accordionTitle">LUBE OIL SYSTEM<span className="accordian-plus-image"><img src={asset_model_accordian_plus} /></span> <span className="accordian-minus-image"><img src={asset_model_accordian_minus} /></span></div>
            <div className="accordian-body">
                <div className="spare-model-health-index">
                    <Compressor />
                </div>
            </div> */}
        </div>
    );
};

export default Sap;