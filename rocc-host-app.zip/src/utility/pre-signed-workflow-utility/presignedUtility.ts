/*
 * Created on Tue Aug 2 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EPresignedStatus, IPresignedWorkflow } from "@rocc/rocc-client-services"

export const addOrUpdatePresignedWorkflow = (presignedWorkflows: IPresignedWorkflow[], newPresignedWorkflow: IPresignedWorkflow) => {
    const workflowId = presignedWorkflows.findIndex(workflow => workflow.id === newPresignedWorkflow.id)
    if (workflowId > -1) {
        presignedWorkflows[workflowId] = { ...newPresignedWorkflow }
    } else {
        presignedWorkflows.push(newPresignedWorkflow)
    }
    return [...presignedWorkflows]
}

export const updatePresignedWorkflowStatus = (presignedWorkflows: IPresignedWorkflow[], presignedId: string, presignedStatus: EPresignedStatus) => (
    presignedWorkflows.map(workflow => workflow.id === presignedId ? { ...workflow, status: presignedStatus } : workflow)
)

export const computePresignedErrorIfAny = (presignedWorkflows: IPresignedWorkflow[]) => {
    const { EXPIRED, FAILED, FORBIDDEN, INPROGRESS, INVALID, NOT_STARTED_YET, PAUSED, REVOKED, VALID } = EPresignedStatus
    let message = ""
    let valid = false
    presignedWorkflows.forEach(jwtDetails => {
        if ([EXPIRED, FAILED, FORBIDDEN, INVALID, NOT_STARTED_YET, REVOKED].includes(jwtDetails.status)) {
            message = jwtDetails?.additionalAttributes?.errorMessage ?? "There is a problem in the provided link, please reach out to administrator"
        } else if ([INPROGRESS, PAUSED, VALID].includes(jwtDetails.status)) {
            valid = true
        }
    })
    return valid ? "" : message
}

export const computeMessageAndStatusBasedOnVerification = (response: any) => {
    /* TODO: Need to use internationalized strings for Pre-signed messages */
    let errorMessage = ""
    let presignedInitialStatus = EPresignedStatus.NOT_STARTED_YET
    let statusCode
    switch (response?.status) {
        case 200:
            presignedInitialStatus = EPresignedStatus.VALID
            break
        case 206:
            statusCode = response?.data?.statusCode
            if (statusCode) {
                errorMessage = `${statusCode === 410 ? "Authorization is expired" : "The request is not available for the current time"}`
                presignedInitialStatus = statusCode === 410 ? EPresignedStatus.EXPIRED : EPresignedStatus.NOT_STARTED_YET
            }
            break
        case 403:
            errorMessage = "You are not authorized for accessing the scanner data"
            presignedInitialStatus = EPresignedStatus.FORBIDDEN
            break
        case 401:
            errorMessage = "Invalid user credentials used"
            presignedInitialStatus = EPresignedStatus.REVOKED
            break
        case 400:
        case 500:
        default:
            errorMessage = "There is a problem in the provided link, please reach out to administrator"
            presignedInitialStatus = EPresignedStatus.FAILED
            break
    }
    return { presignedInitialStatus, errorMessage }
}
