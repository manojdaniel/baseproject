import {fetchLocationData, getTechnologistName, setCustomerOrgId} from "./customerActions"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { mocked } from "ts-jest/utils"
import initialStatesForCustomer from "../reducers/customerReducer"
import { fetchLocationInfoForCurrentUser } from "../services/customerServices"
import * as clientServices from "@rocc/rocc-client-services"

jest.mock("../services/customerServices")

describe("Customer Actions actions", () => {

    const middlewares = [thunk]
    const mockStore = configureMockStore(middlewares)
    let store:any = null

    beforeEach(()=>{
        store = mockStore(initialStatesForCustomer)
        store.dispatch = jest.fn()    
    })

    it("should dispatch setCustomerOrgId", () => {
        const orgId = "f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"
        setCustomerOrgId(orgId,store.dispatch)
        expect(store.dispatch).toHaveBeenCalled()
    })

    it("should pass fetchLocationData", async () => {
        const mockFetchLocationInfoForCurrentUser = mocked(fetchLocationInfoForCurrentUser)
        mockFetchLocationInfoForCurrentUser.mockResolvedValue({"customerMetaData":{"orgId":"f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"} as any,"locations":[],"rooms":[]})
        const orgId = "f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"
        const getValue = () => {
            return {customerReducer: {metaData: {orgId: "f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"}}}
        }
        await fetchLocationData(orgId)(store.dispatch, getValue)
        expect(store.dispatch).toHaveBeenCalled()
    })

    it("should fail fetchLocationData", async () => {
        const mockFetchLocationInfoForCurrentUser = mocked(fetchLocationInfoForCurrentUser)
        mockFetchLocationInfoForCurrentUser.mockRejectedValue("API call failed")
        const orgId = "f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"
        const getValue = () => {
            return {customerReducer: {metaData: {orgId: "f06fdb8a-dfc5-4c0c-ba6a-ef2d712383cf"}}}
        }
        await fetchLocationData(orgId)(store.dispatch, getValue)
        expect(store.dispatch).toHaveBeenCalled()
    })

     it("should get technologist name", async () => {
        const spy = jest.spyOn(clientServices, "getUserByUUID").mockImplementation()
        const contacts = [
            {
                id: "",
                uuid: "",
                siteId: [""],
                orgId: "",
                status: clientServices.EUserPresence.AVAILABLE,
                name: "",
                phoneNumber: "",
                clinicalRole: clientServices.EClinicalRole.EXPERTUSER,
                email: "",
                roomName: "",
                allRoles: [clientServices.EClinicalRole.EXPERTUSER],
                secondaryName: "",
                secondaryUUID: "",
                modalities: [""],
                description: ""
            }
        ]
        await getTechnologistName(contacts, "abcd")
        expect(spy).toHaveBeenCalled()
    })
})
