/*
 * Created on Thu Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { ECallStatus, EConnectionStatus } from "@rocc/rocc-client-services"
import PresenceController from "./PresenceController"
import * as helpers from "../../utility/helpers/helpers"

const testState = {
    userReducer: {
        contactsFetched: true,
        currentUser: {
            loggedInLocation: ""
        }
    },
    clientStatusReducer: {
        applicationConnectionState: EConnectionStatus.ONLINE,
        updatedPresenceStatus: EUserPresence.AVAILABLE
    },
    customerReducer: {
        userLoggedInLocation: ""
    }
}

jest.mock("react-redux", () => ({
    useDispatch: jest.fn().mockReturnValue(jest.fn),
    useSelector: jest.fn(),
}))

jest.mock("../../redux/store/globalStore", () => ({
    CreateStore: jest.fn(),
    GetGlobalState: jest.fn().mockReturnValue({
        CALLING_APP_STORE: {
            callReducer: {
                videoCallStatus: [{ contextId: "", callStatus: ECallStatus.IDLE }],
                phoneCallStatus: ECallStatus.IDLE,
            }
        }
    }),
    SubscribeToPartnerState: jest.fn(),
}))

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

describe("should render PresenceController component", () => {
    beforeEach(() => {
        useSelectorMock(testState)
        jest.spyOn(helpers, "isLogoutInProgress").mockReturnValue(false)
    })

    it("should render Fragment", () => {
        withHooks(() => {
            const wrapper = shallow(<PresenceController />)
            expect(wrapper.find("Fragment")).toBeDefined()
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
