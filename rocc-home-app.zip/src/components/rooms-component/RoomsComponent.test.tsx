/*
 * Created on Fri Dec 3 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import { locations, rooms } from "../../mocks/mock-data"
import RoomsComponent from "./RoomsComponent"

const mockDispatch = jest.fn()

jest.mock("../../redux/store/globalStore", () => ({
  GetGlobalState: jest.fn().mockReturnValue({
    CC_CONSOLE: {
      protocolTransferReducer: {
        protocolTransferStatus: true,
        completedDestinations: []
      },
    }
  }),
  CreateStore: jest.fn().mockReturnValue({
    getState: jest.fn().mockReturnValue({
      externalReducer: {
        permissions: {
          RESOURCE_STARRED_ROOM: true
        }
      }
    })
  }),
  SubscribeToPartnerState: jest.fn()
}))

const featureFlags = {
  "rocc-multi-console": true,
  "rocc-protocol-transfer": true
}

jest.mock("../../redux/store/externalAppStates", () => ({
  fetchGlobalActiveLocation: jest.fn(() => {
    return 4
  }),
  fetchGlobalRooms: jest.fn(() => {
    return rooms
  }),
  fetchGlobalLocations: jest.fn(() => {
    return locations
  }),
  getGlobalStoreDetails: jest.fn(() => {
    return { featureFlags: featureFlags }
  }),
  fetchGlobalReceivers: jest.fn(() => {
    return []
  }),
  fetchGlobalAppVersion: jest.fn(() => { return "" }),
  dispatchToParentStore: jest.fn(),

}))

jest.mock("../../common/helpers/helpers", () => ({
  checkIfMultiEditEnabled: jest.fn().mockReturnValue(false),
  getFeatureFlagsReducerFromGlobalStore: jest.fn().mockReturnValue({
    featureFlags: {
      "rocc-multi-console": true,
      "rocc-protocol-transfer": true
    }
  })
}))

jest.mock("react-redux", () => ({
  useSelector: () => ({
    currentUser: {},
    activeSessions: [],
    activeLocationId: 5,
    locations: [],
    rooms: rooms,
    videoCallStatus: [],
    phoneCallStatus: []
  }),
  useDispatch: () => mockDispatch
}))

describe("Rooms Component", () => {
  let wrapper: any
  it("should render Rooms Component with header and body", () => {
    wrapper = shallow(<RoomsComponent />)
    wrapper.find("RoomViewHeaderComponent").props().modalityChangeHandler({ modality: "CT" })
    wrapper.find("RoomViewHeaderComponent").props().roomSearchHandler()
    expect(wrapper.find("RoomViewHeaderComponent").exists()).toBeTruthy()
    expect(wrapper.find(".roomViewHeaderWrapper")).toBeTruthy()
  })
})

describe("use effect", () => {
  let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
  const mockUseEffect = () => {
    useEffect.mockImplementationOnce(f => f())
  }

  it("should render useEffect", () => {
    useEffect = jest.spyOn(React, "useEffect")
    mockUseEffect()
    mockUseEffect()
    mockUseEffect()
    mockUseEffect()
    mockUseEffect()
    shallow(<RoomsComponent />)
    expect(useEffect).toHaveBeenCalled()
    jest.clearAllMocks()
  })
})
