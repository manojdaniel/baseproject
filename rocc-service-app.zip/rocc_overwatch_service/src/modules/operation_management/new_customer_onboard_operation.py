"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os

from src.constants.config_keys import CUSTOMER_OB_CRYPT_ENABLED, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE, CUSTOMER_OB_NO_OF_PIN_DIGITS, CUSTOMER_OB_PRIVACY_POLICY_URL, CUSTOMER_OB_ROCC_MEDIA_REGION, CUSTOMER_OB_ROCC_SIGNALING_REGION, CUSTOMER_OB_SELECTED_ROLES, INFRA_CFG_DEFAULT_ROLE_NAME, INFRA_CFG_ORG_OAUTH_CLIENT_ID, \
    INFRA_CFG_ORG_OAUTH_PASSWORD, INFRA_CFG_ORG_OAUTH_NAME, INFRA_CFG_ORG_PROPOSITION_NAME, INFRA_CFG_ORG_APP_NAME, INFRA_CFG_ORG_AUTH_SERVICE_NAME, \
    INFRA_CFG_DEVICE_PROPOSITION_NAME, INFRA_CFG_DEVICE_APP_NAME, INFRA_CFG_DEVICE_OAUTH_CLIENT_ID, INFRA_CFG_DEVICE_OAUTH_CLIENT_NAME, \
    INFRA_CFG_DEVICE_OAUTH_GROUP_NAME, INFRA_CFG_DEVICE_TYPE_NAME, INFRA_CFG_SET_PASSWORD_URL, INFRA_CFG_RECOVER_PASSWORD_URL, CUSTOMER_OB_LOCALE, \
    CUSTOMER_OB_ANALYTICS_LOG_CONSENT, CUSTOMER_OB_CONSOLE_IP, CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY, CUSTOMER_OB_SESSION_IDLE_TIMEOUT, CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT, \
    CUSTOMER_OB_ROCC_HELPLINE_NUMBER, CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS, \
    CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS, \
    CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, INFRA_CFG_DEFAULT_EXTERNAL_SYSTEM_NAME,  VAULT_HSDP_IAM_URL, \
    VAULT_PARENT_ORG_ID, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING, \
    CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS, CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION, CUSTOMER_OB_COUNTRY_ISO_CODE, CUSTOMER_OB_AV_AUTO_DISCONNECT_TIMEOUT, \
    CUSTOMER_OB_EDIT_REQUEST_APPROVAL_TIMEOUT_IN_SECONDS, CUSTOMER_OB_KVM_VENDOR_TYPE, \
    CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE, CUSTOMER_OB_BOXILLA_USER_PASS_VALUE, CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL, CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY, CUSTOMER_OB_MFA_ORG_POLICY
from src.constants.constants import CF_DOMAIN, ROUTING_KEY, OPERATION, JOB_LIST, CURRENT_JOB, TARGET_QUEUE, TRANSACTION_ID, ENTITY_ID, ENTITY_TYPE, \
    JOB_NAME, INDEX, STATUS, NOT_STARTED, INIT, OPERATION_STATUS, TASK_ID, FAILED, ROCC_SERVICE_TOOL_ROUTING_KEY, USER_UUID, REASON
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_task_id_and_order_from_task_name, insert_job_transaction_object, fetch_job_id_from_name, \
    fetch_task_id_from_name, \
    update_customers_table, update_service_job_transaction_status, upsert_customer_configurations_service, DEFAULT_SUMMARY_OBJECT
from src.modules.event_management.event_enums import EEntity, EJobs, EOperations, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.operation_management.operation_handler import OperationHandler
from src.utility.utility import generate_random_string, generate_random_string_with_special_character
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.rabbitmq.rabbitmq_utility import compute_rmq_queue_name

LOG = create_logger("NewCustomerOnboard")


class NewCustomerOnboard(OperationHandler):

    def __init__(self, customer_identifier, file_identifier, customer_object, user_detail):
        self._customer_identifier = customer_identifier
        self._file_identifier = file_identifier
        self._customer_object = customer_object
        self._user_uuid = user_detail
        self._transaction_id = None
        self._customer_id = None
        try:
            self._profile_configs = get_profile_data()
            self._parent_org_infra_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                          issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                          private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self._client = get_client_connection(
                self._token, org_infra_uuid=self._parent_org_infra_uuid)
        except RoccException as exception:
            LOG.exception(
                f"Error occurred while creating service token: {exception}")
            raise exception
        except Exception as exception:
            LOG.exception(
                f"Failed to initialize New customer onboard operation with error: {exception}")
            raise RoccException(
                status_code=500, payload="Internal server error") from exception

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._parent_org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Customer Onboard", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._user_uuid,
                                       org_id=self._parent_org_infra_uuid, token=self._token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def create_transaction(self):
        """
        1. Create a new transaction in transaction table
        2. Return transaction_id (operation_id) to the caller
        """
        try:
            LOG.info(
                "Adding a new transaction record at DB for the operation: NewCustomerOnboard")
            transaction_data = self.create_new_customer_transaction_data()
            job_id = fetch_job_id_from_name(job_name=EJobs.CUSTOMER_ORG_SETUP.value,
                                            client=self._client)
            task_id = fetch_task_id_from_name(task_name=ETasks.CREATE_ORG.value,
                                              client=self._client)
            transaction_id = insert_job_transaction_object(operation_type=EOperations.NEW_CUSTOMER_ONBOARD.value,
                                                           job_id=job_id,
                                                           task_id=task_id,
                                                           entity_id=self._customer_id,
                                                           entity_type=EEntity.CUSTOMER.value,
                                                           file_identifier=self._file_identifier,
                                                           transaction_data=transaction_data,
                                                           user_uuid=self._user_uuid,
                                                           client=self._client)
            return transaction_id

        except RoccException as exception:
            LOG.error(f"Error while storing transaction in DB {exception}")
            raise RoccException(str(exception)) from exception

    def update_transaction_in_db_wrt_job(self, status):
        """Update corresponding transaction from transaction table"""
        update_status = update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                              status=status,
                                                              client=self._client)
        LOG.info(
            f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        return update_status

    def add_customer_in_customers_table(self):
        try:
            LOG.info("Adding customer record in table: customers")
            customer_id = update_customers_table(client=self._client,
                                                 name=self._customer_identifier)
            if customer_id:
                return customer_id
        except RoccException as exception:
            LOG.error(
                f"Error occured while adding new customer to table - customers, error: {exception}")
        self.update_transaction_in_db_wrt_job(FAILED)
        return False

    def create_customer_configurations(self):
        """
        1. Compute auto-generatable configurations
        2. Collect configurations from the request
        3. Create configuration object for the customer
        4. Add the configurations in table: infrastructure_configurations
        """
        try:
            LOG.info("Capturing customer configurations record to DB")
            proxy_url = f"https://{self._customer_identifier}-rocc.{os.environ[CF_DOMAIN]}"
            infra_configs = json.loads(json.dumps(
                self.compute_infra_configs(proxy_url=proxy_url)))
            infra_configs_ob = {
                "customer_id": self._customer_id,
                "profile": os.environ.get("VAULT_PROFILE"),
                "proxy_url": proxy_url,
                "infra_configs": infra_configs
            }
            response = upsert_customer_configurations_service(client=self._client,
                                                              infra_configs_ob=infra_configs_ob)
            if response:
                return True
        except RoccException as exception:
            LOG.error(
                f"Error occured while adding new customer to table - customers, error: {exception}")
        self.update_transaction_in_db_wrt_job(FAILED)
        return False

    def compute_infra_configs(self, proxy_url):
        return {
            INFRA_CFG_DEFAULT_ROLE_NAME: generate_random_string(inp=f"{self._customer_identifier}ARN", length=8),
            INFRA_CFG_DEFAULT_EXTERNAL_SYSTEM_NAME: generate_random_string(inp=f"{self._customer_identifier}SYS", length=8),
            INFRA_CFG_ORG_OAUTH_CLIENT_ID: generate_random_string(inp=f"{self._customer_identifier}OACID", length=13),
            INFRA_CFG_ORG_OAUTH_PASSWORD: generate_random_string_with_special_character(inp=f"{self._customer_identifier}OACPWD",
                                                                                        length=16,
                                                                                        special_characters_set=["-", "@", "?"]),
            INFRA_CFG_ORG_OAUTH_NAME: generate_random_string(inp=f"{self._customer_identifier}OACNAME", length=8),
            INFRA_CFG_ORG_PROPOSITION_NAME: generate_random_string(inp=f"{self._customer_identifier}PROP", length=8),
            INFRA_CFG_ORG_APP_NAME: generate_random_string(inp=f"{self._customer_identifier}APP", length=8),
            INFRA_CFG_ORG_AUTH_SERVICE_NAME: generate_random_string(inp=f"{self._customer_identifier}SERVICE", length=8),
            INFRA_CFG_DEVICE_PROPOSITION_NAME: generate_random_string(inp=f"{self._customer_identifier}PROP", length=10),
            INFRA_CFG_DEVICE_APP_NAME: generate_random_string(inp=f"{self._customer_identifier}APP", length=16),
            INFRA_CFG_DEVICE_OAUTH_CLIENT_ID: generate_random_string(inp=f"{self._customer_identifier}OACID", length=16),
            INFRA_CFG_DEVICE_OAUTH_CLIENT_NAME: generate_random_string(inp=f"{self._customer_identifier}NAME", length=16),
            INFRA_CFG_DEVICE_OAUTH_GROUP_NAME: generate_random_string(inp=f"{self._customer_identifier}GROUP", length=10),
            INFRA_CFG_DEVICE_TYPE_NAME: generate_random_string(inp=f"{self._customer_identifier}TYPE", length=10),
            INFRA_CFG_SET_PASSWORD_URL: f"{proxy_url}/#/setpassword",
            INFRA_CFG_RECOVER_PASSWORD_URL: f"{proxy_url}/#/resetpassword",
            CUSTOMER_OB_LOCALE: self._customer_object[CUSTOMER_OB_LOCALE],
            CUSTOMER_OB_COUNTRY_ISO_CODE: self._customer_object[CUSTOMER_OB_COUNTRY_ISO_CODE],
            CUSTOMER_OB_ANALYTICS_LOG_CONSENT: self._customer_object[CUSTOMER_OB_ANALYTICS_LOG_CONSENT],
            CUSTOMER_OB_CONSOLE_IP: self._customer_object[CUSTOMER_OB_CONSOLE_IP],
            CUSTOMER_OB_KVM_VENDOR_TYPE: self._customer_object[CUSTOMER_OB_KVM_VENDOR_TYPE],
            CUSTOMER_OB_BOXILLA_USER_PASS_VALUE: self._customer_object[CUSTOMER_OB_BOXILLA_USER_PASS_VALUE],
            CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE: self._customer_object[CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE],
            CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY: self._customer_object[CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY],
            CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL: self._customer_object[CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL],
            CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY: self._customer_object[CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY],
            CUSTOMER_OB_EDIT_REQUEST_APPROVAL_TIMEOUT_IN_SECONDS:  "180",
            CUSTOMER_OB_SESSION_IDLE_TIMEOUT: self._customer_object[CUSTOMER_OB_SESSION_IDLE_TIMEOUT],
            CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT: self._customer_object[CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT],
            CUSTOMER_OB_ROCC_HELPLINE_NUMBER: self._customer_object[CUSTOMER_OB_ROCC_HELPLINE_NUMBER],
            CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS: self._customer_object[CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS],
            CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS: self._customer_object[CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS],
            CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS: self._customer_object[CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS],
            CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS: self._customer_object[CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS],
            CUSTOMER_OB_ROCC_MEDIA_REGION: self._customer_object[CUSTOMER_OB_ROCC_MEDIA_REGION],
            CUSTOMER_OB_ROCC_SIGNALING_REGION: self._customer_object[CUSTOMER_OB_ROCC_SIGNALING_REGION],
            CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS: self._customer_object[CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS],
            CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING: self._customer_object[CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING],
            CUSTOMER_OB_NO_OF_PIN_DIGITS: self._customer_object[CUSTOMER_OB_NO_OF_PIN_DIGITS],
            CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION: self._customer_object[CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION],
            CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE: self._customer_object[CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE],
            CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE: self._customer_object[CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE],
            CUSTOMER_OB_AV_AUTO_DISCONNECT_TIMEOUT: "3",
            # TODO:Fetch cryptEnabled value from UI New Customer Form
            CUSTOMER_OB_CRYPT_ENABLED: "false",
            CUSTOMER_OB_PRIVACY_POLICY_URL: self._customer_object[CUSTOMER_OB_PRIVACY_POLICY_URL],
            CUSTOMER_OB_MFA_ORG_POLICY: "false",
            CUSTOMER_OB_SELECTED_ROLES: self._customer_object[CUSTOMER_OB_SELECTED_ROLES]
        }

    def fetch_task_data(self, task_name, job_name):
        task_id, order = fetch_task_id_and_order_from_task_name(task_name=task_name,
                                                                job_name=job_name,
                                                                client=self._client)
        return {"index": order, "name": task_name, "status": NOT_STARTED, TASK_ID: task_id, REASON: ""}

    def create_new_customer_transaction_data(self):
        transaction_data = {
            "jobs": [
                {
                    "index": 1,
                    "name": EJobs.CUSTOMER_ORG_SETUP.value,
                    "job_id": fetch_job_id_from_name(EJobs.CUSTOMER_ORG_SETUP.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.CREATE_ORG.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_ROLES_AND_GROUPS.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_PROPOSITION.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_APPLICATION.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_SERVICE.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.ENABLE_SERVICE_TOOLS_FOR_CUSTOMER.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_OAUTH_CLIENT.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.UPDATE_CLIENT_SCOPE.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_EMAIL_TEMPLATES.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.MANAGE_DEVICE_PROPISITION.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_GROUP_POLICY.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.MANAGE_VAULT.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.MANAGE_REDIS.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_ALLOWED_ORG_ROCC.value, EJobs.CUSTOMER_ORG_SETUP.value),
                        self.fetch_task_data(
                            ETasks.ROLES_AND_PERMISSION_FOR_CUSTOMERS.value, EJobs.CUSTOMER_ORG_SETUP.value),
                    ]
                },
                {
                    "index": 2,
                    "name": EJobs.CF_CUSTOMER_SETUP.value,
                    "job_id": fetch_job_id_from_name(EJobs.CF_CUSTOMER_SETUP.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.CREATE_PROXY_ROUTE_FOR_NEW_CUSTOMER.value, EJobs.CF_CUSTOMER_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_TWILIO_SUB_ACCOUNT_FOR_NEW_CUSTOMER.value, EJobs.CF_CUSTOMER_SETUP.value),
                        self.fetch_task_data(
                            ETasks.CREATE_ORG_COMMUNICATION_PROFILE.value, EJobs.CF_CUSTOMER_SETUP.value),
                    ]
                },
                {
                    "index": 3,
                    "name": EJobs.TIMED_WAIT.value,
                    "job_id": fetch_job_id_from_name(EJobs.TIMED_WAIT.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.TIMED_WAIT.value, EJobs.TIMED_WAIT.value),
                    ]
                },
                {
                    "index": 4,
                    "name": EJobs.CUSTOMER_DATA_INSERTION.value,
                    "job_id": fetch_job_id_from_name(EJobs.CUSTOMER_DATA_INSERTION.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.SITE_DATA_INSERTION.value, EJobs.CUSTOMER_DATA_INSERTION.value),
                        self.fetch_task_data(
                            ETasks.CC_DATA_INSERTION.value, EJobs.CUSTOMER_DATA_INSERTION.value),
                        self.fetch_task_data(
                            ETasks.MANAGE_ROOMS.value, EJobs.CUSTOMER_DATA_INSERTION.value),
                        self.fetch_task_data(
                            ETasks.MANAGE_USERS.value, EJobs.CUSTOMER_DATA_INSERTION.value),
                    ]
                }, {
                    "index": 5,
                    "name": EJobs.VALIDATE_ONBOARDED_DATA.value,
                    "job_id": fetch_job_id_from_name(EJobs.VALIDATE_ONBOARDED_DATA.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.SITE_DATA_VALIDATION.value, EJobs.VALIDATE_ONBOARDED_DATA.value),
                        self.fetch_task_data(
                            ETasks.CC_DATA_VALIDATION.value, EJobs.VALIDATE_ONBOARDED_DATA.value),
                        self.fetch_task_data(
                            ETasks.ROOMS_DATA_VALIDATION.value, EJobs.VALIDATE_ONBOARDED_DATA.value),
                        self.fetch_task_data(
                            ETasks.USERS_DATA_VALIDATION.value, EJobs.VALIDATE_ONBOARDED_DATA.value),
                        self.fetch_task_data(
                            ETasks.EULA_DATA_VALIDATION.value, EJobs.VALIDATE_ONBOARDED_DATA.value),
                    ]
                },
                {
                    "index": 6,
                    "name": EJobs.COMPLETE.value,
                    "job_id": fetch_job_id_from_name(EJobs.COMPLETE.value, self._client),
                    "status": NOT_STARTED,
                    "tasks": [
                        self.fetch_task_data(
                            ETasks.COMPLETE.value, EJobs.COMPLETE.value),
                    ]
                }
            ],
            "summary": {
                "sites": DEFAULT_SUMMARY_OBJECT,
                "cc": DEFAULT_SUMMARY_OBJECT,
                "rooms": DEFAULT_SUMMARY_OBJECT,
                "users": DEFAULT_SUMMARY_OBJECT,
                "kvm": DEFAULT_SUMMARY_OBJECT
            }
        }
        return transaction_data

    def post_message(self):
        """
        1. Post message to RabbitMQ with Payload
        """
        job_list = [
            {INDEX: 1, JOB_NAME: EJobs.CUSTOMER_ORG_SETUP.value, STATUS: NOT_STARTED},
            {INDEX: 2, JOB_NAME: EJobs.CF_CUSTOMER_SETUP.value, STATUS: NOT_STARTED},
            {INDEX: 3, JOB_NAME: EJobs.TIMED_WAIT.value, STATUS: NOT_STARTED},
            {INDEX: 4, JOB_NAME: EJobs.CUSTOMER_DATA_INSERTION.value, STATUS: NOT_STARTED},
            {INDEX: 5, JOB_NAME: EJobs.VALIDATE_ONBOARDED_DATA.value, STATUS: NOT_STARTED},
            {INDEX: 6, JOB_NAME: EJobs.COMPLETE.value, STATUS: NOT_STARTED},
        ]

        payload = {
            TRANSACTION_ID: self._transaction_id,
            OPERATION: EOperations.NEW_CUSTOMER_ONBOARD.value,
            OPERATION_STATUS: INIT,
            CURRENT_JOB: EJobs.CUSTOMER_ORG_SETUP.value,
            JOB_LIST: job_list,
            ROUTING_KEY: ROCC_SERVICE_TOOL_ROUTING_KEY,
            TARGET_QUEUE: compute_rmq_queue_name(),
            ENTITY_TYPE: EEntity.CUSTOMER.value,
            ENTITY_ID: self._customer_identifier,
            USER_UUID: self._user_uuid
        }
        LOG.info(
            "Publishing a rabbitMQ message after creating a transaction for the operation: NewCustomerOnboard")
        publish_message(payload=payload)

    def initiate_operation(self):
        """
        1. Create a new transaction in transaction table
        2. Create a new customer in table: customers
        3. Create configurations for the customer
        4. Post message to RabbitMQ with Payload
        5. Return transaction_id (operation_id) to the caller
        """
        self._customer_id = self.add_customer_in_customers_table()
        error_message = "Failed to create a new customer"
        status_code = 500
        if self._customer_id:
            self._transaction_id = self.create_transaction()
            if self._transaction_id:
                success = self.create_customer_configurations()
                if success:
                    self.post_message()
                    self.safe_audit(event_subtype="Onboard Customer initiated.", action="C",
                                    outcome=0, code="Onboard Customer initiated.", value="Success")
                    return {"success": True,
                            "message": self._transaction_id,
                            "status": 202}
        self.safe_audit(event_subtype="Onboard Customer", action="C",
                        outcome=8, code="Onboard Customer", value="Error")
        return {"success": False,
                "message": error_message,
                "status": status_code}
