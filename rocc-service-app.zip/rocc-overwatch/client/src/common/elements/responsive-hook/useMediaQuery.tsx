/*
 * Created on Wed Jun 16 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { useEffect, useState } from "react"

const useMediaQuery = (query: string, defaultMatches = window.matchMedia(query).matches) => {
	const [matches, setMatches] = useState(defaultMatches)
	useEffect(() => {
		const media = window.matchMedia(query)
		if (media.matches !== matches) {
			setMatches(media.matches)
		}
		const listener = () => setMatches(media.matches)
		media.addListener(listener)
		return () => media.removeListener(listener)
	}, [query, matches])

	return matches
}

export default useMediaQuery
