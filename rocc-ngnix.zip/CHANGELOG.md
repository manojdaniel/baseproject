# Changelog

## [1.0.12](https://github.com/philips-internal/rocc-nginx/compare/1.0.11...1.0.12) (2022-10-03)


### Bug Fixes

* enabled auto versioning ([d38f60e](https://github.com/philips-internal/rocc-nginx/commit/d38f60e063a47ddace2fb0d53317ff0efc3b40db))


