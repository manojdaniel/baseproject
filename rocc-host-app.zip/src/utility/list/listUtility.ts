/*
 * Created on Mon Apr 19 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const insertElementIfNotExists = (arr: any[], value: any) => {
    if (!arr.includes(value)) {
        arr.push(value)
    }
    return arr
}

export const insertObjectIfNotExists = (arr: any[], object: any, uniqueKey: string) => {
    let exists = false
    for (const element of arr) {
        if (element[uniqueKey] === object[uniqueKey]) {
            exists = true
            break
        }
    }
    if (!exists) {
        arr.push(object)
    }
    return arr
}
