/*
 * Created on Fri Oct 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Reducer } from "redux"
import { SYNC_CONSOLE_STORE, SYNC_PROTOCOL_TRANSFER_STORE, SYNC_CALLING_STORE, SYNC_PARENT_REDUCERS } from "../actions/types"
import { IExternalReducer } from "../interfaces/types"
import { IUserInfo, EClinicalRole, ECallStatus, IAVCallDetails, ERoomType, DEFAULT_PERMISSION_LIST, EConnectionStatus, ECallType } from "@rocc/rocc-client-services"
import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { EProtocolTransferSteps } from "../interfaces/enums"

const INIT_CURRENT_USER_PROFILE: IUserInfo = {
    accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
    orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "",
    clinicalRole: EClinicalRole.DEFAULT, secondaryUUID: "", secondaryName: "", description: ""
}

const DEFAULT_ONGOING_CALL_DEATILS: IAVCallDetails = { contextId: "", roomName: "", roomType: ERoomType.GROUP, twilioToken: "", userDetails: "", participants: [], isFirstParticipant: false, callAcceptedTime: "", isMuted: false, isDeafened: false, callStatus: ECallStatus.IDLE, numOfParticipants: -1, callType: ECallType.WEB_TO_WEB }

export const initialStateForParentStates: IExternalReducer = {
    currentUser: INIT_CURRENT_USER_PROFILE,
    activeLocationId: -1,
    sideBar: {
        activeRightPanel: "",
        displayRightSidePanel: false,
        activeLeftPanel: "",
        displayLeftSidePanel: false,
        desktopFullScreen: false
    },
    consoleDetails: { activeConsoleTransactions: [], activeConsoleSessions: [] },
    callingDetails: { videoCallStatus: [], phoneCallStatus: ECallStatus.IDLE, connectedCallDetails: DEFAULT_ONGOING_CALL_DEATILS, onHoldCallDetails: [] },
    featureFlags: {},
    protocolTransferDetails: {
        protocolTransferStatus: false,
        selectedSource: {
            modality: "",
            identity: {
                uuid: "",
                name: ""
            }
        },
        selectedDestination: {
            identity: {
                uuid: "",
                name: ""
            }
        },
        currentStep: EProtocolTransferSteps.SelectSourceScanner,
        completedDestinations: [],
    },
    locations: [],
    rooms: [],
    initRoomsFetched: false,
    workflows: [],
    permissions: DEFAULT_PERMISSION_LIST,
    applicationConnectionState: EConnectionStatus.ONLINE,
    forceCleanUp: false,
    focusedCallAndConsole: { callContextId: "", consoleContextId: "" },
}

const externalReducer: Reducer = (state: IExternalReducer = initialStateForParentStates, action: any) => {
    switch (action.type) {
        case SYNC_PARENT_REDUCERS: {
            const { currentUser, notificationMessage, rooms, locations, activeLocationId, featureFlags, sideBar, workflows, permissions, focusedCallAndConsole, forceCleanUp, applicationConnectionState, initRoomsFetched } = action.payload
            return { ...state, currentUser, notificationMessage, rooms, locations, activeLocationId, featureFlags, sideBar, workflows, permissions, focusedCallAndConsole, forceCleanUp, applicationConnectionState, initRoomsFetched }
        }
        case SYNC_CONSOLE_STORE:
            return { ...state, consoleDetails: action.payload }
        case SYNC_CALLING_STORE:
            return { ...state, callingDetails: action.payload }
        case SYNC_PROTOCOL_TRANSFER_STORE:
            return { ...state, protocolTransferDetails: action.payload }
        default:
    }
    return { ...state }
}

export default externalReducer
