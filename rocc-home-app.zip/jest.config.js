module.exports = {
  roots: ["src"],
  testEnvironment: "jsdom",
  preset: "ts-jest",
  collectCoverage: true,
  setupFilesAfterEnv: ["./src/setupTests.ts"],
  moduleFileExtensions: ["ts", "tsx", "js"],
  testPathIgnorePatterns: ["node_modules/", "src/mocks/redux-micro-frontend-mock.ts", "src/mocks/mock-data.ts"],
  transform: {
    "^.+\\.tsx?$": "ts-jest",
    "^.+\\.css$": "<rootDir>/config/jest/cssTransform.js",
    "^(?!.*\\.(js|jsx|ts|tsx|css|json)$)": "<rootDir>/config/jest/fileTransform.js"
  },
  collectCoverageFrom: [
    "**/*.(ts|tsx)",
    "!src/**/*.d.ts",
    "!src/**/bootstrap.tsx",
    "!src/**/index.{ts,tsx}",
    "!src/redux/reducers/*.{ts,tsx}",
    "!src/redux/interfaces/*.{ts,tsx}",
    "!src/redux/actions/types.ts",
    "!src/resources/translations/*.{ts,tsx}",
    "!src/mocks/*.{ts,tsx}",
    "!src/constants/*.{ts,tsx}"
  ],
  transformIgnorePatterns: [
    "[/\\\\]node_modules[/\\\\].+\\.(js|jsx|ts|tsx)$",
    "^.+\\.module\\.(css|sass|scss)$"
  ],
  testMatch: ["<rootDir>/src/**/*.test.{ts,tsx}"],
  moduleNameMapper: {
    // Mocks out all these file formats when tests are run.
    "\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$":
      "identity-obj-proxy",
    "\\.(less|scss|sass)$": "identity-obj-proxy",
    "redux-micro-frontend": "<rootDir>/src/mocks/redux-micro-frontend-mock.ts"
  }
}
