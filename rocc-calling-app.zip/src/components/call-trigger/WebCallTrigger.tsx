/* eslint-disable @typescript-eslint/no-unused-vars */
/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { WebCall } from "@rocc/rocc-calling-components"
import React from "react"
import { useDispatch } from "react-redux"
import { useCallOptionStatus } from "../../common/helpers/customHooks"
import { IWebCallTrigger } from "../../redux/interfaces/types"
import { initiateWebCallHandler } from "../../services/callServices"

const COMPONENT_NAME = "WebCallTrigger"


const WebCallTrigger = ({ contactUuid, showTitle = true, background = false, modalityName }: IWebCallTrigger) => {

    const dispatch = useDispatch()

    const { isWebCallDisabled } = useCallOptionStatus(contactUuid)

    return (
        <WebCall
            initiateAVCall={() => initiateWebCallHandler({ contactUuid, componentName: COMPONENT_NAME, dispatch, modalityName })}
            showTitle={showTitle}
            isDisabled={isWebCallDisabled}
            isBorder={background}
        />
    )
}

export default WebCallTrigger
