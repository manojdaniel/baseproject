/*
 * Created on Fri May 21 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_FEATURE_FLAG_VALUES, EAppStates, EClinicalRole, IUrls, IUserInfo } from "@rocc/rocc-client-services"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { initializeFFMClient } from "@vip/feature-flags-js-sdk"
import { Dispatch } from "redux"
import { ADMIN_ROUTE, CONSULTS_ROUTE, IDN_ROUTE, PHARMA_ROUTE, UNAUTHORIZED_ROUTE } from "../../constants/routes"
import { updateFeatureFlags } from "../../redux/actions/featureFlagsActions"
import { SET_APPSTATE } from "../../redux/actions/types"
import { getUserAccessToken } from "../../services/authentication/AuthenticationService"


interface IInitFFClient {
    urls: IUrls
    currentUser: IUserInfo
    orgIdentifier: string
    dispatch: Dispatch<any>
    ffConfig: any
    defaultFeatureFlags: any
}

export const initializeFeatureFlagClient = async ({ urls, currentUser, orgIdentifier, ffConfig, defaultFeatureFlags, dispatch }: IInitFFClient) => {
    const { GRAPHQL_API_HSDP_URI, GRAPHQL_API_HSDP_WS_URI } = urls
    const { email, allRoles } = currentUser
    if (ffConfig) {
        const { clientId, apiEndpoint = "", applicationId = "" } = ffConfig.configuration

        const params = {
            "key": email,
            "userAccessToken": getUserAccessToken,
            "onReady": (ffmClient: any) => {
                /* Initialize the flags (state or Redux) for the application */
                const featureFlags = computeFeatureFlags(ffmClient.getAllFlags())
                dispatch(updateFeatureFlags(featureFlags))
                dispatch({ type: SET_APPSTATE, appState: EAppStates.READY })
            },
            "onChange": (ffmClient: any) => {
                /* Update the flags (state or Redux) for the application */
                const featureFlags = computeFeatureFlags(ffmClient.getAllFlags())
                dispatch(updateFeatureFlags(featureFlags))
            },
            "logger": (info: any) => infoLogger(info),
            "apiEndpoint": apiEndpoint,
            "applicationId": applicationId,
            "graphQlUrl": GRAPHQL_API_HSDP_URI,
            "graphQlWSUrl": GRAPHQL_API_HSDP_WS_URI,
        }

        const context = {
            "role": allRoles,
            "org": orgIdentifier,
            "emailId": email
        }

        initializeFFMClient({ type: ffConfig.type, clientId: clientId }, params, context, defaultFeatureFlags)
            .catch((error) => {
                errorLogger(`Error on initializing FFM Client. Params : ${errorParser(params)} & context: ${errorParser(context)} failed with ${errorParser(error)}`)
            })
    }
}

export const computeFeatureFlags = (featureFlags: any) => {
    const currentFeatureFlags = Object.keys(featureFlags)
    for (const [key, value] of Object.entries(DEFAULT_FEATURE_FLAG_VALUES)) {
        if (!currentFeatureFlags.includes(key)) {
            featureFlags[key] = value
        }
    }
    return featureFlags
}

export const determineRoute = (clinicalRole: EClinicalRole) => {
    let navigateTo = UNAUTHORIZED_ROUTE
    switch (clinicalRole) {
        case EClinicalRole.RADIOLOGIST:
            /* Uses rad consults */
            navigateTo = CONSULTS_ROUTE
            break
        case EClinicalRole.TECHNOLOGIST:
            /* Uses tech consults */
            navigateTo = CONSULTS_ROUTE
            break
        case EClinicalRole.EXPERTUSER:
            navigateTo = IDN_ROUTE
            break
        case EClinicalRole.PHARMA_ADMIN:
        case EClinicalRole.PHARMA_CUSTOMER_ADMIN:
        case EClinicalRole.PHARMA_SPECIALIST:
            navigateTo = PHARMA_ROUTE
            break
        case EClinicalRole.ADMIN:
            navigateTo = ADMIN_ROUTE
            break
        default:
    }
    return navigateTo
}
