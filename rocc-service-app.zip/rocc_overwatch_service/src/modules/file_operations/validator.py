"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import ERROR_DICT, ROCC_MODALITY_TYPES, ROCC_SCANNER_RESOURCES, ROCC_SITES, ROOMS_DICT, SITES_DICT, EMP_DICT, KVM_CONFIGURATION_DICT
from src.constants.headers import EXCEL_HOSPITAL_IDENTIFIER, EXCEL_ROOM_SITE_IDENTIFIER, EXCEL_USER_HOSPITAL_IDENTIFIER, EXCEL_ROOM_IDENTIFIER, EXCEL_CUSTOMER_NAME, \
    EXCEL_ROOM_MODALITY, EXCEL_USER_MODALITY
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_org_db_id_from_identifier
from src.modules.db_operations.db_utility.graphql_response_parser import extract_items_from_result
from src.wrappers.graphql.queries.queries import get_sites_from_db_query, get_resources_from_db_query, \
    get_modalities_from_db_query

LOG = create_logger("Validator")


def validate_sheet_for_blanks(sheet):
    empty_cells = []
    for row in range(0, sheet.nrows):
        for col in range(sheet.ncols):
            cell_val = sheet.cell(row, col).value
            if cell_val == "":
                empty_cells.append({row, col})
    return empty_cells


def validate_dicts(client, data_dict, error_msgs, customer_identifier):
    validation_exceptions = []
    try:
        sites_from_db = get_sites_from_db(client)
        sites_from_excel = get_sites_from_excel(data_dict[SITES_DICT])
        try:
            LOG.info("Validating data in dictionaries")
            customer_org_check = check_if_customer_orgs_are_valid(client, data_dict[SITES_DICT])
            data_dict[SITES_DICT] = customer_org_check[SITES_DICT]
            """ TODO: Need to have this check only for existing customer data upload """
            # if len(customer_org_check["invalid_customer_orgs"]) > 0:
            #     error_msgs.append("Following are invalid customer orgs: {}.".format(customer_org_check["invalid_customer_orgs"]))
        except RoccException as ex:
            validation_exceptions.append(ex.payload)

        try:
            LOG.info("Validating sites in rooms sheet")
            invalid_sites_from_res = validate_sites_of_resources(data_dict=data_dict[ROOMS_DICT], sites_from_db=sites_from_db, sites_from_excel=sites_from_excel)
            if len(invalid_sites_from_res) > 0:
                error_msgs.append(f"Following sites in resources sheet are invalid {invalid_sites_from_res}")
        except RoccException as ex:
            validation_exceptions.append(ex.payload)

        try:
            LOG.info("Validating sites in users sheet")
            invalid_sites_from_emp = validate_sites_of_employee(data_dict=data_dict[EMP_DICT], sites_from_db=sites_from_db, sites_from_excel=sites_from_excel)
            if len(invalid_sites_from_emp) > 0:
                error_msgs.append(f"Following sites in employee sheet are invalid: {invalid_sites_from_emp}")
        except RoccException as ex:
            validation_exceptions.append(ex.payload)

        try:
            LOG.info("Validating modalities in users sheet")
            invalid_modality_from_employees = validate_modality_of_employees(client, data_dict[EMP_DICT], data_dict[ROOMS_DICT])
            if len(invalid_modality_from_employees) > 0:
                error_msgs.append(f"Following modalities in employees sheet are invalid: {invalid_sites_from_emp}")
        except RoccException as ex:
            validation_exceptions.append(ex.payload)

        try:
            LOG.info("Checking if Kvm Configurations sheet is filled (Only for new customer)")
            validate_kvm_dict_new_customer(client, data_dict[KVM_CONFIGURATION_DICT], customer_identifier)
        except RoccException as ex:
            error_msgs.append("Kvm configurations sheet is empty for new customer.")
            validation_exceptions.append(ex.payload)

        data_dict[ERROR_DICT] = error_msgs
        LOG.info("Validating data in dictionaries is completed")
    except Exception as ex:
        LOG.exception(ex)
        LOG.error("Error while validating dictionaries")

    return data_dict, validation_exceptions

# ##########SITES VALIDATION##############


def check_if_customer_orgs_are_valid(client, sites_dict):
    try:
        invalid_customer_orgs = []
        for _, value in sites_dict.items():
            org_db_id = fetch_org_db_id_from_identifier(client=client, customer_identifier=value[EXCEL_CUSTOMER_NAME])
            value["org_db_id"] = org_db_id
            if not org_db_id:
                invalid_customer_orgs.append(value[EXCEL_CUSTOMER_NAME])
        invalid_customer_orgs = list(set(invalid_customer_orgs))
        return {
            "invalid_customer_orgs": invalid_customer_orgs,
            SITES_DICT: sites_dict
        }
    except Exception as ex:
        LOG.exception(f"Failed to check if customer orgs are valid with error: {ex}")
        raise RoccException(status_code=400, title="Customer orgs validation failed", payload="Checking customer orgs failed as sites couldn't be extracted") from ex


def validate_sites_of_resources(data_dict, sites_from_excel, sites_from_db):
    try:
        invalid_sites = []
        for _, value in data_dict.items():
            if value[EXCEL_ROOM_SITE_IDENTIFIER] not in [*sites_from_excel, *sites_from_db]:
                invalid_sites.append(value[EXCEL_ROOM_SITE_IDENTIFIER])
        return invalid_sites
    except Exception as ex:
        LOG.exception(f"Error while validating sites of resources: {ex}")
        raise RoccException(status_code=400, title="Site validation failed", payload="Scanner data was found to be linked to an invalid site") from ex


def validate_sites_of_employee(data_dict, sites_from_excel, sites_from_db):
    try:
        invalid_sites = []
        for _, value in data_dict.items():
            for site_name in value[EXCEL_USER_HOSPITAL_IDENTIFIER].split(","):
                if site_name not in [*sites_from_excel, *sites_from_db]:
                    invalid_sites.append(site_name)

        return invalid_sites
    except Exception as ex:
        LOG.exception(f"Error while validating sites of employees: {ex}")
        raise RoccException(status_code=400, title="Site validation failed", payload="Customer user data was found to be linked to an invalid site") from ex


def get_sites_from_excel(sites_dict):
    try:
        sites = []
        for _, value in sites_dict.items():
            sites.append(value[EXCEL_HOSPITAL_IDENTIFIER])
        sites = list(set(sites))
        return sites
    except Exception as ex:
        LOG.exception(f"Error while extracting unique sites from excel: {ex}")


def get_sites_from_db(client):
    sites = []
    try:
        sites = extract_items_from_result(client.execute(get_sites_from_db_query), ROCC_SITES, "identifier")
    except Exception as ex:
        LOG.exception(f"Error while extracting unique sites from DB: {ex}")
    return sites


# ##########RESOURCES VALIDATION##############


def validate_resources_of_transmitters(client, resources_dict, transmitter_dict):
    try:
        invalid_resources = []
        resources_from_db = get_resources_from_db(client)
        resources_from_excel = get_resources_from_excel(resources_dict)
        for _, value in transmitter_dict.items():
            if value[EXCEL_ROOM_IDENTIFIER] not in [*resources_from_db, *resources_from_excel]:
                invalid_resources.append(value[EXCEL_ROOM_IDENTIFIER])
        return invalid_resources
    except Exception as ex:
        LOG.exception(f"Error while validating sites of employees: {ex}")


def get_resources_from_excel(resources_dict):
    try:
        resources = []
        for _, value in resources_dict.items():
            resources.append(value[EXCEL_ROOM_IDENTIFIER])
        sites = list(set(resources))
        return sites
    except Exception as ex:
        LOG.exception(f"Error while extracting unique sites from excel: {ex}")


def get_resources_from_db(client):
    resources = []
    try:
        resources = extract_items_from_result(client.execute(get_resources_from_db_query), ROCC_SCANNER_RESOURCES, "identifier")
    except Exception as ex:
        LOG.exception(f"Error while extracting unique resources from DB: {ex}")
    return resources


# ##########MODALITY VALIDATION##############

def validate_modality_of_employees(client, employee_dict, resources_dict):
    try:
        invalid_modalities = []
        modalities_from_db = get_modalities_from_db(client)
        modalities_from_excel = get_modalities_from_excel(resources_dict)
        for _, value in employee_dict.items():
            for modality in value[EXCEL_USER_MODALITY].split(","):
                if modality.strip() not in [*modalities_from_db, *modalities_from_excel]:
                    invalid_modalities.append(modality)
        return invalid_modalities
    except Exception as ex:
        LOG.exception(ex)
        LOG.error("Error while validating modalities of resources")
        raise RoccException(status_code=400, title="Site validation failed", payload="Employee modality is invalid") from ex


def get_modalities_from_db(client):
    modalities = []
    try:
        modalities = extract_items_from_result(client.execute(get_modalities_from_db_query), ROCC_MODALITY_TYPES, "modality")
    except Exception as ex:
        LOG.exception(f"Error while extracting unique resources from DB: {ex}")
    return modalities


def get_modalities_from_excel(resources_dict):
    try:
        modalities = []
        for _, value in resources_dict.items():
            modalities.append(value[EXCEL_ROOM_MODALITY])
        modalities = list(set(modalities))
        return modalities
    except Exception as ex:
        LOG.exception(f"Error while extracting unique modalities from excel: {ex}")

def validate_kvm_dict_new_customer(client, kvm_dict, customer_identifier):
    org_db_id = fetch_org_db_id_from_identifier(client=client, customer_identifier=customer_identifier)
    if not org_db_id and not bool(kvm_dict):
        LOG.error("Kvm configuration sheet is empty for new customer.")
        raise RoccException(status_code=400, title="Kvm configuration sheet is empty", payload="Kvm configuration sheet is empty for new customer.")
