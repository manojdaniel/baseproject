/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionType, ETransactionStatus, IUserInfo, parseIntBase10 } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { updateSpecificDataToTransactionGroup } from "../../../redux/actions/consoleActions"
import { IConsoleTransaction } from "../../../redux/interfaces/types"
import { requestAuthorizationService } from "../../../services/consoleService"
import { getCallContextByContactUuid } from "../../helpers/helpers"

export interface IAuthorizationRequest {
    consoleTransaction: IConsoleTransaction
    currentUser: IUserInfo
    seatName: string
    dispatch: Dispatch<any>
    auth: boolean
}

export const handleAuthorizationRequest = async (props: IAuthorizationRequest) => {
    const { currentUser, dispatch, consoleTransaction, seatName, auth } = props
    const { connectionType, connectionMode, roomUuid, receiverName, groupId } = consoleTransaction
    const callContextId = getCallContextByContactUuid(roomUuid)?.contextId
    if (connectionType === EConnectionType.FULL_CONTROL && !callContextId) {
        errorLogger(`Failed to make console authorization request since callContext is not availablefor user ${currentUser.uuid}`)
        return ETransactionStatus.FAILED
    }
    const authorizeRequestProps = {
        connectionType, connectionMode, requester: currentUser.uuid, roomUuid, auth,
        seatName, accessToken: currentUser.accessToken, receiverName, callContextId, orgId: parseIntBase10(currentUser.orgId),

    }
    const contextId = await requestAuthorizationService(authorizeRequestProps)
    if (contextId) {
        // Update ContextId in all available transactions
        infoLogger(`Update contextId ${contextId} to all the transactions for user ${currentUser.uuid}`)
        dispatch(updateSpecificDataToTransactionGroup("contextId", contextId, groupId))
        return ETransactionStatus.FINISHED
    }
    errorLogger(`Failed to get console contextId, updating transaction status to ${ETransactionStatus.FAILED} for user ${currentUser.uuid}`)
    return ETransactionStatus.FAILED
}
