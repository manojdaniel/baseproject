// import react from 'react';
// import { Spin } from 'antd';
// import { LoadingOutlined } from '@ant-design/icons';

// const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;

// // Return value should be component
// const Loader = () => <Spin indicator={antIcon} />

// export default Loader;

import React from "react";

const App: React.FC = () => {
	return (
		<div className="noData-text">No data available</div>
	);
};

export default App;
