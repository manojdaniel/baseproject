/*
 * Created on Thu Jul 29 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getDurationInFormat, parseIntBase10 } from "./mathUtility"

describe("Unit tests for Math utility", () => {
    let lesserDate: Date
    let largerDate: Date
    beforeEach(() => {
        lesserDate = new Date(1970, 1, 1)
        largerDate = new Date(1970, 1, 1)
        largerDate.setMinutes(lesserDate.getMinutes() + 90)
    })

    it("should parse int", () => {
        expect(parseIntBase10("100")).toBe(100)
    })

    it("date time difference in miliseconds ", () => {
        const diffInMiliseconds = getDurationInFormat(largerDate, lesserDate, "miliseconds")
        expect(diffInMiliseconds === 5400000).toBeTruthy()
    })

    it("date time difference in seconds ", () => {
        const diffInSeconds = getDurationInFormat(largerDate, lesserDate, "seconds")
        expect(diffInSeconds === 5400).toBeTruthy()
    })

    it("date time difference in minutes ", () => {
        const diffInMins = getDurationInFormat(largerDate, lesserDate, "minutes")
        expect(diffInMins === 90).toBeTruthy()
    })

    it("date time difference in hours ", () => {
        const diffInHours = getDurationInFormat(largerDate, lesserDate, "hours")
        expect(diffInHours === 2).toBeTruthy()
    })
})
