import { notification } from "antd";

const PushNotification = (type: string, message: string) => {
	switch (type) {
		case "success":
			notification.success({
				message,
				// description: 'This is the content of the success notification.',
				duration: 10,
				placement: "topRight",
				style: { marginTop: "120px" },
			});
			break;
		case "error":
			notification.error({
				message,
				//description: 'This is the content of the error notification.',
				duration: 10,
				placement: "topRight",
				style: { marginTop: "120px" },
			});
			break;
		case "warning":
			notification.warning({
				message,
				// description: 'This is the content of the warning notification.',
				duration: 10,
				placement: "topRight",
				style: { marginTop: "120px" },
			});
			break;
		default:
			notification.info({
				message,
				// description: 'This is the content of the notification.',
				duration: 10,
				placement: "topRight",
				style: { marginTop: "120px" },
			});
			break;
	}
};

export default PushNotification;
