/*
 * Created on Tue Sep 14 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { ECallStatus, EClinicalRole } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import * as Redux from "react-redux"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { ESidePanelTabs } from "../../../lib/types"
import ContactsList from "./ContactList"

jest.mock("react-redux", () => ({
    useDispatch: () => void (0),
    useSelector: jest.fn().mockReturnValue({
        videoCallStatus: [{ callStatus: "idle", contextId: "" }],
        phoneCallStatus: "idle",
        currentUser: {
            uuid: "uuid"
        },
    })
}))

const testState = {
    callReducer: {
        videoCallStatus: [],
        phoneCallStatus: ECallStatus.IDLE,
    },
    externalReducer: {
        permissions: {
            CALL_WEB_TO_WEB: true,
            CALL_WEB_TO_PHONE: true,
        }
    }

}

let store: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}

describe("ContactsList tests", () => {
    let wrapper: any
    const contactsData = [{
        id: "1",
        uuid: "1",
        siteId: ["site1"],
        orgId: "org1",
        status: EUserPresence.AVAILABLE,
        name: "dummy user",
        phoneNumber: "+91 1234567890",
        clinicalRole: EClinicalRole.EXPERTUSER,
        email: "demo@yopmail.com",
        roomName: "room1",
        allRoles: [EClinicalRole.EXPERTUSER],
        secondaryUUID: "1",
        secondaryName: "dummy",
        modalities: ["CT"],
        description: "description",
    }]
    beforeEach(() => {
        useSelectorMock(testState)
    })
    it("should render contactList", () => {
        withHooks(() => {
            wrapper = shallow(<ContactsList contacts={contactsData} activeItem={ESidePanelTabs.Active} />)
            expect(wrapper.find("#contactList")).toHaveLength(1)
        })
    })

    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
