/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo } from "@rocc/rocc-client-services"
import { CONSOLE_STORE, PARENT_STORE } from "../../constants/constants"
import globalStore from "./globalStore"

interface IGetGloalStoreDetails {
    storeName: string
    reducerPath: string
}
export const getGlobalStoreDetails = (props: IGetGloalStoreDetails) => {
    const { storeName, reducerPath } = props
    const gState = globalStore.GetGlobalState()
    if (gState[storeName] && gState[storeName][reducerPath]) {
        return gState[storeName][reducerPath]
    }
}

/* Global states */
export const fetchGlobalURLs = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.urls
}
export const fetchGlobalConfigs = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.configReducer.configs
}
export const fetchGlobalFeatureFlags = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.featureFlagsReducer.featureFlags
}
export const fetchGlobalOrgUUID = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.orgId
}

export const fetchGlobalOrgName = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.name
}
export const fetchGlobalMetaSite = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.displayName
}
export const fetchGlobalActiveLocation = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.activeLocationId
}
export const fetchGlobalRooms = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.rooms
}
export const fetchGlobalLocations = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.locations
}
export const fetchGlobalContacts = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.userReducer.contacts
}
export const fetchGlobalSideBar = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.appReducer.sideBar
}
export const fetchMetaSiteId = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST.customerReducer.metaData.id
}

export const fetchGlobalCurrentUser = () => {
    const gState = globalStore.GetGlobalState()
    const user: IUserInfo = gState.CC_HOST.userReducer.currentUser
    return user
}

export const fetchGlobalReceivers = () => {
    const gState = globalStore.GetGlobalState()
    const receivers = gState[CONSOLE_STORE]?.consoleReducer?.commandCenterDetails?.commandCenterSeat.receivers
    return receivers
}

export const dispatchToParentStore = (action: any) => {
    globalStore.DispatchAction(PARENT_STORE, action)
}

export const fetchGlobalAppVersion = () => {
    const gState = globalStore.GetGlobalState()
    return gState.CC_HOST?.appReducer?.version
}
