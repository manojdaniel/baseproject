/*
 * Created on Thu Dec 10 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useState } from "react"
import { Button, Dropdown, Icon, Menu, MenuItemProps } from "semantic-ui-react"
import { INavBar, INavMenu, INavMenuItem, EMenuTypes } from "./NavBar.types"
import { COMPANY_NAME, APP_NAME } from "constants/constants"
import About from "common/elements/about/About"
import "./NavBar.scss"
import { INIT_CUSTOMER_NAV_DATA } from "redux/interfaces/defaulData"
import { setActiveTab, updateCustomersNavData } from "redux/actions/customersActions"
import { useDispatch, useSelector } from "react-redux"
import { IStore } from "redux/interfaces/types"

const NavBar: React.FC<INavBar> = ({
	appName,
	userName,
	appSwitcher,
	primaryMenuItems,
	searchIcon,
	notificationIcon,
	notificationValue,
	settingsIcon,
	aboutIcon,
	secondaryMenuItems,
	isMobile,
	useAppNameLink,
	appNameLink,

}) => {
	const dispatch = useDispatch()
	const { navData } = useSelector((state: IStore) => ({
		navData: state.customerReducer.navData
	}))

	const isActiveMenu = (path: string | null | undefined) => {
		// Works only if Hash Router is used
		if (
			typeof path === "string" &&
			window &&
			window.location &&
			window.location.hash
		) {
			return path
				? path.toLowerCase().endsWith("/" + window.location.hash.split("/")[1]) : false
		} else {
			return false
		}
	}

	const getNavMenu = (menus: INavMenu[], menuLabel?: string) => {
		return menus.map((menu: INavMenu, index: number) => {
			const { type, label, items } = menu
			return type === EMenuTypes[EMenuTypes.dropdown] ? (
				<Dropdown key={index} item text={menuLabel ? menuLabel : label}>
					<Dropdown.Menu>{getNavMenuItems(type, items)}</Dropdown.Menu>
				</Dropdown>
			) : (
				getNavMenuItems(type, items)
			)
		})
	}

	const handleHomeTab = (e: any, data: MenuItemProps) => {
		const isCustomerSelected = navData.selectedCustomer !== 0
		const isAllOrgPage = navData.activePage === 1
		const isFeatureFlagClicked = window.location.hash === "#/featureflag"
		const isAppNameClicked = data.name !== undefined && data.name === appName

		const dispatchNavData = () => {
			dispatch(updateCustomersNavData(INIT_CUSTOMER_NAV_DATA))
			dispatch(setActiveTab(0))
		}

		if (isCustomerSelected) {
			if ((!isFeatureFlagClicked && !isAppNameClicked) || ((isFeatureFlagClicked || isAppNameClicked) && !isAllOrgPage)) {
				dispatchNavData()
			}
		} else {
			dispatchNavData()
		}
	}

	const getNavMenuItems = (
		type: EMenuTypes | string,
		items: INavMenuItem[],
	) => {
		return items.map((menuItem: INavMenuItem, index: number) => {
			const { text, to, onClick } = menuItem
			return type === EMenuTypes[EMenuTypes.dropdown] ? (
				onClick ? <Dropdown.Item key={index} onClick={onClick}>{text}</Dropdown.Item> :
					<Dropdown.Item key={index} to={to} href={`/${to}`}>{text}</Dropdown.Item>
			) : (
				<Menu.Item
					onClick={handleHomeTab}
					key={index}
					active={isActiveMenu(to)}
					to={to}
					href={`/${to}`}>
					{text}
				</Menu.Item>
			)
		})
	}

	const getAppMenuItem = () => {
		if (useAppNameLink && appNameLink) {
			return <Menu.Item name={appName} onClick={handleHomeTab}></Menu.Item>
		} else {
			return <Menu.Item name={appName}></Menu.Item>
		}
	}

	const [aboutModal, setAboutModal] = useState(false)

	const openModal = () => {
		setAboutModal(true)
	}

	return <>
		{!isMobile && (
			<Menu className="navigation">
				<div className="container ui navbar">
					{appSwitcher && (
						<div className="menu-icon">
							<Menu.Item name="home" href="/">
								<Icon className="Menu large" />
							</Menu.Item>
						</div>
					)}
					<div className="menu-title">
						{getAppMenuItem()}
					</div>
					<div className="menu-items">
						{primaryMenuItems && getNavMenu(primaryMenuItems)}
					</div>
					<Menu.Menu position="right">
						<div className="facet-icon">
							{aboutIcon && (
								<Menu.Item >
									<Button onClick={openModal} circular secondary className="icon">
										<Icon className="QuestionmarkCircleOutline big" />
									</Button>
								</Menu.Item>

							)}

							{searchIcon && (
								<Menu.Item>
									<Button circular secondary icon="Search big" />
								</Menu.Item>
							)}
							{notificationIcon && (
								<Menu.Item href="/" className="notificationContainer">
									<Icon className="Alarm large iconBadge">
										<span className="badgeContent">{notificationValue}</span>
									</Icon>
								</Menu.Item>
							)}
							{settingsIcon && (
								<Menu.Item>
									<Button circular secondary icon="Settings big" />
								</Menu.Item>
							)}
						</div>
						<div className="facet-text"></div>
						<div className="separator" />
						{secondaryMenuItems && getNavMenu(secondaryMenuItems, userName)}
					</Menu.Menu>
					<About
						isModalOpen={aboutModal}
						closeModal={() => setAboutModal(false)}
						companyName={COMPANY_NAME}
						applicationTitle={APP_NAME}
					/>
				</div>
			</Menu>
		)}
		{isMobile && (
			<Menu className="sm-navigation">
				<div className="container ui">
					<div className="menu-icon">
						<Menu.Item name="home">
							<Icon className="Menu large" />
						</Menu.Item>
					</div>
					<div className="menu-title">
						<Menu.Item name={appName} href="/"></Menu.Item>
					</div>
					<Menu.Menu position="right">
						<div className="facet-icon">
							{aboutIcon && (
								<Menu.Item>
									<Button circular secondary>
										<Icon className="QuestionmarkCircleOutline big" />
									</Button>
								</Menu.Item>
							)}
							{searchIcon && (
								<Menu.Item>
									<Button circular secondary icon="Search large" />
								</Menu.Item>
							)}
							{notificationIcon && (
								<Menu.Item href="/">
									<Icon className="Alarm large" />
								</Menu.Item>
							)}
							{settingsIcon && (
								<Menu.Item>
									<Button circular secondary icon="Settings big" />
								</Menu.Item>
							)}
						</div>
						{/* TODO: figure out the use case here 
                                <div className="facet-text">
                                    <Menu.Item name="Add">
                                    </Menu.Item>  You can add button or Menu.Item name
                                </div>  In mobile case either 2 icons or a one single text button is allowed  
                            */}
					</Menu.Menu>
				</div>
			</Menu>
		)}
	</>
}


export default NavBar
