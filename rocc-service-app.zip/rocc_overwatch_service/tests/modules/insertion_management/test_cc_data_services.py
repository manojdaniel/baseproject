import unittest
from unittest.mock import Mock, patch
from src.exceptions.RoccException import RoccException
from src.modules.insertion_management.cc_data_services import CcDataServices


class ManageRoomsTest(unittest.TestCase):
    def test_start_job(self):
        param_dict = {"COMMAND_CENTERS_DICT": "test", "TEMPLATE_DETAILS": {"version": "1.0.0"}, "SITES_DICT": "test"}
        cc_data_services = CcDataServices({}, "org_db_id", param_dict, {}, "user_uuid")
        with self.assertRaises(RoccException):
            cc_data_services.execute()

        cc_data_services._rcvr_dict = {"key": "value"}
        with self.assertRaises(Exception):
            cc_data_services.verify_and_insert_records(multi_console_support=True)
        self.assertIsNotNone(cc_data_services)

    @patch("src.modules.insertion_management.cc_data_services.check_if_id_is_present", side_effect=lambda data, table_name:  True)
    def test_handle_multi_console(self, fn_id_present):
        fn_id_present.return_value = True
        param_dict = {"COMMAND_CENTERS_DICT": "test", "TEMPLATE_DETAILS": {"version": "1.0.0"}, "SITES_DICT": "test"}
        cc_data_services = CcDataServices({}, "org_db_id", param_dict, {}, "user_uuid")
        cc_data_services._rcvr_dict = {"key": "value"}

        mock_client = Mock()
        mock_client.execute.return_value = {"data": True}
        cc_data_services._client = mock_client
        cc_data_services._org_db_id = 1

        with self.assertRaises(Exception):
            cc_object = {"'Command Center Name\n(To be filled by Philips)'": "seat name",
                         "Receiver Name (To be filled by Philips)": "receiver"}
            cc_data_services.handle_multi_console("key", cc_object)

        with self.assertRaises(Exception):
            cc_data_services._rcvr_dict = None
            cc_data_services.verify_and_insert_records(True)
        self.assertIsNotNone(cc_data_services)

    def test_verify_and_insert_records(self):
        param_dict = {"COMMAND_CENTERS_DICT": "test", "TEMPLATE_DETAILS": {"version": "1.0.0"}, "SITES_DICT": "test"}
        cc_data_services = CcDataServices({}, "org_db_id", param_dict, {}, "user_uuid")
        cc_data_services._user_uuid = ""
        cc_object = {"Receiver Name (To be filled by Philips)": "a",
                     "Receiver IP (To be filled by Philips)": "a",
                     "Monitor identification label (To be filled by Philips)": "2"}
        data_dict = cc_data_services.prepare_receiver_object_for_existing_cc(cc_object, "commandCentre It")
        cc_data_services.prepare_update_receiver_object(cc_object)
        self.assertIsNotNone(data_dict)
