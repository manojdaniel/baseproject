import { EUserPresence, IRoomDetails } from "@rocc/rocc-client-services"
import { PARENT_STORE } from "../common/constants/constants"

export const mockedFn = {
    Get: jest.fn().mockReturnValue({
        GetGlobalState: jest.fn().mockReturnValue({
            [PARENT_STORE]: {
                configReducer: { configs: { ROCC_DEV: "false" } },
                userReducer: {
                    currentUser: {}
                }
            }
        }),
        CreateStore: jest.fn().mockReturnValue({}),
        DispatchAction: jest.fn(),
        SubscribeToPartnerState: jest.fn(),
        GetPartnerState: jest.fn().mockReturnValue({
            userReducer: {
                currentUser: {}
            }
        }),
    })
}

export const mockLocations = [{
    id: 5,
    name: "Cambridge",
    address: "2 Canal Park, 02141",
    shortName: "PHSCM01",
    modalityList: [
        {
            id: 2,
            modality: "CT"
        },
        {
            id: 1,
            modality: "MR"
        }
    ],
    roomsFetched: true,
    locationContacts: [
        {
            id: "fd159095",
            name: "Psycology tower - 1",
            phoneNumber: "1234567890",
            clinicalRole: "Frontdesk"
        }
    ],
    totalRooms: 0
}]

export const rooms: IRoomDetails[] = [
    {
        identity: {
            id: 37,
            name: "CT Analytics Scanner 04",
            uuid: "e404fb07-1e53-4183-ad8b-5e6a4827abe1",
            address: "Trauma Department"
        },
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        address: "Trauma Department",
        locationId: 4,
        modalityId: "2",
        modality: "CT",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isConnecting: false,
        isRoomStarred: true,
        monitorsCount: 3,
        loggedInTech: { techUuid: "", techName: "" }
    },
    {
        identity: {
            id: 25,
            name: "CT Analytics Scanner 05",
            uuid: "d751ffae-4e64-42e5-84a3-318414ad8fcd",
            address: "Trauma Department"
        },
        address: "Trauma Department",
        monitorsCount: 3,
        locationId: 4,
        modality: "CT",
        modalityId: "2",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isRoomStarred: false,
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        isConnecting: false,
        loggedInTech: { techUuid: "", techName: "" }
    },
    {
        identity: {
            id: 29,
            name: "CT Analytics Scanner 06",
            uuid: "4b095617-e3c0-491d-84fc-4a12b3eefccb",
            address: "Trauma Department"
        },
        address: "Trauma Department",
        monitorsCount: 3,
        locationId: 4,
        modality: "CT",
        modalityId: "2",
        favourite: false,
        phoneNumber: "+1 4252432344",
        disabled: false,
        isRoomStarred: false,
        presenceData: {
            presence: EUserPresence.AVAILABLE,
            mapId: ""
        },
        isConnecting: false,
        loggedInTech: { techUuid: "", techName: "" }
    }
]
