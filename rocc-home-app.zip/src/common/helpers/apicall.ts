/*
 * Created on weds Jul 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { AxiosHandler } from "@rocc/rocc-http-client"
import { infoLogger } from "@rocc/rocc-logging-module"
import { CURRENT_APP_NAME } from "../../constants/constants"


export let roccHttpClient: AxiosHandler = new AxiosHandler()
export const setupAxiosHandler = (httpClient: AxiosHandler) => {
    roccHttpClient = httpClient
    infoLogger(`Reusing ROCC axios handler from parent app in current app: ${CURRENT_APP_NAME}`)
}
export const postCall = (params: any) => {
    return roccHttpClient.postCall({ url: params.url, data: params.body, headers: params.headers })
}
export const putCall = (params: any) => {
    return roccHttpClient.putCall({ url: params.url, data: params.body, headers: params.headers })
}
export const deleteCall = (params: any) => {
    return roccHttpClient.deleteCall({ url: params.url, data: params.body, headers: params.headers })
}
export const getCall = (params: any) => {
    return roccHttpClient.getCall({ url: params.url, data: params.body, headers: params.headers })
}
export const postService = (params: any) => {
    return roccHttpClient.postService({ url: params.url, data: params.body, headers: params.headers })
}
export const putService = (params: any) => {
    return roccHttpClient.putService({ url: params.url, data: params.body, headers: params.headers })
}
export const deleteService = (params: any) => {
    return roccHttpClient.deleteService({ url: params.url, data: params.body, headers: params.headers })
}
export const getService = (params: any) => {
    return roccHttpClient.getService({ url: params.url, data: params.body, headers: params.headers })
}
export const safeURL = (url: string, uri: string) => url.endsWith(uri) ? url : `${url}${uri}`
export const refreshToken = () => roccHttpClient.refreshToken()
