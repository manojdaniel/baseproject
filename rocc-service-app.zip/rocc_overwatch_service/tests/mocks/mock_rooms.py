import string
from src.constants.headers import *
from tests.mocks.random import randint, rand_string


def prepare_room_db_mapping(room_dict):
    room_mapping = {
        room_id: {
            "name": room[EXCEL_ROOM_FULL_NAME],
            "resource": room[EXCEL_ROOM_IDENTIFIER],
            "site_id": room["site_id"],
            "external_system_id": 1,
            "modality_id": room["modality_id"],
            "resource_uuids": {
                "data": {
                    "uuid": room["device_id"]
                }
            },
            "resource_devices": {
                "data": {
                    "resourceByDeviceId": {
                        "data": {
                            "device_id": room["device_id"],
                            "device_name": room[EXCEL_ROOM_IDENTIFIER]
                        }
                    }
                }
            },
            "kvm_connection_details": {
                "data": [{
                    "tx_connection_ip": room[EXCEL_ROOM_TRANSMITTER_IP],
                    "tx_connection_name": room[EXCEL_ROOM_EDIT_CONNECTION],
                    "tx_connection_type": "full_control"
                }, {
                    "tx_connection_ip": room[EXCEL_ROOM_TRANSMITTER_IP],
                    "tx_connection_name": room[EXCEL_ROOM_VIEW_CONNECTION],
                    "tx_connection_type": "view"
                }]
            },
            "resourcesByResourcesDemoId": {
                "data": [{
                    "demographic": room[EXCEL_ROOM_PHONE_NUMBER],
                    "demographic_type_id": rand_string(10, corpus=string.digits)
                }, {
                    "demographic": room[EXCEL_ROOM_LOCATION],
                    "demographic_type_id": rand_string(10)
                }]
            }
        } for room_id, room in room_dict.items()
    }

    room_mapping_scanner = {room_id: dict(room_mapping[room_id], **{
        "manufacturer": room[EXCEL_ROOM_SCANNER_MANUFACTURER],
        "model": room[EXCEL_ROOM_SCANNER_MODEL],
        "serial_number": room[EXCEL_ROOM_SCANNER_SERIAL_NUMBER],
        "dicom_ae_title": room[EXCEL_ROOM_SCANNER_DICOM_AE_TITLE],
        "scanner_software_version": room[EXCEL_ROOM_SCANNER_SOFTWARE_VERSION],
        "scanner_os_type": room[EXCEL_ROOM_SCANNER_OS],
        "scanner_os_version": room[EXCEL_ROOM_SCANNER_OS_VERSION],
        "notes": room[EXCEL_ROOM_SCANNER_NOTES],
    }) for room_id, room in room_dict.items()}

    return room_mapping, room_mapping_scanner


def generate_mock_rooms(newCount=1, existingCount=1):
    """ Generates Mock rooms for tests
    Returns rooms_dict and a rooms_dict_scanner for testing
    """
    room_props = {
        "site_id": randint(0, 100),
        "device_id": rand_string(36, corpus=string.ascii_uppercase + "-" + string.digits),
        "modality_id": randint(0, 100),
        EXCEL_ROOM_IDENTIFIER: rand_string(10),
        EXCEL_ROOM_FULL_NAME: rand_string(10),
        EXCEL_ROOM_TRANSMITTER_IP: f"{randint(0, 255)}.{randint(0, 255)}.{randint(0, 255)}.{randint(0, 255)}",
        EXCEL_ROOM_EDIT_CONNECTION: rand_string(10),
        EXCEL_ROOM_VIEW_CONNECTION: rand_string(10),
        EXCEL_ROOM_PHONE_NUMBER: rand_string(10, corpus=string.digits),
        EXCEL_ROOM_LOCATION: rand_string(10),
        EXCEL_ROOM_SCANNER_MANUFACTURER: rand_string(10),
        EXCEL_ROOM_SCANNER_MODEL: rand_string(10),
        EXCEL_ROOM_SCANNER_SERIAL_NUMBER: rand_string(10),
        EXCEL_ROOM_SCANNER_DICOM_AE_TITLE: "41TH7UL",
        EXCEL_ROOM_SCANNER_SOFTWARE_VERSION: f"{randint(0, 255)}.{randint(0, 255)}.{randint(0, 255)}",
        EXCEL_ROOM_SCANNER_OS: rand_string(10),
        EXCEL_ROOM_SCANNER_OS_VERSION: rand_string(10),
        EXCEL_ROOM_SCANNER_NOTES: rand_string(255),
    }

    room_props_scanner = dict(room_props, **{
        EXCEL_ROOM_SCANNER_MANUFACTURER: rand_string(10),
        EXCEL_ROOM_SCANNER_MODEL: rand_string(10),
        EXCEL_ROOM_SCANNER_SERIAL_NUMBER: rand_string(10),
        EXCEL_ROOM_SCANNER_DICOM_AE_TITLE: "41TH7UL",
        EXCEL_ROOM_SCANNER_SOFTWARE_VERSION: f"{randint(0, 255)}.{randint(0, 255)}.{randint(0, 255)}",
        EXCEL_ROOM_SCANNER_OS: rand_string(10),
        EXCEL_ROOM_SCANNER_OS_VERSION: rand_string(10),
        EXCEL_ROOM_SCANNER_NOTES: rand_string(255),
    })

    new_rooms_dict = {
        rand_string(10): dict({
            "eligibility": {
                "new_room": True,
            },
        }, **room_props) for _ in range(newCount)
    }

    existing_rooms_dict = {
        rand_string(10): dict({
            "eligibility": {
                "new_room": False,
            },
        }, **room_props) for _ in range(existingCount)
    }

    new_rooms_dict_scanner = {
        rand_string(10): dict({
            "eligibility": {
                "new_room": True,
            },
        }, **room_props_scanner) for _ in range(newCount)
    }

    existing_rooms_dict_scanner = {
        rand_string(10): dict({
            "eligibility": {
                "new_room": False,
            },
        }, **room_props_scanner) for _ in range(existingCount)
    }

    return dict(new_rooms_dict, **existing_rooms_dict), dict(new_rooms_dict_scanner, **existing_rooms_dict_scanner)
