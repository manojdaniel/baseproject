## Commit guidelines for Auto Versioning

Please follow the Conventional Commits Specification while committing the changes:
https://www.conventionalcommits.org/en/v1.0.0/

On raising PR the 'Lint PR commits' step in the GitHub Action workflow validates all the commits. PR tends to fail if the commits doesn't follow the convention.

In CHANGELOG and release notes only the information related to Breaking Changes, Features and Bug Fixes will be generated. 

The following convention types can be used to account for the PATCH, MINOR and MAJOR version change:

* fix: a commit of the type fix patches a bug in your codebase (this correlates with **PATCH** in Semantic Versioning).

    * Example:

      fix: correct typos in code

* feat: a commit of the type feat introduces a new feature to the codebase (this correlates with **MINOR** in Semantic Versioning).

    * Example: 

      feat: allow provided config object to extend other configs

* BREAKING CHANGE: a commit that has a footer BREAKING CHANGE:, or appends a ! after the type/scope, introduces a breaking API change (correlating with **MAJOR** in Semantic Versioning). A BREAKING CHANGE can be part of commits of any type.

    * Example: Commit message with description and breaking change footer

      feat: allow provided config object to extend other configs

      BREAKING CHANGE: extends key in config file is now used for extending other config files


Other types that can be used are mentioned below:

* chore: Other changes that don't modify src or test files.
* ci: Changes to our CI configuration files and scripts (example scopes: Travis, Circle, BrowserStack, SauceLabs).
* docs: Documentation only changes.
* perf: A code change that improves performance.
* refactor: A code change that neither fixes a bug or adds a feature.
* style: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc).
* test: Adding missing tests or correcting existing tests.
* revert: Reverts a previous commit.
* build: Changes that affect the build system or external dependencies (example scopes: gulp, broccoli, npm).

## Release process

Actions job generates CHANGELOG automatically and creates GitHub release, and version bumps for your checkins by parsing git history. It does so by looking for [Conventional Commit messages](https://www.conventionalcommits.org/). It creates a release PR.

### What's a Release PR?

Rather than continuously releasing what's landed to default branch, Actions job  maintains Release PRs:

<img width="400" src="/release-please.png">

This Release PR is kept up-to-date as additional work is merged. When you're ready to tag a release, simply merge the release PR.