"""
 Created on Thu Nov 26 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import configparser
from src.constants.config_keys import VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, VAULT_ROOT_SERVICE_AUTH_ISSUER, VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY
from src.loggers.log import create_logger
from src.wrappers.cf.cf_utility import get_vault_credentials
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, post_vault_values_for_path

LOG = create_logger("CLIUtility")

SERVICE_CONF_FILE_PATH = "cli_utility/configs/config.ini"
CONF = configparser.RawConfigParser()
CONF.read(SERVICE_CONF_FILE_PATH, encoding="utf-8")


def fetch_config_value(key):
    switcher = {
        "LOG_INGESTER_URL": CONF.get("DEFAULT", "LOG_INGESTER_URL"),
        "ENV": CONF.get("DEFAULT", "ENV"),
        "PROFILE": CONF.get("VAULT", "PROFILE"),
        "ROLE_ID": CONF.get("VAULT", "ROLE_ID"),
        "SECRET_ID": CONF.get("VAULT", "SECRET_ID"),
        "URL": CONF.get("VAULT", "URL"),
        "USERNAME": CONF.get("DEFAULT", "USER_NAME"),
        "PASSWORD": CONF.get("DEFAULT", "PASSWORD"),
        "ROOT_ORG_IAM_CLIENT_ID": CONF.get("DEFAULT", "ROOT_ORG_IAM_CLIENT_ID"),
        "ROOT_ORG_IAM_CLIENT_SECRET": CONF.get("DEFAULT", "ROOT_ORG_IAM_CLIENT_SECRET"),
        "SELFSERVICE_PROFILE": CONF.get("VAULT", "SELFSERVICE_PROFILE"),
        "CRM_CLIENT_SECRET_KEY": CONF.get("DEFAULT", "CRM_CLIENT_SECRET_KEY"),
        "CRM_KEY": CONF.get("DEFAULT", "CRM_KEY")
    }
    return switcher.get(key)


def fetch_profile_configs_for_cli():
    profile_configs = None
    vault_credentials_response = None
    profile_path = CONF.get("VAULT", "PROFILE")
    try:
        vault_credentials_response = get_vault_credentials(role_id=CONF.get("VAULT", "ROLE_ID"),
                                                           secret_id=CONF.get("VAULT", "SECRET_ID"),
                                                           vault_url=CONF.get("VAULT", "URL"))
        profile_configs = get_path_specific_vault_values(path_name=profile_path,
                                                         vault_credentials_response=vault_credentials_response)

    except Exception as ex:
        LOG.exception(f"Failed to load vault data with error: {ex}")

    return profile_configs["data"], vault_credentials_response, profile_path

def fetch_selfservice_profile_configs_for_cli(vault_credentials):
    selfservice_profile_configs = None
    vault_credentials_response = None
    selfservice_profile_path = CONF.get("VAULT", "SELFSERVICE_PROFILE")
    try:
        response = get_path_specific_vault_values(path_name=selfservice_profile_path,
                                                         vault_credentials_response=vault_credentials)

    except Exception as ex:
        LOG.exception(f"Failed to load self service vault data with error: {ex}")

    if response is not None:
        selfservice_profile_configs = response["data"]

    return selfservice_profile_configs, selfservice_profile_path


def prompt_and_get_rocc_url():
    env = CONF.get("DEFAULT", "ENV")
    env = env[5:] if env.startswith("rocc-") else env
    ROCC_PROXY_URL = f"https://rocc-nginx-{env}.cloud.pcftest.com"
    option = input(f"""
=======================================================================================================================\n\n
Using follwing url as ROCC_PROXY_URL => {ROCC_PROXY_URL}\n\n
============================================================
Enter '1' to proceed or '2' to correct the url ['1' / '2']: """)
    if option == "2":
        ROCC_PROXY_URL = input("Enter the ROCC_PROXY_URL in format: https://rocc-nginx-<env>.cloud.pcftest.com: ")
    return ROCC_PROXY_URL


def check_and_update_profile_configs_in_vault(**kwargs):
    """ 
    1. Get path data
    2. Update all key-values from **kwargs in response
    3. Store the updated response
    """
    profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
    for key, value in kwargs.items():
        profile_configs[key] = value
    post_vault_values_for_path(path=profile_path,
                               body=profile_configs,
                               vault_credentials_response=vault_credentials_response)


def fetch_service_token():
    profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
    parent_token = create_service_token_from_vault(iam_url=profile_configs["HSDP_IAM_URL"],
                                                   issuer=profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                   private_key=profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
    print(f"parent_token: {parent_token}")
    root_token = create_service_token_from_vault(iam_url=profile_configs["HSDP_IAM_URL"],
                                                 issuer=profile_configs[VAULT_ROOT_SERVICE_AUTH_ISSUER],
                                                 private_key=profile_configs[VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY])
    print(f"root_token: {root_token}")
