#!/usr/bin/env sh
echo "";
echo "Start creating network policies...";
echo "";

CF=$(which cf)

if [ -n "$CF" ]; then
    $CF add-network-policy rocc-nginx-{target_env} --destination-app rocc-cc-host-{target_env} --protocol tcp --port 8080
    $CF add-network-policy rocc-cc-host-{target_env} --destination-app rocc-nginx-{target_env} --protocol tcp --port 8080
    $CF add-network-policy rocc-cc-host-{target_env} --destination-app rocc-console-app-{target_env} --protocol tcp --port 8080
    $CF add-network-policy rocc-cc-host-{target_env} --destination-app rocc-calling-app-{target_env} --protocol tcp --port 8080
else
    echo "Cannot find cf binary in your path, please install the latest cf cli tools."
fi

echo "";
echo "Network policy creation is done."
