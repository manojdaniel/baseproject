#!/bin/bash
echo "Reading config...."
cd ..
. graphql.cfg #note the space between the dot and the leading slash of /etc.cfg
#source graphql.cfg
cd -
status_code=$(curl --write-out %{http_code} \
 --request POST \
 --header "Content-Type:application/json" \
 --header "X-Hasura-Role:$graphql_role" \
 --header "X-Hasura-Access-Key:$graphql_secret_key" \
 -d @table_permissions.json \
 --url $graphql_api \
 -so "table_permissions.log" \
 --noproxy "*")

if [[ "$status_code" == 200 ]] ; then
  echo "Successfully added table permissions in rocc schema to GraphQL-Engine"
else
  echo "Error while adding table permissions in rocc schema to GraphQL-Engine"
  echo "Please refer to log file table_permissions.log!"
fi

status_code=$(curl --write-out %{http_code} \
 --request POST \
 --header "Content-Type:application/json" \
 --header "X-Hasura-Role:$graphql_role" \
 --header "X-Hasura-Access-Key:$graphql_secret_key" \
 -d @reload_metadata.json \
 --url $graphql_api \
 -so "reload_metadata.log" \
 --noproxy "*")

if [[ "$status_code" == 200 ]] ; then
  echo "Successfully reloaded all metadata in GraphQL-Engine"
else
  echo "Error while reloading metadata in GraphQL-Engine"
  echo "Please refer to log file reload_metadata.log!"
fi
