/*
 * Created on Mon Aug 1 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { isNowBetweenRange } from "@rocc/rocc-client-services"
import { errorLogger } from "@rocc/rocc-logging-module"
import jwtDecode, { JwtPayload } from "jwt-decode"
import store from "../../redux/store/store"

type AuthJwtPayload = {
    [K in keyof Exclude<JwtPayload, "iat" | "jti">]-?: JwtPayload[K]
}

export const validateAuthToken = (jwtToken: string, roomUuid: string) => {
    try {
        const { iss: techUserId, aud: requesterUuid, ...tokenProps } = jwtDecode<AuthJwtPayload>(jwtToken)
        if (!isNowBetweenRange(tokenProps.nbf, tokenProps.exp)) {
            return false
        }

        const state = store.getState()
        const { currentUser } = state.externalReducer

        if (!(requesterUuid !== currentUser.uuid || techUserId !== roomUuid)) {
            return false
        }

        // TODO: [MARKER] More validation
    } catch (ex) {
        errorLogger(`An error occurred while testing integrity of JWT token: ${ex}`)
        return false
    }

    return true
}
