/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import thunk from "redux-thunk"
import rootReducer from "../reducers/rootReducer"
import globalStore from "./globalStore"
import { persistStore, persistReducer } from "redux-persist"
import storageSession from "redux-persist/lib/storage/session"
import hardSet from "redux-persist/lib/stateReconciler/hardSet"
import { CURRENT_APP_NAME, STORAGE_KEY } from "../../constants/constants"
import { IStore } from "../interfaces/types"
import { Store } from "redux"

const persistConfig = {
    key: `${CURRENT_APP_NAME}_${STORAGE_KEY}`,
    storage: storageSession,
    stateReconciler: hardSet,
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store: Store<IStore> = globalStore.CreateStore(CURRENT_APP_NAME, persistedReducer, [thunk], [])

export const persistor = persistStore(store)

export default store
