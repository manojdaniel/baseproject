import React, { useRef, useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
	// getAffiliateDropdownList,
	// getPlantDropdownList,
	// getAssetDropdownList,
	getAssetModelConfigTableData,
	updateAssetModelConfigTableStatus,
	getAnomalyModelbyAssetId,
	getGraphicalImageByAssetId,
	getAssetModelConfigDropdownList,
	getAssetModelConfigAffiliateDropdownList,
	getAssetModelConfigPlantDropdownList,
	updateAssetModelConfigResponseStatus,
} from "../../../redux/reducers/CommonReducer";
import "./AssetModelConfig.scss";
import Dropdown from "components/Dropdown";
import AssetModelConfigTable from "table/AssetModelConfigTable";
import Loader from "components/Loader";
import AdminAssetModel from "charts/AdminAssetModel";
import PushNotification from "components/PushNotification";
import axios from "axios";
import { BASE_URL2, Api } from "../../../utility/api";
import { encryptRSAData } from "../../../utility/rsa";

const AssetModelConfig = () => {
	let dispatch = useDispatch();
	const [selectedAssetId, setSelectedAssetId] = useState<any>();
	const [selectedAffiliate, setSelectedAffiliate] = useState<any>();
	const [selectedPlant, setSelectedPlant] = useState<any>();
	const [loading, setLoading] = useState<any>(false);

	const [parentData, setParentData] = useState<any>([]);
	const [data, setData] = useState<any>();
	const userId = 18;

	const {
		// affiliateDropdownList,
		// plantDropdownList,
		// assetDropdownList,
		// loadingAffiliateDropdownList,
		// loadingPlantDropdownList,
		// loadingAssetDropdownList,
		assetModelConfigTableData,
		loadingAssetModelConfigTableData,
		GraphicalImageByAssetId,
		assetModelConfigDropdown,
		loadingAssetModelConfigDropdown,
		assetModelConfigAffiliateDropdown,
		loadingAssetModelConfigAffiliateDropdown,
		assetModelConfigPlantDropdown,
		loadingAssetModelConfigPlantDropdown,
		assetModelConfigTableStatus,
	} = useSelector((state: any) => ({
		affiliateDropdownList: state.Common.affiliateDropdownList,
		plantDropdownList: state.Common.plantDropdownList,
		assetDropdownList: state.Common.assetDropdownList,
		assetModelConfigTableData: state.Common.assetModelConfigTableData,
		assetModelConfigDropdown: state.Common.assetModelConfigDropdown,
		assetModelConfigAffiliateDropdown:
			state.Common.assetModelConfigAffiliateDropdown,
		assetModelConfigPlantDropdown: state.Common.assetModelConfigPlantDropdown,

		loadingAffiliateDropdownList: state.Common.loadingAffiliateDropdownList,
		loadingPlantDropdownList: state.Common.loadingPlantDropdownList,
		loadingAssetDropdownList: state.Common.loadingAssetDropdownList,
		loadingAssetModelConfigTableData:
			state.Common.loadingAssetModelConfigTableData,
		loadingAssetModelConfigDropdown:
			state.Common.loadingAssetModelConfigDropdown,
		loadingAssetModelConfigAffiliateDropdown:
			state.Common.loadingAssetModelConfigAffiliateDropdown,
		loadingAssetModelConfigPlantDropdown:
			state.Common.loadingAssetModelConfigPlantDropdown,

		GraphicalImageByAssetId: state.Common.GraphicalImageByAssetId,
		assetModelConfigTableStatus: state.Common.assetModelConfigTableStatus,
	}));

	useEffect(() => {
		dispatch(getAssetModelConfigAffiliateDropdownList(""));
	}, []);

	useEffect(() => {
		if (
			assetModelConfigTableStatus.length > 0 &&
			selectedAssetId !== "" &&
			selectedAssetId !== undefined
		) {
			if (!assetModelConfigTableStatus.hasOwnProperty("Succeeded")) {
				if (assetModelConfigTableStatus[0].retVal === 1) {
					PushNotification("success", assetModelConfigTableStatus[0].retMsg);
					let data = {
						plantId: selectedPlant.value,
						assetId: selectedAssetId.value,
						userId: userId,
					};
					dispatch(
						getGraphicalImageByAssetId(
							encryptRSAData(
								`plantId=${selectedPlant.value}&assetId=${selectedAssetId.value}`
							)
						)
					);
					dispatch(
						getAssetModelConfigTableData(
							encryptRSAData(
								`plantId=${selectedPlant.value}&assetId=${selectedAssetId.value}`
							)
						)
					);
				} else {
					PushNotification("error", assetModelConfigTableStatus[0].retMsg);
				}
			} else {
				PushNotification("error", assetModelConfigTableStatus.Message);
			}
			const emptyObj = [];
			dispatch(updateAssetModelConfigResponseStatus(emptyObj));
		} else {
			// if (assetModelConfigTableStatus.hasOwnProperty('Succeeded')) {
			//     PushNotification('error', assetModelConfigTableStatus.Message)
			// }
		}
	}, [assetModelConfigTableStatus]);

	useEffect(() => {
		//  alert(selectedAssetId)

		if (selectedAssetId !== "" && selectedAssetId !== undefined) {
			let data = {
				plantId: selectedPlant.value,
				assetId: selectedAssetId.value,
				userId: userId,
			};
			dispatch(
				getGraphicalImageByAssetId(
					encryptRSAData(
						`plantId=${selectedPlant.value}&assetId=${selectedAssetId.value}`
					)
				)
			);
		}
	}, [selectedAssetId]);

	useEffect(() => {
		if (assetModelConfigTableData.length > 0) {
			let result: any[] = [];
			assetModelConfigTableData.forEach((item: any) => {
				result.push({
					assetId: item.assetId,
					sensorGroupId: item.sensorGroupId,
					modelName: item.modelName,
					x: item.xCoordinate,
					y: item.yCoordinate,
					assetSapId: item.assetSapId,
				});
			});
			setParentData(result);
		}
	}, [assetModelConfigTableData]);

	useEffect(() => {
		if (parentData.length > 0) {
			let mydata = parentData.map(function (item: any) {
				return {
					assetId: item.assetId,
					sensorGroupId: item.sensorGroupId,
					modelName: item.modelName,
					assetSapId: item.assetSapId,
					x: (
						<input
							value={item.x}
							onKeyPress={handleKeyPress}
							onChange={(e) => handleOnXChange(item.modelName, e)}
						/>
					),
					y: (
						<input
							value={item.y}
							onKeyPress={handleKeyPress}
							onChange={(e) => handleOnYChange(item.modelName, e)}
						/>
					),
				};
			});
			setData(mydata);
		}
	}, [parentData]);

	const handleAffiliateDropDown = (e: any) => {
		setSelectedAffiliate(e);
		setSelectedPlant("");
		setSelectedAssetId("");
		dispatch(
			getAssetModelConfigPlantDropdownList(
				encryptRSAData(`affilliateId=${e.value}`)
			)
		);
	};

	const handlePlantDropDown = (e: any) => {
		setSelectedPlant(e);
		setSelectedAssetId("");
		dispatch(
			getAssetModelConfigDropdownList(
				encryptRSAData(
					`affilliateId=${selectedAffiliate.value}&plantId=${e.value}`
				)
			)
		);
	};
	const handleAssetDropDown = (e: any) => {
		setSelectedAssetId(e);
		dispatch(
			getAssetModelConfigTableData(
				encryptRSAData(`plantId=${selectedPlant.value}&assetId=${e.value}`)
			)
		);
	};

	const handleKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[.0-9-]+$/i.test(keyValue)) event.preventDefault();
	};

	const handleOnXChange = (name: any, e: any) => {
		// let list = parentData;
		// let cards = list.map((item: any) => ({
		//     ...item,
		//     x: item.modelName === name ? e.target.value : item.x
		// }))
		// setParentData(cards)
		setParentData((prevState: any) => {
			// Loop over your list
			return prevState.map((item: any) => {
				// Check for the item with the specified id and update it
				return item.modelName === name ? { ...item, x: e.target.value } : item;
			});
		});
	};
	const handleOnYChange = (name: any, e: any) => {
		let list = parentData;
		let cards = list.map((item: any) => ({
			...item,
			y: item.modelName === name ? e.target.value : item.y,
		}));
		setParentData(cards);
	};

	const handleSubmit = () => {
		// PushNotification('success', 'x and y coordinates updated succesfully')
		if (
			selectedAssetId === "" ||
			selectedAssetId === undefined ||
			Object.keys(selectedAssetId).length < 0
		) {
			PushNotification("error", "Please select Asset");
		} else {
			handleApiCall(parentData);
		}

		// dispatch(updateAssetModelConfigTableStatus(parentData))
	};

	const handleApiCall = (data: any) => {
		let result: any[] = [];
		data.forEach((item: any) => {
			result.push({
				sensorGroupId: item.sensorGroupId,
				assetSapId: item.assetSapId,
				xCoordinate: item.x,
				yCoordinate: item.y,
			});
		});
		//  setLoading(true)
		// axios({
		//     method: 'post',
		//     url: `${Api.updateAssetModelConfigDetails}`,
		//     headers: {
		//         'Content-Type': 'application/json',
		//     },
		//     data: result
		// }).then((response) => {
		//     setLoading(false)

		//     if (response.data[0].retVal === 1) {
		//         PushNotification('success', response.data[0].retMsg)
		//         let data = { assetId: selectedAssetId.value, userId: userId }
		//         dispatch(getGraphicalImageByAssetId(data));
		//         dispatch(getAssetModelConfigTableData(`${selectedAssetId.value.value}/18`));
		//     }
		//     else {
		//         PushNotification('error', response[0].retMsg)
		//     }
		// }).catch((error) => {
		//     setLoading(false)

		// })
		dispatch(updateAssetModelConfigTableStatus(result));
	};

	const LeftComponent = useMemo(() => {
		return (
			<AdminAssetModel
				GraphicalImageByAssetId={GraphicalImageByAssetId}
				mysensorGroupId={""}
				AnomalyModelbyAssetId={[]}
			/>
		);
	}, [GraphicalImageByAssetId]);

	return (
		<div id="assetModelConfig-page">
			{loadingAssetModelConfigTableData ? <Loader /> : null}
			<div className="assetModelConfig-left-container">
				<div className="common-box-inner">
					<div className="title">GRAPHICAL OVERVIEW</div>
					{LeftComponent}
					{/* <AdminAssetModel
                    GraphicalImageByAssetId={GraphicalImageByAssetId}
                    mysensorGroupId={""}
                    AnomalyModelbyAssetId={[]}
                    /> */}
				</div>
			</div>
			<div className="assetModelConfig-right-container">
				<div className="common-box-inner">
					<div className="arc-options">
						<div>
							<span className="cus-label">AFFILATE</span>
							<Dropdown
								name={"Select Affiliate"}
								options={assetModelConfigAffiliateDropdown}
								handleChange={handleAffiliateDropDown}
								defaultValue={""}
								value={selectedAffiliate}
								loading={loadingAssetModelConfigAffiliateDropdown}
							/>
						</div>
						<div>
							<span className="cus-label">PLANT</span>
							<Dropdown
								name={"Select Plant"}
								handleChange={handlePlantDropDown}
								options={assetModelConfigPlantDropdown}
								defaultValue={""}
								value={selectedPlant}
								loading={loadingAssetModelConfigPlantDropdown}
							/>
						</div>
						<div>
							<span className="cus-label">ASSET ID</span>
							<Dropdown
								name={"Asset ID"}
								handleChange={handleAssetDropDown}
								options={assetModelConfigDropdown}
								value={selectedAssetId}
								defaultValue={""}
								loading={loadingAssetModelConfigDropdown}
							/>
						</div>
					</div>

					{/* <div className="arc-upload">
                        <div>
                            Asset Image
                        </div>
                        <div>
                            File Upload
                        </div>
                    </div> */}
					{loadingAssetModelConfigTableData ? (
						<Loader />
					) : (
						<AssetModelConfigTable data={data} />
					)}
					<div className="acr-submit">
						<button onClick={() => handleSubmit()}>SUBMIT</button>
					</div>
				</div>{" "}
			</div>
		</div>
	);
};
export default AssetModelConfig;
