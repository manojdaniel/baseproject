import React, { useRef, useEffect, useState } from "react";
import GraphicalOverview from "charts/GraphicalOverview";
import LiveModel from "table/LiveModel";
import "./AssetModel.scss";
import Graph from "../../../assets/images/Graph.png";
import Tooltipgraph from "../../../assets/images/tooltipgraph.png";
import Loader from "components/Loader";
import { useDispatch, useSelector } from "react-redux";
import {
	getassetlistOfAssetModelByplantid,
	getAnomalyModelbyAssetId,
	getFailurepreDictionByAssetId,
	getGraphicalImageByAssetId,
	getAssetKPI,
	getAssetDropdownList,
	getGlobalSelecetedAsset,
	getFailurePopupDataFun,
	getFailurePopupDataFunEmpty,
} from "../../../redux/reducers/CommonReducer";
import { useLocation } from "react-router-dom";
import Dropdown from "components/Dropdown";
import PerformanceCurveChart from "charts/PerformanceCurveChart";
import { encryptRSAData } from "../../../utility/rsa";
import NoData from "components/NoData";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const AssetModel = () => {
	const [selectedAssetId, setSelectedAssetId] = useState<any>();
	const [sensorGroupId, setSensorGroupId] = useState<any>();
	const [selectedAssetIdLabel, setSelectedAssetIdLabel] = useState<any>();
	const [assetData, setAssetData] = useState<any>();

	const [showPopup, setShowPopup] = useState<any>(false);
	const [showPopup2, setShowPopup2] = useState<any>(false);

	let dispatch = useDispatch();

	const {
		assetlistOfAssetModelByplantid,
		AnomalyModelbyAssetId,
		FailurepreDictionByAssetId,
		plotAssetDropDown,
		GraphicalImageByAssetId,
		AssetKPIForAssetModel,
		searchValue,
		globalSelecetedAsset,
		assetDropdownList,
		globalSelecetedPlant,
		loadingGraphicalImageByAssetId,
		getFailurePopupData,
		getFailurePopupOpen,
		loadinggetAnomalyModelbyAssetId,
	} = useSelector((state: any) => ({
		assetlistOfAssetModelByplantid: state.Common.assetlistOfAssetModelByplantid,
		AnomalyModelbyAssetId: state.Common.AnomalyModelbyAssetId,
		FailurepreDictionByAssetId: state.Common.FailurepreDictionByAssetId,
		GraphicalImageByAssetId: state.Common.GraphicalImageByAssetId,
		AssetKPIForAssetModel: state.Common.AssetKPIForAssetModel,
		searchValue: state.Common.searchValue,
		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		assetDropdownList: state.Common.assetDropdownList,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		plotAssetDropDown: state.Common.plotAssetDropDown,

		loadingGraphicalImageByAssetId: state.Common.loadingGraphicalImageByAssetId,
		loadinggetAnomalyModelbyAssetId:
			state.Common.loadinggetAnomalyModelbyAssetId,

		getFailurePopupData: state.Common.getFailurePopupData,
		getFailurePopupOpen: state.Common.getFailurePopupOpen,
	}));

	const handleAssetDropDown = (e: any) => {
		setSensorGroupId(undefined);
		setSelectedAssetId(e);
		setSelectedAssetIdLabel(e.value);
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
	};

	// useEffect(() => {
	//     let data = assetDropdownList.map(function (item: any) {
	//         return { value: item.assetId, label: item.assetId };
	//     });
	//     setAssetData(data.value);
	// }, []);

	const userId = 18;
	useEffect(() => {
		dispatch(getFailurePopupDataFunEmpty(""));

		if (Object.keys(globalSelecetedAsset).length > 0) {
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
			setSelectedAssetId(globalSelecetedAsset);
			setSelectedAssetIdLabel(globalSelecetedAsset.value);
		}
	}, [globalSelecetedAsset]);

	useEffect(() => {
		if (selectedAssetIdLabel !== "" && selectedAssetIdLabel !== undefined) {
			let data = {
				plantId: globalSelecetedPlant.value,
				assetId: selectedAssetIdLabel,
				userId: userId,
			};
			dispatch(
				getAnomalyModelbyAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAssetIdLabel}`
					)
				)
			);
			dispatch(
				getGraphicalImageByAssetId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAssetIdLabel}`
					)
				)
			);
			dispatch(
				getAssetKPI(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAssetIdLabel}`
					)
				)
			);
		}
	}, [selectedAssetIdLabel]);

	// PMT Health Index Tooltip nagivation in Assetmodel by asset id
	const location = useLocation();
	useEffect(() => {
		dispatch(getFailurePopupDataFunEmpty(""));
		try {
			// setRegionId(location.state.data.regionid)
		} catch (error) {}
	}, [location]);

	const openAssetPopup = () => {
		setShowPopup(true);
	};

	const popupFunc = (data: any) => {
		dispatch(getFailurePopupDataFun(data));
	};
	const popupFuncClose = () => {
		dispatch(getFailurePopupDataFunEmpty(""));
	};
	return (
		<div id="asset-model">
			<div id="asset-model-left">
				<div className="common-box-inner">
					<div className="title">GRAPHICAL OVERVIEW</div>
					<div id="new-filter">
						<div className="nf-left">
							<div className="asset-name">{selectedAssetIdLabel}</div>
						</div>
						<div className="nf-right">
							<div>
								<label className="cus-label">Asset ID</label>
								<Dropdown
									name={"Asset ID"}
									handleChange={handleAssetDropDown}
									options={assetDropdownList}
									value={selectedAssetId}
									defaultValue={""}
								/>
							</div>
						</div>
					</div>
					{/* <div className="asset-name">{searchValue.id}</div> */}
					<div className="asset-plot-graph">
						{loadingGraphicalImageByAssetId &&
						loadinggetAnomalyModelbyAssetId ? (
							<div className="tc-loaderpd">
								<Loader />
							</div>
						) : GraphicalImageByAssetId.length === 0 ? (
							<div className="tc-loaderpd">
								<NoData />
							</div>
						) : (
							<GraphicalOverview
								GraphicalImageByAssetId={GraphicalImageByAssetId}
								mysensorGroupId={sensorGroupId}
								AnomalyModelbyAssetId={AnomalyModelbyAssetId}
								popupFunc={popupFunc}
							/>
						)}
					</div>
				</div>
				<div className="asset-plot-status">
					<div className="asset-plot-status-left">
						{AssetKPIForAssetModel.length === 0 ? (
							<div className="kpi-loader"><NoData /></div>
						) : (
							<>
								{AssetKPIForAssetModel.map((item: any) => (
									<>
										{item.percentFlag === true && item.percentFlag !== null ? (
											<div className="asset-efficiency hovermeyaar">
												<span
													className={
														item.kpiTrend === true
															? "uparrow greeny"
															: "downarrow redy"
													}
												></span>
												<span>{item.kpi}</span>
												<span className="amhi-slider">
													{item.kpiPercent > 30 ? (
														<i
															className="abefore"
															style={{
																left: `calc(${item.kpiPercent}% - 87px)`,
															}}
														>
															{item.kpiValue !== null
																? item.kpiValue
																: "Poor Data"}{" "}
															{item.engUnits !== null
																? item.engUnits
																: "Poor Data"}
														</i>
													) : (
														<i
															className="aafter"
															style={{ left: `${item.kpiPercent}%` }}
														>
															{item.kpiValue !== null
																? item.kpiValue
																: "Poor Data"}{" "}
															{item.engUnits !== null
																? item.engUnits
																: "Poor Data"}
														</i>
													)}
												</span>
												<div className="asset-status-tooltip centerarr">
													<div className="asset-tooltip-text">
														<h3>What is {item.kpi}?</h3>
														<p>Description Here</p>
													</div>
												</div>
											</div>
										) : (
											<div className="asset-efficiency hovermeyaar">
												<span
													className={
														item.kpiTrend === true
															? "uparrow greeny"
															: "downarrow redy"
													}
												></span>
												<span>{item.kpi}</span>
												<span className="amhi-slider amhislider2">
													{item.kpiPercent > 30 ? (
														<i
															className="abefore"
															style={{
																left: `calc(${item.kpiPercent}% - 117px)`,
															}}
														>
															{item.kpiValue !== null
																? item.kpiValue
																: "Poor Data"}{" "}
															{item.engUnits !== null
																? item.engUnits
																: "Poor Data"}
														</i>
													) : (
														<i
															className="aafter"
															style={{ left: `${item.kpiPercent}%` }}
														>
															{item.kpiValue !== null
																? item.kpiValue
																: "Poor Data"}{" "}
															{item.engUnits !== null
																? item.engUnits
																: "Poor Data"}
														</i>
													)}
												</span>
												<div className="asset-status-tooltip centerarr">
													<div className="asset-tooltip-text">
														<h3>What is {item.kpi}?</h3>
														<p>Description Here</p>
													</div>
												</div>
											</div>
										)}
									</>
								))}
							</>
						)}
					</div>
					<div className="asset-plot-status-right">
						<div className="asset-status-graph">
							<a onClick={openAssetPopup}>
								<img src={Graph} />
							</a>
							{/* <div className="asset-status-tooltip asg-pos"><div className="asp-graph"><img src={Tooltipgraph} /></div></div> */}
						</div>
					</div>
				</div>
			</div>
			<div id="asset-model-right">
				<div className="asset-model-right-inner">
					{loadinggetAnomalyModelbyAssetId ? (
						<div className="tc-loaderpd">
							<Loader />
						</div>
					) : (
						<LiveModel
							loadinggetAnomalyModelbyAssetId={loadinggetAnomalyModelbyAssetId}
							AnomalyModelbyAssetId={AnomalyModelbyAssetId}
							setSensorGroupId={setSensorGroupId}
							selectedAssetIdGlobal={selectedAssetIdLabel}
							assetData={getFailurePopupData}
							popupFuncClose={popupFuncClose}
						/>
					)}
				</div>
			</div>
			{showPopup === true ? (
				<div id="asset-popup" className="performance-popup">
					<div id="ap-content">
						<span className="ap-closePopup" onClick={() => setShowPopup(false)}>
							x
						</span>
						<div className="ap-filter preformance-filter">
							<div className="ap-title">PERFORMANCE CURVE</div>
							<div id="ap-dropdown">
								<Dropdown
									name={"Asset ID"}
									handleChange={handleAssetDropDown}
									options={assetDropdownList}
									value={selectedAssetId}
									defaultValue={""}
								/>
							</div>
						</div>
						<div className="common-box-asset-name">
							<div className="ap-asset-name">{selectedAssetIdLabel}</div>
						</div>
						<PerformanceCurveChart />
					</div>
				</div>
			) : (
				""
			)}
		</div>
	);
};

export default AssetModel;
