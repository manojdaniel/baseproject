/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus, getDetailsByUUID, IAVCallDetails, IContactInfo, IMissedCallData } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "react"
import { CALL_ACCEPT, CALL_END, CALL_MESSAGES, CALL_MISSED, CALL_REJECT, HTTP_STATUS, TELEPRESENCE_SIDEBAR, TIMEOUT_10, TIMEOUT_1000, TIMEOUT_30000 } from "../../../../constants/constants"
import { AV_CALL_EP } from "../../../../constants/endpoints"
import { setCallMessage, setCallRingStatus, setIncomingCallDetails, setOutgoingCallDetails, setRecentMissedCall, setVideoCallStatus, storeCallDetails, updateCallTimeout } from "../../../../redux/actions/callActions"
import { GLOBAL_RIGHTSIDE_PANEL } from "../../../../redux/actions/types"
import { DEFAULT_INCOMING_CALL_DEATILS, DEFAULT_OUTGOING_CALL_DEATILS } from "../../../../redux/reducers/callReducer"
import { dispatchToParentStore, fetchGlobalURLs } from "../../../../redux/store/externalAppStates"
import store from "../../../../redux/store/store"
import en from "../../../../resources/translations/en-US"
import { registerMultiEditInitiateCallWorkflow, registerParkAndInitiateCallWorkflow } from "../../../../services/callServices"
import { putService } from "../../../helpers/apiUtility"
import { createICallStatusObject, filterCallStatusByContextId, upsertCallStatus } from "../../../helpers/callUtility"
import { checkToAllowMultiEdit, checkToAllowParkResume, getCustomrReducerFromGlobalStore, getTranslatedCallType, getUserReducerFromGlobalStore } from "../../../helpers/helpers"
import { createUrlCall } from "../messageService"
import { ICallAccept, ICallReject, ICallTimeOut, IParticipant } from "./types"
import { postMissedCallService } from "../../../../components/missed-call-panel/MissedCallServices"

export const getCallerSecondaryUuidIfAvailable = (callerUuid: string, participants: IParticipant[]) => {
    const participant = participants.find((participant: IParticipant) => (participant.primaryUuid === callerUuid))
    if (participant) {
        return (participant.secondaryUUID && participant.secondaryUUID.length) ? participant.secondaryUUID[0] : ""
    }
    return
}

export const onCallTimeout = (params: ICallTimeOut) => {
    const { caller, callee, contextId, isCallee, dispatch } = params
    const { intl } = getIntlProvider()
    const state = store.getState()
    const urls = fetchGlobalURLs()
    const { currentUser } = state.externalReducer

    const { CALLMISSED, CALLUNANSWERED } = CALL_MESSAGES

    dispatch(setCallRingStatus(false))

    infoLogger(`Call request between ${caller.uuid} & ${callee.uuid} is timed out`)

    dispatch(setVideoCallStatus(
        filterCallStatusByContextId(upsertCallStatus(contextId, ECallStatus.NOT_ANSWERED), "", false)
    ))

    videoCallHandler(CALL_MISSED, contextId)

    if (isCallee) {
        dispatch(setIncomingCallDetails(DEFAULT_INCOMING_CALL_DEATILS))
        dispatch(setCallMessage({
            messageType: getTranslatedCallType(CALLMISSED),
            message: `${intl.formatMessage({ id: "content.callMessages.missedCallFrom", defaultMessage: en["content.callMessages.missedCallFrom"] })} ${caller.name}`, contact: caller
        }))
    } else {
        dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
        dispatch(setCallMessage({
            messageType: getTranslatedCallType(CALLUNANSWERED),
            message: `${callee.name} ${intl.formatMessage({ id: "content.callMessages.missedCall", defaultMessage: en["content.callMessages.missedCall"] })}`, contact: callee
        }))
    }

    postMissedCallService(currentUser, urls.COMMUNICATION_SERVICES_URL, contextId, callee.uuid, caller.uuid)

    /** On callee side setting most recent missed call. */
    if (currentUser.uuid === callee.uuid) {
        setRecentMissedCallInRedux(contextId, caller.uuid, callee.uuid, dispatch)
    }
    dispatch(updateCallTimeout({ contextId, timeoutId: setTimeout(() => "", TIMEOUT_10) }, false))
}

export const onCallAcceptWithHoldWarning = async (props: ICallAccept) => {
    if (checkToAllowMultiEdit()) {
        registerMultiEditInitiateCallWorkflow({ contextId: props.contextId, contactUuid: props.contactUuid, modalTimeout: TIMEOUT_30000 })
    } else if (checkToAllowParkResume()) {
        registerParkAndInitiateCallWorkflow({ contextId: props.contextId, contactUuid: props.contactUuid, modalTimeout: TIMEOUT_30000 })
    } else {
        onCallAccept(props, false)
    }
}

export const onCallAccept = async (props: ICallAccept, enableHold: boolean) => {
    const { contextId, dispatch } = props
    const { CONNECTED, RESUMED, CALLING, CALLDECLINED, RINGING, CONNECTING, DISCONNECTED } = ECallStatus
    const state = store.getState()
    const { videoCallStatus } = state.callReducer
    dispatch(setCallRingStatus(false))
    dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: TELEPRESENCE_SIDEBAR, displayRightSidePanel: true, desktopFullScreen: false } })
    const updatedCallStatus = videoCallStatus.map((callStatus) => {
        if (callStatus.contextId === contextId && callStatus.callStatus === RINGING) {
            callStatus.callStatus = CONNECTING
        } else if ([CONNECTED, RESUMED].includes(callStatus.callStatus)) {
            if (enableHold) {
                // TODO: Make hold call redux action call here....
                // putCallAndConsoleOnHold(dispatch)
            } else {
                callStatus.callStatus = DISCONNECTED
            }
        } else if (callStatus.callStatus === CALLING) {
            callStatus.callStatus = CALLDECLINED
            videoCallHandler(CALL_REJECT, callStatus.contextId)
        } else {
            /* Fix Sonar issues */
        }
        return callStatus
    })
    dispatch(setVideoCallStatus(updatedCallStatus))
    await videoCallHandler(CALL_ACCEPT, contextId)
}

export const onCallReject = (props: ICallReject) => {
    const { intl } = getIntlProvider()
    const { setState, contextId, skipAudioPause, dispatch } = props
    if (!skipAudioPause) {
        dispatch(setCallRingStatus(false))
    }
    dispatch(updateCallTimeout({ contextId, timeoutId: setTimeout(() => "", TIMEOUT_10) }, false))

    const { RINGING, CALLDECLINED } = ECallStatus

    const state = store.getState()
    const { videoCallStatus } = state.callReducer

    if (!setState) {
        const updatedCallStatus = videoCallStatus.map((callStatus) => {
            if (callStatus.contextId === contextId && callStatus.callStatus === RINGING) {
                callStatus.callStatus = CALLDECLINED
                updateVideoCallStatus(contextId, false)
            }
            return callStatus
        })
        dispatch(setVideoCallStatus(updatedCallStatus))
    }
    dispatch(setCallMessage({
        messageType: getTranslatedCallType(CALLDECLINED),
        message: intl.formatMessage({ id: "content.callMessages.youDeclinedCall", defaultMessage: en["content.callMessages.youDeclinedCall"] }), contact: DEFAULT_CONTACT_INFO
    }))
    videoCallHandler(CALL_REJECT, contextId)
    setTimeout(() => dispatch(setIncomingCallDetails(DEFAULT_INCOMING_CALL_DEATILS)), TIMEOUT_1000)
}

export const videoCallHandler = async (callStatus: string, contextId: string) => {
    const { currentUser, urls } = getGlobalReduxValue()
    const { accessToken, sessionId, uuid } = currentUser
    const params: any = createUrlCall({
        accessToken,
        sessionId,
        userUuid: uuid,
        communicationServiceUrl: `${urls.COMMUNICATION_SERVICES_URL}${AV_CALL_EP}`,
        contextId, callStatus,
        state: false,
    })
    try {
        const apiResponse = await putService(params)
        if (apiResponse.status === HTTP_STATUS.OK) {
            infoLogger(`${callStatus} is set to ${contextId}`)
        }
    } catch (error) {
        errorLogger(`Exception occurred while updating call status to ${callStatus} : ${errorParser(error)}`)
    }

}

export const setRecentMissedCallInRedux = (callContextId: string, caller: string, callee: string, dispatch: Dispatch<any>) => {
    const missedCall: IMissedCallData = {
        id: "",
        attemptedCallTime: Date.now().toString(),
        callContextId,
        callee,
        caller,
        seen: false
    }
    dispatch(setRecentMissedCall(missedCall))
}

export const updateVideoCallStatus = (contextId: string, addIfNotAvaillable: boolean, updateValue?: ECallStatus) => {
    const state = store.getState()
    const { videoCallStatus } = state.callReducer
    const callStatusIndex = videoCallStatus.findIndex((callStatus) => callStatus.contextId === contextId)
    if (callStatusIndex > -1) {
        if (updateValue) {
            videoCallStatus[callStatusIndex].callStatus = updateValue
        } else {
            videoCallStatus.splice(callStatusIndex, 1)
        }
    } else if (addIfNotAvaillable && updateValue) {
        videoCallStatus.push(createICallStatusObject(contextId, updateValue))
    } else {/** SONAR ISSUE */ }
    return videoCallStatus
}

export const storeCallDetailsInRedux = async (data: any, dispatch: Dispatch<any>) => {
    const state = store.getState()
    const { connectedCallDetails } = state.callReducer.callDetails
    const { contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    let participants: IContactInfo[] = []
    for (const participant of data.participants) {
        const { primaryUuid } = participant
        const details = await getDetailsByUUID(primaryUuid, contacts, rooms)
        details.callStatus = participant.callStatus
        participants.push(details)
    }
    participants = participants.filter((participant) => ![undefined, CALL_REJECT, CALL_END, CALL_MISSED].includes(participant.callStatus))
    const callDetails: IAVCallDetails = {
        contextId: data.contextId,
        roomName: data.roomName,
        roomType: data.roomType,
        twilioToken: data.requester.userContext.twilioToken,
        userDetails: data.requester.userContext,
        participants,
        isMuted: connectedCallDetails.isMuted ?? false,
        isDeafened: connectedCallDetails.isDeafened ?? false,
        isFirstParticipant: false,
        callAcceptedTime: data.callAcceptedTime ? data.callAcceptedTime : connectedCallDetails.callAcceptedTime,
        callStatus: data.callStatus,
        numOfParticipants: data.numOfParticipants,
    }
    dispatch(storeCallDetails({ ...callDetails }))
    const updateCallStatuses = updateVideoCallStatus(data.contextId, true, ECallStatus.CONNECTED)
    dispatch(setVideoCallStatus([...updateCallStatuses]))
    return callDetails
}

const getGlobalReduxValue = () => {
    const state = store.getState()
    const { currentUser } = state.externalReducer
    const urls = fetchGlobalURLs()
    return { currentUser, urls }
}
