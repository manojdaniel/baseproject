/*
 * Created on Tue Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { GLOBAL_SET_INITIATE_PHONE_CALL, GLOBAL_SET_INITIATE_WEB_CALL } from "../../../redux/actions/types"
import { IStore } from "../../../redux/interfaces/types"
import { enableBrowserToPhoneCall, enableWebToWebCallWrapper } from "../../../services/callServices"

const COMPONENT_NAME = "Console event handler"

const CallEventHandler = () => {

    const {
        initiateWebCall,
        currentUser,
        initiatePhoneCall
    } = useSelector((state: IStore) => ({
        initiateWebCall: state.callReducer.initiateWebCall,
        currentUser: state.externalReducer.currentUser,
        initiatePhoneCall: state.callReducer.initiatePhoneCall
    }))

    const dispatch = useDispatch()

    useEffect(() => {
        const { contactUuid, componentName, modalityName } = initiateWebCall
        if (contactUuid) {
            const enableWebCallProps = { contactUuid, dispatch, componentName: componentName || COMPONENT_NAME, currentUserUuid: currentUser.uuid, modalityName }
            enableWebToWebCallWrapper(enableWebCallProps)
            dispatch({
                type: GLOBAL_SET_INITIATE_WEB_CALL, payload: {
                    initiateWebCall: { contactUuid: "" }
                }
            })
        }
    }, [initiateWebCall])

    useEffect(() => {
        const { contactUuid, contactInfo, phoneNumber, componentName } = initiatePhoneCall
        if (contactUuid || contactInfo) {
            const enablePhoneCallProps = { contactUuid, phoneNumber, dispatch, componentName: componentName || COMPONENT_NAME, contactInfo }
            enableBrowserToPhoneCall(enablePhoneCallProps)
            dispatch({
                type: GLOBAL_SET_INITIATE_PHONE_CALL, payload: {
                    initiatePhoneCall: { contactUuid: "", phoneNumber: "" }
                }
            })
        }
    }, [initiatePhoneCall])

    return <></>
}

export default CallEventHandler
