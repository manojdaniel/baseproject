/*
 * Created on Tue Spet 07 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import gql from "graphql-tag"

export const SUBSCRIPTION_CONTACTS_RELEVANT_TO_CURRENT_USER = gql`
subscription getContactDetails($userId: Int!, $limit: Int) {
  employees: rocc_get_contacts_info_function(args: {usr_id: $userId}, limit: $limit, order_by: {modified_at: desc}) {
    user_id
    display_name
    user_hsdp_uuid
    user_email_id
    user_primary_phone
    org_name
    modality
    org_id
    roles
    sites
  }
}
`

export const SUBSCRIPTION_FOR_CURRENT_USER_BUNDLE_INFOS = gql`
subscription getBundleListByUserId($user_id: Int!, $bundle_name: String!) {
  bundle_infos: rocc_get_user_bundle_infos_function(where: {_and: [{user_id: {_eq: $user_id}},{bundle_name: {_eq: $bundle_name}}]}, order_by:{id:desc}, limit:1) {
    id
    version
    mac_address
  }
}
`
