/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import {
    DownloadUtility, EButtonDirection, EConnectionMode, EConnectionState, EConnectionType, EDefaultTransactionValue, EOperationStatus,
    EResponse, ETransactionStatus, IRoomDetails, NATIVE_APP_URI_START, NFCC_BUNDLE, NFCC_BUNDLE_NOT_INSTALLED, parseIntBase10
} from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger } from "@rocc/rocc-logging-module"
import FileSaver from "file-saver"
import { setConsoleOperations, updateConsoleSession } from "../../redux/actions/consoleActions"
import { setProtocolTransferExitInProgress } from "../../redux/actions/protocolTransferActions"
import { GLOBAL_UPDATE_ROOMS } from "../../redux/actions/types"
import { IConsoleOperation, IConsoleTransaction, IPerformConsoleConnectionOps, IStore } from "../../redux/interfaces/types"
import { DEFAULT_CONSOLE_OPERATIONS } from "../../redux/reducers/consoleReducer"
import {
    dispatchToParentStore, fetchGlobalConfigs, fetchGlobalCurrentUser, fetchGlobalNfccBundleInfo,
    fetchGlobalNfccUpgradeStatus, fetchGlobalURLs, fetchRooms
} from "../../redux/store/externalAppStates"
import store from "../../redux/store/store"
import { disconnectConsoleService, initiateCCConsoleService } from "../../services/consoleService"
import { GLOBAL_UPDATE_NOTIFICATION_MODAL, INIT_MEDIA_ROOM_DETAILS } from "../constants/constants"
import { fetchHttpClient } from "./apiUtility"
import { checkAndStopEmeraldApp, constructAppUriForBundleUpgrade, displayNotificationMessage, generateUniqueId, getPidFromContextMapping, hideNotificationModal, launchAppUri } from "./helpers"
import en from "../../resources/translations/en-US"
import { Dispatch } from "react"
import { handleNFCCConnection } from "./consoleUtility"

const fileName = "consoleHelpers.ts"
const currentUser = fetchGlobalCurrentUser()

export const connectToConsole = async (roomUuid: string, connectionType: EConnectionType, dispatch: Dispatch<any>) => {
    const devMode = fetchGlobalConfigs().ROCC_DEV
    const rooms = fetchRooms()
    let updatedRooms: IRoomDetails[] = []
    let response = null
    try {
        const state: IStore = store.getState()
        const { seatName, receivers } = {
            seatName: state.consoleReducer.commandCenterDetails.commandCenterSeat.seatName,
            receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers
        }
        const receiverName = receivers.length > 0 ? receivers[0].receiverName : ""
        rooms.forEach((room: IRoomDetails) => {
            if (room.identity.uuid === roomUuid) { room.isConnecting = true }
            updatedRooms.push(room)
        })
        dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms: updatedRooms } })

        const transactions: IConsoleTransaction[] = [{
            transactionStatus: ETransactionStatus.RUNNING,
            connectionType: EConnectionType.DEFAULT,
            connectionMode: EConnectionMode.CC,
            connectionStatus: EDefaultTransactionValue.CONNECTING,
            roomUuid: roomUuid,
            receiverName: receiverName,
            transactionId: generateUniqueId(),
            groupId: generateUniqueId(),
        }]

        dispatch(setConsoleOperations({ operationId: generateUniqueId(), operationStatus: EOperationStatus.RUNNING, transactions }))
        let contextId = ""
        if (devMode === "true") {
            await simulateConnectionDelay()
            contextId = "dev-mode-context-id"
        } else {
            contextId = await initiateCCConsoleService({
                connectionType, roomUuid, seatName,
                requester: currentUser.uuid,
                accessToken: currentUser.accessToken,
                receiverName,
                orgId: parseIntBase10(currentUser.orgId),
                connectionMode: EConnectionMode.CC
            })
        }
        if (contextId) {
            dispatch(updateConsoleSession({
                requester: currentUser.uuid,
                contextId,
                connectionType,
                roomUuid,
                mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS,
                displayCameraToggle: false,
                connectionMode: EConnectionMode.CC,
                multiCameraList: [],
                connectionStatus: EConnectionState.CONNECTING,
                receiverName,
                consoleStartTime: ""
            }, true))
            response = {
                status: EResponse.SUCCESS,
                contextId: contextId,
                error: null
            }
        } else {
            response = {
                status: EResponse.ERROR,
                contextId: "",
                error: null
            }
            errorLogger(`${fileName} UUID:${currentUser.uuid} Failed to make console connection`)
        }
        updatedRooms = []
        rooms.forEach((room: IRoomDetails) => {
            if (room.identity.uuid === roomUuid) { room.isConnecting = false }
            updatedRooms.push(room)
        })
        dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms: updatedRooms } })
    }
    catch (error) {
        response = {
            status: EResponse.ERROR,
            contextId: "",
            error: error
        }
        rooms.forEach((room: IRoomDetails) => {
            if (room.identity.uuid === roomUuid) { room.isConnecting = false }
            updatedRooms.push(room)
        })
        dispatchToParentStore({ type: GLOBAL_UPDATE_ROOMS, payload: { rooms: updatedRooms } })
        errorLogger(`${fileName} Connecting to console failed with error: ${JSON.stringify(error)}`)
    }
    dispatch(setConsoleOperations(DEFAULT_CONSOLE_OPERATIONS))
    return response
}

export const disconnectFromActiveConsole = async (dispatch: Dispatch<any>, connectionType?: EConnectionType, postTransactionHook?: IConsoleOperation["postTransactionHook"]) => {
    const devMode = fetchGlobalConfigs().ROCC_DEV
    let response = {
        status: EResponse.ERROR,
        responseCode: -1,
        contextId: "",
        connectionType: EConnectionType.DEFAULT,
        error: null
    }
    try {
        const state: IStore = store.getState()
        const { consoleSessions, receivers } = {
            consoleSessions: state.consoleReducer.consoleSessions,
            receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers
        }
        const receiverName = receivers.length > 0 ? receivers[0].receiverName : ""
        if (consoleSessions && consoleSessions.length && ((!connectionType) || (consoleSessions[0].connectionType === connectionType))) {
            const transactions: IConsoleTransaction[] = [{
                transactionStatus: ETransactionStatus.RUNNING,
                connectionType: consoleSessions[0].connectionType,
                connectionMode: consoleSessions[0].connectionMode,
                connectionStatus: EDefaultTransactionValue.DISCONNECTING,
                roomUuid: consoleSessions[0].roomUuid,
                receiverName: receiverName,
                transactionId: generateUniqueId(),
                groupId: generateUniqueId(),
            }]
            dispatch(setConsoleOperations({ operationId: generateUniqueId(), operationStatus: EOperationStatus.RUNNING, transactions, postTransactionHook }))
            if (devMode === "true") {
                await simulateConnectionDelay()
                dispatch(updateConsoleSession({
                    requester: currentUser.uuid,
                    contextId: consoleSessions[0].contextId,
                    connectionType: consoleSessions[0].connectionType,
                    roomUuid: consoleSessions[0].roomUuid,
                    mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS,
                    displayCameraToggle: false,
                    connectionMode: consoleSessions[0].connectionMode,
                    multiCameraList: [],
                    connectionStatus: EConnectionState.DISCONNECTING,
                    receiverName,
                    consoleStartTime: ""
                }, false))
                response = {
                    ...response,
                    status: EResponse.SUCCESS,
                }
            } else {
                const disconnectResponse = await disconnectConsoleService({
                    accessToken: currentUser.accessToken, contextId: consoleSessions[0].contextId, shouldUpdateForceDelete: false, connectionMode: EConnectionMode.CC
                })
                const pid = getPidFromContextMapping(consoleSessions[0].contextId)
                checkAndStopEmeraldApp(consoleSessions[0].connectionMode, currentUser, fetchGlobalURLs().CONSOLE_SERVICES_URL, pid)
                if ([204, 208].includes(disconnectResponse)) {
                    dispatch(updateConsoleSession({
                        requester: currentUser.uuid,
                        contextId: consoleSessions[0].contextId,
                        connectionType: consoleSessions[0].connectionType,
                        roomUuid: consoleSessions[0].roomUuid,
                        mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS,
                        displayCameraToggle: false,
                        connectionMode: consoleSessions[0].connectionMode,
                        multiCameraList: [],
                        connectionStatus: EConnectionState.DISCONNECTING,
                        receiverName,
                        consoleStartTime: ""
                    }, false))
                    response = {
                        ...response,
                        status: EResponse.SUCCESS,
                    }
                } else {
                    response = {
                        ...response,
                        status: EResponse.ERROR,
                    }
                    errorLogger(`${fileName} UUID: ${currentUser.uuid} ApiStatus: Failed to disconnect from console: ${disconnectResponse}`)
                }
                response = {
                    ...response,
                    responseCode: disconnectResponse,
                    contextId: consoleSessions[0].contextId,
                    connectionType: consoleSessions[0].connectionType,
                    error: null
                }
            }
            dispatch(setConsoleOperations(DEFAULT_CONSOLE_OPERATIONS))
        } else {
            response = {
                ...response,
                status: EResponse.SUCCESS,
            }
        }
    }
    catch (error: any) {
        response = {
            ...response,
            error: error
        }
    }
    dispatch(setProtocolTransferExitInProgress(false))
    return response
}

const simulateConnectionDelay = async () => {
    return new Promise(resolve => setTimeout(resolve, 2000))
}


const nfccUpgradePopupOnClick = async (nfccUpgradeAvailable: boolean) => {
    hideNotificationModal()
    const { intl } = getIntlProvider()
    const { url } = await DownloadUtility.getPresignedUrl(fetchHttpClient(), fetchGlobalCurrentUser().accessToken, fetchGlobalURLs().MANAGEMENT_SERVICE_URL, NFCC_BUNDLE)
    if (nfccUpgradeAvailable) {
        const customStyle = { top: "3rem", right: "1rem", width: "29.25rem" }
        const message = [{
            header: intl.formatMessage({ id: "content.upgrade.nfccInstaller.title", defaultMessage: en["content.upgrade.nfccInstaller.title"] }),
            content: intl.formatMessage({ id: "content.notificationMessage.upgradeNFCCMessage", defaultMessage: en["content.notificationMessage.upgradeNFCCMessage"] })
        }]
        displayNotificationMessage(message, customStyle, false, true, false, true)
        launchAppUri(NATIVE_APP_URI_START, constructAppUriForBundleUpgrade(NFCC_BUNDLE, fetchGlobalNfccBundleInfo()))
    }
    else { FileSaver.saveAs(url) }
}

const showNFCCUpgradeNotificationModal = (header: any, modalContent: any, actionButton1Text: any, actionButton2Text: any,
    props: IPerformConsoleConnectionOps, showCloseIcon: any, mandatory: any, nfccUpgradeAvailable: any) => {
    const notificationModal = {
        showModal: true,
        showCloseIcon,
        header,
        modalContent,
        actionButton1Text,
        actionButton2Text,
        buttonDirection: EButtonDirection.RIGHT,
        actionButton1Onclick: () => nfccUpgradePopupOnClick(nfccUpgradeAvailable),
        actionButton2Onclick: () => {
            hideNotificationModal()
            !mandatory && handleNFCCConnection({ ...props })
        },
        onClose: () => { hideNotificationModal() },
        modalStyle: {}
    }
    dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
}

export const checkIfUserHasCompatibleNFCCBundle = async (props: IPerformConsoleConnectionOps) => {
    const nfccUpgradeAvailable = fetchGlobalNfccUpgradeStatus()
    const isAnyActiveConsoleSession = store.getState().consoleReducer.consoleSessions.length
    if (isAnyActiveConsoleSession || (!sessionStorage.getItem(NFCC_BUNDLE_NOT_INSTALLED) && !nfccUpgradeAvailable)) {
        handleNFCCConnection({ ...props })
    }
    else {
        let header
        let modalContent
        let actionButton1Text
        let actionButton2Text
        let showCloseIcon
        const { intl } = getIntlProvider()
        const mandatory = fetchGlobalNfccBundleInfo()?.mandatory
        if (nfccUpgradeAvailable) {
            if (mandatory) {
                header = intl.formatMessage({ id: "content.upgrade.nfccInstaller.mandatoryTitle", defaultMessage: en["content.upgrade.nfccInstaller.mandatoryTitle"] })
                modalContent = intl.formatMessage({ id: "content.upgrade.nfccInstaller.mandatoryModelDesc", defaultMessage: en["content.upgrade.nfccInstaller.mandatoryModelDesc"] })
                actionButton2Text = intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] })
            }
            else {
                header = intl.formatMessage({ id: "content.upgrade.nfccInstaller.optionalTtitle", defaultMessage: en["content.upgrade.nfccInstaller.optionalTtitle"] })
                modalContent = intl.formatMessage({ id: "content.upgrade.nfccInstaller.optionalModelDesc", defaultMessage: en["content.upgrade.nfccInstaller.optionalModelDesc"] })
                actionButton2Text = intl.formatMessage({ id: "content.continue.btn", defaultMessage: en["content.continue.btn"] })
            }
            actionButton1Text = intl.formatMessage({ id: "content.upgrade.btn", defaultMessage: en["content.upgrade.btn"] })
            showCloseIcon = false
        }
        else {
            header = intl.formatMessage({ id: "content.download.nfccInstaller.title", defaultMessage: en["content.download.nfccInstaller.title"] })
            modalContent = intl.formatMessage({ id: "content.download.nfccInstaller.modalDesc", defaultMessage: en["content.download.nfccInstaller.modalDesc"] })
            actionButton2Text = intl.formatMessage({ id: "content.continue.btn", defaultMessage: en["content.continue.btn"] })
            actionButton1Text = intl.formatMessage({ id: "content.download.btn", defaultMessage: en["content.download.btn"] })
            showCloseIcon = true
        }
        showNFCCUpgradeNotificationModal(header, modalContent, actionButton1Text, actionButton2Text, props, showCloseIcon, mandatory, nfccUpgradeAvailable)
    }
}
