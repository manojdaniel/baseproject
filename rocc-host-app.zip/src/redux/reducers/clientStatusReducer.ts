/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { Reducer } from "redux"
import { IClientReducer, EConnectionStatus } from "@rocc/rocc-client-services"
import { SET_APPILICATION_CONNECTION_STATE, GLOBAL_UPDATE_CHAT_CLIENT_STATUS, VERIFY_CURRENT_USER_PRESENCE } from "../actions/types"

export const initialStatesForClientStatus: IClientReducer = {
    chatClientStatus: EConnectionStatus.OFFLINE,
    applicationConnectionState: EConnectionStatus.ONLINE,
    presenceStatus: EUserPresence.AVAILABLE,
}

const clientStatusReducer: Reducer = (state: IClientReducer = initialStatesForClientStatus, action: any) => {
    switch (action.type) {
        case GLOBAL_UPDATE_CHAT_CLIENT_STATUS:
            return { ...state, chatClientStatus: action.payload.chatClientStatus }

        case SET_APPILICATION_CONNECTION_STATE:
            return { ...state, applicationConnectionState: action.applicationConnectionState }

        case VERIFY_CURRENT_USER_PRESENCE:
            return { ...state, presenceStatus: action.presenceStatus }

        default:
            return state
    }
}

export default clientStatusReducer
