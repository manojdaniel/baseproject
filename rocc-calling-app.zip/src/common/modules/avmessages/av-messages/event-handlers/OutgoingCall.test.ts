/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO } from "@rocc/rocc-client-services"
import { outgoingCall } from "./OutgoingCall"

const dispatch = jest.fn()

jest.mock("../../../../helpers/helpers", () => ({
    getUserReducerFromGlobalStore: () => ({
        currentUser: {},
        contacts: [],
    }),
    getCustomrReducerFromGlobalStore: () => ({
        rooms: [],
    })
}))

jest.mock("../../../../../redux/actions/callActions", () => ({
    setCallMessage: jest.fn(),
    setCallRingStatus: jest.fn(),
    setVideoCallStatus: jest.fn(),
    setOutgoingCallDetails: jest.fn(),
    updateCallTimeout: jest.fn(),
}))

describe("outgoingCall tests", () => {
    const contextDetails = {
        data: {
            contextId: "contextId",
            participants: [{
                primaryUuid: "primaryUuid",
            }],
            requester: {}
        }
    }
    it("should able to update redux with outgoing call details", () => {
        outgoingCall({ contextDetails, participant: DEFAULT_CONTACT_INFO, dispatch })
        expect(dispatch).toHaveBeenCalledTimes(2)
    })
})
