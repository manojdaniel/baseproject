export const plantDetailTransformer = (data: any) => {
    let result: any[] = []
    result = data.map((item: any) => ({
        ...item,
        healthIndex: item.healthIndex.replace(/\s|%/, "").replace(/(\d)\s+/, "$1"),
        pmCompliance: item.pmCompliance.replace(/\s|%/, "").replace(/(\d)\s+/, "$1")
    }));

    return result
}