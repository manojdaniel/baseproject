/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse, EAppContext, IAppReducer, ILoadTimes, EIdlePermissionState } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { EAuthState } from "../../services/authentication/hsdp-iam/iamAuthTypes"
import {
    FETCH_VERSION, FORCE_APP_REFRESH, GLOBAL_RIGHTSIDE_PANEL, GLOBAL_SET_ACTIVE_TAB, GLOBAL_LEFTSIDE_PANEL, SET_FSE_MODE, LOAD_TIMES_HOME_PAGE_LOAD, LOAD_TIMES_LOGIN_CLICK, ROOM_MONITORING_WINDOW, SET_APP_CONTEXT, SET_AUTH_CONFIGS, UPDATE_AUTH_STATE, GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL, UPDATE_NFCC_UPGRADE_AVAILABLE, SET_IDLE_PERMISSION_STATE
} from "../actions/types"

const INIT_DATE = new Date(1970, 1, 1)

export const INIT_LOAD_TIMES: ILoadTimes = {
    loginClick: INIT_DATE, homePageLoaded: INIT_DATE, totalTime: 0, initDate: INIT_DATE
}

export const initialStatesForApp: IAppReducer = {
    sideBar: {
        activeRightPanel: "",
        displayRightSidePanel: false,
        activeLeftPanel: "",
        displayLeftSidePanel: false,
        desktopFullScreen: false
    },
    version: "",
    fseData: { customerOrgId: "", isFse: false, customerName: "" },
    appRefreshState: EResponse.DEFAULT,
    activeTabIndex: 0,
    loadTimes: INIT_LOAD_TIMES,
    nfccUpgradeAvailable: false,
    roomMonitoringWindow: false,
    appContext: EAppContext.DEFAULT,
    authConfigs: {
        appClientId: "",
        authId: "",
        authState: EAuthState.DEFAULT,
        authUrl: "",
        otpAllowTrustDevice: false,
        redirectUrl: "",
        identityProviderConfigName: "",
    },
    focusedCallAndConsole: { callContextId: "", consoleContextId: "" },
    idlePermissionState: EIdlePermissionState.DENIED
}
const appReducer: Reducer<IAppReducer> =
    (state: IAppReducer = initialStatesForApp, action: any) => {
        const modSideBar = state.sideBar
        switch (action.type) {
            case GLOBAL_RIGHTSIDE_PANEL:
                modSideBar.activeRightPanel = action.payload.activeRightPanel
                modSideBar.displayRightSidePanel = action.payload.displayRightSidePanel
                modSideBar.desktopFullScreen = action.payload.desktopFullScreen
                return { ...state, sideBar: modSideBar }
            case GLOBAL_LEFTSIDE_PANEL:
                modSideBar.activeLeftPanel = action.payload.activeLeftPanel
                modSideBar.displayLeftSidePanel = action.payload.displayLeftSidePanel
                modSideBar.desktopFullScreen = action.payload.desktopFullScreen
                return { ...state, sideBar: modSideBar }
            case FETCH_VERSION:
                return { ...state, version: action.version }
            case SET_FSE_MODE:
                return { ...state, fseData: action.fseData }
            case FORCE_APP_REFRESH:
                return { ...state, appRefreshState: action.appRefreshState }
            case GLOBAL_SET_ACTIVE_TAB:
                return { ...state, activeTabIndex: action.payload.activeTabIndex }
            case LOAD_TIMES_HOME_PAGE_LOAD:
                return { ...state, loadTimes: action.loadTimes }
            case LOAD_TIMES_LOGIN_CLICK:
                return { ...state, loadTimes: { ...INIT_LOAD_TIMES, loginClick: new Date() } }
            case UPDATE_NFCC_UPGRADE_AVAILABLE:
                return { ...state, nfccUpgradeAvailable: action.nfccUpgradeAvailable }
            case ROOM_MONITORING_WINDOW:
                return { ...state, roomMonitoringWindow: action.roomMonitoringWindow }
            case SET_APP_CONTEXT:
                return { ...state, appContext: action.appContext }
            case SET_AUTH_CONFIGS: {
                /* This allow user to continue from otp stage if user refreshes browser in otp stage */
                const authState = state.authConfigs.authState === EAuthState.SHOW_SERVER_OTP ? EAuthState.SHOW_SERVER_OTP : EAuthState.DEFAULT
                return {
                    ...state,
                    authConfigs:
                    {
                        ...state.authConfigs,
                        authState,
                        appClientId: action.appClientId,
                        authUrl: action.authUrl,
                        redirectUrl: action.redirectUrl,
                        otpAllowTrustDevice: action.otpAllowTrustDevice
                    }
                }
            }
            case UPDATE_AUTH_STATE:
                return { ...state, authConfigs: { ...state.authConfigs, authState: action.authState, authId: action.authId ?? state.authConfigs.authId } }
            case GLOBAL_SET_ACTIVE_CONSOLE_AND_CALL: {
                return { ...state, focusedCallAndConsole: { callContextId: action.callContextId, consoleContextId: action.consoleContextId } }
            }
            case SET_IDLE_PERMISSION_STATE: {
                return { ...state, idlePermissionState: action.idlePermissionState }
            }
            default:
        }
        return { ...state }
    }

export default appReducer
