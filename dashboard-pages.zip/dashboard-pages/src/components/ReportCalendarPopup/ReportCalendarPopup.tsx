import React, { useState } from "react";
import ReportDatePickerComponent from "./ReportDatePickerComponent";
import "./ReportCalendarPopup.scss";
import moment from "moment";

interface Props {
	handleReportFromDate: any;
	handleReportToDate: any;
	commonReportFromDateFormat: any;
	commonReportToDateFormat: any;
	commonReportFromDate: any;
	commonReportToDate: any;
}

const ReportCalendarPopup = ({
	handleReportFromDate,
	handleReportToDate,
	commonReportFromDateFormat,
	commonReportToDateFormat,
	commonReportFromDate,
	commonReportToDate,
}: Props) => {
	const [labelFrom, setLabelFrom] = useState(true);
	const [labelTo, setLabelTo] = useState(false);

	const handleReportFromDateChanged = (date: any) => {
		handleReportFromDate(date);
	};
	const handleReportToDateChanged = (date: any) => {
		handleReportToDate(date);
	};

	return (
		<>
			<div id="calendar-popup" className="cal-show">
				<div className="calendar-filter">
					<div
						className="cf-left"
						onClick={() => {
							setLabelFrom(true);
							setLabelTo(false);
						}}
					>
						<span>From</span>
						<label>{commonReportFromDateFormat}</label>
					</div>
					<div
						className="cf-right"
						onClick={() => {
							setLabelTo(true);
							setLabelFrom(false);
						}}
					>
						<span>To</span>
						<label>{commonReportToDateFormat}</label>
					</div>
				</div>

				<div className="calendar-box">
					<div style={{ marginLeft: "0px" }}>
						{labelFrom ? (
							<ReportDatePickerComponent
								selectedDate={
									commonReportFromDate !== ""
										? moment(commonReportFromDateFormat).toDate()
										: commonReportFromDate
								}
								handleDateChange={handleReportFromDateChanged}
							/>
						) : null}
						{labelTo ? (
							<ReportDatePickerComponent
								selectedDate={
									commonReportToDate !== ""
										? moment(commonReportToDateFormat).toDate()
										: commonReportToDate
								}
								handleDateChange={handleReportToDateChanged}
							/>
						) : null}
					</div>
				</div>
			</div>
		</>
	);
};

export default ReportCalendarPopup;
