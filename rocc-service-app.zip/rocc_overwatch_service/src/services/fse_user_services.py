"""
 Created on Thurs June 02 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
import re
import json
import requests
from src.wrappers.infrastructure_services.email_templates_services.manage_email_templates_services import create_email_templates_service
from src.constants.config_keys import CUSTOMER_OB_LOCALE, INFRA_CFG_RECOVER_PASSWORD_URL, INFRA_CFG_SET_PASSWORD_URL, VAULT_PARENT_ORG_ID, VAULT_HSDP_IDM_URL, VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.exceptions.RoccException import RoccException
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data
from src.constants.constants import ACCEPT, API_VERSION, APPLICATION_JSON, EMAIL_TEMPLATE_URI, AUTHORIZATION, CONTENT_TYPE, ROCC_PROXY_URL, EMAIL_ID_KEY, EMAIL_FORMAT_REGEX, ROLES, ID, ORG_HSDP_UUID, ROCC_ORGANIZATIONS, FSE_USER, FSE_USER_ADD, FSE_USER_EDIT
from src.constants.enums import EDBRoles
from src.loggers.log import create_logger
from src.modules.db_operations.fse_user_db_service.fse_user_db_service import check_if_user_exists, get_roles_identifiers_for_fse_roles, insert_fse_user_into_db, get_all_customers
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import fetch_user_details_from_hsdp
from src.wrappers.infrastructure_services.roles_permissions_services.manage_roles_groups import create_group, get_group_details_by_name
from src.wrappers.platform_services.management_service.user_management_service import insert_and_invite_user, edit_fse_user
from src.wrappers.platform_services.rbac_services.rbac_services import validate_permissions, update_user_role_mapping
from src.modules.db_operations.db_utility.common_query_functions import update_user_org_mapping, get_organization_user_mappings, update_fse_user_status
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.graphql.queries.queries import fetch_user_db_id_from_uuid

LOG = create_logger("FseUserService")


class FseUserService():

    def __init__(self, service_user_uuid, service_user_token):
        try:
            self._service_user_uuid = service_user_uuid
            self._service_user_token = service_user_token
            self._profile_configs = get_profile_data()
            self.populate_service_tokens()
            self._parent_org_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._client = get_client_connection(access_token=self._parent_service_token, org_infra_uuid=self._parent_org_uuid)
            self._base_url = os.environ.get(ROCC_PROXY_URL)
        except RoccException as ex:
            LOG.error(f"FSE user Service initialization failed with error: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"FSE user Service initialization failed with error: {ex}")
            raise RoccException(title="Initialization Failed", status_code=500, payload="Internal server error") from ex

    def populate_service_tokens(self):
        try:
            self._parent_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                         issuer=self._profile_configs[
                                                                             VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                         private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!") from ex

    def add_fse_user(self, fse_user):
        """ 1. validate the logged-in user has permission to add fse user
            2. validate the fse-user already present in hsdp or not
            3. add the user into hsdp and invite
            4. once user is added into hsdp and invited, insert user detail into db
            5. If the user is inserted into db, add user-organization mapping if any
        """
        roles_ids_for_fse_role = []
        self.is_email_format_valid(mail_id=fse_user[EMAIL_ID_KEY])
        self.is_user_with_valid_permission(resource_name=FSE_USER, action_name=FSE_USER_ADD)
        self.is_role_for_fseuser_valid(fse_user=fse_user)
        roles_ids_for_fse_role = get_roles_identifiers_for_fse_roles(self._client)
        LOG.info("*Role id's received from db*")
        group_id = self.is_user_part_of_fse_group()
        LOG.info("*Group id received for Group name 'FseGroup'*")
        user_details = self.is_user_with_read_permission_hsdp(email_id=fse_user[EMAIL_ID_KEY])
        user_already_present = True if isinstance(user_details, list) and len(user_details) > 0 else False
        LOG.info(f"Is Fse user present in HSDP ? {user_already_present}")
        if user_already_present:
            raise RoccException(status_code=400,
                                title="User already present",
                                payload="This email ID already exists in the Database. Try Re-Inviting the User",
                                additional_info="This email ID already exists in the Database. Try Re-Inviting the User")

        roles_id_to_be_added = self.get_fse_roles_obj(roles_ids_for_fse_role, fse_user[ROLES])
        valid_customers = self.extract_org_id_from_hsdp_org_id(fse_user["allowed_customers"])
        if len(valid_customers) is not len(fse_user["allowed_customers"]):
            LOG.error(f"Invalid customer_ids provided:{self.invalid_cust_ids}")
            raise RoccException(status_code=400,
                                title="Invalid Customer id provided",
                                payload=f"Failed to create Fse user. Invalid customers:{','.join(self.invalid_cust_ids)}",
                                additional_info=f"Failed to create Fse user. Invalid customers:{','.join(self.invalid_cust_ids)}")

        self.create_email_service_fse(self._parent_service_token)
        user_to_insert = {}
        user_to_insert[EMAIL_ID_KEY] = fse_user[EMAIL_ID_KEY]
        user_to_insert["first_name"] = fse_user["first_name"]
        user_to_insert["last_name"] = fse_user["last_name"]
        prepared_user_object = self.prepare_user_obj(user=user_to_insert,
                                                     fse_role_id=roles_id_to_be_added, user_id_from_db=None)
        if not user_already_present:
            user_details = self.perform_user_insertion(user_list=[prepared_user_object], group_id=group_id, fse_user=fse_user)
        else:
            user_details[0]["role_ids"] = roles_id_to_be_added
            self.manual_fse_user_insert(user=user_details[0], user_email_id=fse_user[EMAIL_ID_KEY])

        self.assign_role_to_rbac(roles=fse_user[ROLES], user_uuid=user_details[0][ID])

        total_no_of_cust_mapping_to_be_added = fse_user["allowed_customers"]
        if len(total_no_of_cust_mapping_to_be_added) > 0:
            self.evaluate_user_org_mapping(allowed_cust_list=fse_user["allowed_customers"],
                                           fse_user_email_id=fse_user[EMAIL_ID_KEY])
            self.safe_audit(event_subtype="Create FseUser-Customer mapping", action="C", outcome=0, code="Create FseUser-Customer mapping", value="Success")

        self.safe_audit(event_subtype="Create new Fse User", action="C", outcome=0, code="Create Fse User", value="Success")
        return {"status": 201, "data": "FSE User inserted successfully"}

    def task_get_fse_group_id(self, token, profile_configs, group_name="FseGroup"):
        try:
            group_id = get_group_details_by_name(
                token=token, group_name=group_name, profile_configs=profile_configs)
            LOG.info(f"Group id is {group_id}")
            if not group_id:
                group_id = create_group(token=token,
                                        organization_id=profile_configs[VAULT_PARENT_ORG_ID],
                                        name=group_name,
                                        description="This Group is used to authorise ROCC service tool FSE users and ROCC Service Admin users to access data from GraphQl",
                                        profile_configs=profile_configs)
            return group_id
        except Exception as ex:
            LOG.exception(f"Failed to fetch group id for name: {group_name} with error: {ex}")
        return None

    def prepare_user_obj(self, user, fse_role_id, user_id_from_db=None):
        try:
            user_obj = {"clinicalRoles": fse_role_id, "emailId": user[EMAIL_ID_KEY], "firstName": user["first_name"], "lastName": user["last_name"],
                        "uniqueId": user["email_id"], "isfseUserCheck": True, "metasiteId": 0, "phoneNumber": "", "sites": [],
                        "resources": [], "modalities": []}
            if user_id_from_db is not None:
                user_obj["user_id"] = user_id_from_db
            return user_obj
        except Exception as ex:
            LOG.exception(f"Exception occurred while preparing user object with error: {ex}")
            raise RoccException(500, f"Failed to retrieve user details with error: {ex}") from ex

    def get_fse_roles_obj(self, fse_roles_details, new_user_roles):
        role_obj = []
        invalid_role_names = []
        try:
            LOG.info(f"Fetching FSE roles identifiers for roles {new_user_roles}")
            new_user_roles = [item.lower() for item in new_user_roles]
            for role in fse_roles_details:
                if role["role"] in new_user_roles:
                    role_obj.append(role["id"])

            for role_requested in new_user_roles:
                if not self.is_role_name_valid(role_requested, fse_roles_details):
                    invalid_role_names.append(role_requested)

        except KeyError as key_error:
            LOG.exception(f"Exception while fetching role identifiers from list with error: {key_error}")
        if len(invalid_role_names) == 0:
            return role_obj
        else:
            LOG.error(f"Invalid roles:{invalid_role_names}")
            raise RoccException(status_code=500,
                                title="Invalid Roles",
                                payload="Invalid roles provided",
                                additional_info=f"Invalid roles provided:{','.join(invalid_role_names)}")

    def update_fse_user_roles(self, roles, user_uuid):
        """
        Update the fse user roles in rbac
        """

        user_role_mappings = []
        org_ctxt_header = {"Org-Id": self._profile_configs[VAULT_PARENT_ORG_ID]}

        for role in roles:
            user_role_mappings.append({"userId": user_uuid, "role": role.upper()})
        return update_user_role_mapping(url=self._base_url, user_role_mapping=user_role_mappings, user_uuid=user_uuid, org_ctxt_header=org_ctxt_header,
                                        token=self._parent_service_token)

    def initiate_user_org_mapping(self, allowed_cust_list, fse_user_email_id):
        insertion_trial_count = 1
        new_org_ids = []
        data_insertion_success = False
        try:
            data = check_if_user_exists(self._client, fse_user_email_id)
            user_db_id = data[0][ID]
            orgs_from_db = get_all_customers(self._client)
            if orgs_from_db:
                for org in orgs_from_db[ROCC_ORGANIZATIONS]:
                    org_uuid = org[ORG_HSDP_UUID]
                    if org_uuid in allowed_cust_list:
                        new_org_ids.append(org[ID])
            while(insertion_trial_count <= 3 and data_insertion_success is False):
                data_insertion_success = self.update_orgs_user_mapping(deleted_org_ids=[], new_org_ids=new_org_ids, fse_user_id=user_db_id)
                insertion_trial_count = insertion_trial_count+1
        except Exception as ex:
            LOG.exception(f"Exception occurred while adding fse user and organization mapping with error: {ex}")
        return data_insertion_success

    def update_orgs_user_mapping(self, deleted_org_ids, new_org_ids, fse_user_id):
        """
        Update FSE User org mapping
        """
        org_user_mapping_added = False
        try:
            org_mappings = []
            for org_id in new_org_ids:
                org_object = {
                    "organization_id": org_id,
                    "user_id": fse_user_id,
                    "created_by": self._service_user_uuid,
                    "modified_by": self._service_user_uuid
                }
                org_mappings.append(org_object)
            variable_values = {
                "delete_org_ids": deleted_org_ids,
                "org_mappings": org_mappings,
                "user_id": fse_user_id
            }
            update_user_org_mapping(self._client, variable_values)
            org_user_mapping_added = True
        except Exception as ex:
            LOG.exception(f"Failed to update user organization mapping with exception: {ex}")
        return org_user_mapping_added

    def check_if_valid_roles_are_present(self, user):
        """
        1. Get all the FSE Roles provided for FSE user
        2. Check if any non_eligible_roles exists in FSE roles
        3. If exists return True. Else
        4. check any special role FSEREMOTE, RELEASEMANAGER is present
        4. Special roles cant be merged with FSE-READ , EDIT, ADMIN ROLE
        """
        non_eligible_roles = [EDBRoles.EXPERTUSERROLE.value, EDBRoles.INCOGNITOROLE.value,
                              EDBRoles.PROTOCOLMANAGERROLE.value, EDBRoles.TECHNOLOGISTROLE.value,
                              EDBRoles.ADMINROLE.value, EDBRoles.CPPADMINROLE.value]
        non_eligible_roles = [item.lower() for item in non_eligible_roles]

        fse_remote_release_manager_roles = [EDBRoles.FSEREMOTE.value, EDBRoles.RELEASEMANAGER.value]
        fse_remote_release_manager_roles = [item.lower() for item in fse_remote_release_manager_roles]

        new_roles_ro_be_assigned = user[ROLES]
        new_roles_ro_be_assigned = [item.lower() for item in new_roles_ro_be_assigned]
        check_role = any(item in non_eligible_roles for item in new_roles_ro_be_assigned)
        check_fse_remote_release_manager_roles = any(item in fse_remote_release_manager_roles for item in new_roles_ro_be_assigned)
        if check_role:
            LOG.error("User contains customer org roles, hence skipping user management for this user.")
        elif len(new_roles_ro_be_assigned) > 1 and check_fse_remote_release_manager_roles is True:
            LOG.error("Requested roles or combination of roles are invalid. FSEREMOTE and RELEASEMANAGER cannot be clubbed with other FSE roles")
            check_role = True
        else:
            LOG.info("User does not contain customer org roles, hence continuing with user management for this user.")
        return check_role

    def assign_role_to_rbac(self, roles, user_uuid):
        count = 1
        user_role_mapping_added = False
        while (count <= 3 and (user_role_mapping_added is False)):
            user_role_mapping_added = self.update_fse_user_roles(roles=roles, user_uuid=user_uuid)
            count = count+1
        return user_role_mapping_added

    def manual_fse_user_insert(self, user, user_email_id):
        """
        Inserts user record into DB
        """
        data = check_if_user_exists(client=self._client, email_id=user_email_id)
        if not data:
            response = insert_fse_user_into_db(client=self._client, new_user_details=user, current_user_uuid=self._service_user_uuid)
            if not isinstance(response, int):
                LOG.error("Failed to insert user into DB")
            else:
                LOG.info("Inserted user into DB successfully.")

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._parent_org_uuid:
            try:
                prepare_and_post_audit(event_type="Create/Update Fse user", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._parent_org_uuid, token=self._parent_service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def is_role_for_fseuser_valid(self, fse_user):
        customer_org_role_exists = self.check_if_valid_roles_are_present(fse_user)
        if customer_org_role_exists:
            self.safe_audit(event_subtype="customer_org_role_present", action="R", outcome=8, code="Invalid roles present", value="Failure")
            raise RoccException(status_code=400,
                                title="Invalid Roles",
                                payload="Invalid roles provided",
                                additional_info="Requested roles or combination of roles are invalid. FSEREMOTE and RELEASEMANAGER cannot be clubbed with other FSE roles")

    def is_user_with_valid_permission(self, resource_name, action_name):
        validate_permissions(url=self._base_url, token=self._service_user_token,
                             resource_name=resource_name, action_name=action_name,
                             userid=self._service_user_uuid, org_infra_uuid=self._parent_org_uuid)

    def is_user_part_of_fse_group(self):
        group_id = self.task_get_fse_group_id(token=self._parent_service_token,
                                              profile_configs=self._profile_configs)
        if not group_id:
            LOG.error("Fse_group is not present")
            self.safe_audit(event_subtype="Fse_group_not_present", action="R", outcome=8, code="Fse_group_not_present", value="Failure")
            raise RoccException(status_code=500,
                                title="Internal Server Error",
                                payload="FSEGroup not present for Parent org",
                                additional_info="FSEGroup not available, please contact administrator")
        return group_id

    def is_user_with_read_permission_hsdp(self, email_id):
        user_details = fetch_user_details_from_hsdp(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                    token=self._parent_service_token, email_id=email_id)
        if user_details is False:
            LOG.error("Insufficient Permission to read fse_user detail")
            self.safe_audit(event_subtype="Read_Fse_user_detail", action="R",
                            outcome=8, code="Read_Fse_user_detail", value="Failure")
            raise RoccException(status_code=500,
                                title="Insufficient Permission",
                                payload="User is part of different root-org",
                                additional_info="User is part of different root-org")
        return user_details

    def perform_user_insertion(self, user_list, group_id, fse_user):
        user_inserted = insert_and_invite_user(token=self._parent_service_token, user_list=user_list,
                                               org_id=self._profile_configs[VAULT_PARENT_ORG_ID],
                                               url=self._base_url, group_id=group_id, profile_configs=self._profile_configs)
        if not user_inserted:
            LOG.error("Failed to create Fse user in hsdp")
            self.safe_audit(event_subtype="Insert_fse_user_detail", action="C", outcome=8, code="Insert_fse_user_detail", value="Failure")
            raise RoccException(status_code=500,
                                title="Internal Server Error",
                                payload="Failed to create user",
                                additional_info="Failed to create Fse user, please try again")
        self.safe_audit(event_subtype="Insert_fse_user_detail", action="C", outcome=0, code="Insert_fse_user_detail", value="Success")
        user_details = fetch_user_details_from_hsdp(
            idm_url=self._profile_configs[VAULT_HSDP_IDM_URL], token=self._parent_service_token, email_id=fse_user[EMAIL_ID_KEY])
        return user_details

    def evaluate_user_org_mapping(self, allowed_cust_list, fse_user_email_id):
        user_org_mapping_insertion_status = self.initiate_user_org_mapping(allowed_cust_list=allowed_cust_list,
                                                                           fse_user_email_id=fse_user_email_id)

        if not user_org_mapping_insertion_status:
            LOG.error(f"User created successfully, but customer mapping failed, failed_customer_mapping:{allowed_cust_list}")
            self.safe_audit(event_subtype="Insert_fse_user_org_mapping", action="C", outcome=8, code="Insert_fse_user_org_mapping", value="Failure")
            raise RoccException(status_code=206,
                                title="Partially Completed",
                                payload=f"User created successfully, but customer mapping failed, failed_customer_mapping:{allowed_cust_list}",
                                additional_info=f"User created successfully, but customer mapping failed, failed_customer_mapping:{allowed_cust_list}")

    def edit_fse_user(self, fse_user):
        self.is_user_with_valid_permission(resource_name=FSE_USER, action_name=FSE_USER_EDIT)
        self.is_role_for_fseuser_valid(fse_user=fse_user)
        group_id = self.is_user_part_of_fse_group()
        LOG.info("*Group id received for Group name 'FseGroup'*")

        user_from_db = self.fetch_user_id_from_db(fse_user)
        fse_user["email_id"] = user_from_db["user_email_id"]
        fse_user["first_name"] = user_from_db["first_name"]
        fse_user["last_name"] = user_from_db["last_name"]

        new_roles_asked = fse_user[ROLES]
        roles_ids_for_fse_role = get_roles_identifiers_for_fse_roles(self._client)
        new_roles_id_to_be_added = self.get_fse_roles_obj(roles_ids_for_fse_role, new_roles_asked)
        new_user_object = self.prepare_user_obj(user=fse_user, fse_role_id=new_roles_id_to_be_added, user_id_from_db=user_from_db["id"])

        valid_customers = self.extract_org_id_from_hsdp_org_id(fse_user["allowed_customers"])
        if len(valid_customers) is not len(fse_user["allowed_customers"]):
            LOG.error(f"Invalid customer_ids provided:{self.invalid_cust_ids}")
            raise RoccException(status_code=400,
                                title="Invalid Customer id provided",
                                payload=f"Failed to update Fse user. Invalid customers:{','.join(self.invalid_cust_ids)}",
                                additional_info=f"Failed to update Fse user. Invalid customers:{','.join(self.invalid_cust_ids)}")

        is_fse_user_updated = edit_fse_user(url=self._base_url, parent_token=self._parent_service_token, user_list=[new_user_object],
                                            org_id=self._profile_configs[VAULT_PARENT_ORG_ID], group_id=group_id, profile_configs=self._profile_configs)
        if not is_fse_user_updated:
            LOG.error("Failed to update FSE user's role")
            self.safe_audit(event_subtype="Edit Fse User role", action="U", outcome=8, code="Edit Fse User role", value="Failure")
            raise RoccException(status_code=500,
                                title="Role updation failed",
                                payload="Failed to update Fse User's role",
                                additional_info="Failed to update Fse User's role")
        LOG.info("*FSE User role is successfully updated*")
        self.safe_audit(event_subtype="Edit Fse User role", action="U", outcome=0, code="Edit Fse User role", value="Success")

        self.initiate_update_user_org_mapping(fse_user, user_from_db)
        LOG.info("*FSE User-Org Mapping is successfully *")
        self.safe_audit(event_subtype="Edit Fse User", action="U", outcome=0, code="Edit Fse User", value="Success")
        return {"status": 201, "data": "Fse user updated successfully"}

    def fetch_user_id_from_db(self, fse_user):
        try:
            user_obj = self._client.execute(fetch_user_db_id_from_uuid, variable_values={"user_uuid": fse_user["fse_user_hsdp_uuid"]})
            user_obj = user_obj["rocc_users"]
            if len(user_obj) == 0:
                raise RoccException(status_code=400,
                                    title="Invalid User",
                                    payload="Failed to fetch user detail from database")
            return user_obj[0]
        except RoccException as ex:
            raise ex
        except Exception as ex:
            raise RoccException(status_code=500,
                                title="Internal Server Error",
                                payload="Failed to fetch user detail from database") from ex

    def extract_org_id_from_hsdp_org_id(self, allowed_cust_list):
        self.invalid_cust_ids = []
        org_ids = []
        invalid_customers = []
        orgs_from_db = get_all_customers(self._client)
        if not orgs_from_db:
            return org_ids
        for allowed_cust_req_id in allowed_cust_list:
            customer_id_valid = False
            for org in orgs_from_db[ROCC_ORGANIZATIONS]:
                if allowed_cust_req_id == org[ORG_HSDP_UUID]:
                    org_ids.append(org[ID])
                    customer_id_valid = True
            if not customer_id_valid:
                invalid_customers.append(allowed_cust_req_id)
        self.invalid_cust_ids = invalid_customers

        return org_ids

    def initiate_update_user_org_mapping(self, fse_user, user_from_db):
        current_organization_mappings = get_organization_user_mappings(client=self._client, variable_values={"user_id": user_from_db[ID]})
        existing_org_mapping_ids = set()
        for org_detail in current_organization_mappings:
            existing_org_mapping_ids.add(org_detail["organization_id"])
        org_mapping_ids_to_be_removed = existing_org_mapping_ids.copy()

        allowed_customers_ids_to_add = set(self.extract_org_id_from_hsdp_org_id(fse_user["allowed_customers"]))
        allowed_customers_ids_in_request = allowed_customers_ids_to_add.copy()

        allowed_customers_ids_to_add.difference_update(existing_org_mapping_ids)
        org_mapping_ids_to_be_removed.difference_update(allowed_customers_ids_in_request)

        LOG.info(f"************org_mapping_to_be_removed {org_mapping_ids_to_be_removed}")
        LOG.info(f"************user_org_mapping_ids_to_add {allowed_customers_ids_to_add}")
        is_user_org_mapping_updated = self.update_orgs_user_mapping(deleted_org_ids=list(org_mapping_ids_to_be_removed),
                                                                    new_org_ids=list(allowed_customers_ids_to_add),
                                                                    fse_user_id=user_from_db[ID])
        if not is_user_org_mapping_updated:
            LOG.error(f"User updated successfully, but edit customer mapping failed, failed_customer_mapping:{fse_user['allowed_customers']}")
            self.safe_audit(event_subtype="Edit_fse_user_org_mapping", action="U", outcome=8, code="Edit_fse_user_org_mapping", value="Failure")
            raise RoccException(status_code=206,
                                title="Partially Completed",
                                payload=f"User updated successfully, but customer mapping failed, failed_customer_mapping:{fse_user['allowed_customers']}",
                                additional_info=f"User updated successfully, but customer mapping failed, failed_customer_mapping:{fse_user['allowed_customers']}")

    def is_email_format_valid(self, mail_id):
        if not re.search(EMAIL_FORMAT_REGEX, mail_id):
            LOG.error("invalid mail id provided")
            raise RoccException(status_code=400,
                                title="Invalid email id format",
                                payload=f"Invalid email id format provided:{mail_id}",
                                additional_info=f"Invalid email id format provided:{mail_id}")

    def is_role_name_valid(self, role_name, fse_roles_from_db):
        is_role_found = False
        for role in fse_roles_from_db:
            if role["role"] == role_name:
                is_role_found = True
                break
        return is_role_found

    def reinvite_fse_user(self, url, body, header):
        response_status = 500
        response_data = False
        try:
            response = requests.post(f"{os.environ['ROCC_PROXY_URL']}{url}", data=json.dumps(body), headers=header, timeout=10)
            if response.status_code == 201:
                LOG.info("re-invite fse user is successful")
                self.safe_audit(event_subtype="Reinvite Fse user", action="C", outcome=0, code="Reinvite Fse user post operation", value="Success")
                response_data = response.json()
                response_status = response.status_code
            else:
                response_status = response.status_code
                LOG.warning(f"Failed to re-invite fse user with response:{response.json()}")
                self.safe_audit(event_subtype="Reinvite Fse user", action="C", outcome=8, code="Reinvite Fse user post operation", value="failure")
        except Exception as ex:
            LOG.error(f"Failed to re-invite fse user:{ex}")
            self.safe_audit(event_subtype="Reinvite Fse user", action="C", outcome=8, code="Reinvite Fse user post operation", value="failure")
        return response_data, response_status

    def reactivate_fse_user(self, url, body, header):
        response_status = 500
        response_data = False
        try:
            response = requests.put(f"{os.environ['ROCC_PROXY_URL']}{url}", data=json.dumps(body), headers=header, timeout=10)
            if response.status_code == 200:
                LOG.info("Reactivate fse user is successful")
                self.safe_audit(event_subtype="Reactivate Fse user", action="U", outcome=0, code="Reactivate Fse user put operation", value="Success")
                response_data = response.json()
                response_status = response.status_code
            else:
                response_status = response.status_code
                LOG.warning(f"Failed to Reactivate fse user with response:{response.json()}")
                self.safe_audit(event_subtype="Reactivate Fse user", action="U", outcome=8, code="Reactivate Fse user put operation", value="failure")
        except Exception as ex:
            LOG.error(f"Failed to Reactivate fse user:{ex}")
            self.safe_audit(event_subtype="Reactivate Fse user", action="U", outcome=8, code="Reactivate Fse user put operation", value="failure")
        return response_data, response_status

    def delete_fse_user(self, url, header):
        response_status = 500
        response_data = False
        try:
            response = requests.delete(f"{os.environ['ROCC_PROXY_URL']}{url}", headers=header, timeout=10)
            if response.status_code == 200:
                LOG.info("Deactivate fse user is successful")
                self.safe_audit(event_subtype="Deactivate Fse user", action="D", outcome=0, code="Deactivate Fse user delete operation", value="Success")
                response_data = response.json()
                response_status = response.status_code
            else:
                response_status = response.status_code
                LOG.warning(f"Failed to deactivate fse user with response:{response.json()}")
                self.safe_audit(event_subtype="Deactivate Fse user", action="D", outcome=8, code="Deactivate Fse user delete operation", value="failure")
        except Exception as ex:
            LOG.error(f"Failed to deactivate fse user:{ex}")
            self.safe_audit(event_subtype="Deactivate Fse user", action="D", outcome=8, code="Deactivate Fse user delete operation", value="failure")
        return response_data, response_status

    def create_email_service_fse(self, token):
        base_url = os.environ.get("ROCC_OVERWATCH_URL")
        response_data, response_status = self.fetch_email_template_fse(token)
        if not response_data:
            raise RoccException(status_code=response_status,
                                title="Error fetching email Template",
                                payload="Failed to Fetch email template for parent org",
                                additional_info="Failed to Fetch email template for parent org")
        if response_data and response_data["total"] == 0:
            infra_config_prop = {INFRA_CFG_RECOVER_PASSWORD_URL: f"{base_url}/#/setpassword", INFRA_CFG_SET_PASSWORD_URL: f"{base_url}/#/setpassword", CUSTOMER_OB_LOCALE: "en-US"}
            success, error_reasn = create_email_templates_service(token=token, org_id=self._parent_org_uuid, infra_configs=infra_config_prop)
            if not success:
                LOG.warning(f"Failed to create email template for parent org:{error_reasn}")
                self.safe_audit(event_subtype="Create email template Fse user", action="C", outcome=8, code="Create email template Fse user post operation", value="Failure")
                raise RoccException(status_code=500,
                                    title="Error creating mail Template",
                                    payload="Failed to create email template for parent org",
                                    additional_info="Failed to create email template for parent org")
            LOG.info("create_email_templates_service success")
            self.safe_audit(event_subtype="Create email template Fse user", action="C", outcome=0, code="Create email template Fse user post operation", value="Success")

    def fetch_email_template_fse(self, token):
        response_status = 500
        response_data = False
        iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
        url = f"{self._profile_configs[VAULT_HSDP_IDM_URL]}{EMAIL_TEMPLATE_URI}"
        try:
            response = requests.get(url, headers=iam_headers, timeout=10)
            if response.status_code == 200:
                LOG.info("Fetch email template is successful")
                self.safe_audit(event_subtype="Fetch email template Fse user", action="R", outcome=0, code="Fetch email template Fse user get operation", value="Success")
                response_data = response.json()
                LOG.info(f"response_data: {response_data}")
                response_status = response.status_code
            else:
                response_status = response.status_code
                LOG.warning(f"Failed to fetch email template with response:{response.json()}")
                self.safe_audit(event_subtype="Fetch email template Fse user", action="D", outcome=8, code="Fetch email template Fse user get operation", value="failure")
        except Exception as ex:
            LOG.error(f"Failed to fetch email template:{ex}")
            self.safe_audit(event_subtype="Fetch email template Fse user", action="R", outcome=8, code="Fetch email template Fse user get operation", value="failure")
        return response_data, response_status

    def update_status_fse_user(self, email_id):
        LOG.info("update_status_fse_user")
        response_status = 500
        response_data = False
        is_user_status_updated = update_fse_user_status(self._client, email_id)
        if is_user_status_updated:
            response_data = "Fse User Status is updated successfully"
            response_status = 200
        return response_data, response_status
