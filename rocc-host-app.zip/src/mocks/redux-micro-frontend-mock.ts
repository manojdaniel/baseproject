/*
 * Created on Thu Aug 19 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export class GlobalStore {
    public static Get() {
        return {
            CreateStore: () => {
                return {
                    subscribe: () => {
                        return jest.fn()
                    },
                    getState: () => {
                        return {
                            "userReducer": {
                                appState: "INIT",
                                userState: "INIT",
                                loginMessage: "",
                                currentUser: {
                                    accessToken: "",
                                    allRoles: [],
                                    email: "",
                                    id: "",
                                    locale: "",
                                    modalities: [],
                                    name: "",
                                    onBoarded: false,
                                    orgId: "",
                                    phoneNumber: "",
                                    roomName: "",
                                    sessionId: "",
                                    siteId: [],
                                    status: "OFFLINE",
                                    uuid: "",
                                    clinicalRole: "DEFAULT",
                                    secondaryUUID: "",
                                    secondaryName: "",
                                },
                                unauthorised: false,
                                contactsFetched: false,
                                expertUserTransitionState: "DEFAULT",
                                contacts: [],
                                forceCleanUp: false,
                            },
                            "customerReducer": {
                                orgId: "123",
                                metaData: {
                                    name: "testName",
                                }
                            },

                            "configReducer": {
                                urls: {
                                    GRAPHQL_API_HSDP_URI: "GRAPHQL_API_HSDP_URI",
                                    GRAPHQL_API_HSDP_WS_URI: "GRAPHQL_API_HSDP_WS_URI",
                                },
                                configs: {
                                    ROCC_DEV: "true",
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
