/*
 * Created on Mon Jan 31 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import About from "./About"
import { EConnectionStatus } from "@rocc/rocc-client-services"


jest.mock("react-redux", () => ({
    useSelector: () => ({
        appReducer: {
            version: ""
        },
        configReducer: {
            configs: {
                REGION_UKI: false
            }
        },
        clientStatusReducer: {
            applicationConnectionState: EConnectionStatus.ONLINE
        }
    }),
    useDispatch: () => jest.fn(),
}))


describe("About Component", () => {
    let wrapper: any
    it("should render Modal component", () => {
        wrapper = shallow(<About companyName={"Philips"} applicationTitle={"ROCC"} isModalOpen={true} closeModal={() => ""} />)
        expect(wrapper.find("Modal")).toHaveLength(1)
    })
})
