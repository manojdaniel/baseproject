import React, { useEffect, useState } from "react";
import Header from "components/Header";
import { Search } from "../../DataModel/Search";
import { useDispatch, useSelector } from "react-redux";
import { Modal } from "antd";
import { useInterval } from "react-interval-hook";
import {
	getHeaderSearch,
	getGlobalSearch,
	getGlobalSelecetedRegion,
	getGlobalSelecetedAffiliate,
	getGlobalSelecetedPlant,
	getGlobalSelecetedAsset,
	updateLoggedInUserDetails,
	getLoggedInUserDetails,
} from "../../redux/reducers/CommonReducer";
import { useNavigate } from "react-router-dom";

function HeaderWrapper() {
	let timeoutInMinutes = 20;
	const [timeLeft, setTimeLeft] = useState(timeoutInMinutes);
	const [open, setOpen] = useState(false);

	const navigate = useNavigate();

	useEffect(() => {
		try {
			const hashRouteDefault = location.href.split("#")[1];
			if (hashRouteDefault.split("/")[0] != "") {
				navigate("/home");
			}
		} catch (error) { }
	}, [navigate]);

	useEffect(() => {
		try {
			const hashRouteDefault = location.href.split("#")[1];
			if (hashRouteDefault.split("/")[0] != "") {
				navigate("/home");
			}
		} catch (error) { }
	}, [navigate]);

	const hideModal = () => {
		setOpen(false);
	};

	// useInterval(() => {
	// 	dispatch(getLoggedInUserDetails(""));
	// }, 60000 * 1);

	useEffect(() => {
		let countdown;

		const resetTimeout = () => {
			setTimeLeft(timeoutInMinutes);
		};

		const decrementTime = () => {
			setTimeLeft((prevTime) => prevTime - 1);
		};

		const handleActivity = () => {
			resetTimeout();
		};

		const startTimer = () => {
			countdown = setInterval(decrementTime, 60000); // Decrease time left every minute (60000 milliseconds)
		};

		const stopTimer = () => {
			clearInterval(countdown);
		};

		const handleUnload = () => {
			stopTimer();
		};

		if (timeLeft === 0) {
			stopTimer();
			//	setOpen(true);
			localStorage.clear();
			sessionStorage.clear();
			navigate("/logout", { replace: true });
		}

		document.addEventListener("click", handleActivity);
		document.addEventListener("keydown", handleActivity);
		window.addEventListener("beforeunload", handleUnload);

		//	resetTimeout();
		startTimer();

		return () => {
			document.removeEventListener("click", handleActivity);
			document.removeEventListener("keydown", handleActivity);
			window.removeEventListener("beforeunload", handleUnload);
			stopTimer();
		};
	}, [timeoutInMinutes, timeLeft]);

	let dispatch = useDispatch();
	const [assetEnabled, setAssetEnabled] = useState(false);

	const {
		globalSearchData,
		globalSelecetedAsset,
		loggedInUserDetails,
		onePlantUser,
		userName,
		userRole,
		userEmail,
		userProfileActiveOn,
		oneAffiliateUser
	} = useSelector((state: any) => ({
		globalSearchData: state.Common.globalSearchData,
		globalSelecetedAsset: state.Common.globalSelecetedAsset,

		loggedInUserDetails: state.Common.loggedInUserDetails,
		userName: state.Common.userName,
		userRole: state.Common.userRole,
		onePlantUser: state.Common.onePlantUser,
		oneAffiliateUser: state.Common.oneAffiliateUser,
		userEmail: state.Common.userEmail,

		userProfileActiveOn: state.Common.userProfileActiveOn,
	}));

	useEffect(() => {
		/* Only when asset is selected Asset selection in header will be enabled */
		if (Object.keys(globalSelecetedAsset).length > 0) {
			setAssetEnabled(true);
		} else {
			setAssetEnabled(false);
		}
	}, [globalSelecetedAsset]);

	const handleSearchBack = (obj: any) => {
		switch (obj.identifier) {
			case "Region":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				break;
			case "Affiliate":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				break;
			case "Plant":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				dispatch(
					getGlobalSelecetedPlant({ value: obj.plantId, label: obj.plantName })
				);
				break;
			case "Asset":
				dispatch(
					getGlobalSelecetedRegion({
						value: obj.regionId,
						label: obj.regionName,
					})
				);
				dispatch(
					getGlobalSelecetedAffiliate({
						value: obj.affiliateId,
						label: obj.affiliateName,
					})
				);
				dispatch(
					getGlobalSelecetedPlant({ value: obj.plantId, label: obj.plantName })
				);
				dispatch(
					getGlobalSelecetedAsset({ value: obj.assetId, label: obj.assetId })
				);
				break;
		}
	};

	return (
		<>
			<Modal
				title="Session Timeout"
				open={open}
				onOk={hideModal}
				onCancel={hideModal}
				okText="OK"
				cancelText="Cancel"
			>
				<p>You are being timed out due to inactivity.</p>
				<p>Please choose to say signed in or to logoff.</p>
				<p>Otherwise, you will logged off automatically.</p>
			</Modal>
			<Header
				userData={loggedInUserDetails}
				data={globalSearchData}
				handleSearchBack={handleSearchBack}
				assetEnabled={assetEnabled}
				onePlantUser={onePlantUser}
				oneAffiliateUser={oneAffiliateUser}
				name={userName}
				userRole={userRole}
				userEmail={userEmail}
				userProfileActiveOn={userProfileActiveOn}
			/>
		</>
	);
}

export default HeaderWrapper;
