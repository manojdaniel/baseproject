# Changelog

## [1.0.17](https://github.com/philips-internal/rocc-calling-app/compare/1.0.16...1.0.17) (2022-11-10)


### Bug Fixes

* send logs to azure with additional tags and org id ([653a784](https://github.com/philips-internal/rocc-calling-app/commit/653a784d046abfa4d425472755db20e1c170d109))

## [1.0.16](https://github.com/philips-internal/rocc-calling-app/compare/1.0.15...1.0.16) (2022-11-04)


### Bug Fixes

* disconnect call when participant leaves before room join ([#289](https://github.com/philips-internal/rocc-calling-app/issues/289)) ([f16a8f7](https://github.com/philips-internal/rocc-calling-app/commit/f16a8f71e55ec4ef3eaa20307af237d013617827))

## [1.0.15](https://github.com/philips-internal/rocc-calling-app/compare/1.0.14...1.0.15) (2022-10-28)


### Bug Fixes

* sample commit to release build to QA ([48fda9d](https://github.com/philips-internal/rocc-calling-app/commit/48fda9d0048abf582e482f970659dd735a9d5f82))

## [1.0.14](https://github.com/philips-internal/rocc-calling-app/compare/1.0.13...1.0.14) (2022-10-20)


### Bug Fixes

* close call panel ([c07377b](https://github.com/philips-internal/rocc-calling-app/commit/c07377be6a8ae9e99b63b039600bc0f5ffb85bcb))
* code clean for ROCC_AV_COMMUNICATION_ADAPTER flag ([14d3537](https://github.com/philips-internal/rocc-calling-app/commit/14d3537f1343cdea8388fdd8aba2ace45399a24a))
* fixed lint issue ([b356aab](https://github.com/philips-internal/rocc-calling-app/commit/b356aab8717adc839507a030740e0e8fd94703f4))
* update counter ([1f6fe40](https://github.com/philips-internal/rocc-calling-app/commit/1f6fe40c8c814b393393488f451b39a4444dcff5))
* update counter for active call ([55fd915](https://github.com/philips-internal/rocc-calling-app/commit/55fd9159f8bd21f14ac98f1368a3eb2e71c6b052))
* updated cancel call logic ([81ec4e1](https://github.com/philips-internal/rocc-calling-app/commit/81ec4e19d7fd63c39255687f4185333b1de687f2))

## [1.0.13](https://github.com/philips-internal/rocc-calling-app/compare/1.0.12...1.0.13) (2022-10-14)


### Bug Fixes

* auto release for calling app to intg env ([5138d5e](https://github.com/philips-internal/rocc-calling-app/commit/5138d5e2bcc1093ccfbf30a8128a2aa892f9a071))


## [1.0.12](https://github.com/philips-internal/rocc-calling-app/compare/1.0.11...1.0.12) (2022-10-12)


### Bug Fixes

* release calling app to intg env ([be6b673](https://github.com/philips-internal/rocc-calling-app/commit/be6b673ed61ec43038558687e9d68ad42cb6eb0f))
* release calling app to intg env ([362a235](https://github.com/philips-internal/rocc-calling-app/commit/362a235ff01d06fd21afba2ff86a81ad6e2dc6d4))

## [1.0.11](https://github.com/philips-internal/rocc-calling-app/compare/1.0.10...1.0.11) (2022-10-03)


### Bug Fixes

* release new version for SL fix ([503f6a2](https://github.com/philips-internal/rocc-calling-app/commit/503f6a2be64e55c6413eb6b8588e2eeefb0e76f2))

## [1.0.10](https://github.com/philips-internal/rocc-calling-app/compare/1.0.9...1.0.10) (2022-09-28)


### Bug Fixes

* sample commit to release new version ([3b6a112](https://github.com/philips-internal/rocc-calling-app/commit/3b6a112824f42b2ac8ce9027747457abf58ff08e))

## [1.0.9](https://github.com/philips-internal/rocc-calling-app/compare/1.0.8...1.0.9) (2022-09-26)


### Bug Fixes

* remove unncessary spaces ([23f3306](https://github.com/philips-internal/rocc-calling-app/commit/23f33061ec954000c22055f14b5fcb7ce7bf3bc8))

## [1.0.8](https://github.com/philips-internal/rocc-calling-app/compare/1.0.7...1.0.8) (2022-09-20)


### Bug Fixes

* this is sample commit to enable autoversion ([decfb88](https://github.com/philips-internal/rocc-calling-app/commit/decfb887e88975140245b892f1bcc3b04d6872c7))

## [1.0.7](https://github.com/philips-internal/rocc-calling-app/compare/1.0.6...1.0.7) (2022-09-14)


### Bug Fixes

* merge conflicts are resolved ([214dc34](https://github.com/philips-internal/rocc-calling-app/commit/214dc343f3489c14a3b0c00906413fad0c19341d))

## [1.0.6](https://github.com/philips-internal/rocc-calling-app/compare/v1.0.5...1.0.6) (2022-09-12)


### Bug Fixes

* remove prefix v from version ([243f4a7](https://github.com/philips-internal/rocc-calling-app/commit/243f4a78ae143c2c20bd52aac1ba709e37cfbb88))

## [1.0.5](https://github.com/philips-internal/rocc-calling-app/compare/v1.0.4...v1.0.5) (2022-09-09)


### Bug Fixes

* enabled auto versioning ([181c828](https://github.com/philips-internal/rocc-calling-app/commit/181c82899c28b02c1d403c10786c30bc962c284d))

## [1.0.4](https://github.com/philips-internal/rocc-calling-app/compare/v1.0.3...v1.0.4) (2022-09-08)


### Bug Fixes

* enabled auto versioning ([92cb8a7](https://github.com/philips-internal/rocc-calling-app/commit/92cb8a7a6f2e787764627fcf2801cb1f6b5602f7))

## [1.0.3](https://github.com/philips-internal/rocc-calling-app/compare/v1.0.2...v1.0.3) (2022-08-03)


### Bug Fixes

* updated locales ([2c4b82b](https://github.com/philips-internal/rocc-calling-app/commit/2c4b82b78d41101d2aa99f5ac1dc3114e6a4c49c))
