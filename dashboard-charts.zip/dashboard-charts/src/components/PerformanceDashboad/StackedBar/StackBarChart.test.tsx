import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import StackBarChart from "./StackBarChart";

//Mock data for the chart component
const data = [
	{
		state: "Overdue",
		countofAlerts: 629,
	},
	{
		state: "Closed",
		countofAlerts: 49,
	},
	{
		state: "Under investigation",
		countofAlerts: 29,
	},
];

//Test Case to check chart exist in the component.
describe("StackBarChart", () => {
	it("renders the chart with data", () => {
		const { container } = render(<StackBarChart data={data} />);
		expect(container.querySelector("#chartdiv1")).toBeInTheDocument();
	});
});
