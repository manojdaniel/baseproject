export const AlertBreadCrumbsData = [
    {
        "regionId": 5,
        "regionName": "Middle East Africa",
        "affiliateId": 4,
        "affiliateName": "YANPET",
        "plantId": 18,
        "plantName": "POLY2",
        "assetId": "2k-3101",
        "assetName": "cycle gas presssure"
    }
]