/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECameraStreamAvailable, EClinicalRole, EConnectionMode, EConnectionState, EConnectionType, EOperationStatus, ETransactionStatus, IMediaRoomDetails, IMultiCameraListItem, TransactionValue } from "@rocc/rocc-client-services"
import * as globalComponent from "@rocc/rocc-global-components"
import * as consoleServices from "../../services/consoleService"
import { HTTP_STATUS } from "../constants/constants"
import { displayLoader, getCurrentConsoleSession, getEditConsoleStatus, getEditSessionRevokedContent, getEditSessionRevokedHeader, getEditSessionRevokedMessage, getOnGoingEmeraldForRoom, getRoomAdditionalAttributes, getViewOrPMConsoleStatus, handleAppUri, handleAuthorizeCCConnection, handleCCDisconnect,handleCCDisconnectAll, handleConsleSessionCleanUp, handleConsoleSwitch, handleDirectCCConnection, handleTransitionConnectionState, hasReceivers, isIncognitoPMNFCCPossible } from "./consoleUtility"
import * as helpers from "./helpers"

const mockDispatch = jest.fn()

jest.mock("../../redux/actions/consoleActions", () => ({
    resetConsoleSession: jest.fn(),
    updateConsoleSession: jest.fn(),
    setConsoleOperations: jest.fn(),
}))

jest.mock("./TelemetryTrackingHelper", () => ({
    trackConsoleDisconnection: jest.fn(),
    trackConsoleSwitching: jest.fn(),
}))
jest.mock("@rocc/rocc-logging-module", () => ({
    errorLogger: jest.fn(),
    infoLogger: jest.fn(),
    errorParser: jest.fn().mockReturnValue({}),
}))

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        consoleReducer: {
            commandCenterDetails: {
                commandCenterSeat: { receivers: [{ id: "id" }] },
            },
            consoleSessions: [{ contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC },
            {
                contextId: "contextId2", roomUuid: "roomUuid2", consoleStartTime: new Date(), connectionType: EConnectionType.FULL_CONTROL,
                connectionMode: EConnectionMode.CC, connectionStatus: EConnectionState.IN_TRANSITION_STATE
            }],
            consoleOperation: { transactions: [] }
        },
        externalReducer: {
            rooms: [{
                roomUuid: "id",
                additionalAttributes: {
                    ncc_edit: true
                }
            }],
            permissions: { CONSOLE_VIEW_INCOGNITO: true }
        }
    })
}))

jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        CONSOLE_SERVICES_URL: "https://CONSOLE_SERVICES_URL"
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValue({
        MAX_NUM_OF_CONSOLE_SESSION: "3",
        MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE: "2",
        MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE: "2",
    }),
    fetchGlobalCurrentUser: jest.fn().mockReturnValue({
        currentUser: {
            clinicalRole: EClinicalRole.EXPERTUSER
        }
    }),
    dispatchToParentStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useDispatch: () => mockDispatch
}))

describe("handleConsoleSwitch tests", () => {
    const props: any = {
        currentSession: { roomUuid: "roomUuid", additionalData: { transitionDetails: true } },
        newConnectionType: EConnectionType.VIEW,
        newConnectionState: EConnectionState.PARKED,
        dispatch: mockDispatch,
        accessToken: "accessToken"
    }
    it("should call switch console service and handle positive response", async () => {
        const spy = jest.spyOn(consoleServices, "consoleSwitchService").mockReturnValue(
            Promise.resolve({
                respStatus: HTTP_STATUS.OK,
                respContextId: "newContextId",
                respMessage: "responseMessage",
            })
        )

        const returnValue = await handleConsoleSwitch(props)
        expect(spy).toBeCalled()
        expect(mockDispatch).toBeCalled()
        expect(returnValue).toBe(ETransactionStatus.FINISHED)
    })

    it("should call switch console service and handle negative response", async () => {
        const spy = jest.spyOn(consoleServices, "consoleSwitchService").mockReturnValue(
            Promise.resolve({
                respStatus: HTTP_STATUS.INTERNAL_SERVER_ERROR,
                respContextId: "newContextId",
                respMessage: "responseMessage",
            })
        )

        const displayModalSpy = jest.spyOn(helpers, "displayErrorModal")

        const returnValue = await handleConsoleSwitch(props)
        expect(spy).toBeCalled()
        expect(displayModalSpy).toBeCalled()
        expect(returnValue).toBe(ETransactionStatus.FAILED)
    })

    it("should handle switch console service exception", async () => {
        const spy = jest.spyOn(consoleServices, "consoleSwitchService").mockImplementation(
            () => { throw new Error() }
        )

        const displayModalSpy = jest.spyOn(helpers, "displayErrorModal")

        const returnValue = await handleConsoleSwitch(props)
        expect(spy).toBeCalled()
        expect(displayModalSpy).toBeCalled()
        expect(returnValue).toBe(ETransactionStatus.FAILED)
    })
})

describe("handleDirectCCConnection tests", () => {
    const props: any = {
        consoleTransaction: {
            connectionType: EConnectionType.VIEW,
            roomUuid: "roomUuid",
            receiverName: "Dev-receiver"
        },
        consoleSessions: [{ roomUuid: "roomUuid", additionalData: { transitionDetails: true } },
        { roomUuid: "roomUuid", additionalData: { transitionDetails: true } }],
        currentUser: { ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US" },
        dispatch: jest.fn(),
        seatName: "PHSEAT03"
    }
    it("shouble able to initiate console session", () => {
        const spy = jest.spyOn(consoleServices, "initiateCCConsoleService").mockReturnValue(Promise.resolve("contextId"))
        handleDirectCCConnection(props)
        expect(spy).toBeCalled()
    })

    it("shouble able to initiate new console session", () => {
        props.consoleSessions = []
        const spy = jest.spyOn(consoleServices, "initiateCCConsoleService").mockReturnValue(Promise.resolve("contextId"))
        handleDirectCCConnection(props)
        expect(spy).toBeCalled()
    })

    it("shouble return empty response", () => {
        const spy = jest.spyOn(consoleServices, "initiateCCConsoleService").mockReturnValue(Promise.resolve(""))
        handleDirectCCConnection(props)
        expect(spy).toBeCalled()
    })

    it("shouble throw exception", () => {
        const spy = jest.spyOn(consoleServices, "initiateCCConsoleService").mockReturnValue(Promise.reject(new Error()))
        handleDirectCCConnection(props)
        expect(spy).toBeCalled()
    })
})

describe("handleCCDisconnect tests", () => {
    const props: any = {
        currentSession: { contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC },
        currentUser: { ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US" },
        dispatch: jest.fn(),
        componentName: ""
    }
    it("should able to disconenct console session", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.resolve(HTTP_STATUS.NO_CONTENT))
        handleCCDisconnect(props)
        expect(spy).toBeCalled()
    })

    it("should able to disconenct console session", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.resolve(HTTP_STATUS.ALREADY_REPORTED))
        handleCCDisconnect(props)
        expect(spy).toBeCalled()
    })

    it("should able to disconenct console session", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.resolve(HTTP_STATUS.INTERNAL_SERVER_ERROR))
        handleCCDisconnect(props)
        expect(spy).toBeCalled()
    })

    it("should throw exception", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.reject(new Error()))
        handleCCDisconnect(props)
        expect(spy).toBeCalled()
    })
})

describe("handleCCDisconnectAll tests", () => {
    const props: any = {
        consoleSessions: [{
            contextId: "f59192df-0e4a-400c-b464-556bd1a72574",
            requester: "e39e2723-cba2-4c22-9003-a41faaae5ad0",
            roomUuid: "5080ba3d-f77c-4962-a38e-ea1620f58fe8",
            connectionType: EConnectionType.VIEW,
            connectionMode: EConnectionMode.CC,
            displayCameraToggle: true,
            mediaRoomDetails: { mediaRoomId: "", mediaRoomToken: "", cameraStreamAvailable: ECameraStreamAvailable.IDLE },
            multiCameraList: [],
            connectionStatus: EConnectionState.DEFAULT,
            receiverName: "1",
            consoleStartTime: ""
        }],
        currentUser: { ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US" },
        dispatch: jest.fn(),
        componentName: ""
    }
    it("should able to disconenct console session", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.resolve(HTTP_STATUS.INTERNAL_SERVER_ERROR))
        handleCCDisconnectAll(props)
        expect(spy).toBeCalled()
    })

    it("should throw exception", () => {
        const spy = jest.spyOn(consoleServices, "disconnectConsoleService").mockReturnValue(Promise.reject(new Error()))
        handleCCDisconnectAll(props)
        expect(spy).toBeCalled()
    })
})


describe("Handle handleAuthorizeCCConnection tests", () => {
    const props: any = {
        contextId: "contextId",
        currentUser: { ...DEFAULT_CONTACT_INFO, },
        dispatch: jest.fn(),
        consoleTransaction: {
            receiverName: "roomUuid", connectionType: EConnectionType.FULL_CONTROL, roomUuid: "roomUuid",
        }
    }
    beforeEach(() => {
        jest.spyOn(globalComponent, "getIntlProvider").mockReturnValue({
            intl: {
                formatMessage: jest.fn().mockReturnValue("CallMessage")
            }
        })
    })
    it("should return success response", () => {
        const spy = jest.spyOn(consoleServices, "initiateAuthorizeCCConsoleService").mockReturnValue(Promise.resolve(HTTP_STATUS.OK))
        jest.spyOn(helpers, "fetchCallContextForRoomUuid").mockReturnValue(undefined)
        handleAuthorizeCCConnection(props).then(response => expect(response).toBe(ETransactionStatus.FINISHED))
        expect(spy).toHaveBeenCalled()
    })
})

describe("getCurrentConsoleSession tests", () => {
    const currentSessions: any = [{ contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC }]
    it("should return current Session", () => {
        expect(getCurrentConsoleSession(currentSessions, "contextId")?.contextId).toEqual("contextId")
    })
})

describe("getViewOrPMConsoleStatus tests", () => {
    const props: any = {
        consoleSessions: [{ roomUuid: "roomUuid", connectionType: EConnectionType.VIEW }],
        consoleOperation: { operationStatus: EOperationStatus.RUNNING, transactions: [{ transactionStatus: ETransactionStatus.RUNNING, connectionType: EConnectionType.VIEW, roomUuid: "roomUuid", }] },
        roomUuid: "roomUuid",
        connectionType: EConnectionType.VIEW,
        protocolTransferStatus: false
    }

    it("should return active connectionState", () => {
        expect(getViewOrPMConsoleStatus(props).connectionState).toBe(true)
    })

    it("should return false connectionState", () => {
        props.connectionType = EConnectionType.FULL_CONTROL
        expect(getViewOrPMConsoleStatus(props).disabled).toBe(true)
    })
})

describe("getEditConsoleStatus tests", () => {
    const props: any = {
        consoleSessions: [{ roomUuid: "roomUuid", connectionType: EConnectionType.FULL_CONTROL }],
        consoleOperation: { operationStatus: EOperationStatus.RUNNING, transactions: [{ transactionStatus: ETransactionStatus.RUNNING, connectionType: EConnectionType.FULL_CONTROL, roomUuid: "roomUuid", }] },
        roomDetails: { identity: "id" },
        connectionType: EConnectionType.FULL_CONTROL,
        protocolTransferStatus: false,
        workflows: [],
    }

    it("should return active connectionState", () => {
        expect(getEditConsoleStatus(props).connectionState).toBe(false)
    })

    it("should return false connectionState", () => {
        props.roomUuid = "roomUuid1"
        expect(getEditConsoleStatus(props).disabled).toBe(true)
    })
})

describe("getOnGoingEmeraldForRoom tests", () => {
    const props: any = {
        consoleSessions: [{ roomUuid: "roomUuid", connectionType: EConnectionType.FULL_CONTROL }],
        roomUuid: "roomUuid",
        connectionState: TransactionValue.START_EMERALD_APP,
        accessToken: "token",
        contextId: "contectId",
    }

    it("should return getOnGoingEmeraldForRoom", () => {
        expect(getOnGoingEmeraldForRoom(props.consoleSessions, props.roomUuid)).toBe(undefined)
    })
})

describe("handleAppUri tests", () => {
    const props: any = {
        consoleSessions: [{ roomUuid: "roomUuid", connectionType: EConnectionType.FULL_CONTROL }],
        roomUuid: "roomUuid",
        connectionState: TransactionValue.START_EMERALD_APP,
        accessToken: "token",
        contextId: "contectId",
    }

    it("should return getOnGoingEmeraldForRoom", () => {
        expect(handleAppUri(props)).toBeInstanceOf(Object)
    })
})

describe("displayLoader tests", () => {
    const props: any = {
        content: "",
        inverted: false
    }
    it("should return loader", () => {
        expect(displayLoader(props)).toBeDefined()
    })
})

describe("getEditSessionRevokedHeader tests", () => {
    it("should return header", () => {
        expect(getEditSessionRevokedHeader()).toBeDefined()
    })
})

describe("getEditSessionRevokedContent tests", () => {
    it("should return content", () => {
        expect(getEditSessionRevokedContent("123")).toBeDefined()
    })
})

describe("getEditSessionRevokedMessage tests", () => {
    it("should return modal", () => {
        expect(getEditSessionRevokedMessage("123")).toBeDefined()
    })
})
describe("handleConsleSessionCleanUp tests", () => {
    it("should return modal", () => {
        expect(handleConsleSessionCleanUp(jest.fn(), [], ETransactionStatus.FAILED)).toBeUndefined()
    })
})
describe("isIncognitoPMNFCCPossible tests", () => {
    it("should if IncognitoPMNFCCPossible", () => {
        expect(isIncognitoPMNFCCPossible(true)).toBeTruthy()
    })
})
describe("getRoomAdditionalAttributes tests", () => {
    it("should return getRoomAdditionalAttributes", () => {
        expect(getRoomAdditionalAttributes("id")).toBeDefined()
    })
})
describe("hasReceivers tests", () => {
    it("should return id receiver exits", () => {
        expect(hasReceivers()).toBeTruthy()
    })
})
describe("handleTransitionConnectionState", () => {
    it("should handle Transition Connection State", () => {
        const currentSession = {
            contextId: "contextId2",
            requester: "",
            roomUuid: "roomUuid2",
            consoleStartTime: "",
            connectionType: EConnectionType.FULL_CONTROL,
            connectionMode: EConnectionMode.CC,
            connectionStatus: EConnectionState.CONNECTED,
            additionalData: {},
            receiverName: "",
            displayCameraToggle: false,
            mediaRoomDetails: {} as IMediaRoomDetails,
            multiCameraList: [] as IMultiCameraListItem[],
        }
        handleTransitionConnectionState(currentSession, mockDispatch)
        expect(mockDispatch).toHaveBeenCalled()
    })
})
