/*
 * Created on Tue Nov 16 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { defineMessages, IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import { EN_LOCALE, EN_LANGUAGE } from "./common/constants/constants"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import { isDev } from "./common/helpers/helpers"
import CommandCenterLocationsSettings from "./components/command-center-locations-settings/CommandCenterLocationsSettings"
import store, { persistor } from "./redux/store/store"
import messages from "./resources/translations/messages"

const CommandCenterSettingsFeature = () => {
    const httpClient = useRoccHttpClient()
    const locale = sessionStorage.getItem("locale")
    const language = sessionStorage.getItem("language")
    useEffect(() => {
        setupLogger({ isDev: isDev() })
        setupAxiosHandler(httpClient)
    }, [])
    const defaultLocale = language || EN_LOCALE
    const defaultMessage = (locale: string) => defineMessages(messages[locale])
    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                <HttpClientProvider client={httpClient}>
                    <IntlProvider
                        defaultLocale={defaultLocale}
                        locale={defaultLocale}
                        messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
                    >
                        <>
                            <CommandCenterLocationsSettings />
                        </>
                    </IntlProvider>
                </HttpClientProvider>
            </PersistGate>
        </Provider>
    </>
}

export default CommandCenterSettingsFeature
