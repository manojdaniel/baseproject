import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import DatePickerComponent from "./index";

describe("DatePickerComponent", () => {
	// Test that the component renders without crashing
	it("should render without crashing", () => {
		render(
			<DatePickerComponent
				selectedDate={new Date("2022-01-01")}
				handleDateChange={() => {}}
			/>
		);
	});

	// // Test that handleDateChange is called with the correct value when a new date is selected
	// it("should call handleDateChange with the correct value when a new date is selected", () => {
	//   const handleDateChange = jest.fn();
	//   const { container } = render(
	//     <DatePickerComponent
	//       selectedDate={new Date("2022-01-01")}
	//       handleDateChange={handleDateChange}
	//     />
	//   );

	//   const input = container.querySelector("input");
	//   fireEvent.change(input, { target: { value: "02/01/2022" } });

	//   expect(handleDateChange).toHaveBeenCalledWith(new Date("2022-02-01"));
	// });

	// // Test that the DatePicker only shows dates up to today's date
	// it("should only show dates up to today's date", () => {
	//   const today = new Date();
	//   const { container } = render(
	//     <DatePickerComponent
	//       selectedDate={today}
	//       handleDateChange={() => {}}
	//     />
	//   );

	//   const input = container.querySelector("input");
	//   expect(input).toHaveAttribute(
	//     "max",
	//     `${today.getFullYear()}-${(today.getMonth() + 1)
	//       .toString()
	//       .padStart(2, "0")}-${today.getDate().toString().padStart(2, "0")}`
	//   );
	// });

	// // Test that the DatePicker has the correct date format
	// it("should have the correct date format", () => {
	//   const { container } = render(
	//     <DatePickerComponent
	//       selectedDate={new Date("2022-01-01")}
	//       handleDateChange={() => {}}
	//     />
	//   );

	//   const input = container.querySelector("input");
	//   expect(input).toHaveAttribute("placeholder", "dd/M/yyyy");
	// });

	// // Test that the DatePicker is displayed inline
	// it("should be displayed inline", () => {
	//   const { container } = render(
	//     <DatePickerComponent
	//       selectedDate={new Date("2022-01-01")}
	//       handleDateChange={() => {}}
	//     />
	//   );

	//   const datePicker = container.querySelector(".react-datepicker");
	//   expect(datePicker).toHaveStyle("display: inline-block");
	// });
});
