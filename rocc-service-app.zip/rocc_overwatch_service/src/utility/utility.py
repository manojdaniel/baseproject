"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import random
import re
import string

from src.constants.constants import IP_FORMAT
from src.loggers.log import create_logger

LOG = create_logger("Utility")


def generate_random_string_with_special_character(inp, length, special_characters_set=["-", "!", ".", "_", "{"]):
    """ Returns a random string with a special character and number """
    try:
        random_number = random.randint(0, 9)
        random_special_characters = random.choice(special_characters_set)
        random_capital_character = random.choice(string.ascii_letters.upper())
        random_lowercase_character = random.choice(
            string.ascii_letters.lower())
        res = "".join(random.choices(inp, k=length - 4))
        return f"{str(res)}{str(random_number)}{random_capital_character}{random_lowercase_character}{random_special_characters}"
    except Exception as ex:
        LOG.error(f"Failed to generate random string with error: {ex}")


def generate_random_string(inp, length):
    """ Returns a random string with a number """
    try:
        random_number = random.randint(0, 9)
        res = "".join(random.choices(inp, k=length - 1))
        return f"{str(res)}{str(random_number)}"
    except Exception as ex:
        LOG.error(f"Failed to generate random string with error: {ex}")


def construct_negative_response(code, title, error_message, additional_info=None):
    """
    Response structure:
        {
            "resourceType": "OperationOutcome",
            "id": "<title>",
            "issue": [
                {
                    "severity": "error",
                    "code": <code>,
                    "details": {
                        "text": "<error_message>"
                    }
                }
            ]
        }
    """
    details = {
        "text": error_message,
    }

    if additional_info is not None:
        details["additionalInformation"] = additional_info

    return {
        "resourceType": "OperationOutcome",
        "id": title,
        "issue": [
            {
                "severity": "error",
                "code": code,
                "details": details
            }
        ]
    }


def get_str_value(item):
    try:
        return str(int(item))
    except Exception:
        try:
            return str(int(float(item)))
        except Exception:
            return str(item)


def check_if_array_is_empty(array):
    return bool(len(array) == 0)


def log_error_reasons(log, log_type, error_reason, method_name):
    if error_reason:
        if log_type == "error":
            log.error(
                f"Found error in method: {method_name} due to reason: {error_reason}")
        elif log_type == "info":
            log.info(f"{error_reason} in method {method_name}")


def log_to_handle_unused_variable(log, *args):
    try:
        msg = ""
        for arg in args:
            msg = msg + str(type(arg))
        log.debug(f"Logging to handle unused variable: {msg}")
    except Exception as ex:
        log.exception(f"Logging of unused variable activity failed with error: {ex}")


def check_ip_format(ip_address):
    ip_addr = re.match(IP_FORMAT, ip_address)
    return bool(ip_addr)
