/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EFetchStatus, getUserByUUID, IContactInfo, IParentStore, IRoomDetails } from "@rocc/rocc-client-services"
import { errorParser } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { errorLogger } from "@rocc/rocc-logging-module"
import { fetchLocationInfoForCurrentUser } from "../services/customerServices"
import { FETCH_LOCATION_DATA, FETCH_LOCATION_DATA_FAILED, UPDATE_CUSTOMER_ORG_ID, UPDATE_ROOM_PRESENCE } from "./types"

const FILENAME = "customerActions.tsx:"

export const setCustomerOrgId = (orgId: string, dispatch: Dispatch) => {
    dispatch({ type: UPDATE_CUSTOMER_ORG_ID, orgId })
}

export const fetchLocationData = (uuid: string, deviceUuids?: String[]) => async (dispatch: Dispatch, getState: any) => {
    try {
        const state: IParentStore = getState()
        const { orgId } = state.customerReducer.metaData
        //captureLoadTimesAction(ELoadTimes.CUSTOMER_DATA_INIT, dispatch)
        const { customerMetaData, locations, rooms } = await fetchLocationInfoForCurrentUser(uuid, deviceUuids)
        customerMetaData.orgId = orgId
        //captureLoadTimesAction(ELoadTimes.CUSTOMER_DATA_COMPLETE, dispatch)
        dispatch({ type: FETCH_LOCATION_DATA, customerMetaData, locations, rooms, initRoomsFetched: true })
    } catch (error) {
        errorLogger(`${FILENAME} Fetching Hospital/DIC data failed with: ${errorParser(error)}`)
        dispatch({ type: FETCH_LOCATION_DATA_FAILED, locationFetched: EFetchStatus.failed })
    }
}

export const getTechnologistName = async (contacts: IContactInfo[], loggedInTech: string) => {
    let techUserName: string = ""
    if (loggedInTech !== "") {
        const loggedInContact = await getUserByUUID(contacts, loggedInTech)
        techUserName = loggedInContact && loggedInContact.id !== "" ? loggedInContact.name : ""
    }
    return techUserName
}

export const updateAllRoomPresence = (rooms: IRoomDetails[]) => (dispatch: Dispatch) => {
    dispatch({ type: UPDATE_ROOM_PRESENCE, rooms })
}
