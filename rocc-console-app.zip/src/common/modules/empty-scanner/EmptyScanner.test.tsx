/*
 * Created on Thu Nov 05 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import EmptyScanner from "./EmptyScanner"

describe("EmptyScanner component", () => {
    let wrapper: any
    let componentDivs: any

    const mockProps = {
        messageId: "content.scannerEmpty.source",
        defaultMessage: "Source",
        isHighlighted: false,
    }
    beforeEach(() => {
        wrapper = shallow(<EmptyScanner
            messageId={mockProps.messageId}
            defaultMessage={mockProps.defaultMessage}
            isHighlighted={mockProps.isHighlighted}
        />)
        componentDivs = wrapper.find("div")
    })
    it("should render div elements", () => {
        expect(componentDivs).toHaveLength(2)
    })
})
