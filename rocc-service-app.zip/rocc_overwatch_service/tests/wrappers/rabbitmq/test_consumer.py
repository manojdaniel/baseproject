"""
 Created on Mon May 23 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""


import unittest

from unittest.mock import patch
from pika.exceptions import AMQPChannelError, ConnectionClosedByBroker, StreamLostError
from src.constants.constants import ROCC_SERVICE_TOOL_ROUTING_KEY
from src.exceptions.RoccException import RoccException

from src.wrappers.rabbitmq.consumer import ConsumerConfig, Consumer
from tests.mocks.mock_rabbitmq import MockBlockingConnection, MockURLParameters


class TestConsumer(unittest.TestCase):
    def mock_call_back(self):
        pass

    def test_consumer_class_init(self):
        with self.assertRaises(RoccException):
            consumer_ob = Consumer(ConsumerConfig(host="//DUmmyY6pI8EVPyAOjn4s:dUmmYtTMf3FJiKvXahL1@ip:port/dummy",
                                                  queue="dummy_queue",
                                                  exchange="dummy_exchange",
                                                  routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                                  callback=self.mock_call_back))
            consumer_ob.initialize_channel()

    @patch("src.wrappers.rabbitmq.consumer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.consumer.pika.URLParameters", side_effect=MockURLParameters)
    def test_consumer_init_channel(self, m_pbc, m_pup):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.initialize_channel()
        m_pbc.assert_called()
        m_pup.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.consumer.pika.URLParameters", side_effect=MockURLParameters)
    def test_consumer_listener(self, m_pbc, m_pup):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.listener()
        m_pbc.assert_called()
        m_pup.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.Consumer.initialize_channel", side_effect=ConnectionClosedByBroker)
    @patch("src.wrappers.rabbitmq.consumer.Consumer.close_connection", side_effect=lambda: None)
    def test_consumer_listener_connectionclosedbybroker_exception(self, m_ic, m_cc):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.listener()
        m_ic.assert_called()
        m_cc.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.Consumer.initialize_channel", side_effect=StreamLostError)
    @patch("src.wrappers.rabbitmq.consumer.Consumer.close_connection", side_effect=lambda: None)
    def test_consumer_listener_streamlosterror_exception(self, m_ic, m_cc):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.listener()
        m_ic.assert_called()
        m_cc.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.Consumer.initialize_channel", side_effect=AMQPChannelError)
    def test_consumer_listener_amqpchannelerror_exception(self, m_ic):
        with self.assertRaises(RoccException):
            consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                                  queue="dummy_queue",
                                                  exchange="dummy_exchange",
                                                  routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                                  callback=self.mock_call_back))
            consumer_ob.listener()
            m_ic.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.Consumer.initialize_channel", side_effect=Exception)
    @patch("src.wrappers.rabbitmq.consumer.Consumer.close_connection", side_effect=lambda: None)
    def test_consumer_listener_exception(self, m_ic, m_cc):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.listener()
        m_ic.assert_called()
        m_cc.assert_called()

    @patch("src.wrappers.rabbitmq.consumer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.consumer.pika.URLParameters", side_effect=MockURLParameters)
    def test_check_and_attach_if_consumers_are_not_bound(self, m_pbc, m_pup):
        consumer_ob = Consumer(ConsumerConfig(host="rabbitmq_host",
                                              queue="dummy_queue",
                                              exchange="dummy_exchange",
                                              routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                              callback=self.mock_call_back))
        consumer_ob.listener()
        consumer_ob.check_and_attach_if_consumers_are_not_bound()
        m_pbc.assert_called()
        m_pup.assert_called()


suite = unittest.TestSuite()

suite.addTest(TestConsumer("test_consumer_class_init"))
suite.addTest(TestConsumer("test_consumer_init_channel"))
suite.addTest(TestConsumer("test_consumer_listener"))
suite.addTest(TestConsumer("test_consumer_listener_connectionclosedbybroker_exception"))
suite.addTest(TestConsumer("test_consumer_listener_streamlosterror_exception"))
suite.addTest(TestConsumer("test_consumer_listener_amqpchannelerror_exception"))
suite.addTest(TestConsumer("test_consumer_listener_exception"))
suite.addTest(TestConsumer("test_check_and_attach_if_consumers_are_not_bound"))

unittest.TextTestRunner(verbosity=0).run(suite)
