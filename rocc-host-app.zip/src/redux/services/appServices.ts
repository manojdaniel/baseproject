/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { graphqlClient, IUrls, IUserPermissions, DEFAULT_PERMISSION_LIST, EAppStates, IParentStore } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { APPLICATION_JSON, APP_URL_BASENAME, CONTENT_TYPE, DEFAULT_LOCAL_VALUE, FSE_ADMIN_GROUP, HTTP_STATUS } from "../../constants/constants"
import { APP_CONFIG_URI, DEFAULT_CONFIG_URI, PHILIPS_API_URI } from "../../constants/endpoints"
import { QUERY_GET_VERSION } from "../../graphql/queries/queries"
import { getCall } from "../../utility/api/apiUtility"
import { isDev } from "../../utility/storage/storageUtility"
import { SET_APPSTATE, SET_AUTH_CONFIGS } from "../actions/types"
import store from "../store/store"

export const computePermissionList = (rawPermissions: string[]) => {
    const newObjList: any[] = []
    Object.entries(DEFAULT_PERMISSION_LIST).forEach((entry) => {
        if (rawPermissions && rawPermissions.includes(entry[0])) {
            entry[1] = true
        }
        newObjList.push(entry)
    })

    return Object.fromEntries(newObjList) as IUserPermissions
}

export const initalizeUrls = (urls: IUrls) => {
    urls.COMMUNICATION_SERVICES_URL = setEndpoint(urls.COMMUNICATION_SERVICES_URL, PHILIPS_API_URI)
    urls.IAM_SERVICES_URL = setEndpoint(urls.IAM_SERVICES_URL, PHILIPS_API_URI)
    urls.MANAGEMENT_SERVICE_URL = setEndpoint(urls.MANAGEMENT_SERVICE_URL, PHILIPS_API_URI)
    urls.CONSOLE_SERVICES_URL = setEndpoint(urls.CONSOLE_SERVICES_URL, PHILIPS_API_URI)
    urls.RBAC_SERVICE_URL = setEndpoint(urls.RBAC_SERVICE_URL, PHILIPS_API_URI)
    urls.PROXY_URL = setEndpoint(urls.PROXY_URL, PHILIPS_API_URI)
    return urls
}

const setEndpoint = (envItem: string | undefined, ep: string) => {
    return envItem ? envItem + ep : ep
}

export const fetchVersionService = async (appName: string) => {
    try {
        const result = await graphqlClient.query({
            query: QUERY_GET_VERSION,
            variables: { appName },
        })
        return result.data.configurationVariable[0].appVersion
    } catch (error) {
        errorLogger(`Fetching Version failed with: ${errorParser(error)}`)
        return "Version not available"
    }
}

export const setFseModeService = (allOrgList: any[], isProxy: string = "false") => {
    const fseData = { isFse: false, customerName: "", customerOrgId: "" }
    let customerName = ""
    if (isProxy === "true") {
        customerName = window.location.hostname.split(APP_URL_BASENAME)[0]
    }
    if (isDev() && process.env.CUSTOMER_NAME) { customerName = process.env.CUSTOMER_NAME }
    try {
        if (customerName) {
            allOrgList.forEach((item) => {
                if (customerName === item.organizationName && [...item.groups].includes(FSE_ADMIN_GROUP)) {
                    fseData.customerName = customerName
                    fseData.customerOrgId = item.organizationId
                    fseData.isFse = true
                }
            })
        }
    } catch (error) {
        errorLogger(`Computing fseMode failed with: ${errorParser(error)}`)
    }
    return fseData
}

export const fetchDefaultConfiguration = async () => {
    try {
        const baseUrl = isDev() ? process.env.ROCC_PROXY_URL : window.location.origin
        const url = `${baseUrl}${DEFAULT_CONFIG_URI}`
        const response = await getCall({
            url, headers: {
                [CONTENT_TYPE]: APPLICATION_JSON,
            }
        })
        if (response.status === HTTP_STATUS.OK) {
            return response.data
        }
    } catch (error) {
        errorLogger(`Failed to fetch default configuration : ${errorParser(error)}`)
    }
    return DEFAULT_LOCAL_VALUE
}

export const getAuthConfigs = async (dispatch: Dispatch<any>) => {
    const state: IParentStore = store.getState()
    try {
        dispatch({ type: SET_APPSTATE, appState: EAppStates.LOADING })
        const baseUrl = isDev() ? process.env.ROCC_PROXY_URL : window.location.origin
        const url = `${baseUrl}${APP_CONFIG_URI}`
        const response = await getCall({
            url, headers: {
                [CONTENT_TYPE]: APPLICATION_JSON,
            }
        })

        if (response.status === HTTP_STATUS.OK) {
            /* Load the iam js file based on region */
            if (!document.getElementById("iamScript")) {
                const script = document.createElement("script")
                script.type = "text/javascript"
                script.id = "iamScript"
                script.src = `${response.data.authEndpoint}/resources/iam_authorization-2.0.0.js`
                document.head.appendChild(script)
            }
            dispatch({
                type: SET_AUTH_CONFIGS,
                appClientId: response.data.authClientId,
                authUrl: response.data.authEndpoint,
                otpAllowTrustDevice: response.data.otpAllowTrustDevice ?? false,
                redirectUrl: `${window.location.origin}${window.location.pathname}`
            })
        }
    } catch (error) {
        errorLogger(`Failed to fetch default configuration : ${errorParser(error)}`)
    }
    dispatch({ type: SET_APPSTATE, appState: state.userReducer.appState })
}
