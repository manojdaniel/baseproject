// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
	getutilizationreporttable,
	getAlertManagementYearDropdown,
	getAlertManagementMonthDropdown
} from "../../../../redux/reducers/CommonReducer";
import UtilizationReportTable from "table/UtilizationReportTable";
// calendar============start
import ReportCalendarPopup from "../../../../components/ReportCalendarPopup/ReportCalendarPopup";
import useOnClickOutside from "../../../../hooks/useOnClickOutside";
import moment from "moment";
import iconCalendar from "../../../../assets/images/icon_calendar.svg";
import "../AlertManagementPage.scss";
import { encryptRSAData } from "../../../../utility/rsa";
import Dropdown from "components/Dropdown";
import { Switch, Space } from 'antd';

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const Utilization = () => {
	// From Date To Date Start====
	const [commonUtilizationReportFromDateFormat, setcommonUtilizationReportFromDateFormat] = useState<any>();
	const [commonUtilizationReportToDateFormat, setcommonUtilizationReportToDateFormat] = useState<any>();
	const [commonUtilizationReportFromDate, setcommonUtilizationReportFromDate] = useState<any>();
	const [commonUtilizationReportToDate, setcommonUtilizationReportToDate] = useState<any>();
	const [showPickerUtilization, setShowPickerUtilization] = useState(false);
	// From Date to Date End=====
	const [selectedYearsDropDown, setSelectedYearsDropDown] = useState<any>("");
	const [selectedMonthsDropDown, setSelectedMonthsDropDown] = useState<any>("");
	const [showMyToggle, setMyToggle] = useState<any>(true);

	let dispatch = useDispatch();
	const { utilizationreporttable, loadingutilizationreporttable, alertManagementYearListDroprdown, loadingAlertManagementYearListDroprdown,
		alertManagementMonthListDroprdown, loadingAlertManagementMonthListDroprdown } = useSelector(
			(state: any) => ({
				utilizationreporttable: state.Common.utilizationreporttable,
				loadingutilizationreporttable: state.Common.loadingutilizationreporttable,

				alertManagementYearListDroprdown: state.Common.alertManagementYearListDroprdown,
				loadingAlertManagementYearListDroprdown: state.Common.loadingAlertManagementYearListDroprdown,
				alertManagementMonthListDroprdown: state.Common.alertManagementMonthListDroprdown,
				loadingAlertManagementMonthListDroprdown: state.Common.loadingAlertManagementMonthListDroprdown,
			})
		);

	useEffect(() => {
		dispatch(getAlertManagementYearDropdown(""));
		dispatch(getAlertManagementMonthDropdown(""));
	}, []);

	const showUtilizationTable = () => {
		dispatch(
			getutilizationreporttable(
				encryptRSAData(
					`fromDate=${commonUtilizationReportFromDateFormat}&toDate=${commonUtilizationReportToDateFormat}&year=null&month=null`
				)
			)
		);
	};
	const showUtilizationTableByYearsMonths = () => {
		dispatch(
			getutilizationreporttable(
				encryptRSAData(
					`fromDate=null&toDate=null&year=${selectedYearsDropDown.value}&month=${selectedMonthsDropDown.value}`
				)
			)
		);
	};

	const clearAllUtilizationFields = () => {
		setcommonUtilizationReportFromDateFormat("");
		setcommonUtilizationReportToDateFormat("");
		setcommonUtilizationReportFromDate("");
		setcommonUtilizationReportToDate("");
		setSelectedYearsDropDown("");
		setSelectedMonthsDropDown("");
	};

	// Report Date Start======================
	const ref = useRef(null);
	useOnClickOutside(ref, () => setShowPickerUtilization(false));

	const handleUtilizationReportFromDate = (date: any) => {
		setcommonUtilizationReportFromDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonUtilizationReportFromDateFormat(upatedDate);
	};
	const handleUtilizationReportToDate = (date: any) => {
		setcommonUtilizationReportToDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonUtilizationReportToDateFormat(upatedDate);
	};

	const handleClickUtilizationMyReport = () => {
		document.getElementById("handleClickUtilizationReport").click();
	};
	// Report Date End======================
	const handleYearsDropDown = (e: any) => {
		setSelectedYearsDropDown(e);
	};
	const handleMonthsDropDown = (e: any) => {
		setSelectedMonthsDropDown(e);
	};
	const getToggleStock = () => {
		setMyToggle(!showMyToggle);
	}

	return (
		<div id="utilizationreport">
			<div className="common-box-inner">
				<div className="common-box-filter">
					<div className="title"> AHC UTILIZATION REPORT</div>
				</div>

				<div className="spare-switch" style={{marginTop: "10px"}}><Switch checkedChildren="SEARCH BY YEAR & MONTH" unCheckedChildren="SEARCH BY YEAR & MONTH" onClick={() => getToggleStock()} /></div>
				
				<div className="utilization-filter">
					{showMyToggle === true ?
						<div id="LeftSetDate">
							<label>SET DATE</label>
							{/* Report Date Start component====================== */}
							<div id="ReportCalendar" ref={ref}>
								<input
									type="text"
									value={`${commonUtilizationReportFromDateFormat !== undefined
										? commonUtilizationReportFromDateFormat
										: ""
										} ${commonUtilizationReportToDateFormat !== undefined
											? commonUtilizationReportToDateFormat
											: ""
										}`}
									style={{ float: "left" }}
								/>
								<a
									className="mobile-calendar"
									onClick={() => setShowPickerUtilization(!showPickerUtilization)}
								>
									<img
										src={iconCalendar}
										title="calendar"
										style={{ float: "left" }}
									/>
								</a>
								{showPickerUtilization ? (
									<ReportCalendarPopup
										commonReportFromDateFormat={
											commonUtilizationReportFromDateFormat
										}
										commonReportToDateFormat={commonUtilizationReportToDateFormat}
										commonReportFromDate={commonUtilizationReportFromDate}
										commonReportToDate={commonUtilizationReportToDate}
										handleReportFromDate={handleUtilizationReportFromDate}
										handleReportToDate={handleUtilizationReportToDate}
									/>
								) : null}
							</div>
							{/* Report Date End component====================== */}
						</div>
						:
						<>
							{/* Report Year Month Start====================== */}
							<div id="YearMonthUtilization">
								<div style={{ width: "70%" }}>
									<label>Years</label>
									<Dropdown
										name={"Select Year"}
										handleChange={handleYearsDropDown}
										options={alertManagementYearListDroprdown}
										value={selectedYearsDropDown}
										defaultValue={""}
										loading={loadingAlertManagementYearListDroprdown}
									/>
								</div>
								<div style={{ width: "70%" }}>
									<label>Months</label>
									<Dropdown
										name={"Select Month"}
										handleChange={handleMonthsDropDown}
										options={alertManagementMonthListDroprdown}
										value={selectedMonthsDropDown}
										defaultValue={""}
										loading={loadingAlertManagementMonthListDroprdown}
									/>
								</div>
							</div></>
					}
					{/* Report Year Month End====================== */}
					<div className="report-btns">
						<button onClick={handleClickUtilizationMyReport}>
							EXPORT TO EXCEL
						</button>
						<button onClick={showMyToggle === true ? showUtilizationTable : showUtilizationTableByYearsMonths}>SUBMIT </button>
						<button onClick={clearAllUtilizationFields}>CLEAR </button>
					</div>
				</div>
				<div className="common-box-content">
					<UtilizationReportTable
						data={utilizationreporttable}
						loading={loadingutilizationreporttable}
					/>
				</div>
			</div>
		</div>
	);
};
export default Utilization;
