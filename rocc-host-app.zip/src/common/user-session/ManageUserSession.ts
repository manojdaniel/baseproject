/*
 * Created on Fri Jul 1 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore } from "@rocc/rocc-client-services"
import { useEffect, useRef } from "react"
import { useDispatch, useSelector } from "react-redux"
import { MINIMUM_EXPIRE_TIME_DIFFERENCE, TOKEN_ABOUT_TO_EXPIRE_TIME, DEFAULT_TOKEN_EXPIRY_TIME } from "../../constants/constants"
import { checkAndRefreshToken } from "../../services/authentication/AuthenticationService"

export const useManageUserSession = () => {
    const { currentUser, authUrl } = useSelector((store: IParentStore) => ({
        currentUser: store.userReducer.currentUser,
        authUrl: store.configReducer.urls.IAM_SERVICES_URL,
    }))

    const dispatch = useDispatch()

    const tokenRef = useRef(currentUser.accessToken)

    useEffect(() => {
        tokenRef.current = currentUser.accessToken
    }, [currentUser.accessToken])

    useEffect(() => {
        const {accessTokenExpiryTime, sessionId } = currentUser
        const expireTime = new Date(accessTokenExpiryTime).getTime()
        const currentTime = new Date().getTime()
        const difference = Math.abs(expireTime - currentTime) - TOKEN_ABOUT_TO_EXPIRE_TIME
        if(difference < TOKEN_ABOUT_TO_EXPIRE_TIME) {
            checkAndRefreshToken({token: tokenRef.current, sessionId, authUrl, dispatch})
        }
        const expireIn = difference > MINIMUM_EXPIRE_TIME_DIFFERENCE ? difference : DEFAULT_TOKEN_EXPIRY_TIME
        const interval = setInterval(() => {
            checkAndRefreshToken({token: tokenRef.current, sessionId, authUrl, dispatch})
        }, expireIn)

        return (() => {
            clearInterval(interval)
        })
    }, [])
}
