declare module "*.mp3"
