import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../../assets/common/CommonTables.scss";
//import moment from "moment";

interface Props {
	data: any[];
}
const MonthWiseTable = ({ data }: Props) => {
	const [monthWise, setMonthwiseList] = useState<any>();
	useEffect(() => {
		let mydata = data.map(function (item: any) {
			return {
				month: item.month + " " + item.year,
				truePositive: item.truePositive,
				falsePositive: item.falsePositive,
				precision: item.precision,
				recall: item.recall,
				unClassified: item.unClassified,

			};
		});
		setMonthwiseList(mydata);
	}, [data]);

	const columns = [
		{
			title: "MONTH",
			dataIndex: "month",
			key: "month",
			width: 100,
		},
		{
			title: "PRECISION",
			dataIndex: "precision",
			key: "precision",
			width: 100,
		},
		{
			title: "RECALL",
			dataIndex: "recall",
			key: "recall",
			width: 100,
		},
		{
			title: "TRUE POSITIVE",
			dataIndex: "truePositive",
			key: "truePositive",
			width: 100,
		},
		{
			title: "FALSE POSITIVE",
			dataIndex: "falsePositive",
			key: "falsePositive",
			width: 100,
		},
		{
			title: "UNCLASSIFIED",
			dataIndex: "unClassified",
			key: "unClassified",
			width: 100,
			render: (status: any) => (
				<span style={{ color: status === "Active" ? "red" : "inherit" }}>
					{status}
				</span>
			),
		},
	];

	return (
		<Table
			tableLayout={undefined}
			scroll={{ x: true, y: 200 }}
			columns={columns}
			dataSource={monthWise}
			pagination={false}
		/>
	);
};

export default MonthWiseTable;
