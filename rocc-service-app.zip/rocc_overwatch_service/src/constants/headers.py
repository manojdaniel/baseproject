"""
 Created on Thu Oct 15 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""


# Sheet Names
EXCEL_REFERENCE_SHEET = "Reference"
EXCEL_SITES_SHEET = "Customer Information"
EXCEL_ROOMS_SHEET = "Scanner Details"
EXCEL_EMP_SHEET = "Customer Users"
EXCEL_COMMAND_CENTERS_SHEET = "Command Center"
EXCEL_ROLE_PERMISSION_MAPPING_SHEET = "role-permission-mapping"
EXCEL_KVM_CONFIGURATION_SHEET = "Configuration"
EXCEL_MODALITY_CONNECTION_SHEET = "Modality Connection"

# SITES
EXCEL_CUSTOMER_NAME = "IDN/Customer Identifier- To be filled by Philips"
EXCEL_CUSTOMER_DISPLAY_NAME = "IDN (Multi-hospital system name)"
EXCEL_HOSPITAL_IDENTIFIER = "Hospital/DIC Identifier- To be filled by Philips"
EXCEL_HOSPITAL_DISPLAY_NAME = "Hospital or DIC"
EXCEL_STREET_ADDRESS = "Address"
EXCEL_HOSPITAL_CITY = "City"
EXCEL_HOSPITAL_PROVINCE = "State Or Province"
EXCEL_HOSPITAL_POSTAL_CODE = "Postal Code"
EXCEL_HOSPITAL_FRONTDESK_PHONE = "Frontdesk Contact Number (with country code)"
EXCEL_HOSPITAL_SCHEDULER_PHONE = "Schedular Contact Number(with country code)"

# ROOM
EXCEL_ROOM_SITE_IDENTIFIER = "Hospital/DIC Identifier- To be filled by Philips"
EXCEL_ROOM_IDENTIFIER = "Room Identifier (To be filled by Philips)"
EXCEL_ROOM_FULL_NAME = "Room or Device Name"
EXCEL_ROOM_MODALITY = "Modality (CT or MR)"
EXCEL_ROOM_PHONE_NUMBER = "Room Phone Number(with Country code)"
EXCEL_ROOM_LOCATION = "Location Name"
EXCEL_ROOM_VIEW_CONNECTION = "Transmitter view connection name- To be filled by Philips"
EXCEL_ROOM_EDIT_CONNECTION = "Transmitter edit connection name- To be filled by Philips"
EXCEL_ROOM_TRANSMITTER_IP = "Transmitter Relay IP (Static IP)"
EXCEL_ROOM_TRANSMITTER_NAME = "Transmitter Name\n(To be filled by Philips)"
EXCEL_ROOM_QUALIFY_NCC_EDIT = "Is NCC Edit supported - To be filled by Philips"

# Merge fields in order of excel template
EXCEL_ROOM_SCANNER_MANUFACTURER = "Manufacturer"
EXCEL_ROOM_SCANNER_MODEL = "Scanner Model"
EXCEL_ROOM_SCANNER_SERIAL_NUMBER = "Scanner\nSerial number"
EXCEL_ROOM_SCANNER_DICOM_AE_TITLE = "DICOM AE Title"
EXCEL_ROOM_SCANNER_SOFTWARE_VERSION = "Scanner software version"
EXCEL_ROOM_SCANNER_OS = "Scanner OS\n(Windows/Linux/etc)"
EXCEL_ROOM_SCANNER_OS_VERSION = "Scanner OS version"
EXCEL_ROOM_SCANNER_NOTES = "Additional Notes"
EXCEL_ROOM_MODALITY_CONNECTION = "Modality_Connection"

# EMP
EXCEL_USER_FIRST_NAME = "First Name"
EXCEL_USER_LAST_NAME = "Last Name"
EXCEL_USER_EMAIL_ID = "Email ID /Unique ID"
EXCEL_USER_HOSPITAL_IDENTIFIER = "Multiple Hospital/DIC Identifier Employee Belongs To( To be filled by Philips)"
EXCEL_USER_ROOM_IDENTIFIER = "Multiple Scanner/Rooms Technologist Belongs To( To be filled by Philips)"
EXCEL_USER_MODALITY = "Modality (CT or MR)"
EXCEL_USER_PHONE = "Phone Number (with Country code)"
EXCEL_USER_ROLES = "Role"
EXCEL_USER_ADDITIONAL_ROLES = "Additional functionality for Expert user"

# RECR
EXCEL_CC_IP = "Receiver IP (To be filled by Philips)"
EXCEL_CC_SEAT_NAME = "Command Center Name\n(To be filled by Philips)"
EXCEL_CC_SEAT_INFO = "Additonal information\n(To be filled by Philips)"
EXCEL_RECEIVER_SEAT_NAME = "Receiver Name (To be filled by Philips)"
EXCEL_MONITOR_IDENTIFICATION_LABEL = "Monitor identification label (To be filled by Philips)"

# KVM_CONFIGURATION
EXCEL_KVM_BOXILLA_IP = "KVM Boxilla IP- To be filled by Philips"
EXCEL_KVM_BOXILLA_USER_NAME = "KVM Boxilla User Name - To be filled by Philips"
EXCEL_KVM_BOXILLA_REST_USER_NAME = "KVM Boxilla Rest User Name - To be filled by Philips"

# MODALITY_CONNECTION
EXCEL_MOD_CONN_IP = "Connection IP- To be filled by Philips"
EXCEL_MOD_CONN_PRIORITY = "Priority- To be filled by Philips"
EXCEL_MOD_CONN_CONNECTION_MODE = "Connection Mode- To be filled by Philips"
EXCEL_MOD_CONN_ROOM_IDENTIFIER = "Room Identifier (To be filled by Philips)"
EXCEL_MOD_CONN_USERNAME = "Connection Username"

# ROLE_MAP
EXCEL_ROLE_MAP_SNNO = "SN No"
EXCEL_ROLE_MAP_ROLE = "Role"
EXCEL_ROLE_MAP_RESOURCE = "Resource"
EXCEL_ROLE_MAP_ACTIONS = "Actions"

# Security questions
SECURITY_QUES_FILE_PATH = "resources/security_questions/security_questions.json"

# R-BAC
RBAC_MAPPINGS_FILE_PATH = "resources/rbac_resources/rbac_mappings.json"
RBAC_PERMISSIONS_FILE_PATH = "resources/rbac_resources/rbac_permissions.json"
RBAC_ROLES_FILE_PATH = "resources/rbac_resources/rbac_roles.json"
FSE_RBAC_ROLES_FILE_PATH = "resources/rbac_resources/fse_rbac_role_mapping.json"
FSE_USER_DETAILS_FILE_PATH = "resources/fse_user_details/fse_user_details.json"

# Email templates
EMAILTEMPLATE_DOCUMENTS_PATH = "resources/email_templates"
# Invite
EMAILTEMPLATE_INVITE_TEMPLATE = "rocc_invite_template"
# Password recovery
EMAILTEMPLATE_FORGOT_PWD_TEMPLATE = "rocc_forgot_password_template"
# Password expiry - Coming soon, not operational yet
EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE = "rocc_password_expiry_template"
# Locales
LOCALES_DIRECTORY_PATH = "resources/locales"
# Region config
REGION_CONFIG_FILE_PATH = "resources/platform/communication_region_config.json"


# TERMS_OF_SERVICE
TOS_DOCUMENT_PATH = "resources/terms_of_service"
