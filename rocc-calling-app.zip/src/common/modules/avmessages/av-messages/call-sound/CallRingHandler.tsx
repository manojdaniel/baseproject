/*
 * Created on Thu Dec 10 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { errorLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import ringTone from "../../../../../assets/sound/phone-calling.mp3"
import { DEFAULT } from "../../../../../constants/constants"
import { IStore } from "../../../../../redux/interfaces/types"

const CallRing = () => {
    const {
        audioOutputSource, callRingStatus
    } = useSelector((state: IStore) => ({
        audioOutputSource: state.callReducer.audioOutput,
        callRingStatus: state.callReducer.callRingStatus,
    }))

    const [audio, setAudio] = useState<any>()

    const initiateAudio = async () => {
        try {
            const localAudio: any = new Audio(ringTone)
            localAudio.loop = true
            if (audioOutputSource) {
                await localAudio.setSinkId(audioOutputSource)
            } else {
                await localAudio.setSinkId(DEFAULT)
            }
            setAudio(localAudio)
        } catch (error) {
            errorLogger(`Failed to set sinkId for Audio device: ${error}`)
        }
    }

    useEffect(() => {
        initiateAudio()
        return (() => {
            try {
                if (audio) {
                    audio.pause()
                }
            } catch (error) {
                errorLogger(`Failed to update audio during component unmount: ${error}`)
            }
            setAudio(undefined)
        })
    }, [])

    useEffect(() => {
        try {
            if (audio) {
                audio.setSinkId(audioOutputSource)
            }
        } catch (error) {
            errorLogger(`Failed to update sinkId for Audio device: ${error}`)
        }

    }, [audioOutputSource])

    useEffect(() => {
        try {
            if (audio) {
                (callRingStatus) ? audio.play() : audio.pause()
            }
        } catch (error) {
            errorLogger(`Failed to Play or Pause Audio: ${error}`)
        }
    }, [callRingStatus])

    return <></>
}

export default CallRing
