/*
 * Created on Thu Aug 05 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export const PHILIPS_API_URI = "/philips/rocc"
export const COMMUNICATION_TOKEN_EP = `/Token`
export const AV_CALL_EP = `/Call/`
export const MISSED_CALL_EP = "/user/MissedCall/"
export const UI_SERVICE_API_URI = `/ui/service`
export const VENDOR_SERVICE_API_URI = `${AV_CALL_EP}CommunicationVendorName`
