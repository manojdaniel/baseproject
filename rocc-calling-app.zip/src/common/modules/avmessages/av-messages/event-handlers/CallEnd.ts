/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Dispatch } from "redux"
import { CALL_REJECT, CALL_END, CALL_MISSED, HTTP_STATUS, TIMEOUT_3000 } from "../../../../../constants/constants"
import { setCallRingStatus, setVideoCallStatus } from "../../../../../redux/actions/callActions"
import { ECallStatus } from "@rocc/rocc-client-services"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"
import store from "../../../../../redux/store/store"
import { getContextDetails } from "../../messageService"
import { ICallDetails } from "../types"
import { updateCallDetails } from "../../../av/AudioVideoHelper"

const { DISCONNECTED } = ECallStatus

interface ICallEnd {
    contextId: string
    dispatch: Dispatch<any>
}

export const callEnd = (props: ICallEnd) => {
    const { contextId, dispatch } = props
    const { currentUser, urls, videoCallStatus, connectedCallDetails, onHoldCallDetails } = initialiseReduxValues()
    dispatch(setCallRingStatus(false))
    const activeCall = [connectedCallDetails, ...onHoldCallDetails].find(callDetails => callDetails.contextId === contextId)
    if (activeCall) {
        setTimeout(async () => {
            const contextDetails = await getContextDetails(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL)
            if (contextDetails.status === HTTP_STATUS.OK) {
                const data: ICallDetails = contextDetails.data
                activeCall.participants = activeCall.participants.filter(
                    (participant) => data.participants.findIndex((apiParticipant) => apiParticipant.primaryUuid === participant.uuid &&
                        ![undefined, CALL_REJECT, CALL_END, CALL_MISSED].includes(apiParticipant.callStatus)) > -1)
                updateCallDetails(activeCall, dispatch, true)
            }
        }, TIMEOUT_3000)
    } else {
        const endCallStatusIndex = videoCallStatus.findIndex((callStatus) => callStatus.contextId === contextId && callStatus.callStatus !== DISCONNECTED)
        if (endCallStatusIndex > -1) {
            videoCallStatus.splice(endCallStatusIndex, 1)
            setVideoCallStatus([...videoCallStatus])
        }

    }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const urls = fetchGlobalURLs()
    const { currentUser } = state.externalReducer
    const { videoCallStatus } = state.callReducer
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    return { currentUser, urls, videoCallStatus, connectedCallDetails, onHoldCallDetails }
}
