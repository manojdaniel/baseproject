/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ECameraStreamAvailable, EConnectionMode, EConnectionState, EConnectionType, ERoccWorkflow, ERoomType, IAVCallDetails, IConsoleSession, IMediaRoomDetails } from "@rocc/rocc-client-services"
import { ECommandCenterAccessMode, IConfirmModal, ILeaveProtocolTransferConfirmProps, IReceiverSelectionModal, IRoomInfo } from "../../redux/interfaces/types"

/** Global constants */
export const APP_NAME = "CC_CONSOLE"
export const STORAGE_KEY = "REDUX_STATE"
export const PARENT_STORE = "CC_HOST"
export const CALLING_APP = "CC_CALLING"

export const CALL_REDUCER = "callReducer"

/* API Constants */
export const ACCEPT = "Accept"
export const POST = "POST"
export const GET = "GET"
export const PUT = "PUT"
export const CONTENT_TYPE = "Content-Type"
export const APPLICATION_JSON = "application/json"
export const AUTHORIZATION = "Authorization"
export const API_VERSION = "api-version"
export const ORG_CONTEXT_HEADER = "org_ctxt_header"
export const ORG_ID = "Org-Id"
export const DEFAULT_API_VERSION = "1.0.0"
export const API_VERSION_101 = "1.0.1"

export enum HTTP_STATUS {
    OK = 200,
    CREATED = 201,
    NO_CONTENT = 204,
    PARTIAL_CONTENT = 206,
    ALREADY_REPORTED = 208,
    BAD_REQUEST = 400,
    UNAUTHORIZED = 401,
    FORBIDDEN = 403,
    LOCKED = 423,
    INTERNAL_SERVER_ERROR = 500,
}

export enum EEventType {
    SELECT = "Receiver Selected",
    UNSELECT = "UnSelecting Receiver",
    SWITCH = "Switch Receiver",
    CANCEL = "Console operation cancelled",
    INITIATE_CONSOLE_SESSION = "Initiate console session",
}

/** Logger */
/* Log constants */
export const ERROR = "ERROR"
export const WARNING = "WARNING"
export const INFO = "INFO"
export const DEBUG = "DEBUG"

/** Conversation Constants */
export const CHAT = "CHAT"

/** Reducer Names */
export const USER_REDUCER = "userReducer"

export const INIT_MEDIA_ROOM_DETAILS: IMediaRoomDetails = { mediaRoomId: "", mediaRoomToken: "", cameraStreamAvailable: ECameraStreamAvailable.NOT_AVAILABLE }

export const COMMAND_CENTER_LOCATION = "COMMAND CENTER"
export const NO_COMMAND_CENTER_LOCATION = "NON COMMAND CENTER"

export const MANAGE_GRAPHQL_MUTATION_EP = "/data/Graphql"
export const MANAGE_GRAPHQL_BUNDLE_INFOS_EP = `${MANAGE_GRAPHQL_MUTATION_EP}/UserBundleInfos/`
export const MANAGE_GRAPHQL_IN_APP_MUTATIONS_EP = `${MANAGE_GRAPHQL_MUTATION_EP}/inAppMutations`
export const SESSION_MANAGEMENT_EP = "/sessionmgmt/Session/"

export const CONSOLE_ACCESS_MODE = "consoleAccessMode"
export const LOCATION_NAME = "locationName"
export const COMMAND_CENTER_LOCATION_NAME = "commmandCenterLocationName"
export const SEP = "%;;;%"
export const ACCESS_MODE_SET = "ACCESS_MODE_SET"

export const CONSOLE_REQUESTER_UUID = "?requester="
export const EMERALD_APP_NAME = "EmeraldRA"
export const ROCC_ANY_WHERE_APP = "ROCCAnywhereApp"
export const EMERALD_APP_URI_START = "start"
export const EMERALD_APP_URI_STOP_ALL = "stopAll"
export const EMERALD_APP_URI_STOP = "stop"
export const EMERALD_APP_URI_RESTART = "restart"
export const PID = "PID"
export const KVM_ADMIN_USERNAME = "admin"
export const ACCESS_TOKEN_STRING = "accessToken"
export const ORG_ID_STRING = "orgId"
export const CONTEXT_ID = "contextId"
export const WEB_SOCKET_URL = "webSocketUrl"
export const IAM_SERVICE_ENDPOINT = "iamServiceEndpoint"
export const ADMIN_SERVICE_ENDPOINT = "adminServiceEndpoint"
export const PID_UPDATE_ENDPOINT = "pidUpdateConsoleEndpoint"
export const TARGET_APP_ENDPOINT = "targetAppEndpoint"
export const TARGET_APP_NAME = "targetAppName"
export const TARGET_APP_ARGS = "targetAppArgs"
export const VERSION_STRING = "version"
export const URL = "url"
export const API_METHOD = "method"
export const API_ENDPOINT = "apiEndpoint"
export const API_METHOD_STRING = "apiMethod"
export const API_VERSION_STRING = "apiVersion"
export const BUNDLE_NAME = "bundleName"
export const BUNDLE_VERSION = "bundleVersion"
export const DOWNLOAD_URL = "downloadUrl"
export const NFCC_BUNDLE_VERSION = "NFCC_BUNDLE_VERSION"

export const GLOBAL_UPDATE_NOTIFICATION_MODAL = "GLOBAL_UPDATE_NOTIFICATION_MODAL"
export const GLOBAL_UPDATE_ROOMS = "GLOBAL_UPDATE_ROOMS"

export const initLeaveProtocolTransferDlgModel: ILeaveProtocolTransferConfirmProps = { show: false, postConfirmCallback: () => { "" }, onDialogClosed: () => { "" } }
export const initConfirmModal: IConfirmModal = { onConfirm: () => { "" }, onCancel: () => { "" }, show: false }

export const COMMUNICATION_SERVICE_MEDIA_ROOM_URI = "/MediaRoom"

export const CONSOLE_DATA = "consoleData"
export const CONSOLE_STATUS = "consoleStatus"
export const MESSAGE_TYPE = "MessageType"
export const MEDIA_ROOM_ID = "MediaRoomId"
export const MEDIA_ROOM = "MEDIA_ROOM"
export const MEDIA_TOKEN = "MediaToken"
export const CALL_ACCEPT = "CALL_ACCEPT"
export const initReceiverSelectionModal: IReceiverSelectionModal = { showReceiverModal: false, connectionType: "" }
export const MULTI_CAMERA_SETTINGS_SIDEBAR = "MultiCameraSettingsSidebar"

// TODO: Move this to vault and read from global redux
export const API_TIMEOUT = 3 * 60 * 1000

export const INIT_ROOM_INFO: IRoomInfo = {
    roomUuid: "",
    roomName: "",
    address: "",
    locationId: -1,
    phoneNumber: "",
    loggedInTech: { techUuid: "", techName: "" }
}
export const INIT_NOTIFICATION_MODAL = {
    showModal: false,
    showCloseIcon: false,
    header: "",
    modalContent: "",
}

export const DEFAULT_SUBSCRIPTION_BITRATE = 240000
export const DEFAULT_VIDEO_BITRATE = 1500000

export const BANDWIDTH_PROFILE_MODE = {
    COLLABORATION: "collaboration",
    GRID: "grid",
}

export const TWILIO_ERROR_CODES = {
    ACCESS_TOKEN_EXPIRE: 20104,
    DUPLICATE_IDENTITY: 53205,
    PARTICIPANT_SESSION_LENGTH_EXCEEDED: 53216
}

export const DEFAULT_ONGOING_CALL_DETAILS: IAVCallDetails = {
    contextId: "", roomName: "", roomType: ERoomType.GROUP, twilioToken: "", userDetails: "", participants: [],
    isFirstParticipant: false, callAcceptedTime: "", isMuted: false, isDeafened: false, callStatus: ECallStatus.IDLE, numOfParticipants: -1,
}

export const consoleDummyObject = {
    contextId: "1",
    requester: "",
    roomUuid: "123",
    connectionType: EConnectionType.INCOGNITO_VIEW,
    connectionMode: EConnectionMode.CC,
    connectionStatus: EConnectionState.CONNECTED,
    receiverName: "",
    displayCameraToggle: false,
    mediaRoomDetails: {
        cameraStreamAvailable: ECameraStreamAvailable.IDLE,
        mediaRoomId: "id",
        mediaRoomToken: "token",
    },
    multiCameraList: [],
    consoleStartTime: "",
}

export const MAX_SUPPORTED_MULTICAMERA_STREAMS = 2
export const ADDITIONAL_ATTRIBUTES = "additional_attributes"
export const IS_NCC_WARNING_DISPLAYED = "is_ncc_warning_displayed"
export const EditConsoleEventName = "Edit Console"
export const CONTROL_CONSOLE = "Control Console"
export const MEDIA_ROOM_FAILED = "MEDIA_ROOM_FAILED"
export const RESUME = "RESUME"

export const externalReducerObj = {
    rooms: [{
        roomUuid: "id",
        additionalAttributes: {
            ncc_edit: true
        }
    }],
    featureFlags: {
        "rocc-multi-console": true,
        "rocc-room-monitoring": true,
    },
    permissions: { CONSOLE_EDIT_WITHOUT_AUTHORIZATION: true, CONSOLE_VIEW_INCOGNITO: true }
}

export const commandCenterDetailsObj = {
    initialised: ECommandCenterAccessMode.WITHOUT_HARDWARE,
    commandCenterSeat: {
        organizationId: 1,
        seatName: "seat1",
        receivers: [{
            id: 1,
            receiverName: "name",
            monitorName: "monitor",
            isSelected: false
        }]
    },
}
export const VIEW_CONSOLE = "View Console"
export const GLOBAL_FORCE_CLEAN_UP = "GLOBAL_FORCE_CLEAN_UP"

export const EN_LOCALE = "en"
export const EN_LANGUAGE = "en-US"

/** Emerald CLI */
export const EMERALD_FETCH_CLI_ARGS = "/console/fetchCliArgs"
export const EMERALD_KVM_MAPPING_CLI_ARGS = "/console/KvmRemoteAppCliArgs"
export const EMERALD_CLI_OPERATION_TYPE_LAUNCH = "/launch"
export const EMERALD_CLI_OPERATION_TYPE_TERMINATE = "/terminate"
export const EMERALD_APP_URI_PID = "emerald-remote-app://"
export const EMERALD_APP_URI = "nativeapp-launcher://"
export const MANAGEMENT_SERVICE_URL = "MANAGEMENT_SERVICE_URL"
export const UPDATER_NAME = "Updater"

export const CONFIRM = "CONFIRM"
export const TIMEOUT = "TIMEOUT"
export const CANCEL = "CANCEL"
export const SESSION_PARKING = "SESSION_PARKING"
export const INITIATING_EDIT_CONSOLE_SESSION = "INITIATING_EDIT_CONSOLE_SESSION"
export const RESUMING_EDIT_CONSOLE_SESSION = "RESUMING_EDIT_CONSOLE_SESSION"
export const REVERT_CONSOLE_SESSION = "REVERT_CONSOLE_SESSION"
export const PARK_SESSION_SUCCESS = "PARK_SESSION_SUCCESS"
export const PARK_SESSION_FAILED = "PARK_SESSION_FAILED"
export const REVERT_SESSION_SUCCESS = "REVERT_SESSION_SUCCESS"
export const REVERT_SESSION_FAILED = "REVERT_SESSION_FAILED"
export const INITIATE_EDIT_CONSOLE_SESSION = "INITIATE_EDIT_CONSOLE_SESSION"
export const INITIATE_EDIT_SESSION_SUCCESS = "INITIATE_EDIT_SESSION_SUCCESS"
export const INITIATE_EDIT_SESSION_FAILED = "INITIATE_EDIT_SESSION_FAILED"
export const RESUME_EDIT_SESSION_SUCCESS = "RESUME_EDIT_SESSION_SUCCESS"
export const RESUME_EDIT_SESSION_FAILED = "RESUME_EDIT_SESSION_FAILED"
export const CONSOLE_DISCONNECT_SUCCESS = "CONSOLE_DISCONNECT_SUCCESS"
export const CONSOLE_DISCONNECT_FAILED = "CONSOLE_DISCONNECT_FAILED"
export const MFE_LOGOUT_ELECT = "MFE_LOGOUT_ELECT"
export const MFE_LOGGED_OUT = "MFE_LOGGED_OUT"
export const MFE_LOGOUT_FAILED = "MFE_LOGOUT_FAILED"

export const TRACKED_CONSOLE_WORKFLOWS = [
    ERoccWorkflow.MULTI_EDIT_INITIATE_CALL,
    ERoccWorkflow.MULTI_EDIT_START_EDITING,
    ERoccWorkflow.PARK_AND_INITIATE_CALL,
    ERoccWorkflow.PARK_AND_START_EDITING,
    ERoccWorkflow.PARK_AND_RESUME,
    ERoccWorkflow.DISCONNECT_CALL,
    ERoccWorkflow.DISCONNECT_CONSOLE_SESSION,
]
export const TRACKED_WORKFLOWS = [
    ...TRACKED_CONSOLE_WORKFLOWS,
    ERoccWorkflow.LOGOUT,
]

export const INIT_CONSOLE_SESSION_DETAILS: IConsoleSession = {
    contextId: "",
    connectionType: EConnectionType.DEFAULT,
    connectionMode: EConnectionMode.CC,
    requester: "",
    roomUuid: "",
    connectionStatus: EConnectionState.DEFAULT,
    receiverName: "",
    displayCameraToggle: false,
    mediaRoomDetails: INIT_MEDIA_ROOM_DETAILS,
    multiCameraList: [],
    consoleStartTime: new Date().toString(),
}

export const CONSOLE_SESSIONS = "CONSOLE_SESSIONS"
export const VIEW_STATUS = "viewStatus"
export const EDIT_STATUS = "editStatus"
export const ACCESS_TOKEN = "ACCESS_TOKEN"
export const CCTV_WINDOW = "CCTV_WINDOW"
export const ROOMS = "ROOMS"
export const CONSOLE_MEDIA_ROOM_UPDATE = "CONSOLE_MEDIA_ROOM_UPDATE"
export const UPDATE_ROOM_CAMERA_AVAILABILITY = "UPDATE_ROOM_CAMERA_AVAILABILITY"
export const UPDATE_DISPLAY_CAMERA_TOGGLE = "UPDATE_DISPLAY_CAMERA_TOGGLE"

export const NO_VIDEO_PROP = { fullScreen: false }

export const ROOM_MONITORING_TRACKING = "Room Monitoring:"
export const EXPANDED = "expanded"
export const COLLAPSED = "collapsed"
export const ON = "on"
export const OFF = "off"
export const SINGLE_RECIEVER = "single reciver"
export const MULTI_RECIEVER = "multi reciver"
export const TIME = "Time"

export const commandCenter = "command center"
export const nonFixedCommandCenter = "non-fixed command center"
export const CONSOLE = "CONSOLE"
export const TRACKER_ROLE_NAME = "ROCC UI Application"
export const TRACKER_ROLE_INSTANCE = "ROCC UI Application instance"
