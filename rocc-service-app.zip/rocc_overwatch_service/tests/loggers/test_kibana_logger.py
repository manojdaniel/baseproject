import os
import unittest
from math import comb

from src.constants.config_keys import VAULT_LOG_PRODUCT_KEY
from src.loggers.kibana_logger import prepare_log_object


class KibanaLoggerTestCase(unittest.TestCase):

    def test_prepare_log_object(self):
        os.environ[VAULT_LOG_PRODUCT_KEY] = "logProductKey"
        self.assertIsNotNone(prepare_log_object(message="testMessage", severity="INFO", component="cpp"))  # add assertion here


if __name__ == '__main__':
    unittest.main()
