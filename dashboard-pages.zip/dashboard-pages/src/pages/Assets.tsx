import React, { useRef, useEffect, useState } from "react";
import "./Assets.scss";
// import BreadCrumb from "../components/BreadCrumb/BreadCrumb";
// import AlertList from "./AssetsPage/AlertList/AlertList";
// import AssetModel from "./AssetsPage/AssetModel/AssetModel";
// import AssetTimeLine from "./AssetsPage/AssetTimeLine/AssetTimeLine";
// import SpareParts from "./AssetsPage/SpareParts/SpareParts";
// import LiveTracking from "./AssetsPage/LiveTracking/LiveTracking";
// import ReferenceTable from "./AssetsPage/ReferenceTable/ReferenceTable";
// import Plot from "./AssetsPage/Plot/Plot";
import { useNavigate } from "react-router-dom";
import { Outlet } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const Assets = () => {
	let navigate = useNavigate();
	const location = useLocation();

	const [assetType, setassetType] = useState("");
	const [predictionData, setPredictionData] = useState<any[]>([]);

	const { globalSelecetedAsset } = useSelector((state: any) => ({
		globalSelecetedAsset: state.Common.globalSelecetedAsset,
	}));

	// const DATA = [
	//     { id: "AssetModel", value: "ASSET MODEL" },
	//     { id: "LiveTracking", value: "LIVE TRACKING" },
	//     { id: "AssetTimeLine", value: "ASSET TIMELINE" },
	//     { id: "AlertList", value: "ALERT LIST" },
	//     { id: "Plots", value: "PLOTS" },
	//     { id: "ReferenceTable", value: "REFERENCE TABLE" },
	//     { id: "SpareParts", value: "SPARE PARTS" },
	//     { id: "PredictionCase", value: "PREDICTION CASE"},

	// ];

	// prediction/ detection selection
	useEffect(() => {
		if (globalSelecetedAsset.value.includes("_Static")) {
			let data = [
				{ id: "AssetModel", value: "ASSET MODEL" },
				{ id: "LiveTracking", value: "LIVE TRACKING" },
				{ id: "AssetTimeLine", value: "ASSET TIMELINE" },
				{ id: "AlertList", value: "ALERT LIST" },
				{ id: "Plots", value: "PLOTS" },
				{ id: "ReferenceTable", value: "REFERENCE TABLE" },
				{ id: "SpareParts", value: "SPARE PARTS" },
				{ id: "PredictionCase", value: "PREDICTION CASE" },
			];

			setPredictionData(data);
		} else {
			let data = [
				{ id: "AssetModel", value: "ASSET MODEL" },
				{ id: "LiveTracking", value: "LIVE TRACKING" },
				{ id: "AssetTimeLine", value: "ASSET TIMELINE" },
				{ id: "AlertList", value: "ALERT LIST" },
				{ id: "Plots", value: "PLOTS" },
				{ id: "ReferenceTable", value: "REFERENCE TABLE" },
				{ id: "SpareParts", value: "SPARE PARTS" },
			];
			setPredictionData(data);
		}
	}, [assetType, globalSelecetedAsset]);

	const [elements, setElements] = useState(predictionData);
	const [selectedID, setSelectedID] = useState("AssetModel"); // you could set a default id as well
	useEffect(() => {
		if (predictionData !== null) {
			setElements(predictionData);
		}
	}, [predictionData]);

	const handleClick = (id: any) => {
		setSelectedID(id);
		switch (id) {
			case "AssetModel":
				navigate("/assets/assetModel");
				break;
			case "AlertList":
				navigate("/assets/alertList");
				break;
			case "Plots":
				navigate("/assets/plots");
				break;
			case "LiveTracking":
				navigate("/assets/liveTracking");
				break;
			case "AssetTimeLine":
				navigate("/assets/assetTimeLine");
				break;
			case "SpareParts":
				navigate('/assets/spareParts');
				break;
			case "ReferenceTable":
				navigate("/assets/referenceTable");
				break;
			case "PredictionCase":
				navigate("/assets/predictioncase");
				break;
			default:
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	useEffect(() => {
		if (location.pathname.split("/")[2] === undefined) {
			if (location.pathname.split("/")[1] === "assets") {
				navigate("/assets/assetModel");
			}
		}
	}, [location.pathname]);

	let currentPathname =
		location.pathname.split("/")[2] !== undefined
			? location.pathname.split("/")[2]
			: location.pathname.split("/")[1];
	let updatedCurrentPath =
		currentPathname.charAt(0).toUpperCase() + currentPathname.slice(1);
	// const getSelectedclassName = (id: any) => selectedID === id ? "active" : "notselected";

	const TopContainer = () => {
		return (
			<div id="asset-menu">
				{elements.map((el) => (
					<a
						key={el.id}
						id={el.id}
						// className={`top-container-conten ${getSelectedclassName(el.id)}`}
						className={updatedCurrentPath === el.id ? "active" : ""}
						onClick={() => handleClick(el.id)}
					>
						{el.value}
					</a>
				))}
			</div>
		);
	};

	const renderStep = () => {
		switch (selectedID) {
			case "AssetModel":
				navigate("/assets/assetModel");
				break;
			case "AlertList":
				navigate("/assets/alertList");
				break;
			case "Plot":
				navigate("/assets/plots");
				break;
			case "LiveTracking":
				navigate("/assets/liveTracking");
				break;
			case "AssetTimeLine":
				navigate("/assets/assetTimeLine");
				break;
			case "SpareParts":
				navigate("/assets/spareParts");
				break;
			case "ReferenceTable":
				navigate("/assets/referenceTable");
				break;
			case "ReferenceTable":
				navigate("/assets/predictioncase");
				break;
			case "ReferenceTable":
				navigate("/assets/predictioncase");
				break;
			default:
				return <div>{"INFO_NO_STEP_AVAILABLE"}</div>;
		}
	};

	return (
		<div id="content-affiliates" style={{ top: "0px" }}>
			<TopContainer />
			{/* {renderStep()} */}
			<Outlet />
		</div>
	);
};

export default Assets;
