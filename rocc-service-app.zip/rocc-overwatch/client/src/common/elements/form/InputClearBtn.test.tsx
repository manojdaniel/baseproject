/*
 * Created on Fri Feb 12 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import InputClearBtn from "./InputClearBtn"

describe("Input Clear Btn component", () => {
    let wrapper: any
    let IconClass: any
    beforeEach(() => {
        wrapper = shallow(<InputClearBtn handleClear={() => void (0)} />)
        IconClass = wrapper.find(".CrossCircle")
    })
    it("should render with the correct Classname", () => {
        expect(IconClass).toHaveLength(1)
    })
})
