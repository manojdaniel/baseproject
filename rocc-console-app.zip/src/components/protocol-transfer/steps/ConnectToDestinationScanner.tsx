/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ProtocolTransferWizardContent from "../ProtocolTransferWizardContent"
import en from "../../../resources/translations/en-US"
import { sourceContent, destinationContent } from "./StepUtility"
import { getIntlProvider } from "@rocc/rocc-global-components"

const ConnectToDestinationScanner = () => {
    const { intl } = getIntlProvider()
    const stepMessageContent = intl.formatMessage({ id: "content.protocolTransfer.transferProtocolMessage", defaultMessage: en["content.protocolTransfer.transferProtocolMessage"] })

    return <ProtocolTransferWizardContent sourceScannerContent={sourceContent(false)}
        destinationScannerContent={destinationContent(true)}
        stepMessageContent={stepMessageContent} />
}

export default ConnectToDestinationScanner
