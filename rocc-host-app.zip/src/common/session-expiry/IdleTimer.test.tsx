/*
 * Created on Fri Dec 17 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { withHooks } from "jest-react-hooks-shallow"
import useIdletimer from "./IdleTimer"
import React from "react"
import { shallow } from "enzyme"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: { status: "IN_CALL" },
    }),
    useDispatch: () => void (0),
}))

describe("idle timer", () => {
    it("test idle timer", () => {
        withHooks(() => {
            const onWarn = jest.fn()
            const onTimeOut = jest.fn()
            const DummyComponent = () => {
                useIdletimer({
                    timeout: 3,
                    warningTimeout: 3,
                    onWarn: onWarn,
                    onTimeOut: onTimeOut
                })
                return <div></div>
            }
            const wrapper = shallow(<DummyComponent />)
            expect(wrapper).toBeDefined()
        })
    })
})
