/*
 * Created on Mon Oct 04 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import PhoneCallTrigger from "./PhoneCallTrigger"
import { shallow } from "enzyme"

jest.mock("../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useDispatch: () => void (0),
    useSelector: jest.fn().mockReturnValue({
        videoCallStatus: [{ callStatus: "idle", contextId: "" }],
        phoneCallStatus: "idle",
    })
}))

jest.mock("../../services/callServices", () => ({
    enableBrowserToPhoneCall: jest.fn(),
}))

describe("PhoneCallTrigger component", () => {
    let wrapper: any
    const props = {
        contactUuid: "1",
        phoneNumbers: ["1234567890"],
        showTitle: true,
        isDisabled: false,
        dimOnHover: false
    }
    beforeEach(() => {
        wrapper = shallow(<PhoneCallTrigger {...props} />)
    })
    it("should render PhoneCall component", () => {
        expect(wrapper.find("PhoneCall")).toHaveLength(1)
    })
})
