import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import StackedBarDepartmentAsset from "./index";

//Mock data for the chart component
const data = [
	{
		count: 62,
		state: "Closed",
		department: "Digitalization Champion",
	},
	{
		count: 70,
		state: "Overdue",
		department: "Digitalization Champion",
	},
];

//Test Case to check chart exist in the component.
describe("StackedBarAsset Departments", () => {
	it("renders the chart with sdata", () => {
		const { container } = render(<StackedBarDepartmentAsset data={data} />);
		expect(container.querySelector("#chartdiv2")).toBeInTheDocument();
	});
});
