import unittest
from src.modules.job_management.cf_customer_setup_job import CFCustomerSetupJob
class CFCustomerSetupJobTest(unittest.TestCase):
    def test_start_job(self):
        set_up_job=CFCustomerSetupJob()
        set_up_job.initalize_job()
        self.assertIsNotNone(set_up_job)
    def test_load_infra_configs(self):
        set_up_job=CFCustomerSetupJob()
        with self.assertRaises(Exception):
            set_up_job.load_infra_configs("123")
    def test_fetch_all_tasks(self):
        set_up_job=CFCustomerSetupJob()
        with self.assertRaises(Exception):
            set_up_job.fetch_all_tasks()
    def test_execute_task(self):
        set_up_job=CFCustomerSetupJob()
        set_up_job.execute_tasks()
