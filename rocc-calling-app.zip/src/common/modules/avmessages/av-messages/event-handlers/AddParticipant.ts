/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Dispatch } from "redux"
import { incomingCall } from "./IncomingCall"
import { TRACKING_VALUES } from "../types"
import { ALREADY_ON_CALL } from "../../../../../constants/constants"
import { ECallStatus } from "@rocc/rocc-client-services"
import store from "../../../../../redux/store/store"
import { errorLogger, errorParser, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { createUrlCall } from "../../messageService"
import { AV_CALL_EP } from "../../../../../constants/endpoints"
import { filterCallStatusByContextIdAndStatus } from "../../../../helpers/callUtility"
import { putService } from "../../../../helpers/apiUtility"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"

const { RINGING, CONNECTING, CONNECTED } = ECallStatus

interface IAddParticipant {
    contextId: string
    participant: string
    dispatch: Dispatch<any>
}

export const addParticipant = async (props: IAddParticipant) => {
    const { contextId, dispatch, participant } = props
    const { currentUser, urls, videoCallStatus } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES

    const acceptedCallStatuses = [RINGING, CONNECTING, CONNECTED]
    if (filterCallStatusByContextIdAndStatus(videoCallStatus, contextId, acceptedCallStatuses, true).length) {
        const { accessToken, sessionId } = currentUser
        sendLogsToAzure({ contextData: { component, event: `${event} Add Participant`, message: `User ${currentUser.uuid} is already on different call with contextId ${contextId}` } })
        const params: any = createUrlCall({
            accessToken,
            sessionId,
            userUuid: participant,
            communicationServiceUrl: `${urls.COMMUNICATION_SERVICES_URL}${AV_CALL_EP}`,
            contextId, callStatus: ALREADY_ON_CALL,
            state: false,
        })
        try {
            await putService(params)
        } catch (error) {
            errorLogger(`Exception occurred while updating the call status as ALREADY_ON_CALL : ${errorParser(error)}`)
        }
        infoLogger(`The user is already on a different call with contextId ${contextId}`)
    } else {
        sendLogsToAzure({ contextData: { component, event: `${event} Add Participant`, Call_To: currentUser.uuid, Call_From: participant, contextId } })
        incomingCall({ contextId, dispatch })
    }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const urls = fetchGlobalURLs()
    const { currentUser } = state.externalReducer
    const { videoCallStatus } = state.callReducer
    return { currentUser, urls, videoCallStatus }
}
