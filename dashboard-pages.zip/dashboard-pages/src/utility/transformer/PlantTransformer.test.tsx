import { plantDetailTransformer } from './PlantTransformer';
import "@testing-library/jest-dom/extend-expect";

describe('plantDetailTransformer', () => {
  it('transforms healthIndex and pmCompliance correctly', () => {
    const data = [      {        name: 'Plant A',        healthIndex: '70 %',        pmCompliance: '85 %',      },      {        name: 'Plant B',        healthIndex: '80 %',        pmCompliance: '90 %',      },    ];

    const expected = [      {        name: 'Plant A',        healthIndex: '70',        pmCompliance: '85',      },      {        name: 'Plant B',        healthIndex: '80',        pmCompliance: '90',      },    ];

    const result = plantDetailTransformer(data);

    expect(result).toEqual(expected);
  });

  it('handles undefined values', () => {
    const data = [      {        name: 'Plant A',        healthIndex: undefined,        pmCompliance: undefined,      },      {        name: 'Plant B',        healthIndex: '80 %',        pmCompliance: '90 %',      },    ];

    const expected = [      {        name: 'Plant A',        healthIndex: undefined,        pmCompliance: undefined,      },      {        name: 'Plant B',        healthIndex: '80',        pmCompliance: '90',      },    ];

    const result = plantDetailTransformer(data);

    expect(result).toEqual(expected);
  });

  it('handles empty array', () => {
    const data = [];

    const expected = [];

    const result = plantDetailTransformer(data);

    expect(result).toEqual(expected);
  });
});
