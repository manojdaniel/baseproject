"""
 Created on Thu Nov 24 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import unittest
from unittest.mock import patch
from src.services.raw_data_insertion_service.file_upload_service import FileUploadService
from src.constants.config_keys import VAULT_PARENT_ORG_ID, VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY


class TestFileUploadService(unittest.TestCase):
    @patch("src.services.raw_data_insertion_service.file_upload_service.get_profile_data", side_effect=lambda: json.loads(json.dumps({
        VAULT_PARENT_ORG_ID: "org_infra_uuid", "CF_USERNAME": "t1", "CF_PASSWORD": "t2",
        VAULT_HSDP_IAM_URL: "", VAULT_PARENT_SERVICE_AUTH_ISSUER: "", VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY: ""
    })))
    @patch("src.services.raw_data_insertion_service.file_upload_service.get_client_connection")
    @patch("src.services.raw_data_insertion_service.file_upload_service.create_service_token_from_vault", side_effect=lambda iam_url, issuer, private_key: "mToken")
    def test_file_upload_fetch_service_token(self, m_profile, m_client, m_token):
        file_upload_service = FileUploadService(service_user_uuid="")
        token = file_upload_service.fetch_service_token()
        m_profile.assert_called()
        m_client.assert_called()
        m_token.assert_called()
        self.assertEqual(token, "mToken")
