export const getassetlistByplantid = [
  {
    "assetId": "2K-3101",
    "assetName": "Cycle Gas Compressor 4"
  },
  {
    "assetId": "2K-3201",
    "assetName": "Cycle Gas Compressor 5"
  },
  {
    "assetId": "2K-4101",
    "assetName": "Cycle Gas Compressor 6"
  },
  {
    "assetId": "2K-4103",
    "assetName": "VRC"
  },
  {
    "assetId": "2Y-3001A",
    "assetName": "JSW N2 compressors"
  },
  {
    "assetId": "2Y-3001B",
    "assetName": "JSW N2 compressors"
  },
  {
    "assetId": "2Y-3003A",
    "assetName": "JSW C2 compressors"
  },
  {
    "assetId": "2Y-3003B",
    "assetName": "JSW C2 compressors"
  },
  {
    "assetId": "2Y-3013A",
    "assetName": "JSW H2 compressors"
  },
  {
    "assetId": "2Y-3013B",
    "assetName": "JSW H2 compressors"
  },
  {
    "assetId": "2Y-3223",
    "assetName": "Extruder 5"
  },
  {
    "assetId": "2Y-3601",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetId": "2Y-3602",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetId": "2Y-3603",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetId": "2Y-3604",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetId": "2Y-3605",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-3606",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-3607",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-3608",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-3609",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-3630",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetId": "2Y-4123A",
    "assetName": "Extruder 6"
  },
  {
    "assetId": "2Y-4123B",
    "assetName": "Extruder 7"
  },
  {
    "assetId": "2Y-3665",
    "assetName": "ORC"
  },
  {
    "assetId": "2Y-3123",
    "assetName": "Extruder 4"
  }

]

export const getplantAlertspmt = [
  {
    "timeStamp": "2022-09-20T13:55:51",
    "alertId": "63334",
    "description": "Intercooler Perf.",
    "assetId": "2Y-3605",
    "status": "Overdue",
    "taskAssignedTo": "30763547",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter"
  },
  {
    "timeStamp": "2022-10-31T16:15:08",
    "alertId": "132785",
    "description": "Suction Filter",
    "assetId": "2Y-3605",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check differential  pressure across  filter "
  },
  {
    "timeStamp": "2022-09-21T22:45:11",
    "alertId": "63787",
    "description": "Intercooler Performance",
    "assetId": "2Y-3605",
    "status": "Overdue",
    "taskAssignedTo": "30763547",
    "recommendation": "1. Check tube side inlet pressure "
  },
  {
    "timeStamp": "2022-11-01T11:00:18",
    "alertId": "132863",
    "description": "1st Stage Compressor Process",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure"
  },
  {
    "timeStamp": "2022-11-07T18:15:55",
    "alertId": "133503",
    "description": "Gearbox",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1.Check temperature of  thrust bearing"
  },
  {
    "timeStamp": "2022-10-31T13:27:47",
    "alertId": "132749",
    "description": "Motor Performance",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check current drawn by the motor"
  },
  {
    "timeStamp": "2022-11-21T16:01:38",
    "alertId": "136970",
    "description": "Lube Oil System",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil Containation / Quality / Send for analysis"
  },
  {
    "timeStamp": "2022-11-21T16:32:15",
    "alertId": "136975",
    "description": "Lube Oil Cooler",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil Containation / Quality / Send for analysis"
  },
  {
    "timeStamp": "2022-11-27T16:46:04",
    "alertId": "139164",
    "description": "Intercooler Performance",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check tube side inlet pressure "
  },
  {
    "timeStamp": "2022-11-09T13:30:35",
    "alertId": "133823",
    "description": "Aftercooler Performance",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check tube side inlet pressure "
  },
  {
    "timeStamp": "2022-11-09T21:45:20",
    "alertId": "133904",
    "description": "1st Stage Compressor Process",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure"
  },
  {
    "timeStamp": "2022-11-09T13:15:48",
    "alertId": "133819",
    "description": "Suction Filter",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check differential  pressure across  filter "
  },
  {
    "timeStamp": "2022-11-09T12:15:45",
    "alertId": "133818",
    "description": "Discharge Filter",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check differential  pressure across  filter "
  },
  {
    "timeStamp": "2022-11-24T12:17:31",
    "alertId": "137907",
    "description": "Compressor Journal Bearing Stage 1",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "In case of high vibration: 1.Check for dirt contamination"
  },
  {
    "timeStamp": "2022-11-24T14:05:03",
    "alertId": "138036",
    "description": "Compressor Journal Bearing Stage 2",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "In case of high vibration: 1.Check for dirt contamination"
  },
  {
    "timeStamp": "2022-09-18T13:43:43",
    "alertId": "62246",
    "description": "1st Stage Compressor Process",
    "assetId": "2Y-3608",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure"
  },
  {
    "timeStamp": "2022-11-18T23:15:50",
    "alertId": "136384",
    "description": "Compressor Journal Bearing Stage 2",
    "assetId": "2Y-3608",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "In case of high vibration: 1.Check for dirt contamination"
  },
  {
    "timeStamp": "2022-09-20T13:56:29",
    "alertId": "63341",
    "description": "Compressor Thrust Bearing Stage 1",
    "assetId": "2Y-3608",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil quality / Send for analysis"
  },
  {
    "timeStamp": "2022-12-28T10:31:49",
    "alertId": "184561",
    "description": "Gear Pump Motor Performance",
    "assetId": "2Y-3223",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check for any overloading of gear pump."
  },
  {
    "timeStamp": "2022-11-20T19:32:11",
    "alertId": "136770",
    "description": "Gear Box Lube Oil System",
    "assetId": "2Y-4123B",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check Lube Oil header pressure "
  },
  {
    "timeStamp": "2022-11-02T16:00:11",
    "alertId": "133106",
    "description": "Motor Journal Bearing",
    "assetId": "2K-3101",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil quality / Send for analysis"
  },
  {
    "timeStamp": "2022-10-31T13:27:34",
    "alertId": "132746",
    "description": "Compressor Performance",
    "assetId": "2K-3101",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure"
  },
  {
    "timeStamp": "2022-10-31T13:27:52",
    "alertId": "132751",
    "description": "Compressor Thrust Bearing",
    "assetId": "2K-3101",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil quality / Send for analysis"
  },
  {
    "timeStamp": "2022-11-19T11:16:05",
    "alertId": "136479",
    "description": "Motor Performance",
    "assetId": "2K-3201",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check current drawn by the motor"
  },
  {
    "timeStamp": "2022-11-04T11:22:24",
    "alertId": "133366",
    "description": "Motor Journal Bearing",
    "assetId": "2K-3201",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check lub oil quality / Send for analysis"
  },
  {
    "timeStamp": "2022-10-17T15:40:59",
    "alertId": "132042",
    "description": "Compressor Seal Gas Performance",
    "assetId": "2K-3201",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check for secondary vent flow rate"
  },
  {
    "timeStamp": "2022-09-22T15:31:48",
    "alertId": "64035",
    "description": "1st Stage Compressor Process_FE",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter  3. Check discharge temperature 4. Check for discharge Pressure (2nd stage) 5. Check for Suction flow 6. Check pre-cooler performance 7. Check for Intercooler performance 8. Check for After Cooler Performance 9. Check for feed gas composition and change in properties  10. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems* 11. Ensure proper oil supply to compressor and bearings 12. Check for internal damages of gears during overhaul in case of high vibration"
  },
  {
    "timeStamp": "2022-11-01T12:31:23",
    "alertId": "132887",
    "description": "1st Stage Compressor Process_FE",
    "assetId": "2Y-3606",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter  3. Check discharge temperature 4. Check for discharge Pressure (2nd stage) 5. Check for Suction flow 6. Check pre-cooler performance 7. Check for Intercooler performance 8. Check for After Cooler Performance 9. Check for feed gas composition and change in properties  10. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems* 11. Ensure proper oil supply to compressor and bearings 12. Check for internal damages of gears during overhaul in case of high vibration"
  },
  {
    "timeStamp": "2022-11-14T02:05:07",
    "alertId": "134596",
    "description": "1st Stage Compressor Process_FE",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter  3. Check discharge temperature 4. Check for discharge Pressure (2nd stage) 5. Check for Suction flow 6. Check pre-cooler performance 7. Check for Intercooler performance 8. Check for After Cooler Performance 9. Check for feed gas composition and change in properties  10. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems* 11. Ensure proper oil supply to compressor and bearings 12. Check for internal damages of gears during overhaul in case of high vibration"
  },
  {
    "timeStamp": "2022-11-09T13:17:36",
    "alertId": "133821",
    "description": "2nd Stage Compressor Process_FE",
    "assetId": "2Y-3607",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter  3. Check discharge temperature 4. Check for discharge Pressure (2nd stage) 5. Check for Suction flow 6. Check pre-cooler performance 7. Check for Intercooler performance 8. Check for After Cooler Performance 9. Check for feed gas composition and change in properties  10. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems* 11. Ensure proper oil supply to compressor and bearings 12. Check for internal damages of gears during overhaul in case of high vibration"
  },
  {
    "timeStamp": "2022-10-31T13:28:04",
    "alertId": "132755",
    "description": "2nd Stage Compressor Process_FE",
    "assetId": "2Y-3608",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check differential  pressure across suction gas filter  3. Check discharge temperature 4. Check for discharge Pressure (2nd stage) 5. Check for Suction flow 6. Check pre-cooler performance 7. Check for Intercooler performance 8. Check for After Cooler Performance 9. Check for feed gas composition and change in properties  10. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems* 11. Ensure proper oil supply to compressor and bearings 12. Check for internal damages of gears during overhaul in case of high vibration"
  },
  {
    "timeStamp": "2022-11-04T11:24:31",
    "alertId": "133389",
    "description": "Compressor Performance_FE",
    "assetId": "2K-3101",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check discharge pressure 3. Check suction temperature 4. Check discharge temperature 5. Check for suction flow 6. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems 7. Check for internal damages (blade / fin / disk / labyrinth) during overhaul in case of inadequate speed /power 8. Check Recycle / Anti Surge Valve /Blow-Off Valve for sluggishness in case of frequent compressor surges 9. Check for feed gas composition and change in properties "
  },
  {
    "timeStamp": "2022-09-20T13:57:07",
    "alertId": "63345",
    "description": "Compressor Performance_FE",
    "assetId": "2K-4101",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check discharge pressure 3. Check suction temperature 4. Check discharge temperature 5. Check for suction flow 6. Check for IGV malfunctioning / wearing of linkages in case load control and regulation problems 7. Check for internal damages (blade / fin / disk / labyrinth) during overhaul in case of inadequate speed /power 8. Check Recycle / Anti Surge Valve /Blow-Off Valve for sluggishness in case of frequent compressor surges 9. Check for feed gas composition and change in properties "
  },
  {
    "timeStamp": "2022-09-25T17:00:57",
    "alertId": "65246",
    "description": "Compressor Performance Stage 2_FE",
    "assetId": "2Y-3001A",
    "status": "Overdue",
    "taskAssignedTo": "13867",
    "recommendation": "1. Check suction pressure 2. Check discharge pressure 3. Check suction temperature 4. Check discharge temperature 5. Check for suction flow 6. Check filter differential pressure 7. Check for internal damages both head end and crank end during overhaul  8. Check for proper functioning of Suction valve unloaders 9. Check for proper operation of inlet and outlet valves. 10. Check for adequate clearance pockets maintained as per design. 11. Check for any leakages in the distance pieces."
  }
]

export const getassetcardpmtByplantid = [
  {
    "timeStamp": "2022-09-20T13:55:51",
    "alertId": "63334",
    "description": "1st Stage Compressor Process",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-31T16:15:08",
    "alertId": "132785",
    "description": "Suction Filter",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-21T22:45:11",
    "alertId": "63787",
    "description": "Intercooler Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-01T11:00:18",
    "alertId": "132863",
    "description": "1st Stage Compressor Process",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-07T18:15:55",
    "alertId": "133503",
    "description": "Gearbox",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-31T13:27:47",
    "alertId": "132749",
    "description": "Motor Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-21T16:01:38",
    "alertId": "136970",
    "description": "Lube Oil System",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-21T16:32:15",
    "alertId": "136975",
    "description": "Lube Oil Cooler",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-27T16:46:04",
    "alertId": "139164",
    "description": "Intercooler Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-09T13:30:35",
    "alertId": "133823",
    "description": "Aftercooler Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-09T21:45:20",
    "alertId": "133904",
    "description": "1st Stage Compressor Process",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-09T13:15:48",
    "alertId": "133819",
    "description": "Suction Filter",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-09T12:15:45",
    "alertId": "133818",
    "description": "Discharge Filter",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-24T12:17:31",
    "alertId": "137907",
    "description": "Compressor Journal Bearing Stage 1",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-24T14:05:03",
    "alertId": "138036",
    "description": "Compressor Journal Bearing Stage 2",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-18T13:43:43",
    "alertId": "62246",
    "description": "1st Stage Compressor Process",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-18T23:15:50",
    "alertId": "136384",
    "description": "Compressor Journal Bearing Stage 2",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-20T13:56:29",
    "alertId": "63341",
    "description": "Compressor Thrust Bearing Stage 1",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-12-28T10:31:49",
    "alertId": "184561",
    "description": "Gear Pump Motor Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-20T19:32:11",
    "alertId": "136770",
    "description": "Gear Box Lube Oil System",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-02T16:00:11",
    "alertId": "133106",
    "description": "Motor Journal Bearing",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-31T13:27:34",
    "alertId": "132746",
    "description": "Compressor Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-31T13:27:52",
    "alertId": "132751",
    "description": "Compressor Thrust Bearing",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-19T11:16:05",
    "alertId": "136479",
    "description": "Motor Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-04T11:22:24",
    "alertId": "133366",
    "description": "Motor Journal Bearing",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-17T15:40:59",
    "alertId": "132042",
    "description": "Compressor Seal Gas Performance",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-22T15:31:48",
    "alertId": "64035",
    "description": "1st Stage Compressor Process_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-01T12:31:23",
    "alertId": "132887",
    "description": "1st Stage Compressor Process_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-14T02:05:07",
    "alertId": "134596",
    "description": "1st Stage Compressor Process_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-09T13:17:36",
    "alertId": "133821",
    "description": "2nd Stage Compressor Process_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-10-31T13:28:04",
    "alertId": "132755",
    "description": "2nd Stage Compressor Process_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-11-04T11:24:31",
    "alertId": "133389",
    "description": "Compressor Performance_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-20T13:57:07",
    "alertId": "63345",
    "description": "Compressor Performance_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-25T17:00:57",
    "alertId": "65246",
    "description": "Compressor Performance Stage 2_FE",
    "status": "Overdue"
  }
]
export const getassetcardpmtByassetid = [
  {
    "timeStamp": "2022-09-20T13:57:07",
    "alertId": "63345",
    "description": "Compressor Performance_FE",
    "status": "Overdue"
  },
  {
    "timeStamp": "2022-09-25T17:00:57",
    "alertId": "65246",
    "description": "Compressor Performance Stage 2_FE",
    "status": "Overdue"
  }
]
export const gettopbarsummaryAssetpmtByplantid = [
  {
    "affiliateCount": 1,
    "assetCount": 25,
    "healthIndex": 28,
    "pmCompliance": 100,
    "active": 37,
    "overdueInvestigation": 0,
    "underInvestigation": 37,
    "healthTrend": 1,
    "alertTrend": 0
  }
]

export const getassetstatuspmtByplantid = [
  // {
  //   "title": "Asset_Under_Risk",
  //   "value": "10"
  // },
  // {
  //   "title": "Warning",
  //   "value": "4"
  // },
  // {
  //   "title": "Normal",
  //   "value": "2"
  // },
  // {
  //   "title": "Normal",
  //   "value": "2"
  // }

  {
    "title": "Asset_Under_Risk",
    "value": "0"
  },
  {
    "title": "Warning",
    "value": "4"
  },
  {
    "title": "Normal",
    "value": "11"
  },
  {
    "title": "Asset-off",
    "value": "4"
  }

]
export const getJsonAssetStatusListbyPlantId = [
  {
    "status": "All Asset Status"
  },
  {
    "status": "Asset-off"
  },
  {
    "status": "Normal"
  },
  {
    "status": "Warning"
  },
  {
    "status": "Asset Under Risk"
  }
]
export const getJsonHeatMapToolTipbyAssetStatus = [
  {
    "assetSapId": "310059910",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2K-3101",
    "assetName": "Cycle Gas Compressor 4"
  },
  {
    "assetSapId": "310059923",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2K-3201",
    "assetName": "Cycle Gas Compressor 5"
  },
  {
    "assetSapId": "310059938",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2K-4101",
    "assetName": "Cycle Gas Compressor 6"
  },
  {
    "assetSapId": "310059948",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2K-4103",
    "assetName": "VRC"
  },
  {
    "assetSapId": "310060739",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3001A",
    "assetName": "JSW N2 compressors"
  },
  {
    "assetSapId": "310060748",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3001B",
    "assetName": "JSW N2 compressors"
  },
  {
    "assetSapId": "310060752",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3003A",
    "assetName": "JSW C2 compressors"
  },
  {
    "assetSapId": "310060756",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3003B",
    "assetName": "JSW C2 compressors"
  },
  {
    "assetSapId": "310060764",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3013A",
    "assetName": "JSW H2 compressors"
  },
  {
    "assetSapId": "310060771",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3013B",
    "assetName": "JSW H2 compressors"
  },
  {
    "assetSapId": "310061001",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3223",
    "assetName": "Extruder 5"
  },
  {
    "assetSapId": "310061164",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3601",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061172",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3602",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061180",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3603",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061188",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3604",
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061193",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3605",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061199",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3606",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061205",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3607",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061211",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3608",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061217",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3609",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061244",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3630",
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061349",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-4123A",
    "assetName": "Extruder 6"
  },
  {
    "assetSapId": "310061373",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-4123B",
    "assetName": "Extruder 7"
  },
  {
    "assetSapId": "310365022",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3665",
    "assetName": "ORC"
  },
  {
    "assetSapId": "320034310",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "assetId": "2Y-3123",
    "assetName": "Extruder 4"
  }
]
export const getJsonTopBarToolTipbyPlantId = [
  {
    "assetSapId": "310059910",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2K-3101",
    "plantId": 18,
    "assetName": "Cycle Gas Compressor 4"
  },
  {
    "assetSapId": "310059923",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2K-3201",
    "plantId": 18,
    "assetName": "Cycle Gas Compressor 5"
  },
  {
    "assetSapId": "310059938",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2K-4101",
    "plantId": 18,
    "assetName": "Cycle Gas Compressor 6"
  },
  {
    "assetSapId": "310059948",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2K-4103",
    "plantId": 18,
    "assetName": "VRC"
  },
  {
    "assetSapId": "310060739",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3001A",
    "plantId": 18,
    "assetName": "JSW N2 compressors"
  },
  {
    "assetSapId": "310060748",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3001B",
    "plantId": 18,
    "assetName": "JSW N2 compressors"
  },
  {
    "assetSapId": "310060752",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3003A",
    "plantId": 18,
    "assetName": "JSW C2 compressors"
  },
  {
    "assetSapId": "310060756",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3003B",
    "plantId": 18,
    "assetName": "JSW C2 compressors"
  },
  {
    "assetSapId": "310060764",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3013A",
    "plantId": 18,
    "assetName": "JSW H2 compressors"
  },
  {
    "assetSapId": "310060771",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3013B",
    "plantId": 18,
    "assetName": "JSW H2 compressors"
  },
  {
    "assetSapId": "310061001",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3223",
    "plantId": 18,
    "assetName": "Extruder 5"
  },
  {
    "assetSapId": "310061164",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3601",
    "plantId": 18,
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061172",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3602",
    "plantId": 18,
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061180",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3603",
    "plantId": 18,
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061188",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3604",
    "plantId": 18,
    "assetName": "Atlas Copco N2 Compressor"
  },
  {
    "assetSapId": "310061193",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3605",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061199",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3606",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061205",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3607",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061211",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3608",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061217",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3609",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061244",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3630",
    "plantId": 18,
    "assetName": "Atlas Copco Air Compressor"
  },
  {
    "assetSapId": "310061349",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-4123A",
    "plantId": 18,
    "assetName": "Extruder 6"
  },
  {
    "assetSapId": "310061373",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-4123B",
    "plantId": 18,
    "assetName": "Extruder 7"
  },
  {
    "assetSapId": "310365022",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3665",
    "plantId": 18,
    "assetName": "ORC"
  },
  {
    "assetSapId": "320034310",
    "assetHealthIndex": 0,
    "assetTrend": false,
    "plantHealth": 28,
    "plantTrend": true,
    "assetId": "2Y-3123",
    "plantId": 18,
    "assetName": "Extruder 4"
  }
]
export const getReferenceTableModelDataInput = [
  {
    "modelName": "Compressor Performance Stage 1",
    "sensorName": "N2 A Comp Suct Press 230PI227A",
    "high": 704.953,
    "low": 646.99,
    "uom": "kPa"
  },
  {
    "modelName": "Compressor Performance Stage 1",
    "sensorName": "N2 A Comp 1St Disch Press 230PI269",
    "high": 1710.678,
    "low": 1580.279,
    "uom": "kPa"
  },
  {
    "modelName": "Compressor Performance Stage 1",
    "sensorName": "N2 A Comp Cwr Temp  230TI212",
    "high": 47.293,
    "low": 32.943,
    "uom": "DegC"
  },
  {
    "modelName": "Compressor Performance Stage 1",
    "sensorName": "N2 A Comp Suct Temp 230TI224",
    "high": 43.879,
    "low": 15.801,
    "uom": "DegC"
  }
]