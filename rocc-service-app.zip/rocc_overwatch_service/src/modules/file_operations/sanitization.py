from src.utility.dict_utils import drill_and_apply

def sanitize_dicts(data_dict):
    exceptions = []
    drill_and_apply(fn_list=[
        lambda value: value.strip() if isinstance(value, str) else value,   # Whitespace trimming
    ], data_dict=data_dict, exception_collector=exceptions)
    return data_dict, exceptions
