/*
 * Created on Fri Dec 3 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import RoomCardFooter from "./RoomCardFooter"
import { shallow } from "enzyme"
import React from "react"
import { EConnectionType } from "../../lib/types"
import { EUserPresence } from "@rocc/rocc-client-services"


jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalCurrentUser: jest.fn(() => {
        return {
            allRoles: []
        }
    }),
    fetchGlobalAppVersion: jest.fn(() => {
        return "version-test-123"
    }),
    fetchGlobalReceivers: jest.fn(() => {
        return {
            receivers: []
        }
    }),
}))
jest.mock("react-redux", () => ({
    useSelector: () => ({
        activeSessions: [{ roomUuid: "roomUuid", connectionType: EConnectionType.INCOGNITO_VIEW, connectionMode: "CC", receiverName: "receiverName" }],
        featureFlags: {
            "rocc-command-center-incognito": true,
            "rocc-command-center-pm-edit": true,
        },
        permissions: {
            CALL_WEB_TO_WEB: true,
            CONSOLE_EDIT_WITHOUT_AUTHORIZATION: true,
            CONSOLE_VIEW_INCOGNITO: true,
        },
    })
}))

describe("RoomCard footer", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    const useEffectMockMethod = () => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
    }
    it("should render footer", () => {
        useEffectMockMethod()
        wrapper = shallow(<RoomCardFooter isDisabled={false} phoneNumbers={["123456789"]} roomUuid="1" modalityName={"CT"} presence={EUserPresence.OFFLINE} roomName={""} />)
        expect(wrapper).toBeDefined()
    })
    it("should render popup", () => {
        useEffectMockMethod()
        wrapper = shallow(<RoomCardFooter isDisabled={true} phoneNumbers={["123456789"]} roomUuid="1" modalityName={"MRI"} presence={EUserPresence.OFFLINE} roomName={""} />)

        expect(wrapper.find("Popup").exists()).toBeTruthy()
    })
})
