/*
 * Created on Thu Jul 11 2019
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import React, { useEffect, useState } from "react"
import { Button, Grid, GridColumn, GridRow } from "semantic-ui-react"
import Pagination from "./Pagination/Pagination"
import { IDataGrid, ISortColumn } from "../data-grid/types"
import { paginate } from "./Utils"
import PDVTable from "./Table/Table"
import _ from "lodash"
import "./DataGrid.scss"


const sorted = (data: any, sortColumn: any) => _.orderBy(data,
    [(entry: any) => {
        let sortingValue = entry[sortColumn.path]
        const valueType = typeof sortingValue

        if (valueType === "object") {
            sortingValue = Object.values(sortingValue)[0]
        }

        if (valueType === "string") {
            return sortingValue?.toString()?.trim()?.toLowerCase()
        }

        return entry
    }],
    (sortColumn.order === "asc") ? "asc" : "desc"
)

const DataGrid: React.FC<IDataGrid> = ({ title, data, columns, pagination, initialPageSize, filter, search, multiSelect, moreAction, onDrillDown, tableHeadButton, detailsComponent, disableSort, searchBox, initialSortColumn, noRecords }) => {

    const [loading, setLoading] = useState(true)
    const [pageSize, setPageSize] = useState(initialPageSize)
    const [currentPage, setCurrentPage] = useState(1)
    const [isDetailPaneOpen, setIsDetailPaneOpen] = useState(false)
    const [columnWidth, setColumnWidth] = useState(true)
    const [sortColumn, setSortColumn] = useState(initialSortColumn ?? { path: Object.keys(data)[0] ?? "name", order: "asc" })
    const [selectedDataIndex, setSelectedDataIndex] = useState([-1])
    const [currentRow, setCurrentRow] = useState(-1)

    useEffect(() => {
        setCurrentPage(1)
    }, [data])

    const handleLoading = () => {
        const timeout = 10
        setTimeout(() => {
            setLoading(false)
        }, timeout)
    }

    const updateEntriesPerPage = (perPage: number) => {
        setPageSize(perPage)
        setCurrentPage(1)
    }

    const handlePageChange = (page: number) => {
        setCurrentPage(page)
    }

    const handleSort = (column: ISortColumn) => {
        setSortColumn(column)
    }

    const onRowClick = (index: number, row: any) => {
        if (detailsComponent) {
            const selectedRows = selectedDataIndex
            selectedRows.push(index)
            setIsDetailPaneOpen(true)
            setCurrentRow(index)
            setSelectedDataIndex(selectedRows)
            setColumnWidth(false)
            // TODO: filter will be per column per DLS
            // setIsFiltersPaneOpen(false)
        }
    }

    const handleDeselectDataClick = () => {
        const selectedRows = [-1]
        setSelectedDataIndex(selectedRows)
        setColumnWidth(true)
        setIsDetailPaneOpen(false)
        setCurrentRow(-1)
    }

    const paginatedData = paginate(disableSort ? data : sorted(data, sortColumn), currentPage, pageSize)

    if (paginatedData && paginatedData.length) {
        handleLoading()
    }

    return (
        <Grid className={"pdv-data-grid"}>
            <GridRow>
                <Grid columns={2}>
                    {/* TODO: filter refactor to column filter UI per DLS
                        <GridColumn width={3} className={`${isFiltersOpen ? "filtersOpen" : "filters"}`}>
                            {renderFiltersPane()}
                        </GridColumn> */}
                    <GridColumn className={columnWidth ? "widthPanelClose" : "widthPanelOpen"}>
                        <PDVTable
                            loading={loading}
                            title={title}
                            data={paginatedData}
                            columns={columns}
                            initialPageSize={pageSize}
                            sortColumn={sortColumn}
                            selectedRowIndex={[]}
                            multiSelect={multiSelect}
                            onSort={handleSort}
                            onRowClick={onRowClick}
                            onDrillDown={onDrillDown}
                            tableHeadButton={tableHeadButton}
                            currentRow={currentRow}
                            searchBox={searchBox}
                            noRecords={noRecords}
                        />
                        {pagination &&
                            <Pagination
                                itemsCount={data.length}
                                initialPageSize={initialPageSize}
                                pageSize={pageSize}
                                currentPage={currentPage}
                                onPageChange={handlePageChange}
                                updateEntriesPerPage={updateEntriesPerPage}
                            />
                        }
                    </GridColumn>
                    {detailsComponent && <GridColumn className={isDetailPaneOpen ? "detailpaneopen" : "detailpanehide"}>
                        <GridRow>
                            <Button className={"closeIcon"} onClick={handleDeselectDataClick}>
                                {"X"}
                            </Button>
                            {detailsComponent(currentRow, handleDeselectDataClick)}
                        </GridRow>
                    </GridColumn>}
                </Grid>
            </GridRow>
        </Grid>
    )
}

export default DataGrid