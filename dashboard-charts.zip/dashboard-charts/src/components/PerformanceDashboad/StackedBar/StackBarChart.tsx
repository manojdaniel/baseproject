// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

import totalalert from "../../../assets/images/total-alert.svg";
interface Props {
	data: any[];
}
const StackBarChart = ({ data }: Props) => {
	useLayoutEffect(() => {
		if (data.length > 0) {
			/* Chart code */
			// Create root element
			// https://www.amcharts.com/docs/v5/getting-started/#Root_element
			let root = am5.Root.new("chartdiv1");
			/* remove amchart logo */

			root._logo.dispose();

			// Set themes
			// https://www.amcharts.com/docs/v5/concepts/themes/
			root.setThemes([am5themes_Animated.new(root)]);

			// Create chart
			// https://www.amcharts.com/docs/v5/charts/xy-chart/
			let chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					wheelX: "panX",
					wheelY: "zoomX",
					layout: root.verticalLayout,
					width: am5.percent(100),
				})
			);

			chart.get("colors").set("colors", [
				am5.color(0xe35205), //red
				am5.color(0x3bb44a), //green
				am5.color(0x929292), //Gray
			]);
			//chart.zoomOutButton.set("color", { fill: am5.color(0xff0000) });

			chart.zoomOutButton.get("background").setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart.zoomOutButton.get("background").states.create("hover", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});

			chart.zoomOutButton.get("background").states.create("down", {}).setAll({
				fill: am5.color(0x009fdf),
				fillOpacity: 0.8
			});


			// Create axes
			// https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
			let xRenderer = am5xy.AxisRendererX.new(root, { minGridDistance: 0 });
			xRenderer.labels.template.setAll({
				rotation: -90,
				fontSize: "0.8rem",
				centerY: am5.p50,
				centerX: am5.p100,
				// paddingRight: 15,
			});
			let xAxis = chart.xAxes.push(
				am5xy.CategoryAxis.new(root, {
					categoryField: "assetId",
					renderer: xRenderer,
					tooltip: am5.Tooltip.new(root, {}),
					minHorizontalGap: 0,
				})
			);

			xRenderer.grid.template.setAll({});

			xAxis.data.setAll(data);

			let yAxis = chart.yAxes.push(
				am5xy.ValueAxis.new(root, {
					min: 0,
					renderer: am5xy.AxisRendererY.new(root, {
						strokeOpacity: 0.1,
						fontSize: "0.8rem",
					}),
				})
			);
			let yRenderer = yAxis.get("renderer");
			yRenderer.labels.template.setAll({
				fontSize: "0.8rem",
			});

			// Add series
			// https://www.amcharts.com/docs/v5/charts/xy-chart/series/
			function makeSeries(name, fieldName) {
				let series = chart.series.push(
					am5xy.ColumnSeries.new(root, {
						name,
						stacked: true,
						xAxis,
						yAxis,
						valueYField: fieldName,
						categoryXField: "assetId",
					})
				);
				let tooltip = am5.Tooltip.new(root, {
					getFillFromSprite: true,

					getLabelFillFromSprite: true,
				});

				series.set("tooltip", tooltip);
				series.columns.template.setAll({
					tooltipText: "{valueY}",
					tooltipY: am5.percent(5),

					width: am5.percent(35),
				});
				series.data.setAll(data);

				// Make stuff animate on load
				// https://www.amcharts.com/docs/v5/concepts/animations/
				series.appear();

				series.bullets.push(function () {
					return am5.Bullet.new(root, {
						sprite: am5.Label.new(root, {
							fill: root.interfaceColors.get("alternativeText"),
							centerY: am5.p50,
							centerX: am5.p50,
							populateText: true,
						}),
					});
				});


			}



			makeSeries("True_Positive", "True_Positive");
			makeSeries("False_Positive", "False_Positive");
			makeSeries("Unclassified", "Unclassified");

			// Make stuff animate on load
			// https://www.amcharts.com/docs/v5/concepts/animations/
			chart.appear(1000, 100);
			return () => {
				root.dispose();
			};
		}
	}, [data]);
	return (
		<div id="rightchartdiv1">
			<img src={totalalert} />
			<div id="chartdiv1" style={{ width: "100%", height: "250px" }}></div>
		</div>
	);
};

export default StackBarChart;
