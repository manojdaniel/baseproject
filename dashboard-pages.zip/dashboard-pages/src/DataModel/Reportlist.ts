export const reportData = [
    {
        "alertID": "140190",
        "affiliate": "YANPET",
        "plant": "POLY2",
        "timeStamp": "Nov 29 2022  9:30PM",
        "assetID": "2Y-3123",
        "assetDescription":"Testing Description",
        "assetName": "Extruder 4",
        "anomalyType": "Main Motor Bearing",
        "keyIdentifiedSensor1": "Outboard Bearing Vibration 231VI739D",
        "keyIdentifiedSensor2": "Outboard Bearing Vibration 231VI739C",
        "keyIdentifiedSensor3": "Inboard Bearing Temp 231TI728AA",
        "keyIdentifiedSensor4": "Outboard Bearing Temp 231TI728BB",
        "keyIdentifiedSensor5": "Inboard Bearing Temp 231TI728AB",
        "keyIdentifiedSensor6": "Outboard Bearing Temp 231TI728BA",
        "currentStage": "Department Action",
        "assignedTo": "Digitalization Champion",
        "assignedToUser": "SABICCORP\\30757265",
        "status": "Overdue",
        "alertClass": "TRUE POSITIVE",
        "requireLeadAction": false
    }
]

export const alertDetailsData = [{
    "alertId": "12346",
    "alertTimeStamp": "2212412",
    "url": "cleck here to navigate",
    "longLead": "cleck here to navigate",
    "description": "Alert",
    "assetId": "Alert",
    "Alert Class": "Alert",
    "Target": "Alert",
    "anamaloy": "Alert",
    "assetDescription": "Alert",
    "AHC": "Alert",
    "actionDetails": "Alert",
    "attachements": [{
    "fileName": "sfffdf",
    "fileType": "iamge/png"
    }]
}]

export const GetAHCRequestLogByRequestIdJSON = [
    {
      "processStage": "Start",
      "activityAction": "Submit",
      "commentedByName": null,
      "comments": "Request Submitted",
      "commentedOn": "2023-01-03T06:25:49.513",
      "commentedByNTID": null,
      "requestLogID": 31650,
      "requestID": 25395,
      "isActive": true
    },
    {
      "processStage": "Start",
      "activityAction": "Submit",
      "commentedByName": null,
      "comments": "Request Submitted",
      "commentedOn": "2023-01-03T06:25:49.513",
      "commentedByNTID": "SABICCORP\\deadmin",
      "requestLogID": 31651,
      "requestID": 25395,
      "isActive": true
    },
    {
      "processStage": "Start",
      "activityAction": "Submit",
      "commentedByName": null,
      "comments": "Request Submitted",
      "commentedOn": "2023-01-03T06:25:49.513",
      "commentedByNTID": "SABICCORP\\deadmin",
      "requestLogID": 31752,
      "requestID": 25395,
      "isActive": true
    }
  ]