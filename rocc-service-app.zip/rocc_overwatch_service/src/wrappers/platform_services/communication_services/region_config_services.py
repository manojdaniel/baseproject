"""
 Created on Wed Jul 20 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, ORG_CTXT_HEADER, PHILIPS_ROCC_URI, AUTHORIZATION

LOG = create_logger("RegionConfigServices")


def fetch_region_config_data(url, token, country_code=None):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token
    }
    try:
        region_config_url = f"{url}{PHILIPS_ROCC_URI}/RegionConfig"
        if country_code:
            region_config_url = f"{region_config_url}?countryIsoCode={country_code}"
        response = requests.get(region_config_url,
                                headers=headers,
                                verify=False)
        if response.status_code == 200:
            LOG.info(f"Successfully able to fetch region config : {response.json()}")
            if isinstance(response.json(), list) and len(response.json()):
                return response.json()[0]
        else:
            LOG.error(f"Failed to fetch region config with error: {response}")
    except Exception as e:
        LOG.exception(f"Exception occurred while fetching region config information: {e}")


def update_region_config(url, data, id, token):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token
    }
    try:
        countryISOCode = data["countryIsoCode"]
        region_config_url = f"{url}{PHILIPS_ROCC_URI}/RegionConfig/{id}"
        response = requests.put(region_config_url,
                                data=json.dumps(data),
                                headers=headers,
                                verify=False)
        if response.status_code == 200:
            LOG.info(f"Region config for Country {countryISOCode} is updated successfully.")
            return True
        else:
            LOG.error(f"Failed to update region config for country {countryISOCode} with error: {response}")
    except Exception as e:
        LOG.exception(f"Exception occurred while region config updation: {e}")
    return False


def create_new_region_config(url, data, token):
    headers = {
        CONTENT_TYPE: APPLICATION_JSON,
        AUTHORIZATION: token
    }
    try:
        countryISOCode = data["countryIsoCode"]
        region_config_url = f"{url}{PHILIPS_ROCC_URI}/RegionConfig"
        response = requests.post(region_config_url,
                                 data=json.dumps(data),
                                 headers=headers,
                                 verify=False)
        if response.status_code == 201:
            LOG.info(f"Region config for Country {countryISOCode} created successfully.")
            return True
        else:
            LOG.error(f"Failed to create region config for country {countryISOCode} with error: {response}")
    except Exception as e:
        LOG.exception(f"Exception occurred while region config creation: {e}")
    return False
