/*
 * Created on Mon Sept 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { attachLocalVideoEvent, detachLocalVideoEvent, getTrackingEvent, guestUserVideoEvent, MPC_TO_P2P_EVENT, P2P_TO_MPC_EVENT, videoCallDuration } from "./TelemetryTrackingHelper"

describe("TelemetryTrackingHelper", () => {
    let mockUser: any
    let mockParticipants: any
    let mockOptionName: any
    beforeEach(() => {
        mockUser = {
            uuid: "e9557e1f-5d99-469b-a944-e1a1b6170f23",
        }
        mockParticipants = 1
        mockOptionName = "VIEW_CONSOLE"
    })

    it("should track mute event of user", () => {
        expect(detachLocalVideoEvent(mockUser, mockParticipants)).toEqual("Logged in Expert User stopped the local video e9557e1f-5d99-469b-a944-e1a1b6170f23")
    })

    it("should track mute event of user in multi-party call", () => {
        mockParticipants = 2
        expect(detachLocalVideoEvent(mockUser, mockParticipants)).toEqual("Switching to MPC Call from peer to peer video call")
    })

    it("should track unmute event of user", () => {
        expect(attachLocalVideoEvent(mockUser)).toEqual("Logged in Expert User started the local video e9557e1f-5d99-469b-a944-e1a1b6170f23")
    })

    it("should track the guest user events", () => {
        expect(guestUserVideoEvent(mockUser)).toEqual("Video is enabled for guest user in the room e9557e1f-5d99-469b-a944-e1a1b6170f23")
    })

    it("should track P2P to MPC event", () => {
        expect(P2P_TO_MPC_EVENT).toEqual("Switching to MPC audio video call")
    })
    it("should track MPC to P2P event", () => {
        expect(MPC_TO_P2P_EVENT).toEqual("Switching to P2P audio video call")
    })

    it("should track the duration of video enabled in the call", () => {
        expect(videoCallDuration(mockUser)).toEqual("e9557e1f-5d99-469b-a944-e1a1b6170f23 Expert User disabled the local video ")
    })

    it("should track the event name", () => {
        expect(getTrackingEvent(mockOptionName)).toEqual("View Console")
    })
})
