/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import { isDev } from "./common/helpers/helpers"
import CallMessageWrapper from "./common/modules/avmessages/CallMessageWrapper"
import CallEventHandler from "./common/modules/call-event-handler/CallEventHandler"
import SyncExternalRedux from "./common/modules/setup/SyncExternalRedux"
import IncomingCall from "./components/incoming-call/IncomingCall"
import store, { persistor } from "./redux/store/store"
import { ICallFeatures } from "./types/types"
import { WorkflowController } from "./common/modules/workflow-controller/WorkflowController"


const CallFeatures = (props: ICallFeatures) => {
    const httpClient = useRoccHttpClient()

    useEffect(() => {
        setupAxiosHandler(httpClient)
        setupLogger({ isDev: isDev() })
    }, [])

    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                <HttpClientProvider client={httpClient}>
                    <IntlProvider
                        defaultLocale={"en-US"}
                        locale={"en"}
                    >
                        <>
                            <CallMessageWrapper />
                            <IncomingCall {...props} />
                            <SyncExternalRedux />
                            <CallEventHandler />
                            <WorkflowController />
                        </>
                    </IntlProvider>
                </HttpClientProvider>
            </PersistGate>
        </Provider>
    </>
}

export default CallFeatures
