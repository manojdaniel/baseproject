// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5xy from "@amcharts/amcharts5/xy";
import * as am5 from "@amcharts/amcharts5";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

//chart type
interface Props {
	data: any[];
}
const PredictionCase = ({ data }: Props) => {
	if (data.length > 0) {
		useLayoutEffect(() => {
			// Create root and chart
			var root = am5.Root.new("chartdiv2");
			/* remove amchart logo */

			root._logo.dispose();

			let Topdata = [];
			data.forEach((device, index) => {
				Topdata[index] = { ...device };
			});

			root.setThemes([am5themes_Animated.new(root)]);

			var chart = root.container.children.push(
				am5xy.XYChart.new(root, {
					panY: false,
					wheelY: "zoomX",
					layout: root.verticalLayout,
					maxTooltipDistance: 0,
					x: 200,
				})
			);

			// Create Y-axis
			var yAxis = chart.yAxes.push(
				am5xy.ValueAxis.new(root, {
					extraTooltipPrecision: 1,
					renderer: am5xy.AxisRendererY.new(root, {}),
				})
			);

			var xAxis = chart.xAxes.push(
				am5xy.DateAxis.new(root, {
					baseInterval: { timeUnit: "day", count: 1 },
					renderer: am5xy.AxisRendererX.new(root, {
						minGridDistance: 34,
					}),
				})
			);

			chart
				.get("colors")
				.set("colors", [am5.color(0xe35205), am5.color(0x4e79a7)]);

			function createSeries(name, field) {
				var series = chart.series.push(
					am5xy.LineSeries.new(root, {
						minBulletDistance: 10,
						name,
						xAxis,
						yAxis,
						valueYField: field,
						valueXField: "date",
						stacked: false,

						tooltip: am5.Tooltip.new(root, {
							pointerOrientation: "horizontal",
							labelText: "{valueY}",
						}),
					})
				);

				series.fills.template.setAll({});
				series.data.processor = am5.DataProcessor.new(root, {
					dateFormat: "yyyy-MM-dd",
					dateFields: ["date"],
				});
				series.bullets.push(function () {
					return am5.Bullet.new(root, {
						sprite: am5.Circle.new(root, {
							radius: 5,
							fill: series.get("fill"),
						}),
					});
				});

				series.strokes.template.set("strokeWidth", 2);

				series.get("tooltip").label.set("text", "{valueY}");

				series.data.setAll(Topdata);
			}
			createSeries("Precision", "precision");
			createSeries("Recall", "recall");
			var legend = chart.leftAxesContainer.children.push(
				am5.Legend.new(root, {
					background: am5.Rectangle.new(root, {}),
					height: am5.percent(80),
					centerX: am5.percent(8),
					x: -170,
					position: "absolute",
					centerY: am5.percent(20),
					useDefaultMarker: true,
					y: 50,
				})
			);

			legend.markerRectangles.template.setAll({
				width: 18,
				height: 10,
				cornerRadiusTL: 8,
				cornerRadiusTR: 7,
				cornerRadiusBL: 7,
				cornerRadiusBR: 7,
				fontSize: 11,
				y: 4,
			});

			legend.itemContainers.template.set("width", am5.percent(40));

			legend.data.setAll(chart.series.values.slice(0, 4));

			// Add cursor
			var cursor = chart.set(
				"cursor",
				am5xy.XYCursor.new(root, {
					xAxis,
				})
			);
			cursor.lineY.set("visible", false);
			// Add cursor
			chart.set(
				"cursor",
				am5xy.XYCursor.new(root, {
					behavior: "zoomXY",
					xAxis,
				})
			);

			// xAxis.set(
			// 	"tooltip",
			// 	am5.Tooltip.new(root, {
			// 		themeTags: ["axis"],
			// 	})
			// );

			// yAxis.set(
			// 	"tooltip",
			// 	am5.Tooltip.new(root, {
			// 		themeTags: ["axis"],
			// 	})
			// );

			chart.appear(1000, 100);
			return () => {
				root.dispose();
			};
		}, [data]);
		return (
			<div id="chartdiv2" style={{ width: "100%", height: "180px" }}></div>
		);
	}
};
export default PredictionCase;
