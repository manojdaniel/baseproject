"""
 Created on Tue Nov 16 2021
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os

from src.constants.constants import ID, ROCC_COMMAND_CENTRE_SEATS, RETURNING, AFFECTED_ROWS, ROCC_COMMAND_CENTER_RECEIVER_MAPPINGS, ROCC_RECEIVER, ROCC_UPDATE_COMMAND_CENTER_SEATS, RECEIVER_FK_VIOLATION, ROCC_DELETE_COMMAND_CENTER_SEATS, ROCC_KVM_TRANSACTIONS_AGGREGATE
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present, extract_items_from_result, extract_data_items_from_result, get_aggregate_count
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.graphql.queries.queries import fetch_customer_name_from_db_id, verify_if_receiver_present, fetch_cc_details, check_if_transaction_exists_for_seat_receiver
from src.wrappers.graphql.mutations.mutations import insert_seats_receivers, update_command_center_details, delete_command_center, soft_delete_command_center, soft_update_command_center_details
from src.wrappers.graphql.connection.connection import get_client_connection
from src.loggers.log import create_logger
from src.exceptions.RoccException import RoccException

from src.constants.config_keys import VAULT_PARENT_ORG_ID
from src.constants.constants import DATA, HSDP_IAM_URL, ROCC_ORGANIZATIONS, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, \
    HSDP_ORGANIZATION_ID, OBJECTS


LOG = create_logger("CommandCenterService")


class CommandCenterService():

    def __init__(self, service_user_uuid, customer_id, user_token):
        try:
            self._service_user_uuid = service_user_uuid
            self._service_user_token = user_token
            self._org_db_id = customer_id
            self._profile_configs = get_profile_data()
            self._parent_org_infra_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            read_only_client = get_client_connection(
                self._service_user_token, org_infra_uuid=self._parent_org_infra_uuid, is_fse=True)
            self._vault_values, self._org_infra_uuid, self._token = self.populate_service_token(
                read_only_client)
            self._client = get_client_connection(
                self._token, org_infra_uuid=self._org_infra_uuid)
        except RoccException as ex:
            LOG.exception(
                f"RoccException - Service initialization failed with error: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"Service initialization failed: {ex}.")
            raise ex

    def populate_service_token(self, read_only_client):
        db_result = read_only_client.execute(
            fetch_customer_name_from_db_id, variable_values={"org_db_id": self._org_db_id})
        customers = db_result[ROCC_ORGANIZATIONS]
        if customers and len(customers) == 1:
            customer_name = customers[0]["org_identifier"]
            customer_vault_values = get_path_specific_vault_values(
                path_name=customer_name)
            org_infra_uuid = customer_vault_values[DATA][HSDP_ORGANIZATION_ID]
            token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                    issuer=customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                    private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            return customer_vault_values, org_infra_uuid, token
        else:
            LOG.error(
                f"Invalid customer_id: {self._org_db_id}, could not get valid customer name!")
            raise RoccException(status_code=400, title="Invalid customer id.",
                                payload=f"Invalid customer_id: {self._org_db_id}, could not get valid customer name!")

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Command Center", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_infra_uuid, token=self._token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def onboard_command_center(self, seat_name, seat_info, receivers):
        try:
            receiver_objects = []
            for receiver in receivers:
                obj = {
                    "created_by": self._service_user_uuid,
                    "modified_by": self._service_user_uuid,
                    "rocc_receiver": {
                        "data": {
                            "receiver_ip": receiver["receiver_ip"],
                            "receiver_connection_name": receiver["receiver_connection_name"],
                            "monitor_name": receiver["monitor_name"],
                            "created_by": self._service_user_uuid,
                            "modified_by": self._service_user_uuid
                        }
                    }
                }
                receiver_objects.append(obj)

            command_center_object = {
                "organization_id": self._org_db_id,
                "seat_name": seat_name,
                "seat_info": seat_info,
                "created_by": self._service_user_uuid,
                "modified_by": self._service_user_uuid,
                "rocc_command_centre_receiver_mappings": {
                    "data": receiver_objects
                }
            }

            response = self._client.execute(verify_if_receiver_present,
                                            variable_values={"seat_name": seat_name,
                                                             "organization_id": self._org_db_id})
            result = check_if_id_is_present(
                data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)
            if result:
                LOG.info(f"Seat Name: {seat_name} already exists")
                raise RoccException(
                    400, f"RoccException while onboarding command center: {seat_name}", "Seat Name already exists.")

            LOG.info(
                f"Initiating Graphql request to create new command center seat {seat_name}")
            db_result = self._client.execute(insert_seats_receivers, variable_values={
                                             OBJECTS: command_center_object})
            LOG.info(
                f"Command Center onboard completed: {db_result} ")
            self.safe_audit(event_subtype="Onboard Command Center completed.", action="C",
                            outcome=0, code="Onboard Command Center completed.", value="Success")
            command_center_response = db_result["insert_rocc_rocc_command_centre_seats"]["returning"][0]

            return {
                "id": command_center_response[ID],
                "seat_name": command_center_response["seat_name"],
                "seat_info": command_center_response["seat_info"],
                "organization": command_center_response["organization"],
                "cc_mapping": command_center_response["rocc_command_centre_receiver_mappings"],
                "registered_count": command_center_response["registered_count"]
            }

        except RoccException as ex:
            LOG.exception(
                f"ROCCException while onboarding command center: {seat_name}. {ex}")
            self.safe_audit(event_subtype="Onboard Command Center", action="C",
                            outcome=8, code="Onboard Command Center", value="Error")
            raise ex
        except Exception as ex:
            LOG.exception(
                f"while onboarding command center: {seat_name}. {ex}")
            self.safe_audit(event_subtype="Onboard Command Center", action="C",
                            outcome=8, code="Onboard Command Center", value="Error")
            raise RoccException(
                500, title=f"RoccException while onboarding command center: {seat_name}", payload="Internal server error") from ex

    def get_receiver_ids(self, receivers):
        ids = []
        receivers_map = {}
        for receiver in receivers:
            receivers_map[receiver[ID]] = receiver
            ids.append(receiver[ID])
        return ids, receivers_map

    def check_kvm_transaction_present(self, seat_name, receiver_names):
        """
        Check whether a transaction has been made with given seat_name or receiver_name.
        Checks if seat_name or rx_name present in kvm_transactions table
        """
        try:
            response = self._client.execute(check_if_transaction_exists_for_seat_receiver, variable_values={
                                            "seat_name": seat_name, "org_id": self._org_db_id, "rx_names": receiver_names})
            return True if get_aggregate_count(response, ROCC_KVM_TRANSACTIONS_AGGREGATE) > 0 else False
        except Exception as ex:
            LOG.exception(f"Exception while checking transaction exists for seat and receivers: {seat_name}.{receiver_names} {ex}")
            raise RoccException(
                500, title=f"Exception while checking transaction exists for: {seat_name}", payload="Internal server error") from ex

    def check_seat_name_exists(self, seat_name):
        try:
            response = self._client.execute(verify_if_receiver_present, variable_values={"seat_name": seat_name, "organization_id": self._org_db_id})
            result = check_if_id_is_present(data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)
            return not result is False
        except Exception as ex:
            LOG.exception(f"Exception while checking seat name present : {seat_name}. {ex}")
            raise RoccException(
                500, title=f"Exception while checking seat name present: {seat_name}", payload="Internal server error") from ex

    def update_command_center(self, seat_id, seat_name, seat_info, receivers, reg_count):
        try:
            LOG.info(
                f"Initiating Graphql request to fetch command center seat details of {seat_id}")
            response = self._client.execute(
                fetch_cc_details, variable_values={"cc_id": seat_id})
            result = check_if_id_is_present(
                data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)

            if not result:
                LOG.info(f"Seat id: {seat_id} does not exist.")
                raise RoccException(400, f"RoccException while updating command center: {seat_name}", "Seat id does not exist.")

            db_receivers = extract_items_from_result(response[ROCC_COMMAND_CENTRE_SEATS][0], ROCC_COMMAND_CENTER_RECEIVER_MAPPINGS, ROCC_RECEIVER)
            db_receiver_ids, db_receivers_map = self.get_receiver_ids(db_receivers)
            old_receivers_names = []
            old_seat_name = ""
            # Check whether seat name to be updated already present in DB
            if response[ROCC_COMMAND_CENTRE_SEATS][0]["seat_name"] != seat_name:
                old_seat_name = response[ROCC_COMMAND_CENTRE_SEATS][0]["seat_name"]
                if self.check_seat_name_exists(seat_name):
                    LOG.info(f"Seat Name: {seat_name} already exists")
                    raise RoccException(400, f"RoccException while onboarding command center: {seat_name}", "Seat Name already exists.")

            updated_receivers, new_receiver_mappings, deleted_receivers, old_receivers_names = self.compute_receiver_changes(
                receivers=receivers, db_receiver_ids=db_receiver_ids, db_receivers_map=db_receivers_map, seat_id=seat_id)

            if self.check_kvm_transaction_present(old_seat_name, old_receivers_names):
                LOG.info(f"Transactions present with given seat name {old_seat_name} or receiver names {old_receivers_names}")
                raise RoccException(400, f"RoccException while updating command center: {seat_name}", "Seat or receiver has transactions.")

            for deleted_receiver in deleted_receivers:
                old_receivers_names.append(db_receivers_map[deleted_receiver]["receiver_connection_name"])

            query_variables = {
                "cc_id": seat_id,
                "cc_details": {
                    "seat_name": seat_name,
                    "seat_info": seat_info,
                    "registered_count": reg_count,
                    "modified_by": self._service_user_uuid
                },
                "del_receivers": deleted_receivers,
                "updated_receivers": updated_receivers,
                "new_receiver_mappings": new_receiver_mappings
            }
            if len(deleted_receivers) > 0:
                LOG.info(f"Deleting receivers {deleted_receivers} from receivers {receivers} for seat id {seat_id}")

            try:
                if self.check_kvm_transaction_present(old_seat_name, old_receivers_names):
                    LOG.info(f"Transactions present with receiver names {old_receivers_names}. Unmapping receivers only")
                    response = self._client.execute(soft_update_command_center_details, variable_values=query_variables)
                else:
                    response = self._client.execute(update_command_center_details, variable_values=query_variables)
            except Exception as ex:
                # Indicates shared receiver among multiple seats, remove seat receiver mappings only
                if RECEIVER_FK_VIOLATION in str(ex.args[0]):
                    LOG.info(f"Seat id: {seat_id} has shared receivers. Unmapping receivers")
                    response = self._client.execute(soft_update_command_center_details, variable_values=query_variables)
                else:
                    raise ex

            self.safe_audit(event_subtype="Update Command Center completed.", action="U",
                            outcome=0, code="Update Command Center completed.", value="Success")
            cc_mappings = extract_data_items_from_result(
                response["insert_rocc_rocc_receivers"],
                RETURNING, ROCC_COMMAND_CENTER_RECEIVER_MAPPINGS) + response["insert_rocc_rocc_command_centre_receiver_mappings"][RETURNING]
            return {
                "id": seat_id,
                "seat_name": seat_name,
                "seat_info": seat_info,
                "organization": response[ROCC_UPDATE_COMMAND_CENTER_SEATS][RETURNING][0]["organization"],
                "cc_mapping": cc_mappings,
                "registered_count": reg_count
            }
        except RoccException as ex:
            LOG.exception(
                f"ROCCException while updating command center: {seat_name}. {ex}")
            self.safe_audit(event_subtype="Update Command Center", action="U",
                            outcome=8, code="Update Command Center", value="Error")
            raise ex
        except Exception as ex:
            LOG.exception(
                f"Exception while updating command center: {seat_name}. {ex}")
            self.safe_audit(event_subtype="Update Command Center", action="U",
                            outcome=8, code="Update Command Center", value="Error")
            raise RoccException(
                500, title=f"RoccException while updating command center: {seat_name}", payload="Internal server error") from ex

    def delete_command_center(self, seat_id):
        try:
            LOG.info(
                f"Initiating Graphql request to fetch command center seat details of {seat_id}")
            response = self._client.execute(
                fetch_cc_details, variable_values={"cc_id": seat_id})
            result = check_if_id_is_present(
                data=response, table_name=ROCC_COMMAND_CENTRE_SEATS)

            if not result:
                LOG.info(f"Seat id: {seat_id} does not exist.")
                raise RoccException(
                    400, f"RoccException while offboarding command center: {seat_id}", "Seat id does not exist.")

            seat_name = response[ROCC_COMMAND_CENTRE_SEATS][0]["seat_name"]
            db_receivers = extract_items_from_result(
                response[ROCC_COMMAND_CENTRE_SEATS][0], ROCC_COMMAND_CENTER_RECEIVER_MAPPINGS, ROCC_RECEIVER)
            receiver_ids, db_receivers_map = self.get_receiver_ids(db_receivers)
            receivers_names = [receiver["receiver_connection_name"] for receiver in db_receivers_map.values()]

            # Check if CC has transactions
            if self.check_kvm_transaction_present(seat_name, receivers_names):
                LOG.info(f"Transactions present with given seat name {seat_name} or receiver names {receivers_names}")
                raise RoccException(400, f"RoccException while offboarding command center: {seat_name}", "Seat or receiver has transactions.")

            query_variables = {
                "cc_id": seat_id,
                "receiver_ids": receiver_ids,
            }
            try:
                response = self._client.execute(
                    delete_command_center, variable_values=query_variables)
            except Exception as ex:
                # Indicates shared receiver among multiple seats, remove seat receiver mappings only
                if RECEIVER_FK_VIOLATION in str(ex.args[0]):
                    LOG.info(
                        f"Seat id: {seat_id} has shared receivers. Unmapping receivers only.")
                    response = self._client.execute(
                        soft_delete_command_center, variable_values={"cc_id": seat_id})
                else:
                    raise ex

            if response[ROCC_DELETE_COMMAND_CENTER_SEATS][AFFECTED_ROWS] != 1:
                raise RoccException(
                    500, title=f"RoccException while offboarding command center: {seat_id}", payload="Internal server error")
            self.safe_audit(event_subtype="Offboard Command Center completed", action="D",
                            outcome=0, code="Offboard Command Center completed", value="Success")

        except RoccException as ex:
            LOG.exception(
                f"Exception while offboarding command center: {seat_id}. {ex}")
            self.safe_audit(event_subtype="Offboard Command Center", action="D",
                            outcome=8, code="Offboard Command Center", value="Error")
            raise ex
        except Exception as ex:
            LOG.exception(
                f"ROCCException while offboarding command center: {seat_id}. {ex}")
            self.safe_audit(event_subtype="Offboard Command Center", action="D",
                            outcome=8, code="Offboard Command Center", value="Error")
            raise RoccException(
                500, title=f"RoccException while updating command center: {seat_id}", payload="Internal server error") from ex

    def compute_receiver_changes(self, receivers, db_receiver_ids, db_receivers_map, seat_id):
        """
        Calculate query variables.
        Compute receivers updated_receivers,deleted_receivers,old_receiver names
        """
        updated_receivers = []
        new_receiver_mappings = []
        old_receivers_names = []
        for receiver in receivers:
            if ID in receiver and receiver[ID] in db_receiver_ids:
                # Receiver already present
                updated_receivers.append({
                    "id": receiver["id"],
                    "receiver_ip": receiver["receiver_ip"],
                    "monitor_name": receiver["monitor_name"],
                    "receiver_connection_name": receiver["receiver_connection_name"],
                    "modified_by": self._service_user_uuid
                })
                db_receiver_ids.remove(receiver[ID])
                # Check if rx name was changed
                if db_receivers_map[receiver[ID]]["receiver_connection_name"] != receiver["receiver_connection_name"]:
                    old_receivers_names.append(db_receivers_map[receiver[ID]]["receiver_connection_name"])
            else:
                # New receiver added
                new_receiver_mappings.append({
                    "command_centre_seat_id": seat_id,
                    "rocc_receiver": {
                        "data": {
                            "receiver_ip": receiver["receiver_ip"],
                            "monitor_name": receiver["monitor_name"],
                            "receiver_connection_name": receiver["receiver_connection_name"],
                            "created_by": self._service_user_uuid,
                            "modified_by": self._service_user_uuid
                        }
                    },
                    "created_by": self._service_user_uuid,
                    "modified_by": self._service_user_uuid
                })
        deleted_receivers = db_receiver_ids
        return updated_receivers, new_receiver_mappings, deleted_receivers, old_receivers_names
