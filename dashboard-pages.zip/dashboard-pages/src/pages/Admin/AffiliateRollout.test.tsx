import React from "react";
import { render, fireEvent, waitFor, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
import "@testing-library/jest-dom/extend-expect";
import AffiliateRollout from "./AffiliateRollout";
import { getAffiliateRollout, updateAffiliateRollout } from "../../redux/reducers/CommonReducer";

const mockStore = configureStore([]);

describe("AffiliateRollout component", () => {
  let store;
  beforeEach(() => {
    store = mockStore({
      Common: {
        affiliateRollout: [
          {
            affiliate: 2,
            country: 3,
            abbreviation: "SF",
            lattitude: 27.07291,
            longitude: 49.5764,
            rollout: true,
          },
          {
            affiliate: 3,
            country: 2,
            abbreviation: "MTV",
            lattitude: 37.904477936179916,
            longitude: -87.92959812869488,
            rollout: true,
          },
          {
            affiliate: 4,
            country: 3,
            abbreviation: "YA",
            lattitude: 23.988192685568624,
            longitude: 38.22259029687356,
            rollout: false,
          },
          {
            affiliate: 5,
            country: 3,
            abbreviation: "PK",
            lattitude: 49.605039,
            longitude: 27.032672,
            rollout: false,
          },
          {
            affiliate: 7,
            country: 3,
            abbreviation: "KY",
            lattitude: 27.04608942,
            longitude: 49.55082767,
            rollout: false,
          },
          {
            affiliate: 8,
            country: 3,
            abbreviation: "SQ",
            lattitude: 27.04608942,
            longitude: 49.55082767,
            rollout: false,
          },
          {
            affiliate: 9,
            country: 3,
            abbreviation: "YS",
            lattitude: 27.04608942,
            longitude: 49.55082767,
            rollout: false,
          },
        ],
        affiliateRolloutStatus: "SUCCESS",
      },
    });
    store.dispatch = jest.fn();
  });

  it("should dispatch getAffiliateRollout action on mount", () => {
    render(
      <Provider store={store}>
        <AffiliateRollout />
      </Provider>
    );
    expect(store.dispatch).toHaveBeenCalledWith(getAffiliateRollout(`18`));
  });

  it("should dispatch updateAffiliateRollout action on update button click", async () => {
    render(
      <Provider store={store}>
        <AffiliateRollout />
      </Provider>
    );

    const updateBtn = screen.getAllByText("Update")[0];
    fireEvent.click(updateBtn);
    await waitFor(() =>
      expect(store.dispatch).toHaveBeenCalledWith(
        updateAffiliateRollout(`2/false/18`)
      )
    );
  });
});
