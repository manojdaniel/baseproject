/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IParentStore } from "@rocc/rocc-client-services"
import { Form } from "formik-semantic-ui"
import React, { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Container, Grid } from "semantic-ui-react"
import GetStartedPage from "../get-started-page/GetStartedPage"
import EndForm from "../end-form/EndForm"
import WelcomeForm from "../welcome-form/WelcomeForm"
import StackableStep from "../stackable-step/StackableStep"
import styles from "./FormInvoker.scss"
import { useHistory } from "react-router"
import { getLandingPageRoute } from "../../../utility/helpers/helpers"

enum EOnBoardingSteps {
    Welcome,
    TermsConditions,
    Complete,
}

interface IForm {
    steps: any[]
    postSubmitActions: () => Promise<boolean>
    consentData: any
    isEulaRequired: boolean
}

const FormInvoker = ({ postSubmitActions, steps, consentData, isEulaRequired }: IForm) => {
    const [page, setPage] = useState(0)
    const [terms, setTerms] = useState(true)
    const [onBoardingSuccessStatus, setOnBoardingSuccessStatus] = useState(true)
    const { Welcome, TermsConditions, Complete } = EOnBoardingSteps

    const { currentUser, fseData, featureFlags } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        fseData: state.appReducer.fseData,
        featureFlags: state.featureFlagsReducer.featureFlags,
    }))

    const dispatch = useDispatch()
    const history = useHistory()

    const renderWelcome = () => {
        return <WelcomeForm
            username={currentUser.name}
            getStarted={() => next()}
        />
    }

    const renderTermsConditions = () => {
        return <EndForm
            onBoardingSuccessStatus={onBoardingSuccessStatus}
            value={!terms}
            consentData={consentData}
            getAgree={() => next()}
            getPrevious={() => prev()}
        />
    }

    const renderComplete = () => {

        return <GetStartedPage
            currentUser={currentUser}
            getFinish={handleSubmit}
        />
    }

    const handleStepper = (index: number) => {
        setPage(index)
    }
    const next = () => {
        isEulaRequired ? setPage(page + 1) : setPage(page + 2)
    }

    const prev = () => {
        setPage(page - 1)
        setOnBoardingSuccessStatus(true)
    }
    const handleSubmit = async () => {
        const result: boolean = await postSubmitActions()
        if (result) {
            setOnBoardingSuccessStatus(false)
            setTerms(true)
            getLandingPageRoute(currentUser, fseData, featureFlags, history, dispatch)
        }
    }

    return (
        <Container className={styles.onboardingPage} id={"OnboardingFormInvoker"}>
            <Form
                className={styles.forms}
                render={() => (
                    <Grid className={styles.mainGrid} padded={false}>
                        <Grid.Row centered={true} className={styles.StepsIcon}>
                            <StackableStep
                                steps={steps}
                                activePage={page}
                                onClick={(index: number) => handleStepper(index)}
                            />
                        </Grid.Row>
                        <Grid.Row
                            className={styles.contentGrid}
                            centered={true}
                            verticalAlign="middle"
                            stretched={true}
                        >

                            {page === Welcome && renderWelcome()}
                            {isEulaRequired && page === TermsConditions && renderTermsConditions()}
                            {page === Complete && renderComplete()}

                        </Grid.Row>
                    </Grid>
                )}
            />
        </Container>
    )
}

export default FormInvoker
