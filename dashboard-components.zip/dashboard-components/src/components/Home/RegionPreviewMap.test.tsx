import React from "react";
import { render, screen } from "@testing-library/react";
import RegionPreviewMap from "./RegionPreviewMap";
import "@testing-library/jest-dom/extend-expect";
import { useNavigate } from "react-router-dom";
import {
	MapContainer,
	TileLayer,
	CircleMarker,
	SVGOverlay,
} from "react-leaflet";

jest.mock("react-router-dom", () => ({
	useNavigate: jest.fn(),
}));

jest.mock("react-leaflet", () => ({
	MapContainer: jest.fn(({ children }) => <div>{children}</div>),
	TileLayer: jest.fn(),
	CircleMarker: jest.fn(),
	SVGOverlay: jest.fn(),
	Tooltip: jest.fn(),
	useMap: jest.fn(),
}));

describe("RegionPreviewMap", () => {
	const mockNavigate = jest.fn();
	let mockSelectedRegionData = [
		{
			affiliateCount: 10,
			countryId: 1,
			regionId: 1,
			name: "Test Region",
			abrv: "TR",
			latitude: 51.505,
			longitude: -0.09,
			healthIndex: 80,
			pmCompliance: 70,
			active: 5,
			overDue: 3,
			underInvestigation: 2,
		},
	];
	const mockSelectedRegion = {
		regionId: 1,
		name: "Test Region",
		abrv: "TR",
		latitude: 51.505,
		longitude: -0.09,
	};
	const mockHandleNavigation = jest.fn();

	beforeEach(() => {
		useNavigate.mockReturnValue(mockNavigate);
	});

	it("renders the map with selected region", () => {
		render(
			<RegionPreviewMap
				getSelectedRegion={mockSelectedRegion}
				getSelectedRegionData={mockSelectedRegionData}
				handleNavigation={mockHandleNavigation}
			/>
		);

		expect(MapContainer).toHaveBeenCalled();
		expect(TileLayer).toHaveBeenCalled();
		expect(CircleMarker).toHaveBeenCalled();
		expect(SVGOverlay).toHaveBeenCalled();

		expect(screen.getByText(mockSelectedRegion.name)).toBeInTheDocument();
		expect(screen.getByText("Affiliate Count: 10")).toBeInTheDocument();
	});

	it("calls handleNavigation when a CircleMarker is clicked", () => {
		render(
			<RegionPreviewMap
				getSelectedRegion={mockSelectedRegion}
				getSelectedRegionData={mockSelectedRegionData}
				handleNavigation={mockHandleNavigation}
			/>
		);

		const circleMarker = screen.getByTitle(mockSelectedRegion.name);
		circleMarker.click();
		expect(mockHandleNavigation).toHaveBeenCalledWith({
			value: mockSelectedRegion.regionId,
			label: mockSelectedRegion.name,
		});
	});
});
