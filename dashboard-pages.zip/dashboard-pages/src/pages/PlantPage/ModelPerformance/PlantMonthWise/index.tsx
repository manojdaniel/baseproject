import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import MonthWiseTable from "table/MonthWiseTable";
import MonthWiseChart from "charts/MonthWiseChart";
import {
    getplantmodelbasedtabledatabyplant,
    getplantmonthwisebarchartdata,
} from "../../../../redux/reducers/CommonReducer";
// import { monthwisebarchartTransformer } from "../../../../utility/transformer/MonthWiseBarchartTransformers";
import "./MonthWiseChart.scss";
import moment from "moment";
import NoData from "components/NoData";
import { encryptRSAData } from "../../../../utility/rsa";
import Loader from "components/Loader";

interface Props {
    buttonName: string;
    onClickHandler: any;
}
const PlantMonthWise = () => {
    let dispatch = useDispatch();
    //const [assetChartBarData, setAssetChartBarData] = useState<any>([]);
    const {
        plantmodelbasedtabledatabyplant,
        plantmonthwisebarchartdata,
        modelPerformanceAssetDropdownChangedValue,
        globalSelecetedPlant,
        selectedBreadCrumbDate,
        breadCrumbDateFormated,
        breadCrumbDate,
        commonToDate,
        commonFromDate,
        commonFromDateFormat,
        commonToDateFormat,
        loadingplantmonthwisebarchartdata,
        loadingplantmodelbasedtabledatabyplant,
    } = useSelector((state: any) => ({
        plantmodelbasedtabledatabyplant:
            state.Common.plantmodelbasedtabledatabyplant,
        plantmonthwisebarchartdata: state.Common.plantmonthwisebarchartdata,
        modelPerformanceAssetDropdownChangedValue:
            state.Common.modelPerformanceAssetDropdownChangedValue,
        globalSelecetedPlant: state.Common.globalSelecetedPlant,

        commonFromDateFormat: state.Common.commonFromDateFormat,
        commonToDateFormat: state.Common.commonToDateFormat,
        commonToDate: state.Common.commonToDate,
        commonFromDate: state.Common.commonFromDate,

        selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
        breadCrumbDate: state.Common.breadCrumbDate,
        breadCrumbDateFormated: state.Common.breadCrumbDateFormated,
        loadingplantmonthwisebarchartdata: state.Common.loadingplantmonthwisebarchartdata,
        loadingplantmodelbasedtabledatabyplant: state.Common.loadingplantmodelbasedtabledatabyplant,
    }));

    useEffect(() => {
        let today = moment(new Date()).format("YYYY-MM-DD");
        if (breadCrumbDateFormated !== "" && breadCrumbDateFormated !== undefined) {
            if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
                if (modelPerformanceAssetDropdownChangedValue.label === "All") {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                } else {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=0&assetId=${globalSelecetedPlant.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                }
            } else {
                if (Object.keys(globalSelecetedPlant).length > 0) {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${breadCrumbDateFormated}&toDate=${today}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                }
            }
        }
    }, [breadCrumbDateFormated, modelPerformanceAssetDropdownChangedValue]);

    useEffect(() => {
        if (
            commonToDateFormat !== "" &&
            commonToDateFormat !== undefined &&
            commonFromDateFormat !== "Invalide date"
        ) {
            if (Object.keys(modelPerformanceAssetDropdownChangedValue).length > 0) {
                if (modelPerformanceAssetDropdownChangedValue.label === "All") {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                } else {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=0&assetId=${modelPerformanceAssetDropdownChangedValue.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                }
            } else {
                if (Object.keys(globalSelecetedPlant).length > 0) {
                    dispatch(
                        getplantmodelbasedtabledatabyplant(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                    dispatch(
                        getplantmonthwisebarchartdata(
                            encryptRSAData(
                                `plantId=${globalSelecetedPlant.value}&assetId=0&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
                            )
                        )
                    ); //{plantId}/{asset Id}/{userid}
                }
            }
        }
    }, [modelPerformanceAssetDropdownChangedValue, commonToDateFormat]);

    return (
        <div id="pmbb">
            <div className="pmw-box">
                <div className="common-box-inner">
                    <div className="common-box-filter">
                        <div className="title">PLANT MODEL BASE</div>
                    </div>
                    <div className="common-box-content">
                        {loadingplantmodelbasedtabledatabyplant ? (
                            <div className="tc-loaderpd">
                                <Loader />
                            </div>
                        ) : (
                            <MonthWiseTable data={plantmodelbasedtabledatabyplant} />
                        )}
                    </div>
                </div>
            </div>
            <div className="pmw-box">
                <div className="common-box-inner">
                    <div className="common-box-filter">
                        <div className="title">MONTHWISE</div>
                    </div>
                    <div className="common-box-content">
                        <div id="pmw-chart">
                            <div className="pmw-chart-left">
                                <div className="pmw-plot-list">
                                    <div>
                                        <span style={{ background: "#E35205" }}></span>
                                        <span>False Positive</span>
                                    </div>
                                    <div>
                                        <span style={{ background: "#3BB44A" }}></span>
                                        <span>True Positive</span>
                                    </div>
                                    <div>
                                        <span style={{ background: "#929292" }}></span>
                                        <span>Unclassified</span>
                                    </div>
                                </div>
                            </div>
                            <div className="pmw-chart-right">
                                {loadingplantmonthwisebarchartdata ? (
                                    <div className="tc-loaderpd">
                                        <Loader />
                                    </div>
                                ) : plantmonthwisebarchartdata.length === 0 ? (
                                    <div className="tc-loaderpd">
                                        <NoData />
                                    </div>
                                ) : (
                                    <MonthWiseChart data={plantmonthwisebarchartdata} />
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div></div>
        </div>
    );
};

export default PlantMonthWise;