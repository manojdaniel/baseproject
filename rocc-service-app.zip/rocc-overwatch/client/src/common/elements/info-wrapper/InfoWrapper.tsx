/*
 * Created on Wed Dec 9 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Popup, Icon } from "semantic-ui-react"


const InfoWrapper = (element: any, infoContent: any) => {
    return <>{element} <Popup
    id={"InfoWrapper"}
    trigger={<Icon className="InformationCircle" style={{ fontSize: "1rem", marginLeft: "8px" }} />}
    position="right center"
    inverted
  >
    <Popup.Content>
      {infoContent}
    </Popup.Content>
  </Popup>
  </>
}

export default InfoWrapper
