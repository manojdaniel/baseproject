import React, { useRef, useState, useEffect } from "react";
import "./CalendarComponet.scss";
import iconCalendar from "../../assets/images/icon_calendar.svg";
import CalendarPopup from "../CalendarPopup";
import { useDispatch, useSelector } from "react-redux";
import {
	getBreadCrumbDate,
	getTodayDate,
} from "../../redux/reducers/CommonReducer";
import useOnClickOutside from "../../hooks/useOnClickOutside";

const CalendarComponent = () => {
	let dispatch = useDispatch();

	// Create a ref that we add to the element for which we want to detect outside clicks
	const ref = useRef(null);
	// State for our modal
	const [showPicker, setShowPicker] = useState(false);
	// Call hook passing in the ref and a function to call on outside click
	useOnClickOutside(ref, () => setShowPicker(false));

	let date = new Date();

	useEffect(() => {
		dispatch(getTodayDate(date));
	}, []);

	const dateFilterList = [
		{ id: "1D", value: "1D" },
		// { id: "1W", value: "1W" },
		{ id: "1M", value: "1M" },
		{ id: "3M", value: "3M" },
		{ id: "1Y", value: "1Y" },
		{ id: "5Y", value: "5Y" },
	];

	const {
		commonFromDateFormat,
		commonToDateFormat,
		selectedBreadCrumbDate,
		todayDate,
	} = useSelector((state: any) => ({
		commonFromDate: state.Common.commonFromDate,
		commonToDate: state.Common.commonToDate,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,

		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
		todayDate: state.Common.todayDate,
	}));

	const onClickDate = (id: any) => {
		const currentdate = new Date();
		let updatedDate: any;
		const dayFilter = id;

		if (dayFilter === "1D") {
			updatedDate = new Date(currentdate.setDate(currentdate.getDate() - 1));
			// } else if (dayFilter === "1W") {

			// 	updatedDate = new Date(currentdate.getTime() - 6 * 24 * 60 * 60 * 1000);
		} else if (dayFilter === "1M") {
			updatedDate = new Date(currentdate.setMonth(currentdate.getMonth() - 1));
		} else if (dayFilter === "3M") {
			updatedDate = new Date(currentdate.setMonth(currentdate.getMonth() - 3));
		} else if (dayFilter === "1Y") {
			updatedDate = new Date(
				currentdate.setFullYear(currentdate.getFullYear() - 1)
			);
		} else if (dayFilter === "5Y") {
			updatedDate = new Date(
				currentdate.setFullYear(currentdate.getFullYear() - 5)
			);
		}
		dispatch(getBreadCrumbDate({ id, updatedDate }));
		dispatch(getTodayDate(date));
	};

	const getSelectedclassName = (id: any) =>
		selectedBreadCrumbDate === id ? "active" : "notselected";

	return (
		<div className="breadcrumb-right">
			<div id="calendar" ref={ref}>
				<a className="customdate" onClick={() => setShowPicker(!showPicker)}>
					<span>Today:</span>
					{todayDate === "" ? (
						<span className="calen-date">
							{commonFromDateFormat} &nbsp;&nbsp;&nbsp; {commonToDateFormat}
						</span>
					) : (
						<span className="calen-date">{todayDate}</span>
					)}
					<span className="calen-icon">
						<img src={iconCalendar} title="calendar" />
					</span>
				</a>
				{dateFilterList &&
					dateFilterList.map((item, index) => (
						<a
							className={`custom ${getSelectedclassName(item.id)}`}
							key={index}
							onClick={() => onClickDate(item.id)}
						>
							{item.value}
						</a>
					))}
				<a className="mobile-calendar">
					<img src={iconCalendar} title="calendar" />
				</a>
				{showPicker ? <CalendarPopup title={"common"} /> : null}
			</div>
		</div>
	);
};

export default CalendarComponent;
