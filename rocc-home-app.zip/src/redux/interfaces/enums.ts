/*
 * Created on Mon Sep 27 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

export enum EResponse {
    INIT = "INIT",
    SUCCESS = "SUCCESS",
    ERROR = "ERROR",
    TIMEOUT = "TIMEOUT",
    DEFAULT = "DEFAULT",
}

export enum EFetchStatus {
    success = "success",
    failed = "failed",
    inProgress = "inProgress",
    notStarted = "notStarted",
}

export enum EUserPresence {
    AVAILABLE = "AVAILABLE",
    BUSY = "BUSY",
    IN_CALL = "IN_CALL",
    DND = "DND",
    OFFWORK = "OFFWORK",
    AWAY = "AWAY",
    OFFLINE = "OFFLINE"
}

export enum EConnectionState {
    DEFAULT = "DEFAULT",
    REQUESTED = "REQUESTED",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    CONNECTING = "CONNECTING",
    CONNECTED = "CONNECTED",
    CONSOLE_CLOSE = "CONSOLE_CLOSE",
    DISCONNECTING = "DISCONNECTING",
    DISCONNECTED = "DISCONNECTED",
    FORCE_CONSOLE_CLOSE = "FORCE_CONSOLE_CLOSE",
    FORCE_EDIT_CONSOLE_CLOSE = "FORCE_EDIT_CONSOLE_CLOSE",
    DEVICE_CONSOLE_DISCONNECT = "DEVICE_CONSOLE_DISCONNECT",
    FAILED = "FAILED",
    CANCELLED = "CANCELLED",
    TIMEOUT = "TIMEOUT",
    DISCONNECTFAILURE = "DISCONNECTFAILURE",
    ASSOCIATE_INITIATED = "ASSOCIATE_INITIATED",
    ASSOCIATE_COMPLETED = "ASSOCIATE_COMPLETED"
}

export enum EProtocolTransferSteps {
    SelectSourceScanner = 1,
    ConnectToSourceScanner,
    SelectDestinationScanner,
    ConnectToDestinationScanner,
    CompletionStep
}
export enum EAppUriValue {
    START_EMERALD_APP = "START_EMERALD_APP",
    STOP_EMERALD_APP = "STOP_EMERALD_APP",
    RESTART_EMERALD_APP = "RESTART_EMERALD_APP",
}
export enum EDefaultTransactionValue {
    CONNECTING = "CONNECTING",
    DISCONNECTING = "DISCONNECTING",
    ASSOCIATE_COMPLETED = "ASSOCIATE_COMPLETED"
}
export type EConnectionStatus = EConnectionState | EAppUriValue | EDefaultTransactionValue

export const  EConnectionStatus = { ...EConnectionState , ...EAppUriValue , ...EDefaultTransactionValue}
