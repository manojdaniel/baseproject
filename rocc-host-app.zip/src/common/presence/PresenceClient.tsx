/*
 * Created on Tue Oct 16 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionStatus, EResponse, IParentStore } from "@rocc/rocc-client-services"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { ConnectionState, SyncClient } from "twilio-sync"
import { isEmptyObject } from "../../utility/helpers/helpers"
import { fetchCommunicationClientDetails } from "./presenceService"
import { SetupPresenceSubscriptions } from "./SetupPresenceSubscriptions"

const PresenceClient = () => {

    const [syncClient, setSyncClient] = useState({} as SyncClient)
    const [componentMounted, setComponentMounted] = useState(false)


    const { currentUser, COMMUNICATION_SERVICES_URL, forceCleanUp, applicationConnectionState } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        forceCleanUp: state.userReducer.forceCleanUp,
        COMMUNICATION_SERVICES_URL: state.configReducer.urls.COMMUNICATION_SERVICES_URL,
        applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
    }))

    const userTokenRef = useRef(currentUser.accessToken)
    const syncClientRef = useRef(syncClient)

    const createRoccSyncClient = async (userToken?: string) => {
        const { status, tokenDetails } = await fetchCommunicationClientDetails(
            COMMUNICATION_SERVICES_URL, userToken ?? userTokenRef.current, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            /* Fetch Sync client */
            const roccSyncClient = new SyncClient(tokenDetails.communicationToken)
            setSyncClient(roccSyncClient)
            setupSyncClient(roccSyncClient)
        }
        if (!componentMounted) {
            setComponentMounted(true)
        }
    }

    const setupSyncClient = (syncClient: SyncClient) => {
        syncClient.on("tokenAboutToExpire", updateToken)
        syncClient.on("tokenExpired", updateToken)
        syncClient.on("connectionStateChanged", connectionStateChanged)
        infoLogger(`Sync client creation is successful...`)
    }

    const updateToken = async () => {
        const { status, tokenDetails } = await fetchCommunicationClientDetails(
            COMMUNICATION_SERVICES_URL, userTokenRef.current, currentUser.uuid)
        if (status === EResponse.SUCCESS) {
            if (!isEmptyObject(syncClientRef.current)) {
                infoLogger(`Existing Communication client is updated with new token`)
                syncClientRef.current.updateToken(tokenDetails.communicationToken)
            } else {
                infoLogger(`Communication client is re-created for user ${currentUser.uuid}`)
                createRoccSyncClient()
            }
        }
    }

    const connectionStateChanged = (newState: ConnectionState) => {
        if (componentMounted) {
            if (newState === "denied") {
                errorLogger(`SyncClient is disconnected, trying to reconnect for user ${currentUser.uuid}`)
                if (!isEmptyObject(syncClientRef.current)) { syncClientRef.current.shutdown() }
                createRoccSyncClient()
            }
        }
    }

    const cleanUpTasks = () => {
        if (!isEmptyObject(syncClientRef.current)) {
            infoLogger(`Close presence client for user ${currentUser.uuid}`)
            syncClientRef.current.removeAllListeners()
            syncClientRef.current.shutdown()
            setSyncClient({} as SyncClient)
        } else {
            infoLogger(`Couldn't close presence client since it is already closed`)
        }
    }

    useEffect(() => {
        return () => {
            cleanUpTasks()
        }
    }, [])
    useEffect(() => { syncClientRef.current = syncClient }, [syncClient])
    useEffect(() => { userTokenRef.current = currentUser.accessToken }, [currentUser.accessToken])

    useEffect(() => {
        const { accessToken, uuid } = currentUser
        if (forceCleanUp || applicationConnectionState === EConnectionStatus.OFFLINE) {
            infoLogger(`ForceCleanUp is set to true, cleaning up Sync client for user ${uuid}`)
            cleanUpTasks()
        } else {
            if (accessToken) {
                infoLogger(`Initializing Sync client for Rocc application for user ${uuid}`)
                cleanUpTasks()
                createRoccSyncClient(accessToken)
            }
        }
    }, [forceCleanUp, applicationConnectionState])

    if (!isEmptyObject(syncClientRef.current)) {
        return <SetupPresenceSubscriptions syncClient={syncClient} />
    }
    return <></>

}

export default PresenceClient
