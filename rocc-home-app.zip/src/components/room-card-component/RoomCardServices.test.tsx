/*
 * Created on Tue Oct 5 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as services from "./RoomCardServices"
import * as apiUtiltiy from "../../common/helpers/apicall"

jest.mock("../../common/helpers/apicall", () => ({
    postService: jest.fn()
}))
const mockResponse : any = {
    data: {},
    status: 200,
    headers: [],
    statusText: "",
    config: {}
}

describe("Room card services", () => {
    const postCallMock = jest.spyOn(apiUtiltiy, "postService")
    afterEach(() => {
        jest.clearAllMocks()
    })
    it("post service success", async () => {
        postCallMock.mockResolvedValue(mockResponse)
        const res = await services.setStarredRoom({ roomId: 1, adminServiceUrl: "abc", metasiteId: 1, isRoomStarred: false, userId: 2, token: "abc" })
        expect(res).toBeTruthy()
    })
    it("post service failure", async () => {
        postCallMock.mockRejectedValue(new Error())
        expect(await services.setStarredRoom({ roomId: 1, adminServiceUrl: "abc", metasiteId: 1, isRoomStarred: false, userId: 2, token: "abc" })).toBeDefined()
    })
})
