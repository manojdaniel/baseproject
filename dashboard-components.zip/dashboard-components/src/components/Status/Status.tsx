import React, { useState } from "react";
import "./Status.scss";

import iconAffiliates from "../../assets/images/icon_Affiliates.svg";
import iconAssets from "../../assets/images/icon_Assets.svg";
import iconHealthIndex from "../../assets/images/icon_Health_Index.svg";
import iconProfile from "../../assets/images/icon_PM_Compliance.svg";
import imagePMCompliance from "../../assets/images/icon_Spares_Availability.svg";
import imageActive from "../../assets/images/icon_Active.svg";
import imageOverdue from "../../assets/images/icon_Overdue.svg";
import imageUnderInvestigate from "../../assets/images/icon_Under_Investigate.svg";
import icon_health_index_up_arrow from "../../assets/images/icon_health_index_up_arrow.svg";
import icon_health_index_down_arrow from "../../assets/images/icon_health_index_down_arrow.svg";
import icon_health_index_circle from "../../assets/images/icon_healthindex_circle.svg";
import status_Arrow_up_red from "../../assets/images/status_Arrow_up_red.svg";
import status_Arrow_down_red from "../../assets/images/status_Arrow_down_red.svg";
import status_Arrow_up_blue from "../../assets/images/status_Arrow_up_blue.svg";
import status_Arrow_down_blue from "../../assets/images/status_Arrow_down_blue.svg";
import { useNavigate } from "react-router-dom";

interface Props {
  data: any[];
  page: string;
  healthIndexToolTip: any[];
  goAssetModelPageFromPMTStatus: any;
  navigateActiveUIOIPMT: any;
  navigateActiveUIOIAllPlant: any;
}

const Status = ({ data, page, healthIndexToolTip, goAssetModelPageFromPMTStatus, navigateActiveUIOIPMT, navigateActiveUIOIAllPlant }: Props) => {
  const [mouseHoverTooltip, setMouseHoverTooltip] = useState<any>(false);
  const [mouseHoverTooltipAsset, setmouseHoverTooltipAsset] = useState<any>(false);
  const [mouseHoverActiveTooltip, setMouseHoverActiveTooltip] = useState<any>(false);
  const [mouseHoverUnderInvTooltip, setMouseHoverUnderInvTooltip] = useState<any>(false);
  const [mouseHoverOverdueInvTooltip, setMouseHoverOverdueInvTooltip] = useState<any>(false);

  let navigate = useNavigate();

  const navigatePMCompliance = (data: any) => {
    navigate('/plant/pmCompliance');
  }

  const navigatePMTtoSpares = (data: any) => {
    navigate('/assets/spareParts');
  }

  const navigatePMTtoAffiliates = (data: any) => {
    navigate('/affiliates');
  }

  return (
    <>
      {page === "PLANT" ? (
        <>
          {data && data.length > 0 ? (
            <div id="status">
              <div className="common">
                <div onClick={() => navigatePMTtoAffiliates(data[0].affiliateCount)} style={{ cursor: "pointer" }}>
                  <div>
                    <img src={iconAffiliates} title="Affiliates" />
                  </div>
                  <div>
                    <span id="value">{data[0].affiliateCount}</span>
                    <span>AFFILIATES</span>
                  </div>
                </div>
                <div className="status-asset-box"
                  onMouseOver={() => setmouseHoverTooltipAsset(true)}
                  onMouseLeave={() => setmouseHoverTooltipAsset(false)}
                  style={{ cursor: "pointer" }}
                >
                  <div>
                    <img src={iconAssets} title="Assets" />
                  </div>
                  <div>
                    <span id="value2">{data[0].assetCount}</span>
                    <span>ASSETS</span>
                  </div>
                  {mouseHoverTooltipAsset === true ? (
                    <div className="status-tooltip singletlp">
                      <div className="status-tooltip-head"><span style={{flexBasis:'100%'}}>{data[0].assetCount} ASSETS</span></div>
                      <div className="status-tooltip-box">
                        {healthIndexToolTip.map((item) => (
                          <div className="status-single singletlp1">
                            <span onClick={() => goAssetModelPageFromPMTStatus(item.assetId)}>{item.assetId}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div className="status-health-box"
                  onMouseOver={() => setMouseHoverTooltip(true)}
                  onMouseLeave={() => setMouseHoverTooltip(false)}
                >
                  <div className="arrowbox1">
                    <img src={iconHealthIndex} title="Health_Index" />
                  </div>
                  <div className="arrowbox2">
                    {data[0].healthTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].healthTrend === true || data[0].healthTrend === 1 || data[0].alertTrend === "1" ? (
                      <img src={status_Arrow_up_blue} />
                    ) : (
                      <img src={status_Arrow_down_blue} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span>{data[0].healthIndex}%</span>
                    <span>HEALTH INDEX</span>
                  </div>
                  {mouseHoverTooltip === true ? (
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span>HEALTH INDEX</span>
                        <span>
                          <i>
                            {healthIndexToolTip[0].plantTrend === null ? (
                              <img src={icon_health_index_circle} />
                            ) : healthIndexToolTip[0].plantTrend === 1 || healthIndexToolTip[0].plantTrend === true ? (
                              <img src={icon_health_index_up_arrow} />
                            ) : (
                              <img src={icon_health_index_down_arrow} />
                            )}
                          </i>
                          {healthIndexToolTip[0].plantHealth}%
                        </span>
                      </div>
                      <div className="status-tooltip-box">
                        {healthIndexToolTip.map((item) => (
                          <div className="status-tooltiprow" onClick={() => goAssetModelPageFromPMTStatus(item.assetId)} style={{ cursor: "pointer" }}>
                            <span>{item.assetId}</span>
                            <span className="st-u">
                              <i>
                                {item.assetTrend === null ? (
                                  <img src={icon_health_index_circle} />
                                ) : item.assetTrend === 0 || item.assetTrend === false ? (
                                  <img src={icon_health_index_down_arrow} />
                                ) : (
                                  <img src={icon_health_index_up_arrow} />
                                )}
                              </i>
                              {
                                item.assetHealthIndex !== null ?
                                  <>{item.assetHealthIndex}%</>
                                  : "N/A"
                              }

                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div onClick={() => navigatePMCompliance(data[0].pmCompliance)} style={{ cursor: "pointer" }}>
                  <div>
                    <img src={iconProfile} title="PM_Compliance" />
                  </div>
                  <div>
                    <span id="value4">
                      {data[0].pmCompliance} %
                      <i> PM</i>
                    </span>
                    <span>COMPLIANCE</span>
                  </div>
                </div>
                {/* // onClick={() => navigatePMTtoSpares(data[0].spare)} */}
                <div>
                  <div>
                    <img src={imagePMCompliance} title="Spares_Availability" />
                  </div>
                  <div>
                    <span id="value4">
                      {data[0].spare} <i>SPARES</i>
                    </span>
                    <span>AVAILABILITY</span>
                  </div>
                </div>
                <div 
                  onClick={() => navigateActiveUIOIPMT("Active")} 
                  style={{ cursor: "pointer" }}
                  onMouseOver={() => setMouseHoverActiveTooltip(true)}
                  onMouseLeave={() => setMouseHoverActiveTooltip(false)}
                >
                  <div>
                    <img src={imageActive} title="Active" />
                  </div>
                  <div>
                    <span
                      id="value2" style={{ color: "#E35205" }} >
                      {data[0].active}
                    </span>
                    <span>ACTIVE</span>
                  </div>
                  {mouseHoverActiveTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Active</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                         The total number of overdue and under investigation alerts
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div 
                  onClick={() => navigateActiveUIOIPMT("Work in Progress")} 
                  style={{ cursor: "pointer" }}
                  onMouseOver={() => setMouseHoverUnderInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverUnderInvTooltip(false)}
                >
                  <div>
                    <img
                      src={imageUnderInvestigate}
                      title="Under_Investigate"
                    />
                  </div>
                  <div>
                    <span id="value2">
                      {data[0].underInvestigation}
                      <i> UNDER</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverUnderInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Under Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                           Alerts under investigation are alerts that are not assigned by site Digitalization champion for less than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for less than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div className="overdue-status-invest"
                  onClick={() => navigateActiveUIOIPMT("Overdue")} 
                  style={{ cursor: "pointer" }}
                  onMouseOver={() => setMouseHoverOverdueInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverOverdueInvTooltip(false)}
                >
                  <div className="arrowbox1">
                    <img src={imageOverdue} title="Overdue_Investigate" />
                  </div>
                  <div className="arrowbox2">
                    {data[0].alertTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].alertTrend === true || data[0].alertTrend === 1 || data[0].alertTrend === "1" ? (
                      <img src={status_Arrow_up_red} />
                    ) : (
                      <img src={status_Arrow_down_red} title="Arrow Down" />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span id="value2" style={{ color: "#E35205" }}>
                      {" "}
                      {data[0].overdueInvestigation}
                      <i> OVERDUE</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverOverdueInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Overdue Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                          Overdue alerts are alerts that are not assigned by site Digitalization champion for more than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for more than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : null}

      {page === "HOME" ? (
        <>
          {data && data.length > 0 ? (
            <div id="status">
              <div className="common">
                <div>
                  <div><img src={iconAffiliates} title="Affiliates" /></div>
                  <div>
                    <span id="value">{data[0].affiliateCount}</span>
                    <span>AFFILIATES</span>
                  </div>
                </div>
                <div>
                  <div><img src={iconAssets} title="Assets" /></div>
                  <div>
                    <span id="value2">{data[0].assetCount}</span>
                    <span>ASSETS</span>
                  </div>
                </div>
                <div className="status-health-box"
                  onMouseOver={() => setMouseHoverTooltip(true)}
                  onMouseLeave={() => setMouseHoverTooltip(false)}
                >
                  <div className="arrowbox1"><img src={iconHealthIndex} title="Health_Index" /></div>
                  <div className="arrowbox2">
                    {data[0].healthTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].healthTrend === true || data[0].healthTrend === 1 ? (
                      <img src={status_Arrow_up_blue} />
                    ) : (
                      <img src={status_Arrow_down_blue} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span>{data[0].healthIndex}</span>
                    <span>HEALTH INDEX</span>
                  </div>
                  {mouseHoverTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title jcc">What is Health Index</span>
                      </div>
                      <div className="status-tooltip-box ha notolheight">
                        <div className="status-tooltiprow">
                         The health index is an indicative value of the assets healthiness covered by the AHC. It is a calculated value based on the anomaly detection algorithm output. It is to bring focus on assets deviating from optimal operation
                        </div>
                      </div>
                    </div>
                    :
                    ""
                  }
                </div>
                <div>
                  <div><img src={iconProfile} title="PM_Compliance" /></div>
                  <div>
                    <span id="value4">
                      {data[0].pmCompliance}
                      <i> PM</i>
                    </span>
                    <span>COMPLIANCE</span>
                  </div>
                </div>
                <div>
                  <div><img src={imagePMCompliance} title="Spares_Availability" /></div>
                  <div>
                    <span id="value4">
                      {data[0].sparesAvailability} <i>SPARES</i>
                    </span>
                    <span>AVAILABILITY</span>
                  </div>
                </div>
                <div
                  onMouseOver={() => setMouseHoverActiveTooltip(true)}
                  onMouseLeave={() => setMouseHoverActiveTooltip(false)}
                >
                  <div><img src={imageActive} title="Active" /></div>
                  <div>
                    <span id="value2" style={{ color: "#E35205" }}>
                      {data[0].activeCount}
                    </span>
                    <span>ACTIVE</span>
                  </div>
                  {mouseHoverActiveTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Active</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                         The total number of overdue and under investigation alerts
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div
                  onMouseOver={() => setMouseHoverUnderInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverUnderInvTooltip(false)}
                >
                  <div><img src={imageUnderInvestigate} title="Under_Investigate" /></div>
                  <div>
                    <span id="value2">
                      <i>{data[0].underInvestigationCount}</i>
                      <i> UNDER</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverUnderInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Under Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                           Alerts under investigation are alerts that are not assigned by site Digitalization champion for less than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for less than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div className="overdue-status-invest"
                  onMouseOver={() => setMouseHoverOverdueInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverOverdueInvTooltip(false)}
                >
                  <div className="arrowbox1"><img src={imageOverdue} title="Overdue_Investigate" /></div>
                  <div className="arrowbox2">
                    {data[0].alertTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].alertTrend === true || data[0].alertTrend === 1 ? (
                      <img src={status_Arrow_up_red} />
                    ) : (
                      <img src={status_Arrow_down_red} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span id="value2" style={{ color: "#E35205" }}>
                      {" "}
                      <i style={{ color: "#E35205" }}>{data[0].overdueInvestigationCount}</i>
                      <i> OVERDUE</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverOverdueInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Overdue Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                          Overdue alerts are alerts that are not assigned by site Digitalization champion for more than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for more than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : null}

      {page === "AFFILIATE" ? (
        <>
          {data && data.length > 0 ? (
            <div id="status">
              <div className="common">
                <div>
                  <div><img src={iconAffiliates} title="Affiliates" /></div>
                  <div>
                    <span id="value">{data[0].affiliateCount}</span>
                    <span>AFFILIATES</span>
                  </div>
                </div>
                <div>
                  <div><img src={iconAssets} title="Assets" /></div>
                  <div>
                    <span id="value2">{data[0].assetCount}</span>
                    <span>ASSETS</span>
                  </div>
                </div>
                <div className="status-health-box"
                  onMouseOver={() => setMouseHoverTooltip(true)}
                  onMouseLeave={() => setMouseHoverTooltip(false)}
                >
                  <div className="arrowbox1"><img src={iconHealthIndex} title="Health_Index" /></div>
                  <div className="arrowbox2">
                    {data[0].healthTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].healthTrend === 1 || data[0].healthTrend === true ? (
                      <img src={status_Arrow_up_blue} />
                    ) : (
                      <img src={status_Arrow_down_blue} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span>{data[0].healthIndex}</span>
                    <span>HEALTH INDEX</span>
                  </div>
                  {mouseHoverTooltip === true ? (
                    <div className="status-tooltip">
                      <div className="status-tooltip-head sct">
                        <span className="status-title">What is Health Index</span>
                      </div>
                      <div className="status-tooltip-box ha notolheight">
                        <div className="status-tooltiprow">
                           The health index is an indicative value of the assets healthiness covered by the AHC. It is a calculated value based on the anomaly detection algorithm output. It is to bring focus on assets deviating from optimal operation
                        </div>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div>
                  <div><img src={iconProfile} title="PM_Compliance" /></div>
                  <div>
                    <span id="value4">
                      {data[0].pmCompliance}
                      <i> PM</i>
                    </span>
                    <span>COMPLIANCE</span>
                  </div>
                </div>
                <div>
                  <div><img src={imagePMCompliance} title="Spares_Availability" /></div>
                  <div>
                    <span id="value4">
                      {data[0].sparesAvailability} <i>SPARES</i>
                    </span>
                    <span>AVAILABILITY</span>
                  </div>
                </div>
                <div
                  onMouseOver={() => setMouseHoverActiveTooltip(true)}
                  onMouseLeave={() => setMouseHoverActiveTooltip(false)}
                >
                  <div><img src={imageActive} title="Active" /></div>
                  <div>
                    <span id="value2" style={{ color: "#E35205" }}>
                      {data[0].activeCount}
                    </span>
                    <span>ACTIVE</span>
                  </div>
                  {mouseHoverActiveTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Active</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                         The total number of overdue and under investigation alerts
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div
                  onMouseOver={() => setMouseHoverUnderInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverUnderInvTooltip(false)}
                >
                  <div><img src={imageUnderInvestigate} title="Under_Investigate" /></div>
                  <div>
                    <span id="value2">
                      <i>{data[0].underInvestigationCount}</i>
                      <i> UNDER</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverUnderInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Under Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                           Alerts under investigation are alerts that are not assigned by site Digitalization champion for less than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for less than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div className="overdue-status-invest"
                  onMouseOver={() => setMouseHoverOverdueInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverOverdueInvTooltip(false)}
                >
                  <div className="arrowbox1"><img src={imageOverdue} title="Overdue_Investigate" /></div>
                  <div className="arrowbox2">
                    {data[0].alertTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].alertTrend === true || data[0].alertTrend === 1 ? (
                      <img src={status_Arrow_up_red} />
                    ) : (
                      <img src={status_Arrow_down_red} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span id="value2" style={{ color: "#E35205" }}>
                      {" "}
                      <i style={{ color: "#E35205" }}>{data[0].overdueInvestigationCount}</i>
                      <i> OVERDUE</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverOverdueInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Overdue Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                          Overdue alerts are alerts that are not assigned by site Digitalization champion for more than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for more than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : null}

      {page === "ALLPLANT" ? (
        <>
          {data && data.length > 0 ? (
            <div id="status">
              <div className="common">
                <div>
                  <div><img src={iconAffiliates} title="Affiliates" /></div>
                  <div>
                    <span id="value">{data[0].affiliateCount}</span>
                    <span>AFFILIATES</span>
                  </div>
                </div>
                <div>
                  <div><img src={iconAssets} title="Assets" /></div>
                  <div>
                    <span id="value2">{data[0].assetCount}</span>
                    <span>ASSETS</span>
                  </div>
                </div>
                <div className="status-health-box"
                  onMouseOver={() => setMouseHoverTooltip(true)}
                  onMouseLeave={() => setMouseHoverTooltip(false)}
                  >
                  <div className="arrowbox1">
                    <img src={iconHealthIndex} title="Health_Index" />
                  </div>
                  <div className="arrowbox2">
                    {data[0].healthTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].healthTrend === true || data[0].healthTrend === 1 ? (
                      <img src={status_Arrow_up_blue} />
                    ) : (
                      <img src={status_Arrow_down_blue} />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span>{data[0].healthIndex}</span>
                    <span>HEALTH INDEX</span>
                  </div>
                  {mouseHoverTooltip === true ? (
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title jcc">What is Health Index</span>
                      </div>
                      <div className="status-tooltip-box ha notolheight">
                        <div className="status-tooltiprow">
                          The health index is an indicative value of the assets healthiness covered by the AHC. It is a calculated value based on the anomaly detection algorithm output. It is to bring focus on assets deviating from optimal operation
                        </div>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div>
                  <div><img src={iconProfile} title="PM_Compliance" /></div>
                  <div>
                    <span id="value4">
                      {data[0].pmCompliance}
                      <i> PM</i>
                    </span>
                    <span>COMPLIANCE</span>
                  </div>
                </div>
                <div>
                  <div><img src={imagePMCompliance} title="Spares_Availability" /></div>
                  <div>
                    <span id="value4">
                      {data[0].sparesAvailability} <i>SPARES</i>
                    </span>
                    <span>AVAILABILITY</span>
                  </div>
                </div>
                <div
                  onMouseOver={() => setMouseHoverActiveTooltip(true)}
                  onMouseLeave={() => setMouseHoverActiveTooltip(false)}
                >
                  <div><img src={imageActive} title="Active" /></div>
                  <div>
                    <span id="value2" style={{ color: "#E35205" }}>{data[0].active}</span>
                    <span>ACTIVE</span>
                  </div>
                  {mouseHoverActiveTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Active</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                         The total number of overdue and under investigation alerts
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div
                  onMouseOver={() => setMouseHoverUnderInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverUnderInvTooltip(false)}
                >
                  <div><img src={imageUnderInvestigate} title="Under_Investigate" />
                  </div>
                  <div>
                    <span id="value2">
                      <i>{data[0].underInvestigation}</i>
                      <i> UNDER</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverUnderInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Under Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                           Alerts under investigation are alerts that are not assigned by site Digitalization champion for less than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for less than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
                <div className="overdue-status-invest"
                  onMouseOver={() => setMouseHoverOverdueInvTooltip(true)}
                  onMouseLeave={() => setMouseHoverOverdueInvTooltip(false)}
                >
                  <div className="arrowbox1">
                    <img src={imageOverdue} title="Overdue_Investigate" />
                  </div>
                  <div className="arrowbox2">
                    {data[0].alertTrend === null ? (
                      <img src={icon_health_index_circle} />
                    ) : data[0].alertTrend === true || data[0].alertTrend === 1 ? (
                      <img src={status_Arrow_up_red} title="Arrow Rise" />
                    ) : (
                      <img src={status_Arrow_down_red} title="Arrow Down" />
                    )}
                  </div>
                  <div className="arrowbox3">
                    <span id="value2" style={{ color: "#E35205" }}>
                      {" "}
                      <i style={{ color: "#E35205" }}>{data[0].overdueInvestigation}</i>
                      <i> OVERDUE</i>
                    </span>
                    <span>INVESTIGATION</span>
                  </div>
                  {mouseHoverOverdueInvTooltip === true ?
                    <div className="status-tooltip">
                      <div className="status-tooltip-head">
                        <span className="status-title">What is Overdue Investigation</span>
                      </div>
                      <div className="status-tooltip-box">
                        <div className="status-tooltiprow">
                          Overdue alerts are alerts that are not assigned by site Digitalization champion for more than 3 calendar days. Also, alerts actions that are not closed by assignee department focal point for more than 5 working day from assigned date.
                        </div>
                      </div>
                    </div>

                    :
                    ""
                  }
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : null}
    </>
  );
};

export default Status;
