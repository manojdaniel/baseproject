import React from "react";
import "./HealthIndexComponent.scss";
import stripes from "../../assets/images/stripes.svg";

interface Props {
	item: any;
	title: string;
}

const HealthIndexComponent = ({ item, title }: Props) => {
	return (
		<>
			<div className="allaffiliate-right-row">
				{title === "AFFILIATE" ? (
					<>
						{item.image !== null ?
							<div className="plant-rightimg">
								<img src={item.image} className="affilateimg" />
							</div>
							:
							<div className="plant-rightname">{item.name}</div>
						}
					</>

				) : (
					<div className="plant-rightname">{item.name}</div>
				)}

				{item.healthIndex > 10 ? (
					<div className="blue-bar">
						<span style={{ width: `${item.healthIndex}%` }}>
							<span className="stripes">
								<img src={stripes} />
							</span>
							<i>{item.healthIndex}%</i>
						</span>
					</div>
				) : (
					<div className="blue-bar">
						<span style={{ width: `${item.healthIndex}%` }}>
							<span className="stripes">
								<img src={stripes} />
							</span>
						</span>
						<i>{item.healthIndex}%</i>
					</div>
				)}
			</div>
		</>
	);
};

export default HealthIndexComponent;
