"""
 Created on Thu Oct 29 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import base64
import json
from os import listdir, path
from os.path import isfile, join

import requests

from src.constants.config_keys import CUSTOMER_OB_LOCALE, VAULT_HSDP_IDM_URL, INFRA_CFG_SET_PASSWORD_URL, INFRA_CFG_RECOVER_PASSWORD_URL
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, API_VERSION, ACCEPT
from src.constants.headers import EMAILTEMPLATE_INVITE_TEMPLATE, EMAILTEMPLATE_FORGOT_PWD_TEMPLATE, \
    EMAILTEMPLATE_DOCUMENTS_PATH, EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE, LOCALES_DIRECTORY_PATH
from src.loggers.log import create_logger
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_profile_data

LOG = create_logger("ManageHSDPEmailTemplateServices")

EMAIL_TEMPLATE_DATA = {
    EMAILTEMPLATE_INVITE_TEMPLATE: {"name": EMAILTEMPLATE_INVITE_TEMPLATE, "available": "no"},
    EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE: {"name": EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE, "available": "no"},
    EMAILTEMPLATE_FORGOT_PWD_TEMPLATE: {"name": EMAILTEMPLATE_FORGOT_PWD_TEMPLATE, "available": "no"},
}


def create_email_templates_service(token, org_id, infra_configs):
    LOG.info("Starting email template creation")
    profile_configs = get_profile_data()
    available_locales = infra_configs[CUSTOMER_OB_LOCALE].split(",")
    is_default_template_set = False
    invite_success = False
    recover_success = False
    success = False
    invite_success_error = ""
    recover_success_error = ""
    error_reasn = ""

    for locale in available_locales:
        locale = locale.strip()
        email_template_data = generate_content(locale)

        locale_file = path.join(LOCALES_DIRECTORY_PATH, f"{locale}.json")
        if path.isfile(locale_file):
            with open(locale_file) as file_received:
                locale_string = json.load(file_received)
            LOG.info(f"Locale String  : {locale_string}")
            # Invite
            invite_success, invite_success_error = set_invite_email_template(
                email_template_data, locale_string, is_default_template_set, token, org_id, infra_configs, locale, profile_configs)
            # TODO: Need to enable password expiry after the relevant APIs and UI is ready
            is_default_template_set, recover_success, recover_success_error = set_password_recovery_email_template(email_template_data=email_template_data,
                                                                                                                   locale_string=locale_string,
                                                                                                                   is_default_template_set=is_default_template_set,
                                                                                                                   token=token,
                                                                                                                   org_id=org_id,
                                                                                                                   infra_configs=infra_configs,
                                                                                                                   locale=locale,
                                                                                                                   profile_configs=profile_configs)
        else:
            LOG.info("********FILE NOT FOUND****************")
    LOG.info(f"Email template task is completed for org: {org_id}")
    error_reasn = invite_success_error if invite_success_error else recover_success_error
    if recover_success and invite_success:
        success = True
    return success, error_reasn


def set_invite_email_template(email_template_data, locale_string, is_default_template_set, token, org_id, infra_configs, locale, profile_values):
    success = False
    invite_id = False
    default_invite_id = False
    error_reasn = ""
    error_reasn_invite = ""
    error_reasn_default_invite = ""
    if email_template_data[EMAILTEMPLATE_INVITE_TEMPLATE]["available"].lower() == "yes":
        invite_subject = locale_string["EMAIL_TEMPLATE"]["INVITE_SUBJECT"]
        invite_id, error_reasn_invite = create_email_template_service(token=token,
                                                                      org_id=org_id,
                                                                      email_type="ACCOUNT_VERIFICATION",
                                                                      subject=invite_subject,
                                                                      content=email_template_data[
                                                                          EMAILTEMPLATE_INVITE_TEMPLATE]["encoded_data"],
                                                                      link=infra_configs[INFRA_CFG_SET_PASSWORD_URL],
                                                                      locale=locale,
                                                                      profile_configs=profile_values)
        LOG.info(f"Invite EmailTemplateId:::::: {invite_id}")
        if not is_default_template_set:
            LOG.info("Create this invite email template as default template")
            default_invite_id, error_reasn_default_invite = create_email_template_service(token=token,
                                                                                          org_id=org_id,
                                                                                          email_type="ACCOUNT_VERIFICATION",
                                                                                          subject=invite_subject,
                                                                                          content=email_template_data[
                                                                                              EMAILTEMPLATE_INVITE_TEMPLATE]["encoded_data"],
                                                                                          link=infra_configs[INFRA_CFG_SET_PASSWORD_URL],
                                                                                          profile_configs=profile_values)
        # Reset value once data is inserted
        email_template_data[EMAILTEMPLATE_INVITE_TEMPLATE]["available"] = "no"
        email_template_data[EMAILTEMPLATE_INVITE_TEMPLATE]["encoded_data"] = ""
    else:
        LOG.error(
            f"{EMAILTEMPLATE_INVITE_TEMPLATE} for locale {locale} is not available")
    error_reasn = error_reasn_invite if error_reasn_invite else error_reasn_default_invite
    if invite_id and default_invite_id:
        success = True
    return success, error_reasn


def set_password_recovery_email_template(email_template_data, locale_string, is_default_template_set, token, org_id, infra_configs, locale, profile_configs):
    success = False
    pwd_recovery_id = False
    default_pwd_recovery_id = False
    error_reasn_pwd_recovery = ""
    error_reasn_default_pwd_recovery = ""
    error_reasn = ""
    if email_template_data[EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]["available"].lower() == "yes":
        forgot_pwd_subject = locale_string["EMAIL_TEMPLATE"]["FORGOT_PWD_SUBJECT"]
        pwd_recovery_id, error_reasn_pwd_recovery = create_email_template_service(token=token,
                                                                                  org_id=org_id,
                                                                                  email_type="PASSWORD_RECOVERY",
                                                                                  subject=forgot_pwd_subject,
                                                                                  content=email_template_data[
                                                                                      EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]["encoded_data"],
                                                                                  link=infra_configs[INFRA_CFG_RECOVER_PASSWORD_URL],
                                                                                  locale=locale,
                                                                                  profile_configs=profile_configs)
        LOG.info(f"Pwd Recovery EmailTemplateId:::::: {pwd_recovery_id}")
        if not is_default_template_set:
            LOG.info(
                "Create this password recovery email template as default template")
            default_pwd_recovery_id, error_reasn_default_pwd_recovery = create_email_template_service(token=token,
                                                                                                      org_id=org_id,
                                                                                                      email_type="PASSWORD_RECOVERY",
                                                                                                      subject=forgot_pwd_subject,
                                                                                                      content=email_template_data[
                                                                                                          EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]["encoded_data"],
                                                                                                      link=infra_configs[
                                                                                                          INFRA_CFG_RECOVER_PASSWORD_URL],
                                                                                                      profile_configs=profile_configs)
            is_default_template_set = True
        # Reset value once data is inserted
        email_template_data[EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]["available"] = "no"
        email_template_data[EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]["encoded_data"] = ""
    else:
        LOG.error(
            f"{EMAILTEMPLATE_FORGOT_PWD_TEMPLATE} for locale {locale} is not available")
    error_reasn = error_reasn_pwd_recovery if error_reasn_pwd_recovery else error_reasn_default_pwd_recovery

    if pwd_recovery_id and default_pwd_recovery_id:
        success = True
    return is_default_template_set, success, error_reasn


def generate_content(locale):
    documents = fetch_raw_email_template_content(locale)

    for doc in documents:
        document_name = path.splitext(path.basename(doc))[0]
        if document_name in [EMAILTEMPLATE_INVITE_TEMPLATE, EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE, EMAILTEMPLATE_FORGOT_PWD_TEMPLATE]:
            encoded_data = generate_encoded_data(doc)
            EMAIL_TEMPLATE_DATA[document_name]["available"] = "yes"
            EMAIL_TEMPLATE_DATA[document_name]["encoded_data"] = encoded_data
            LOG.info(
                f"Encoded email template for: {document_name} successfully")
        else:
            LOG.warning(f"Unrecognized html: {document_name} file found. It should be one of these: \
                        {EMAILTEMPLATE_INVITE_TEMPLATE}, {EMAILTEMPLATE_FORGOT_PWD_TEMPLATE}, {EMAILTEMPLATE_PWD_EXPIRY_TEMPLATE}")
    return EMAIL_TEMPLATE_DATA


def generate_encoded_data(doc):
    with open(doc, "rb") as file_handle:
        data = file_handle.read()
    return base64.b64encode(data).decode("utf-8")


def fetch_raw_email_template_content(locale):
    """
    Return all files ending with ".html" from "DOCUMENTS_PATH"
    :return:
    """
    try:
        documents = []
        document_path = path.join(EMAILTEMPLATE_DOCUMENTS_PATH, locale)
        if path.exists(document_path):
            for received_f in listdir(document_path):
                if isfile(join(document_path, received_f)) and received_f.endswith(".html"):
                    documents.append(join(document_path, received_f))
            LOG.info(
                f"Following files are considered for loading into email_templates: {documents}")
        else:
            LOG.error(
                f"Path {document_path} doesn't exist, please check locale value.")
        return documents
    except Exception as ex:
        LOG.exception(
            f"Problem while getting raw email_template documents, error: {ex}")


def create_email_template_service(token, org_id, email_type, subject, content, link, profile_configs, locale=""):
    email_template_id = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "1", ACCEPT: APPLICATION_JSON}
    data = {"type": email_type, "managingOrganization": org_id,
            "format": "HTML", "subject": subject, "message": content, "link": link}
    try:
        if locale:
            data["locale"] = locale
        response = requests.post(f"{profile_configs[VAULT_HSDP_IDM_URL]}/authorize/identity/EmailTemplate",
                                 data=json.dumps(data),
                                 headers=iam_headers)
        if response.status_code == 201:
            LOG.info(
                f"Email template of type: {email_type} for org: {org_id} is created successfully")
            email_template_id = response.json()["id"]
        else:
            LOG.error(
                f"Email template creation failed for type: {email_type} for org: {org_id} with error: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.exception(ex)
        error_reasn = f"Error while updating clientScope: {repr(ex.args)}"
    return email_template_id, error_reasn
