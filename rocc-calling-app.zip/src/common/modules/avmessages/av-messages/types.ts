/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IContactInfo, ECallStatus } from "@rocc/rocc-client-services"
import { Dispatch } from "redux"

export interface ITokenResultSet {
    twilioToken: string
    channelSid: string
    presenceMapId: string
}

export interface ICreateUrlCallFunction {
    accessToken: string
    sessionId: string
    userUuid: string
    communicationServiceUrl: string
    contextId: string
    callStatus: string
    state: boolean
}

export interface IRequester {
    primaryUuid: string
    secondaryUuid: string[]
    callStatus: string
    userContext: any

}

export interface IParticipant {
    primaryUuid: string
    callStatus: string
    secondaryUUID: string[]
}

export interface ICallDetails {
    contextId: string
    roomName: string
    callType: string
    mediaType: string[]
    requester: IRequester
    participants: IParticipant[]
}

export interface IAVMessageType {
    contextId: string
    eventType: string
    participant: string
}

export interface ICallTimeOut {
    caller: IContactInfo
    callee: IContactInfo
    contextId: string
    isCallee: boolean
    lastCallStatus: ECallStatus
    dispatch: Dispatch<any>
}

export interface ICallReject {
    setState: boolean
    contextId: string
    skipAudioPause?: boolean
    dispatch: Dispatch<any>
}

export interface ICallAccept {
    contextId: string
    dispatch: Dispatch<any>
    contactUuid: string
}

export const INIT_AV_MESSAGE = { contextId: "", eventType: "", participant: "" }
export const INIT_REQUESTER: IRequester = { primaryUuid: "", secondaryUuid: [], callStatus: "", userContext: {} }

export const TRACKING_VALUES = {
    component: "MessageHandler",
    event: "Web to Web Call:",
}
