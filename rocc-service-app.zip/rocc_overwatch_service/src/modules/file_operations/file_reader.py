"""
 Created on Mon Oct 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from os import listdir
from os.path import isfile, join

from xlrd import open_workbook

from src.constants.constants import EXCEL_MULTI_KEY_SEPARATOR, SITES_DICT, EMP_DICT, ROOMS_DICT, COMMAND_CENTERS_DICT, CUSTOMER_INFO_DICT, \
    KVM_CONFIGURATION_DICT, TEMPLATE_VERSION_1_0_3, TEMPLATE_VERSION_1_0_6
from src.constants.headers import EXCEL_RECEIVER_SEAT_NAME, EXCEL_SITES_SHEET, EXCEL_EMP_SHEET, EXCEL_ROOMS_SHEET, EXCEL_COMMAND_CENTERS_SHEET, \
    EXCEL_REFERENCE_SHEET, \
    EXCEL_USER_EMAIL_ID, EXCEL_ROOM_IDENTIFIER, EXCEL_CC_SEAT_NAME, EXCEL_CUSTOMER_NAME, EXCEL_HOSPITAL_IDENTIFIER, \
    EXCEL_CUSTOMER_DISPLAY_NAME, \
    TOS_DOCUMENT_PATH, EXCEL_KVM_CONFIGURATION_SHEET, EXCEL_KVM_BOXILLA_IP, EXCEL_MODALITY_CONNECTION_SHEET, EXCEL_ROOM_MODALITY_CONNECTION
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.file_operations.sanitization import sanitize_dicts
from src.modules.file_operations.validator import validate_sheet_for_blanks, validate_dicts
from src.utility.semver import parse_version
from src.modules.file_operations.validations.modality_connection import modality_connection_sheet, append_modality_connection_to_room_dict

LOG = create_logger("FileReader")


def get_book_handle(file_content):
    try:
        book = open_workbook(file_contents=file_content.read())
        return book
    except Exception as ex:
        LOG.exception(f"Failed to read excel with error: {ex}")
        raise RoccException(status_code=400, title="Unreadable template contents", payload="Could not read template file's contents due to an error") from ex


def release_book_handle(book):
    try:
        book.release_resources()
    except Exception as ex:
        LOG.exception(f"Failed to close excel resources with error: {ex}")


def read_excel(book, client, template_version):
    try:
        LOG.debug(f"Sheet Names from Excel Sheet: {book.sheet_names()}")
        errors = []
        employees_dict = gen_dicts(book, EXCEL_EMP_SHEET, errors, True, EXCEL_USER_EMAIL_ID)
        sites_dict = gen_dicts(book, EXCEL_SITES_SHEET, errors, False, EXCEL_HOSPITAL_IDENTIFIER)
        rooms_dict = gen_dicts(book, EXCEL_ROOMS_SHEET, errors, False, EXCEL_ROOM_IDENTIFIER)
        if template_version >= parse_version(TEMPLATE_VERSION_1_0_6):
            receivers_dict = gen_dicts(book, EXCEL_COMMAND_CENTERS_SHEET, errors, False, EXCEL_CC_SEAT_NAME, EXCEL_RECEIVER_SEAT_NAME)
        else:
            receivers_dict = gen_dicts(book, EXCEL_COMMAND_CENTERS_SHEET, errors, False, EXCEL_CC_SEAT_NAME)
        #pylint: disable=unsubscriptable-object
        customer_info_dict = get_unique_customers(sites_dict) if sites_dict else None
        customer_identifier = customer_info_dict[0]["customer_identifier"]
        data_dict = {
            EMP_DICT: employees_dict,
            SITES_DICT: sites_dict,
            ROOMS_DICT: rooms_dict,
            COMMAND_CENTERS_DICT: receivers_dict,
            CUSTOMER_INFO_DICT: customer_info_dict
        }
        data_dict, modality_exceptions = get_modality_dict(book, data_dict, errors)
        if template_version >= parse_version(TEMPLATE_VERSION_1_0_3):
            LOG.info(f"Read sheet {EXCEL_KVM_CONFIGURATION_SHEET} since template version is {str(template_version)}")
            kvm_dict = gen_dicts(book, EXCEL_KVM_CONFIGURATION_SHEET, errors, False, EXCEL_KVM_BOXILLA_IP )
            data_dict[KVM_CONFIGURATION_DICT] = kvm_dict

        data_dict, sanitization_exceptions = sanitize_dicts(data_dict=data_dict)
        data_dict, validation_exceptions = validate_dicts(client=client, data_dict=data_dict, error_msgs=errors, customer_identifier=customer_identifier)
        return data_dict, [*sanitization_exceptions, *validation_exceptions, *modality_exceptions]
    except RoccException as ex:
        raise ex
    except Exception as ex:
        read_failure_msg = f"Failed to read excel with error: {ex}"
        LOG.exception(read_failure_msg)
        raise RoccException(status_code=400, title="Unreadable template file contents", payload="Could not read template file's contents due to an error") from ex


def get_modality_dict(book, data_dict, errors):
    if EXCEL_MODALITY_CONNECTION_SHEET in book.sheet_names():
        """
        If Modality Connection sheet is present, modality_connection rows are validated and grouped based on room_identifier.
        Then append the modality_connection to existing room_dict
        """
        modality_dict, errors = modality_connection_sheet(book, EXCEL_MODALITY_CONNECTION_SHEET, errors)
        data_dict, modality_exceptions = append_modality_connection_to_room_dict(modality_dict, data_dict, errors)
    else:
        for room_value in data_dict[ROOMS_DICT].values():
            room_value[EXCEL_ROOM_MODALITY_CONNECTION] = []
        modality_exceptions = []
    return data_dict, modality_exceptions


def gen_dicts(book, sheet_name, errors, convert_to_lowercase, *key_field):
    try:
        #TODO: Refactor this to reduce the nesting and branches. Pylint: too-many-nested-blocks, too-much-branching
        LOG.debug(f"Reading data from sheet: {sheet_name}")
        sheet = book.sheet_by_name(sheet_name)
        empty_cells = validate_sheet_for_blanks(sheet)
        if len(empty_cells) == 0:
            dictionary = {}
            headers = []  # The row where we stock the name of the column
            for col in range(sheet.ncols):
                headers.append(sheet.cell_value(0, col))
            for row in range(1, sheet.nrows):
                elm = {}
                dictkey = ""
                if len(key_field) > 1:
                    for col in range(sheet.ncols):
                        elm[headers[col]] = str(sheet.cell_value(row, col)).strip()
                        if headers[col] == key_field[0]:
                            key1 = str(sheet.cell_value(row, col)).strip()
                        if headers[col] == key_field[1]:
                            key2 = str(sheet.cell_value(row, col)).strip()
                    dictionary[key1 + EXCEL_MULTI_KEY_SEPARATOR + key2] = elm
                else:
                    for col in range(sheet.ncols):
                        elm[headers[col]] = str(sheet.cell_value(row, col)).strip()
                        if headers[col] == key_field[0]:
                            if convert_to_lowercase:
                                dictkey = str(sheet.cell_value(row, col)).lower().strip()
                            else:
                                dictkey = str(sheet.cell_value(row, col)).strip()
                    dictionary[dictkey] = elm
            if sheet.nrows > 51:
                errors.append(f"Total number of rows in sheet: '{sheet.name}' is {sheet.nrows}. It should not have more than 50 records")
            return dictionary
        else:
            error_message = f"Blank values were encountered in the sheet {sheet_name} cells: {empty_cells}"
            LOG.error(error_message)
            errors.append(error_message)
            return {}
    except Exception as ex:
        LOG.error(f"Problem while extracting dictionaries from excel data with error: {ex}")


def terms_of_service(locale):
    """
    Return all files ending with ".html" from "document_path"
    :return:
    """
    try:
        documents = []
        document_path = join(TOS_DOCUMENT_PATH, locale)
        for file in listdir(document_path):
            if isfile(join(document_path, file)) and file.endswith(".html"):
                documents.append(join(document_path, file))
        LOG.info(f"Following files are considered for loading into terms_of_service: {documents}")
        return documents
    except Exception as ex:
        LOG.error(f"Problem while getting terms of service, problem: {ex}")
        raise ex


def get_unique_customers(sites):
    try:
        metasites = []
        for _, site in sites.items():
            metasites.append({
                "customer_identifier": site[EXCEL_CUSTOMER_NAME].lower(),
                "customer_name": site[EXCEL_CUSTOMER_DISPLAY_NAME]
            })
        metasites = list({customer["customer_identifier"]: customer for customer in metasites}.values())
        return metasites
    except Exception as ex:
        LOG.exception(f"Exception occurred while checking metasites: {ex}")


def get_excel_template_version(book):
    try:
        sheet = book.sheet_by_name(EXCEL_REFERENCE_SHEET)
        template_version_cell = sheet.cell_value(2, 2)
        return parse_version(template_version_cell)
    except Exception as ex:
        LOG.exception(f"Failed to fetch excel template version with error: {ex}")
        raise RoccException(status_code=400, title="Inaccessible excel template version", payload="Template version couldn't be fetched from excel file") from ex
