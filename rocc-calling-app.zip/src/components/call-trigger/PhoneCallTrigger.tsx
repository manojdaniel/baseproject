/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { PhoneCall } from "@rocc/rocc-calling-components"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useCallOptionStatus } from "../../common/helpers/customHooks"
import { IPhoneCallTrigger, IStore } from "../../redux/interfaces/types"
import { enableBrowserToPhoneCall } from "../../services/callServices"

const componentName = "PhoneCallTrigger"

const PhoneCallTrigger = (props: IPhoneCallTrigger) => {

    const { contactUuid, background } = props

    const dispatch = useDispatch()

    const [ffEnabled, setFfEnabled] = useState(true)

    const {
        permissions,
    } = useSelector((state: IStore) => ({
        permissions: state.externalReducer.permissions,
    }))

    useEffect(() => {
        !permissions.CALL_WEB_TO_PHONE ? setFfEnabled(false) : setFfEnabled(true)
    }, [permissions])

    const { isPhoneCallDisabled } = useCallOptionStatus(contactUuid)

    const initiatePhoneCall = (phoneNumber: any) => {
        enableBrowserToPhoneCall({
            contactUuid, phoneNumber: phoneNumber.value, componentName, dispatch,
        })
    }

    return (
        ffEnabled ?
            <PhoneCall {...props} initiatePhoneCall={initiatePhoneCall} isDisabled={isPhoneCallDisabled} isBorder={background} /> : <></>
    )
}

export default PhoneCallTrigger
