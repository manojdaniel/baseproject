/*
 * Created on Thu Jul 29 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { errorLogger } from "@rocc/rocc-logging-module"

export const parseIntBase10 = (value: string) => {
    return parseInt(value, 10)
}

export const getDurationInFormat = (greaterDate: Date, lesserDate: Date, format: "miliseconds" | "seconds" | "minutes" | "hours" = "seconds") => {
    /* Returns Time in number with requested format */
    try {
        const differenceInMiliSeconds = (greaterDate.getTime() - lesserDate.getTime())
        const difference = differenceInMiliSeconds / 1000
        switch (format) {
            case "miliseconds":
                return differenceInMiliSeconds
            case "seconds":
                return Math.abs(Math.round(difference))
            case "minutes":
                return Math.abs(Math.round(difference / 60))
            case "hours":
                return Math.abs(Math.round(difference / (60 * 60)))
        }
    } catch (error) {
        errorLogger(`Error while calculating difference in date-times - ${JSON.stringify(error)}`)
        return 0
    }
}
