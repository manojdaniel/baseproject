/*
 * Created on Fri May 6 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 20121 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ERoomMoinitorRenderState } from "@rocc/rocc-client-services"
import { RoomMonitoringItem } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { OFF, ON, ROOM_MONITORING_TRACKING } from "../../../common/constants/constants"
import { getDurationInFormat } from "../../../common/helpers/dateTimeUtility"
import { attachTrack, detachTracks } from "../../../common/helpers/multiCameraUtility"
import { IStore } from "../../../redux/interfaces/types"
import en from "../../../resources/translations/en-US"
import { IRoomMonitorStream } from "../RoomMonitoringTypes"

const FILENAME = "RoomMonitoringCameraView.tsx : "

const RoomMonitoringCameraItem = ({
    cameraName, cameraState, hideCameraControl, hideFullscreenControl, renderState, message, videoTrackItem, isSwitchingConsoleSession,
    handlefullscreenClick, setVideoStarted, setIsSwitchingConsoleSession, consoleSession
}: IRoomMonitorStream) => {

    const [cameraStatus, setCameraStatus] = useState(cameraState)
    const [videoMessage, setVideoMessage] = useState(message)
    const [hideCameraControlStatus, setHideCameraControlStatus] = useState(hideCameraControl)
    const [hideFullscreenControlStatus, setHideFullscreenControlStatus] = useState(hideFullscreenControl)
    const [renderStatus, setRenderStatus] = useState(renderState)
    const { intl } = getIntlProvider()
    const { MESSAGE, RENDER_VIDEO } = ERoomMoinitorRenderState
    const { currentUser } = useSelector((state: IStore) => ({
        currentUser: state.externalReducer.currentUser
    }))
    const loggerInitialMessage = `${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId}`

    const handleCameraSliderClick = () => {
        infoLogger(`${loggerInitialMessage} - Switching camera ${videoTrackItem.videoTrack.name} state to ${!cameraStatus}`)
        if (cameraStatus) {
            setCameraStatus(false)
            detachTracks([videoTrackItem.videoTrack])
            setRenderStatus(MESSAGE)
            setHideFullscreenControlStatus(true)
            setVideoMessage(`${cameraName} ${intl.formatMessage({ id: "content.room.stoppedMessage", defaultMessage: en["content.room.stoppedMessage"] })}`)
        } else {
            setCameraStatus(true)
            setRenderStatus(RENDER_VIDEO)
            setHideFullscreenControlStatus(false)
        }
        sendLogsToAzure({ contextData: { component: `${ROOM_MONITORING_TRACKING}`, event: `${cameraName}: Toggle button clicked and status is ${cameraStatus ? ON : OFF}`, Event_by: currentUser.uuid } })
    }

    const handleVideoStart = () => {
        infoLogger(`${loggerInitialMessage} - Rendering video stream for track ${videoTrackItem.videoTrack.name}`)
        setHideCameraControlStatus(true)
        setHideFullscreenControlStatus(false)
        setRenderStatus(RENDER_VIDEO)
        setVideoStarted(true)
        setIsSwitchingConsoleSession(false)
    }

    useEffect(() => { setRenderStatus(renderState) }, [renderState])
    useEffect(() => { setHideCameraControlStatus(hideCameraControl) }, [hideCameraControl])
    useEffect(() => { setHideFullscreenControlStatus(hideFullscreenControl) }, [hideFullscreenControl])

    useEffect(() => {
        if (videoTrackItem.videoTrack && renderState === RENDER_VIDEO) {
            sendLogsToAzure({
                contextData: {
                    component: ROOM_MONITORING_TRACKING,
                    event: `${cameraName} stream on`,
                    duration: getDurationInFormat(new Date(), new Date(consoleSession.consoleStartTime))
                }
            })
        }
    }, [videoTrackItem.videoTrack])

    return <RoomMonitoringItem
        cameraName={cameraName}
        videoTrackItem={videoTrackItem}
        message={videoMessage}
        cameraState={cameraStatus}
        fullscreenState={videoTrackItem.fullScreen}
        hideCameraControl={hideCameraControlStatus}
        hideFullscreenControl={hideFullscreenControlStatus}
        renderState={renderStatus}
        isSwitchingConsoleSession={isSwitchingConsoleSession}
        currentUserUuid={consoleSession.requester}
        consoleContextId={consoleSession.contextId}
        infoLogger={infoLogger}
        onCameraSliderClick={handleCameraSliderClick}
        onFullScreenClick={handlefullscreenClick}
        onVideoStart={handleVideoStart}
        attachTrack={attachTrack}
        detachTracks={detachTracks}
       
    />
}

export default RoomMonitoringCameraItem
