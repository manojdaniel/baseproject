/*
 * Created on Mon Aug 9 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Logout } from "@rocc/rocc-authentication-components"
import { EAppContext, EAppStates, ECallStatus, EClinicalRole, EConnectionStatus, EFetchStatus, EResponse, FeatureFlagHelper, ICallStatus, IConsoleSession, IContactInfo, IParentStore, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { CustomLoader, ErrorBoundary, getIntlProvider, MessageNotifier, ModalComponent, NotificationBubble } from "@rocc/rocc-global-components"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Prompt } from "react-router-dom"
import { Button, Sidebar } from "semantic-ui-react"
import { applicationName, APP_NAME, BEFORE_UNLOAD, CALLING_APP_STORE, companyName, CONSOLE_APP_STORE, MULTI_CAMERA_SETTINGS_SIDEBAR, RELOAD, TABID, TELEPRESENCE_SIDEBAR, UNLOAD } from "../../../constants/constants"
import { LOGOUT_ROUTE, SESSION_EXPIRED } from "../../../constants/routes"
import { TRACK } from "../../../constants/tracking"
import { updateFocusedCallAndConsole } from "../../../redux/actions/appActions"
import { setConfigs } from "../../../redux/actions/configActions"
import { fetchLocationData } from "../../../redux/actions/customerActions"
import { GLOBAL_LEFTSIDE_PANEL, GLOBAL_RIGHTSIDE_PANEL, GLOBAL_UPDATE_NOTIFICATION_MESSAGE } from "../../../redux/actions/types"
import { fetchBundleUpdateNotification, fetchContacts, setCurrentAppState } from "../../../redux/actions/userAction"
import globalStore from "../../../redux/store/globalStore"
import en from "../../../resources/translations/en-US"
import { checkIfCallGoingOn } from "../../../utility/calling/CallingUtility"
import { initializeFeatureFlagClient } from "../../../utility/feature-flags/featureFlag"
import { cctvClose, cctvWindow, convertSiteContactToContactInfo, isAnyOfEmeraldEnabled, isExpert } from "../../../utility/helpers/helpers"
import { parseIntBase10 } from "../../../utility/math/mathUtility"
import { computePresignedErrorIfAny } from "../../../utility/pre-signed-workflow-utility/presignedUtility"
import { usePreSigned } from "../../../utility/pre-signed-workflow-utility/usePreSigned"
import About from "../../about/About"
import Navbar from "../../navbar/Navbar"
import { handleApplicationLogout } from "../../navbar/NavBarHelper"
import { fetchCommunicationConfig } from "../../presence/presenceService"
import useIdletimer from "../../session-expiry/IdleTimer"
import SessionExpiryModal from "../../session-expiry/SessionExpiryModal"
import SetupClients from "../../setup/setup-clients/SetupClients"
import { useWorkflowController } from "../../workflow-controller/WorkflowController"
import { useWorkflowExecutor } from "../../workflow-executor/WorkflowExecutor"
import styles from "./AppLayout.module.scss"

const SidebarContentFeature = React.lazy(() => import("roccHome/SidebarContentFeature").catch(() => false))
const TWO_TABS = "2"


const AppLayout = ({ ComponentToLoad }: { ComponentToLoad: any }) => {
    const { config, currentUser, appState, sideBar, expertUserTransitionState, urls, presignedWorkflows, appContext,
        locationFetched, notificationModal, notificationMessage, applicationConnectionState, featureFlags, fseData, permissions,
        ffConfig, defaultFeatureFlags, orgIdentifier, sites, contacts, contactsFetched, devMode, queryLimitContacts, } = useSelector((state: IParentStore) => ({
            config: state.configReducer.configs,
            currentUser: state.userReducer.currentUser,
            appState: state.userReducer.appState,
            sideBar: state.appReducer.sideBar,
            expertUserTransitionState: state.userReducer.expertUserTransitionState,
            locationFetched: state.customerReducer.locationFetched,
            notificationModal: state.modalReducer.notificationModal,
            notificationMessage: state.modalReducer.notificationMessage,
            applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
            urls: state.configReducer.urls,
            featureFlags: state.featureFlagsReducer.featureFlags,
            fseData: state.appReducer.fseData,
            permissions: state.userReducer.permissions,
            presignedWorkflows: state.workflowReducer.presignedWorkflows,
            appContext: state.appReducer.appContext,
            ffConfig: state.featureFlagsReducer.featureFlagConfig.provider,
            defaultFeatureFlags: state.featureFlagsReducer.defaultFeatureFlags,
            orgIdentifier: state.customerReducer.metaData.name,
            devMode: state.configReducer.configs.ROCC_DEV,
            contacts: state.userReducer.contacts,
            sites: state.customerReducer.locations,
            contactsFetched: state.userReducer.contactsFetched,
            queryLimitContacts: state.configReducer.configs.QUERY_LIMIT_CONTACTS,
        }))
    const { intl } = getIntlProvider()
    const gState = globalStore.GetGlobalState()
    let timeoutId: NodeJS.Timeout
    const [aboutModal, setAboutModal] = useState(false)
    const [presignedError, setPresignedError] = useState("")
    const [isNfccRoccFeatureEnabled, setIsNfccRoccFeatureEnabled] = useState(false)
    const [consoleStoreSubscribed, setConsoleStoreSubscribed] = useState(false)
    const [callingStoreSubscribed, setCallingStoreSubscribed] = useState(false)
    const [phoneCallStatus, setPhoneCallStatus] = useState(ECallStatus.IDLE)
    const [videoCallStatus, setVideoCallStatus] = useState([] as ICallStatus[])
    const [consoleSessions, setConsoleSessions] = useState([] as IConsoleSession[])
    const [initClient, setInitClient] = useState(false)
    const [isTechAppDownloadAvailable, setIsTechAppDownloadAvailable] = useState(false)
    const showNetworkDisconnectionMessage = applicationConnectionState === EConnectionStatus.OFFLINE
    const CALL_IN_PROGRESS_WANT_TO_LEAVE = intl.formatMessage({ id: "content.leavePageMessage.activeCallInProgress", defaultMessage: en["content.leavePageMessage.activeCallInProgress"] })
    const CONSOLE_IN_PROGRESS_WANT_TO_LEAVE = intl.formatMessage({ id: "content.leavePageMessage.consoleSessionInProgress", defaultMessage: en["content.leavePageMessage.consoleSessionInProgress"] })
    const isCallGoingOn = checkIfCallGoingOn(phoneCallStatus, videoCallStatus)
    const areActiveConsoleSessionsInProgress = consoleSessions && consoleSessions.length > 0 && appState !== EAppStates.SESSION_EXPIRED
    const loggingOut = location.hash.includes(LOGOUT_ROUTE)
    const displayPrompt = isCallGoingOn || (areActiveConsoleSessionsInProgress && !loggingOut)
    const userLeavingPromptMessage = isCallGoingOn ? CALL_IN_PROGRESS_WANT_TO_LEAVE : CONSOLE_IN_PROGRESS_WANT_TO_LEAVE
    const [isEmeraldCliFeatureEnabled, setIsEmeraldCliFeatureEnabled] = useState(false)
    const [allContacts, setAllContacts] = useState([] as IContactInfo[])

    const dispatch = useDispatch()

    /* TODO: Display customized message */
    const alertUser = (e: any) => {
        e.preventDefault()
        e.returnValue = ""
    }
    usePreSigned()
    useWorkflowExecutor()
    useWorkflowController()

    useEffect(() => {
        //useEffect to reinitialize featureflag after refresh
        if ((window.performance.getEntriesByType("navigation")[0] as any).type === RELOAD) {
            initializeFeatureFlagClient({
                currentUser,
                defaultFeatureFlags,
                dispatch,
                ffConfig,
                orgIdentifier,
                urls,
            })
        }
    }, [])

    useEffect(() => {
        const { timeOut } = notificationMessage
        if (timeOut) {
            timeoutId = setTimeout(() => closeMessageHandler(), timeOut)
        }
    }, [notificationMessage])

    useEffect(() => {
        if (currentUser.onBoarded && isAnyOfEmeraldEnabled(permissions) && FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.NFCC_INSTALLER, true)
            && (isExpert || (fseData && fseData.isFse))) {
            setIsNfccRoccFeatureEnabled(true)
        }
        setIsTechAppDownloadAvailable(
            FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_TECH_APP_DOWNLOAD)
            && currentUser.allRoles.includes(EClinicalRole.ADMIN)
        )
        setIsEmeraldCliFeatureEnabled(FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_EMERALD_CLI, true))
    }, [featureFlags])

    const setAvConfigs = async () => {
        const { COUNTRY_ISO_CODE, REGION } = config
        const { signalingRegion, edgeLocation } = await fetchCommunicationConfig(COUNTRY_ISO_CODE, REGION, urls.COMMUNICATION_SERVICES_URL, currentUser.accessToken)
        const newConfigs = { ...config, SIGNALING_REGION: signalingRegion, EDGE_LOCATION: edgeLocation }
        dispatch(setConfigs(newConfigs))
    }

    useEffect(() => {
        if (currentUser.onBoarded) {
            setAvConfigs()
        }
    }, [currentUser.onBoarded])

    useEffect(() => {
        if (FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_EMERALD_CLI, true) && isNfccRoccFeatureEnabled) {
            dispatch(fetchBundleUpdateNotification(currentUser, urls))
        }
    }, [isNfccRoccFeatureEnabled, isEmeraldCliFeatureEnabled])

    useEffect(() => {
        if (displayPrompt) {
            window.addEventListener(BEFORE_UNLOAD, alertUser)
        }
        return () => {
            window.removeEventListener(BEFORE_UNLOAD, alertUser)
        }
    }, [displayPrompt])

    useEffect(() => {
        const tabID = sessionStorage[TABID] && sessionStorage.closedLastTab !== TWO_TABS ?
            sessionStorage[TABID] : window.crypto.getRandomValues(new Uint16Array(1))
        sessionStorage.closedLastTab = TWO_TABS
        sessionStorage[TABID] = tabID
        setInitClient(true)
        window.addEventListener(UNLOAD, function (e) {
            if (cctvWindow) {
                cctvClose()
            }
            e.preventDefault()
            return ""
        })
    }, [])

    useEffect(() => {
        const subscribeToParentStore = () => {
            if (!consoleStoreSubscribed && gState[CONSOLE_APP_STORE]) {
                setConsoleSessions(gState[CONSOLE_APP_STORE].consoleReducer.consoleSessions)
                globalStore.SubscribeToPartnerState(APP_NAME, CONSOLE_APP_STORE, (changedState: any) => {
                    setConsoleSessions(changedState.consoleReducer.consoleSessions)
                })
                setConsoleStoreSubscribed(true)
            }
            if (!callingStoreSubscribed && gState[CALLING_APP_STORE]) {
                setPhoneCallStatus(gState[CALLING_APP_STORE].callReducer.phoneCallStatus)
                setVideoCallStatus(gState[CALLING_APP_STORE].callReducer.videoCallStatus)
                globalStore.SubscribeToPartnerState(APP_NAME, CALLING_APP_STORE, (changedState: any) => {
                    setPhoneCallStatus(changedState.callReducer.phoneCallStatus)
                    setVideoCallStatus(changedState.callReducer.videoCallStatus)
                })
                setCallingStoreSubscribed(true)
            }
        }
        subscribeToParentStore()
    }, [gState])

    useEffect(() => {
        const checkForPreSignedError = () => {
            if (appContext === EAppContext.PRE_SIGNED) {
                const message = computePresignedErrorIfAny(presignedWorkflows)
                if (message) {
                    setPresignedError(message)
                }
            }
        }
        checkForPreSignedError()
    }, [appContext === EAppContext.PRE_SIGNED, presignedWorkflows])

    useEffect(() => {
        /** Fetch Contacts */
        if (currentUser.onBoarded && !contactsFetched) {
            const limit = ((devMode && devMode === "true") && queryLimitContacts) ? parseIntBase10(queryLimitContacts) : 0
            dispatch(fetchContacts(currentUser, limit))
        }
    }, [currentUser])

    useEffect(() => {
        let siteContacts: IContactInfo[] = []
        sites.forEach((site: any) => {
            const newContacts = convertSiteContactToContactInfo(site)
            siteContacts = ([...siteContacts, ...newContacts])
        })
        setAllContacts([...contacts, ...siteContacts])
    }, [sites, contacts])

    const halfMin = 0.5
    const SESSION_EXPIRY_TIME_IN_MINS = parseIntBase10(config.SESSION_IDLE_TIMEOUT)
    const diff = SESSION_EXPIRY_TIME_IN_MINS - 1
    const SESSION_EXPIRY_WARNING_TIME_IN_MINS = diff > 0 ? diff : halfMin
    const SESSION_EXPIRY_TIME = SESSION_EXPIRY_TIME_IN_MINS * 60 * 1000
    const SESSION_EXPIRY_WARNING_TIME = SESSION_EXPIRY_WARNING_TIME_IN_MINS * 60 * 1000
    const leftSideBarStyle = sideBar.activeLeftPanel === MULTI_CAMERA_SETTINGS_SIDEBAR && styles.cameraSettings

    const handleSessionTimeout = () => {
        handleApplicationLogout(dispatch, SESSION_EXPIRED)
    }

    const handleWarning = () => {
        if (appState !== EAppStates.SESSION_EXPIRY_WARNING) {
            dispatch(setCurrentAppState(EAppStates.SESSION_EXPIRY_WARNING))
        }
    }

    useIdletimer({
        timeout: SESSION_EXPIRY_TIME,
        warningTimeout: SESSION_EXPIRY_WARNING_TIME,
        onWarn: handleWarning,
        onTimeOut: handleSessionTimeout
    })

    const fetchLocationDetails = () => {
        if (currentUser.id && [EFetchStatus.notStarted, EFetchStatus.failed].includes(locationFetched)) {
            dispatch(fetchLocationData(currentUser.uuid))
        }
    }

    const toggleRightPane = () => {
        if (sideBar.displayRightSidePanel) {
            const { component, tab: { contacts } } = TRACK.EXPERT_USER_VIEW
            sendLogsToAzure({ contextData: { component: component, Tab: contacts } })
        }
        dispatch({
            type: GLOBAL_RIGHTSIDE_PANEL, payload: {
                displayRightSidePanel: !sideBar.displayRightSidePanel,
                activeRightPanel: TELEPRESENCE_SIDEBAR,
                desktopFullScreen: false,
            }
        })
        if (sideBar.displayRightSidePanel) {
            dispatch(updateFocusedCallAndConsole())
        }
    }

    const toggleAboutClick = () => {
        sendLogsToAzure({ contextData: { Page: "About: Desktop Home" } })
        setAboutModal(true)
    }

    const renderSideBarFromHomeApp = () => (
        <React.Suspense fallback="">
            <ErrorBoundary>
                <SidebarContentFeature contacts={allContacts} />
            </ErrorBoundary>
        </React.Suspense>
    )

    const closeMessageHandler = () => {
        if (timeoutId) {
            clearTimeout(timeoutId)
        }
        dispatch({
            type: GLOBAL_UPDATE_NOTIFICATION_MESSAGE, payload: {
                notificationMessage: {
                    header: "",
                    content: "",
                    closeMessage: {},
                    showNotification: false,
                    isSuccess: false,
                    isWarning: false,
                    fixed: true,
                    customStyle: {}
                }
            }
        })
    }

    const locationFetchError = () => {
        return <div className={styles.pusher}>
            <div id={"locationfetchError"} className={styles.error}>
                <h3>
                    {intl.formatMessage({ id: "content.locationInfo.failed", defaultMessage: en["content.locationInfo.failed"] })}
                </h3>
                <Button id={"locationInfoRetry"} onClick={() => fetchLocationDetails()} secondary={true} >
                    {intl.formatMessage({ id: "content.locationInfo.retry", defaultMessage: en["content.locationInfo.retry"] })}
                </Button>
            </div>
        </div>
    }

    const displayPresignedError = () => {
        /* TODO: Need to use internationalized strings for Pre-signed messages */
        return appContext === EAppContext.PRE_SIGNED && presignedError ? <div className={styles.pusher}>
            <div id={"presignedError"} className={styles.error}>
                <h3>
                    {intl.formatMessage({ id: "content.presignedInfo.failed", defaultMessage: presignedError })}
                </h3>
            </div>
        </div> : <></>
    }

    const initialiseClient = () => {
        return initClient ? <SetupClients /> : <></>
    }

    return (
        <div id="AppLayout" className={cx("t-tonal-range-ultra-light t-color-range-group-blue t-accent-pink", styles.appLayout)}>
            <Prompt
                when={displayPrompt}
                message={() => {
                    if (confirm(userLeavingPromptMessage)) {
                        dispatch({
                            type: GLOBAL_LEFTSIDE_PANEL,
                            payload: {
                                displayLeftSidePanel: false,
                                activeLeftPanel: "",
                                desktopFullScreen: false,
                            }
                        })
                        return true
                    }
                    history.go(-1)
                    return false
                }} />
            {showNetworkDisconnectionMessage && <NotificationBubble
                content={intl.formatMessage({ id: "content.banner.noInternetConnection", defaultMessage: en["content.banner.noInternetConnection"] })}
            />}
            <Navbar
                userName={currentUser.name}
                phoneIconCallBack={toggleRightPane}
                aboutClick={toggleAboutClick}
                showNfccDownload={isNfccRoccFeatureEnabled}
                phoneCallStatus={phoneCallStatus}
                videoCallStatus={videoCallStatus}
                consoleSessions={consoleSessions}
                isTechAppDownloadAvailable={isTechAppDownloadAvailable}
            />
            {displayPresignedError()}
            {
                locationFetched === EFetchStatus.failed ? locationFetchError() :
                    <>
                        {notificationMessage.showNotification && <MessageNotifier
                            show={notificationMessage.showNotification}
                            closeMessage={closeMessageHandler}
                            message={notificationMessage.message}
                            isSuccess={notificationMessage.isSuccess}
                            isWarning={notificationMessage.isWarning}
                            isNotification={notificationMessage.isNotification}
                            timeOut={notificationMessage.timeOut}
                            hideIcon={notificationMessage.hideIcon}
                            className={styles.notificationMessage}
                            fixed={notificationMessage.fixed}
                            customStyle={notificationMessage.customStyle} />
                        }
                        {notificationModal.showModal && <ModalComponent
                            header={notificationModal.header}
                            showModal={notificationModal.showModal}
                            modalContent={notificationModal.modalContent}
                            showCloseIcon={notificationModal.showCloseIcon}
                            actionButton1Onclick={notificationModal.actionButton1Onclick}
                            actionButton2Onclick={notificationModal.actionButton2Onclick}
                            actionButton1Text={notificationModal.actionButton1Text}
                            actionButton2Text={notificationModal.actionButton2Text}
                            onClose={notificationModal.onClose}
                            modalStyles={notificationModal.modalStyles}
                        />}
                        <Sidebar.Pushable className={cx(styles.sideBarComponent, leftSideBarStyle)}>
                            <Sidebar.Pusher>
                                {expertUserTransitionState === EResponse.INIT && <Logout />}
                                {appState === EAppStates.READY ?
                                    ComponentToLoad :
                                    <CustomLoader
                                        content={intl.formatMessage({ id: "content.loading.text", defaultMessage: en["content.loading.text"] })}
                                        dimmer={true}
                                        inline={true}
                                        inverted={true}
                                        size={"normal"} />}
                                {appState === EAppStates.SESSION_EXPIRY_WARNING &&
                                    <SessionExpiryModal resetSessionTimeout={() => dispatch(setCurrentAppState(EAppStates.READY))} />}
                                {renderSideBarFromHomeApp()}
                                {aboutModal && <About
                                    isModalOpen={aboutModal}
                                    closeModal={() => setAboutModal(false)}
                                    companyName={companyName}
                                    applicationTitle={applicationName}
                                />}
                            </Sidebar.Pusher>
                        </Sidebar.Pushable>
                        {initialiseClient()}
                    </>
            }
        </div >
    )
}

export default AppLayout
