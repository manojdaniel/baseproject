"""
 Created on Fri Oct 07 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import base64
import sys
import traceback
from urllib.error import HTTPError
import requests

from src.exceptions.RoccException import RoccException
from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, X_VAULT_TOKEN, SPACE_ID, CLIENT_TOKEN, VAULT_URL, VAULT_ROCC_CRED_PATH, UTF_8
from src.constants.config_keys import CUSTOMER_OB_CRYPT_ENABLED, CUSTOMER_OB_LOCALE, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE, CUSTOMER_OB_ROCC_MEDIA_REGION, CUSTOMER_OB_ROCC_SIGNALING_REGION, VAULT_INSIGHTS_KEY, \
    VAULT_LOG_PRODUCT_KEY, VAULT_GOOGLE_MAPS_API, VAULT_PARENT_OAUTH_CLIENT_ID, VAULT_PARENT_OAUTH_PASSWORD, VAULT_PARENT_ORG_ID, VAULT_PARENT_ORG_NAME, \
    VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, \
    VAULT_ROCC_GLOBAL_PATH, VAULT_SECRET_KEY, VAULT_SHARED_KEY, VAULT_EVAL_APP_ID, VAULT_AUDIT_PRODUCT_KEY, VAULT_AUDIT_SHARED_KEY, VAULT_AUDIT_SECRET_KEY, \
    CUSTOMER_OB_CONSOLE_IP, CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY, CUSTOMER_OB_SESSION_IDLE_TIMEOUT, CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT, \
    CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS, CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, \
    CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS, CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, \
    CUSTOMER_OB_ANALYTICS_LOG_CONSENT, CUSTOMER_OB_ROCC_HELPLINE_NUMBER, INFRA_CFG_ORG_OAUTH_CLIENT_ID, \
    INFRA_CFG_ORG_OAUTH_PASSWORD, VAULT_BLACKBOX_AUTH_HEADER, VAULT_HTTP_PASSWORD, INFRA_CFG_DEVICE_TYPE_NAME, CUSTOMER_OB_BOXILLA_USER_PASS_VALUE, \
    CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE, CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS, CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING, \
    CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION, CUSTOMER_OB_NO_OF_PIN_DIGITS, CUSTOMER_OB_COUNTRY_ISO_CODE, CUSTOMER_OB_AV_AUTO_DISCONNECT_TIMEOUT,\
    CUSTOMER_OB_EDIT_REQUEST_APPROVAL_TIMEOUT_IN_SECONDS, CUSTOMER_OB_PRIVACY_POLICY_URL, CUSTOMER_OB_KVM_VENDOR_TYPE, \
    CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY, CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL
from src.loggers.log import create_logger
from src.wrappers.cf.cf_utility import vault_credentials

LOG = create_logger("ManageHSDPVaultServices")


def get_path_specific_vault_values(path_name, vault_credentials_response=None):
    if vault_credentials_response is None:
        vault_credentials_response = vault_credentials()
    vault_headers = {CONTENT_TYPE: APPLICATION_JSON,
                     X_VAULT_TOKEN: vault_credentials_response[CLIENT_TOKEN]}
    try:
        response = requests.get(f"{vault_credentials_response[VAULT_URL]}v1/cf/{vault_credentials_response[SPACE_ID]}/secret/data/rocc/{path_name}",
                                headers=vault_headers)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            LOG.warn(
                f"Vault values are not available for path {path_name}, they need to be created. Error: {response.json()}")
            # '404 Not Found' is returned when there is no entry in the path specified. This might mean it is a fresh installation. We just need to log and continue
        else:
            LOG.exception(
                f"Error while getting vault values {response.json()}")
            response.raise_for_status()
        return
    except requests.exceptions.RequestException as ex:
        LOG.error(ex)
        LOG.error(traceback.print_exc())
        raise RoccException(ex.response.status_code,
                            str(sys.exc_info()[1])) from ex


def post_vault_values_for_path(path, body, vault_credentials_response=None):
    if vault_credentials_response is None:
        vault_credentials_response = vault_credentials()
    vault_headers = {CONTENT_TYPE: APPLICATION_JSON,
                     X_VAULT_TOKEN: vault_credentials_response[CLIENT_TOKEN]}
    return requests.post(f"{vault_credentials_response[VAULT_URL]}v1/cf/{vault_credentials_response[SPACE_ID]}/secret/data/rocc/{path}",
                         data=json.dumps(body),
                         headers=vault_headers)


def get_profile_data():
    response = get_path_specific_vault_values(os.environ["VAULT_PROFILE"])
    if response and response.get("data"):
        return response.get("data")
    LOG.error("Failed to retrieve vault profile configs")
    raise RoccException(500, "Failed to retrieve vault profile configs")


def create_global_vault_values(service_response, profile_configs, vault_credentials_response=None):
    customer_map = {}
    try:
        vault_data = get_path_specific_vault_values(
            path_name=profile_configs[VAULT_ROCC_GLOBAL_PATH], vault_credentials_response=vault_credentials_response)["data"]
        if "customerMap" in vault_data:
            customer_map = vault_data["customerMap"]
        customer_map[profile_configs[VAULT_PARENT_ORG_NAME]
                     ] = profile_configs[VAULT_PARENT_ORG_ID]
    except Exception as _:
        LOG.warn(
            f"There is no data in Vault data in path: {profile_configs[VAULT_ROCC_GLOBAL_PATH]}, so setting customerMap to blank")
    try:
        data = {"customerMap": customer_map,
                "insightsKey": profile_configs[VAULT_INSIGHTS_KEY],
                "logProductKey": profile_configs[VAULT_LOG_PRODUCT_KEY],
                "googleMapsApi": profile_configs[VAULT_GOOGLE_MAPS_API],
                "signatureAuthSecretKey": profile_configs[VAULT_SECRET_KEY],
                "signatureAuthSharedKey": profile_configs[VAULT_SHARED_KEY],
                "evalAuthPolicyId": profile_configs[VAULT_EVAL_APP_ID],
                "auditProductKey": profile_configs[VAULT_AUDIT_PRODUCT_KEY],
                "auditSharedKey": profile_configs[VAULT_AUDIT_SHARED_KEY],
                "auditSecretKey": profile_configs[VAULT_AUDIT_SECRET_KEY],
                "serviceAuthIssuer": service_response["serviceId"],
                "serviceAuthPrivateKey": service_response["privateKey"].replace("-----BEGIN RSA PRIVATE KEY-----", "").replace("-----END RSA PRIVATE KEY-----", ""),
                "iamAuthClientId": profile_configs[VAULT_PARENT_OAUTH_CLIENT_ID],
                "iamAuthClientSecret": profile_configs[VAULT_PARENT_OAUTH_PASSWORD],
                "demoConsoleVideos": "",
                "mfeOrgs": ""
                }
        response = post_vault_values_for_path(
            path=profile_configs[VAULT_ROCC_GLOBAL_PATH], body=data, vault_credentials_response=vault_credentials_response)
        if response.status_code == 204:
            LOG.info("Vault values created Successfully")
            return True
        else:
            LOG.error(
                f"Error while creating vault values: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating vault values: {ex}")
    return False


def create_selfservice_vault_values(crm_client_secret, crm_key, self_service_path, vault_credentials_response=None):
    try:
        data = {"crmClientSecretKey": crm_client_secret,
                "crmKey": crm_key}
        response = post_vault_values_for_path(
            path=self_service_path, body=data, vault_credentials_response=vault_credentials_response)
        if response.status_code == 204:
            LOG.info("Vault values created Successfully")
            return True
        else:
            LOG.error(
                f"Error while creating vault values: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.exception(f"Error while creating vault values: {ex}")
    return False


def create_customer_specific_vault_values(service_response, device_bootstrap_client_id, device_bootstrap_client_secret, org_id, customer_name, infra_configs):
    response_success = False
    error_reasn = ""
    try:
        encryption_value = str(base64.b64encode(os.urandom(16)), UTF_8)
        profile_configs = get_profile_data()
        data = {"iamAuthClientId": infra_configs[INFRA_CFG_ORG_OAUTH_CLIENT_ID],
                "iamAuthClientSecret": infra_configs[INFRA_CFG_ORG_OAUTH_PASSWORD],
                "consoleIpAddressAndPort": infra_configs[CUSTOMER_OB_CONSOLE_IP],
                "consoleDisconnectDelay": infra_configs[CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY],
                "blackBoxAuthHeader": profile_configs[VAULT_BLACKBOX_AUTH_HEADER],
                "blackBoxPassValue": profile_configs[VAULT_HTTP_PASSWORD],
                "serviceAuthIssuer": service_response["serviceId"],
                "serviceAuthPrivateKey": service_response["privateKey"].replace("-----BEGIN RSA PRIVATE KEY-----", "").replace("-----END RSA PRIVATE KEY-----", ""),
                "deviceClientId": device_bootstrap_client_id,
                "deviceClientSecret": device_bootstrap_client_secret,
                "deviceTypeName": infra_configs[INFRA_CFG_DEVICE_TYPE_NAME],
                "hsdpOrganizationId": org_id,
                "avAutoDisconnectTimeout": infra_configs[CUSTOMER_OB_AV_AUTO_DISCONNECT_TIMEOUT],
                "editRequestApprovalTimeoutInSeconds": infra_configs[CUSTOMER_OB_EDIT_REQUEST_APPROVAL_TIMEOUT_IN_SECONDS],
                "sessionIdleTimeout": infra_configs[CUSTOMER_OB_SESSION_IDLE_TIMEOUT],
                "sessionIdleTimeoutDevice": infra_configs[CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT],
                "roccCallDesktopMaxVideoBitrate": int(infra_configs[CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS]) * 1000,
                "roccCallDesktopMaxSubscriptionBitrate": int(infra_configs[CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS]) * 1000,
                "roccCallDeviceMaxVideoBitrate": int(infra_configs[CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS]) * 1000,
                "roccCallDeviceMaxSubscriptionBitrate": int(infra_configs[CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS]) * 1000,
                "s3PresignedUrlExpiryMinutes": "30",
                "customerAnalyticsLogConsent": str(infra_configs[CUSTOMER_OB_ANALYTICS_LOG_CONSENT]),
                "roccHelpline": infra_configs[CUSTOMER_OB_ROCC_HELPLINE_NUMBER],
                "encryptionValue": encryption_value,
                "roccMediaRegion": infra_configs[CUSTOMER_OB_ROCC_MEDIA_REGION],
                "roccSignalingRegion": infra_configs[CUSTOMER_OB_ROCC_SIGNALING_REGION],
                "locale": infra_configs[CUSTOMER_OB_LOCALE],
                "kvmVendorType": infra_configs[CUSTOMER_OB_KVM_VENDOR_TYPE],
                "boxillaRestUserPassValue": infra_configs[CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE],
                "boxillaUserPassValue": infra_configs[CUSTOMER_OB_BOXILLA_USER_PASS_VALUE],
                "boxillaEmeraldAppPublicKey": infra_configs[CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY],
                "boxillaEmeraldAppUserCredentials": infra_configs[CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL],
                "maxSupportedDeviceUsbCameras": infra_configs[CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS],
                "deviceUsbCamerasLimit": infra_configs[CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING],
                "noOfPinDigits": infra_configs[CUSTOMER_OB_NO_OF_PIN_DIGITS],
                "maxNumOfConsoleSession": infra_configs[CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION],
                "maxNumOfNFCCSessionWithHardware": infra_configs[CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE],
                "maxNumOfNFCCSessionWithoutHardware": infra_configs[CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE],
                "countryIsoCode": infra_configs[CUSTOMER_OB_COUNTRY_ISO_CODE],
                "region": "ALL",
                "cryptEnabled": infra_configs[CUSTOMER_OB_CRYPT_ENABLED],
                "privacyPolicy": infra_configs[CUSTOMER_OB_PRIVACY_POLICY_URL],
                "codeGrantEnabled": "true",
                "mfaOrgPolicy": "false",
                "mfaOrgPolicyId": ""
                }

        response = post_vault_values_for_path(path=customer_name, body=data)
        if response.status_code == 204:
            LOG.info("Customer specific vault values created Successfully")
            response_success = True
        else:
            LOG.error(
                f"Error while creating Customer specific vault values: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating Customer specific vault values: {ex}")
        error_reasn = f"Error While creating Proposition {repr(ex.args)}"
    return response_success, error_reasn


def update_customer_map_in_vault_global_path(customer_name, org_id, updated_customer_map=None):
    response_success = False
    error_reasn = ""
    try:
        vault_values = get_path_specific_vault_values(
            path_name=os.environ[VAULT_ROCC_CRED_PATH])
        vault_data = vault_values.get("data")
        if updated_customer_map is None:
            updated_customer_map = create_customer_map_object(
                customer_name=customer_name, org_id=org_id, vault_values=vault_values)
        del vault_data["customerMap"]
        vault_data["customerMap"] = updated_customer_map
        response = post_vault_values_for_path(
            path=os.environ[VAULT_ROCC_CRED_PATH], body=vault_data)
        if response.status_code == 204:
            LOG.info(
                f"Customer map object in vault path: {os.environ[VAULT_ROCC_CRED_PATH]} is updated for customer: {customer_name}")
            response_success = True
        else:
            LOG.error(
                f"Failed to update Customer map vault values for customer: {customer_name} with error: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(
            f"Failed to update Customer map vault values for customer: {customer_name} with error: {ex}")
        error_reasn = f"Failed to update Customer map vault values for customer: {customer_name} with error: {repr(ex.args)}"
    return response_success, error_reasn


def create_customer_map_object(customer_name, org_id, vault_values=None):
    customer_map = {}
    if vault_values is None:
        vault_values = get_path_specific_vault_values(
            path_name=os.environ[VAULT_ROCC_CRED_PATH])
    try:
        if vault_values is not None:
            vault_data = vault_values["data"]
            if "customerMap" in vault_data:
                customer_map = vault_data["customerMap"]
        customer_map[customer_name] = org_id
    except HTTPError as ex:
        LOG.error(
            f"Exception occurred in creating Customer Map - Code: {ex.code}")
    return customer_map


def create_parent_org_specific_vault_values(profile_configs, vault_credentials_response=None):
    try:
        data = {
            "iamAuthClientId": profile_configs[VAULT_PARENT_OAUTH_CLIENT_ID],
            "iamAuthClientSecret": profile_configs[VAULT_PARENT_OAUTH_PASSWORD],
            "consoleIpAddressAndPort": "NA",
            "consoleDisconnectDelay": "NA",
            "boxillaEmeraldAppUserCredentials": "NA",
            "boxillaEmeraldAppPublicKey": "NA",
            "blackBoxAuthHeader": "NA",
            "blackBoxPassValue": "NA",
            "serviceAuthIssuer": profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
            "serviceAuthPrivateKey": profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY],
            "deviceClientId": "NA",
            "deviceClientSecret": "NA",
            "deviceTypeName": "NA",
            "hsdpOrganizationId": profile_configs[VAULT_PARENT_ORG_ID],
            "sessionIdleTimeout": "NA",
            "sessionIdleTimeoutDevice": "NA",
            "roccCallDesktopMaxVideoBitrate": 0,
            "roccCallDesktopMaxSubscriptionBitrate": 0,
            "roccCallDeviceMaxVideoBitrate": 0,
            "roccCallDeviceMaxSubscriptionBitrate": 0,
            "customerAnalyticsLogConsent": "NA",
            "roccHelpline": "NA",
            "encryptionValue": "NA",
            "roccMediaRegion": "NA",
            "roccSignalingRegion": "NA",
            "locale": "NA",
            "BBBoxillaIP": "NA",
            "BBBoxillaUser": "NA",
            "signatureAuthSecretKey": "NA",
            "signatureAuthSharedKey": "NA",
            "boxillaRestUserPassValue": "NA",
            "boxillaUserPassValue": "NA",
            "maxSupportedDeviceUsbCameras": 2,
            "deviceUsbCamerasLimit": 2,
            "mfaOrgPolicy": "NA"
        }
        response = post_vault_values_for_path(path=profile_configs[VAULT_PARENT_ORG_NAME],
                                              body=data,
                                              vault_credentials_response=vault_credentials_response)
        if response.status_code == 204:
            LOG.info("Parent vault values created Successfully")
            return True
        else:
            LOG.error(
                f"Error while creating Parent vault values: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while creating Parent vault values: {ex}")
    return False
