/*
 * Created on Thu Sep 29 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ChatProvider, RoccChatClient, useSetupRoccChatClient } from "@rocc/rocc-chat-library"
import { FeatureFlagHelper, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { isEmpty } from "lodash"
import React, { useState } from "react"
import { useSelector } from "react-redux"
import { CURRENT_APP_NAME, PARENT_STORE, REMOTE_LOAD_FAIL_MSG_SUB_STR } from "../../../constants/constants"
import { IStore } from "../../../redux/interfaces/types"
import { fetchGlobalCurrentUser, fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import { fetchCommunicationTokenService } from "./chatServices"

const ChatApp = React.lazy(() => import("roccChat/App").catch((ex) => errorLogger(`${REMOTE_LOAD_FAIL_MSG_SUB_STR} ChatApp with error: ${errorParser(ex)}`)))

/* 
- This component is used to setup other child apps like chat-app, console-app, calling-app, etc.
- Communication client is initialized here and it can be consumed by child apps
*/
const ChildAppsSetup = () => {
    const [chatClient, setChatClient] = useState({} as RoccChatClient)
    const { applicationConnectionState, forceCleanUp, featureFlags, } = useSelector((state: IStore) => ({
        applicationConnectionState: state.externalReducer.applicationConnectionState,
        forceCleanUp: state.externalReducer.forceCleanUp,
        featureFlags: state.externalReducer.featureFlags,
    }))

    const fetchCommunicationToken = async () => {
        const currentUser = fetchGlobalCurrentUser()
        /* Fetch communication token */
        const response = await fetchCommunicationTokenService(fetchGlobalURLs().COMMUNICATION_SERVICES_URL, currentUser.accessToken, currentUser.uuid)
        return response
    }

    const updateChatClient = (client: RoccChatClient) => {
        infoLogger(`For user: ${fetchGlobalCurrentUser().uuid} setting up chat client in state of app/component: ${CURRENT_APP_NAME}/ChildAppsSetup`)
        /* TODO: Remove chatClient from redux */
        setChatClient(client)
    }
    useSetupRoccChatClient({
        appName: CURRENT_APP_NAME,
        chatClient,
        fetchCommunicationClientDetails: fetchCommunicationToken,
        setChatClient: updateChatClient,
        userUuid: fetchGlobalCurrentUser().uuid,
        forceCleanUp,
        applicationConnectionState,
        onSuccess: () => void (0),
        onFailure: () => void (0),
    })

    return <ChatProvider client={chatClient}>
        {!isEmpty(chatClient) && !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_CHAT, false) ? <ChatApp parentStoreName={PARENT_STORE} /> : <></>}
    </ChatProvider>
}

export default ChildAppsSetup
