/*
 * Created on Mon May 02 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, ERoomType, EVENT_DISCONNECTED, EVENT_RECONNECTED, EVENT_RECONNECTING, IConsoleSession } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, infoLogger } from "@rocc/rocc-logging-module"
import { useEffect, useRef } from "react"
import Video, { LocalTrack, Room, TwilioError } from "twilio-video"
import { fetchGlobalConfigs } from "../../../redux/store/externalAppStates"
import { TWILIO_ERROR_CODES } from "../../constants/constants"
import { displayErrorModal } from "../../helpers/helpers"
import { toggleCameraState } from "../../helpers/multiCameraUtility"
import { addLocalTracks, closeMediaRoom, getMediaRoomConnectOptions, handleUnloadEventHandler, RenderDimensions, renewMediaRoomToken, updateConsoleMediaDetails } from "../multi-camera/MultiCameraHelper"
import { IMediaRoomConnectOptions, IMultiCamVideoTrack } from "../multi-camera/MultiCameraTypes"
import en from "../../../resources/translations/en-US"

interface IUseCameraController {
    previewTracks: LocalTrack[]
    consoleSession: IConsoleSession
    filename: string
    currentUserUuid: string
    dispatch: any
    accessToken?: string
    previewTracksRef: React.MutableRefObject<Video.LocalTrack[]>
    setVideoTracks: (videoTracks: IMultiCamVideoTrack[]) => void
    setPreviewTracks: (value: React.SetStateAction<LocalTrack[]>) => void
    setActiveRoom: (value: React.SetStateAction<Room>) => void
    setRemoteVideoStatus?: (status: boolean) => void
    setShowModal?: (state: boolean) => void
    isSyncSession: boolean
}

const UseCameraController = ({
    previewTracks, consoleSession, filename, currentUserUuid, dispatch, accessToken, previewTracksRef,
    setPreviewTracks, setVideoTracks, setActiveRoom, setRemoteVideoStatus, isSyncSession, setShowModal
}: IUseCameraController) => {
    const accessTokenRef = useRef(accessToken)
    
    const configs = fetchGlobalConfigs()
    const region = configs.SIGNALING_REGION
    let initialiseRoom = false
    const loggerInitialMessage = `${filename}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId}`
    
    useEffect(() => {
        accessTokenRef.current = accessToken
        infoLogger(`${loggerInitialMessage} CCTV app using the latest access token for ${currentUserUuid}.`)
    }, [accessToken])

    const initialiseMediaRoom = async (newRoomId?: string, newRoomToken?: string) => {
        initialiseRoom = true
        const { mediaRoomId, mediaRoomToken } = consoleSession.mediaRoomDetails
        const renderDimensions = RenderDimensions()
        const roomUniqueId = newRoomId ? newRoomId : mediaRoomId
        const roomToken = newRoomToken ? newRoomToken : mediaRoomToken
        infoLogger(`${loggerInitialMessage} - Initiating Camera stream with mediaRoomId: ${mediaRoomId}.`)
        try {
            const localTracks = previewTracks.length ? previewTracks : await addLocalTracks({ isDevice: false })
            setPreviewTracks(localTracks)
            const connectOptionParams: IMediaRoomConnectOptions = { roomName: roomUniqueId, roomType: ERoomType.GROUP, renderDimensions, localTracks, region, videoStatus: false }
            const connectOptions = getMediaRoomConnectOptions(connectOptionParams)
            infoLogger(`${loggerInitialMessage} - Connecting Camera stream with mediaRoomId: ${mediaRoomId}.`)
            const room = await Video.connect(roomToken, connectOptions)
            roomJoined(room)
            setVideoTracks([])
            setRemoteVideoStatus && setRemoteVideoStatus(false)
            updateConsoleMediaDetails({
                mediaRoomId: roomUniqueId, mediaRoomToken: roomToken,
                dispatch, contextId: consoleSession.contextId, isSyncSession,
                cameraStreamAvailable: ECameraStreamAvailable.INITIATED,
            })

        } catch (error: any) {
            errorLogger(`${filename}: For user ${currentUserUuid} - Failed to initiate Media Room: ${error}.`)
            if (error.name && error.name === "TwilioError") {
                handleErrorCode(error.code, roomUniqueId, isSyncSession)
            }
        } finally {
            initialiseRoom = false
        }
    }

    const handleErrorCode = (errorCode: number, roomUniqueId: string, isSyncSession: boolean) => {
        switch (errorCode) {
            case 20104:
                infoLogger(`${loggerInitialMessage} - Handling error code: ${errorCode} by reinitiating media room connection.`)
                reInitiateMediaRoomConnection(roomUniqueId)
                break
            case 53205:
                infoLogger(`${loggerInitialMessage} - Handling error code: ${errorCode} by setting display camera to false.`)
                toggleCameraState(consoleSession, false, !isSyncSession, dispatch)
                break
            case 53105:
                infoLogger(`${loggerInitialMessage} - Handling error code: ${errorCode} by setting display camera to false and showing pop up with sorry message.`)
                toggleCameraState(consoleSession, false, !isSyncSession, dispatch)
                if (setShowModal) {
                    setShowModal(true)
                } else {
                    const { intl } = getIntlProvider()
                    const message = `${intl.formatMessage({ id: "content.room.toggleDisplayCameraWarningMessage1", defaultMessage: en["content.room.toggleDisplayCameraWarningMessage1"] })} ${intl.formatMessage({ id: "content.room.toggleDisplayCameraWarningMessage2", defaultMessage: en["content.room.toggleDisplayCameraWarningMessage2"] })}`
                    displayErrorModal(message, false)
                }
                break
            default:
                infoLogger(`${loggerInitialMessage} - Handling error code: ${errorCode} default case.`)
                break
        }
    }

    const reInitiateMediaRoomConnection = async (mediaRoomId: string) => {
        infoLogger(`${loggerInitialMessage} - Reinitializing media room connection : ${mediaRoomId}.`)
        const mediaRoomResponse = accessTokenRef.current ? await renewMediaRoomToken(mediaRoomId, accessTokenRef.current) : await renewMediaRoomToken(mediaRoomId)
        if (mediaRoomResponse) {
            const { mediaRoomToken, mediaRoomId } = mediaRoomResponse
            updateConsoleMediaDetails({
                mediaRoomId, mediaRoomToken,
                dispatch, contextId: consoleSession.contextId, isSyncSession,
                cameraStreamAvailable: ECameraStreamAvailable.IDLE,
            })
            infoLogger(`${loggerInitialMessage} - Reconnecting to the room : ${mediaRoomId}.`)
            initialiseMediaRoom(mediaRoomId, mediaRoomToken)
        } else {
            errorLogger(`${loggerInitialMessage} - Failed to renew Media room Token.`)
        }
    }

    const roomJoined = (room: Room) => {
        infoLogger(`${loggerInitialMessage} - Connected to Room ${room.name} and waiting for the room events to be triggered.`)
        handleUnloadEventHandler({ addHandler: true, room, setActiveRoom, previewTracksRef, setPreviewTracks })
        setActiveRoom(room)
        room.on(EVENT_RECONNECTING, roomReconnecting)
        room.on(EVENT_DISCONNECTED, roomDisconnected)
        room.on(EVENT_RECONNECTED, roomReconnected)
    }

    const roomReconnecting = (error: Error) => {
        infoLogger(`${loggerInitialMessage} - Reconnecting event triggered.`)
        if (error) {
            errorLogger(`${loggerInitialMessage} - Reconnecting media room connection : ${error}.`)
        }
    }

    const roomReconnected = () => {
        infoLogger(`${loggerInitialMessage} - ${filename} camera stream video room is reconnected.`)
    }

    const roomDisconnected = (room: Room, error: TwilioError) => {
        infoLogger(`${loggerInitialMessage} - Room disconected event triggered in room ${room.sid}.`)
        closeMediaRoom({ room, setActiveRoom, previewTracksRef, setPreviewTracks })
        if (error) {
            errorLogger(`${loggerInitialMessage} - ${filename} camera stream unexpectedly disconnected: ${error}.`)
            const { ACCESS_TOKEN_EXPIRE, PARTICIPANT_SESSION_LENGTH_EXCEEDED } = TWILIO_ERROR_CODES
            if ([ACCESS_TOKEN_EXPIRE, PARTICIPANT_SESSION_LENGTH_EXCEEDED].includes(error.code)) {
                infoLogger(`${loggerInitialMessage} - ${error.code}: ${error.message} reinitiating media room connection.`)
                reInitiateMediaRoomConnection(room.name)
            } else {
                if (error.code !== TWILIO_ERROR_CODES.DUPLICATE_IDENTITY) {
                    infoLogger(`${loggerInitialMessage} - ${error.code}: ${error.message} Initializing media room.`)
                    initialiseMediaRoom()
                }
            }
        }
        handleUnloadEventHandler({ addHandler: false, room, setActiveRoom, previewTracksRef, setPreviewTracks })
    }


    return {
        initialiseRoom,
        initialiseMediaRoom
    }
}

export default UseCameraController
