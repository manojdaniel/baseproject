/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoccVideoCall, RoccAVEvents } from "@rocc/rocc-av-communication-sdk"
import { DEFAULT_CONTACT_INFO, ECallStatus, EClinicalRole, IAVCallDetails, IUserInfo } from "@rocc/rocc-client-services"
import { RoccAvRoom, RoccException } from "@rocc/rocc-common-communication-sdk"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, infoLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { Dispatch } from "react"
import { HTTP_STATUS } from "../../../constants/constants"
import { setCallMessage, setVideoCallStatus, storeCallDetails, storeOnHoldCallDetails } from "../../../redux/actions/callActions"
import { DEFAULT_ONGOING_CALL_DETAILS } from "../../../redux/reducers/callReducer"
import { fetchGlobalURLs } from "../../../redux/store/externalAppStates"
import store from "../../../redux/store/store"
import en from "../../../resources/translations/en-US"
import { endCall } from "../../../services/callServices"
import { ICallHookProps } from "../../../types/types"
import { upsertCallStatus } from "../../helpers/callUtility"
import { getDurationInFormat } from "../../helpers/dateTimeUtility"
import { getCallerID, getContextDetails, getRequesterActualUUID } from "../avmessages/messageService"

const component = "Audio Video Helper"

export const MEDIASTREAM_EXCEPTION = {
    NOTALLOWED_ERROR: "NotAllowedError",
    NOTFOUND_ERROR: "NotFoundError",
    NOTREADABLE_ERROR: "NotReadableError",
    PERMISSION_DENIED: "Permission denied by system",
}

export const evaluateInitialVideoStatus = (currentUser: IUserInfo) => {
    const state = store.getState()
    const permissions = state.externalReducer.permissions
    return !!(permissions.CALL_VIDEO_CALL && currentUser.clinicalRole === EClinicalRole.DEVICE && currentUser.secondaryUUID)
}

export const transitionResumeToConnected = (activeCall: IAVCallDetails, dispatch: Dispatch<any>) => {
    activeCall.callStatus = ECallStatus.CONNECTED
    updateCallDetails(activeCall, dispatch, true)
    dispatch(setVideoCallStatus(upsertCallStatus(activeCall.contextId, ECallStatus.CONNECTED)))
}

export const updateNumOfParticipants = (numOfParticipants: number, contextId: string, dispatch: Dispatch<any>) => {
    const { connectedCallDetails, onHoldCallDetails } = store.getState().callReducer.callDetails
    const activeCall = [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
    if (activeCall) {
        activeCall.numOfParticipants = numOfParticipants
        updateCallDetails(activeCall, dispatch, true)
    }
}

export const getAVEventType = (eventType: RoccAVEvents, callBackfn: (...args: any) => void) => {
    return { eventType, callBackfn }
}
export const leaveRoom = async (activeCall: IAVCallDetails, room: RoccAvRoom, dispatch: Dispatch<any>, vendorService: IRoccVideoCall, callEndHooks?: ICallHookProps) => {
    const state = store.getState()
    const { contextId, participants, callAcceptedTime } = activeCall
    const { COMMUNICATION_SERVICES_URL } = fetchGlobalURLs()
    const { currentUser } = state.externalReducer
    const { intl } = getIntlProvider()
    try {
        infoLogger(`Closing the Video Connection for room ${room?.name} for User ${currentUser.uuid} with contextId: ${contextId}`)
        if (callEndHooks) { callEndHooks.preHook() }
        if (contextId) {
            dispatch(setVideoCallStatus(upsertCallStatus(contextId, ECallStatus.DISCONNECTED)))
            const contact = participants?.[0] ?? DEFAULT_CONTACT_INFO
            dispatch(setCallMessage({ messageType: intl.formatMessage({ id: "content.callMessage.callEnded", defaultMessage: en["content.callMessage.callEnded"] }), message: "", contact }))
            endCall({ currentUser, communicationServiceUrl: COMMUNICATION_SERVICES_URL, contextId })
            updateCallDetails(activeCall, dispatch, false)
            const contextDetails = await getContextDetails(contextId, currentUser, COMMUNICATION_SERVICES_URL)
            if (contextDetails.status == HTTP_STATUS.OK) {
                const { data } = contextDetails
                sendLogsToAzure({ contextData: { component, event: `Web To Web call: Call Disconnected`, Call_From: getCallerID(data.requester, data.participants), Event_By: getRequesterActualUUID(data.requester), ContextId: contextId, duration: getDurationInFormat(new Date(), new Date(callAcceptedTime)) } })
            }
        }
    } catch (ex) {
        errorLogger(`An exception has occurred during Video call End : ${errorParser(ex)} for User ${currentUser.uuid} with contextId: ${contextId}`)
    } finally {
        if (room) {
            detachParticipantAndRoom(room, vendorService, currentUser, contextId)
        }
        if (callEndHooks) { callEndHooks.postHook() }
    }
}


const detachParticipantAndRoom = (room: RoccAvRoom, vendorService: IRoccVideoCall, currentUser: IUserInfo, contextId: string) => {
    try {
        vendorService.detachLocalParticipant(room)
        vendorService.detachAVParticipants(room)
        vendorService.disconnectRoom(room)
    } catch (error) {
        const err = error as RoccException
        errorLogger(`An exception has occurred while disconnecting room with status code: ${err.statusCode}, error message: ${err.errorMessage} 
        for User ${currentUser.uuid} with contextId: ${contextId}`)
    }
}

export const getActiveAndOnHoldCalls = () => {
    const state = store.getState()
    const { connectedCallDetails, onHoldCallDetails } = state.callReducer.callDetails
    return { connectedCallDetails, onHoldCallDetails }
}

export const fetchCallContextByContextId = (contextId: string) => {
    const { connectedCallDetails, onHoldCallDetails } = getActiveAndOnHoldCalls()
    return [...onHoldCallDetails, connectedCallDetails].find(callDetails => callDetails.contextId === contextId)
}

export const updateCallDetails = (activeCall: IAVCallDetails, dispatch: Dispatch<any>, isUpdate: boolean) => {
    const { connectedCallDetails, onHoldCallDetails } = getActiveAndOnHoldCalls()
    if (isUpdate) {
        if (connectedCallDetails.contextId === activeCall.contextId) {
            dispatch(storeCallDetails({ ...activeCall }))
        } else {
            dispatch(storeOnHoldCallDetails([...onHoldCallDetails.map(callDetail => callDetail.contextId === activeCall.contextId ? activeCall : callDetail)]))
        }
    } else {
        if (connectedCallDetails.contextId === activeCall.contextId) {
            dispatch(storeCallDetails(DEFAULT_ONGOING_CALL_DETAILS))
        } else {
            dispatch(storeOnHoldCallDetails([...onHoldCallDetails.filter((callDetails) => callDetails.contextId !== activeCall.contextId)]))
        }
    }
}
