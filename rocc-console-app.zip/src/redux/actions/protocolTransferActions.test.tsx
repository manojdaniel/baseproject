/*
 * Created on Mon Nov 12 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */


import { EConnectionMode, EConnectionType, EUserPresence } from "@rocc/rocc-client-services"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { EProtocolTransferSteps } from "../interfaces/types"
import { DEFAULT_CONSOLE_OPERATIONS } from "../reducers/consoleReducer"
import { resetAllStates, resetDestination, setDestinationScanner, setInitiationRoute, setProtocolTransferExitInProgress, setProtocolTransferStatus, setProtocolTransferStep, setSourceScanner, updateDestinationScanners } from "./protocolTransferActions"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

const roomDetails = {
    identity: {
        id: 1,
        uuid: "",
        name: "",
        address: "",
    },
    presenceData: {
        presence: EUserPresence.AVAILABLE,
        mapId: "",
    },
    address: "",
    locationId: 1,
    modalityId: "",
    modality: "",
    favourite: true,
    phone1: "",
    disabled: true,
    isConnecting: true,
    loggedInTech: { techUuid: "", techName: "" },
    isRoomStarred: true,
    monitorsCount: 1,
    phoneNumber: ""
}

describe("protocolTransferActions tests", () => {
    const store = mockStore({
        protocolTransferReducer: {
            currentStep: EProtocolTransferSteps.SelectDestinationScanner
        },
        consoleReducer: {
            consoleMessages: [],
            consoleSessions: [{ contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC },],
            commandCenterDetails: { initialised: false, commandCenterSeat: { organizationId: "", seatName: "", receivers: [] } },
            consoleOperation: DEFAULT_CONSOLE_OPERATIONS,
        }
    })
    beforeEach(() => {
        store.clearActions()
    })
    it("setProtocolTransferStatus is defined", () => {
        store.dispatch(setProtocolTransferStatus(true) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("setProtocolTransferExitInProgress is defined", () => {
        store.dispatch(setProtocolTransferExitInProgress(true) as any)
        expect(store.getActions()).toEqual([{ "payload": { "protocolTransferExit": true }, "type": "GLOBAL_SET_PROTOCOL_TRANSFER_EXIT" }])
        store.clearActions()
    })
    it("updateDestinationScanners is defined", () => {
        store.dispatch(updateDestinationScanners("") as any)
        expect(store.getActions()).toEqual([{ "selectedDestination": "", "type": "UPDATE_DESTINATION_SCANNERS" }])
        store.clearActions()
    })
    it("setInitiationRoute is defined", () => {
        store.dispatch(setInitiationRoute("") as any)
        expect(store.getActions()).toEqual([{ "payload": { "initiationRoute": "" }, "type": "GLOBAL_SET_INITIATION_ROUTE" }])
        store.clearActions()
    })
    it("setSourceScanner is defined", () => {
        store.dispatch(setSourceScanner(roomDetails) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("setDestinationScanner is defined", () => {
        store.dispatch(setDestinationScanner(roomDetails) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("setProtocolTransferStep is defined", () => {
        store.dispatch(setProtocolTransferStep(1) as any)
        expect(store.getActions()[0].payload.currentStep).toBe(1)
        store.clearActions()
    })

    it("updateDestinationScanners is defined", () => {
        store.dispatch(updateDestinationScanners("") as any)
        expect(store.getActions()[0].selectedDestination).toBe("")
        store.clearActions()
    })
    it("resetAllStates is defined", () => {
        store.dispatch(resetAllStates() as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
})
describe("protocolTransferActions tests", () => {
    let store = mockStore({
        protocolTransferReducer: {}
    })
    beforeEach(() => {
        store.clearActions()
    })
    it("resetDestination  is defined", () => {
        store.dispatch(resetDestination() as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("resetDestination when selected destination is defined", () => {
        store = mockStore({
            protocolTransferReducer: {
                selectedDestination: "destination"
            }
        })
        store.dispatch(resetDestination() as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("resetAllStates when selected destination is defined", () => {
        store.dispatch(resetAllStates() as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("resetAllStates when selected source is defined", () => {
        store = mockStore({
            protocolTransferReducer: {
                selectedSource: "source"
            }
        })
        store.dispatch(resetAllStates() as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
})
