/*
 * Created on Tue May 25 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as FeatureFlagHelper from "./featureFlag"
import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { EClinicalRole, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { ADMIN_ROUTE, CONSULTS_ROUTE, IDN_ROUTE } from "../../constants/routes"
import { INIT_CURRENT_USER_PROFILE } from "../../redux/reducers/userReducer"
import { INIT_URLS } from "../../redux/reducers/configReducer"
import { computeFeatureFlags } from "./featureFlag"

jest.mock("../../redux/store/store",()=>({
    getState: jest.fn().mockReturnValue({
        userReducer:{currentUser:{accessToken:"token"}}
    })
}))
describe("Feature Flags helper", () => {
    const middlewares = [thunk]
    const mockStore = configureMockStore(middlewares)

    it("should initializeFeatureFlagClient", () => {
        const mockState = {
            featureFlagsReducer: {},
        }

        const store = mockStore(mockState)

        const spy = jest.spyOn(FeatureFlagHelper, "initializeFeatureFlagClient")
        FeatureFlagHelper.initializeFeatureFlagClient({
            dispatch: store.dispatch,
            currentUser: INIT_CURRENT_USER_PROFILE,
            defaultFeatureFlags: {},
            ffConfig: {},
            orgIdentifier: "",
            urls: INIT_URLS
        })
        expect(spy).toHaveBeenCalled()
        spy.mockRestore()
    })
    it("should determine route for admin", () => {
        expect(FeatureFlagHelper.determineRoute(EClinicalRole.ADMIN)).toBe(ADMIN_ROUTE)
    })
    it("should determine route for technologist radconnect", () => {
        expect(FeatureFlagHelper.determineRoute(EClinicalRole.TECHNOLOGIST)).toBe(CONSULTS_ROUTE)
    })
    it("should determine route for expert user without radconnect", () => {
        const mockState = {
            featureFlagsReducer: {
                featureFlags: {
                    [ROCC_FEATURES.FLAG_RADCONNECT]: false
                },
            }
        }
        mockStore(mockState)
        const spy = jest.spyOn(FeatureFlagHelper, "determineRoute")
        expect(FeatureFlagHelper.determineRoute(EClinicalRole.EXPERTUSER)).toBe(IDN_ROUTE)
        spy.mockRestore()
    })
    it("should compute feature flag", () => {
        const featureFlags = computeFeatureFlags({ "rocc-pp-camera-mode": true })
        expect(featureFlags).toBeDefined()

    })

})
