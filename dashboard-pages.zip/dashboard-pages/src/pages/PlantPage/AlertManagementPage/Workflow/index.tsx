// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { Table } from "antd";
import { Button, Upload } from "antd";
import Dropdown from "components/Dropdown";
import type { DatePickerProps } from "antd";
import { DatePicker, Space } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import WorkflowTable from "table/WorkflowTable";
import RadioGroup from "components/RadioGroup";
import InputField from "components/InputField";
import iconcalendar from "../../../../assets/images/icon_calendar.svg";
import AlertMangementDatePicker from "../../../../components/AlertMangementDatePicker";
import {
	getWorkflowAlertDetails,
	getWorkflowRequestLog,
	getWorkflowSearchData,
	getWorkflowAttachementDetails,
	getWorkflowUserRole,
	setWorkflowSearchDataEmpty,
	setRefreshPmtPage,
	setRefreshAlertListPage,
	setRefreshMyTaskPage,
	uploadAttachements,
	resetUploadAttachements,
	updateWorkflowStatus,
	resetUpdateWorkflowStatus,
	getGlobalSelecetedRegion,
	getGlobalSelecetedAffiliate,
	getGlobalSelecetedPlant,
	getGlobalSelecetedAsset,
	getPlotDeviationModel,
	getIBMAlertDetailsByAlertId,
	getConsultSomeone,
	getCommonFromDate,
	getCommonToDate,
	getBreadCrumbDate,
	getTodayDate
} from "../../../../redux/reducers/CommonReducer";
import RequestLogTable from "table/RequestLogTable";
import axios from "axios";
import { Api } from "../../../../utility/api";
import PushNotification from "components/PushNotification";
import Loader from "components/Loader";
import "./Workflow.scss";
import { encryptRSAData } from "../../../../utility/rsa";

interface Props {
	alertId: any;
	setShowWorkflow: any;
	currentStage: string;
}

const Workflow = () => {
	// const [myalertdata, setMyalertdata] = useState<any>();
	let navigate = useNavigate();
	const [selectAssignee, setSelectedAssignee] = useState<any>("");
	const [showPopup, setShowPopup] = useState<any>(false);
	const [selectAlertClass, setSelectAlertClass] = useState<any>();
	const [selectConsultSomeone, setSelectConsultSomeone] = useState<any>();

	const [selectLongLead, setSelectLongLead] = useState<any>();
	const [selectUserType, setSelectUserType] = useState<any>("");
	const [selectedImage, setSelectedImage] = useState<any>("");
	const inputRef = useRef<any>();

	const [finishStatus, setfinishStatus] = useState(false);
	const [details, setDetails] = useState("");
	const [comments, setComments] = useState("");
	const [date, setDate] = useState("");

	const [labelDate, setLabelDate] = useState(false);
	const [query, setquery] = useState("");
	const [assignedPerson, setAssignedPerson] = useState([]);
	const [consultPerson, setConsultPerson] = useState([]);

	const [assigneeRadio, setAssigneeRadio] = useState(false);
	const [consultRadio, setConsultRadio] = useState(false);
	const [loading, setLoading] = useState<any>(false);
	const [submitLoading, setSubmitLoading] = useState<any>(false);

	const [showDate, setShowDate] = useState<any>(false);
	const [detailErrorMsg, setDetailErrorMsg] = useState(false);
	const [commentErrorMsg, setCommentErrorMsg] = useState(false);
	const [assigneeAccepted, setAssigneeAccepted] = useState("");

	const [alertId, setAlertId] = useState("");
	const [currentStage, setCurrentStage] = useState("");

	const {
		workflowAlertDetails,
		loadingWorkflowAlertDetails,
		workflowRequestLog,
		loadingWorkflowRequestLog,
		workflowSearchData,
		loadingWorkflowSearchData,
		workflowAttachementDetails,
		loadingWorkflowAttachementDetails,
		workflowUserRole,
		loadingWorkflowUserRole,
		uploadAttachementStatus,
		loadingUploadAttachementStatus,
		WorkflowStatus,
		loadingWorkflowStatus,
		loggedInUserDetails,
		userName,
		IBMAlertDetailsByAlertId
	} = useSelector((state: any) => ({
		workflowAlertDetails: state.Common.workflowAlertDetails,
		workflowRequestLog: state.Common.workflowRequestLog,
		workflowSearchData: state.Common.workflowSearchData,
		workflowAttachementDetails: state.Common.workflowAttachementDetails,
		workflowUserRole: state.Common.workflowUserRole,

		loadingWorkflowAlertDetails: state.Common.loadingWorkflowAlertDetails,
		loadingWorkflowRequestLog: state.Common.loadingWorkflowRequestLog,
		loadingWorkflowSearchData: state.Common.loadingWorkflowSearchData,
		loadingWorkflowAttachementDetails:
			state.Common.loadingWorkflowAttachementDetails,
		loadingWorkflowUserRole: state.Common.loadingWorkflowUserRole,

		uploadAttachementStatus: state.Common.uploadAttachementStatus,
		loadingUploadAttachementStatus: state.Common.loadingUploadAttachementStatus,
		WorkflowStatus: state.Common.WorkflowStatus,
		loadingWorkflowStatus: state.Common.loadingWorkflowStatus,

		loggedInUserDetails: state.Common.loggedInUserDetails,
		userName: state.Common.userName,

		IBMAlertDetailsByAlertId: state.Common.IBMAlertDetailsByAlertId,
	}));

	let dispatch = useDispatch();
	let location = useLocation();

	useEffect(() => {
		if (location.state && location.state.alertId !== undefined) {
			setAlertId(location.state.alertId);
			setCurrentStage(location.state.currentStage);
		}
	}, []);

	useEffect(() => {
		if (alertId !== "") {
			dispatch(getWorkflowAlertDetails(encryptRSAData(`alertId=${alertId}`)));
			dispatch(getWorkflowRequestLog(encryptRSAData(`alertId=${alertId}`)));
			dispatch(getIBMAlertDetailsByAlertId(encryptRSAData(`alertId=${alertId}`)));
			// dispatch(getWorkflowSearchData(alertId));
			dispatch(
				getWorkflowAttachementDetails(encryptRSAData(`alertId=${alertId}`))
			);
			dispatch(getWorkflowUserRole(""));
			dispatch(setWorkflowSearchDataEmpty(""));
		}
	}, [alertId]);

	useEffect(() => {
		//response from backend [{ "retVal": 1, "retMsg": "AHC Alert Attachment uploaded Successfully" }]
		if (uploadAttachementStatus.length > 0) {
			if (uploadAttachementStatus[0].retMsg === "AHC Alert Attachment uploaded Successfully") {
				PushNotification("success", uploadAttachementStatus[0].retMsg);
				dispatch(getWorkflowAttachementDetails(encryptRSAData(`alertId=${alertId}`)));
				dispatch(resetUploadAttachements(""));
			}
		}
	}, [uploadAttachementStatus]);

	const userTypeDropdown = [
		{
			value: "EmpID Id",
			label: "EmpID Id",
		},
		{
			value: "Domain Login",
			label: "Domain Login",
		},
		{
			value: "Email Id",
			label: "Email Id",
		},
		{
			value: "Assigned AHC Member",
			label: "Assigned AHC Member",
		},
	];

	const assigneOption = [
		{ label: "Assign To", value: "Assign To" },
		{ label: "Close", value: "Close" },
	];
	const assigneAccepted = [
		{ label: "Yes", value: "Yes" },
		{ label: "No", value: "No" },
	];

	const consultOption = [
		{ label: "Yes", value: "Yes" },
		{ label: "No", value: "No" },
	];

	const alertOption = [
		{ label: "True Positive", value: "TRUE POSITIVE" },
		{ label: "False Positive", value: "FALSE POSITIVE" },
	];

	const longLeadOption = [
		{ label: "Yes", value: "Yes" },
		{ label: "No", value: "No" },
	];

	const handleChangeAssignee = (value: any) => {
		setSelectedAssignee(value);
		if (value === "Assign To") {
			setAssigneeRadio(true);
			openAssetPopup();
		} else {
			setAssignedPerson([]);
			//setConsultPerson([]);
		}
	};
	const handleAssigneeAccepted = (value: any) => {
		setAssigneeAccepted(value);
		// if (value === "Assign To") {
		//     setAssigneeRadio(true)
		//     openAssetPopup()
		// }
		// else {
		//     setAssignedPerson([])
		// }
	};

	const handleChangeConsultSomeone = (value) => {
		setSelectConsultSomeone(value);
		if (value === "Yes") {
			setConsultRadio(true);
			openAssetPopup();
		} else {
			setConsultPerson([]);
		}
	};

	const handleChangeAlertClass = (value) => {
		setSelectAlertClass(value);
		if (value === "FALSE POSITIVE") {
			setShowDate(false);
		}
	};

	const handleChangeLongLead = (value) => {
		setSelectLongLead(value);
		if (value === "Yes") {
			setShowDate(true);
		} else {
			setShowDate(false);
		}
	};

	const openAssetPopup = () => {
		setShowPopup(true);
		dispatch(setWorkflowSearchDataEmpty(""));
	};

	const closeAssetPopup = () => {
		setShowPopup(false);
		setConsultRadio(false);
		setAssigneeRadio(false);
		dispatch(setWorkflowSearchDataEmpty(""));
		setquery("");
	};

	const handleUserTypeSelection = (e: any) => {
		setSelectUserType(e);
	};

	const clearSlection = () => {
		setSelectUserType("");
		setquery("");
		dispatch(setWorkflowSearchDataEmpty(""));
	};

	const submitSelection = (e: any) => {
		if (query !== "") {
			dispatch(
				getWorkflowSearchData(encryptRSAData(`searchBy=${selectUserType.value}&searchText=${query}&selectedUser=${18}`))
			);
		}
	};

	const handleDetailsChange = (event) => {
		const newName = event.target.value.replace(/[^a-zA-Z\s]/g, "");
		setDetails(newName);
	};

	const handleCommentsChange = (event) => {
		const newName = event.target.value.replace(/[^a-zA-Z\s]/g, "");
		setComments(newName);
	};

	const handleImageOnChange = async (e) => {
		// let value = URL.createObjectURL(e.target.files[0]);
		// alert(value)
		setSelectedImage(e.target.files[0]);
	};

	// useEffect(() => {
	//[{ "retVal": 1, "retMsg": "AHC Alert Attachment uploaded Successfully" }]
	// dispatch(getWorkflowAttachementDetails(alertId));
	//     dispatch(resetUploadAttachements(""));

	// }, [loadingUploadAttachementStatus]);

	// { "successFlag": true, "responseMsg": null }

	useEffect(() => {
		if (Object.keys(WorkflowStatus).length > 0) {
			// setShowWorkflow(false)
			if (WorkflowStatus.successFlag === true) {
				PushNotification("success", "Success");
				handlePageSucces();
				dispatch(resetUpdateWorkflowStatus(""));
			} else {
				PushNotification("error", WorkflowStatus.responseMsg);
				dispatch(resetUpdateWorkflowStatus(""));
			}
		}
	}, [WorkflowStatus]);

	const uploadImage = async () => {
		if (selectedImage !== "") {
			setSelectedImage("");
			if (inputRef.current !== null) {
				inputRef.current.value = "";
			}

			let base64Transform = await toBase64(selectedImage);

			let date = moment(new Date()).format("YYYY-MM-DD");
			let data = {
				alertId: alertId,
				submittedBy: "",
				submittedOn: date,
				modifiedBy: "",
				modifiedOn: date,
				currentStage: currentStage !== "" ? currentStage : null,
				attachmentFile: base64Transform,
				attachmentURL: selectedImage?.name,
				file_Name: selectedImage?.name,
				file_Type: selectedImage?.type,
			};
			dispatch(uploadAttachements(data));
			// setLoading(true)
			// axios({
			//     method: 'post',
			//     url: Api.updateAhcAttachement,
			//     headers: {
			//         'Content-Type': 'application/json',
			//     },
			//     data: data
			// }).then((response) => {
			// dispatch(getWorkflowAttachementDetails(alertId));
			//     setLoading(false)

			// }).catch((error) => {
			//     setLoading(false)

			// })
		}
	};

	const handleDateChanged = (value: any) => {
		let date = moment(value).format("YYYY-MM-DD");
		setDate(date);
		setLabelDate(false);
	};

	const handleAssigneeRowSelection = (data: any) => {
		let list: any = [];
		list.push(data);
		// alert(list)
		setAssignedPerson(list);
		closeAssetPopup();
	};
	const handleConsultRowSelection = (data: any) => {
		let list: any = [];
		list.push(data);
		setConsultPerson(list);
		dispatch(
			getConsultSomeone(encryptRSAData(`consultEmpId=${list[0]?.empID}&alertId=${workflowAlertDetails.alertId}`))
		);
		closeAssetPopup();
	};

	const handleQueryChange = (e: any) => {
		setquery(e.target.value);
		// setData(results);

	};

	const toBase64 = (file: any) =>
		new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onload = () => resolve(reader.result.split(",")[1]);
			reader.onerror = reject;
		});

	const handleSubmit = () => {
		if (assignedPerson.length < 1) {
			PushNotification("warning", "Please Choose Assignee");
			return;
		} else if (selectConsultSomeone === "Yes" && consultPerson.length < 1) {
			PushNotification("warning", "Please Choose Consult Person");
			return;
		} else if (details === "") {
			setDetailErrorMsg(true);
		} else if (comments === "") {
			setCommentErrorMsg(true);
			setDetailErrorMsg(false);
		} else {
			setDetailErrorMsg(false);
			setCommentErrorMsg(false);
			let todaydate = moment(new Date()).format("YYYY-MM-DD");
			let data = {
				action: selectAssignee,
				actionTakenByUserId: "", //login Id
				sendToUserEmpId: assignedPerson[0].empID, //assignee Id
				comments: comments,
				anomalyFeedback: false, //need to check
				targetDate: date !== "" ? date : todaydate,
				requireLeadAction: selectLongLead === "Yes" ? true : false,
				assigneeDepartment: assignedPerson[0].deptFullDesc,
				alertId: alertId,
				actionTakenByUserFullName: userName,
				assigneeAccepted: workflowUserRole !== "" && workflowUserRole !== "Digitalization Champion" ? assigneeAccepted : false,
				consultSomeone: selectConsultSomeone === "Yes" ? true : false,
				consultSomeoneEmpId:
					consultPerson.length > 0 ? consultPerson[0].empID : 0,
			};
			dispatch(updateWorkflowStatus(data));
			// handleApiCall(data)
		}

		if (selectConsultSomeone === "Yes" && consultPerson.length > 0) {
			handleConsultSomeoneSubmit()
		}
	};
	const handleClose = () => {
		setCommentErrorMsg(false);
		setDetailErrorMsg(false);
		let todaydate = moment(new Date()).format("YYYY-MM-DD");
		let data = {
			action: selectAssignee,
			actionTakenByUserId: "", //login Id
			sendToUserEmpId: "", //assignee Id
			comments: comments,
			anomalyFeedback: false, //need to check
			targetDate: date !== "" ? date : todaydate,
			requireLeadAction: selectLongLead === "Yes" ? true : false,
			assigneeDepartment: "",
			alertId: alertId,
			actionTakenByUserFullName: userName,
			assigneeAccepted: workflowUserRole !== "" && workflowUserRole !== "Digitalization Champion" ? assigneeAccepted : false,
			consultSomeone: selectConsultSomeone === "Yes" ? true : false,
			consultSomeoneEmpId: 0,
		};
		dispatch(updateWorkflowStatus(data));

		if (selectConsultSomeone === "Yes" && consultPerson.length > 0) {
			handleConsultSomeoneSubmit()
		}
	};

	const handlePlantUser = () => {
		setCommentErrorMsg(false);
		setDetailErrorMsg(false);
		let todaydate = moment(new Date()).format("YYYY-MM-DD");
		let data = {
			action: "",
			actionTakenByUserId: "", //login Id
			sendToUserEmpId: "", //assignee Id
			comments: comments,
			anomalyFeedback: false, //need to check
			targetDate: date !== "" ? date : todaydate,
			requireLeadAction: selectLongLead === "Yes" ? true : false,
			assigneeDepartment: "",
			alertId: alertId,
			actionTakenByUserFullName: userName,
			assigneeAccepted: assigneeAccepted === "Yes" ? true : false,
			consultSomeone: false,
			consultSomeoneEmpId: 0,
		};
		dispatch(updateWorkflowStatus(data));
	};

	const handleConsultSomeoneSubmit = () => {
		//console.log('---->' + 'consult someone')
		dispatch(getConsultSomeone(encryptRSAData(`consultEmpId=${list[0]?.empID}&alertId=${workflowAlertDetails.alertId}`)));
	}


	const downloadFile = (base64Data, contentType, fileName) => {
		const linkSource = `data:${contentType};base64,${base64Data}`;
		const downloadLink = document.createElement("a");

		downloadLink.href = linkSource;
		downloadLink.download = fileName;
		downloadLink.click();
	};

	const handleApiCall = (data: any) => {
		setSubmitLoading(true);
		axios({
			method: "post",
			url: Api.updateIbmWorkflow,
			headers: {
				"Content-Type": "application/json",
			},
			data: data,
		})
			.then((response) => {
				if (response.status === 200) {
					if (response.data.successFlag === true) {
						// setShowWorkflow(false)
						handlePageSucces();
					} else {
						PushNotification("error", response.data.responseMsg);
					}
				}
				setSubmitLoading(false);
			})
			.catch((error) => {
				setSubmitLoading(false);
			});
	};

	const handlePageSucces = () => {
		if (location.state && location.state.pageName === "pmt") {
			dispatch(setRefreshPmtPage(true));
		}
		if (location.state && location.state.pageName === "alertList") {
			dispatch(setRefreshAlertListPage(true));
		}
		if (location.state && location.state.pageName === "myTask") {
			dispatch(setRefreshMyTaskPage(true));
		}
		navigate(-1);
	};

	const HeaderText = ({ label }) => {
		return <div>{label}</div>;
	};

	const List = ({ data, name, type }) => {
		// alert('hii')
		return (
			<div className="w-tablebody">
				<div>{name}</div>
				<div>{type}</div>
				<div><button onClick={() => downloadFile(data, type, name)} className="cus-button">View</button></div>
			</div>
		);
	};

	const AttacheMentComponent = ({ data }: any) => {
		return (
			<>
				<div className="w-tablehead">
					<HeaderText label="File Name" />
					<HeaderText label="File Type" />
					<HeaderText label="View" />
				</div>
				{data &&
					data.map((item: any) => (
						<List
							data={item.attachment_File}
							name={item.file_Name}
							type={item.file_Type}
						/>
					))}
			</>
		);
	};

	const Popup = () => {
		return (
			<div id="asset-popup">
				<div id="ap-content">
					<span class="ap-closePopup" onClick={() => { setShowPopup(false); setAssigneeRadio(false); }}>
						x
					</span>
					<div className="ap-filter">
						<div className="ap-title">SEARCH CRITERIA</div>
						<div className="w-pop-filter-right">
							<div>
								<p> Search By :</p>
								<Dropdown
									name={"Select user"}
									handleChange={handleUserTypeSelection}
									options={userTypeDropdown}
									defaultValue={""}
									value={selectUserType}
								/>
							</div>
							{selectUserType !== "" ?
								<>
									<input
										type="search"
										value={query}
										onChange={handleQueryChange}
										placeholder="Search..."
										onKeyPress={handleSearchKeyPress}
										autoFocus="autoFocus"
									/>
									<button onClick={submitSelection}>SEARCH</button>
									<button onClick={clearSlection}>CLEAR </button>
								</>
								: null}
						</div>
					</div>

					<div>
						<WorkflowTable
							data={workflowSearchData}
							handleUpdate={
								assigneeRadio
									? handleAssigneeRowSelection
									: handleConsultRowSelection
							}
							radio={true}
							loading={loadingWorkflowSearchData}
						/>
					</div>
				</div>
			</div>
		);
	};

	const Card = ({ label, value }) => {
		return (
			<React.Fragment>
				<div>{label}</div>
				<div>{value}</div>
			</React.Fragment>
		);
	};

	const handleSearchKeyPress = (event) => {
		const keyCode = event.keyCode || event.which;
		const keyValue = String.fromCharCode(keyCode);
		if (!/^[a-z0-9@.]+$/i.test(keyValue)) event.preventDefault();
	};

	const navigatePlotpage = (item: any) => {

		let list: any = [];
		if (item[0].influencingSensor1 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor1,
				color: "#E35205",
			};
			list.push(data);
		}
		if (item[0].influencingSensor2 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor2,
				color: "#3BB44A",
			};
			list.push(data);
		}
		if (item[0].influencingSensor3 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor3,
				color: "#939598",
			};
			list.push(data);
		}
		if (item[0].influencingSensor4 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor4,
				color: "#009FDF",
			};
			list.push(data);
		}
		if (item[0].influencingSensor5 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor5,
				color: "#ffae21",
			};
			list.push(data);
		}
		if (item[0].influencingSensor6 !== "N/A") {
			let data = {
				value: "",
				label: item[0].influencingSensor6,
				color: "#4e79a7",
			};
			list.push(data);
		}
		//console.log(moment(item[0].fromDate).format("YYYY-MM-DD"))
		dispatch(getCommonFromDate(moment(item[0].fromDate).format("YYYY-MM-DD")));
		dispatch(getCommonToDate(moment(item[0].toDate).format("YYYY-MM-DD")));
		dispatch(getBreadCrumbDate({ id: "", updatedDate: "" }));
		dispatch(getTodayDate(""));
		dispatch(getGlobalSelecetedRegion({ value: item[0].regionId, label: item[0].regionName, }));
		dispatch(getGlobalSelecetedAffiliate({ value: item[0].affiliateId, label: item[0].affiliateName, }));
		dispatch(getGlobalSelecetedPlant({ value: item[0].plantId, label: item[0].plantName }));
		dispatch(getGlobalSelecetedAsset({ value: item[0].assetId, label: item[0].assetId }));
		navigate(`/assets/plots`, { state: { data: item[0].assetId, data2: item[0].modelId, data3: item[0].modelName, data4: list, } });
	}

	useEffect(() => {
		console.log(typeof (selectAssignee))
	}, [selectAssignee])


	return (
		<div id="workflow">
			<div className="common-box-inner">
				<div className="title"> ALERT DETAILS</div>
				<div className="workflow-content">
					{workflowAlertDetails !== undefined &&
						Object.keys(workflowAlertDetails).length > 0 ? (
						<>
							<div>
								<Card label={"Alert ID"} value={workflowAlertDetails.alertId} />
							</div>

							<div>
								<Card
									label={"Alert TimeStamp"}
									value={workflowAlertDetails.alertTimestamp}
								/>
							</div>
							<div>
								<Card label={"Asset Id"} value={workflowAlertDetails.assetId} />
							</div>

							<div>
								<Card
									label={"Anomaly Category"}
									value={workflowAlertDetails.anomalyCategory}
								/>
							</div>
							<div>
								<Card
									label={"Asset Description"}
									value={workflowAlertDetails.assetName}
								/>
							</div>
							<div>
								<div>Dashbord URL </div>
								<div style={{ cursor: "pointer" }} onClick={() => navigatePlotpage(IBMAlertDetailsByAlertId)}>Click here to go Plot page</div>
							</div>
						</>
					) : null}
				</div>
			</div>

			<div className="workflow-options">
				<div className="common-box-inner">
					{/* {loadingWorkflowStatus || loadingWorkflowUserRole ? <Loader /> : null} */}
					<div className="title">ACTION</div>
					{loadingWorkflowStatus || loadingWorkflowUserRole ? <Loader /> :
						<>
							{workflowUserRole === "" ?
								<div style={{ alignSelf: 'center' }}>User not found In IBM/BPM Portal. Please contact IBM/BPM Administrator/</div>
								: null}
							<div className="wo-action">
								{workflowUserRole !== "" && workflowUserRole !== "Digitalization Champion" ? (
									<RadioGroup
										title={"Assigmnet Accepted"}
										options={assigneAccepted}
										name="Assigmnet Accepted"
										defaultOption=""
										onChange={handleAssigneeAccepted}
									/>
								) : null}
								{workflowUserRole === "Digitalization Champion" ? (
									<RadioGroup
										title={"Select Your Action"}
										options={assigneOption}
										name="Select Your Action"
										defaultOption=""
										onChange={handleChangeAssignee}
									/>
								) : null}
								{selectAssignee === "Close" || (workflowUserRole !== "Digitalization Champion" && workflowUserRole !== "") ? (
									<RadioGroup
										title={"Alert Class"}
										options={alertOption}
										name="Alert Class"
										defaultOption=""
										onChange={handleChangeAlertClass}
									/>
								) : null}
								<div className="true-box">
									{selectAlertClass === "TRUE POSITIVE" ? (
										<RadioGroup
											title={
												"Does the alert required long lead action (Exp,S/D,T/A,spare part procurement ,etc....)?"
											}
											options={longLeadOption}
											name="Long Lead Action"
											defaultOption=""
											onChange={handleChangeLongLead}
										/>
									) : null}
									{showDate ? (
										<div className="w-calendar">
											<label>Select Date</label>
											<div
												onClick={() => {
													setLabelDate(true);
												}}
												className="w-left"
											>
												<div>{date}</div>
												<a className="mobile-calendar">
													<img src={iconcalendar} title="calendar" />
												</a>
											</div>
											{labelDate ? (
												<div id="calendar-popup">
													<div className="calendar-box">
														<AlertMangementDatePicker
															//  selectedDate={date}
															handleDateChange={handleDateChanged}
														/>
													</div>
												</div>
											) : null}
										</div>
									) : null}
								</div>
							</div>
							{assignedPerson.length > 0 ? (
								<div className="wo-actiontable">
									<div className="title">ALERT ASSIGNED TO</div>
									<WorkflowTable
										data={assignedPerson}
										handleUpdate={() => { }}
										radio={false}
									/>
								</div>
							) : null}
							<div className="wo-action">
								{workflowUserRole === "Digitalization Champion" ? (
									<RadioGroup
										title={"Consult Someone ?"}
										options={consultOption}
										name="Consult Someone"
										defaultOption={"No"}
										onChange={handleChangeConsultSomeone}
									// disabled={
									// 	selectAssignee === ""
									// 		? true
									// 		: false
									// }
									// disabled={
									// 	selectAssignee === "Close" || selectAssignee === ""
									// 		? true
									// 		: false
									// }
									/>
								) : null}
							</div>
							{consultPerson.length > 0 ? (
								<div className="wo-actiontable">
									<div className="title">
										ALERT FORWARDED TO (Only For Information Purpose)
									</div>
									<WorkflowTable
										data={consultPerson}
										handleUpdate={() => { }}
										radio={false}
									/>
								</div>
							) : null}
							<br />
							{workflowUserRole !== "" ?
								<>
									<div className="title">COMMENTS</div>
									<div className="wo-form">
										<div>
											<label>Action Detail</label>
											<InputField
												multiline
												type="text"
												value={details}
												onChange={handleDetailsChange}
												placeholder=""
											/>
											{detailErrorMsg === true ? (
												<span className="PmtErrorMsgcomments">Please fill Action details</span>
											) : (
												""
											)}
										</div>
										<div>
											<label>Comments</label>
											<InputField
												multiline
												value={comments}
												onChange={handleCommentsChange}
												placeholder=""
											/>
											{commentErrorMsg === true ? (
												<span className="PmtErrorMsgcomments">Please fill comments</span>
											) : (
												""
											)}
										</div>
										{selectAssignee !== "" ? (
											<button
												onClick={() => {
													selectAssignee === "Close" ? handleClose() : handleSubmit();
												}}
											>
												{selectAssignee === "Close" ? "Close" : "Submit"}
											</button>
										) : null}
										{consultPerson.length > 0 && selectAssignee === "" ? (
											<button
												onClick={() => handleConsultSomeoneSubmit()}
											>
												Submit
											</button>
										) : null}
										{workflowUserRole !== "" && workflowUserRole !== "Digitalization Champion" ? (
											<button onClick={() => handlePlantUser()}>Submit</button>
										) : null}
									</div>
								</>
								: null}
							{showPopup === true ? <Popup /> : null}
						</>}
				</div>
			</div>
			<div className="workflow-attachments">
				<div className="common-box-inner">
					<div className="title">ATTACHMENTS</div>
					<div className="w-attach">
						<label>File Name</label>
						<input
							type="file"
							name="myImage"
							className="custom-file-input"
							// value={selectedImage}
							onChange={(event) => handleImageOnChange(event)}
							ref={inputRef}
						/>
						<button onClick={() => uploadImage()}> Upload </button>
					</div>
					{loadingWorkflowAttachementDetails ? (
						<Loader />
					) : (
						<div className="w-attach-table">
							<AttacheMentComponent data={workflowAttachementDetails} />
						</div>
					)}
				</div>

			</div>
			<div className="workflow-table">
				<div className="common-box-inner">
					<div className="title">REQUEST LOG</div>
					<RequestLogTable
						data={workflowRequestLog}
						loading={loadingWorkflowRequestLog}
					/>
				</div>
			</div>
		</div>
	);
};
export default Workflow;

{
	/* <input type="upload" /> */
}
{
	/* <Upload multiple action="http://localhost:3000/" listType="text">
					<button>Upload File</button>
				</Upload> */
}

// useEffect(() => {
//     let mydata = data.map(
//         function (item: any) {
//             return {
//               AlertID: item.AlertID, AlertTimeStamp: moment(new Date(`${item.AlertTimeStamp}`)).format("DD/MM/YYYY HH:MM:SS A"), AnomolyType:item.AnomolyType,AssetID:item.AssetID, AnomolyCategory: item.AnomolyCategory , AssetDescription:item.AssetDescription
//           };
//         });
//         setMyalertdata(mydata);
// }, [data]);

//  <br></br>
//
