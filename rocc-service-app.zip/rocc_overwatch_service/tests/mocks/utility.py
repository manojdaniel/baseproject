def clear_value_for_keys(dictionary, target_keys):
    return {key: dictionary[key] if key not in target_keys else "" for key in dictionary}


def drop_keys(dictionary, target_keys):
    return {key: dictionary[key] for key in dictionary if key not in target_keys}
