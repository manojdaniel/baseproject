/*
 * Created on The Oct 19 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, IContactInfo, IRoomDetails, IParentStore } from "@rocc/rocc-client-services"
import React, { useState, useEffect } from "react"
import { useSelector } from "react-redux"
import { SyncClient } from "twilio-sync"
import { COMMUNICATION_PRESENCE_SUBSCRIPTION_EP } from "../../constants/endpoints"
import { getSingleKeyListFromList } from "../../utility/helpers/helpers"
import { errorLogger } from "@rocc/rocc-logging-module"
import { getSubscriptionsService, updateSubscriptionsService } from "./presenceService"
import { SubscribeToPresence } from "./SubscribeToPresence"
import { IPresenceMap } from "./types"

interface ISetupPresenceSubscription {
    syncClient: SyncClient
}


export const SetupPresenceSubscriptions = (props: ISetupPresenceSubscription) => {
    /*
    1. Get current subscriptions for the user (Get-call Get all subscriptions)
    2. Get all interested subjects
        a. Contacts
        b. Rooms
    3. Prepare a delta of users that are not subscribed
    4. Subscribe to delta users (Put-call Update subscriptions to have new users)
    5. Update subjects with the mapId
        a. Contacts
        b. Rooms
    */

    const [init, setInit] = useState(true)
    const [subscriptionMaps, setSubscriptionMaps] = useState([] as IPresenceMap[])
    const [unsubscribers, setUnsubscriptionMaps] = useState([] as string[])
    const [failedSubscriptions, setFailedSubscriptions] = useState([] as string[])

    const { currentUser, contacts, contactsFetched, COMMUNICATION_SERVICES_URL, rooms, chatClientStatus, initRoomsFetched } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        contacts: state.userReducer.contacts,
        contactsFetched: state.userReducer.contactsFetched,
        COMMUNICATION_SERVICES_URL: state.configReducer.urls.COMMUNICATION_SERVICES_URL,
        rooms: state.customerReducer.rooms,
        initRoomsFetched: state.customerReducer.initRoomsFetched,
        chatClientStatus: state.clientStatusReducer.chatClientStatus,
    }))
    useEffect(() => {
        const subjectsReady = contactsFetched && initRoomsFetched && init
        if (subjectsReady) {
            setupSubscriptions()
        }
    }, [chatClientStatus, initRoomsFetched, contactsFetched])

    useEffect(() => {
        if (!init) {
            const interestedSubjects = generateSubjects({ contacts, rooms })
            if (subscriptionMaps.length) {
                if (interestedSubjects !== subscriptionMaps) {
                    updateSubscriptionsMap(interestedSubjects)
                }
            } else {
                setupSubscriptions()
            }
        }
    }, [contacts, rooms])

    useEffect(() => {
        return () => {
            if (unsubscribers.length) {
                errorLogger(`For user ${currentUser.uuid} unsubscribing following users: ${JSON.stringify(unsubscribers)}`)
                updateSubscriptions([], unsubscribers)
            }
        }
    }, [])

    const updateSubscriptionsMap = async (interestedSubjects: IPresenceMap[]) => {
        const interestedSubjectsUUID: string[] = getSingleKeyListFromList(interestedSubjects, "uuid")
        const availableSubscriptionsUUID: string[] = getSingleKeyListFromList(subscriptionMaps, "uuid")
        const subscribeUUIDs = interestedSubjectsUUID.filter((x: string) => !availableSubscriptionsUUID.includes(x))
        const unSubscribeUUIDs = availableSubscriptionsUUID.length ?
            availableSubscriptionsUUID.filter((x: string) => !interestedSubjectsUUID.includes(x)) : []
        setUnsubscriptionMaps(unSubscribeUUIDs)
        if (subscribeUUIDs.length && !subscribeUUIDs.every(uuid => failedSubscriptions.includes(uuid))) {
            try {
                const newSubscriptions = await updateSubscriptions(subscribeUUIDs, [])
                if (newSubscriptions.subscriptionsMap.length) {
                    updateSubjects(newSubscriptions.subscriptionsMap)
                    setSubscriptionMaps([...newSubscriptions.subscriptionsMap])
                } else if (newSubscriptions.failedSubscriptions.length) {
                    setFailedSubscriptions(newSubscriptions.failedSubscriptions)
                }
            } catch (error) {
                errorLogger(`Subscriptions failed with ${JSON.stringify(error)}`)
            }
        }
    }

    const setupSubscriptions = async () => {
        try {
            const currentSubjects: IPresenceMap[] = await getSubscriptions()
            const interestedSubjects: IPresenceMap[] = generateSubjects({ contacts, rooms })
            const { subscribeUUIDs, unSubscribeUUIDs } = compareToUpdateSubscriptions(currentSubjects, interestedSubjects)
            setUnsubscriptionMaps(unSubscribeUUIDs)
            let newSubscriptions: IPresenceMap[] = currentSubjects
            if (subscribeUUIDs.length) {
                const updatedSubscriptions = await updateSubscriptions(subscribeUUIDs, [])
                if (updatedSubscriptions.subscriptionsMap.length) {
                    newSubscriptions = updatedSubscriptions.subscriptionsMap
                }
            }
            updateSubjects(newSubscriptions)
            setSubscriptionMaps(newSubscriptions)
        } catch (error) {
            errorLogger(`Subscriptions failed with ${JSON.stringify(error)}`)
        } finally {
            setInit(false)
        }
    }

    const getSubscriptions = () => {
        const { accessToken, uuid } = currentUser
        const subPresenceUrl = `${COMMUNICATION_SERVICES_URL}${COMMUNICATION_PRESENCE_SUBSCRIPTION_EP}`
        return getSubscriptionsService(accessToken, uuid, subPresenceUrl)
    }

    const generateSubjects = ({ contacts, rooms }: { contacts?: IContactInfo[], rooms?: IRoomDetails[] }) => {
        const subjects: IPresenceMap[] = []
        if (contacts && contactsFetched) {
            contacts.forEach((item: IContactInfo) => {
                subjects.push({ uuid: item.uuid, syncMapId: item.presenceMapId ? item.presenceMapId : "", subscribed: false, type: item.clinicalRole })
            })
        }
        if (rooms && rooms.length) {
            rooms.forEach((item: IRoomDetails) => {
                subjects.push({ uuid: item.identity.uuid, syncMapId: item.presenceData.mapId ? item.presenceData.mapId : "", subscribed: false, type: EClinicalRole.DEVICE })
            })
        }
        return subjects
    }

    const updateSubscribedState = (subjects: IPresenceMap[]) => {
        setSubscriptionMaps(subjects)
    }

    const compareToUpdateSubscriptions = (availableSubscriptions: IPresenceMap[], interestedSubjects: IPresenceMap[]) => {
        let subscribeUUIDs: string[] = []
        let unSubscribeUUIDs: string[] = []
        try {
            if (interestedSubjects.length) {
                const interestedSubjectsUUID: string[] = getSingleKeyListFromList(interestedSubjects, "uuid")
                const availableSubscriptionsUUID: string[] = getSingleKeyListFromList(availableSubscriptions, "uuid")
                subscribeUUIDs = interestedSubjectsUUID.filter((x: string) => !availableSubscriptionsUUID.includes(x))
                unSubscribeUUIDs = availableSubscriptionsUUID.filter((x: string) => !interestedSubjectsUUID.includes(x))
            }
        } catch (error) {
            errorLogger(`Subscriptions failed with ${JSON.stringify(error)}`)
        }
        return { subscribeUUIDs, unSubscribeUUIDs }
    }

    const updateSubscriptions = (subscribeUUID: string[], unSubscribeUUID: string[]) => {
        const { accessToken, uuid } = currentUser
        const subPresenceUrl = `${COMMUNICATION_SERVICES_URL}${COMMUNICATION_PRESENCE_SUBSCRIPTION_EP}`
        return updateSubscriptionsService(accessToken, uuid, subscribeUUID, unSubscribeUUID, subPresenceUrl)
    }

    const updateSubjects = (subscriptionsMap: IPresenceMap[]) => {
        for (const sub of subscriptionsMap) {
            let isRoom: boolean = true
            contacts.forEach((contact: IContactInfo) => {
                if (contact.uuid === sub.uuid) {
                    isRoom = false
                    contact.presenceMapId = sub.syncMapId
                    sub.type = contact.clinicalRole
                }
            })
            if (isRoom) {
                rooms.forEach((room: IRoomDetails) => {
                    if (room.identity.uuid === sub.uuid) {
                        room.presenceData.mapId = sub.syncMapId
                        sub.type = EClinicalRole.DEVICE
                    }
                })
            }
        }
    }
    return <SubscribeToPresence subjects={subscriptionMaps} updateSubscribedState={updateSubscribedState} {...props} />
}
