"""
 Created on Fri Dec 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import ast
import json
import os
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_PARENT_SERVICE_AUTH_ISSUER, VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.enums import EConnectionMode
from src.constants.config_keys import VAULT_PARENT_ORG_ID
from src.constants.constants import DATA, HSDP_IAM_URL, ROCC_ORGANIZATIONS, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, \
    HSDP_ORGANIZATION_ID, CONNECTION_MODE, CONNECTION_IP
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.insertion_services.room_db_services import get_scanner_details, get_modality_id, check_if_scanner_exists, get_org_db_id_by_uuid, \
    get_kvm_configuration_id_by_org_db_id, get_scanner_details_by_identifier
from src.modules.insertion_management.manage_rooms import ManageRooms
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.graphql.mutations.mutations import update_scanner_transmitter_mappings, insert_scanner_tablet_transmitters
from src.wrappers.graphql.queries.queries import fetch_customer_name_from_db_id
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.utility.utility import check_ip_format

LOG = create_logger("ScannerService")


class ScannerService():

    def __init__(self, service_user_uuid, customer_id, user_token):
        try:
            self._service_user_uuid = service_user_uuid
            self._service_user_token = user_token
            self._org_db_id = customer_id
            self._profile_configs = get_profile_data()
            self._parent_org_infra_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            read_only_client = get_client_connection(self._service_user_token, org_infra_uuid=self._parent_org_infra_uuid, is_fse=True)
            self._vault_values, self._org_infra_uuid, self._token = self.populate_service_token(read_only_client)
            self._client = get_client_connection(self._token, org_infra_uuid=self._org_infra_uuid)
        except RoccException as ex:
            LOG.error(f"RoccException - Service initialization failed with error: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"Service initialization failed: {ex}.")
            raise ex

    def populate_service_token(self, read_only_client):
        db_result = read_only_client.execute(fetch_customer_name_from_db_id, variable_values={"org_db_id": self._org_db_id})
        customers = db_result[ROCC_ORGANIZATIONS]
        if customers and len(customers) == 1:
            customer_name = customers[0]["org_identifier"]
            customer_vault_values = get_path_specific_vault_values(path_name=customer_name)
            org_infra_uuid = customer_vault_values[DATA][HSDP_ORGANIZATION_ID]
            token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                    issuer=customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                    private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            return customer_vault_values, org_infra_uuid, token
        else:
            LOG.error(f"Invalid customer_id: {self._org_db_id}, could not get valid customer name!")
            raise RoccException(status_code=400, title="Invalid customer id.", payload=f"Invalid customer_id: {self._org_db_id}, could not get valid customer name!")

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Modify user", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_infra_uuid, token=self._token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def update_scanner_transmitter_mapping(self, scanner_details, scanner_id, site_id):
        try:
            scanner_obj = get_scanner_details(self._client, scanner_id, self._org_infra_uuid, site_id)
            modality_id = get_modality_id(self._client, scanner_details["modality"])
            if scanner_details["modality_connection"]:
                modality_connection = self.validate_ip_address(scanner_details["modality_connection"])
            else:
                modality_connection = []
            scanner_details["modality_connection"] = modality_connection
            transmitter_mappings_objects = self.set_kvm_connection_details(scanner_details, scanner_id, scanner_obj.transmitter_mappings)
            secondary_phone, manufacturer, model, serial_number, dicom_ae_title, software_version, os_type, os_version, notes = self.set_scanner_optional_fields(scanner_details,
                                                                                                                                                                 scanner_obj)
            variable_values = {"display_name": scanner_details["display_name"], "modality_id": modality_id, "location": scanner_details["location"],
                               "primary_phone": scanner_details["primary_phone"], "secondary_phone": secondary_phone,
                               "resource_id": scanner_id, "manufacturer": manufacturer, "model": model, "serial_number": serial_number, "dicom_ae_title": dicom_ae_title,
                               "software_version": software_version,
                               "os_type": os_type, "os_version": os_version, "notes": notes,
                               "additional_attributes": self.compute_additional_attributes(scanner_details=scanner_details, existing_attributes=scanner_obj.additional_attributes),
                               "transmitter_mapping_objects": transmitter_mappings_objects,
                               "modified_by": self._service_user_uuid, "modality_connection": scanner_details["modality_connection"]
                               }
            LOG.info(f"Going to update scanner details: {variable_values}")
            db_result = self._client.execute(update_scanner_transmitter_mappings, variable_values)
            LOG.info(f"Scanner/transmitter data update completed: {db_result} ")
            self.safe_audit(event_subtype="Update scanner mapping", action="C", outcome=0, code="Update scanner mapping", value="Success")
            return {
                "modality": scanner_details["modality"], "primary_phone": scanner_details["primary_phone"], "secondary_phone": secondary_phone,
                "location": scanner_details["location"], "transmitters": transmitter_mappings_objects,
                "display_name": scanner_details["display_name"],
                "manufacturer": manufacturer, "model": model, "serial_number": serial_number,
                "dicom_ae_title": dicom_ae_title, "software_version": software_version, "os_type": os_type, "os_version": os_version, "notes": notes,
                "modality_connection": scanner_details["modality_connection"]
            }
        except RoccException as ex:
            LOG.exception(f"ROCCException while updating Scanner: {scanner_id}. {ex}")
            self.safe_audit(event_subtype="Update scanner mapping", action="C", outcome=8, code="Update scanner mapping", value="Error")
            raise ex
        except Exception as ex:
            LOG.exception(f"Error while updating Scanner: {scanner_id}. {ex}")
            self.safe_audit(event_subtype="Update scanner mapping", action="C", outcome=8, code="Update scanner mapping", value="Error")
            raise RoccException(500, title=f"RoccException while Updating scanner {scanner_id}.", payload="Internal server error") from ex

    def set_kvm_connection_details(self, scanner_details, scanner_id, transmitter_mappings_obj):
        transmitter_mappings = scanner_details["transmitters"]
        transmitter_mappings_objects = []
        if transmitter_mappings:
            for kvm_connection in transmitter_mappings:
                kvm_connection = ast.literal_eval(kvm_connection)
                kvm_connection_object = {"scanner_resource_id": scanner_id,
                                         "transmitter_connection_name": kvm_connection["name"],
                                         "transmitter_connection_type": kvm_connection["type"],
                                         "created_at": transmitter_mappings_obj.created_at,
                                         "created_by": transmitter_mappings_obj.created_by,
                                         "modified_by": self._service_user_uuid,
                                         "transmitter": {
                                             "data": {
                                                 "kvm_configuration_id": transmitter_mappings_obj.transmitter.kvm_configuration_id,
                                                 "transmitter_name": kvm_connection["transmitter"]["name"],
                                                 "transmitter_ip": kvm_connection["transmitter"]["ip"],
                                                 "created_at": transmitter_mappings_obj.created_at,
                                                 "created_by": transmitter_mappings_obj.created_by,
                                                 "modified_by": self._service_user_uuid,
                                             }
                                         }
                                         }
                transmitter_mappings_objects.append(kvm_connection_object)
        else:
            kvm_connection_object = {"scanner_resource_id": scanner_id,
                                     "transmitter_connection_name": transmitter_mappings_obj.transmitter_connection_name,
                                     "transmitter_connection_type": transmitter_mappings_obj.transmitter_connection_type,
                                     "created_at": transmitter_mappings_obj.created_at,
                                     "created_by": transmitter_mappings_obj.created_by,
                                     "modified_at": transmitter_mappings_obj.modified_at,
                                     "modified_by": transmitter_mappings_obj.modified_by,
                                     "transmitter": {
                                         "data": {
                                             "kvm_configuration_id": transmitter_mappings_obj.transmitter.kvm_configuration_id,
                                             "transmitter_name": transmitter_mappings_obj.transmitter.transmitter_name,
                                             "transmitter_ip": transmitter_mappings_obj.transmitter.transmitter_ip,
                                             "created_by": self._service_user_uuid,
                                         }
                                     }
                                     }
            transmitter_mappings_objects.append(kvm_connection_object)
        return transmitter_mappings_objects

    def validate_ip_address(self, modality_connection):
        for data in modality_connection:
            if data[CONNECTION_MODE] == EConnectionMode.VNC.value or data[CONNECTION_MODE] == EConnectionMode.RDP.value:
                ip_addr = check_ip_format(str(data[CONNECTION_IP]))
                if not ip_addr:
                    self.safe_audit(event_subtype="Ip validation failed", action="C", outcome=8, code="IP address is incorrect", value="Error")
                    raise RoccException(status_code=422, title="RoccException while onboarding of scanner.", payload="IP field in Modality_connection is incorrect")
        return modality_connection

    def create_scanner_tablet_transmitters_mapping(self, site_id, scanner_details):
        try:
            check_if_scanner_exists(self._client, scanner_details["short_name"], site_id)
            modality_id = get_modality_id(self._client, scanner_details["modality"])
            org_db_id = get_org_db_id_by_uuid(self._client, self._org_infra_uuid)
            transmitter_objects = self.create_transmitter_objects(scanner_details, org_db_id)
            if scanner_details["modality_connection"]:
                modality_connection = self.validate_ip_address(scanner_details["modality_connection"])
            else:
                modality_connection = []
            scanner_details["modality_connection"] = modality_connection
            hsdp_device_id = self.provision_new_hsdp_device()
            org_ctxt_header = {"Org-Id": self._org_infra_uuid}
            ManageRooms.create_communication_profile(self._token, hsdp_device_id, scanner_details["short_name"], org_ctxt_header)
            user_role_mapping = [{"userId": hsdp_device_id, "role": "DEVICEROLE"}]
            ManageRooms.create_rbac_roles_for_room(self._token, self._org_infra_uuid, user_role_mapping)
            variable_values = {
                "scanner_objects": {
                    "identifier": scanner_details["short_name"], "name": scanner_details["display_name"], "modality_id": modality_id, "organization_id": org_db_id,
                    "site_id": site_id, "manufacturer": scanner_details["manufacturer"], "model": scanner_details["model"], "serial_number": scanner_details["serial_number"],
                    "dicom_ae_title": scanner_details["dicom_ae_title"], "scanner_software_version": scanner_details["software_version"],
                    "scanner_os_type": scanner_details["os_type"], "scanner_os_version": scanner_details["os_version"], "primary_phone": scanner_details["primary_phone"],
                    "secondary_phone": scanner_details["secondary_phone"], "location": scanner_details["location"], "notes": scanner_details["notes"],
                    "additional_attributes": self.compute_additional_attributes(scanner_details=scanner_details, existing_attributes=None),
                    "created_by": self._service_user_uuid,
                    "rocc_tablets": {
                        "data": {
                            "device_name": scanner_details["short_name"], "device_hsdp_uuid": hsdp_device_id, "status": "Active", "created_by": self._service_user_uuid
                        }
                    },
                    "rocc_transmitter_mappings": {
                        "data": transmitter_objects
                    },
                    "modality_connection": scanner_details["modality_connection"]
                }
            }
            LOG.info(f"Going to create Scanner/tablets/transmitters data: {variable_values}")
            db_result = self._client.execute(insert_scanner_tablet_transmitters, variable_values)
            LOG.info(f"Scanner/tablets/transmitters data inserted. : {db_result} ")
            self.safe_audit(event_subtype="Update scanner mapping", action="C", outcome=0, code="Update scanner mapping", value="Success")
        except RoccException as ex:
            LOG.exception(f"ROCCException while Scanner onboard {ex}.")
            self.safe_audit(event_subtype="Create new Scanner", action="C", outcome=8, code="Create new Scanner", value="Error")
            raise ex
        except Exception as ex:
            LOG.exception(f"Error while Scanner onboard {ex}.")
            self.safe_audit(event_subtype="Create new Scanner", action="C", outcome=8, code="Create new Scanner", value="Error")
            raise RoccException(500, title="RoccException while Onboarding scanner.", payload="Internal server error") from ex

    def create_transmitter_objects(self, scanner_details, org_db_id):
        transmitters = scanner_details["transmitters"]
        kvm_configuration_id = get_kvm_configuration_id_by_org_db_id(self._client, org_db_id)
        transmitter_objects = []
        if transmitters:
            for transmitter in transmitters:
                transmitter = ast.literal_eval(transmitter)
                transmitter_object = {
                    "transmitter_connection_name": transmitter["name"],
                    "transmitter_connection_type": transmitter["type"],
                    "created_by": self._service_user_uuid,
                    "transmitter": {
                        "data": {
                            "kvm_configuration_id": kvm_configuration_id,
                            "transmitter_name": transmitter["name"],
                            "transmitter_ip": transmitter["ip"],
                            "created_by": self._service_user_uuid,
                        }
                    }
                }
                transmitter_objects.append(transmitter_object)
        return transmitter_objects

    def provision_new_hsdp_device(self):
        new_device_ids = ManageRooms.provision_new_hsdp_devices(number_of_devices_required=1,
                                                                vault_response=self._vault_values,
                                                                token=self._token)
        if len(new_device_ids) == 0:
            raise RoccException(status_code=422, title="RoccException while onboarding of scanner.", payload="hsdp device could not be provisioned.")
        return new_device_ids.pop()

    def set_scanner_optional_fields(self, scanner_details, scanner_obj):
        secondary_phone = self.compute_values(scanner_details["secondary_phone"], scanner_obj.secondary_phone)
        manufacturer = self.compute_values(scanner_details["manufacturer"], scanner_obj.manufacturer)
        model = self.compute_values(scanner_details["model"], scanner_obj.model)
        serial_number = self.compute_values(scanner_details["serial_number"], scanner_obj.serial_number)
        dicom_ae_title = self.compute_values(scanner_details["dicom_ae_title"], scanner_obj.dicom_ae_title)
        software_version = self.compute_values(scanner_details["software_version"], scanner_obj.scanner_software_version)
        os_type = self.compute_values(scanner_details["os_type"], scanner_obj.scanner_os_type)
        os_version = self.compute_values(scanner_details["os_version"], scanner_obj.scanner_os_version)
        notes = self.compute_values(scanner_details["notes"], scanner_obj.notes)
        return secondary_phone, manufacturer, model, serial_number, dicom_ae_title, software_version, os_type, os_version, notes

    def compute_additional_attributes(self, scanner_details, existing_attributes):
        if existing_attributes:
            return self.compute_existing_attribute(scanner_details, existing_attributes)
        else:
            return self.compute_additional_attribute(scanner_details)

    def compute_existing_attribute(self, scanner_details, existing_attributes):
        existing_attributes["ncc_edit"] = True if scanner_details["nccEdit"] else False
        existing_attributes["start_date"] = scanner_details["start_date"] if scanner_details["start_date"] else False
        existing_attributes["end_date"] = scanner_details["end_date"] if scanner_details["end_date"] else False
        existing_attributes["is_pharma_enabled"] = True if scanner_details["isPharmaEnabled"] else False
        return json.loads(json.dumps(existing_attributes))

    def compute_additional_attribute(self, scanner_details):
        additional_attributes = {}
        additional_attributes["ncc_edit"] = True if scanner_details["nccEdit"] else False
        additional_attributes["start_date"] = scanner_details["start_date"] if scanner_details["start_date"] else False
        additional_attributes["end_date"] = scanner_details["end_date"] if scanner_details["end_date"] else False
        additional_attributes["is_pharma_enabled"] = True if scanner_details["isPharmaEnabled"] else False
        return json.loads(json.dumps(additional_attributes))

    @staticmethod
    def compute_values(payload_value, obj_value):
        return payload_value if not isinstance(payload_value, type(None)) else obj_value


class ScannerDetailsService():
    def __init__(self):
        try:
            self._profile_configs = get_profile_data()
            self.populate_service_tokens()
            self._parent_org_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            self._client = get_client_connection(access_token=self._parent_service_token, org_infra_uuid=self._parent_org_uuid)

        except RoccException as ex:
            LOG.error(f"RoccException - Service initialization failed with error: {ex}")
            raise ex
        except Exception as ex:
            LOG.exception(f"Service initialization failed: {ex}.")
            raise ex

    def populate_service_tokens(self):
        try:
            self._parent_service_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                         issuer=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                         private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
        except Exception as ex:
            LOG.error(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500,
                                title="Internal server error",
                                payload="Service token creation failed!") from ex

    def get_device_details_by_scanner_identifier(self, scanner_identifier):
        try:
            device_details = get_scanner_details_by_identifier(self._client, scanner_identifier)
            return json.loads(json.dumps(device_details))
        except RoccException as ex:
            LOG.exception(f"ROCCException while getting device details {ex}.")
            raise ex
