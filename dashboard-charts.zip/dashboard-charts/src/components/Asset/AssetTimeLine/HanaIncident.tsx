// @ts-nocheck
import React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import HighchartsExporting from "highcharts/modules/exporting";
import moment from "moment";
import "./HanaIncident.scss";

HighchartsExporting(Highcharts);
Highcharts.AST.allowedAttributes.push("onclick");

interface Props {
	hanaIncidentData: any[];
}
const HanaIncident = ({ hanaIncidentData }: Props) => {
	const mygetdate = (gedata: any) => {
		let utcdate = Date.UTC(
			new Date(gedata).getFullYear(),
			new Date(gedata).getMonth(),
			new Date(gedata).getDate()
		);
		return utcdate;
	};

	function dateFormat(value: any, pattern: any) {
		if(value !== null && value !== "" && value !== "null" && value !== "NULL")
		{
			var i = 0,
			date = value.toString();
		    return pattern.replace(/#/g, (_) => date[i++]);

		} else {

			return "Null";
		}
		
	}

	let HanaIncidentGetData = [];
	hanaIncidentData.forEach((device, index) => {
		HanaIncidentGetData[index] = { ...device };
	});

	let dataset = [];
	for (var i = 0; i < HanaIncidentGetData.length; i++) {
		if (HanaIncidentGetData[i].eventType === "Slowdown") {
			let localdata = {
				showInLegend: false,
				color: "#4d4d4d",
				data: [
					[
						mygetdate(HanaIncidentGetData[i].startDate),
						HanaIncidentGetData[i].eventNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDYiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0NiIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iI2UzNTIwNSIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;">
                        <tspan>&nbsp;EVENT TYPE : ${
													HanaIncidentGetData[i].eventType
												}</tspan><br/>
                        <tspan>START DATE :  ${moment(
													new Date(HanaIncidentGetData[i].startDate)
												).format("DD MMM YY")}</tspan><br/>
                        <tspan>DESCRIPTION : ${
													HanaIncidentGetData[i].eventDescription
												}</tspan><br/>
                        <tspan>END DATE : ${dateFormat(
													HanaIncidentGetData[i].endDate,
													"####-##-##"
												)}</tspan><br/>
                        <tspan>STATUS : ${
													HanaIncidentGetData[i].status
												}</tspan><br/>
                        <tspan>ZPOSSIBLE CAUSE : ${
													HanaIncidentGetData[i].zPossibleCause
												}</tspan><br/>
                        <tspan>RCA INITIATED : ${
													HanaIncidentGetData[i].rcaInitiated
												}</tspan><br/>
                        <tspan>UNPLANNED SHUTDOWN HOURS : ${
													HanaIncidentGetData[i].unplannedShutdownHours
												}</tspan>
                        <br/>
                    </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		} else if (HanaIncidentGetData[i].eventType === "Planned Shutdown") {
			let localdata = {
				showInLegend: false,
				color: "#4d4d4d",
				data: [
					[
						mygetdate(HanaIncidentGetData[i].startDate),
						HanaIncidentGetData[i].eventNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDQiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0NCIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iIzRlNzlhNyIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;">
                        <tspan>&nbsp;EVENT TYPE : ${
													HanaIncidentGetData[i].eventType
												}</tspan><br/>
                        <tspan>START DATE :  ${moment(
													new Date(HanaIncidentGetData[i].startDate)
												).format("DD MMM YY")}</tspan><br/>
                        <tspan>DESCRIPTION : ${
													HanaIncidentGetData[i].eventDescription
												}</tspan><br/>
                        <tspan>END DATE : ${dateFormat(
													HanaIncidentGetData[i].endDate,
													"####-##-##"
												)}</tspan><br/>
                        <tspan>STATUS : ${
													HanaIncidentGetData[i].status
												}</tspan><br/>
                        <tspan>ZPOSSIBLE CAUSE : ${
													HanaIncidentGetData[i].zPossibleCause
												}</tspan><br/>
                        <tspan>RCA INITIATED : ${
													HanaIncidentGetData[i].rcaInitiated
												}</tspan><br/>
                        <tspan>UNPLANNED SHUTDOWN HOURS : ${
													HanaIncidentGetData[i].unplannedShutdownHours
												}</tspan>
                        <br/>
                    </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		} else if (HanaIncidentGetData[i].eventType === "Unplanned Shutdown") {
			let localdata = {
				showInLegend: false,
				color: "#4d4d4d",
				data: [
					[
						mygetdate(HanaIncidentGetData[i].startDate),
						HanaIncidentGetData[i].eventNumber,
					],
				],
				marker: {
					symbol:
						"url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDI2IDEwIj4NCiAgPHJlY3QgaWQ9IlJlY3RhbmdsZV8xNDYiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDE0NiIgd2lkdGg9IjI2IiBoZWlnaHQ9IjEwIiByeD0iNSIgZmlsbD0iIzNiYjQ0YSIvPg0KPC9zdmc+DQo=)",
				},

				tooltip: {
					useHTML: true,
					headerFormat: `<div class="ttt" style="color:#fff;font-size:0.75rem;">
                        <tspan>&nbsp;EVENT TYPE : ${
													HanaIncidentGetData[i].eventType
												}</tspan><br/>
                        <tspan>START DATE :  ${moment(
													new Date(HanaIncidentGetData[i].startDate)
												).format("DD MMM YY")}</tspan><br/>
                        <tspan>DESCRIPTION : ${
													HanaIncidentGetData[i].eventDescription
												}</tspan><br/>
                        <tspan>END DATE : ${dateFormat(
													HanaIncidentGetData[i].endDate,
													"####-##-##"
												)}</tspan><br/>
                        <tspan>STATUS : ${
													HanaIncidentGetData[i].status
												}</tspan><br/>
                        <tspan>ZPOSSIBLE CAUSE : ${
													HanaIncidentGetData[i].zPossibleCause
												}</tspan><br/>
                        <tspan>RCA INITIATED : ${
													HanaIncidentGetData[i].rcaInitiated
												}</tspan><br/>
                        <tspan>UNPLANNED SHUTDOWN HOURS : ${
													HanaIncidentGetData[i].unplannedShutdownHours
												}</tspan>
                        <br/>
                    </div>`,
					pointFormat: "",
				},
			};
			dataset.push(localdata);
		}
	}

	const getHighcharts = () => ({
		chart: {
			type: "scatter",
			zoomType: "xy",
			height: 180,
		},
		title: {
			text: null,
		},
		xAxis: {
			visible: true,
			tickInterval: 24 * 3600 * 1000, // the number of milliseconds in a day
			allowDecimals: false,
			type: "datetime",
			labels: {
				formatter() {
					return Highcharts.dateFormat("%d-%b-%y", this.value);
				},
				style: {
                    fontSize: '0.8rem',
                }
			},
		},
		yAxis: {
			visible: false,
			min: 0,
			max: 4,
		},

		navigation: {
			buttonOptions: {
				enabled: false,
			},
		},
		plotOptions: {
			scatter: {
				marker: {
					radius: 10,
					// symbol: 'url(https://www.highcharts.com/samples/graphics/sun.png)',
					borderRadius: 10,
					states: {
						hover: {
							enabled: false,
						},
					},
				},
				states: {
					hover: {
						marker: {
							enabled: false,
						},
					},
				},
			},
		},

		tooltip: {
			enabled: true,
		},

		series: dataset,
	});

	return (
			<div id="asset-timeline" className="pb25">
				<div id="asset-timeline-left">
					<div id="asset-timeline-plot">
						<div className="asset-timeline-filter">
							<div className="title">HANA INCIDENT</div>
						</div>
						<div className="asset-timeline-plot-graph">
							<HighchartsReact
								highcharts={Highcharts}
								options={getHighcharts()}
							/>
						</div>
					</div>
				</div>
				<div id="asset-timeline-right">
					<div id="asset-timeline-names">
						<div className="right-title">EVENT TYPE</div>
						<div className="asset-timeline-list">
							<div>
								<span style={{ background: "#E35205" }}></span>
								<span>Slowdown</span>
							</div>
							<div>
								<span style={{ background: "#4E79A7" }}></span>
								<span>Planned Shutdown</span>
							</div>
							<div>
								<span style={{ background: "#3BB44A" }}></span>
								<span>Unplanned Shutdown</span>
							</div>
						</div>
					</div>
				</div>
			</div>
	);
};

export default HanaIncident;
