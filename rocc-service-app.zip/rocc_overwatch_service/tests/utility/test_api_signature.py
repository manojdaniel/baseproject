"""
 Created on Wed Dec 2 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest.mock import Mock, patch

from tests.mocks.random import rand_string
from src.utility.api_signature import *


class LogApiSignatureTestCase(unittest.TestCase):
    # TODO: Branching coverage done. Needs logical coverage
    def setUp(self):
        self.shared_key = rand_string(10)
        self.secret_key = rand_string(10)

    @patch("src.utility.api_signature.hmac")
    def test_generature_signature(self, mock_hmac):
        # Define constants
        signed_date = rand_string(10)
        digest_message = rand_string(10)

        # Mock objects
        mock_hmac_object = Mock()

        # Return values
        mock_hmac.new.return_value = mock_hmac_object
        mock_hmac_object.digest.return_value = bytearray(digest_message, UTF_8)

        # Main test method
        signature_creator = LogApiSignature(self.shared_key, self.secret_key)
        signature = signature_creator.generate_signature(signed_date)

        # Assertion tests
        mock_hmac.new.assert_called_with(key=bytearray(f"DHPWS{self.secret_key}", UTF_8),
                                         msg=bytearray(base64.b64encode(signed_date.encode(UTF_8))),
                                         digestmod=hashlib.sha256)

        mock_hmac_object.digest.assert_called()

        self.assertEqual(signature, f"HmacSHA256;Credential:{self.shared_key};SignedHeaders:SignedDate;Signature:{base64.b64encode(bytearray(digest_message, UTF_8)).decode()}")
