import unittest
from unittest.mock import patch
from src.modules.insertion_management.manage_org_metadata_site_data import ManageOrgMetadataAndSiteDataTask
from src.constants.constants import EMP_DICT, KVM_CONFIGURATION_DICT, ROOMS_DICT, SITES_DICT


class ManageOrgMetadataAndSiteDataTaskTest(unittest.TestCase):
    @patch("src.wrappers.infrastructure_services.vault_services.manage_vault_services.get_path_specific_vault_values")
    @patch("src.modules.db_operations.insertion_services.sites_db_services.construct_sites")
    def test_start_job(self, mock_fn, mock_const_site):
        mock_fn.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        mock_const_site.return_value = []
        data_dict = {}
        data_dict[ROOMS_DICT] = "room"
        data_dict[SITES_DICT] = {"identity": "site_identity"}
        data_dict[EMP_DICT] = {}
        manage_data = ManageOrgMetadataAndSiteDataTask(
            data_dict, {}, 1234, "abc", "kvm_config_id", {}, "11")
        manage_data._data_dict[KVM_CONFIGURATION_DICT] = ""
        sites_response = [{"id": 1, "identifier": "identity"}]
        with self.assertRaises(Exception):
            manage_data.task_add_new_data_for_existing_customer_data(1)
        with self.assertRaises(Exception):
            manage_data.task_check_and_add_eula(1)
        with self.assertRaises(Exception):
            manage_data.task_check_and_add_kvm_configs(1)
        with self.assertRaises(Exception):
            manage_data.task_check_and_add_site_contacts(sites_response, 1)
        self.assertIsNotNone(manage_data)
