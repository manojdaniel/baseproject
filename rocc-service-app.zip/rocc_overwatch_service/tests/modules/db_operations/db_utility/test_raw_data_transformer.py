"""
 Created on Mon Feb 14 2022
 Copyright (c) 2022 Philips
 (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import unittest
from unittest.mock import Mock
from src.exceptions.RoccException import RoccException
from src.modules.db_operations.db_utility.raw_data_transformer import fetch_dict_from_transaction_id, extract_table_name_from_schema_table_name

class RawDataTransform(unittest.TestCase):
    def test_fetch_dict_from_transaction_id_success(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": [{
            "id": 1,
            "data": "data"
        }
        ]}
        resp1, resp2 = fetch_dict_from_transaction_id(1, mock_client)
        self.assertEqual(resp1, "data")
        self.assertEqual(resp2, 1)

    def test_fetch_dict_from_transaction_id_exception(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        self.assertRaises(RoccException, fetch_dict_from_transaction_id, 1, mock_client)

    def test_extract_table_name_from_schema_table_name_exception(self):
        resp = extract_table_name_from_schema_table_name(1, "")
        self.assertEqual(resp, 1)

    def test_extract_table_name_from_schema_table_name_success(self):
        resp = extract_table_name_from_schema_table_name("rocc_rocc_users", "rocc")
        self.assertEqual(resp, "rocc_users")
