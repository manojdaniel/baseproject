
import { Dispatch } from "react"
import { getVendorServiceName } from "../avmessages/messageService"
import { setCommunicationVendorName } from "../../../redux/actions/callActions"
import { COMMUNICATION_VENDOR_NAME_UNAVAILABLE, HTTP_STATUS } from "../../../constants/constants"
import { errorLogger, errorParser, infoLogger } from "@rocc/rocc-logging-module"
import { RoccCommunication, IRoccVideoCall, EAvCallType } from "@rocc/rocc-av-communication-sdk"
import { IUserInfo } from "@rocc/rocc-client-services"
import { fetchGlobalURLs } from "../../../redux/store/externalAppStates"
const urls = fetchGlobalURLs()
export class AVFactory {
    static instance: IRoccVideoCall

    public static getAvVendor = async (communicationVendor: EAvCallType, currentUser: IUserInfo, dispatch: Dispatch<any>) => {
        if (!communicationVendor) {
            return this.getCommunicationVendorName(currentUser, urls.COMMUNICATION_SERVICES_URL, dispatch)
        } else {
            return this.getVendorService(communicationVendor as EAvCallType)
        }
    }

    public static getCommunicationVendorName = async (currentUser: any, url: string, dispatch: Dispatch<any>) => {
        return getVendorServiceName(currentUser, url).then((response: any) => {
            if (response.status == HTTP_STATUS.OK) {
                dispatch(setCommunicationVendorName(response.data))
                infoLogger(`AVFACTORY - selected vendor name ${response.data.vendorName} for User ${currentUser.uuid} `)
                return this.getVendorService(response.data.vendorName)
            } else {
                return COMMUNICATION_VENDOR_NAME_UNAVAILABLE
            }
        }).catch((error: any) => {
            errorLogger(`An exception has occurred during fetching communication Vendor Name : ${errorParser(error)} for User ${currentUser.uuid}`)
            return COMMUNICATION_VENDOR_NAME_UNAVAILABLE
        })
    }

    public static getVendorService(type: EAvCallType): IRoccVideoCall {
        return new RoccCommunication(type)
    }
}
