/*
 * Created on Tue Nov 24 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import { Icon } from "semantic-ui-react"
import { IRoomInfo } from "../../redux/interfaces/types"
import en from "../../resources/translations/en-US"
import styles from "./ConsoleMonitorSelection.module.scss"
import cx from "classnames"

export const getHeaderForCC = (selectedReceiverName: string) => {
    const { intl } = getIntlProvider()
    return (
        <div className={styles.headerContainerForCC}>
            <span className="headerContainerIconForCC">
                <Icon className={cx("icon ExclamationMarkCircle", styles.iconExclamation)} />
            </span>
            <span className={styles.headerContainerMessageForCC}>
                {`${intl.formatMessage({
                    id: "content.consoleMessages.ActiveSessionChangeHeader",
                    defaultMessage: en["content.consoleMessages.ActiveSessionChangeHeader"]
                })} ${selectedReceiverName}`}
            </span>
        </div>
    )
}

export const getRoomNameAndAddress = (roomName: string, address: string) => {
    return (
        <>
            <b>{roomName.trim()}</b>{` ${"-"} ${address}`}
        </>
    )
}

export const getActiveSessionMessageForCC = (selectedReceiverName: string, newRoomDetail: IRoomInfo, oldRoomDetail: IRoomInfo) => {
    const { intl } = getIntlProvider()
    const activeSessionConsoleRoomName = oldRoomDetail ? oldRoomDetail.roomName : ""
    const activeSessionConsoleRoomAddress = oldRoomDetail ? oldRoomDetail.address : ""
    const newConsoleRoomName = newRoomDetail ? newRoomDetail.roomName : ""
    const newConsoleRoomAddress = newRoomDetail ? newRoomDetail.address : ""
    const monitorName = selectedReceiverName
    const messagePart1 = `${intl.formatMessage({
        id: "content.consoleMessages.activeSessionMessagePart1",
        defaultMessage: en["content.consoleMessages.activeSessionMessagePart1"]
    })} ${monitorName} ${intl.formatMessage({
        id: "content.consoleMessages.activeSessionMessagePart2",
        defaultMessage: en["content.consoleMessages.activeSessionMessagePart2"]
    })} `
    const nameAndAddress = getRoomNameAndAddress(activeSessionConsoleRoomName, activeSessionConsoleRoomAddress)
    const newNameAndAddress = getRoomNameAndAddress(newConsoleRoomName, newConsoleRoomAddress)
    const messagePart2 = `${intl.formatMessage({
        id: "content.consoleMessages.activeSessionMessagePart3",
        defaultMessage: en["content.consoleMessages.activeSessionMessagePart3"]
    })} ${monitorName} ${intl.formatMessage({
        id: "content.consoleMessages.activeSessionMessagePart4",
        defaultMessage: en["content.consoleMessages.activeSessionMessagePart4"]
    })} `
    const messagePart3 = `${intl.formatMessage({
        id: "content.consoleMessages.activeSessionMessagePart5",
        defaultMessage: en["content.consoleMessages.activeSessionMessagePart5"]
    })}`
    return <span className={styles.activeSessionMessageContent}>
        {`${messagePart1}`} {nameAndAddress}. {`${messagePart2}`} {nameAndAddress} {`${messagePart3}`} {newNameAndAddress}.
    </span>
}

export const errorModalHeader = () => {
    const { intl } = getIntlProvider()
    return (
        <div>
            <Icon className={cx("CrossCircle", styles.errorCrossMark)} />
            <span className={styles.errorMessage}>{intl.formatMessage({ id: "content.consoleMessage.ConsoleConnectionFailedHeader", defaultMessage: en["content.consoleMessage.ConsoleConnectionFailedHeader"] })}</span>
        </div>
    )
}

export const requestRejectModalHeader = () => {
    const { intl } = getIntlProvider()
    return (
        <div id="rejectModalHeader">
            <Icon className={cx("icon ExclamationMarkCircle", styles.requestRejectExclamationMark)} />
            <span className={styles.errorMessage}>{intl.formatMessage({ id: "content.requestRejectModal.header", defaultMessage: en["content.requestRejectModal.header"] })}</span>
        </div>
    )
}
