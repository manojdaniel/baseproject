/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Dispatch } from "redux"
import { setRecentMissedCallInRedux, storeCallDetailsInRedux } from "../MessageHelper"
import { ICallDetails, TRACKING_VALUES } from "../types"
import { CALL_MESSAGES, HTTP_STATUS, TIMEOUT_10, TIMEOUT_3000 } from "../../../../../constants/constants"
import { updateCallTimeout, setCallRingStatus, setCallMessage, setVideoCallStatus, setIncomingCallDetails, setOutgoingCallDetails } from "../../../../../redux/actions/callActions"
import store from "../../../../../redux/store/store"
import { filterCallStatusByContextIdAndStatus } from "../../../../helpers/callUtility"
import { infoLogger, errorLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import { getContextDetails, checkCurrentCallRejected } from "../../messageService"
import en from "../../../../../resources/translations/en-US"
import { getDetailsByUUID, getTrackingEvent, DEFAULT_CONTACT_INFO, IContactInfo, ECallStatus, IIncomingCallDetails, IOutgoingCallDetails } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { getCustomrReducerFromGlobalStore, getTranslatedCallType, getUserReducerFromGlobalStore } from "../../../../helpers/helpers"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"
import { DEFAULT_INCOMING_CALL_DEATILS, DEFAULT_OUTGOING_CALL_DEATILS } from "../../../../../redux/reducers/callReducer"

interface ICallRejected {
    contextId: string
    dispatch: Dispatch<any>
}

const { CALLING, CALLREJECT, RINGING, CALLDECLINED } = ECallStatus

export const callRejected = async (props: ICallRejected) => {
    const { videoCallStatus, currentUser, urls, connectedCallDetails } = initialiseReduxValues()

    const { contextId, dispatch } = props

    /* Display Call Message To User */
    if (filterCallStatusByContextIdAndStatus(videoCallStatus, contextId, [RINGING, CALLING, CALLREJECT], true).length) {
        dispatch(updateCallTimeout({ contextId, timeoutId: setTimeout(() => "", TIMEOUT_10) }, false))
        dispatch(setCallRingStatus(false))
    }
    const contextDetails = await getContextDetails(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL)
    if (contextDetails && contextDetails.status === HTTP_STATUS.OK) {
        const data = contextDetails.data
        /* Update User's status since call is not picked. */
        if (contextId === connectedCallDetails.contextId) {
            data.contextId = contextId
            data.numOfParticipants = connectedCallDetails.numOfParticipants
            storeCallDetailsInRedux(data, dispatch)
        }
        handleCallDisconnect(data, props)
    } else {
        errorLogger("Failed to Accept the call")
    }
}

const handleCallDisconnect = async (data: ICallDetails, props: ICallRejected) => {
    const { contextId, dispatch } = props
    const { videoCallStatus, currentUser, contacts, rooms, incomingCall, outgoingCall } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES
    const { isRejectedByMe, shouldCallDisconnect, callInitiator, callerId, rejectedParticipantID } = checkCurrentCallRejected(data)
    if (shouldCallDisconnect) {
        const rejectedCallStatusIndex = videoCallStatus.findIndex((callStatus) => callStatus.contextId === contextId)
        if (rejectedCallStatusIndex > -1) {
            let contact = DEFAULT_CONTACT_INFO
            if (data.participants.length) {
                contact = await getDetailsByUUID(data.participants[0].primaryUuid, contacts, rooms)
            }
            if (isRejectedByMe) {
                setTimeout(() => { videoCallStatus.splice(rejectedCallStatusIndex, 1) }, TIMEOUT_3000)
            } else if (!callInitiator) {
                setRecentMissedCallInRedux(contextId, callerId, currentUser.uuid, dispatch)
            } else {/** SONAR ISSUE */ }
            const { messageType, message } = callRejectMessages(isRejectedByMe, contact, callInitiator)
            sendLogsToAzure({ contextData: { component, event: `${event} ${getTrackingEvent(messageType)}`, Call_From: callerId, Event_By: rejectedParticipantID } })
            videoCallStatus[rejectedCallStatusIndex].callStatus = CALLDECLINED
            dispatch(setCallMessage({ messageType, message, contact }))
            infoLogger(`An attemplted call with contextId: ${contextId} was rejected`)
            dispatch(setVideoCallStatus([...videoCallStatus]))
        }
        resetCallDetails(incomingCall, outgoingCall, props)
    }
}

const resetCallDetails = (incomingCall: IIncomingCallDetails, outgoingCall: IOutgoingCallDetails, props: ICallRejected) => {
    const {contextId, dispatch} = props
    if(incomingCall.contextId === contextId) {
        dispatch(setIncomingCallDetails(DEFAULT_INCOMING_CALL_DEATILS))
    } else if(outgoingCall.contextId === contextId) {
        dispatch(setOutgoingCallDetails(DEFAULT_OUTGOING_CALL_DEATILS))
    } else {/** To fix Sonar issue */}
}

const callRejectMessages = (isRejectedByMe: boolean, contact: IContactInfo, callInitiator?: boolean) => {
    const { intl } = getIntlProvider()
    const { CALL_CANCELLED, CALLDECLINED, CALLMISSED, CALL_REJECTED } = CALL_MESSAGES
    let messageType = ""
    let message = ""
    if (isRejectedByMe) {
        if (callInitiator) {
            messageType = getTranslatedCallType(CALL_CANCELLED)
            message = intl.formatMessage({ id: "content.callMessages.youCancelledCall", defaultMessage: en["content.callMessages.youCancelledCall"] })
        } else {
            messageType = getTranslatedCallType(CALL_REJECTED)
            message = intl.formatMessage({ id: "content.callMessages.youDeclinedCall", defaultMessage: en["content.callMessages.youDeclinedCall"] })
        }
    } else {
        if (callInitiator) {
            messageType = getTranslatedCallType(CALLDECLINED)
            message = `${contact.name} ${intl.formatMessage({ id: "content.callMessages.declinedCall", defaultMessage: en["content.callMessages.declinedCall"] })}`
        } else {
            messageType = getTranslatedCallType(CALLMISSED)
            message = `${intl.formatMessage({ id: "content.callMessages.missedCallFrom", defaultMessage: en["content.callMessages.missedCallFrom"] })} ${contact.name}`
        }
    }
    return { messageType, message }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const { contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    const urls = fetchGlobalURLs()
    const { videoCallStatus } = state.callReducer
    const { currentUser } = state.externalReducer
    const { connectedCallDetails, incomingCall, outgoingCall } = state.callReducer.callDetails
    return { urls, currentUser, videoCallStatus, connectedCallDetails, contacts, rooms, incomingCall, outgoingCall}
}
