/*
 * Created on Fri Apr 30 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

interface Global {
    React: object,
    BroadcastChannel: object
}
declare const global: Global

import enzyme from "enzyme"
import Adapter from "enzyme-adapter-react-16"
import  React from "react"
import enableHooks from "jest-react-hooks-shallow"

enableHooks(jest, { dontMockByDefault: true })

enzyme.configure({ adapter: new Adapter() })
global.React = React

jest.mock("redux-persist", () => {
    const real = jest.requireActual("redux-persist")

    return {
        ...real,
        persistReducer: jest.fn().mockImplementation(() => jest.fn()),
        persistStore: jest.fn().mockImplementation(() => jest.fn()),
    }
})

global.BroadcastChannel = jest.fn()
