import { ERoomMoinitorRenderState, IConsoleSession } from "@rocc/rocc-client-services"
import { IMultiCamVideoTrack } from "../../common/modules/multi-camera/MultiCameraTypes"

export interface IRoomMonitorStream {
    cameraName: string
    cameraState: boolean
    hideFullscreenControl: boolean
    hideCameraControl: boolean
    renderState: ERoomMoinitorRenderState
    message: string
    videoTrackItem: IMultiCamVideoTrack | any
    isSwitchingConsoleSession: boolean
    handlefullscreenClick: (trackName: string) => void
    setVideoStarted: (state: boolean) => void
    setIsSwitchingConsoleSession: (state: boolean) => void
    consoleSession: IConsoleSession
}
