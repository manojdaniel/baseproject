import { stackedBarAssetTransformer, stackedBarDepartmentTransformer } from './AlertDashboardTransformers';

describe('stackedBarAssetTransformer', () => {
  it('transforms asset data correctly', () => {
    const input = [
      { assetID: 'A1', state: 'Overdue', count: 10 },
      { assetID: 'A1', state: 'Closed', count: 20 },
      { assetID: 'A2', state: 'Under', count: 5 },
    ];

    const expectedOutput = [
      { assetID: 'A1', overdue: 10, closed: 20, under: null },
      { assetID: 'A2', overdue: null, closed: null, under: 5 },
    ];

    expect(stackedBarAssetTransformer(input)).toEqual(expectedOutput);
  });
});

describe('stackedBarDepartmentTransformer', () => {
  it('transforms department data correctly', () => {
    const input = [
      { department: 'Sales', state: 'Overdue', count: 5 },
      { department: 'Sales', state: 'Closed', count: 15 },
      { department: 'Marketing', state: 'Under', count: 8 },
    ];

    const expectedOutput = [
      { department: 'Sales', overdue: 5, closed: 15, under: null },
      { department: 'Marketing', overdue: null, closed: null, under: 8 },
    ];

    expect(stackedBarDepartmentTransformer(input)).toEqual(expectedOutput);
  });
});
