/*
 * Created on Thu Jun 16 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EPhoneIconColor } from "../../types/types"
import { getHomepageLink, handleApplicationLogout, handleProtocolTransferExit, secondaryTopMenuLink, settingsIcon, getIconMenuItems, getInitialNavConfig } from "./NavBarHelper"

const mockDispatch = jest.fn()

jest.mock("../../utility/helpers/helpers", () => ({
    getCurrentUserData: jest.fn().mockReturnValue({
        id: "1", uuid: "1", clinicalRole: "Expert user", onBoarded: true, allRoles: ["Expert user", "Technologist", "Radiologist", "Admin"], accessToken: "token"
    }),
    getAppReducerData: jest.fn().mockReturnValue({ nfccUpgradeAvailable: false, fseData: {} }),
    getFullApplicationName: jest.fn().mockReturnValue("Philips ROCC"),
    hideNotificationModal: jest.fn(),
    getFeatureFlags: jest.fn().mockReturnValue({}),
    checkIfParticularSessionGoingOn: () => true,
    getConFigs: jest.fn().mockReturnValue({ ADMIN_MANUAL_PATH: "path1", USER_MANUAL_PATH: "path2", CUSTOMER_PRIVACY_POLICY_URL: "url" }),
    getUrls: jest.fn().mockReturnValue({ MANAGEMENT_SERVICE_URL: "url" }),
    getPreSignedUrls: jest.fn().mockReturnValue({ expertUserManual: "expert user manual", adminUserManual: "admin user manual" }),
}))

describe("Unit tests for NavBarHelper", () => {
    const props = {
        phoneIconColor: EPhoneIconColor.GREEN,
        logoutText: "",
        protocolTransferStatus: true,
        dispatch: jest.fn(),
        count: 1,
        showNfccDownload: true,
        phoneIconCallBack: jest.fn(),
        aboutClick: jest.fn(),
        isAdminOnly: false,
        isTechAppDownloadAvailable: true,
        cctvWindow: true
    }

    describe("Unit tests for NavbarHelpers ", () => {

        it("should call function handleProtocolTransferExit with props as true", () => {
            expect(handleProtocolTransferExit(true, mockDispatch))
        })
        it("should call function handleProtocolTransferExit with props as false", () => {
            expect(handleProtocolTransferExit(false, mockDispatch))
        })
        it("should call function secondaryTopMenuLink", () => {
            expect(secondaryTopMenuLink("Link"))
        })
        it("should call function handleApplicationLogout", () => {
            expect(handleApplicationLogout(mockDispatch, "/logout"))
        })
        it("should call function settingsIcon", () => {
            expect(settingsIcon(true, mockDispatch, true, true))
        })
        it("should get HomepageLink", () => {
            expect(getHomepageLink()).toBeDefined()
        })
        it("should get IconMenuItems", () => {
            expect(getIconMenuItems(props)).toBeDefined()
        })
        it("should get InitialNavConfig", () => {
            expect(getInitialNavConfig(props)).toBeDefined()
        })
    })
})
