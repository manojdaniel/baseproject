/*
 * Created on Thu May 16 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { safeURL } from "./apiUtility"

describe("safe url", () => {
    it("should append uri if not present on url", () => {
        const safeUrlReturn = safeURL("https://some-url.com/", "uri")
        expect(safeUrlReturn).toEqual("https://some-url.com/uri")
    })

    it("should return url as is if uri already present on url", () => {
        const safeUrlReturn = safeURL("https://some-url.com/uri", "uri")
        expect(safeUrlReturn).toEqual("https://some-url.com/uri")
    })
})
