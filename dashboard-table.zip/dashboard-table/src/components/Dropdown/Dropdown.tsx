import React from "react";
import Select from "react-select";
import "./Dropdown.scss";

interface Props {
	options?: any;
	handleChange?: any;
	value?: any;
	defaultValue?: any;
	multi?: any;
	name?: any;
	loading?: any;
}

// initial
const Dropdown = ({
	options,
	handleChange,
	value,
	defaultValue,
	multi,
	name,
	loading,
}: Props) => {
	return (
		<>
			<Select
				styles={{
					option: (provided, state) => ({
						...provided,
						color: "#333333",
						backgroundColor: state.isSelected ? "red" : "white",
						borderColor: state.isFocused ? "transparent" : "transparent",
					}),
					control: (baseStyles, state) => ({
						...baseStyles,
						borderColor: state.isFocused ? "transparent" : "transparent",
					}),
					valueContainer: (provided) => ({
						...provided,
						height: "30px",
						padding: "0 6px",
					}),
				}}
				className="react-select"
				classNamePrefix="react-select"
				// background:#c5E7F7
				options={options}
				onChange={handleChange}
				data-testid="select"
				value={value}
				defaultValue={defaultValue}
				isLoading={loading}
				//menuIsOpen={true}
				placeholder={defaultValue !== "" ? defaultValue : name}
				// isMulti={multi}
				components={
					multi && {
						DropdownIndicator: () => null,
						IndicatorSeparator: () => null,
					}
				}
			/>
		</>
	);
};

export default Dropdown;
