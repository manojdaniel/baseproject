"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
import traceback

from src.constants.constants import HSDP_ORGANIZATION_ID, ROUTING_KEY, OPERATION, JOB_LIST, CURRENT_JOB, TARGET_QUEUE, TRANSACTION_ID, ENTITY_ID, ENTITY_TYPE, \
    JOB_NAME, INDEX, STATUS, NOT_STARTED, INIT, OPERATION_STATUS, SERVICE_AUTH_ISSUER, SERVICE_AUTH_PRIVATE_KEY, HSDP_IAM_URL, DATA, ROCC_SERVICE_TOOL_ROUTING_KEY, USER_UUID
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.common_query_functions import fetch_overwatch_customer_id_from_name
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_job_id_from_name, fetch_task_id_from_name, insert_job_transaction_object, \
    create_update_existing_customer_transaction_data
from src.modules.event_management.event_enums import EEntity, EJobs, EOperations, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.operation_management.operation_handler import OperationHandler
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.rabbitmq.rabbitmq_utility import compute_rmq_queue_name

LOG = create_logger("BulkUploadExistingCustomer")


class BulkUploadExistingCustomer(OperationHandler):

    def __init__(self, entity_identifier, user_detail):
        """
        1. Create a new transaction in transaction table
        2. Post message to RabbitMQ with Payload
        3. Return transaction_id (operation_id) to the caller
        """
        try:
            self._user_uuid = user_detail
            organization_vault_values = get_path_specific_vault_values(path_name=entity_identifier)
            self.org_infra_uuid=organization_vault_values[DATA][HSDP_ORGANIZATION_ID]
            self._service_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                                  issuer=organization_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                                  private_key=organization_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            self._client = get_client_connection(self._service_token, org_infra_uuid=organization_vault_values[DATA][HSDP_ORGANIZATION_ID])
        except RoccException as ex:
            LOG.error(f"Error occurred while creating service token: {ex}")
            LOG.error(traceback.print_exc())
        except Exception as ex:
            LOG.error(f"Error occurred while creating service token: {ex}")
            LOG.error(traceback.print_exc())

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self.org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Update Customer", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._user_uuid,
                                       org_id=self.org_infra_uuid, token=self._service_token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def create_transaction(self, entity_identifier, file_identifier):
        """
        1. Create a new transaction in transaction table
        2. Return transaction_id (operation_id) to the caller
        """
        try:
            LOG.info("Adding a new transaction record at DB for the operation: BulkUploadExistingCustomer")
            transaction_data = create_update_existing_customer_transaction_data(client=self._client)
            job_id = fetch_job_id_from_name(job_name=EJobs.CUSTOMER_DATA_INSERTION.value, client=self._client)
            task_id = fetch_task_id_from_name(task_name=ETasks.SITE_DATA_INSERTION.value, client=self._client)
            entity_id = fetch_overwatch_customer_id_from_name(customer_name=entity_identifier, client=self._client)
            transaction_id = insert_job_transaction_object(operation_type=EOperations.UPDATE_EXISTING_CUSTOMER.value,
                                                           job_id=job_id,
                                                           task_id=task_id,
                                                           entity_id=entity_id,
                                                           entity_type=EEntity.CUSTOMER.value,
                                                           file_identifier=file_identifier,
                                                           transaction_data=transaction_data,
                                                           user_uuid=self._user_uuid,
                                                           client=self._client)
            self.safe_audit(event_subtype="Bulk upload for Customer initiated.", action="U",
                            outcome=0, code="Bulk upload for Customer initiated.", value="Success")
            return transaction_id

        except RoccException as ex:
            LOG.error(f"Error while storing transaction in DB {ex}")
            self.safe_audit(event_subtype="Bulk upload for Customer", action="U",
                            outcome=8, code="Bulk upload for Customer", value="Error")
            raise RoccException(ex.status_code, str(ex.payload)) from ex

    def post_message(self, transaction_id, entity_identifier):
        """
        1. Post message to RabbitMQ with Payload
        """
        payload = {
            TRANSACTION_ID: transaction_id,
            OPERATION: EOperations.UPDATE_EXISTING_CUSTOMER.value,
            OPERATION_STATUS: INIT,
            CURRENT_JOB: EJobs.CUSTOMER_DATA_INSERTION.value,
            JOB_LIST: [
                {INDEX: 1, JOB_NAME: EJobs.CUSTOMER_DATA_INSERTION.value, STATUS: NOT_STARTED},
                {INDEX: 2, JOB_NAME: EJobs.VALIDATE_ONBOARDED_DATA.value, STATUS: NOT_STARTED},
                {INDEX: 3, JOB_NAME: EJobs.COMPLETE.value, STATUS: NOT_STARTED},
            ],
            ROUTING_KEY: ROCC_SERVICE_TOOL_ROUTING_KEY,
            TARGET_QUEUE: compute_rmq_queue_name(),
            ENTITY_TYPE: EEntity.CUSTOMER.value,
            ENTITY_ID: entity_identifier,
            USER_UUID: self._user_uuid
        }
        LOG.info("Publishing a rabbitMQ message after creating a transaction for the operation: BulkUploadExistingCustomer")
        publish_message(payload=payload)

    def initiate_operation(self, entity_identifier, file_identifier):

        transaction_id = self.create_transaction(entity_identifier=entity_identifier,
                                                 file_identifier=file_identifier)
        self.post_message(transaction_id=transaction_id,
                          entity_identifier=entity_identifier)
        return transaction_id
