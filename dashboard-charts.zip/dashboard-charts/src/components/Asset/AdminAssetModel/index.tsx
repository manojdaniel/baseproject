// @ts-nocheck
import React, { useState, useEffect } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import HighchartsExporting from "highcharts/modules/exporting";
HighchartsExporting(Highcharts);
Highcharts.AST.allowedAttributes.push("onclick");

interface Props {
	GraphicalImageByAssetId: any[];
	mysensorGroupId: any;
	AnomalyModelbyAssetId: any[];
}

var datafortesting = [],
	n = 10000,
	i: any;
for (i = 0; i < n; i += 1) {
	datafortesting.push([
		Math.pow(Math.random(), 1) * 100,
		Math.pow(Math.random(), 1) * 100,
	]);
}

const AdminAssetModel = ({
	GraphicalImageByAssetId,
	mysensorGroupId,
}: Props) => {
	const [imageData, setImageData] = useState<any>("");

	useEffect(() => {
		if (GraphicalImageByAssetId && GraphicalImageByAssetId.length > 0) {
			setImageData(GraphicalImageByAssetId[0].image);
		}
	}, [GraphicalImageByAssetId]);

	useEffect(() => {}, [mysensorGroupId]);

	const getHighcharts = () => ({
		chart: {
			type: "scatter",
			zoomType: "xy",
			backgroundColor: "#ffffff",
			plotBackgroundImage: `${imageData}`,
		},
		title: {
			text: null,
		},
		xAxis: {
			visible: false,
			min: 0,
			max: 100,
		},
		yAxis: {
			visible: false,
			min: 0,
			max: 100,
		},

		navigation: {
			buttonOptions: {
				theme: {
					states: {
						hover: {
							fill: "#fff",
						},
						select: {
							fill: "#f7f8fa",
						},
					},
				},
			},
			menuItemStyle: {
				fontWeight: "normal",
				color: "#4d4d4d",
			},
			menuItemHoverStyle: {
				fontWeight: "bold",
				background: "#009FDF",
				color: "#fff",
			},
		},
		plotOptions: {
			scatter: {
				marker: {
					radius: 3,

					symbol: "square",
					lineWidth: 0.5,
					lineColor: "#00000000",
					states: {
						hover: {
							enabled: true,
						},
					},
				},
				states: {
					hover: {
						marker: {
							enabled: false,
						},
					},
				},
			},
		},
		tooltip: {
			useHTML: true,
			backgroundColor: "#000000",
			borderRadius: 10,
			borderColor: "#000000",
			valueDecimals: 2,
			animation: true,
			font: "SabicRegular",
			style: {
				color: "white",
				opacity: 0.75,
				shadow: "0px 3px 6px #000000",
				pointerEvents: "auto",
			},
			hideDelay: 1000,
			formatter() {
				const { point } = this;
				return `<div style="width:250px;padding:25px;border-radius:5px !important;font-family:'SabicRegular';"><div><div style="font-size:1rem;text-transform:uppercase;border-bottom:1px solid white;white-space:break-spaces;margin-bottom:10px;width:100%;text-align:center;padding-bottom:5px;font-weight:normal !important;font-family: 'SabicHeadlineRegular';">X: ${point.x} Y: ${point.y}</div></div></div>`;
			},
		},

		series: [
			{
				color: "#00000000",
				data: datafortesting,
			},
		],
	});

	return <HighchartsReact highcharts={Highcharts} options={getHighcharts()} />;
};

export default AdminAssetModel;
