"""
 Created on Fri Oct 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from src.constants.constants import ROCC_KVM_CONFIGURATIONS
from src.constants.headers import EXCEL_KVM_BOXILLA_IP, EXCEL_KVM_BOXILLA_USER_NAME, EXCEL_KVM_BOXILLA_REST_USER_NAME
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import check_if_kvm_data_exists

LOG = create_logger("KvmDataValidationService")


def check_if_data_exists(client, kvm_details, org_db_id):
    try:
        variable = {"org_id": org_db_id, "boxilla_ip": kvm_details[EXCEL_KVM_BOXILLA_IP],
                    "boxilla_user_name": kvm_details[EXCEL_KVM_BOXILLA_USER_NAME],
                    "boxilla_rest_user_name": kvm_details[EXCEL_KVM_BOXILLA_REST_USER_NAME]}
        response = check_if_id_is_present(client.execute(
            check_if_kvm_data_exists, variable_values=variable), ROCC_KVM_CONFIGURATIONS)
        return response
    except Exception as ex:
        LOG.error(
            f"Exception occurred while checking if kvm config data exists {ex}")
        LOG.error(traceback.print_exc())
    return False
