"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os
from cli_utility.scripts.utility import check_and_update_profile_configs_in_vault, fetch_profile_configs_for_cli, fetch_config_value, fetch_selfservice_profile_configs_for_cli
from src.constants.config_keys import VAULT_HSDP_IAM_URL, VAULT_HSDP_IDM_URL, VAULT_PARENT_APP_NAME, \
    VAULT_PARENT_AUTH_SERVICE_NAME, VAULT_PARENT_OAUTH_CLIENT_ID, VAULT_PARENT_OAUTH_NAME, \
    VAULT_PARENT_OAUTH_PASSWORD, VAULT_PARENT_ORG_NAME, VAULT_PARENT_ORG_ID, VAULT_PARENT_PROPOSITION_NAME, VAULT_PARENT_SERVICE_AUTH_ISSUER, \
    VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY, \
    VAULT_ROOT_SERVICE_AUTH_ISSUER, VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY
from src.constants.constants import ROCC_PROXY_URL, COMPLETED, FAILED
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.parent_org_setup.service_tools_infra_setup import ServiceToolsInfraSetup
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.hsdp_idm_services.manage_identity_services import create_application_service, create_oauth_client_service, \
    create_proposition_service, create_service_identity, update_client_scope_service
from src.wrappers.infrastructure_services.policy_services.manage_policy_services import create_all_policies, delete_password_policy, delete_policies
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import create_global_vault_values, create_parent_org_specific_vault_values, get_profile_data, create_selfservice_vault_values
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit
from src.wrappers.platform_services.iam_service.authorization_services import create_allowed_org_mapping
from src.wrappers.platform_services.iam_service.rocc_iam_infra_setup import create_security_questions
from src.wrappers.platform_services.management_service.manage_redis_services import load_redis_in_bulk, store_values_in_redis

LOG = create_logger("ParentOrgInfraSetup")


class ParentOrgInfraSetup:
    def __init__(self):
        self._success = False
        self._policy_ids = []
        self._password_policy_id = None
        self._parent_token = None

    def start_job(self, vault_credentials_response, policy_create, user_details, profile_configs=None, rocc_proxy_url=None):
        try:
            LOG.info(f"Starting Job: {EJobs.PARENT_ORG_SETUP.value}")
            self.load_proxy_url(rocc_proxy_url=rocc_proxy_url)
            self.load_vault_configs(profile_configs)
            self._user_uuid = user_details["userId"]
            self._user_org = user_details["orgId"]
            self._token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                          issuer=self._profile_configs[VAULT_ROOT_SERVICE_AUTH_ISSUER],
                                                          private_key=self._profile_configs[VAULT_ROOT_SERVICE_AUTH_PRIVATE_KEY])
            self._parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
            self.execute_tasks(
                policy_create, vault_credentials_response=vault_credentials_response)
            self.post_audit(sub_type=EJobs.PARENT_ORG_SETUP.value, action="E", outcome=0, **{
                            EJobs.PARENT_ORG_SETUP.value: COMPLETED}, **{"User Org Details": self._user_org})
            LOG.info(f"Finished Job: {EJobs.PARENT_ORG_SETUP.value}")
        except RoccException as ex:
            LOG.error("Exception {ex}")
            raise RoccException(ex.status_code, str(ex.payload)) from ex
        return self._success

    def post_audit(self, sub_type, action, outcome, **kwargs):
        if self._parent_token:
            prepare_and_post_audit(event_type=EJobs.PARENT_ORG_SETUP.value,
                                   event_subtype=sub_type, action=action, outcome=outcome,
                                   user_detail=self._user_uuid,
                                   org_id=self._parent_org_id,
                                   token=self._parent_token,
                                   **kwargs)

    def load_vault_configs(self, profile_configs):
        """Fetch vault configs from the profile path"""
        try:
            self._profile_configs = get_profile_data(
            ) if not profile_configs else profile_configs
        except Exception as ex:
            self._success = False
            LOG.error(
                f"Failed to retrieve vault profile configs with error: {ex}")
            raise RoccException(
                500, f"Failed to retrieve vault profile configs with error: {ex}") from ex

    def load_proxy_url(self, rocc_proxy_url=None):
        """Fetch proxy url"""
        try:
            self._rocc_proxy_url = rocc_proxy_url if rocc_proxy_url else os.environ[
                ROCC_PROXY_URL]
        except Exception as ex:
            self._success = False
            LOG.error(f"Failed to retrieve proxy url with error: {ex}")
            raise RoccException(
                500, f"Failed to retrieve proxy url with error: {ex}") from ex

    def roll_back_on_failure(self):
        """ Roll-back, if there is a failed task """
        if len(self._policy_ids) > 0:
            delete_policies(token=self._token, policy_ids=self._policy_ids,
                            profile_configs=self._profile_configs)
        if self._password_policy_id:
            delete_password_policy(
                token=self._token, profile_configs=self._profile_configs, policy_id=self._password_policy_id)

    def execute_tasks(self, policy_create, vault_credentials_response):
        """
        Tasks:
        - CREATE_PROPOSITION
        - CREATE_APPLICATION
        - CREATE_SERVICE
        - CREATE_OAUTH_CLIENT
        - UPDATE_CLIENT_SCOPE
        - CREATE_VAULT_VALUES(AuthCredentials & SelfService)
        - CREATE_ALL_POLICIES
        - CREATE_SECURITY_QUESTIONS
        """
        try:
            proposition_id = self.task_create_proposition()
            application_id = self.task_create_application(proposition_id)
            service_identity_response = self.task_create_service(
                application_id)
            if service_identity_response:
                check_and_update_profile_configs_in_vault(
                    PARENT_SERVICE_AUTH_ISSUER=service_identity_response["serviceId"],
                    PARENT_SERVICE_AUTH_PRIVATE_KEY=service_identity_response["privateKey"].replace("-----BEGIN RSA PRIVATE KEY-----", "").replace("-----END RSA PRIVATE KEY-----", ""))
                self._profile_configs, vault_credentials_response, profile_path = fetch_profile_configs_for_cli()
                LOG.debug(f"profile_path {profile_path}")
            # Fetch SelfService profile configs
            self._selfservice_profile_configs, selfservice_profile_path = fetch_selfservice_profile_configs_for_cli(
                vault_credentials=vault_credentials_response)
            LOG.debug(f"selfservice_profile_path {selfservice_profile_path}")
            oauth_client_id = self.task_create_oauth_client(application_id)
            self.task_update_client_scope(oauth_client_id)
            if policy_create:
                self.task_create_all_policies()
            else:
                LOG.warn(
                    "Skipping policy creation and executing only the service tool policy")
                self.setup_service_tool_policy()
            self.task_update_global_vault_values(
                service_identity_response, vault_credentials_response=vault_credentials_response)
            # Create SelfService Vault values if not present already
            if self._selfservice_profile_configs is None:
                self.task_update_selfservice_vault_values(
                    vault_credentials_response=vault_credentials_response)

            self._parent_token = create_service_token_from_vault(iam_url=self._profile_configs[VAULT_HSDP_IAM_URL],
                                                                 issuer=self._profile_configs[
                                                                     VAULT_PARENT_SERVICE_AUTH_ISSUER],
                                                                 private_key=self._profile_configs[VAULT_PARENT_SERVICE_AUTH_PRIVATE_KEY])
            self.task_populate_global_redis()
            self.task_create_allowed_org_mapping()
            self.task_create_security_questions()
            self._success = True
        except RoccException as ex:
            LOG.error(
                f"ParentOrgSetup failed during execution with ROCC exception, hence initiating roll-back, error: {ex}")
            self.roll_back_on_failure()
        except Exception as ex:
            LOG.error(
                f"ParentOrgSetup failed during execution with general exception, hence initiating roll-back, error: {ex}")
            self.roll_back_on_failure()

    def task_create_security_questions(self):
        response = create_security_questions(url=self._rocc_proxy_url,
                                             token=self._parent_token,
                                             org_id=self._parent_org_id)
        if not response:
            LOG.error(
                f"Task: {ETasks.CREATE_SECURITY_QUESTIONS.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
        LOG.info(
            f"Security questions are created/updated successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")

    def setup_service_tool_policy(self):
        LOG.info("Initiating service tool policy setup")
        service_tool_set_up = ServiceToolsInfraSetup()
        service_tool_set_up.task_create_service_tools_policy(
            token=self._token, profile_configs=self._profile_configs)

    def task_create_all_policies(self):
        self._policy_ids, self._password_policy_id = create_all_policies(token=self._token,
                                                                         profile_configs=self._profile_configs)
        self.post_audit(sub_type=ETasks.CREATE_ALL_POLICIES.value,
                        action="E", outcome=0, **{"Policy creation": COMPLETED})
        if len(self._policy_ids) == 0:
            LOG.error(
                f"Task: {ETasks.CREATE_ALL_POLICIES.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            self.post_audit(sub_type=ETasks.CREATE_ALL_POLICIES.value,
                            action="E", outcome=12, **{"Policy creation": FAILED})
            raise RoccException(status_code=500, payload=str(
                "Failed to create all policies"))
        LOG.info(
            f"Policy ids that were created as part of parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]} are: {self._policy_ids}")

    def task_update_global_vault_values(self, service_identity_response, vault_credentials_response):
        global_vault_response = create_global_vault_values(service_response=service_identity_response,
                                                           profile_configs=self._profile_configs,
                                                           vault_credentials_response=vault_credentials_response)
        parent_vault_response = create_parent_org_specific_vault_values(profile_configs=self._profile_configs,
                                                                        vault_credentials_response=vault_credentials_response)
        self.post_audit(sub_type=ETasks.CREATE_VAULT_VALUES.value,
                        action="E", outcome=0, **{"Update vault values": COMPLETED})
        if not (global_vault_response and parent_vault_response):
            LOG.error(
                f"Task: {ETasks.CREATE_VAULT_VALUES.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            self.post_audit(sub_type=ETasks.CREATE_VAULT_VALUES.value,
                            action="E", outcome=12, **{"Update vault values": FAILED})
            raise RoccException(status_code=500, payload=str(
                "Failed to create/update global vault values"))
        LOG.info(
            f"Global Vault values are created/updated successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")

    def task_update_selfservice_vault_values(self, vault_credentials_response):
        crm_client_secret = fetch_config_value("CRM_CLIENT_SECRET_KEY")
        crm_key = fetch_config_value("CRM_KEY")
        self_service_path = fetch_config_value("SELFSERVICE_PROFILE")
        self_service_vault_response = create_selfservice_vault_values(
            crm_client_secret, crm_key, self_service_path, vault_credentials_response=vault_credentials_response)

        self.post_audit(sub_type=ETasks.CREATE_SELFSERVICE_VAULT_VALUES.value,
                        action="E", outcome=0, **{"Update vault values": COMPLETED})
        if not self_service_vault_response:
            LOG.error(
                f"Task: {ETasks.CREATE_SELFSERVICE_VAULT_VALUES.value} failed")
            self.post_audit(sub_type=ETasks.CREATE_SELFSERVICE_VAULT_VALUES.value,
                            action="E", outcome=12, **{"Update vault values": FAILED})
            raise RoccException(status_code=500, payload=str(
                "Failed to create/update SelfService vault values"))
        LOG.info("SelfService values are created/updated successfully")

    def task_update_client_scope(self, oauth_client_id):
        update_client_scope_response, error_reasn = update_client_scope_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                                                token=self._token,
                                                                                oauth_client_id=oauth_client_id)
        if not update_client_scope_response:
            LOG.error(
                f"Task: {ETasks.UPDATE_CLIENT_SCOPE.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            raise RoccException(status_code=500, payload=str(
                f"Failed to update client scope:{error_reasn}"))
        LOG.info(
            f"CLIENT_SCOPE is updated successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")

    def task_create_oauth_client(self, application_id):
        oauth_client_id, error_reasn = create_oauth_client_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                                   token=self._token,
                                                                   application_id=application_id,
                                                                   name=self._profile_configs[VAULT_PARENT_OAUTH_NAME],
                                                                   description=self._profile_configs[
                                                                       VAULT_PARENT_OAUTH_NAME],
                                                                   client_id=self._profile_configs[
                                                                       VAULT_PARENT_OAUTH_CLIENT_ID],
                                                                   password=self._profile_configs[VAULT_PARENT_OAUTH_PASSWORD],
                                                                   org_name=self._profile_configs[VAULT_PARENT_ORG_NAME])
        if not oauth_client_id:
            LOG.error(
                f"Task: {ETasks.CREATE_OAUTH_CLIENT.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            raise RoccException(status_code=500, payload=str(
                f"Failed to create OAuth Client:{error_reasn}"))
        LOG.info(
            f"OAuth Client: {oauth_client_id} is created successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
        return oauth_client_id

    def task_create_service(self, application_id):
        service_identity_response, error_reasn = create_service_identity(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                                         token=self._token,
                                                                         application_id=application_id,
                                                                         name=self._profile_configs[
                                                                             VAULT_PARENT_AUTH_SERVICE_NAME],
                                                                         description=self._profile_configs[VAULT_PARENT_AUTH_SERVICE_NAME])
        if not service_identity_response:
            LOG.error(
                f"Task: {ETasks.CREATE_SERVICE.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            raise RoccException(status_code=500, payload=str(
                f"Failed to create service identity:{error_reasn}"))
        LOG.info(
            f"Service: {service_identity_response} is created successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
        return service_identity_response

    def task_create_application(self, proposition_id):
        application_id, error_resn = create_application_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                                token=self._token,
                                                                proposition_id=proposition_id,
                                                                name=self._profile_configs[VAULT_PARENT_APP_NAME],
                                                                description=self._profile_configs[VAULT_PARENT_APP_NAME])
        if not application_id:
            LOG.error(
                f"Task: {ETasks.CREATE_APPLICATION.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            raise RoccException(status_code=500, payload=str(
                f"Failed to create application:{error_resn}"))
        LOG.info(
            f"Application: {application_id} is created successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
        return application_id

    def task_create_proposition(self):
        proposition_id, error_reasn = create_proposition_service(idm_url=self._profile_configs[VAULT_HSDP_IDM_URL],
                                                                 token=self._token,
                                                                 org_id=self._profile_configs[VAULT_PARENT_ORG_ID],
                                                                 name=self._profile_configs[VAULT_PARENT_PROPOSITION_NAME],
                                                                 description=self._profile_configs[VAULT_PARENT_PROPOSITION_NAME])
        if not proposition_id:
            LOG.error(
                f"Task: {ETasks.CREATE_PROPOSITION.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
            raise RoccException(status_code=500, payload=str(
                f"Failed to create proposition:{error_reasn}"))
        LOG.info(
            f"Proposition: {proposition_id} is created successfully for ParentOrg: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
        return proposition_id

    def task_populate_global_redis(self):
        try:
            """ Parent org's redis details are loaded from Global vault data's customerMap using bulkCreation API """
            bulk_response = load_redis_in_bulk(
                token=self._parent_token, url=self._rocc_proxy_url)
            org_response, error_reasn = store_values_in_redis(
                url=self._rocc_proxy_url, token=self._parent_token)
            self.post_audit(sub_type="Populate global redis value", action="E",
                            outcome=0, **{"Create/Update global redis values": COMPLETED})
            if not (bulk_response and org_response):
                LOG.error(
                    f"Task: {ETasks.MANAGE_REDIS.value} failed for parent org: {self._profile_configs[VAULT_PARENT_ORG_ID]}")
                self.post_audit(sub_type="Populate global redis value", action="E",
                                outcome=12, **{"Create/Update global redis values": FAILED})
                raise RoccException(status_code=500, payload=str(
                    f"Failed to create/update global and parent redis values:{error_reasn}"))
        except Exception as ex:
            LOG.error(f"Failed to load values in Redis. Error {ex}")

    def task_create_allowed_org_mapping(self):
        parent_org_id = self._profile_configs[VAULT_PARENT_ORG_ID]
        response = create_allowed_org_mapping(token=self._parent_token,
                                              url=self._rocc_proxy_url,
                                              org_id=parent_org_id,
                                              use_org_context=True)
        if not response:
            LOG.error("Failed to create allowed org mapping")
            raise RoccException(500, "Failed to create allowed org mapping")
