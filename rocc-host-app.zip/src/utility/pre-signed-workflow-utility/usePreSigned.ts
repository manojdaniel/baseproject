/*
 * Created on Mon Aug 1 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EAppContext, EFetchStatus, EPresignedStatus, IParentStore, IPresignedWorkflow } from "@rocc/rocc-client-services"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { API_VERSION, APPLICATION_JSON, CONTENT_TYPE, DEFAULT_API_VERSION, HASH_JWT } from "../../constants/constants"
import { fetchLocationData } from "../../redux/actions/customerActions"
import { addPresignedWorkflow } from "../../redux/actions/workflowActions"
import { postService } from "../api/apiUtility"
import { computeMessageAndStatusBasedOnVerification } from "./presignedUtility"

export const usePreSigned = () => {
    const { appContext, currentUser, locationFetched, urls } = useSelector((state: IParentStore) => ({
        appContext: state.appReducer.appContext,
        currentUser: state.userReducer.currentUser,
        locationFetched: state.customerReducer.locationFetched,
        urls: state.configReducer.urls,
    }))
    const dispatch = useDispatch()
    useEffect(() => {
        const executePreSignedTasks = async () => {
            if (appContext === EAppContext.PRE_SIGNED) {
                /* 
                1. Run validation on JWT
                    - On failure, Handle Failure cases, if any
                    - On success, Load controlled data
                */
                const validationResponse = await validateJwt()
                const presignedData = validationResponse.data
                const presignedInitialStatus = validationResponse.presignedInitialStatus
                const deviceUuid = (presignedData?.resourceData?.customPayload?.subjectId ?? presignedData?.resourceData?.customPayload?.resourceIdentifier) ?? ""
                if (presignedInitialStatus === EPresignedStatus.VALID && presignedData?.resourceData) {
                    fetchLocationDetails(deviceUuid)
                }
                createPresignedWorkflow(presignedData.resourceData, presignedInitialStatus, validationResponse.errorMessage)
            } else {
                fetchLocationDetails()
            }
        }
        executePreSignedTasks()
    }, [])

    const fetchLocationDetails = (deviceUuid?: String) => {
        if (currentUser.id && [EFetchStatus.notStarted, EFetchStatus.failed].includes(locationFetched)) {
            dispatch(fetchLocationData(currentUser.uuid, deviceUuid ? [deviceUuid] : undefined))
        }
    }

    const createPresignedWorkflow = (resourceData: any, presignedInitialStatus: EPresignedStatus, errorMessage: string) => {
        const additionalAttributes = resourceData?.customPayload?.additionalParams ?? {}
        if (errorMessage) {
            additionalAttributes.errorMessage = errorMessage
        }
        const presignedWorkflow: IPresignedWorkflow = {
            id: resourceData?.jti ?? "",
            resourceId: (resourceData?.customPayload?.subjectId ?? resourceData?.customPayload?.resourceIdentifier) ?? "",
            subject: resourceData?.sub ?? "",
            startTime: resourceData?.nbf ?? "",
            expiryTime: resourceData?.exp ?? "",
            hashCode: "",
            status: presignedInitialStatus,
            additionalAttributes,
        }
        dispatch(addPresignedWorkflow(presignedWorkflow))
        if (!resourceData?.customPayload) {
            errorLogger(`CustomPayload is not available, please make sure presigned url is created properly`)
        }
    }

    const validateJwt = async () => {
        try {
            const headers = { [CONTENT_TYPE]: APPLICATION_JSON, Authorization: currentUser.accessToken, [API_VERSION]: DEFAULT_API_VERSION }
            const jwtToken = sessionStorage.getItem(HASH_JWT)
            const response = await postService({
                headers,
                url: `${urls.PROXY_URL}/auth/ResourceAuthorization/$validate`,
                body: { jwtToken }
            })
            const { errorMessage, presignedInitialStatus } = computeMessageAndStatusBasedOnVerification(response)
            sessionStorage.removeItem(HASH_JWT)
            return { data: response.data, presignedInitialStatus, errorMessage }
        } catch (error: any) {
            const { errorMessage, presignedInitialStatus } = computeMessageAndStatusBasedOnVerification(error?.response)
            errorLogger(`Failed to verify the pre-signed url with error: ${errorParser(error)}`)
            errorLogger(error)
            return { data: "", presignedInitialStatus, errorMessage }
        }
    }
}
