/*
 * Created on Fri Dec 3 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, ECameraStreamAvailable, EConnectionMode, EConnectionState, EConnectionType, EDefaultTransactionValue, ERoccWorkflow, ETransactionStatus, IConsoleSession, TransactionValue } from "@rocc/rocc-client-services"
import { EMultiSessionModalNextAction } from "@rocc/rocc-console-components"
import { rooms } from "../../mocks/mock-data"
import { ECommandCenterAccessMode, IConsoleTransaction, IRoomInfo } from "../../redux/interfaces/types"
import * as externalAppStates from "../../redux/store/externalAppStates"
import * as consoleService from "../../services/consoleService"
import { EMERALD_APP_NAME, EMERALD_APP_URI_RESTART, EMERALD_APP_URI_START, EMERALD_APP_URI_STOP, EMERALD_APP_URI_STOP_ALL } from "../constants/constants"
import { CONSOLE_TRANSACTION } from "../constants/endpoints"
import { checkCallStatus, checkIfAnyActiveTransaction, checkIfEditConsoleEnabled, checkIfEmeraldEditEnabled, checkIfEmeraldGoingOn, checkIfIncognitoConsoleEnabled, checkIfParkedConsoleEnabled, checkIfReceiverInUse, checkIfViewConsoleEnabled, constructAppUriConfigsforPID, convertConsoleSessionToTransaction, fetchActiveSession, fetchActiveSessionForReceiver, fetchActiveSessionToBeDisconnected, fetchActiveTransactionIndex, fetchConsoleSessionByRoomUuid, fetchFirstWaitingTransactionIndex, fetchTransactionForRoomAndStatus, fetchTransactionForStatus, fetchTransactionIndexForState, fetchTransactionIndexForStatus, fetchViewConsoleSessionForRoom, generateUniqueId, getActionFromWorkflowType, getActiveSessionConsoleRoom, getActiveSessionsForConnectionMode, getConsoleConnectionErrorMessage, getCurrentRoom, getNFCCMaxlimitMessage, getPidFromContextMapping, getRoomConnection, getSpokeMessage, hasActiveVidoCallWithRoom, isDev, isDevice, isMaximumNFCCLimitReached, isNonCommandCenterViewConnection, messageEditToView, messageViewToEdit, updateSpokeQualifiedCheckboxStatus } from "./helpers"

const sessions: IConsoleSession = {
    contextId: "contextId",
    requester: "requester",
    roomUuid: "roomUuid",
    connectionType: EConnectionType.VIEW,
    connectionMode: EConnectionMode.CC,
    connectionStatus: EConnectionState.CONNECTED,
    receiverName: "receiverName",
    displayCameraToggle: true,
    mediaRoomDetails: {
        cameraStreamAvailable: ECameraStreamAvailable.IDLE,
        mediaRoomId: "",
        mediaRoomToken: ""
    },
    multiCameraList: [],
    consoleStartTime: "consoleStartTime",
}
const transactions: IConsoleTransaction = {
    transactionStatus: ETransactionStatus.IDLE,
    roomUuid: "roomUuid",
    connectionType: EConnectionType.VIEW,
    connectionMode: EConnectionMode.CC,
    connectionStatus: EDefaultTransactionValue.CONNECTING,
    receiverName: "Dev-receiver",
    transactionId: "",
    groupId: "",
}
const mockErrObject = {
    response: {
        data: {
            httpStatusCode: 423
        }
    }
}

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        consoleReducer: { consoleSessions: [], commandCenterDetails: { commandCenterSeat: { receivers: [{ id: "id" }] } } },
        externalReducer: {
            callDetails: {
                connectedCallDetails: {
                    participants: [{
                        callStatus: "CALL_ACCEPT", roomUuid: "roomUuid"
                    }]
                },
                onHoldCallDetails: [],
            }
        }
    })
}))

jest.mock("../../redux/store/globalStore", () => ({
    ...jest.requireActual("../../redux/store/globalStore"),
    GetGlobalState: jest.fn().mockReturnValue({
        CC_CALLING: {
            callReducer: {
                callDetails: {
                    outgoingCall: {
                        participant: {
                            uuid: "roomUuid"
                        }
                    },
                    connectedCallDetails: {
                        participants: [{ uuid: "roomUuid", callStatus: "CALL_ACCEPT" }],
                    }
                }
            }
        },
        CC_HOST: {
            userReducer: {
                currentUser: {}
            },
            configReducer: {
                configs: {
                    ROCC_DEV: "true"
                }
            },
            featureFlagsReducer: {
                featureFlags: {
                    "rocc-emerald-cli": true
                }
            }
        }
    }),
}))

describe("checkIfViewConsoleEnabled tests", () => {
    it("should return boolean", () => {
        expect(checkIfViewConsoleEnabled({ CONSOLE_VIEW: true }, [{ id: 1, receiverName: "", monitorName: "", isSelected: false }])).toEqual(true)
    })
})
describe("checkIfEditConsoleEnabled tests", () => {
    it("should return boolean", () => {
        expect(checkIfEditConsoleEnabled({ "rocc-command-center-view": true }, [{ id: 1, receiverName: "", monitorName: "", isSelected: false }], EConnectionMode.EMERALD)).toEqual(false)
    })
})

describe("checkIfEmeraldEditEnabled  tests", () => {
    it("should return boolean", () => {
        expect(checkIfEmeraldEditEnabled({ "rocc-command-center-view": true }, "kvm", EConnectionMode.CC)).toEqual(false)
    })
})

describe("getConsoleConnectionErrorMessage  tests", () => {
    it("should return error message", () => {
        expect(getConsoleConnectionErrorMessage(mockErrObject)).toEqual("Cannot establish connection as there is another connection in progress")
    })
})

describe("getActiveSessionsForConnectionMode tests", () => {
    it("should return active sessions", () => {
        expect(getActiveSessionsForConnectionMode([sessions], EConnectionMode.CC)).toEqual(sessions)
    })
})

describe("checkIfIncognitoConsoleEnabled tests", () => {
    it("should return boolean", () => {
        expect(checkIfIncognitoConsoleEnabled({ CONSOLE_VIEW_INCOGNITO: true }, [{ id: 1, receiverName: "", monitorName: "", isSelected: false }])).toEqual(true)
    })
})
describe("checkIfReceiverInUse tests", () => {
    it("should return boolean", () => {
        expect(checkIfReceiverInUse([sessions], "receiverName")).toEqual(true)
    })
})
describe("checkIfEmeraldGoingOn tests", () => {
    it("should return boolean", () => {
        expect(checkIfEmeraldGoingOn([sessions])).toEqual(false)
    })
})
describe("checkIfAnyActiveTransaction tests", () => {
    it("should return boolean", () => {
        expect(checkIfAnyActiveTransaction([transactions])).toEqual(false)
    })
})
describe("fetchFirstWaitingTransactionIndex tests", () => {
    it("should return number", () => {
        expect(fetchFirstWaitingTransactionIndex([transactions, transactions])).toEqual(-1)
    })
})
describe("convertConsoleSessionToTransaction tests", () => {
    it("should return boolean", () => {
        expect(convertConsoleSessionToTransaction(sessions, "").connectionMode).toContain("COMMANDCENTER")
    })
})
describe("generateUniqueId tests", () => {
    it("should return boolean", () => {
        expect(generateUniqueId()).toHaveLength(9)
    })
})
describe("fetchActiveTransactionIndex tests", () => {
    it("should return transaction", () => {
        expect(fetchActiveTransactionIndex([transactions])).toBe(-1)
    })
})
describe("isDevice tests", () => {
    it("should return if is device", () => {
        expect(isDevice()).toBeFalsy()
    })
})
describe("isDev tests", () => {
    it("should return if environment is dev", () => {
        expect(isDev()).toBeTruthy()
    })
})

describe("isNonCommandCenterViewConnection tests", () => {
    it("should return if isNonCommandCenterViewConnection", () => {
        expect(isNonCommandCenterViewConnection(sessions, "4b095617-e3c0-491d-84fc-4a12b3eefccb")).toBeFalsy()
    })
})

describe("getNFCCMaxlimitMessage tests", () => {
    it("should return if getNFCCMaxlimitMessage", () => {
        expect(getNFCCMaxlimitMessage([sessions], rooms, rooms[0])).toBeDefined()
    })
})

describe("messageViewToEdit tests", () => {
    it("should return if messageViewToEdit", () => {
        expect(messageViewToEdit()).toBeDefined()
    })
})

describe("hasActiveVidoCallWithRoom tests", () => {
    it("should return if hasActiveVidoCallWithRoom", () => {
        expect(hasActiveVidoCallWithRoom("roomUuid")).toBeDefined()
    })
})

describe("fetchActiveSession tests", () => {
    it("should return if fetchActiveSession", () => {
        expect(fetchActiveSession([sessions], "roomUuid")).toBeDefined()
    })
})

describe("fetchViewConsoleSessionForRoom tests", () => {
    it("should return if fetchViewConsoleSessionForRoom", () => {
        expect(fetchViewConsoleSessionForRoom([sessions], "roomUuid")).toBeDefined()
    })
})

describe("updateSpokeQualifiedCheckboxStatus tests", () => {
    const roomDetails: any = {
        identity: { id: "id", uuid: "uuid" }
    }
    it("should able to update skope status", () => {
        const spy = jest.spyOn(consoleService, "spokeNotQualifiedService").mockReturnValue(Promise.resolve(true))
        updateSpokeQualifiedCheckboxStatus(roomDetails, true)
        expect(spy).toBeCalled()
    })
})

describe("checkCallStatus tests", () => {
    it("check for call failed", () => {
        const videoCallStatus = [{ callStatus: ECallStatus.FAILED, contextId: "" }]
        expect(checkCallStatus(videoCallStatus, "")).toBe(ETransactionStatus.FAILED)
    })

    it("check for call declined", () => {
        const videoCallStatus = [{ callStatus: ECallStatus.CALLDECLINED, contextId: "" }]
        expect(checkCallStatus(videoCallStatus, "roomUuid")).toBe(ETransactionStatus.STOP)
    })

    it("check for call connected", () => {
        const videoCallStatus = [{ callStatus: ECallStatus.CONNECTED, contextId: "roomUuid" }]
        expect(checkCallStatus(videoCallStatus, "roomUuid")).toBe(ETransactionStatus.FINISHED)
    })
})

describe("fetchActiveSessionToBeDisconnected tests", () => {
    const consoleSessions: any = [
        { roomUuid: "roomUuid", receiverName: "receiverName", connectionMode: EConnectionMode.CC, connectionType: EConnectionType.VIEW },
        { roomUuid: "roomUuid1", receiverName: "", connectionMode: EConnectionMode.EMERALD, connectionType: EConnectionType.VIEW }
    ]
    it("should be in active session with same room", () => {
        jest.spyOn(externalAppStates, "fetchGlobalConfigs").mockReturnValue({ MAX_NUM_OF_CONSOLE_SESSION: "2", MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE: "1", MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE: "1" })
        expect(fetchActiveSessionToBeDisconnected(consoleSessions, "", "roomUuid", EConnectionMode.EMERALD).isActiveSessionWithSameRoom).toBeTruthy()
    })
})

describe("isMaximumNFCCLimitReached tests", () => {
    const consoleSessions: any = [
        { roomUuid: "roomUuid", receiverName: "receiverName", connectionMode: EConnectionMode.CC, connectionType: EConnectionType.VIEW },
        { roomUuid: "roomUuid1", receiverName: "", connectionMode: EConnectionMode.EMERALD, connectionType: EConnectionType.VIEW }
    ]
    it("shoould return true", () => {
        jest.spyOn(externalAppStates, "fetchGlobalConfigs").mockReturnValue({ MAX_NUM_OF_CONSOLE_SESSION: "2", MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE: "1", MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE: "1" })
        expect(isMaximumNFCCLimitReached(consoleSessions)).toBeTruthy()
    })
})

describe("getPidFromContextMapping tests", () => {
    it("shoould return pid", () => {
        expect(getPidFromContextMapping("123")).toBeDefined()
    })
})

describe("fetchTransactionForRoomAndStatus tests", () => {
    it("shoould return transaction for room", () => {
        expect(fetchTransactionForRoomAndStatus([transactions], "roomUuid", ETransactionStatus.IDLE)).toBeDefined()
    })
})

describe("fetchTransactionForStatus tests", () => {
    it("shoould return transaction status", () => {
        expect(fetchTransactionForStatus([transactions], TransactionValue.CONNECTING, ETransactionStatus.IDLE)).toBeDefined()
    })
})

describe("fetchTransactionIndexForState tests", () => {
    it("shoould return transaction index", () => {
        expect(fetchTransactionIndexForState([], ETransactionStatus.IDLE)).toBe(-1)
    })
})

describe("getRoomConnection tests", () => {
    it("shoould return console session", () => {
        expect(getRoomConnection([sessions], "roomUuid")).toBe(sessions)
    })
})

describe("messageEditToView tests", () => {
    it("shoould return message", () => {
        expect(messageEditToView()).toStrictEqual([{ "content": "Edit session ends and switching back to view session", "header": "Switching back to view session" }])
    })
})

describe("getActiveSessionConsoleRoom tests", () => {
    it("shoould return console room", () => {
        const session: IConsoleSession = {
            contextId: "contextId",
            requester: "requester",
            roomUuid: rooms[0].identity.uuid,
            connectionType: EConnectionType.VIEW,
            connectionMode: EConnectionMode.CC,
            connectionStatus: EConnectionState.CONNECTED,
            receiverName: "receiverName",
            displayCameraToggle: true,
            mediaRoomDetails: {
                cameraStreamAvailable: ECameraStreamAvailable.IDLE,
                mediaRoomId: "",
                mediaRoomToken: ""
            },
            multiCameraList: [],
            consoleStartTime: "consoleStartTime",
        }
        expect(getActiveSessionConsoleRoom(rooms, session)).toBe(rooms[0])
    })
})

describe("checkIfParkedConsoleEnabled tests", () => {
    it("should return false", () => {
        expect(checkIfParkedConsoleEnabled(sessions)).toBeFalsy()
    })
})

describe("fetchActiveSessionForReceiver tests", () => {
    it("should return active session", () => {
        expect(fetchActiveSessionForReceiver([sessions], "receiverName")).toBe(sessions)
    })
})

describe("fetchConsoleSessionByRoomUuid tests", () => {
    it("should return consoleSession", () => {
        expect(fetchConsoleSessionByRoomUuid([sessions], "roomUuid")).toBe(sessions)
    })
})

describe("fetchTransactionIndex tests", () => {
    it("fetchTransactionIndexForStatus", () => {
        expect(fetchTransactionIndexForStatus([transactions], TransactionValue.CONNECTING, ETransactionStatus.IDLE)).toBe(0)
    })
    it("fetchTransactionIndexForState", () => {
        expect(fetchTransactionIndexForState([transactions], ETransactionStatus.IDLE)).toBe(0)
    })
})

describe("construct app uri tests", () => {
    it("constrct app uri configs for PID", () => {
        const configs = `?config={"appName":"${EMERALD_APP_NAME}","appArguments":["${CONSOLE_TRANSACTION}","PUT","",""]}`
        expect(constructAppUriConfigsforPID("", "", EMERALD_APP_URI_START, 0, "", "")).toEqual(configs)
        expect(constructAppUriConfigsforPID("", "", EMERALD_APP_URI_RESTART, 0, "", "")).toEqual(`${configs}&PID=0`)
        expect(constructAppUriConfigsforPID("", "", "", 0, "", "")).toBe(undefined)
        expect(constructAppUriConfigsforPID("", "", EMERALD_APP_URI_STOP, 0, "", "")).toBe(`?PID=0`)
        expect(constructAppUriConfigsforPID("", "", EMERALD_APP_URI_STOP_ALL, 0, "", "")).toBe(`?config={"appName":"${EMERALD_APP_NAME}"}`)
    })
})

describe("getSpokeMessage tests", () => {
    it("should return consoleSession", () => {
        expect(getSpokeMessage({ "rocc-emerald-edit": true }, ECommandCenterAccessMode.WITH_HARDWARE)).toBeTruthy()
    })
})
describe("getActionFromWorkflowType tests", () => {
    expect(getActionFromWorkflowType(ERoccWorkflow.MULTI_EDIT_INITIATE_CALL)).toEqual(EMultiSessionModalNextAction.INITIATE_CALL)
    expect(getActionFromWorkflowType(ERoccWorkflow.PARK_AND_INITIATE_CALL)).toEqual(EMultiSessionModalNextAction.INITIATE_CALL)
    expect(getActionFromWorkflowType(ERoccWorkflow.MULTI_EDIT_START_EDITING)).toEqual(EMultiSessionModalNextAction.INITIATE_SESSION)
    expect(getActionFromWorkflowType(ERoccWorkflow.PARK_AND_START_EDITING)).toEqual(EMultiSessionModalNextAction.INITIATE_SESSION)
    expect(getActionFromWorkflowType(ERoccWorkflow.DISCONNECT_CALL)).toEqual(EMultiSessionModalNextAction.DISCONNECT_CALL)
    expect(getActionFromWorkflowType(ERoccWorkflow.PARK_AND_RESUME)).toEqual(EMultiSessionModalNextAction.RESUME_SESSION)
    expect(getActionFromWorkflowType(ERoccWorkflow.DISCONNECT_CONSOLE_SESSION)).toEqual(EMultiSessionModalNextAction.DISCONNECT_SESSION)
    expect(getActionFromWorkflowType(ERoccWorkflow.LOGOUT)).toEqual(EMultiSessionModalNextAction.INITIATE_SESSION)
})

describe("getCurrentRoom tests", () => {
    const roomInfo: IRoomInfo = {
        roomUuid: "id",
        roomName: "name",
        address: "address",
        locationId: 1,
        phoneNumber: "1",
        loggedInTech: {
            techUuid: "12",
            techName: "tech name"
        }
    }
    it("should return currentRoom", () => {
        expect(getCurrentRoom("id", [roomInfo])).toBe(roomInfo)
    })
})
