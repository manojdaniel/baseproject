/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React from "react"
import { Button, Header, Item } from "semantic-ui-react"
import getStartedHeaderTitleImg from "../../../assets/images/CompleteBg.png"
import en from "../../../resources/translations/en-US"
import styles from "./GetStartedPage.scss"

interface IGetStartedPage {
    currentUser: IUserInfo
    getFinish: () => void
}

const GetStartedPage = (props: IGetStartedPage) => {
    const { currentUser, getFinish } = props
    const { intl } = getIntlProvider()

    return (
        <div className={styles.getStartedPage} id="getStartedPage">
            <Header textAlign={"center"}>
                <img
                    src={getStartedHeaderTitleImg}
                    alt="Get Started"
                    className={"getStartedHeaderTitleImg"}
                />
                <Item className={styles.confirmationMessage}>
                    <Item.Header className={styles.getStartedHeaderTitle}>
                        {intl.formatMessage({ id: "content.onboarding.allsetText", defaultMessage: en["content.onboarding.allsetText"] })}
                        <span className={"getStartedHeaderUserName"}>{currentUser.name}!</span></Item.Header>
                    <Item.Content className={styles.getStartedcontent}>
                        <Button
                            primary={true}
                            className={"finishBtn"}
                            onClick={getFinish}
                        >
                            {intl.formatMessage({ id: "content.finish.btn", defaultMessage: en["content.finish.btn"] })}
                        </Button>
                    </Item.Content>
                </Item>
            </Header>
        </div>
    )
}

export default GetStartedPage
