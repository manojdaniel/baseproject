#!/bin/bash -ex
cd ${WORKSPACE}/$repo_name/cicd
export CF_DOCKER_PASSWORD=$CF_USERNAME_PSW
cf login -a $CF_API -u $CF_USERNAME_USR  -p $CF_USERNAME_PSW -o $CF_ORG -s $cf_space
echo "---Deploying $app_name app ---"
if [ "$deployment_type" = "non-prod" ]; then
    var_type="clienttest"
elif [ "$deployment_type" = "prod" ]; then
    var_type="prod"
fi
cp "${WORKSPACE}/rocc-ops-configs/vars/vars_${var_type}_${region}.yml" "vars.yaml"
sed -i "s/target_env:*/target_env: $target_env/g" vars.yaml
if [[ ! "$buildVersion" == *"-tc"* ]]; then
    echo "Release build"
    docker_repo=$DOCKER_REPO_RELEASED
else
    echo "Test build"
    docker_repo=$DOCKER_REPO_DEV
fi
cf push  $app_name-$target_env --docker-image "${docker_repo}/${app_name}:${buildVersion}" -f manifest_cf.yaml --vars-file vars.yaml --docker-username $CF_USERNAME_USR --no-start
cf start $app_name-$target_env
cf restage $app_name-$target_env