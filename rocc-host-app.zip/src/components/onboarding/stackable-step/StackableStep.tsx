/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import Stepper from "react-stepper-horizontal"
import { Grid, Step } from "semantic-ui-react"
import styles from "./StackableStep.scss"

interface IFormSteps {
    steps: IFormStep[]
    activePage: number
    onClick: (key: number) => void
}

interface IFormStep {
    key: number
    title: string
    onClick?: (key: number) => void
}
const StackableStep = (props: IFormSteps) => {
    const { steps, onClick, activePage } = props
    const linkColor = "#1474a4"
    const renderSteps = steps.map((step: IFormStep) => {
        step.onClick = () => onClick(step.key)
        return step
    })
    return (
        <Grid.Column textAlign="center">
            <Step.Group className={styles.steps} id={"OnBoardingStep"}>
                <Stepper
                    steps={renderSteps}
                    activeStep={activePage}
                    activeColor={linkColor}
                    completeColor={linkColor}
                />
            </Step.Group>
        </Grid.Column>
    )
}

export default StackableStep
