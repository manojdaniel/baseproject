/*
 * Created on Wed Oct 21 2020
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { Header } from "semantic-ui-react"

const UnauthorizedComponent = () => {
    return (
        <div
            id={"UnauthorizedComponent"}
            style={{
                position: "absolute",
                top: "20%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                textAlign: "center"
            }}
        >
            <Header>
                {"Welcome to Philips ROCC Service tool. Please contact administrator to configure the ROCC-Service Tool app before you can use it."}
            </Header>
        </div >
    )
}

export default UnauthorizedComponent
