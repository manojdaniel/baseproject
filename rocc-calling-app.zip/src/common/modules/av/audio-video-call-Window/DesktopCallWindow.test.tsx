/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import { ECallOptions } from "../types"
import DesktopCallWindow from "./DesktopCallWindow"
import * as DesktopCallWindowCustomHook from "./DesktopCallWindowCustomHook"

jest.mock("../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("./DesktopCallWindowCustomHook")

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: { name: "test" },
        connectedCallDetails: {
            participants: [{
                callStatus: ECallStatus.CONNECTED
            }],
        },
        desktopCallWindowFullScreen: false,
        activeConsoleSessions: [{
            roomUuid: 13456,
            connectionType: "VIEW",
        }],
        permissions: {
            CALL_DESKTOP_FULL_SCREEN: true,
            CALL_VIDEO_CALL: true,
        },
        urls: {},
        consoleMultiCamera: false,
    }),
    connect: (stateToProps: any, dispatchToProps: any) => (connectComponent: any) => ({
        stateToProps,
        dispatchToProps,
        connectComponent,
    }),
    useDispatch: () => void (0),
}))

describe("DesktopCallWindow component", () => {
    let wrapper: any
    let props: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    const mockedActiveOptionCustomHook: any = DesktopCallWindowCustomHook as jest.Mocked<typeof DesktopCallWindowCustomHook>

    beforeEach(() => {
        props = {
            localMediaRef: null,
            remoteMediaRef: null,
            videoStatus: true,
            remoteUserVideoStatus: true,
            remoteAudioTrackStatus: true,
            dominantSpeaker: {
                name: "Test Name",
            },
            signalStrength: -1,
            callDuration: null,
            activeCall: {
                participants: [{
                    callStatus: ECallStatus.CONNECTED
                }],
                numOfParticipants: 1
            }
        }
        mockedActiveOptionCustomHook.useActiveCallOption.mockImplementation(() => {
            return {
                selectedOption: ECallOptions.SETTINGS,
                changeActiveCallOption: (callOption: ECallOptions) => { "" }, // eslint-disable-line @typescript-eslint/no-unused-vars
            }
        })
        wrapper = shallow(<DesktopCallWindow {...props} />)
    })

    it("should render with the correct id", () => {
        const renderCallWindowHeader = wrapper.find("CallWindowHeader")
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        mockUseEffect()
        expect(renderCallWindowHeader).toHaveLength(1)
    })

    it("should render RenderLocalMedia component with props localMediaRef, videoStatus, dominantSpeaker, isDevice, cssStyleClass", () => {
        const renderCallWindowHeader = wrapper.find("CallWindowHeader")

        expect(renderCallWindowHeader).toHaveLength(1)
        expect(renderCallWindowHeader.prop("callWindowFullscreen")).toBeDefined()
        expect(renderCallWindowHeader.prop("participantsList")).toBeTruthy()
    })
    it("should render RenderRemoteMedia component with props remoteMediaRef, remoteUserVideoStatus, dominantSpeaker, isDevice, callDuration, signalStrength, cssStyleClass", () => {
        const renderRemoteMediaComponent = wrapper.find("RenderRemoteMedia")

        expect(renderRemoteMediaComponent).toHaveLength(1)
        expect(renderRemoteMediaComponent.prop("remoteMediaRef")).toBeDefined()
        expect(renderRemoteMediaComponent.prop("remoteUserVideoStatus")).toBeTruthy()
        expect(renderRemoteMediaComponent.prop("dominantSpeaker")).toBeDefined()
        expect(renderRemoteMediaComponent.prop("callDuration")).toBeDefined()
        expect(renderRemoteMediaComponent.prop("signalStrength")).toBe(-1)
    })
    it("should render remote media with CallerDetails component with props dominantSpeaker, remoteAudioTrackStatus, callDuration, cssStyleClass", () => {
        const callerDetailsComponent = wrapper.find("#remoteMediaCallDetails").find("CallerDetails")

        expect(callerDetailsComponent).toHaveLength(1)
        expect(callerDetailsComponent.prop("dominantSpeaker")).toBeDefined()
        expect(callerDetailsComponent.prop("remoteAudioTrackStatus")).toBeTruthy()
    })
    it("should render remote media footer with CallControls component with props", () => {
        const callControlsComponent = wrapper.find("#remoteMediaCallFooter").find("CallControls")

        expect(callControlsComponent).toHaveLength(1)
        expect(callControlsComponent.prop("selectedOption")).toBeDefined()
        expect(callControlsComponent.prop("setSelectedOption")).toBeDefined()
        expect(callControlsComponent.prop("isDesktopFullScreen")).toBeDefined()
        expect(callControlsComponent.prop("videoStatus")).toBeDefined()
        expect(callControlsComponent.prop("volumeStatus")).toBeFalsy()
    })
})
