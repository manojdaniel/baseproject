/*
 * Created on Wed Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import configureMockStore from "redux-mock-store"
import thunk from "redux-thunk"
import { UPDATE_PRESIGNED_URLS, UPDATE_URLS } from "./types"
import { setConfigs, setUrls, updateLocale, updatePresignedUrls } from "./configActions"
import { IUrls } from "@rocc/rocc-client-services"
import { IPresignedUrls } from "@rocc/rocc-client-services"
import { INIT_CONFIGS } from "../reducers/configReducer"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

describe("should test config actions", () => {
    const store = mockStore({
        externalReducer: {
            currentUser: {},
        }
    })

    beforeEach(() => {
        store.clearActions()
    })

    it("setUrls is defined", () => {
        const urls: IUrls = {
            GRAPHQL_API_HSDP_URI: "",
            GRAPHQL_API_HSDP_WS_URI: "",
            COMMUNICATION_SERVICES_URL: "",
            IAM_SERVICES_URL: "",
            RBAC_SERVICE_URL: "",
            CONSOLE_SERVICES_URL: "",
            PROXY_URL: "",
            MANAGEMENT_SERVICE_URL: "",
        }
        store.dispatch(setUrls(urls) as any)
        expect(String(store.getActions()[0].type)).toBe(UPDATE_URLS)
        store.clearActions()
    })
    it("presigned urls is defined", () => {
        const preSignedUrls: IPresignedUrls = {
            adminUserManual: { url: "", createdAt: new Date() }, expertUserManual: { url: "", createdAt: new Date() }
        }
        store.dispatch(updatePresignedUrls(preSignedUrls) as any)
        expect(String(store.getActions()[0].type)).toBe(UPDATE_PRESIGNED_URLS)
        store.clearActions()
    })
    it("set configs is defined", () => {
        store.dispatch(setConfigs(INIT_CONFIGS) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
    it("update locale is defined", () => {
        store.dispatch(updateLocale({
            theme: "",
            locales: [],
            language: "",
            preferredLocale: ""
        }) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })
})
