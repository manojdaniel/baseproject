/*
 * Created on Sun Oct 16 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionType } from "@rocc/rocc-client-services"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import { IPerformConsoleConnectionOps } from "../../redux/interfaces/types"
import { checkIfUserHasCompatibleNFCCBundle, connectToConsole } from "./consoleHelpers"
import * as consoleUtility from "./consoleUtility"
import { GLOBAL_UPDATE_ROOMS } from "../constants/constants"

const mockDispatch = jest.fn()
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

const mockData = {
    notificationModal: {
        showModal: false,
        showCloseIcon: false,
        header: "",
        modalContent: "",
    }
}
const store = mockStore(mockData)

jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalNfccUpgradeStatus: jest.fn().mockReturnValueOnce(false).mockReturnValue(true),
    fetchGlobalNfccBundleInfo: jest.fn().mockReturnValueOnce({ mandatory: false }).mockReturnValueOnce({ mandatory: true }),
    fetchGlobalCurrentUser: jest.fn().mockReturnValue({
        currentUser: {
            uuid: "",
            accessToken: "",
            orgId: "1"
        }
    }),
    fetchGlobalConfigs: jest.fn().mockReturnValueOnce({ ROCC_DEV: "false" }),
    fetchRooms: jest.fn().mockReturnValue([{ identity: { uuid: "roomUuid" }, isConnecting: true }]),
    dispatchToParentStore: jest.fn().mockImplementation((action) => store.dispatch(action))
}))

jest.mock("../../redux/actions/consoleActions", () => ({
    resetConsoleSession: jest.fn(),
    updateConsoleSession: jest.fn(),
    setConsoleOperations: jest.fn(),
}))

jest.mock("../../services/consoleService", () => ({
    initiateCCConsoleService: jest.fn().mockResolvedValueOnce("contextId"),
}))

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        consoleReducer: {
            commandCenterDetails: {
                commandCenterSeat: {
                    receivers: [{ id: "id" }],
                    seatName: "seatName"
                },
            },
            consoleSessions: []
        }
    })
}))

describe("console helper tests", () => {
    const props: IPerformConsoleConnectionOps = {
        connectionMode: EConnectionMode.CC,
        consoleSessions: [],
        connectionType: EConnectionType.VIEW,
        roomUuid: "",
        receivers: [],
        dispatch: undefined,
        setReceiverSelectionModal: function (): void {
            throw new Error("Function not implemented.")
        },
        componentName: "",
        featureFlags: undefined
    }
    const handleNFCCConnectionSpy = jest.spyOn(consoleUtility, "handleNFCCConnection")
    beforeEach(() => {
        store.clearActions()
    })
    it("check if user has campatible nfcc bundle tests", () => {
        checkIfUserHasCompatibleNFCCBundle(props)
        expect(handleNFCCConnectionSpy).toBeCalled()
    })
    it("should show optional upgrade popup", () => {
        checkIfUserHasCompatibleNFCCBundle(props)
        expect(store.getActions()[0].payload.notificationModal.actionButton2Text).toBe("Continue")
    })
    it("should show mandatory upgrade popup", () => {
        checkIfUserHasCompatibleNFCCBundle(props)
        expect(store.getActions()[0].payload.notificationModal.actionButton2Text).toBe("Cancel")
    })
    it("console connect tests", () => {
        connectToConsole("roomUuid", EConnectionType.VIEW, mockDispatch)
        expect(store.getActions()[0].type).toBe(GLOBAL_UPDATE_ROOMS)
    })
})
