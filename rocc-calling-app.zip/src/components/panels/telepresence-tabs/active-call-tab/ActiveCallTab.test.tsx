/*
 * Created on Wed Sep 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import ActiveCallTab from "./ActiveCallTab"
import { shallow } from "enzyme"
import { ESidePanelTabs } from "../../../../types/types"
import thunk from "redux-thunk"
import configureMockStore from "redux-mock-store"
import * as Redux from "react-redux"
import { ECallStatus } from "@rocc/rocc-client-services"
import { withHooks } from "jest-react-hooks-shallow"

jest.mock("../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("react-redux", () => ({
    useSelector: jest.fn(),
    useDispatch: jest.fn(),
}))
jest.mock("../../../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    }),
    dispatchToParentStore: jest.fn(),
}))

jest.mock("../../../../common/helpers/helpers", () => ({
    getAppReducerFromGlobalStore: () => ({
        focusedCallAndConsole: { callContextId: "", consoleContextId: "" }
    }),
    getActiveStyles: () => ({

    })

}))

let store: any
let wrapper: any
const useSelectorSpy: jest.SpyInstance = jest.spyOn(Redux, "useSelector")
const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)
const mockAppState: any = {
    callReducer: {
        phoneCallStatus: ECallStatus.IDLE,
        videoCallStatus: [{ callStatus: ECallStatus.CALLING, contextId: "123" }],
        callDetails: {
            connectedCallDetails: {
                twilioToken: "token",
                contextId: "123",
                participants: [{
                    primaryUuid: "primaryUuid",
                }],
                callAcceptedTime: Date.now(),
            },
            onHoldCallDetails: [],
            incomingCall: {
                contextId: "incomingContextId",
                participant: {
                    uuid: "uuid",
                }
            },
            outgoingCall: {
                contextId: "123"
            },
        },
        callMessage: {},
    },
}
const useSelectorMock = (mockedAppState: any) => {
    store = mockStore(mockedAppState)
    useSelectorSpy.mockImplementation(cb => {
        return cb(store.getState())
    })
}
const getShallowWrapper = () => { return shallow(<ActiveCallTab activeItem={ESidePanelTabs.Active} />) }

describe("ActiveCallTab Component in idle state", () => {
    beforeEach(() => {
        useSelectorMock(mockAppState)
    })
    it("should render ActiveCallTab component", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("#activeCallTab")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("ActiveCallTab Component in calling state", () => {
    beforeEach(() => {
        mockAppState.callReducer.phoneCallStatus = ECallStatus.CONNECTED
        useSelectorMock(mockAppState)
    })
    it("should render WebToPhoneCall component", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("WebToPhoneCall")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})

describe("ActiveCallTab Component in ConnectingCall state", () => {
    beforeEach(() => {
        mockAppState.callReducer.phoneCallStatus = ECallStatus.IDLE
        mockAppState.callReducer.videoCallStatus = [{ callStatus: ECallStatus.CONNECTING, contextId: "123" }]
        useSelectorMock(mockAppState)
    })
    it("should render ConnectingCall  component", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("ConnectingCall")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
describe("ActiveCallTab Component in Connected state", () => {
    beforeEach(() => {
        mockAppState.callReducer.videoCallStatus = [{ callStatus: ECallStatus.CONNECTED, contextId: "123" }]
        mockAppState.callReducer.callDetails.connectedCallDetails.twilioToken = "twillio_token"
        useSelectorMock(mockAppState)
    })
    it("should render Connected  component", () => {
        withHooks(() => {
            wrapper = getShallowWrapper()
            expect(wrapper.find("AudioVideoCalling")).toHaveLength(1)
        })
    })
    afterEach(() => {
        useSelectorSpy.mockClear()
    })
})
