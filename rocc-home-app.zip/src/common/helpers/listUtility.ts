/*
 * Created on Mon Oct 17 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, EUserPresence, getLocationDetailsForId, IContactInfo, IUserInfo, parseIntBase10 } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { DEVICE } from "../../constants/constants"
import { fetchGlobalLocations } from "../../redux/store/externalAppStates"
import en from "../../resources/translations/en-US"
import { getRoleName, renderHTMLCd } from "./stringUtility"

const { TECHNOLOGIST } = EClinicalRole

export const convertContactToDisplayList = (contact: IContactInfo, getUserAction: (props?: any) => JSX.Element[]) => {
    const { id, status, secondaryUUID, uuid, name, description, siteId, clinicalRole, secondaryName, loggedInLocation } = contact
    const { intl } = getIntlProvider()
    const guest = intl.formatMessage({ id: "content.room.guest", defaultMessage: en["content.room.guest"] })
    const isGuest = (clinicalRole === DEVICE && secondaryUUID === "")
    return {
        id: id,
        uuid: secondaryUUID || uuid,
        title: isGuest ? guest : (secondaryName !== "" ? secondaryName : name),
        metaData: secondaryUUID !== "" ? getRoleName(TECHNOLOGIST) : getRoleName(clinicalRole),
        description: clinicalRole === DEVICE ? `${name} ${renderHTMLCd('&#8226;')} ` + getSiteName(description, siteId) : (loggedInLocation || ""),
        presence: status,
        userActions: getUserAction(),
    }
}

export const getSiteName = (description: string, siteId: string[]) => {
    let siteName = description
    if (siteName === "") {
        const locationList = fetchGlobalLocations()
        for (const site of siteId) {
            const name = getLocationDetailsForId(locationList, parseIntBase10(site)).name
            if (name) {
                siteName = name
                break
            }
        }
    }
    return siteName
}

export const sortContacts = (contacts: IContactInfo[]) => {
    const { AVAILABLE, BUSY, IN_CALL, DND, OFFWORK, AWAY, OFFLINE } = EUserPresence
    const order = [
        AVAILABLE, BUSY, IN_CALL,
        DND, OFFWORK, AWAY, OFFLINE,
    ]
    contacts.sort((a: IContactInfo, b: IContactInfo) => a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1)
    return contacts.sort((a: IContactInfo, b: IContactInfo) =>
        order.indexOf(a.status) > order.indexOf(b.status) ? 1 :
            order.indexOf(a.status) === order.indexOf(b.status) ? 1 : -1)
}

export const isExpert = (currentUser: IUserInfo) => {
    return currentUser.allRoles.includes(EClinicalRole.EXPERTUSER)
}
