# ROCC - Console Application

![master](https://github.com/philips-internal/rocc-console-app/actions/workflows/master.yml/badge.svg)
![tag](https://github.com/philips-internal/rocc-console-app/actions/workflows/tag.yml/badge.svg)
![pr-apps-deletion](https://github.com/philips-internal/rocc-console-app/actions/workflows/pr-apps-deletion.yml/badge.svg)
![blackduck](https://github.com/philips-internal/rocc-console-app/actions/workflows/blackduck.yml/badge.svg)
<a href=https://codescene.ta.philips.com/1610/analyses/latest/dashboard> <img src="https://codescene.com/status/analyzed-by-codescene-badge.svg" width="130"></a>

This MFE is the container for a console application in ROCC. This application enables the user to initiate a remote console connection.

This repo comes with the following features
 - Linting Per ROCC
 - Unit tests
 - Husky
 - MS Application Insights
 - PDV Toolkit
 - Cloud/PR Scripts 
 - Webpack Module Federation https://webpack.js.org/concepts/module-federation/ 


# Setting up in local
 ## Pre-requisites
  - node (v14.17.3)
  - npm (6.14.13)
  - nginx (latest)
  - A Host application like rocc-cc-host
  
 ## Cloning
 - Create a Personal Access Token (PAT) - https://github.com/settings/tokens  (one time activity)
 - Use the following command to clone the repo
   - `git clone --recursive https://<<PAT>>:x-oauth-basic@github.com/philips-internal/rocc-self-service-home-app.git`

 ## Update npm config

 - `npm config set @vip:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @dls-pdv:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`
 - `npm config set @rocc:registry=https://artifactory-ehv.ta.philips.com/artifactory/api/npm/pdv-npm-release-local/`

 ## Install

 - `npm install`

 ## Running

 - `npm start`. This will build and serve the app on port 8080.
  
 - Alternatively,
    - `npm build`
    - `npm serve`

 ## Nginx Config

 - download and install Nginx in your local (http://nginx.org/en/download.html)
 - Sample config 
        
        server {
            listen       9090;
            server_name  localhost;

            location ~^/app/console(.*) {
                gzip_static on;
                proxy_pass "http://host.docker.internal:7774/$1";
                proxy_http_version 1.1;            
            }

            location / {
                gzip_static on;
                proxy_pass "http://localhost:3001";
                proxy_http_version 1.1;
            }
        }

    -   Note: Running all child MFEs in local is not required. Child MFEs can be referred with the dev URLs
  

### Run the application in the browser http://localhost:9090
