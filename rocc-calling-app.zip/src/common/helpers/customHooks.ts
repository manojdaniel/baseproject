/*
 * Created on Tue Apr 11 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { IStore } from "../../redux/interfaces/types"
import { checkIfCallGoingOn, checkIfSeamlessEditFeatureExist, getCallsWithParticipant } from "./helpers"

export const useCallOptionStatus = (contactUuid: string) => {
    const [callStatusDisabled, setCallStatusDisabled] = useState({ isPhoneCallDisabled: false, isWebCallDisabled: false })

    const { phoneCallStatus, featureFlags, videoCallStatus, connectedCallDetails, onHoldCallDetails, outgoingCall, incomingCall } = useSelector((state: IStore) => ({
        phoneCallStatus: state.callReducer.phoneCallStatus,
        featureFlags: state.externalReducer.featureFlags,
        videoCallStatus: state.callReducer.videoCallStatus,
        connectedCallDetails: state.callReducer.callDetails.connectedCallDetails,
        onHoldCallDetails: state.callReducer.callDetails.onHoldCallDetails,
        outgoingCall: state.callReducer.callDetails.outgoingCall,
        incomingCall: state.callReducer.callDetails.incomingCall,
    }))

    useEffect(() => {
        let phoneCallDisabled = false
        let webCallDisabled = false

        if (checkIfCallGoingOn(videoCallStatus, phoneCallStatus) || outgoingCall.contextId || incomingCall.contextId) {
            phoneCallDisabled = true
            webCallDisabled = true
        }

        if (checkIfSeamlessEditFeatureExist()) {
            if (getCallsWithParticipant(contactUuid, [...onHoldCallDetails, connectedCallDetails])) {
                phoneCallDisabled = true
                webCallDisabled = true
            } else if (connectedCallDetails.contextId) {
                webCallDisabled = false
                phoneCallDisabled = true
            } else {
                webCallDisabled = false
                phoneCallDisabled = false
            }
        }

        setCallStatusDisabled({ isPhoneCallDisabled: phoneCallDisabled, isWebCallDisabled: webCallDisabled })
    }, [featureFlags, videoCallStatus, connectedCallDetails, phoneCallStatus, onHoldCallDetails, outgoingCall, incomingCall])

    return callStatusDisabled

}
