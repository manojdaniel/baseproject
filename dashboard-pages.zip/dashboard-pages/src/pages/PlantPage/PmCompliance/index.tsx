import React, { useRef, useEffect, useState } from "react";
//import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
//import AlertStatusList from "table/Pmcompliance";
import Pmcompliance from "table/Pmcompliance";
//import Loader from "components/Loader";
import { getpmcompliance } from "../../../redux/reducers/CommonReducer";
import { encryptRSAData } from "../../../utility/rsa";

interface Props {
	buttonName: string;
	onClickHandler: any;
}

const PmCompliance = () => {

	let dispatch = useDispatch();

	const { pmcompliance, globalSelecetedPlant,
		loadingpmcompliance } = useSelector((state: any) => ({
			pmcompliance: state.Common.pmcompliance,
			globalSelecetedPlant: state.Common.globalSelecetedPlant,

			loadingpmcompliance: state.Common.loadingpmcompliance,
		}));

	useEffect(() => {
		if (Object.keys(globalSelecetedPlant).length > 0) {
			dispatch(
				getpmcompliance(encryptRSAData(`plantId=${globalSelecetedPlant.value}`))
			);
		}
	}, []);

	return (
		<>
			<Pmcompliance
				data={pmcompliance}
				loading={loadingpmcompliance}
			/>
		</>
	);
};
export default PmCompliance;
