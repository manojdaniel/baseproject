/*
 * Created on Mon Dec 13 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { GLOBAL_CLEAR_DESTINATIONS, GLOBAL_SET_DESTINATION_SCANNER, GLOBAL_SET_INITIATION_ROUTE, GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, GLOBAL_SET_PROTOCOL_TRANSFER_STEP, GLOBAL_SET_SOURCE_SCANNER, UPDATE_DESTINATION_SCANNERS } from "../actions/types"
import protocolTransferReducer, { initialStatesForProtocolTransfer } from "./protocolTransferReducer"

describe("Protocol transfer Reducer", () => {
    it("should handle protocol transfer reducer empty action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_PROTOCOL_TRANSFER_STATUS action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_PROTOCOL_TRANSFER_STATUS, payload: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_PROTOCOL_TRANSFER_EXIT action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_PROTOCOL_TRANSFER_EXIT, payload: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_SOURCE_SCANNER action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_SOURCE_SCANNER, payload: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_DESTINATION_SCANNER action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_DESTINATION_SCANNER, payload: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_PROTOCOL_TRANSFER_STEP action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_PROTOCOL_TRANSFER_STEP, payload: "" })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_CLEAR_DESTINATIONS action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_CLEAR_DESTINATIONS })
        expect(value).toBeDefined()
    })

    it("should handle protocol transfer reducer GLOBAL_SET_INITIATION_ROUTE action", () => {
        const value = protocolTransferReducer({ initialStatesForProtocolTransfer }, { type: GLOBAL_SET_INITIATION_ROUTE, payload: "" })
        expect(value).toBeDefined()
    })
    
    it("should handle protocol transfer reducer UPDATE_DESTINATION_SCANNERS action", () => {
        const value = protocolTransferReducer(initialStatesForProtocolTransfer , { type: UPDATE_DESTINATION_SCANNERS, payload: "" })
        expect(value).toBeDefined()
    })
})
