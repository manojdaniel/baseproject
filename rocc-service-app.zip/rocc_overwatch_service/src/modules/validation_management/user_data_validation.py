"""
 Created on Sun Nov 1 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import EMP_DICT
from src.constants.enums import ESummaryStates
from src.loggers.log import create_logger
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import update_summary_for_entity
from src.modules.db_operations.validation_service.user_data_validation_service import verify_if_user_exists
from src.wrappers.graphql.connection.connection import get_client_connection

LOG = create_logger("UserDataValidation")


class UserDataValidation():

    def __init__(self, service_token, org_infra_uuid):
        LOG.info("Validating User data")
        self._org_infra_uuid = org_infra_uuid
        self._client = get_client_connection(service_token, org_infra_uuid=self._org_infra_uuid)
        self._transaction_data = None
        self._emp_dict = None

    def check_if_user_exists(self, emp_dict):
        new_users = self._transaction_data["summary"]["users"]["new"]
        for email_id, user_detail in emp_dict.items():
            if email_id in new_users:
                response = verify_if_user_exists(self._client, user_detail=user_detail)
                if not response:
                    self._transaction_data = update_summary_for_entity(self._transaction_data, "users", email_id, ESummaryStates.VALIDATION_FAILED)
                    # TODO: Need to capture in Audit. LOG.info(f"User:  {email_id} is not present in database")
                    LOG.info("User is not present in database")
                    user_detail["isPresent"] = False
                else:
                    # TODO: Need to capture in Audit.  LOG.info(f"User:  {email_id} is present in database")
                    LOG.info("User is present in database")
                    user_detail["isPresent"] = True
            else:
                # TODO: Need to capture in Audit.  LOG.info(f"This user {email_id} is not a new user, skipping validation ..!")
                LOG.info("This user is not a new user, skipping validation ..!")
        return emp_dict, self._transaction_data

    def initiate_data_validation(self, data_dict, transaction_data):
        self._emp_dict = data_dict[EMP_DICT]
        self._transaction_data = transaction_data
        self._emp_dict, self._transaction_data = self.check_if_user_exists(emp_dict=self._emp_dict)
        LOG.info("Users data validation complete ..!!")
        return data_dict, self._transaction_data
