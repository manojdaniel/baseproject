import React from "react"
import { Table, Header } from "semantic-ui-react"
import { ITableHead } from "../types"
import "./TableHead.scss"

const PDVTableHead: React.FC<ITableHead> = ({ title, actions }) => {
    return (
        <Table id="TableHead" selectable={true} sortable={true} singleLine={true}>
            <Table.Header className="title">
                <Table.Row>
                    <Table.HeaderCell>
                        <Header as="h3" className="dls-font-bold">
                            <Header.Content>
                                {title}
                            </Header.Content>
                        </Header>
                    </Table.HeaderCell>
                    <Table.HeaderCell className={"tableHeadRowButtons"}>
                        {actions}
                    </Table.HeaderCell>
                </Table.Row>
            </Table.Header>
        </Table>
    )
}

export default PDVTableHead
