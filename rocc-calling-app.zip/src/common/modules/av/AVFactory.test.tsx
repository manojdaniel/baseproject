import { PARENT_STORE } from "../../../constants/constants"
import { AVFactory } from "./AVFactory"
import { EAvCallType } from "@rocc/rocc-common-communication-sdk"
import { DEFAULT_CONTACT_INFO, IUserInfo } from "@rocc/rocc-client-services"
import { getVendorServiceName } from "../avmessages/messageService"
jest.mock("redux-micro-frontend", () => {
  const actualMock = jest.requireActual("redux-micro-frontend")
  return {
    ...actualMock,
    GlobalStore: {
      Get: jest.fn().mockReturnValue({
        GetGlobalState: jest.fn().mockReturnValue({
          [PARENT_STORE]: {
            configReducer: { urls: { COMMUNICATION_SERVICES_URL: "https://platinum-rocc-gcs.cloud.pcftest.com/philips/rocc" } }
          }
        }),
        CreateStore: jest.fn().mockReturnValue({}),
      })
    }
  }
})


jest.mock("../avmessages/messageService", () => ({
  getVendorServiceName: jest.fn().mockReturnValue(Promise.resolve({
    status: 200, data: { vendorName: "Twilio" }
  }))
})
)
const currentUser: IUserInfo = {
  ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", onBoarded: true, sessionId: "sessionId", locale: "en-US",
  accessTokenExpiryTime: ""
}
const dispatch = jest.fn()

describe("Load vendorServices from AVFactory", () => {
  it("return twilio vendor name  ", async () => {
    const spy = jest.spyOn(AVFactory, 'getCommunicationVendorName')
    await AVFactory.getCommunicationVendorName(currentUser, "https://communicationUrl", dispatch)
    expect(spy).toHaveBeenCalled()
    return AVFactory.getCommunicationVendorName(currentUser, "https://communicationUrl", dispatch).then(() => {
      return getVendorServiceName(currentUser, "https://communicationUrl").then((response) => {
        expect(response.status).toBe(200)
      })
    })

  })

  it("return twilio vendor service ", async () => {
    const type = EAvCallType.TWILIO
    const spy = jest.spyOn(AVFactory, 'getVendorService')
    AVFactory.getVendorService(type)
    expect(spy).toHaveBeenCalled()

  })

  it("return av vendor", async () => {
    const type = EAvCallType.TWILIO
    const spy = jest.spyOn(AVFactory, 'getAvVendor')
    AVFactory.getAvVendor(type, currentUser, dispatch)
    expect(spy).toHaveBeenCalled()

  })

})
