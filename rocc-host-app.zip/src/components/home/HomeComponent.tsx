/*
 * Created on Thu Nov 04 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EConnectionMode, EConnectionState, EConnectionType, EFetchStatus, EModalityType, ESessionContentType, getRoomDetailFromUuid, IConsoleSession, IParentStore, ROCC_FEATURES, TransactionValue } from "@rocc/rocc-client-services"
import { AwaitingBannerComponent, EditingBannerComponent, IncognitoBannerMessage, ProtocolManagementBannerComponent, ParkBannerComponent, NoBankSelected } from "@rocc/rocc-console-components"
import { CustomLoader, ErrorBoundary, getIntlProvider } from "@rocc/rocc-global-components"
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Icon, Menu, Tab } from "semantic-ui-react"
import { ALL_ROOMS_TAB_KEY, APP_NAME, CALLING_APP_STORE, CC_PATH, CONSOLE_APP_STORE, LOCALHOST } from "../../constants/constants"
import { DEMO_ENV_CONSOLE_ROUTE, ROOM_MONITORING_ROUTE } from "../../constants/routes"
import { TRACK, transformSessionTypeForAnalytics } from "../../constants/tracking"
import { appRefresh, resetFocusedConsoleSession, setActiveTab, setRoomMonitoringWindow, updateFocusedCallAndConsole, updateFocusedConsoleSession } from "../../redux/actions/appActions"
import globalStore from "../../redux/store/globalStore"
import en from "../../resources/translations/en-US"
import { cctvClose, getEvent, isDemoEnv, openLiveWindow, trackEvent } from "../../utility/helpers/helpers"
import styles from "./HomeComponent.module.scss"
import SomethingWentWrongBanner from "../something-went-wrong/SomethingWentWrongBanner"
import cx from "classnames"

import { FeatureFlagHelper } from "@rocc/rocc-client-services"
import { usePrevious } from "../../utility/hooks/hooks"
import { isEqual, xorWith } from "lodash"

const HomeApp = React.lazy(() => import("roccHome/App").catch(() => false))
const ActiveConsoleSessionFeature = React.lazy(() => import("roccConsole/ActiveConsoleSessionFeature").catch(() => false))

const HomeComponent = () => {
    const { intl } = getIntlProvider()
    const DEFAULT_TRANSACTIONS = { roomUuid: "", connectionType: EConnectionType.DEFAULT }
    const [protocolTransferStatus, setProtocolTransferStatus] = useState(false)
    const [consoleSessions, setConsoleSessions] = useState([] as IConsoleSession[])
    const [transactions, setTransactions] = useState([] as any[])
    const [receivers, setReceivers] = useState([] as any[])
    const [defaultTransaction, setDefaultTrancation] = useState(DEFAULT_TRANSACTIONS)
    const gState = globalStore.GetGlobalState()
    const dispatch = useDispatch()
    const previousConsolesSessionUpdate = usePrevious(consoleSessions ?? [])

    const {
        activeTabIndex,
        rooms,
        locations,
        currentUser,
        locationFetched,
        featureFlags,
        roomMonitoringWindow,
        focusedCallAndConsole,
    } = useSelector((state: IParentStore) => ({
        activeTabIndex: state.appReducer.activeTabIndex,
        rooms: state.customerReducer.rooms,
        locations: state.customerReducer.locations,
        currentUser: state.userReducer.currentUser,
        locationFetched: state.customerReducer.locationFetched,
        featureFlags: state.featureFlagsReducer.featureFlags,
        roomMonitoringWindow: state.appReducer.roomMonitoringWindow,
        focusedCallAndConsole: state.appReducer.focusedCallAndConsole,
    }))
    const isRoomMonitoringEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_ROOM_MONITORING)
    const isMultiEditEnabled = FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.FLAG_ROCC_MULTI_EDIT_WITHOUT_PARK_AND_RESUME)
    const isViewAuthorizationEnabled = !!FeatureFlagHelper.isFeatureEnabled(featureFlags, ROCC_FEATURES.ROCC_VIEW_AUTHORIZATION)
    const { CONNECTING, AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, AV_CALL_WAIT, DISCONNECTING } = TransactionValue
    const HOME_APP =
        <ErrorBoundary>
            <React.Suspense fallback={""}>
                {locationFetched === EFetchStatus.success ? <HomeApp /> : <></>}
            </React.Suspense>
        </ErrorBoundary>

    const DEFAULT_TAB = {
        title: "All Rooms",
        contextId: "",
        menuItem: (
            <Menu.Item>
                {activeTabIndex === 0 ?
                    <div className={styles.allRoomsTab}>
                        <Icon className={"Clinic big"} />
                        {intl.formatMessage({ id: "content.contactGroupCard.rooms", defaultMessage: en["content.contactGroupCard.rooms"] })}
                    </div> :
                    <Button secondary={true} className={styles.backToRooms}>
                        <Icon className={cx("NavigationLeft_Alternate huge", styles.backToRoomsIcon)} />
                        <span className={styles.backToRoomsText}>
                            {intl.formatMessage({ id: "content.desktopHome.backToRooms", defaultMessage: en["content.desktopHome.backToRooms"] })}
                        </span>
                    </Button>
                }
            </Menu.Item>),
        pane: <Tab.Pane attached={true} className={styles.subMenuColor} key={ALL_ROOMS_TAB_KEY}>
            <SomethingWentWrongBanner onRetry={() => dispatch(appRefresh())} />
            {HOME_APP}
        </Tab.Pane>
    }

    const [tabs, setTabs] = useState([DEFAULT_TAB])
    const DEFAULT_TAB_DETAILS = { title: "", tabIndex: -1 }

    const [activeTabDetails, setActiveTabDetails] = useState(DEFAULT_TAB_DETAILS)

    const renderConsoleSession = (consoleTabs: any[], activeSessions: IConsoleSession[]) => {
        const showFixedTabs = isRoomMonitoringEnabled || isMultiEditEnabled
        const softwareConnections: IConsoleSession[] = activeSessions.filter((session: any) => session.connectionMode !== EConnectionMode.CC && session.receiverName === "")
        if (receivers.length > 1 && showFixedTabs) {
            const sortedReceivers = receivers.sort((a, b) => a.monitorName - b.monitorName)
            sortedReceivers.forEach(receiver => {
                if (activeSessions.length || showFixedTabs) {
                    const consoleSession = activeSessions.find((session: IConsoleSession) => session.receiverName === receiver.receiverName)
                    const newTab = {
                        contextId: consoleSession?.contextId,
                        menuItem: (
                            <Menu.Item disabled={consoleSession === undefined}>
                                <ErrorBoundary>
                                    <React.Suspense fallback="">
                                        {consoleSession === undefined ? showFixedTabs && <NoBankSelected receiverName={receiver.monitorName} /> :
                                            <ActiveConsoleSessionFeature
                                                contextId={consoleSession.contextId}
                                                connectionType={consoleSession.connectionType}
                                                contentType={ESessionContentType.TAB_HEADER}
                                                roomUuid={consoleSession.roomUuid} />}
                                    </React.Suspense>
                                </ErrorBoundary>
                            </Menu.Item>),
                        pane: consoleSession !== undefined ?
                            getTabPane(consoleSession) : <></>
                    }
                    consoleTabs.push(newTab)
                }
            })
            if (softwareConnections.length) {
                getConsoleTabs(softwareConnections, consoleTabs)
            } else {
                //do nothing
            }
        } else {
            getConsoleTabs(activeSessions, consoleTabs)
        }
        return consoleTabs
    }

    const getConsoleTabs = (sessions: IConsoleSession[], consoleTabs: any[]) => {
        sessions.forEach((consoleSession: any) => {
            const newTab = {
                contextId: consoleSession.contextId,
                menuItem: (
                    <Menu.Item>
                        <ErrorBoundary>
                            <React.Suspense fallback="">
                                <ActiveConsoleSessionFeature
                                    contextId={consoleSession.contextId}
                                    connectionType={consoleSession.connectionType}
                                    contentType={ESessionContentType.TAB_HEADER}
                                    roomUuid={consoleSession.roomUuid} />
                            </React.Suspense>
                        </ErrorBoundary>
                    </Menu.Item>),
                pane: getTabPane(consoleSession)
            }
            consoleTabs.push(newTab)
        })
        return consoleTabs
    }

    const { PROTOCOL_MANAGEMENT, INCOGNITO_VIEW, FULL_CONTROL, VIEW } = EConnectionType

    const handleTabSwitch = () => {
        const oldTab = activeTabDetails.title
        if (tabs.length > activeTabIndex) {
            const newTab = tabs[activeTabIndex].title
            const { component, event: { tabSwitch } } = TRACK.CONSOLE_INFO
            trackEvent(component, `${tabSwitch}`, { From_Tab: oldTab, To_Tab: newTab, Event_By: currentUser.uuid })
            setActiveTabDetails({ title: newTab, tabIndex: activeTabIndex })
        }
    }

    const getTabPane = (consoleSession: IConsoleSession) => {
        return (
            <Tab.Pane attached={true} className={styles.subMenuColor} key={consoleSession.contextId}>
                <ErrorBoundary>
                    <React.Suspense fallback={<CustomLoader
                        content={`${intl.formatMessage({ id: "content.loading.text", defaultMessage: en["content.loading.text"] })}`}
                        dimmer={true}
                        inverted={true}
                        inline={true}
                        customStyle={{ top: "25rem" }}
                        size={"normal"} />}>
                        <ActiveConsoleSessionFeature
                            contextId={consoleSession.contextId}
                            connectionType={consoleSession.connectionType}
                            contentType={ESessionContentType.TAB_CONTENT}
                            roomUuid={consoleSession.roomUuid} />
                    </React.Suspense>
                </ErrorBoundary>
            </Tab.Pane>
        )
    }

    useEffect(() => {
        const subscribeToParentStore = () => {
            if (gState[CONSOLE_APP_STORE]) {
                setConsoleSessions(gState[CONSOLE_APP_STORE].consoleReducer.consoleSessions)
                setProtocolTransferStatus(gState[CONSOLE_APP_STORE].protocolTransferReducer?.protocolTransferStatus)
                setTransactions(gState[CONSOLE_APP_STORE].consoleReducer.consoleOperation.transactions)
                setReceivers(gState[CONSOLE_APP_STORE].consoleReducer.commandCenterDetails.commandCenterSeat.receivers)
                globalStore.SubscribeToPartnerState(APP_NAME, CONSOLE_APP_STORE, (changedState: any) => {
                    setTransactions(changedState.consoleReducer.consoleOperation.transactions)
                    setConsoleSessions(changedState.consoleReducer.consoleSessions)
                    setProtocolTransferStatus(changedState.protocolTransferReducer?.protocolTransferStatus)
                    setReceivers(changedState.consoleReducer.commandCenterDetails.commandCenterSeat.receivers)
                })
            }
        }
        subscribeToParentStore()
    }, [gState?.[CONSOLE_APP_STORE]])

    useEffect(() => {
        if (isRoomMonitoringEnabled &&
            consoleSessions.length > 0 && !roomMonitoringWindow) {
            dispatch(setRoomMonitoringWindow(true))
            openLiveWindow(ROOM_MONITORING_ROUTE)
        } else if (consoleSessions.length === 0 && roomMonitoringWindow) {
            cctvClose()
            dispatch(setRoomMonitoringWindow(false))
        }
    }, [consoleSessions])

    useEffect(() => {
        const newTabs = [DEFAULT_TAB]

        renderConsoleSession(newTabs, consoleSessions)
        setTabs(newTabs)
    }, [rooms, consoleSessions, activeTabIndex])

    useEffect(() => {
        let activeTab = tabs.findIndex(({ contextId }) => contextId === focusedCallAndConsole?.consoleContextId)
        if (activeTab === -1) {
            activeTab = 0
        }
        dispatch(setActiveTab(activeTab))

    }, [focusedCallAndConsole])

    /* Note: useEffect to prevent circular updates for focusedCallAndConsole using activeTabIndex*/
    useEffect(() => {
        let activeTab = tabs.findIndex(({ contextId }) => contextId === focusedCallAndConsole?.consoleContextId)
        if (activeTab === -1) {
            activeTab = 0
        }
        if (activeTab === activeTabIndex) {
            return
        }
        dispatch(updateFocusedConsoleSession(tabs[activeTabIndex]?.contextId))
    }, [activeTabIndex])

    useEffect(() => {
        if (!consoleSessions) {
            return
        }
        const activeSessions: IConsoleSession[] = xorWith(consoleSessions, previousConsolesSessionUpdate, isEqual)
        const consoleSessionContextId = activeSessions[0]?.contextId
        if (!consoleSessionContextId)
            return
        dispatch(updateFocusedConsoleSession(consoleSessionContextId))
    }, [JSON.stringify(consoleSessions.map((consoleSession: IConsoleSession) => consoleSession.connectionStatus))])

    useEffect(() => {
        dispatch(updateFocusedCallAndConsole())
    }, [gState[CALLING_APP_STORE]?.callReducer?.callDetails?.connectedCallDetails?.callStatus])

    useEffect(() => {
        handleTabSwitch()
    }, [activeTabIndex])

    useEffect(() => {
        const onGoingTraansaction = transactions.find((transaction) => transaction.connectionType === FULL_CONTROL || VIEW)
        if (transactions.length &&
            [CONNECTING].includes(onGoingTraansaction.connectionStatus)) {
            const defaultTransaction = {
                roomUuid: onGoingTraansaction.roomUuid,
                connectionType: onGoingTraansaction.connectionType
            }
            setDefaultTrancation(defaultTransaction)
        }
        if (transactions.length === 0) {
            const consoleSession = consoleSessions.find(session => session.roomUuid === defaultTransaction.roomUuid)
            if (consoleSession) {
                const activeRoomDetailInBanner = getRoomDetailFromUuid(rooms, consoleSession.roomUuid)
                const { name } = activeRoomDetailInBanner.identity
                if (activeRoomDetailInBanner.modality === EModalityType.MR) {
                    isDemoEnv() && openVideoInDemoMode(name, consoleSession.connectionType)
                }
            }
            setDefaultTrancation(DEFAULT_TRANSACTIONS)
        }

    }, [transactions])

    const openVideoInDemoMode = (room: string, connectionType: EConnectionType) => {
        let openedVideoInDemoMode: Window | null = null
        const demovideo = (window.location.toString().includes(LOCALHOST)) ? `/#${DEMO_ENV_CONSOLE_ROUTE}/${room}/${connectionType}` : `${CC_PATH}#${DEMO_ENV_CONSOLE_ROUTE}/${room}/${connectionType}`
        openedVideoInDemoMode = window.open(demovideo, "_blank")
        const { component, event: { demoEnvVideo } } = TRACK.HOME_COMPONENT
        trackEvent(component, getEvent(`${demoEnvVideo}`, transformSessionTypeForAnalytics(connectionType)))
        if (openedVideoInDemoMode !== null) {
            openedVideoInDemoMode.focus()
        }
    }

    const getRoomDetails = (session?: IConsoleSession) => {
        let roomProps = { name: "", address: "", location: "" }
        if (session) {
            const activeRoom = rooms.find(room => room.identity.uuid === session.roomUuid)
            const activeLocation = locations.find(location => location.id === activeRoom?.locationId)
            roomProps = {
                name: activeRoom ? activeRoom.identity.name : "",
                address: (activeRoom && activeRoom.identity.address) ? activeRoom.identity.address : "",
                location: activeLocation ? activeLocation.name : "",
            }
        }
        return roomProps
    }

    const hasActiveSession = (connectionType: EConnectionType) => {
        const hasSession = consoleSessions.find(session => session.connectionType === connectionType)
        const sessionDetails = {
            hasSession: hasSession ? true : false,
            messageProps: getRoomDetails(hasSession)
        }
        return sessionDetails
    }

    const shouldDisplayAwaitingBanner = () => {
        let displayAwaitingBanner = false
        const onGoingTransaction = transactions.find(transaction => transaction.connectionType === FULL_CONTROL ||
            (transaction.connectionType === VIEW && isViewAuthorizationEnabled && transaction.connectionStatus !== DISCONNECTING))
        if (onGoingTransaction) {
            if ([CONNECTING, AUTHORIZATION_REQUEST, AUTHORIZATION_APPROVAL_WAIT, AV_CALL_WAIT].includes(onGoingTransaction.connectionStatus)) {
                displayAwaitingBanner = true
            }
        }
        return displayAwaitingBanner
    }

    const fetchActiveSessionBanner = () => {
        // when on the session tab
        const editSessions = consoleSessions.filter((session: any) => session.connectionType === FULL_CONTROL).length
        if (activeTabIndex !== 0) {
            let session = consoleSessions[activeTabIndex - 1]
            if (isRoomMonitoringEnabled && activeTabIndex <= receivers?.length) {
                session = consoleSessions.find(session => session.receiverName === receivers[activeTabIndex - 1]?.receiverName) || session
            }
            if (session) {
                switch (session.connectionType) {
                    case INCOGNITO_VIEW: return <IncognitoBannerMessage switchedToView={false} {...getRoomDetails(session)} />
                    case PROTOCOL_MANAGEMENT: return <ProtocolManagementBannerComponent isProtocolManagement={true} {...getRoomDetails(session)} />
                    case FULL_CONTROL: return <EditingBannerComponent {...getRoomDetails(session)} multipleEditSessions={editSessions > 1} />
                    case VIEW: {
                        return session.connectionStatus === EConnectionState.PARKED ?
                            <ParkBannerComponent {...getRoomDetails(session)} /> : <></>
                    }
                    default: return <></>
                }
            }
        } else {
            const isPmSession = hasActiveSession(PROTOCOL_MANAGEMENT)
            const isEditSession = hasActiveSession(FULL_CONTROL)
            return (
                isPmSession.hasSession ? <ProtocolManagementBannerComponent isProtocolManagement={!isPmSession.hasSession} {...isPmSession.messageProps} /> : isEditSession.hasSession ?
                    <EditingBannerComponent {...isEditSession.messageProps} multipleEditSessions={editSessions > 1} />
                    : <></>
            )
        }
        return <></>
    }

    const getConsoleBannerMessage = () => {
        let roomDetails = { name: "", address: "", location: "", connectionType: "" }
        if (transactions && transactions.length > 0) {
            const ongoingTransaction = transactions.find((transaction) => transaction.connectionType === FULL_CONTROL || (transaction.connectionType === VIEW && isViewAuthorizationEnabled && transaction.connectionStatus !== DISCONNECTING))
            if (shouldDisplayAwaitingBanner()) {
                const editingRoom = rooms.find(room => room.identity.uuid === ongoingTransaction.roomUuid)
                if (editingRoom) {
                    const activeLocation = locations.find(location => location.id === editingRoom.locationId)
                    roomDetails = {
                        name: editingRoom.identity.name,
                        address: editingRoom?.address,
                        location: activeLocation?.name || "",
                        connectionType: ongoingTransaction.connectionType
                    }
                }
            }
        }
        const activeSessionBanner = fetchActiveSessionBanner()
        if (activeSessionBanner) {
            return <>
                <div>
                    {activeSessionBanner}
                </div>
                <div>
                    {shouldDisplayAwaitingBanner() ?
                        <AwaitingBannerComponent {...roomDetails} /> :
                        <></>}
                </div>
            </>
        }
        return <></>
    }

    return <>
        {protocolTransferStatus ? HOME_APP :
            <div className={styles.tabsNav} id="homeTabs">
                {getConsoleBannerMessage()}
                <Tab
                    menu={{ attached: "top", secondary: true, pointing: true }}
                    activeIndex={activeTabIndex || 0}
                    onTabChange={(e: any, data: any) => {
                        data.activeIndex === 0 ? dispatch(resetFocusedConsoleSession()) :
                            dispatch(updateFocusedConsoleSession(data.panes[data.activeIndex].pane.key))
                    }}
                    panes={tabs}
                    renderActiveOnly={false}
                />
            </div>
        }
    </>
}

export default HomeComponent
