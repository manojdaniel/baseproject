"""
 Created on Thu Sep 10 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
from flask_restful import Resource, reqparse
from flask import request

from src.loggers.log import create_logger
from src.wrappers.platform_services.iam_service.session_services import fetch_access_token, revoke_access_token
from src.constants.constants import AUTHORIZATION

LOG = create_logger("Session controller")


class Session(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument("loginUserName", type=str, required=True, help="This field cannot be left blank!")
    parser.add_argument("loginUserKey", type=str, required=True, help="This field cannot be left blank!")

    def post(self):
        body = Session.parser.parse_args()
        LOG.info(f"User: {body} trying to login")
        response = fetch_access_token(os.environ["ROCC_PROXY_URL"], body["loginUserName"], body["loginUserKey"])
        if response:
            if response["status"] == 200:
                return {"token": response["data"]["accessToken"], "session_id": response["data"]["sessionId"]}, 200
            return {"error": response["data"]}, response["status"]
        return {"error": "Login failed please contact system administrator!"}, 500


    def delete(self, session_id):
        try:
            token = request.headers[AUTHORIZATION]
            if not session_id:
                return {"SessionId is mandatory"}, 400
        except KeyError as ex:
            LOG.error("Token is neccessary to process this request: {}".format(ex))
            return {"error": "Token is neccessary to process this request"}, 401
        except Exception as ex:
            LOG.error("Could not process this request: {}".format(ex))
            return {"error": "Could not process this request"}, 500
        try:
            response = revoke_access_token(os.environ["ROCC_PROXY_URL"], session_id, token)
            if response:
                if response == "204":
                    return {"message": "User logged out successfully"}, 204
                return {"error": response["data"]}, response["status"]
            return {"error": "Logout failed please contact system administrator!"}, 500
        except KeyError as ex:
            LOG.error("ROCC_PROXY_URL should be present in the environment: {}".format(ex))
            return {"error": "Invalid ROCC_PROXY_URL in the environment"}, 500
        except Exception as ex:
            LOG.error("Could not process this request: {}".format(ex))
            return {"error": "Could not process this request"}, 500
