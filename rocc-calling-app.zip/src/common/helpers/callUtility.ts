/*
 * Created on Thu Aug 26 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus, IAVCallDetails, ICallStatus, IContactInfo, IUserInfo } from "@rocc/rocc-client-services"
import { infoLogger } from "@rocc/rocc-logging-module"
import { postMissedCallService } from "../../components/missed-call-panel/MissedCallServices"
import { CALL_REJECT, RINGING, TELEPRESENCE_SIDEBAR } from "../../constants/constants"
import { IStore } from "../../redux/interfaces/types"
import store from "../../redux/store/store"

export const filterCallStatus = (callStatuses: ICallStatus[], filteredStatus: ECallStatus, includeStatus: boolean) => {
    return includeStatus ?
        callStatuses.filter((callStatus) => callStatus.callStatus === filteredStatus) :
        callStatuses.filter((callStatus) => callStatus.callStatus !== filteredStatus)
}

export const filterCallStatusByContextId = (callStatuses: ICallStatus[], contextId: string, includeStatus: boolean) => {
    return includeStatus ?
        callStatuses.filter((callStatus) => callStatus.contextId === contextId) :
        callStatuses.filter((callStatus) => callStatus.contextId !== contextId)
}

export const filterCallStatusByContextIdAndStatus = (callStatuses: ICallStatus[], contextId: string, filteredStatus: ECallStatus[], includeStatus: boolean) => {
    callStatuses = includeStatus ?
        callStatuses.filter((callStatus) => callStatus.contextId === contextId && filteredStatus.includes(callStatus.callStatus)) :
        callStatuses.filter((callStatus) => !(callStatus.contextId === contextId && filteredStatus.includes(callStatus.callStatus)))
    return callStatuses
}

export const findCallStatusByContextId = (callStatuses: ICallStatus[], contextId: string) => {
    return callStatuses.find(callStatus => callStatus.contextId === contextId)
}

export const createICallStatusObject = (contextId: string, callStatus: ECallStatus) => {
    return { contextId, callStatus }
}

export const getCallStatusFromICallStatus = (avCallStatuses: ICallStatus[]) => {
    return avCallStatuses.map((callStatus) => callStatus.callStatus)
}

export const enableBrowserToPhoneCall = (
    contactInfo: IContactInfo,
    currentUser: IUserInfo,
    setPhoneCallStatus: (state: ECallStatus, recipientInfo?: IContactInfo) => void,
    toggleRightSidebarPanelAction: (state: any) => void,
) => {
    if (currentUser && currentUser.accessToken) {
        setPhoneCallStatus(ECallStatus.CALLING, contactInfo)
        toggleRightSidebarPanelAction({ sidebarState: true, currentSidebar: TELEPRESENCE_SIDEBAR })
    }
}

export const upsertCallStatus = (contextId: string, newStatus: ECallStatus) => {
    const state: IStore = store.getState()
    const { videoCallStatus } = state.callReducer
    const { CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED } = ECallStatus
    const endValues = [CALLDECLINED, CALLREJECT, DISCONNECTED, NOT_ANSWERED, FAILED]

    return [
        ...videoCallStatus.filter((callStatus: ICallStatus) => !(callStatus.contextId === contextId || endValues.includes(callStatus.callStatus))),
        createICallStatusObject(contextId, newStatus)
    ]
}

export const disconnectAllCallStatus = () => {
    const state: IStore = store.getState()
    const { videoCallStatus } = state.callReducer
    return [
        ...videoCallStatus.map(
            (statusEntry: ICallStatus) => ({ ...statusEntry, callStatus: ECallStatus.DISCONNECTED })
        )
    ]
}

export const checkIfCallIsAlreadyActive = (contextId: string) => {
    const state: IStore = store.getState()
    const { connectedCallDetails } = state.callReducer.callDetails
    if (connectedCallDetails.contextId === contextId) {
        infoLogger(`Call context ${contextId} is already in active state`)
        return true
    }
    return false
}

export const checkIfNewCallInitiated = () => {
    const { CONNECTING, CALLING, RINGING } = ECallStatus
    const callStatuses = store.getState().callReducer.videoCallStatus.map(callStatus => callStatus.callStatus)
    return [CONNECTING, CALLING, RINGING].some(callStatus => callStatuses.includes(callStatus))
}

export const checkAndAddMissedCallEntry = (currentUser: IUserInfo, uuid: string, connectedCallDetails: IAVCallDetails, communicationUrl: string, callContextId: string) => {
    if (connectedCallDetails.participants.some((participant) => {
        return (participant.uuid === uuid && [undefined, RINGING, CALL_REJECT].includes(participant.callStatus))
    })) {
        postMissedCallService(currentUser, communicationUrl, callContextId, uuid, currentUser.uuid)
    }
}
