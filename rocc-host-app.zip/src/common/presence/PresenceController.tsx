/*
 * Created on The Oct 19 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { ECallStatus, ICallStatus, IParentStore, EConnectionStatus } from "@rocc/rocc-client-services"
import isEqual from "lodash.isequal"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { APP_NAME, CALLING_APP_STORE, CONSOLE_APP_STORE, UNLOAD } from "../../constants/constants"
import { updateCurrentUserPresence } from "../../redux/actions/userAction"
import globalStore from "../../redux/store/globalStore"
import { checkCallStatus, isLogoutInProgress } from "../../utility/helpers/helpers"

let presencePriority: EUserPresence[] = []
const callPresence = 0
const consolePresence = 1
const { CALLING, CONNECTED, CONNECTING } = ECallStatus
const { BUSY, IN_CALL, AVAILABLE, OFFLINE } = EUserPresence

const PresenceController = () => {

    const {
        applicationConnectionState,
        contactsFetched,
        updatedPresenceStatus,
        userLocation
    } = useSelector((state: IParentStore) => ({
        applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
        contactsFetched: state.userReducer.contactsFetched,
        updatedPresenceStatus: state.clientStatusReducer.presenceStatus,
        userLocation: state.userReducer.currentUser.loggedInLocation
    }))

    const [init, setInit] = useState(false)
    const [videoCallStatus, setVideoCallStatus] = useState([] as ICallStatus[])
    const [phoneCallStatus, setPhoneCallStatus] = useState(ECallStatus.IDLE)
    const [isConsoleActive, setIsConsoleActive] = useState(false)
    const [callingStoreSubscribed, setCallingStoreSubscribed] = useState(false)
    const [consoleStoreSubscribed, setConsoleStoreSubscribed] = useState(false)
    const videoCallStatusRef = useRef(videoCallStatus)
    const phoneCallStatusRef = useRef(phoneCallStatus)
    const isConsoleActiveRef = useRef(isConsoleActive)
    const dispatch = useDispatch()
    const gState = globalStore.GetGlobalState()

    const subscribeToParentStore = () => {
        if (!callingStoreSubscribed && gState[CALLING_APP_STORE]) {
            setCallStatus(gState[CALLING_APP_STORE])
            globalStore.SubscribeToPartnerState(APP_NAME, CALLING_APP_STORE, (changedState: any) => {
                setCallStatus(changedState)
            })
            setCallingStoreSubscribed(true)
        }
        if (!consoleStoreSubscribed && gState[CONSOLE_APP_STORE]) {
            setConsoleStatus(gState[CONSOLE_APP_STORE])
            globalStore.SubscribeToPartnerState(APP_NAME, CONSOLE_APP_STORE, (changedState: any) => {
                setConsoleStatus(changedState)
            })
            setConsoleStoreSubscribed(true)
        }
    }

    const setConsoleStatus = (gState: any) => {
        const consoleStatus = gState.consoleReducer.consoleSessions.length > 0
        if (isConsoleActiveRef.current !== consoleStatus) {
            setIsConsoleActive(consoleStatus)
        }
    }

    const setCallStatus = (gState: any) => {
        if (!isEqual(gState.callReducer.videoCallStatus, videoCallStatusRef.current)) {
            setVideoCallStatus(gState.callReducer.videoCallStatus.map((callStatus: ICallStatus) => { return { ...callStatus } }))
        }
        if (gState.callReducer.phoneCallStatus !== phoneCallStatusRef.current) {
            setPhoneCallStatus(gState.callReducer.phoneCallStatus)
        }
    }

    const updatePresence = (forceUpdate: boolean = false, isLoggedInLocationUpdated: boolean = false) => {
        presencePriority[callPresence] = [CALLING, CONNECTED].includes(phoneCallStatus) ||
            checkCallStatus(videoCallStatus, [CALLING, CONNECTED, CONNECTING]) ?
            IN_CALL : AVAILABLE
        presencePriority[consolePresence] = isConsoleActive ? BUSY : AVAILABLE

        if (presencePriority.includes(IN_CALL)) {
            dispatch(updateCurrentUserPresence(IN_CALL, forceUpdate, isLoggedInLocationUpdated))
        } else if (presencePriority.includes(BUSY)) {
            dispatch(updateCurrentUserPresence(BUSY, forceUpdate, isLoggedInLocationUpdated))
        } else {
            if (!isLogoutInProgress()) {
                dispatch(updateCurrentUserPresence(AVAILABLE, forceUpdate, isLoggedInLocationUpdated))
            }
        }
    }

    useEffect(() => {
        videoCallStatusRef.current = videoCallStatus
        phoneCallStatusRef.current = phoneCallStatus
        isConsoleActiveRef.current = isConsoleActive
    }, [videoCallStatus, phoneCallStatus, isConsoleActive])

    useEffect(() => {
        const shouldUpdatePresence = contactsFetched &&
            applicationConnectionState === EConnectionStatus.ONLINE
        if (shouldUpdatePresence) {
            updatePresence()
        }
    }, [videoCallStatus, phoneCallStatus, isConsoleActive, applicationConnectionState])
    useEffect(() => {
        dispatch(updateCurrentUserPresence(AVAILABLE, false, true))
    }, [userLocation])

    useEffect(() => {
        updatePresence(updatedPresenceStatus === OFFLINE)
    }, [updatedPresenceStatus])

    useEffect(() => {
        if (!init) {
            setInit(true)
            window.addEventListener(UNLOAD, () => {
                dispatch(updateCurrentUserPresence(OFFLINE))
            })
            dispatch(updateCurrentUserPresence(AVAILABLE, true))
        }
        return () => {
            presencePriority = []
            window.removeEventListener(UNLOAD, () => {
                dispatch(updateCurrentUserPresence(OFFLINE))
            })
        }
    }, [])

    useEffect(() => { subscribeToParentStore() }, [gState])

    return <div />
}

export default PresenceController
