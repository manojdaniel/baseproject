/*
 * Created on Thu Oct 21 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { shallow } from "enzyme"
import Settings from "./Settings"
import { Container } from "semantic-ui-react"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        currentUser: { allRoles: [] },
        featureFlags: {
            FLAG_TECH_APP_DOWNLOAD: "false"
        }
    }),
    useDispatch: () => jest.fn()
}))

describe("Settings Component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }
        mockUseEffect()
        wrapper = shallow(<Settings />)
    })
    it("should render Container", () => {
        const fragment = wrapper.find(Container)
        expect(fragment).toHaveLength(1)
    })
})
