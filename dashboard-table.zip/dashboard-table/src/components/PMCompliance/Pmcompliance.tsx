import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "./Pmcompliance.scss"
interface Props {
	data: any[];
	loading: any;
}

const Pmcompliance = ({ data, loading }: Props) => {
	const [currentPage, setCurrentPage] = useState<number>(1);
	const pageSize = 10;
	useEffect(() => { }, [data]);
	const columns = [
		{
			title: "ASSET TAG",
			dataIndex: "assetTag",
			key: "assetTag",
		},
		{
			title: "ASSET SAP NUMBER",
			dataIndex: "assetSapNumber",
			key: "assetSapNumber",
			width: "ASSETSAPNUMBER",
		},
		{
			title: "WORK ORDER #",
			dataIndex: "workOrder",
			key: "workOrder",
			width: "WORKORDER",
		},
		{
			title: "PLANNED DATE",
			dataIndex: "plannedDate",
			key: "plannedDate",
		},
		{
			title: "COMPLETION DATE",
			dataIndex: "completionDate",
			key: "completionDate",
		},
		{
			title: "COMPLIANCE",
			dataIndex: "compliance",
			key: "compliance",
		},
	];
	const onChangePage = (page: number) => {
		setCurrentPage(page);
	};

	return (
		<div id="pmcompliance-box">
			<div className="common-box-filter">
				<div className="title">PM COMPLIANCE</div>
			</div>
			<div className="pmcompliance-table">
				<Table
					loading={loading}
					tableLayout={undefined}
					dataSource={data}
					columns={columns}
					scroll={{ x: true }}
					pagination={{
						current: currentPage,
						pageSize,
						total: data.length,
						onChange: onChangePage,
						showSizeChanger: false
					}}
				/></div>
		</div>
	);
};

export default Pmcompliance;
