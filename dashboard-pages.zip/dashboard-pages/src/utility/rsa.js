import { JSEncrypt } from "jsencrypt";

// Copied from https://github.com/travist/jsencrypt
var publicKey = `${process.env.REACT_RSA}`;

export function encryptRSAData(data) {
    let encrypt = new JSEncrypt();
    // Assign our encryptor to utilize the public key.
    encrypt.setPublicKey(publicKey);
    // Perform our encryption based on our public key - only private key can read it!
    let encrypted = encrypt.encrypt(data);

    return encrypted;
}

