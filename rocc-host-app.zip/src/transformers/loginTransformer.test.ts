/*
 * Created on Mon Dec 20 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import {loginTransformer} from "./loginTransformer"

const response = {
    data: { 
        loginResponse: { 
            sessionId: "f1c95a3b-3897-4c4f-81ed-47c2f0cb2000", 
            accessToken: "5fc1d020-f5a8-45f8-9e7c-cfd3398e0a4c",  
            orgId: "e9101b82-493c-40df-b539-d605732ffbb4",
            userId: "28ea7b23-5e64-4384-9461-61f26fe0158d",
            allOrgList: [{ "organizationId": "e9101b82-493c-40df-b539-d605732ffbb4", "organizationName": "platinum", "groups": ["AdminGroup"] }], 
            userName: "isomark@mailinator.com" 
        }, 
        isProxy: "true", 
        configs: {}, 
        features: ["CALL_VIDEO_CALL"], 
        profile: "user", 
        nativeAppConfig: { "kitConfiguration": { "nativeAppIntegrationKitWin": "", "nativeAppInstallerUserManualWin": "" } }, 
        featureFlagConfig: { "provider": { "configuration": { "clientId": "29411e22-ff95-4b7a-b931-7d6a713c2777", "applicationId": "a5873789-4799-4d91-a4ee-cc71460cf8d1", "apiEndpoint": "https://vip-feature-flags-eval-dev.cloud.pcftest.com/philips/vip" }, "type": "PHILIPS" } }, 
        defaultFeatureFlags: { "enabledFeatures": ["rocc-emerald"] } }
}

describe("loginTransformer tests", () => {
    it("should return isProxy", () => {
        expect(loginTransformer(response).isProxy).toBe("true")
    })
})
