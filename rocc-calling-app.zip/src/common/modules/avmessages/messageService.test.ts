/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IUserInfo, DEFAULT_CONTACT_INFO, EResponse, ECallStatus } from "@rocc/rocc-client-services"
import { CALL_DISCONNECTED, CALL_REJECT, RINGING } from "../../../constants/constants"
import * as apiUtility from "../../helpers/apiUtility"
import { ICreateUrlCallFunction, IRequester } from "./av-messages/types"
import { checkCurrentCallRejected, createUrlCall, fetchCommunicationClientDetails, getCallerID, getContextDetails, getRequesterActualUUID, getUserVideoAcceptedTab } from "./messageService"

jest.mock("@rocc/rocc-http-client")

const getAxiosResponse = (data: any) => {
    return {
        data: {data},
        status: 200,
        statusText: "OK",
        headers: {},
        config: {}
    }
}

const currentUser: IUserInfo = { ...DEFAULT_CONTACT_INFO, accessToken: "accessToken", accessTokenExpiryTime: "", onBoarded: true, sessionId: "sessionId", locale: "en-US"}
const requester: IRequester = {
    primaryUuid: "28ea7b23-5e64-4384-9461-61f26fe0158d", secondaryUuid: [""], callStatus: "RINGING", userContext: { callerId: "03393e5f-9721-4747-8981-c4d0567e0a67" }
}
const callResponse = {
    contextId: "dfa87728-8701-44bf-821b-00ab56c550af",
    roomName: null,
    roomType: null,
    callType: "INAPP_CALL",
    mediaType: ["AUDIO", "VIDEO"],
    requester: requester,
    participants: [
        { primaryUuid: "03393e5f-9721-4747-8981-c4d0567e0a67", callStatus: "CALLING", secondaryUUID: [""] }
    ]
}

describe("fetchCommunicationClientDetails tests", () => {
    it("get communication details 200 response", () => {
        const response = getAxiosResponse({})
        jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve(response))
        fetchCommunicationClientDetails("https://communicationUrl/philips/rocc", "token", "userUuid").then(response => {
            expect(response.status).toBe(EResponse.SUCCESS)
        })
    })

    it("get communication details 400 response", () => {
        const response = {
            data: {},
            status: 400,
            statusText: "Bad Request",
            headers: {},
            config: {}
        }
        jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve(response))
        fetchCommunicationClientDetails("https://communicationUrl/philips/rocc", "token", "userUuid").then(response => {
            expect(response.status).toBe(EResponse.ERROR)
        })
    })
})

describe("createUrlCall test", () => {
    it("test create url object", () => {
        const createUrlObject: ICreateUrlCallFunction = {
            accessToken: "accessToken",
            sessionId: "sessionId",
            userUuid: "userUuid",
            communicationServiceUrl: "communicationServiceUrl/",
            contextId: "contextId",
            callStatus: "CALL_ACCEPTED",
            state: true
        }
        expect(createUrlCall(createUrlObject).url).toBe("communicationServiceUrl/contextId")
    })
})

describe("getContextDetails tests", () => {
    jest.spyOn(apiUtility, "getService").mockReturnValue(Promise.resolve(getAxiosResponse(callResponse)))
    getContextDetails("contextId", currentUser, "https://communicationUrl").then(response => {
        expect(response.status).toBe(200)
    })
})

describe("getUserVideoAcceptedTab test", () => {
    it("test when userContext is present", () => {
        expect(getUserVideoAcceptedTab(callResponse).callerId).toBe("03393e5f-9721-4747-8981-c4d0567e0a67")
    })

    it("when user context is not present", () => {
        expect(getUserVideoAcceptedTab({requester: {}})).toBe(undefined)
    })
})

describe("getRequesterActualUUID tests", () => {
    const requester: IRequester = {
        primaryUuid: "primaryUuid",
        secondaryUuid: ["secondaryUuid"],
        callStatus: ECallStatus.RINGING,
        userContext: {}
    }
    it("should return requester Uuid", () => {
        expect(getRequesterActualUUID(requester)).toBe(requester.secondaryUuid[0])
    })

    it("should return primaryUuid if secondary is not available", () => {
        requester.secondaryUuid = []
        expect(getRequesterActualUUID(requester)).toBe(requester.primaryUuid)
    })

    it("should return empty if requester is not available", () => {
        expect(getRequesterActualUUID(null as any)).toBe("")
    })
})

describe("getCallerID tests", () => {
    it("test when requester has callerId", () => {
        expect(getCallerID(requester, callResponse.participants)).toBe("")
    })
})

describe("checkCurrentCallRejected tests", () => {
    const callDetails = {
        requester: {
            primaryUuid: "primaryUuid",
            secondaryUuid: ["secondaryUuid"],
            callStatus: CALL_REJECT,
            userContext: {}
        },
        participants: [{
            callStatus: RINGING
        }]
    }
    it("should return call reject response", () => {
        expect(checkCurrentCallRejected(callDetails as any).isRejectedByMe).toBe(true)
    })

    it("should return call reject response as false", () => {
        callDetails.requester.callStatus = RINGING
        expect(checkCurrentCallRejected(callDetails as any).isRejectedByMe).toBe(false)
    })

    it("should return call reject response when participant reject the call", () => {
        callDetails.requester.callStatus = RINGING
        callDetails.participants[0].callStatus = CALL_DISCONNECTED
        expect(checkCurrentCallRejected(callDetails as any).isRejectedByMe).toBe(false)
    })
})
