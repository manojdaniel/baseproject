/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IRoccVideoCall } from "@rocc/rocc-av-communication-sdk"
import { CallWindowFooter } from "@rocc/rocc-calling-components"
import { EButtonDirection, IAVCallDetails } from "@rocc/rocc-client-services"
import { RoccAvRoom } from "@rocc/rocc-common-communication-sdk"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, sendLogsToAzure } from "@rocc/rocc-logging-module"
import React, { Dispatch, useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Icon } from "semantic-ui-react"
import { AUDIO, DEFAULT, LOCAL_VIDEO } from "../../../../constants/constants"
import { setDeafenCall, setMuteCall } from "../../../../redux/actions/callActions"
import { GLOBAL_UPDATE_NOTIFICATION_MESSAGE, GLOBAL_UPDATE_NOTIFICATION_MODAL } from "../../../../redux/actions/types"
import { IStore } from "../../../../redux/interfaces/types"
import { dispatchToParentStore } from "../../../../redux/store/externalAppStates"
import en from "../../../../resources/locales/en_US.json"
import { getDurationInFormat } from "../../../helpers/dateTimeUtility"
import { fetchActiveEditSession, fetchEditConnectionRoomDetails, hideNotificationModal } from "../../../helpers/helpers"
import { attachLocalVideoEvent, detachLocalVideoEvent, videoCallDuration } from "../../../helpers/TelemetryTrackingHelper"
import { leaveRoom } from "../AudioVideoHelper"
import { handleError, handleVideoSwitchError } from "../HandleError"
import { ECallOptions } from "../types"
import styles from "./CallControls.scss"

interface ICallControls {
    videoStatus: boolean
    setVideoStatus: (videoStatus: boolean) => void
    activeRoom: any
    selectedOption: ECallOptions
    setSelectedOption: (option: ECallOptions) => void
    previewTracks: any
    isDesktopFullScreen: boolean
    activeCall: IAVCallDetails
    vendorService: IRoccVideoCall
}

export const volumeMute = () => {
    try {
        updateVolume(true, 0)
    } catch (error: any) {
        handleError("ToggleLocalVolume.tsx:voumeMute()", error)
    }
}

const updateVolume = (muteAudio: boolean, volume: number) => {
    const players = document.getElementsByTagName(AUDIO)
    for (const player of players) {
        if (player.parentElement && player.parentElement.id !== LOCAL_VIDEO) {
            player.volume = volume
            player.muted = muteAudio
        }
    }
}

const componentName = "CallControls"

const CallControls = (props: ICallControls) => {
    const {
        videoSource,
        currentUser,
        volume,
        isFirstParticipant,
        permissions,
    } = useSelector((state: IStore) => ({
        videoSource: state.callReducer.videoSource,
        currentUser: state.externalReducer.currentUser,
        volume: state.callReducer.volume,
        isFirstParticipant: state.callReducer.callDetails.connectedCallDetails.isFirstParticipant,
        permissions: state.externalReducer.permissions,
    }))

    const {
        videoStatus,
        setVideoStatus,
        activeRoom,
        selectedOption,
        setSelectedOption,
        previewTracks,
        isDesktopFullScreen,
        activeCall,
        vendorService
    } = props
    const { numOfParticipants } = activeCall

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()
    const [attachVideoDuration, setAttachVideoDuration] = useState(new Date())
    const prevNumOfParticipants = useRef(numOfParticipants)
    //TODO: get this value from redis
    const VIDEOCALL_STATE_TIMEOUT = 40000
    const { SETTINGS, ADD_PARTICIPANT } = ECallOptions

    const getModalMessage = (name: string, locationName: string, address?: string,) => {
        return `${intl.formatMessage({
            id: "content.callEndWarning.message", defaultMessage: en["content.callEndWarning.message"]
        })}${name}${intl.formatMessage({
            id: "content.callEndWarning.at", defaultMessage: en["content.callEndWarning.at"]
        })}${address}${intl.formatMessage({
            id: "content.callEndWarning.in", defaultMessage: en["content.callEndWarning.in"]
        })}${locationName}`
    }

    const getHeader = () => {
        return (
            <div className={styles.headerContainer} id="headerContainer">
                <span className={styles.headerContainerIcon}>
                    <Icon className={"icon ExclamationMarkCircle"} />
                </span>
                <span className="headerContainerMessage">
                    {`${intl.formatMessage({ id: "content.callEndWarning.header", defaultMessage: en["content.callEndWarning.header"] })}`}
                </span>
            </div>
        )
    }

    const onModalCancel = () => {
        sendLogsToAzure({ contextData: { component: componentName, event: `User ${currentUser.uuid} cancelled the call disconnect modal`, User: currentUser.uuid } })
        hideNotificationModal()
    }

    const onModalConfirm = () => {
        sendLogsToAzure({ contextData: { component: `Audio Video Calling: ${componentName}`, event: `User ${currentUser.uuid} clicked on the end call button on the call disconnect modal.`, User: currentUser.uuid } })
        leaveRoom(activeCall, activeRoom, dispatch, vendorService)
        hideNotificationModal()
    }

    const leaveRoomWrapper = (activeCall: IAVCallDetails, activeRoom: RoccAvRoom, dispatch: Dispatch<any>) => {
        const activeEditSession = fetchActiveEditSession()
        if (activeEditSession) {
            const { roomDetails, locationDetails } = fetchEditConnectionRoomDetails(activeEditSession)
            const { name, address } = roomDetails.identity
            const locationName = locationDetails.name

            const notificationModal = {
                showModal: true,
                header: getHeader(),
                modalContent: getModalMessage(name, locationName, address),
                actionButton1Text: intl.formatMessage({ id: "content.callEnd.text", defaultMessage: en["content.callEnd.text"] }),
                actionButton2Text: intl.formatMessage({ id: "content.cancel.btn", defaultMessage: en["content.cancel.btn"] }),
                buttonDirection: EButtonDirection.RIGHT,
                actionButton1Onclick: onModalConfirm,
                actionButton2Onclick: onModalCancel,
                modalStyles: "activeSessionOnSelectedMonitor"
            }
            dispatchToParentStore({ type: GLOBAL_UPDATE_NOTIFICATION_MODAL, payload: { notificationModal: notificationModal } })
        }
        else {
            leaveRoom(activeCall, activeRoom, dispatch, vendorService)
        }
    }

    const onCallDisconnect = () => {
        leaveRoomWrapper(activeCall, activeRoom, dispatch)
    }

    const TrackEvents = (event: string) => {
        sendLogsToAzure({ contextData: { component: `Audio Video Calling: ${componentName}`, event } })
    }

    const detachLocalVideo = async (room: RoccAvRoom) => {
        vendorService.detachLocalVideo(room)
        TrackEvents(detachLocalVideoEvent(currentUser, numOfParticipants))
        sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalVideo", event: videoCallDuration(currentUser), duration: getDurationInFormat(new Date(), attachVideoDuration) } })
        setVideoStatus(false)
    }

    const volumeUnmute = (val: any) => {
        try {
            updateVolume(false, val / 100)
            dispatch(setDeafenCall(activeCall, false))
        } catch (error: any) {
            handleError("ToggleLocalVolume.tsx:volumeUnmute()", error)
        }
    }

    useEffect(() => {
        if (numOfParticipants > 1 && videoStatus) {
            detachLocalVideo(activeRoom)
        }
        if (prevNumOfParticipants.current < numOfParticipants && numOfParticipants === 2 && isFirstParticipant) {
            dispatchToParentStore({
                type: GLOBAL_UPDATE_NOTIFICATION_MESSAGE, payload: {
                    notificationMessage:
                    {
                        showNotification: true,
                        message: [{
                            header: `${intl.formatMessage({ id: "content.consoleMessage.videoCallDisconnectedHeader", defaultMessage: en["content.consoleMessage.videoCallDisconnectedHeader"] })}`,
                            content: `${intl.formatMessage({ id: "content.consoleMessage.videoCallDisconnectedContent", defaultMessage: en["content.consoleMessage.videoCallDisconnectedContent"] })}`,
                        }],
                        isSuccess: false,
                        isWarning: true,
                        isNotification: false,
                        fixed: true,
                        timeOut: VIDEOCALL_STATE_TIMEOUT,
                        customStyle: { top: "4rem", right: "1rem", width: "22.4375rem", height: "9.8125rem", border: "none" }
                    },
                },

            })
        }
        prevNumOfParticipants.current = numOfParticipants
    }, [numOfParticipants])

    useEffect(() => {
        if (videoStatus) {
            setAttachVideoDuration(new Date())
        }
    }, [videoStatus])

    useEffect(() => { volumeUnmute(volume ?? 100) }, [volume])

    const displayCallOptions = (updatedOption: ECallOptions) => {
        if (selectedOption === updatedOption) {
            isDesktopFullScreen ? setSelectedOption(ECallOptions.NONE) : setSelectedOption(ECallOptions.ADD_PARTICIPANT)
        } else {
            setSelectedOption(updatedOption)
        }
    }

    const attachLocalVideo = async (room: any) => {
        const deviceId = videoSource ? videoSource : DEFAULT
        const container: any = document.getElementById(LOCAL_VIDEO)
        try {
            const attachLocalVideoResponse = await vendorService.attachLocalVideo({ room, deviceId, container })
            const localVideoTrack = attachLocalVideoResponse.localVideoTrack

            previewTracks.push(localVideoTrack)
            TrackEvents(attachLocalVideoEvent(currentUser))
            setVideoStatus(true)
        } catch (error: any) {
            errorLogger(`Exception while attaching local Video ${error}`)
            const err = error.errorMessage ? error.errorMessage : error
            handleVideoSwitchError(err, dispatch)
        }
    }

    const toggleLocalVideo = () => {
        sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalVideo" } })
        if (activeRoom) {
            if (videoStatus) {
                detachLocalVideo(activeRoom)
            } else if (numOfParticipants === 0 || (numOfParticipants === 1)) {
                attachLocalVideo(activeRoom)
            }
        }
    }

    const toggleLocalAudio = () => {
        sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalAudio" } })
        if (activeRoom) {
            dispatch(setMuteCall(activeCall, !activeCall.isMuted))
        }
    }

    const toggleLocalVolume = () => {
        sendLogsToAzure({ contextData: { component: "Audio Video Calling: ToggleLocalVolume" } })
        dispatch(setDeafenCall(activeCall, !activeCall.isDeafened))
    }

    return (
        <>
            <CallWindowFooter
                showCallControl={true}
                videoStatus={videoStatus}
                callWindowFullscreen={isDesktopFullScreen}
                microphoneStatus={!activeCall.isMuted}
                audioOutputStatus={!activeCall.isDeafened}
                dimEndCallControl={false}
                dimEndCallControlMessage={""}
                toggleParticipants={() => displayCallOptions(ADD_PARTICIPANT)}
                toggleVideoOutput={toggleLocalVideo}
                toggleAudioInput={toggleLocalAudio}
                toggleAudioOutput={toggleLocalVolume}
                toggleSettings={() => displayCallOptions(SETTINGS)}
                toggleEndCall={onCallDisconnect}
                displayParticipants={isDesktopFullScreen ? true : false}
                displayVideoOutput={permissions.CALL_VIDEO_CALL && numOfParticipants < 2}
            />
        </>
    )
}

export default CallControls
