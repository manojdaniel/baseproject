"""
 Created on Fri Dec 12 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import os
from src.constants.config_keys import VAULT_PARENT_ORG_ID

from src.constants.constants import DATA, HSDP_IAM_URL, HSDP_ORGANIZATION_ID, ROCC_ORGANIZATIONS, ROCC_USERS, SERVICE_AUTH_ISSUER, \
    SERVICE_AUTH_PRIVATE_KEY
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.utility.utility import construct_negative_response
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.graphql.mutations.mutations import update_rocc_kvm_employee_user
from src.wrappers.graphql.queries.queries import fetch_kvm_user_details, fetch_customer_name_from_db_id
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values, get_profile_data
from src.wrappers.platform_services.audit_service.audit_services import prepare_and_post_audit

LOG = create_logger("UserManagementServices")


class UserManagementService():

    def __init__(self, service_user_uuid, org_db_id, service_user_token):
        try:
            self._token = None
            self._org_infra_uuid = None
            self._service_user_uuid = service_user_uuid
            self._service_user_token = service_user_token
            self._org_db_id = org_db_id
            self._profile_configs = get_profile_data()
            self._parent_org_infra_uuid = self._profile_configs[VAULT_PARENT_ORG_ID]
            read_only_client = get_client_connection(access_token=self._service_user_token, org_infra_uuid=self._parent_org_infra_uuid, is_fse=True)
            self.populate_service_token(read_only_client)
            self._client = get_client_connection(access_token=self._token, org_infra_uuid=self._org_infra_uuid, is_fse=False)
        except RoccException as ex:
            LOG.error(f"RoccException - Service initialization failed with error: {ex}")
            raise RoccException(status_code=ex.status_code, payload=str(ex.payload)) from ex
        except Exception as ex:
            LOG.exception(f"Service initialization failed with error: {ex}")
            raise RoccException(status_code=500, payload="Internal server error") from ex

    def populate_service_token(self, read_only_client):
        try:
            db_result = read_only_client.execute(fetch_customer_name_from_db_id, variable_values={"org_db_id": self._org_db_id})
            customers = db_result[ROCC_ORGANIZATIONS]
            if customers and len(customers) == 1:
                customer_name = customers[0]["org_identifier"]
                customer_vault_values = get_path_specific_vault_values(path_name=customer_name)
                self._org_infra_uuid = customer_vault_values[DATA][HSDP_ORGANIZATION_ID]
                self._token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                              issuer=customer_vault_values[DATA][SERVICE_AUTH_ISSUER],
                                                              private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            else:
                LOG.error(f"Invalid customer_id: {self._org_db_id}, could not get valid customer name!")
                raise RoccException(status_code=400, payload="Invalid customer_id")
        except Exception as ex:
            LOG.exception(f"Service token creation failed with error: {ex}")
            raise RoccException(status_code=500, payload="Internal server error") from ex

    def safe_audit(self, event_subtype, action, outcome, code, value):
        if self._org_infra_uuid:
            try:
                prepare_and_post_audit(event_type="Modify user", event_subtype=event_subtype, action=action, outcome=outcome,
                                       user_detail=self._service_user_uuid,
                                       org_id=self._org_infra_uuid, token=self._token,
                                       **{"code": code, "value": value})
            except Exception as ex:
                LOG.exception(f"Audit logging failed with error: {ex}")

    def update_user_details_to_map_kvm_role(self, user_db_id, kvm_user_name):
        """
        - Check if user with user_id and customer_id is present - extract kvm_username
        - Compare new_kvm_username with existing_kvm_username
            - If it matches, return already present (200)
            - If it is equal to admin - return 403 Forbidden
            - Else update and return 200
        """
        try:
            if kvm_user_name == "admin":
                LOG.error("Provided kvm_username: admin is forbidden from usage")
                return construct_negative_response(code="403 Forbidden",
                                                   title="Invalid kvm username",
                                                   error_message="Usage of Provided KVM username - admin is forbidden"), 403
            user_object = self.get_user_object(user_db_id)
            if len(user_object) == 0:
                LOG.error(f"Provided user_id: {user_db_id} is not present under customer: {self._org_db_id}")
                return construct_negative_response(code="404 Resource not found",
                                                   title="Invalid user",
                                                   error_message="Provided user is not present"), 404
            elif len(user_object) > 1:
                LOG.error(f"Provided user_id: {user_db_id} has more than one instance")
                return construct_negative_response(code="400 Bad Request",
                                                   title="Invalid user",
                                                   error_message="Provided user has more than one instance"), 400
            existing_kvm_username = user_object[0]["kvm_user_name"]
            if existing_kvm_username == kvm_user_name:
                LOG.info(f"Mapping between user with db_id: {user_db_id} and provided kvm_username is already present")
                return {"message": "User already is mapped with provided kvm_username, hence no change were done"}, 200
            return self.update_emp_kvm_user_mapping(user_db_id=user_db_id, kvm_user_name=kvm_user_name)
        except Exception as ex:
            LOG.exception(f"Failed to update user details with error: {ex}")
            return {"message": "Internal server error, Please contact administrator"}, 500

    def get_user_object(self, user_id):
        try:
            LOG.info(f"Fetching user details for id: {user_id}")
            db_result = self._client.execute(fetch_kvm_user_details,
                                             variable_values={"user_db_id": user_id, "org_db_id": self._org_db_id})
            return db_result[ROCC_USERS]
        except Exception as ex:
            LOG.exception(f"Failed to fetch user object with error: {ex}")

    def update_emp_kvm_user_mapping(self, user_db_id, kvm_user_name):
        try:
            LOG.info("Updating kvm_user_name")
            self._client.execute(update_rocc_kvm_employee_user, variable_values={"user_db_id": user_db_id, "kvm_user_name": kvm_user_name})
            self.safe_audit(event_subtype="Update KVM username mapping", action="U", outcome=0, code="Update KVM username mapping", value="Success")
            return {"message": "User details are updated successfully"}, 200
        except Exception as ex:
            LOG.exception(f"Updating a mapping between user and kvm_user failed with error: {ex}")
            self.safe_audit(event_subtype="Update KVM username mapping", action="U", outcome=8, code="Update KVM username mapping", value="Error")
            return {"message": "Internal server error, Please contact administrator"}, 500
