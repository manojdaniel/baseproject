"""
 Created on Fri Oct 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import traceback

from src.constants.constants import ROCC_SITES
from src.constants.headers import EXCEL_HOSPITAL_FRONTDESK_PHONE, EXCEL_HOSPITAL_SCHEDULER_PHONE, EXCEL_HOSPITAL_DISPLAY_NAME, EXCEL_STREET_ADDRESS, EXCEL_HOSPITAL_CITY, \
    EXCEL_HOSPITAL_PROVINCE, EXCEL_HOSPITAL_POSTAL_CODE
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import check_if_site_details_exists
from src.utility.utility import get_str_value
LOG = create_logger("SiteDataValidationService")


def check_if_site_exists(client, site_identifier, site_info):
    try:
        address = site_info[EXCEL_STREET_ADDRESS]
        city = site_info[EXCEL_HOSPITAL_CITY]
        state_or_province = site_info[EXCEL_HOSPITAL_PROVINCE]
        postal_code = get_str_value(site_info[EXCEL_HOSPITAL_POSTAL_CODE])
        frontdesk_no = site_info[EXCEL_HOSPITAL_FRONTDESK_PHONE]
        scheduler_no = site_info[EXCEL_HOSPITAL_SCHEDULER_PHONE]
        name = site_info[EXCEL_HOSPITAL_DISPLAY_NAME]
    except Exception as ex:
        LOG.error("Exception while parsing data from site dict, {}".format(ex))
        LOG.error(traceback.print_exc())
    try:
        response = client.execute(check_if_site_details_exists, variable_values={"address": address,
                                                                                 "city": city,
                                                                                 "state_or_province": state_or_province,
                                                                                 "postal_code": postal_code,
                                                                                 "frontdesk_no": frontdesk_no,
                                                                                 "scheduler_no": scheduler_no,
                                                                                 "site_identifier": site_identifier,
                                                                                 "name": name})
        return check_if_id_is_present(data=response, table_name=ROCC_SITES)
    except Exception as ex:
        LOG.error("Exception while fetching site data for validation, {}".format(ex))
        LOG.error(traceback.print_exc())
