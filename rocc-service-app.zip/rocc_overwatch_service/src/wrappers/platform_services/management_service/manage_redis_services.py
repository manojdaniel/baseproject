"""
 Created on Thu Oct 29 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import json
import os
import requests

from src.constants.constants import CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, PHILIPS_ROCC_URI, VAULT_ROCC_CRED_PATH
from src.loggers.log import create_logger

LOG = create_logger("ROCCRedisServices")


def store_values_in_redis(url, token, customer_name="", org_id=""):
    response_success = False
    error_reasn = ""
    redis_headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    data = {"customerName": customer_name, "orgId": org_id}
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/redismgmt/Redis",
                                 data=json.dumps(data),
                                 headers=redis_headers)
        if response.status_code == 201:
            LOG.info("Root Vault Values successfully stored in Redis")
            response_success = True
        else:
            LOG.error(
                f"Error while storing Vault Values in Redis: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while storing Vault Values in Redis: {ex}")
        error_reasn = f"Error while storing Vault Values in Redis: {repr(ex.args)}"
    return response_success, error_reasn


def load_redis_in_bulk(url, token):
    redis_headers = {AUTHORIZATION: token}
    try:
        response = requests.post(f"{url}{PHILIPS_ROCC_URI}/redismgmt/Redis/bulkCreation",
                                 headers=redis_headers)
        if response.status_code == 201:
            LOG.info("Values successfully stored in Redis")
            return True
        else:
            LOG.error(f"Error while loading Vault Values in Redis: {response}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Error while loading Vault Values in Redis: {ex}")
    return False


def update_key_in_redis_for_org(url, token, org_id, key, value):
    redis_headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    data = [{"redisKey": key, "redisValue": value}]
    try:
        response = requests.put(f"{url}{PHILIPS_ROCC_URI}/redismgmt/Redis/{org_id}",
                                data=json.dumps(data),
                                headers=redis_headers)
        if response.status_code == 200:
            LOG.info(
                f"Customer Vault Values in Redis - Update for key {key} for org {org_id} is successful")
        else:
            LOG.error(
                f"Error while updating customer Vault Values in Redis: {json.dumps(response.json())} for org: {org_id}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(
            f"Error while updating Customer Vault Values in Redis: {ex} for Org : {org_id}")


def delete_values_from_redis(url, token, keys, path):
    redis_headers = {CONTENT_TYPE: APPLICATION_JSON, AUTHORIZATION: token}
    data = {"keys": keys}
    try:
        LOG.info(f"Deleting Keys: {keys} in redis for Path: {path}")
        response = requests.delete(f"{url}{PHILIPS_ROCC_URI}/redismgmt/Redis/{path}",
                                   data=json.dumps(data),
                                   headers=redis_headers)
        if response.status_code == 204:
            LOG.info(f"{keys} deleted from Redis path: {path}")
            return True
        else:
            LOG.error(
                f"Error while deleting values of keys: {keys} in Redis for patg: {path} with error: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.exception(
            f"Error while deleting values of keys: {keys} in Redis for patg: {path} with error: {ex}")
    return False


def delete_org_related_redis_values(url, token, customer_name, org_id):
    """delete redis values for a org"""
    LOG.info(f"Deleting Org details in redis for Org: {customer_name}")
    delete_org_redis_value_status = delete_values_from_redis(url=url,
                                                             token=token,
                                                             keys=[org_id],
                                                             path=customer_name)

    if delete_org_redis_value_status:
        LOG.info(
            f"Deleting customer name from global redis for Org: {customer_name}")
        delete_values_from_redis(url=url,
                                 token=token,
                                 keys=[customer_name],
                                 path=os.environ.get(VAULT_ROCC_CRED_PATH))
