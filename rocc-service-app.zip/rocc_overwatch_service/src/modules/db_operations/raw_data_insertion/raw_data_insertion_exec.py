"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.constants.constants import OBJECTS, CUSTOMER_NAME, ROCC_OVERWATCH_CUSTOMERS, RETURNING, ROCC_OVERWATCH_RAW_UPLOAD_DATA, TEMPLATE_VERSION_1_0_0
from src.exceptions.RoccException import RoccException
from src.wrappers.graphql.mutations.mutations import insert_rocc_overwatch_customers_raw_data, insert_rocc_overwatch_customers
from src.loggers.log import create_logger
from src.wrappers.graphql.queries.queries import check_if_customer_exists_in_db
from src.modules.db_operations.db_utility.graphql_response_parser import extract_data_from_table
from src.utility.semver import parse_version

LOG = create_logger("Raw data insertion exec")


def check_if_customer_exists(client, customer_identifier, service_user_uuid):
    db_result = client.execute(check_if_customer_exists_in_db, variable_values={CUSTOMER_NAME: customer_identifier})
    data = extract_data_from_table(db_result, ROCC_OVERWATCH_CUSTOMERS)
    if len(data) == 0:
        table_name = f"insert_{ROCC_OVERWATCH_CUSTOMERS}"
        new_list = {"name": customer_identifier, "status": "INIT", "created_by": service_user_uuid, "modified_by": service_user_uuid}
        variables = {OBJECTS: new_list}
        customer_result = client.execute(insert_rocc_overwatch_customers, variable_values=variables)
        result_id = customer_result[table_name][RETURNING][0]["id"]
        LOG.info(f"Customer Identifier has been added to DB, {result_id}")
        return customer_result[table_name][RETURNING][0]["id"]
    data_id = data[0]["id"]
    LOG.info(f"Customer Identifier exists in DB, {data_id}")
    return data[0]["id"]


def insert_existing_customer_information(client, customer_identifier, data_dict, service_user_uuid, template_version_from_excel=parse_version(TEMPLATE_VERSION_1_0_0)):
    try:
        customer_id = check_if_customer_exists(client=client, customer_identifier=customer_identifier, service_user_uuid=service_user_uuid)
        new_list = {"customer_id": customer_id, "data": data_dict, "template_version": str(template_version_from_excel)}
        table_name = f"insert_{ROCC_OVERWATCH_RAW_UPLOAD_DATA}"
        variables = {OBJECTS: new_list}
        db_result = client.execute(insert_rocc_overwatch_customers_raw_data, variable_values=variables)
        identifier = db_result[table_name][RETURNING][0]["id"]
        LOG.info(f"Raw file data uploaded successfully, file identifier is, {identifier}")
        return db_result[table_name][RETURNING][0]["id"]
    except Exception as ex:
        LOG.exception(f"Failed to insert overwatch customer with error: {ex}")
        raise RoccException(title="Customer data insertion failed", payload="Could not parse the customer data while inserting excel data") from ex
