// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
    getmasterdatareporttable,
} from "../../../../redux/reducers/CommonReducer";
import MasterDataReportTable from "table/MasterDataReportTable";
import { encryptRSAData } from "../../../../utility/rsa";
// calendar============start
import ReportCalendarPopup from "../../../../components/ReportCalendarPopup/ReportCalendarPopup";
import useOnClickOutside from "../../../../hooks/useOnClickOutside";
import moment from 'moment';
import iconCalendar from "../../../../assets/images/icon_calendar.svg";
import '../AlertManagementPage.scss';

interface Props {
    buttonName: string;
    onClickHandler: any;
}
const Master = () => {

    // From Date To Date Start====
    const [commonMasterReportFromDateFormat, setcommonMasterReportFromDateFormat] = useState<any>();
    const [commonMasterReportToDateFormat, setcommonMasterReportToDateFormat] = useState<any>();
    const [commonMasterReportFromDate, setcommonMasterReportFromDate] = useState<any>();
    const [commonMasterReportToDate, setcommonMasterReportToDate] = useState<any>();
    const [showPickerMaster, setShowPickerMaster] = useState(false);
    // From Date to Date End=====

    let dispatch = useDispatch();
    const { masterdatareporttable, loadingmasterdatareporttable } = useSelector((state: any) => ({
        masterdatareporttable: state.Common.masterdatareporttable,
        loadingmasterdatareporttable: state.Common.loadingmasterdatareporttable,
    }));

    const showMasterTable = () => {
        dispatch(getmasterdatareporttable(encryptRSAData(`fromDate=${commonMasterReportFromDateFormat}&toDate=${commonMasterReportToDateFormat}`)));
    }

    const clearAllmasterFields = () => {
        setcommonMasterReportFromDateFormat("");
        setcommonMasterReportToDateFormat("");
        setcommonMasterReportFromDate("");
        setcommonMasterReportToDate("");
    }

    // Report Date Start======================
    const ref = useRef(null);
    useOnClickOutside(ref, () => setShowPickerMaster(false));

    const handleMasterReportFromDate = (date: any) => {
        setcommonMasterReportFromDate(date);
        let upatedDate = moment(date).format("YYYY-MM-DD");
        setcommonMasterReportFromDateFormat(upatedDate);
    }
    const handleMasterReportToDate = (date: any) => {
        setcommonMasterReportToDate(date);
        let upatedDate = moment(date).format("YYYY-MM-DD");
        setcommonMasterReportToDateFormat(upatedDate);
    }
    // Report Date End======================
    const handleClickMastermyReport = () => {
        document.getElementById("handleClickMasterReport").click();
    }

    return (
        <div id="utilizationreport">
            <div className="common-box-inner">
                <div className="common-box-filter">
                    <div className="title"> AHC MASTER DATA REPORT </div>
                </div>
                <div className="utilization-filter">
                    <div>
                        <label>SET DATE</label>
                        {/* Report Date Start component====================== */}
                        <div id="ReportCalendar" ref={ref}>
                            <input type="text" value={`${commonMasterReportFromDateFormat !== undefined ? commonMasterReportFromDateFormat : ""} ${commonMasterReportToDateFormat !== undefined ? commonMasterReportToDateFormat : ""}`} style={{ float: "left" }} />
                            <a className="mobile-calendar" onClick={() => setShowPickerMaster(!showPickerMaster)}><img src={iconCalendar} title="calendar" style={{ float: "left" }} /></a>
                            {showPickerMaster ? <ReportCalendarPopup
                                commonReportFromDateFormat={commonMasterReportFromDateFormat}
                                commonReportToDateFormat={commonMasterReportToDateFormat}
                                commonReportFromDate={commonMasterReportFromDate}
                                commonReportToDate={commonMasterReportToDate}
                                handleReportFromDate={handleMasterReportFromDate}
                                handleReportToDate={handleMasterReportToDate}
                            /> : null}
                        </div>
                        {/* Report Date End component====================== */}
                    </div>
                    <div className="report-btns">
                        <button onClick={handleClickMastermyReport}>EXPORT TO EXCEL</button>
                        <button onClick={showMasterTable}>SUBMIT </button>
                        <button onClick={clearAllmasterFields}>CLEAR </button>
                    </div>


                </div>
                <div className="common-box-content">
                    <MasterDataReportTable
                        data={masterdatareporttable}
                        loading={loadingmasterdatareporttable}
                    />
                </div>
            </div>
        </div>
    );
};
export default Master;