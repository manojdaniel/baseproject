import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import GlobalPreviewMap from "./GlobalPreviewMap";
import { MapContainer, CircleMarker } from "react-leaflet";

jest.mock("react-leaflet", () => ({
	MapContainer: jest.fn(({ children }) => <div>{children}</div>),
	TileLayer: jest.fn(() => <div />),
	LayerGroup: jest.fn(({ children }) => <div>{children}</div>),
	Circle: jest.fn(() => <div />),
	Tooltip: jest.fn(() => <div />),
	SVGOverlay: jest.fn(() => <div />),
	CircleMarker: jest.fn(() => <div />),
}));
jest.mock("react-leaflet", () => ({
	MapContainer: jest.fn(),
	CircleMarker: jest.fn(),
}));

describe("GlobalPreviewMap component", () => {
	const mockRegionData = [
		{
			affiliateCount: 5,
			regionId: "1",
			name: "region 1",
			abrv: "R1",
			latitude: 10,
			longitude: 20,
		},
		{
			affiliateCount: 10,
			regionId: "2",
			name: "region 2",
			abrv: "R2",
			latitude: 30,
			longitude: 40,
		},
	];
	describe("GlobalPreviewMap", () => {
		beforeEach(() => {
			MapContainer.mockReturnValue(<div />);
			CircleMarker.mockReturnValue(<div />);
		});

		afterEach(() => {
			jest.clearAllMocks();
		});

		it("renders without crashing", () => {
			render(
				<GlobalPreviewMap setGetSelectedRegion={undefined} regionData={[]} />
			);
		});
	});

	it("should render map with correct props", () => {
		render(
			<GlobalPreviewMap
				setGetSelectedRegion={() => {}}
				regionData={mockRegionData}
			/>
		);
		expect(MapContainer).toHaveBeenCalledWith({
			center: [51.505, 35.09],
			zoom: 2,
			scrollWheelZoom: false,
			style: { width: "100%", height: "100%" },
		});
	});

	it("should render circles and tooltips for each region with correct props", () => {
		const { getAllByTestId } = render(
			<GlobalPreviewMap
				setGetSelectedRegion={() => {}}
				regionData={mockRegionData}
			/>
		);
		const circles = getAllByTestId("circle");
		const tooltips = getAllByTestId("tooltip");

		expect(circles).toHaveLength(mockRegionData.length);
		expect(tooltips).toHaveLength(mockRegionData.length);

		circles.forEach((circle, index) => {
			expect(circle).toHaveAttribute("radius", expect.any(String));
			expect(circle).toHaveAttribute("weight", expect.any(String));
			expect(circle).toHaveAttribute("opacity", "0.6");
			expect(circle).toHaveAttribute("fillOpacity", "0");
			expect(circle).toHaveAttribute("pathOptions.color", "#009fdf");
			expect(circle).toHaveAttribute("pathOptions.fillColor", "#009fdf");
			expect(circle).toHaveAttribute(
				"pathOptions.onClick",
				expect.any(Function)
			);
			expect(circle).toHaveAttribute("pathOptions.radius", expect.any(String));
			expect(circle).toHaveAttribute("pathOptions.weight", expect.any(String));

			const { latitude, longitude } = mockRegionData[index];
			expect(circle).toHaveAttribute("center", `[${latitude},${longitude}]`);
			expect(circle).toHaveAttribute(
				"pathOptions.pathOptions.pathOptions",
				expect.any(Object)
			);

			const tooltip = tooltips[index];
			expect(tooltip).toHaveTextContent(
				mockRegionData[index].name.toUpperCase()
			);
		});
	});
});
