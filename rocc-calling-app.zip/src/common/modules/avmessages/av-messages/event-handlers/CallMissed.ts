/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { Dispatch } from "redux"
import { storeCallDetailsInRedux } from "../MessageHelper"
import { TRACKING_VALUES } from "../types"
import { ECallStatus } from "@rocc/rocc-client-services"
import store from "../../../../../redux/store/store"
import { filterCallStatusByContextIdAndStatus } from "../../../../helpers/callUtility"
import { getContextDetails } from "../../messageService"
import { HTTP_STATUS } from "../../../../../constants/constants"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"

const { CONNECTED } = ECallStatus

interface ICallMissed {
    contextId: string
    dispatch: Dispatch<any>
}

export const callMissed = async (props: ICallMissed) => {
    const { contextId, dispatch } = props
    const { currentUser, urls, videoCallStatus, connectedCallDetails, incomingCall, outgoingCall } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES

    const postTrackingMessage = () => {
        if (incomingCall.contextId === contextId) {
            const { participant } = incomingCall
            sendLogsToAzure({ contextData: { component, event: `${event} Call Missed`, Call_From: participant.uuid, Call_To: currentUser.uuid, contextId } })
        } else {
            if (outgoingCall.contextId === contextId) {
                const { participant } = outgoingCall
                sendLogsToAzure({ contextData: { component, event: `${event} Call Not Answered`, Call_From: currentUser.uuid, Call_To: participant.uuid, contextId } })
            }
        }
    }

    /*  Check if user is already on call */
    if (!filterCallStatusByContextIdAndStatus(videoCallStatus, contextId, [CONNECTED], true).length) {
        postTrackingMessage()
        const contextDetails = await getContextDetails(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL)
        if (contextDetails && contextDetails.status === HTTP_STATUS.OK) {
            const { data } = contextDetails
            /*  Display Call Message To User */
            if (connectedCallDetails.contextId === contextId) {
                data.contextId = contextId
                data.numOfParticipants = connectedCallDetails.numOfParticipants
                storeCallDetailsInRedux(data, dispatch)
            }
        }
    }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const urls = fetchGlobalURLs()
    const { currentUser } = state.externalReducer
    const { videoCallStatus } = state.callReducer
    const { connectedCallDetails, incomingCall, outgoingCall } = state.callReducer.callDetails
    return { currentUser, urls, videoCallStatus, connectedCallDetails, incomingCall, outgoingCall }
}
