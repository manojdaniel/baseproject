import React, { useRef, useEffect, useState } from "react";
import AssetCard from "table/AssetCard";
import PlantAlertList from "table/PlantAlertList";
import ReliablityHeatMap from "charts/ReliablityHeatMap";
import { useDispatch, useSelector } from "react-redux";
import Dropdown from "components/Dropdown";
import "../../../assets/common/PmtDashboard.scss";
import {
	getRegions,
	getAssetListByPlantId,
	getPlantAlertSpmt,
	getAssetCardPmtByPlantId,
	getAssetCardPmtByAssetId,
	getAssetStatusPmtByPlantId,
	getStatusAssetPmtByPlantId,
	getssetStatusListbyPlantId,
	getHeatMapToolTipbyAssetStatus,
	getTopBarToolTipbyPlantId,
	getGlobalSelecetedAsset,
	getHeatMapToolTipbyAssetStatusEmpty,
	setRefreshPmtPage,
} from "../../../redux/reducers/CommonReducer";
import { useNavigate } from "react-router-dom";
import Loader from "components/Loader";
import Workflow from "../AlertManagementPage/Workflow";
import { Outlet, useLocation } from "react-router-dom";
import { encryptRSAData } from "../../../utility/rsa";

const PmtDashboard = () => {
	let navigate = useNavigate();
	let dispatch = useDispatch();
	const location = useLocation();
	const {
		assetListByPlant,
		plantAlertSpmt,
		assetCardPmtByplantId,
		assetCardPmtByAssetId,
		assetStatusPmtByPlantId,
		statusAssetPmtByPlantId,
		setStatusListbyPlantId,
		heatMapToolTipbyAssetStatus,
		topBarToolTipbyPlantId,
		searchValue,
		globalSelecetedPlant,
		loadingAssetCardPmtByplantId,
		loadingAssetCardPmtByAssetId,
		loadingHeatMapToolTipbyAssetStatus,
		refreshPmtPage,
		userId,
		loadingplantAlertSpmt,
	} = useSelector((state: any) => ({
		assetListByPlant: state.Common.assetListByPlant,
		plantAlertSpmt: state.Common.plantAlertSpmt,
		assetCardPmtByplantId: state.Common.assetCardPmtByplantId,
		assetCardPmtByAssetId: state.Common.assetCardPmtByAssetId,
		assetStatusPmtByPlantId: state.Common.assetStatusPmtByPlantId,
		statusAssetPmtByPlantId: state.Common.statusAssetPmtByPlantId,
		setStatusListbyPlantId: state.Common.setStatusListbyPlantId,
		heatMapToolTipbyAssetStatus: state.Common.heatMapToolTipbyAssetStatus,
		topBarToolTipbyPlantId: state.Common.topBarToolTipbyPlantId,
		searchValue: state.Common.searchValue,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		loadingAssetCardPmtByplantId: state.Common.loadingAssetCardPmtByplantId,
		loadingAssetCardPmtByAssetId: state.Common.loadingAssetCardPmtByAssetId,
		loadingHeatMapToolTipbyAssetStatus:
			state.Common.loadingHeatMapToolTipbyAssetStatus,
		refreshPmtPage: state.Common.refreshPmtPage,
		userId: state.Common.userId,
		loadingplantAlertSpmt: state.Common.loadingplantAlertSpmt,
	}));

	const [showWorkflow, setShowWorkflow] = useState<boolean>(false);
	const [workflowAlertId, setWorkflowAlertId] = useState<any>("");
	const [assetIdDropList, setAssetIdDropList] = useState<any>();
	const [selectedAssetId, setSelectedAssetId] = useState<any>("");
	const [assetIdDropList1, setAssetIdDropList1] = useState<any>();
	const [selectedAssetId1, setSelectedAssetId1] = useState<any>("");
	const [heatStatusList, setHeatStatusList] = useState<any>();
	const [selectedHeatStatus, setSelectedHeatStatus] = useState<any>("All");
	const [heatMapData, setheatMapData] = useState({
		assetOff: "",
		warning: "",
		normal: "",
		assetUnderRisk: "",
	});
	const [getErrorMag, setErrorMag] = useState(false);
	const [selectedPlantLabel, setSelectedPlantLabel] = useState<any>(
		globalSelecetedPlant.label
	);

	const [mouseHover, setMouseHover] = useState({
		over: false,
		statusName: "",
	});

	useEffect(() => {
		if (Object.keys(globalSelecetedPlant).length > 0) {
			/**
			 * Top Bar Status
			 */
			dispatch(
				getStatusAssetPmtByPlantId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			);
			/**
			 * Asset DropdownencryptRSAData(`assetId=
			 */
			dispatch(
				getAssetListByPlantId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //Asset dropdown
			/**
			 * Top Bar Tool Tip
			 */
			dispatch(
				getTopBarToolTipbyPlantId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			);
			/**
			 * Plant  Alert List Table
			 */
			dispatch(
				getPlantAlertSpmt(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			);
			/**
			 * Asset card by Plant ID
			 */
			dispatch(
				getAssetCardPmtByPlantId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			);
			/**
			 * Heat Map Status Data
			 */
			dispatch(
				getAssetStatusPmtByPlantId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			);
		}
	}, [globalSelecetedPlant]);

	useEffect(() => {
		let data = assetListByPlant.map(function (item: any) {
			return { value: item.assetId, label: item.assetName };
		});
		setAssetIdDropList(data);

		let data1 = assetListByPlant.map(function (item: any) {
			return { value: item.assetId, label: item.assetId };
		});
		setAssetIdDropList1(data1);
	}, [assetListByPlant]);

	useEffect(() => {
		let data = setStatusListbyPlantId.map(function (item: any, index: number) {
			return { value: item.status, label: item.status };
		});
		setHeatStatusList(data);
	}, [setStatusListbyPlantId]);

	useEffect(() => {
		if (assetStatusPmtByPlantId.length > 0)
			setheatMapData({
				...heatMapData,
				assetOff: assetStatusPmtByPlantId.find(
					(item: any) => item.title === "Asset-off"
				),
				warning: assetStatusPmtByPlantId.find(
					(item: any) => item.title === "Warning"
				),
				normal: assetStatusPmtByPlantId.find(
					(item: any) => item.title === "Normal"
				),
				assetUnderRisk: assetStatusPmtByPlantId.find(
					(item: any) => item.title === "Asset_Under_Risk"
				),
			});
	}, [assetStatusPmtByPlantId]);

	useEffect(() => {
		if (mouseHover.over) {
			dispatch(
				getHeatMapToolTipbyAssetStatus(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetStatus=${mouseHover.statusName}`
					)
				)
			);
		}
		try {
			if (!mouseHover) {
				dispatch(getHeatMapToolTipbyAssetStatusEmpty(encryptRSAData("")));
			}
		} catch (error) { }
	}, [mouseHover.over, mouseHover.statusName]);

	const handleAssetIdDropChange = (e: any) => {
		setSelectedAssetId(e);
		setSelectedAssetId1({ label: e.value, value: e.value });
		/**
		 * Asset card by Asset ID
		 */
		dispatch(
			getAssetCardPmtByAssetId(
				encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`)
			)
		); //selectedAssetId.value
		setErrorMag(false);
	};

	const handleAssetIdDropChange1 = (e: any) => {
		try {
			let filtervalue = assetListByPlant.filter(
				(item: any) => item.assetId === e.value
			);
			setSelectedAssetId({ label: filtervalue[0].assetName, value: e.value });
			setSelectedAssetId1(e);
			/**
			 * Asset card by Asset ID
			 */
			dispatch(
				getAssetCardPmtByAssetId(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`)
				)
			); //selectedAssetId.value
			setErrorMag(false);
		} catch (error) { }
	};

	const handleHeatStatusDropChange = (e: any) => {
		setSelectedHeatStatus(e.value);
	};

	let handleNavigation = (select: any) => {
		if (select === "") {
			setErrorMag(true);
		}
		if (select !== "") {
			setErrorMag(false);
			dispatch(
				getGlobalSelecetedAsset({ value: select.value, label: select.value })
			);
			navigate("/assets/assetModel");
		}
	};

	const handleHeatMapNavigation = (assetId: any) => {
		if (assetId !== "") {
			dispatch(getGlobalSelecetedAsset({ value: assetId, label: assetId }));
			navigate("/assets/assetModel");
		}
	};

	const handleUpdate = (action, assetId, alertId) => {
		if (action === "viewAlert") {
			dispatch(getGlobalSelecetedAsset({ value: assetId, label: assetId }));
			navigate(`/assets/alertList`, { state: { alertId: alertId } });
		} else if (action === "takeAction") {
			setShowWorkflow(true);
			navigate(`/plant/pmt/workFlow`, {
				state: { alertId: alertId, currentStage: "", pageName: "pmt" },
			});
		} else if (action === "viewPlot") {
			dispatch(getGlobalSelecetedAsset({ value: assetId, label: assetId }));
			navigate(`/assets/plots`);
		}
	};

	useEffect(() => {
		try {
			if (
				location.pathname === "/plant/pmt" ||
				location.pathname === "/plant"
			) {
				setShowWorkflow(false);
				if (refreshPmtPage) {
					/**
					 * Plant  Alert List Table
					 */
					dispatch(
						getPlantAlertSpmt(
							encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
						)
					);
					dispatch(setRefreshPmtPage(false));
				}
			}
		} catch (error) { }
	}, [location]);

	return (
		<>
			{showWorkflow ? (
				<>
					<Outlet />
				</>
			) : (
				<div id="pmt-boxx">
					<div id="pmt-left">
						<div id="pmt-asset-card">
							<div className="pmt-padding">
								<div id="pmtf-status">
									<div className="pmtf-left">
										<div className="title">ASSET CARD</div>
										<div className="pmt-asset-name options-padding">
											{selectedAssetId === ""
												? selectedPlantLabel
												: selectedAssetId.label}
										</div>
									</div>
									<div className="pmtf-right">
										<div className="pmt-fills">
											<div className="pmt-error">
												{getErrorMag === true ? (
													<span className="PmtErrorMsg">
														Need to select AssetID
													</span>
												) : (
													""
												)}
											</div>
											<div className="pmt-time">
												<span className="cus-label">Asset ID</span>
												<Dropdown
													name={"Asset Id"}
													options={assetIdDropList1}
													value={selectedAssetId1}
													multi={true}
													handleChange={handleAssetIdDropChange1}
													defaultValue={""}
												/>
											</div>
											<div className="pmt-options">
												<span className="cus-label">Asset Name</span>
												<Dropdown
													name={"Asset Name"}
													options={assetIdDropList}
													value={selectedAssetId}
													handleChange={handleAssetIdDropChange}
													defaultValue={""}
												/>
											</div>
											<div
												className="pmt-gobtn"
												onClick={() => handleNavigation(selectedAssetId)}
											>
												Go
											</div>
										</div>
									</div>
								</div>
								{loadingAssetCardPmtByplantId ||
									loadingAssetCardPmtByAssetId ? (
										<div className="tc-loaderpd-150"><Loader /></div>
								) : (
									<>
										<AssetCard
											data={
												selectedAssetId === ""
													? assetCardPmtByplantId
													: assetCardPmtByAssetId
											}
										/>
									</>
								)}
							</div>
						</div>
						{loadingplantAlertSpmt ? 
						( <div className="tc-loaderpd-150"><Loader /></div> ) : 
						(
						<PlantAlertList
							plantName={selectedPlantLabel}
							data={plantAlertSpmt}
							handleUpdate={handleUpdate}
							userId={userId}
						/>
						)
						}
					</div>
					<div id="pmt-right">
						<div className="pmt-right-box">
							<div className="title">RELIABILITY HEAT MAP</div>
							<div className="pmt-right-name">
								Click on the map to get more details
							</div>

							{/* HAVE TO REMOVE THE FUNCTIONALITY OF THE DROPDOWN as per SABIC INSTRUCTION */}

							<div className="pmt-right-dropdown" style={{ display: "none" }}>
								<Dropdown
									options={heatStatusList}
									defaultValue={{ label: "All", value: "All" }}
									handleChange={handleHeatStatusDropChange}
								/>
							</div>
							{/* {loadingHeatMapToolTipbyAssetStatus ? 
							( <div className="tc-loaderpd"><Loader /></div> ) : 
							( */}
							<ReliablityHeatMap
								statusData={heatMapData}
								toolTipData={heatMapToolTipbyAssetStatus}
								selectedHeatStatus={selectedHeatStatus}
								setMouseHover={setMouseHover}
								mouseHover={mouseHover}
								handleHeatMapNavigation={handleHeatMapNavigation}
								loading={loadingHeatMapToolTipbyAssetStatus}
							/>
							{/* )} */}
						</div>
					</div>
				</div>
			)}
		</>
	);
};
export default PmtDashboard;
