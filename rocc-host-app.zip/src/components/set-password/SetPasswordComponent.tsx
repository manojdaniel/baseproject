/*
 * Created on Tue May 24 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */
import { ISetPasswordWrapper, SetPassword } from "@rocc/rocc-authentication-components"
import React from "react"
import { getFullApplicationName } from "../../utility/helpers/helpers"
import { setPasswordService } from "../../services/authentication/AuthenticationService"
import { EPdType } from "@rocc/rocc-client-services"
import queryString from "query-string"
import { LOGIN_ROUTE } from "../../constants/routes"

const TEXT = {
    recoverPd: "recoverPassword",
    createUser: "userCreate"
}

interface ISetPassword {
    type: EPdType
}

const SetPasswordComponent = (props: ISetPassword) => {
    const { type } = props
    const setPasswordHanlder = async (props: ISetPasswordWrapper) => {
        const { email, password } = props
        const confirmationCode = queryString.parse(window.location.hash)
        const code = confirmationCode[Object.keys(confirmationCode)[0]]
        const context = type === EPdType.RESET_PD ? TEXT.recoverPd : TEXT.createUser
        const response = await setPasswordService(email, password, code, context)
        return response
    }
    const redirectToLogin = () => {
        window.location.hash = LOGIN_ROUTE
    }
    return (
        <SetPassword setPasswordHandler={setPasswordHanlder} applicationName={getFullApplicationName()} type={type} redirectToLogin={redirectToLogin} />
    )
}
export default SetPasswordComponent
