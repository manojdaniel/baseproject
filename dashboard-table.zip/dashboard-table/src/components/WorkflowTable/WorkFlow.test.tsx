import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import WorkflowTable from "./index";

jest.mock("antd", () => {
	const mockTable = jest.fn(({ columns, dataSource, rowSelection }) => (
		<div>
			<table>
				<thead>
					<tr>
						{columns.map((column, index) => (
							<th key={index}>{column.title}</th>
						))}
					</tr>
				</thead>
				<tbody>
					{dataSource.map((data, index) => (
						<tr key={index}>
							{columns.map((column, columnIndex) => (
								<td key={columnIndex}>{data[column.dataIndex]}</td>
							))}
						</tr>
					))}
				</tbody>
			</table>
			<button
				onClick={() =>
					rowSelection.onChange([dataSource[0].UserID], [dataSource[0]])
				}
			>
				Select Row
			</button>
		</div>
	));

	return {
		...jest.requireActual("antd"),
		Table: mockTable,
	};
});

describe("WorkflowTable", () => {
	const mockHandleUpdate = jest.fn();

	const testData = [
		{ UserID: 34, MailID: "bhanum@sabic.com" },
		{ UserID: 30757062, MailID: "mah@sabic.com" },
	];

	beforeEach(() => {
		render(<WorkflowTable data={testData} handleUpdate={mockHandleUpdate} />);
	});
	//   test('renders without crashing', () => {
	//     expect(screen.getByRole('button', { name: 'Select Row' })).toBeInTheDocument();
	//   });
	// });
	test("renders table headers correctly", () => {
		expect(screen.getByText("UserID")).toBeInTheDocument();
		expect(screen.getByText("MailID")).toBeInTheDocument();
	});

	test("renders table rows correctly", () => {
		testData.forEach((item) => {
			expect(screen.getByText(item.UserID.toString())).toBeInTheDocument();
			expect(screen.getByText(item.MailID)).toBeInTheDocument();
		});
	});

	test("calls handleUpdate when a row is selected", () => {
		const selectRowButton = screen.getByText("Select Row");
		fireEvent.click(selectRowButton);

		expect(mockHandleUpdate).toHaveBeenCalledTimes(1);
		expect(mockHandleUpdate).toHaveBeenCalledWith(
			testData[0].UserID,
			testData[0].MailID
		);
	});
});
