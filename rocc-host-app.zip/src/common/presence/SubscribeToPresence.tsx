/*
 * Created on The Oct 19 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { EClinicalRole, EConnectionStatus, IParentStore, parseIntBase10 } from "@rocc/rocc-client-services"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { SyncClient } from "twilio-sync"
import { verifyCurrentUserPresence } from "../../redux/actions/clientStatusActions"
import { getTechnologistName, updateAllRoomPresence } from "../../redux/actions/customerActions"
import { updateAllContactsPresence } from "../../redux/actions/userAction"
import { errorLogger, infoLogger, warningLogger } from "@rocc/rocc-logging-module"
import { IPresenceMap, IPresenceUpdate } from "./types"

const FILENAME = "SubscribeToPresence :"
interface ISubscribeToPresence {
    subjects: IPresenceMap[]
    updateSubscribedState: (subjects: IPresenceMap[]) => void
    syncClient: SyncClient
}
export const SubscribeToPresence = (props: ISubscribeToPresence) => {
    const { currentUser, contacts, rooms, configs, applicationConnectionState, } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        contacts: state.userReducer.contacts,
        contactsFetched: state.userReducer.contactsFetched,
        rooms: state.customerReducer.rooms,
        configs: state.configReducer.configs,
        applicationConnectionState: state.clientStatusReducer.applicationConnectionState,
    }))
    const dispatch = useDispatch()
    const timeoutId: any = useRef(undefined as unknown as NodeJS.Timeout)
    const roomsRef = useRef(rooms)
    const contactsRef = useRef(contacts)
    const prevApplicationConnectionState = useRef(EConnectionStatus.ONLINE)
    const [presenceUpdate, setPresenceUpdate] = useState({ userPresence: [], roomPresence: [] } as IPresenceUpdate)
    const presenceUpdateRef = useRef(presenceUpdate)

    const triggerFunction = async () => {
        const { roomPresence, userPresence } = presenceUpdateRef.current
        await Promise.all(roomPresence.map(async (roomDetails: any) => {
            const roomIndex = roomsRef.current.findIndex(room => room.identity.uuid === roomDetails.subjectUuid)
            if (roomIndex > -1) {
                const loggedInTech = await fetchLoggedInTechInfo(roomDetails.data.loggedInTech)
                roomsRef.current[roomIndex] = { ...roomsRef.current[roomIndex], presenceData: { ...roomsRef.current[roomIndex].presenceData, presence: roomDetails.data.presence }, loggedInTech }
            }
        }))
        userPresence.forEach(async (userDetails: any) => {
            const userIndex = contactsRef.current.findIndex(contact => contact.uuid === userDetails.subjectUuid)
            if (userIndex > -1) {
                contactsRef.current[userIndex] = { ...contactsRef.current[userIndex], status: userDetails.data.presence, loggedInLocation: userDetails.data.loggedInLocation }
            }
        })
        Promise.resolve([])

        dispatch(updateAllContactsPresence([...contactsRef.current]))
        dispatch(updateAllRoomPresence([...roomsRef.current]))
        setPresenceUpdate({ userPresence: [], roomPresence: [] })
        timeoutId.current = undefined as unknown as NodeJS.Timeout
    }
    const updateCameraPresence = async (subjectUuid: string, cameraAvailable: boolean) => {
        const roomIndex = roomsRef.current.findIndex(room => room.identity.uuid === subjectUuid)
        if (roomIndex > -1 && (rooms[roomIndex].cameraAvailable !== cameraAvailable)) {
            roomsRef.current[roomIndex] = { ...roomsRef.current[roomIndex], cameraAvailable: cameraAvailable }
            dispatch(updateAllRoomPresence([...roomsRef.current]))
        }
        Promise.resolve([])
    }
    const createOrUpdatePresenceMap = () => {
        const { subscribedSubjects, unsubscribedSubjects } = splitSubjects()
        infoLogger(`SubscribedSubjects : ${subscribedSubjects.length}`)
        if (unsubscribedSubjects.length) {
            let errorMsgs: string[] = []
            let warningMsgs: string[] = []
            unsubscribedSubjects.forEach(async (subject: IPresenceMap) => {
                const obj = await createPresenceMap(subject, true, errorMsgs, warningMsgs)
                errorMsgs = obj.errorMsgs
                warningMsgs = obj.warningMsgs
            })
            dispatch(updateAllContactsPresence([...contacts]))
            dispatch(updateAllRoomPresence([...rooms]))
            logErrors(errorMsgs, warningMsgs)
        }
    }
    const createPresenceMap = async (subject: IPresenceMap, initiate: boolean, errorMsgs: string[], warningMsgs: string[]) => {
        try {
            const map = await props.syncClient.map(subject.syncMapId)
            if (initiate) {
                warningMsgs = await updateInitialPresence(map, subject, warningMsgs)
            }
            map.on("itemAdded", (item: any) => itemUpdated(item, subject))
            map.on("itemUpdated", (item: any) => itemUpdated(item, subject))
            map.on("itemRemoved", () => itemRemoved(subject))
            subject.subscribed = true
        } catch (error) {
            if (subject.syncMapId) {
                errorMsgs.push(`${FILENAME} Monitoring Presence: for Subjects: ${subject.uuid} : ${error}`)
            } else {
                /** Setting Subject subscribed status as true, since mapId doesn't exist */
                subject.subscribed = true
                warningMsgs.push(`${FILENAME} Skipping Presence for Contacts that do not have Map created: ${subject.uuid}`)
            }
        }
        return { errorMsgs, warningMsgs }
    }
    const itemUpdated = async (item: any, subject: IPresenceMap) => {
        const data = extractPresenceValue(item, subject)
        if (data?.presence) {
            const updatedPresence = { ...presenceUpdateRef.current }
            if (subject.type === EClinicalRole.DEVICE) {
                updatedPresence.roomPresence = [...updatedPresence.roomPresence.filter(room => room.subjectUuid !== subject.uuid).concat({ subjectUuid: subject.uuid, data })]
                updateCameraPresence(subject.uuid, data.cameraAvailable === undefined ? true : data.cameraAvailable)
            } else {
                updatedPresence.userPresence = [...updatedPresence.userPresence.filter(user => user.subjectUuid !== subject.uuid).concat({ subjectUuid: subject.uuid, data })]
            }
            setPresenceUpdate({ ...updatedPresence })
        }
    }
    const extractPresenceValue = (data: any, subject: IPresenceMap) => {
        if (data.item.descriptor.key === currentUser.uuid) {
            if (data.item.descriptor.data.presence !== currentUser.status) {
                dispatch(verifyCurrentUserPresence(data.item.descriptor.data.presence))
            }
        } else if (data.item.descriptor.key === subject.uuid) {
            const { presence, loggedInTech, cameraAvailable, loggedInLocation } = data.item.descriptor.data
            return { presence, loggedInTech, cameraAvailable, loggedInLocation }
        }
        return null
    }
    const itemRemoved = (subject: IPresenceMap) => {
        updatePresence(subject, EUserPresence.OFFLINE)
    }
    const updatePresence = async (subject: IPresenceMap, presence: EUserPresence, loggedInTech: string = "", cameraAvailable: boolean | undefined = undefined, loggedInLocation = "") => {
        if (subject.type === EClinicalRole.DEVICE) {
            const roomIndex = roomsRef.current.findIndex((room) => room.identity.uuid === subject.uuid)
            if (roomIndex > -1) {
                roomsRef.current[roomIndex].presenceData.presence = presence
                roomsRef.current[roomIndex].loggedInTech = {
                    techUuid: loggedInTech,
                    techName: await getTechnologistName(contactsRef.current, loggedInTech)
                }
                roomsRef.current[roomIndex].cameraAvailable = cameraAvailable
            }
        }
        else {
            const contactIndex = contactsRef.current.findIndex((contact) => contact.uuid === subject.uuid)
            if (contactIndex > -1) {
                contactsRef.current[contactIndex].status = presence
                if (presence == EUserPresence.OFFLINE || !loggedInLocation) {
                    contactsRef.current[contactIndex].loggedInLocation = ""
                } else {
                    contactsRef.current[contactIndex].loggedInLocation = loggedInLocation
                }
            }
        }
    }
    const updateInitialPresence = async (map: any, subject: IPresenceMap, warningMsgs: string[]) => {
        try {
            const item = await map.get(subject.uuid)
            const { presence, loggedInTech, cameraAvailable, loggedInLocation } = item.descriptor.data
            updatePresence(subject, presence, loggedInTech, cameraAvailable, loggedInLocation)
        } catch (error) {
            warningMsgs.push(`${FILENAME} Skipping Presence for subject that do not have an entry in the Map : ${subject.uuid} : ${error}`)
        }
        return warningMsgs
    }
    const splitSubjects = () => {
        const subscribedSubjects: IPresenceMap[] = []
        const unsubscribedSubjects: IPresenceMap[] = []
        for (const subject of props.subjects) {
            if (subject.uuid && subject.subscribed) {
                subscribedSubjects.push(subject)
            } else {
                unsubscribedSubjects.push(subject)
            }
        }
        return { subscribedSubjects, unsubscribedSubjects }
    }
    const logErrors = (errorMsgs: string[], warningMsgs: string[]) => {
        if (errorMsgs.length > 0) {
            errorLogger(`${FILENAME} ${errorMsgs.toString()}`)
        }
        if (warningMsgs.length > 0) {
            warningLogger(`${FILENAME} ${warningMsgs.toString()}`)
        }
    }
    const fetchLoggedInTechInfo = async (loggedInTech: string) => {
        return {
            techUuid: loggedInTech,
            techName: await getTechnologistName(contactsRef.current, loggedInTech)
        }
    }

    const updateSubjectInitialPresence = async () => {
        for (const subject of props.subjects) {
            const map = await props.syncClient.map(subject.syncMapId)
            await updateInitialPresence(map, subject, [])
        }
        dispatch(updateAllContactsPresence([...contactsRef.current]))
        dispatch(updateAllRoomPresence([...roomsRef.current]))
    }

    useEffect(() => { contactsRef.current = contacts }, [contacts])
    useEffect(() => { roomsRef.current = rooms }, [rooms])

    useEffect(() => { createOrUpdatePresenceMap() }, [props.subjects])

    useEffect(() => {
        if (prevApplicationConnectionState.current === EConnectionStatus.OFFLINE && applicationConnectionState === EConnectionStatus.ONLINE) {
            infoLogger(`Updating initial presence for all contacts and rooms for user ${currentUser.uuid} in session ${currentUser.sessionId} since application internet was down.`)
            updateSubjectInitialPresence()
        }
        prevApplicationConnectionState.current = applicationConnectionState
    }, [applicationConnectionState])

    useEffect(() => {
        presenceUpdateRef.current = presenceUpdate
        if (timeoutId.current) { return }
        if (presenceUpdate.roomPresence.length || presenceUpdate.userPresence.length) {
            timeoutId.current = setTimeout(triggerFunction, parseIntBase10(configs.PRESENCE_UPDATE_TIMEOUT))
        }
    }, [presenceUpdate.roomPresence, presenceUpdate.userPresence])
    return <div />
}
