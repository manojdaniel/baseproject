/*
 * Created on Wed Sep 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { getActiveStyles } from "../../../../common/helpers/helpers"
import { ESidePanelTabs, IAppProps } from "../../../../types/types"
import styles from "./ContactListTab.scss"
import cx from "classnames"

interface IContactsTab extends IAppProps {
  activeItem: ESidePanelTabs
  ContactListComponentTab: any
}

const ContactsListTab = (props: IContactsTab) => {

  const { activeItem, ContactListComponentTab } = props

  const activeStyle = getActiveStyles(activeItem, ESidePanelTabs.Contacts)

  return <div className={cx(styles.contactListTab, activeStyle)} id={"contactsListTab"}>
    {ContactListComponentTab()}
  </div>
}

export default ContactsListTab
