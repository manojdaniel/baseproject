"""
 Created on Wed Dec 2 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import base64
import hashlib
import hmac

from src.constants.constants import UTF_8


class LogApiSignature(object):
    def __init__(self, shared_key, secret_key):
        self.shared_key = shared_key
        self.secret_key = secret_key

    def generate_signature(self, signed_date):
        digest_mode = hashlib.sha256
        hmac_obj = hmac.new(key=bytearray(f"DHPWS{self.secret_key}", UTF_8),
                            msg=bytearray(base64.b64encode(signed_date.encode(UTF_8))),
                            digestmod=digest_mode)
        signature = f"HmacSHA256;Credential:{self.shared_key};SignedHeaders:SignedDate;Signature:{base64.b64encode(hmac_obj.digest()).decode()}"
        return signature
