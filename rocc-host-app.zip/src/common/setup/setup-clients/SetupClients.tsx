/*
 * Created on Mon July 19 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IGraphqlClient, setupOrGetGraphqlClient, IParentStore, EAppStates } from "@rocc/rocc-client-services"
import React, { useEffect, useRef } from "react"
import { useDispatch, useSelector } from "react-redux"
import { useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupAxiosHandler } from "../../../utility/api/apiUtility"
import NetworkDetector from "../../network-detector/NetworkDetector"
import PresenceClient from "../../presence/PresenceClient"
import PresenceController from "../../presence/PresenceController"
import { SERVER_LOGGER, setupTracker } from "@rocc/rocc-logging-module"
import { useManageUserSession } from "../../user-session/ManageUserSession"
import { TRACKER_ROLE_INSTANCE, TRACKER_ROLE_NAME } from "../../../constants/constants"

const SetupClients = () => {
    const { token, sessionId, urls, orgInfraUuid, userOnboardingStatus, currentUser, config, metaData, appState } = useSelector((state: IParentStore) => ({
        token: state.userReducer.currentUser.accessToken,
        sessionId: state.userReducer.currentUser.sessionId,
        userOnboardingStatus: state.userReducer.currentUser.onBoarded,
        urls: state.configReducer.urls,
        orgInfraUuid: state.customerReducer.metaData.orgId,
        currentUser: state.userReducer.currentUser,
        config: state.configReducer.configs,
        metaData: state.customerReducer.metaData,
        appState: state.userReducer.appState,
    }))
    const dispatch = useDispatch()

    const tokenRef = useRef(token)

    useEffect(() => {
        tokenRef.current = token
    }, [token])

    const roccHttpClient = useRoccHttpClient()

    /** Custom Hook to Manage user session(Token refresh) */
    useManageUserSession()

    useEffect(() => {
        if (urls.GRAPHQL_API_HSDP_URI) {
            const localHttpClient = setupAxiosHandler(sessionId, tokenRef, urls.IAM_SERVICES_URL, dispatch, roccHttpClient)
            const props: IGraphqlClient = {
                token,
                graphQlUrl: urls.GRAPHQL_API_HSDP_URI,
                graphQlWSUrl: urls.GRAPHQL_API_HSDP_WS_URI,
                reInit: false,
                orgInfraUuid,
                isServiceAdmin: false,
                roccHttpClient: localHttpClient,
            }
            setupOrGetGraphqlClient(props)
        }
    }, [tokenRef.current, urls])

    useEffect(() => {
        if (currentUser.uuid !== "") {
            setupTracker({
                userId: currentUser.uuid,
                customerName: metaData.name,
                roomName: "",
                iKey: config.INSIGHTS_KEY,
                profileType: currentUser.clinicalRole,
                userName: config.CUSTOMER_ANALYTICS_LOG_CONSENT && config.CUSTOMER_ANALYTICS_LOG_CONSENT === "true" ? currentUser.name : "NotCaptured",
                sessionId,
                endPoint: SERVER_LOGGER,
                orgId: orgInfraUuid,
                roleName: TRACKER_ROLE_NAME,
                roleInstance: TRACKER_ROLE_INSTANCE
            })
        }
    }, [metaData])

    const setupPresence = () => {
        return userOnboardingStatus && orgInfraUuid && appState === EAppStates.READY &&
            <>
                <PresenceClient />
                <PresenceController />
            </>
    }

    return <>
        <NetworkDetector />
        {setupPresence()}
    </>
}
export default SetupClients
