/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EClinicalRole, IParticipantInfo } from "@rocc/rocc-client-services"
import React from "react"
import SVG from "react-inlinesvg"
import microPhoneIcon from "../../../../assets/images/microphone.svg"
import microPhoneMuteIcon from "../../../../assets/images/microphonemute.svg"
import { getRoleName } from "../../../helpers/helpers"

interface ICallerDetails {
    dominantSpeaker: IParticipantInfo
    remoteAudioTrackStatus: boolean
    cssStyleClass: any
    numOfParticipants: number
}

const CallerDetails = (props: ICallerDetails) => {
    const { dominantSpeaker, remoteAudioTrackStatus, cssStyleClass, numOfParticipants } = props

    const displayName = () => {
        return numOfParticipants > 0 && dominantSpeaker ? dominantSpeaker.secondaryName ? `${dominantSpeaker.name} - ${dominantSpeaker.secondaryName}` : dominantSpeaker.name : ""
    }

    const getPartnerRole = () => {
        return dominantSpeaker ? dominantSpeaker.secondaryUUID ? EClinicalRole.TECHNOLOGIST : dominantSpeaker.clinicalRole : EClinicalRole.DEFAULT
    }

    return (
        <>
            <div className={cssStyleClass.left} id="callerDetails">
                {numOfParticipants > 0 && <div className={cssStyleClass.userName}>
                    <div className={cssStyleClass.displayName}>{displayName()}</div>
                </div>}
                {numOfParticipants > 0 && displayName() && <span className={cssStyleClass.audioIndicatorIcon}>
                    <SVG src={remoteAudioTrackStatus ? microPhoneIcon : microPhoneMuteIcon} cacheRequests={true} />
                </span>}
                <div className={cssStyleClass.roleName}>
                    {getRoleName(getPartnerRole())}
                </div>
            </div>
        </>
    )
}
export default CallerDetails
