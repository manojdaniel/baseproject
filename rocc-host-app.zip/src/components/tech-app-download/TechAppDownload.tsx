import React, { useState } from "react"
import { DownloadUtility, EAppStates, IParentStore } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import en from "../../resources/translations/en-US"
import { Popup, Button } from "semantic-ui-react"
import cx from "classnames"
import { TECHNOLOGIST_DESKTOP_APP_URI } from "../../constants/endpoints"
import { useDispatch, useSelector } from "react-redux"
import { TECH_DESKTOP_APP_INSTALLER } from "../../constants/constants"
import { setCurrentAppState } from "../../redux/actions/userAction"
import FileSaver from "file-saver"
import styles from "./TechAppDownload.scss"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { roccHttpClient } from "../../utility/api/apiUtility"

const TechAppDownload = () => {
    const [isCopied, setCopied] = useState(false)
    const desktopAppURL = `${window.location.origin}${TECHNOLOGIST_DESKTOP_APP_URI}`
    const { currentUser, urls } = useSelector((state: IParentStore) => ({
        currentUser: state.userReducer.currentUser,
        urls: state.configReducer.urls
    }))
    const dispatch = useDispatch()
    const { intl } = getIntlProvider()

    const handleClipboardCopy = () => {
        navigator.clipboard.writeText(desktopAppURL)
        setCopied(true)
        setTimeout(() => {
            setCopied(false)
        }, 3000)
    }
    const handleDownload = async () => {
        dispatch(setCurrentAppState(EAppStates.LOADING))
        const fileInfo = await DownloadUtility.getPresignedUrl(roccHttpClient, currentUser.accessToken, urls.MANAGEMENT_SERVICE_URL, TECH_DESKTOP_APP_INSTALLER)
        FileSaver.saveAs(fileInfo.url)
        sendLogsToAzure({
            contextData: {
                component: "TechAppDownload",
                event: `Expert user downloaded tech desktop app`,
                Event_By: currentUser.uuid
            }
        })
        dispatch(setCurrentAppState(EAppStates.READY))
    }

    return (
        <div className={styles.techAppDownloadRow}>
            <div className={"headerTitle"}>{intl.formatMessage({ id: "content.techDesktopApp.instructions", defaultMessage: en["content.techDesktopApp.instructions"] })}</div>

            <div className={cx(styles.column)} id={"column"}>
                <div className={styles.row}>
                    <label className={styles.steps}>{intl.formatMessage({ id: "content.techAppDownload.step1", defaultMessage: en["content.techAppDownload.step1"] })}</label><br />
                    <label className={styles.label}>
                        {intl.formatMessage({ id: "content.techAppDownload.step1.label", defaultMessage: en["content.techAppDownload.step1.label"] })}
                        <a href="https://developer.microsoft.com/en-us/microsoft-edge/webview2/#download-section" target={"blank"} rel="noreferrer noopener">
                            {intl.formatMessage({ id: "content.techAppDownload.step1.webView2Link", defaultMessage: en["content.techAppDownload.step1.webView2Link"] })}
                        </a>
                    </label>
                </div>

                <div className={styles.row}>
                    <label className={styles.steps}>{intl.formatMessage({ id: "content.techAppDownload.step2", defaultMessage: en["content.techAppDownload.step2"] })}</label><br />
                    <label className={styles.label}>{intl.formatMessage({ id: "content.admin.clickHereToText", defaultMessage: en["content.admin.clickHereToText"] })}</label>
                    <Button className={styles.downButton} content='Download' icon='download' labelPosition='left' primary onClick={handleDownload} />
                </div>

                <div className={styles.row}>
                    <label className={styles.steps}>{intl.formatMessage({ id: "content.techAppDownload.step3", defaultMessage: en["content.techAppDownload.step3"] })}</label><br />
                    <label className={styles.label}>
                        {intl.formatMessage({ id: "content.techDesktopApp.url", defaultMessage: en["content.techDesktopApp.url"] })}
                    </label>
                    <Popup content={en["content.techDesktopApp.tooltip"]}
                        inverted
                        position="top right"
                        trigger={<Button className={styles.popupBtn} basic content={desktopAppURL} onClick={handleClipboardCopy} />}
                    />
                    <span id="textCopied" className={isCopied ? styles.textCopy : styles.hideTextCopy}>
                        {intl.formatMessage({ id: "content.selfService.supportTollNumber.copied", defaultMessage: en["content.selfService.supportTollNumber.copied"] })}
                    </span>
                </div>
            </div>
        </div>
    )
}

export default TechAppDownload
