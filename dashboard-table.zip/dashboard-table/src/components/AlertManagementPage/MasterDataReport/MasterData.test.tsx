import React from "react";
import { render } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import MasterDataReportTable from "./MasterDataReportTable";
jest.mock("antd", () => {
	const original = jest.requireActual("antd");
	return {
		...original,
		Table: jest.fn(() => null), // Mock the Antd Table component
	};
});
jest.mock("moment", () => {
	return () => ({
		format: jest.fn(() => "01/01/2022 12:00:00 AM"),
	});
});

describe("MasterDataReportTable", () => {
	const data = [
		{
			AssetTag: "tag1",
			AssetName: "name1",
			AlertNumber: "alert1",
			Affiliate: "affiliate1",
			Plant: "plant1",
			AlertType: "type1",
			TimeStamp: new Date("2022-01-01T00:00:00Z"),
			ActionOverdue: "overdue1",
			AssignedTo: "assign1",
			CurrentStage: "stage1",
			OpenDate: new Date("2022-01-01T00:00:00Z"),
			EndDate: new Date("2022-01-01T00:00:00Z"),
			AnomolyFeedback: "feedback1",
			Stage: "stage2",
			Ticket: "ticket1",
			Ageing: "ageing1",
			SensorGroup: "group1",
		},
	];
	it("should render the component without errors", () => {
		render(<MasterDataReportTable data={data} />);

		//     expect(Table).toHaveBeenCalled(); // Verify that Antd Table was called
		//   });
		//   it('should render the table with formatted timestamps', () => {
		//     const { getByText } = render(<MasterDataReportTable data={data} />);
		//     expect(getByText('01/01/2022 12:00:00 AM')).toBeInTheDocument();
		//     expect(moment().format).toHaveBeenCalledWith('MM/DD/YYYY hh:mm:ss A');
		//     expect(moment().format).toHaveBeenCalledTimes(2);
	});
});
