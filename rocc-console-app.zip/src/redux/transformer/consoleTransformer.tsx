/*
 * Created on Wed Dec 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IWorkflow } from "@rocc/rocc-client-services"
import { IRoomInfo, IWorkflowInfo } from "../interfaces/types"

export const getRoomInfoDetails = (rooms: any[]) => {
    const updatedRooms: IRoomInfo[] = []
    rooms.forEach((room: any) => {
        const roomInfo = {
            roomUuid: room.identity.uuid,
            roomName: room.identity.name,
            address: room.identity.address ? room.identity.address : "",
            locationId: room.locationId,
            phoneNumber: room.phoneNumber,
            loggedInTech: room.loggedInTech,
            additionalAttributes: room.additionalAttributes ? room.additionalAttributes : null,
            cameraAvailable: room?.cameraAvailable
        }
        updatedRooms.push(roomInfo)
    })
    return updatedRooms
}

export const getWorkflowInfo = (workflows: IWorkflow[]): IWorkflowInfo[] => {
    return workflows.map(
        (workflow: IWorkflow) => {
            const { id, type, state } = workflow
            return { id, type, state }
        }
    )
}
