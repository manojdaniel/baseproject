"""
 Created on Fri Oct 23 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
from src.constants.constants import ROCC_COMMAND_CENTRE_SEATS
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import verify_if_cc_detail_present

LOG = create_logger("CcDataValidationService")


def fetch_cc_data(client, rx_ip, seat_name, rx_name, seat_info):
    response = client.execute(verify_if_cc_detail_present,
                              variable_values={"rx_name": rx_name,
                                               "seat_name": seat_name,
                                               "seat_info": seat_info,
                                               "rx_ip": rx_ip})
    return check_if_id_is_present(response, ROCC_COMMAND_CENTRE_SEATS)
