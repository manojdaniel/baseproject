/*
 * Created on Mon Sep 21 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import { withHooks } from "jest-react-hooks-shallow"
import React from "react"
import ReactDOM from "react-dom"
import { IntlProvider } from "react-intl"
import { ESidePanelTabs } from "../../types/types"
import MissedCallPanel from "./MissedCallPanel"

const testState = {
    contacts: [{
        id: 3682,
        uuid: "f89ff0bc-b109-458d-be0f-7be4c2c99844",
        name: "red white",
        clinicalRole: "Expert user",
        status: "OFFLINE",
        siteId: [
            "1",
            "3"
        ],
        description: "",
        orgId: 1,
        phoneNumber: "+12345678909",
        email: "red.white@mailinator.com",
        roomName: "",
        allRoles: [
            "",
            "Admin",
            "Expert user",
            "Technologist"
        ],
        modalities: [
            "MR",
            "CT",
        ],
        secondaryName: "",
        secondaryUUID: ""

    }],
    contactsFetched: true,
    currentUser: {},
    sites: [],
    urls: {},
    missedCalls: [{
        "id": 10482,
        "callContextId": "2407494f-5606-4089-b6e9-436ae995c1a3",
        "attemptedCallTime": "2021-09-17T08:44:45.000+0000",
        "caller": "f89ff0bc-b109-458d-be0f-7be4c2c99844",
        "callee": "900b968f-76ac-4593-8c4f-b094d50aad89",
        "seen": true
    }],
    videoCallStatus: [{ callStatus: ECallStatus.CALLDECLINED }],
    activeTechProfile: { uuid: "" },
}

jest.mock("../../redux/store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
    })
}))

const props = {
    activeItem: ESidePanelTabs.MissedCalls,
    contactCardActions: jest.fn(),
}

jest.mock("../../common/helpers/helpers", () => ({

    getUserReducerFromGlobalStore: jest.fn().mockReturnValue({
        currentUser: {},
        contacts: [{
            id: 3682,
            uuid: "f89ff0bc-b109-458d-be0f-7be4c2c99844",
            name: "red white",
            clinicalRole: "Expert user",
            status: "OFFLINE",
            siteId: [
                "1",
                "3"
            ],
            description: "",
            orgId: 1,
            phoneNumber: "+12345678909",
            email: "red.white@mailinator.com",
            roomName: "",
            allRoles: [
                "",
                "Admin",
                "Expert user",
                "Technologist"
            ],
            modalities: [
                "MR",
                "CT",
            ],
            secondaryName: "",
            secondaryUUID: ""

        }]
    }),

    getCustomrReducerFromGlobalStore: jest.fn().mockReturnValue({
        rooms: []
    }),

    getConfigReducerFromGlobalStore: jest.fn().mockReturnValue({
        configData: {
            language: "en-US"
        }
    }),

    getAppReducerFromGlobalStore: jest.fn().mockReturnValue({
        sideBar: {
            activeRightPanel: [],
            displayRightSidePanel: true
        }
    }),

    getDeviceReducerFromGlobalStore: jest.fn().mockReturnValue({
        activeTechProfile: { name: "", id: "", uuid: "" }
    })
}))

jest.mock("react-redux", () => ({
    useSelector: () => (testState),
    useDispatch: () => void (0),
    connect: (stateToProps: any, dispatchToProps: any) => (connectComponent: any) => ({
        stateToProps,
        dispatchToProps,
        connectComponent,
    }),
}))

describe("MissedCallPanel tests", () => {
    let wrapper: any

    it("renders without crashing", () => {
        withHooks(() => {
            wrapper = shallow(<MissedCallPanel {...props} />)
            const div = document.createElement("div")
            ReactDOM.render(<MissedCallPanel {...props} />, div)
            ReactDOM.unmountComponentAtNode(div)
        })
    })

    it("renders No Records Content", () => {
        withHooks(() => {
            wrapper = shallow(<MissedCallPanel {...props} />)
            expect(wrapper.find("NoRecordsContent")).toHaveLength(1)
        })
    })

    it("renders user list", () => {
        withHooks(() => {
            wrapper = shallow(<IntlProvider defaultLocale={"en-US"} locale={"en"}><MissedCallPanel {...props} /></IntlProvider>)
            setTimeout(() => {
                expect(wrapper.find("UserList")).toHaveLength(1)
            }, 100)
        })
    })
})
