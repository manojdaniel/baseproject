/*
 * Created on Thu Sep 29 2022
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { validateAuthToken } from "./jwtUtility"

/**
 * Token created using payload
 * {
 *      nbf: new Date('2022-09-27T10:20:30Z').getTime(),
 *      exp: new Date('2022-09-29T10:20:30Z').getTime(),
 *      iss: "room-uuid",
 *      aud: "requester-uuid",
 * }
 */
const token: string = "eyJhbGciOiJIUzI1NiIsInByb3BYIjp0cnVlfQ"
    + "." + "eyJuYmYiOjE2NjQzMTcyMzAsImV4cCI6MTY2NDQ5MDAzMCwiaXNzIjoicm9vbS11dWlkIiwiYXVkIjoicmVxdWVzdGVyLXV1aWQifQ"
    + "." + "BgAWi3RoSrnErgR8vOvbHMO6U2MfpLOKNEZP9jL9LF4"

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        externalReducer: {
            currentUser: {
                uuid: "requester-uuid"
            }
        }
    })
}))

describe("validateAuthToken tests", () => {
    const dateNowOriginal = global.Date.now
    const dateNowMock = jest.fn()

    beforeAll(() => {
        global.Date.now = dateNowMock
    })

    beforeEach(() => {
        dateNowMock.mockImplementation(() => new Date('2022-09-28T10:20:30Z').getTime())

    })

    it("should fail if token is undefined", () => {
        expect(validateAuthToken(undefined as unknown as string, "room-uuid")).toEqual(false)
    })

    it("should fail if token is malformed", () => {
        expect(validateAuthToken("some-invalid-token", "room-uuid")).toEqual(false)
    })

    it("should fail if validated before `nbf` time", () => {
        dateNowMock.mockImplementation(() => new Date('2022-09-26T10:20:30Z').getTime())
        expect(validateAuthToken(token, "room-uuid")).toEqual(false)
    })

    it("should fail if validated after `exp` time", () => {
        dateNowMock.mockImplementation(() => new Date('2022-09-30T10:20:30Z').getTime())
        expect(validateAuthToken(token, "room-uuid")).toEqual(false)
    })

    // TODO: [MARKER] Enable this test by mocking out getState value
    // it("should fail if auth request wasn't placed by current user", () => {
    //     expect(validateAuthToken(token, "room-uuid")).toEqual(false)
    // })

    it("should fail if room extracted from token doesn't match the target room", () => {
        expect(validateAuthToken(token, "invalid-room-uuid")).toEqual(false)
    })

    it("should pass if all validations pass", () => {
        expect(validateAuthToken(token, "room-uuid")).toEqual(false)
    })

    afterAll(() => {
        global.Date.now = dateNowOriginal
    })
})
