"""
 Created on Mon Apr 4 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""


class MockCloudFoundryClient:
    def __init__(self, endpoint, proxy, verify):
        self.endpoint = endpoint
        self.proxy = proxy
        self.verify = verify

    def init_with_user_credentials(self, login, password):
        if login and password:
            pass
