/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import AudioVideoCallWindow from "./AudioVideoCallWindow"

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

describe("AudioVideoCallWindow component", () => {
    let wrapper: any
    let props: any

    beforeEach(() => {
        props = {
            activeRoom: undefined,
            remoteMediaRef: null,
            dominantSpeaker: undefined,
            localMediaRef: null,
            signalStrength: -1,
            remoteUserVideoStatus: true,
            remoteAudioTrackStatus: true,
            videoStatus: true,
            microphoneStatus: true,
            volumeStatus: true,
            callDuration: {},
            setCallStarted: jest.fn(),
            setRemoteUserVideoStatus: jest.fn(),
            setDominantSpeaker: jest.fn(),
            updateRemoteAudioTrackStatus: jest.fn(),
            setVideoStatus: jest.fn(),
            setMicrophoneStatus: jest.fn(),
            setVolumeStatus: jest.fn(),
        }
        wrapper = shallow(<AudioVideoCallWindow {...props} />)
    })
    it("should render DesktopCallWindow component", () => {
        expect(wrapper.find("DesktopCallWindow")).toHaveLength(1)
    })
    it("should render AudioVideoParticipants component", () => {
        expect(wrapper.find("AudioVideoParticipants")).toHaveLength(1)
    })
    it("should render AudioVideoSource component", () => {
        expect(wrapper.find("AudioVideoSource")).toHaveLength(1)
    })
    it("should render AudioVideoParticipantNewDesign component", () => {
        expect(wrapper.find("AudioVideoParticipantNewDesign")).toHaveLength(0)
    })

})
