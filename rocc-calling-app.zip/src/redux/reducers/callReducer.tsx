/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus, ECallType, EOutGoingCallStatus, ERoomType, IAVCallDetails, IIncomingCallDetails, IMissedCallData, IOutgoingCallDetails } from "@rocc/rocc-client-services"
import { Reducer } from "redux"
import { updateCallDeafenStatus, updateCallMuteStatus } from "../../common/helpers/helpers"
import { INIT_REQUESTER } from "../../common/modules/avmessages/av-messages/types"
import { AV_SETTINGS, CALL_MESSAGE, CONNECTED_CALL_DETAILS, DEFAULT_AV_SETTINGS, DISCONNECT_CALL, SET_CALL_DEAFEN, SET_CALL_MUTE, GLOBAL_SET_INITIATE_PHONE_CALL, GLOBAL_SET_INITIATE_WEB_CALL, IS_FIRST_PARTICPANT, ON_HOLD_CALLS, SET_AV_CALL_VOLUME, SET_CALL_RING_STATUS, SET_CHANNEL_SID, SET_COMMUNICATION_VENDOR, SET_CONVERSATION_CLIENT_STATUS, SET_FULL_SCREEN, SET_INCOMING_CALL_DETAILS, SET_MISSED_CALL_DATA, SET_OUTGOING_CALL_DETAILS, SET_RECENT_MISSED_CALL, UPDATE_CALL_TIMEOUT, UPDATE_CURRENT_AV_CALL, UPDATE_PHONE_CALL_STATUS, VIDEO_CALL_STATUS } from "../actions/types"
import { EAvSettingsType, EClientStatus, ICallMessage, ICallReducer } from "../interfaces/types"
export const DEFAULT_INCOMING_CALL_DEATILS: IIncomingCallDetails = { contextId: "", participant: DEFAULT_CONTACT_INFO, requester: INIT_REQUESTER }
export const DEFAULT_ONGOING_CALL_DETAILS: IAVCallDetails = { contextId: "", roomName: "", roomType: ERoomType.GROUP, twilioToken: "", userDetails: "", participants: [], isFirstParticipant: false, callAcceptedTime: "", isMuted: false, isDeafened: false, callStatus: ECallStatus.IDLE, numOfParticipants: -1 }
export const DEFAULT_OUTGOING_CALL_DEATILS: IOutgoingCallDetails = { callType: ECallType.DEFAULT, contextId: "", participant: DEFAULT_CONTACT_INFO, status: EOutGoingCallStatus.DEFAULT, requester: INIT_REQUESTER }
export const DEFAULT_CALL_MESSAGE: ICallMessage = { messageType: "", message: "", contact: DEFAULT_CONTACT_INFO }
export const DEFAULT_RECENT_MISSED_CALL: IMissedCallData = { id: "", callContextId: "", callee: "", caller: "", seen: false, attemptedCallTime: "" }

export const initialStatesForCall: ICallReducer = {
    phoneCallStatus: ECallStatus.IDLE,
    channelSid: "",
    videoCallStatus: [],
    recipient: DEFAULT_CONTACT_INFO,
    callMessage: DEFAULT_CALL_MESSAGE,
    audioSource: "",
    videoSource: "",
    volume: 100,
    audioOutput: "",
    callDetails: {
        connectedCallDetails: DEFAULT_ONGOING_CALL_DETAILS,
        onHoldCallDetails: [],
        incomingCall: DEFAULT_INCOMING_CALL_DEATILS,
        outgoingCall: DEFAULT_OUTGOING_CALL_DEATILS,
    },
    desktopCallWindowFullScreen: false,
    callTimeout: [],
    callRingStatus: false,
    missedCalls: [],
    recentMissedCall: DEFAULT_RECENT_MISSED_CALL,
    conversationClientStatus: EClientStatus.OFFLINE,
    initiateWebCall: { contactUuid: "", modalityName: "" },
    initiatePhoneCall: { contactUuid: "", phoneNumber: "" },
    communicationVendor: { vendorId: "", vendorName: "" }
}

const callReducer: Reducer = (state: ICallReducer = initialStatesForCall, action: any) => {
    switch (action.type) {
        case UPDATE_PHONE_CALL_STATUS:
            return { ...state, phoneCallStatus: action.phoneCallStatus, recipient: action.recipient }

        case VIDEO_CALL_STATUS:
            return { ...state, videoCallStatus: action.videoCallStatus }

        case SET_AV_CALL_VOLUME:
            return { ...state, volume: action.volume }
        case CALL_MESSAGE: {
            const callMessage: ICallMessage = { messageType: action.messageType, message: action.message, contact: action.contact }
            return { ...state, callMessage, callRetryOption: action.callRetryOption }
        }
        case DEFAULT_AV_SETTINGS:
            return { ...state, audioSource: action.audioSource, videoSource: action.videoSource, audioOutput: action.audioOutput }
        case AV_SETTINGS:
            if (action.avSettingType === EAvSettingsType.AUDIO_INPUT) {
                return { ...state, audioSource: action.selectedValue }
            } else if (action.avSettingType === EAvSettingsType.VIDEO_INPUT) {
                return { ...state, videoSource: action.selectedValue }
            } else if (action.avSettingType === EAvSettingsType.AUDIO_OUTPUT) {
                return { ...state, audioOutput: action.selectedValue }
            } else {
                return { ...state }
            }
        case SET_INCOMING_CALL_DETAILS:
            return { ...state, callDetails: { ...state.callDetails, incomingCall: action.incomingCall } }
        case SET_OUTGOING_CALL_DETAILS:
            return { ...state, callDetails: { ...state.callDetails, outgoingCall: action.outgoingCall } }
        case CONNECTED_CALL_DETAILS:
            return { ...state, callDetails: { ...state.callDetails, connectedCallDetails: action.connectedCallDetails } }
        case ON_HOLD_CALLS:
            return { ...state, callDetails: { ...state.callDetails, onHoldCallDetails: action.onHoldCallDetails } }
        case UPDATE_CURRENT_AV_CALL:
            return { ...state, callDetails: { ...state.callDetails, onHoldCallDetails: action.onHoldCallDetails, connectedCallDetails: action.connectedCallDetails } }
        case SET_FULL_SCREEN:
            return { ...state, desktopCallWindowFullScreen: action.isDesktopFullScreen }
        case SET_MISSED_CALL_DATA:
            return { ...state, missedCalls: action.missedCalls }
        case SET_CHANNEL_SID:
            return { ...state, channelSid: action.channelSid }
        case SET_RECENT_MISSED_CALL:
            return { ...state, recentMissedCall: action.missedCall }
        case IS_FIRST_PARTICPANT:
            return {
                ...state, callDetails: {
                    ...state.callDetails,
                    connectedCallDetails: { ...state.callDetails.connectedCallDetails, isFirstParticipant: action.isParticipant }
                }
            }
        case UPDATE_CALL_TIMEOUT:
            return { ...state, callTimeout: action.callTimeout }
        case SET_CALL_RING_STATUS:
            return { ...state, callRingStatus: action.callRingStatus }
        case SET_CONVERSATION_CLIENT_STATUS:
            return { ...state, conversationClientStatus: action.status }
        case SET_COMMUNICATION_VENDOR:
            return { ...state, communicationVendor: action.communicationVendor }
        case DISCONNECT_CALL: {
            const updatedCallStatus = state.videoCallStatus.map(callStatus =>
                callStatus.contextId === action?.payload?.contextId ? { contextId: callStatus.contextId, callStatus: ECallStatus.DISCONNECTED } : callStatus)
            return { ...state, videoCallStatus: [...updatedCallStatus] }
        }
        case GLOBAL_SET_INITIATE_WEB_CALL:
            return { ...state, initiateWebCall: action.payload.initiateWebCall }

        case SET_CALL_MUTE: {
            const { contextId, isMuted } = action.payload
            const { onHoldCallDetails, connectedCallDetails } = updateCallMuteStatus(contextId, isMuted, state.callDetails)
            return { ...state, callDetails: { ...state.callDetails, onHoldCallDetails, connectedCallDetails } }
        }

        case SET_CALL_DEAFEN: {
            const { contextId, isDeafened } = action.payload
            const { onHoldCallDetails, connectedCallDetails } = updateCallDeafenStatus(contextId, isDeafened, state.callDetails)
            return { ...state, callDetails: { ...state.callDetails, onHoldCallDetails, connectedCallDetails } }
        }

        case GLOBAL_SET_INITIATE_PHONE_CALL:
            return { ...state, initiatePhoneCall: action.payload.initiatePhoneCall }
        default:
    }
    return { ...state }
}

export default callReducer
