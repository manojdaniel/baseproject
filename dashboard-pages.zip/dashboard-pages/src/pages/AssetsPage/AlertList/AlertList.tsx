import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import AlertListTable from "table/AlertListTable";
import Dropdown from "components/Dropdown";
import AlertStatus from "components/AlertStatus";
import Workflow from "../../PlantPage/AlertManagementPage/Workflow";
import "./AlertList.scss";
import { encryptRSAData } from "../../../utility/rsa";
import {
	getAlertListtable,
	getAlertListTopBarSummary,
	getAssetDropdownList,
	getModelDropdownList,
	getModelStatusDropdownList,
	getGlobalSelecetedAsset,
	setRefreshAlertListPage,
	getPlantAlertListStateDropdownList,
} from "../../../redux/reducers/CommonReducer";
import moment from "moment";
import { Outlet } from "react-router-dom";

interface Props {
	buttonName: string;
	onClickHandler: any;
}
export const AlertList = () => {
	let dispatch = useDispatch();
	const location = useLocation();
	let navigate = useNavigate();

	const [selectedAsset, setSelectedAsset] = useState<any>("");
	const [selectedModel, setSelectedModel] = useState<any>("");
	const [selectedModelStatus, setSelectedModelStatus] = useState<any>("");
	const [selectedState, setSelectedState] = useState<any>("");
	const [alertID, setAlertID] = useState<any>("0");
	const [dropdownChanged, setDropdownChanged] = useState<boolean>(false);

	let today = moment(new Date()).format("YYYY-MM-DD");

	const [showWorkflow, setShowWorkflow] = useState<boolean>(false);
	const [currentStage, setCurrentStage] = useState<any>("");
	const [myAlertListTable, setMyAlertListTable] = useState<any>([]);

	const {
		globalSelecetedPlant,
		globalSelecetedAsset,
		assetDropdownList,
		modelDropdownList,
		modelStatusDropdownList,
		alertlisttable,
		alertListTopBarSummary,
		commonFromDateFormat,
		commonToDateFormat,
		commonToDate,
		commonFromDate,
		selectedBreadCrumbDate,
		breadCrumbDate,
		breadCrumbDateFormated,
		loadingalertlisttable,
		refreshAlertListPage,
		plantAlertListStateDropdown,
		loadingPlantAlertListStateDropdown,
		userId,
		loadingAssetDropdownList,
		loadingModelNameDropdownList,
		loadingModelStatusDropdownList,
	} = useSelector((state: any) => ({
		alertlisttable: state.Common.alertlisttable,
		alertListTopBarSummary: state.Common.alertListTopBarSummary,
		globalSelecetedAsset: state.Common.globalSelecetedAsset,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		assetDropdownList: state.Common.assetDropdownList,
		modelDropdownList: state.Common.modelDropdownList,
		modelStatusDropdownList: state.Common.modelStatusDropdownList,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		commonToDate: state.Common.commonToDate,
		commonFromDate: state.Common.commonFromDate,

		selectedBreadCrumbDate: state.Common.selectedBreadCrumbDate,
		breadCrumbDate: state.Common.breadCrumbDate,
		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,

		loadingalertlisttable: state.Common.loadingalertlisttable,
		refreshAlertListPage: state.Common.refreshAlertListPage,
		plantAlertListStateDropdown: state.Common.plantAlertListStateDropdown,

		loadingPlantAlertListStateDropdown:
			state.Common.loadingPlantAlertListStateDropdown,
		loadingAssetDropdownList: state.Common.loadingAssetDropdownList,
		loadingModelNameDropdownList: state.Common.loadingModelNameDropdownList,
		loadingModelStatusDropdownList: state.Common.loadingModelStatusDropdownList,
		userId: state.Common.userId,
	}));

	useEffect(() => {
		if (
			Object.keys(globalSelecetedPlant).length > 0 &&
			Object.keys(globalSelecetedAsset).length > 0
		) {
			let data: any;
			// if (location.state) {
			// 	data = { value: location.state.data, label: location.state.data };
			// } else {
			// 	data = globalSelecetedAsset;
			// }
			setSelectedAsset(globalSelecetedAsset);
			dispatch(
				getAssetDropdownList(
					encryptRSAData(`plantId=${globalSelecetedPlant.value}`)
				)
			); //{plantId}/{userId}
			//  dispatch(getAlertListtable(`${data.value}/0/0/2022-01-01/2023-12-31/Alert/1/100/TimeStamp/ASc`));//alert list by default Asset ID
			dispatch(
				getModelDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			); //{assetId}/{userId}
			//dispatch(getAlertListTopBarSummary(`${data.value}/1`));
			dispatch(
				getPlantAlertListStateDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			);
		}
	}, []);

	useEffect(() => {
		if (modelDropdownList.length > 0) {
			let data: any;
			if (
				location.state?.data2 !== undefined &&
				location.state?.data3 !== undefined &&
				dropdownChanged === false
			) {
				data = { value: location.state.data2, label: location.state.data3 };
			} else {
				data = modelDropdownList[0];
			}
			setSelectedModel(data);
			dispatch(
				getModelStatusDropdownList(
					encryptRSAData(`modelId=${modelDropdownList[0].value}`)
				)
			); //{assetid}/{userId}
		}
	}, [modelDropdownList]);

	useEffect(() => {
		if (modelStatusDropdownList.length > 0) {
			setSelectedModelStatus(modelStatusDropdownList[0]);
			dispatch(
				getPlantAlertListStateDropdownList(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
					)
				)
			);
		}
	}, [modelStatusDropdownList]);

	useEffect(() => {
		if (plantAlertListStateDropdown.length > 0) {
			let data: any;
			if (location.state?.alertState !== undefined && dropdownChanged === false) {
				data = { value: location.state.alertState, label: location.state.alertState };
			} else {
				data = plantAlertListStateDropdown[0];
			}

			setSelectedState(data);
		}
	}, [plantAlertListStateDropdown]);

	useEffect(() => {
		if (location.state?.alertId !== undefined && dropdownChanged === false) {
			setAlertID(location.state?.alertId);
		} else {
			setAlertID(0);
		}
	}, [dropdownChanged]);

	useEffect(() => {
		if (
			breadCrumbDateFormated !== "" &&
			Object.keys(selectedAsset).length > 0 &&
			Object.keys(selectedModel).length > 0 &&
			Object.keys(selectedModelStatus).length > 0 &&
			Object.keys(selectedState).length > 0 &&
			breadCrumbDateFormated !== "Invalid date"
		) {
			dispatch(
				getAlertListTopBarSummary(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}&alertId=${alertID}`
					)
				)
			);
			dispatch(
				getAlertListtable(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&modelId=${selectedModel.value}&modelStatus=${selectedModelStatus.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}&state=${selectedState.value}&alertId=${alertID}`
					)
				)
			); //alert list by default Asset ID
		}
	}, [breadCrumbDateFormated, selectedState]);

	useEffect(() => {
		if (
			commonToDateFormat !== "" &&
			Object.keys(selectedAsset).length > 0 &&
			Object.keys(selectedModel).length > 0 &&
			Object.keys(selectedModelStatus).length > 0 &&
			Object.keys(selectedState).length > 0 &&
			commonFromDateFormat !== "Invalid date"
		) {
			dispatch(
				getAlertListTopBarSummary(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&assetId=${selectedAsset.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}&alertId=${alertID}`
					)
				)
			);

			dispatch(
				getAlertListtable(
					encryptRSAData(
						`plantId=${selectedAsset.value}&assetId=${selectedModel.value}&modelId=${selectedModelStatus.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}&state=${selectedState.value}&alertId=${alertID}`
					)
				)
			);
		}
	}, [commonToDateFormat, selectedState]);

	const handleAssetDropDown = (e: any) => {
		setSelectedAsset(e);
		setSelectedModel("");
		setSelectedModelStatus("");
		setDropdownChanged(true);
		dispatch(
			getModelDropdownList(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${e.value}`
				)
			)
		); //{assetId}/{userId}
		dispatch(getGlobalSelecetedAsset({ value: e.value, label: e.label }));
	};

	const handleModeldDropDown = (e: any) => {
		setSelectedModel(e);
		setSelectedModelStatus("");
		setDropdownChanged(true);
		dispatch(getModelStatusDropdownList(encryptRSAData(`modelId=${e.value}`))); //{assetid}/{userId}
	};

	const handleModeldStatusDropDown = (e: any) => {
		setSelectedModelStatus(e);
		setDropdownChanged(true);
		dispatch(
			getPlantAlertListStateDropdownList(
				encryptRSAData(
					`plantId=${globalSelecetedPlant.value}&assetId=${globalSelecetedAsset.value}`
				)
			)
		);
	};
	const handleStateDropDown = (e: any) => {
		setSelectedState(e);
		setDropdownChanged(true);
	};

	const onClickPlotPage = (item: any) => {
		let list: any = [];
		if (item.influencingSensor1 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor1,
				color: "#E35205",
			};
			list.push(data);
		}
		if (item.influencingSensor2 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor2,
				color: "#3BB44A",
			};
			list.push(data);
		}
		if (item.influencingSensor3 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor3,
				color: "#939598",
			};
			list.push(data);
		}
		if (item.influencingSensor4 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor4,
				color: "#009FDF",
			};
			list.push(data);
		}
		if (item.influencingSensor5 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor5,
				color: "#ffae21",
			};
			list.push(data);
		}
		if (item.influencingSensor6 !== "N/A") {
			let data = {
				value: "",
				label: item.influencingSensor6,
				color: "#4e79a7",
			};
			list.push(data);
		}

		navigate(`/assets/plots`, {
			state: {
				data: selectedAsset.value,
				data2: item.sensorGroupId,
				data3: item.modelName,
				data4: list,
			},
		});
		// navigate(`/${key}`, { state: { data: data, data2: data2, data3: data3 } });
	};

	const onClickWorkFlowPage = (alertId: any, currentStage: string) => {
		// setAlertId(alertId)
		// setCurrentStage(currentStage)
		// setShowWorkflow(true)
		setShowWorkflow(true);
		navigate(`/assets/alertList/workFlow`, {
			state: {
				alertId: alertId,
				currentStage: currentStage,
				pageName: "alertList",
			},
		});
	};

	useEffect(() => {
		try {
			if (
				location.pathname === "/assets/alertList" ||
				location.pathname === "/assets"
			) {
				setShowWorkflow(false);
				if (refreshAlertListPage) {
					if (
						breadCrumbDateFormated !== "" &&
						breadCrumbDateFormated !== "Invalid date" &&
						breadCrumbDateFormated !== undefined
					) {
						dispatch(
							getAlertListTopBarSummary(
								encryptRSAData(
									`assetId=${selectedAsset.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
								)
							)
						);
						dispatch(
							getAlertListtable(
								encryptRSAData(
									`assetId=${selectedAsset.value}&modelId${selectedModel.value}&modelStatus=${selectedModelStatus.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
								)
							)
						); //alert list by default Asset ID
						dispatch(setRefreshAlertListPage(false));
					} else {
						dispatch(
							getAlertListTopBarSummary(
								encryptRSAData(
									`assetId=${selectedAsset.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
								)
							)
						);
						dispatch(
							getAlertListtable(
								encryptRSAData(
									`assetId=${selectedAsset.value}&modelId=${selectedModel.value}&modelStatus=${selectedModelStatus.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
								)
							)
						);
					}
				}
			}
		} catch (error) { }
	}, [location]);

	useEffect(() => {
		if ( location.state?.alertIdFromEmail === "true" && location.state?.alertIdFromEmail !== undefined ) {
			const FilterbyUseridAlertListTable = alertlisttable.filter((item: any) => item.taskAssignedTo === userId);
			setMyAlertListTable(FilterbyUseridAlertListTable);
			
		} else {
			setMyAlertListTable(alertlisttable);
			
		}
	}, [alertlisttable]);

	// console.log("myAlertListTable",myAlertListTable);
	// console.log("alertlisttable",alertlisttable);
	// console.log("location.state?.alertIdFromEmail",location.state?.alertIdFromEmail);
	// console.log("userId",userId);
	

	return (
		<>
			<>
				<AlertStatus
					data={alertListTopBarSummary}
					// data={topbarData}
					page={"ALERT"}
				// healthIndex={jsonTopBarToolTipbyPlantId}
				/>
			</>
			<div id="asset-alert-list" className="asset-alert-list-page">
				{!showWorkflow ? (
					<div className="common-box-inner">
						<div className="title">ALERT LIST</div>
						<div id="new-filter">
							<div className="nf-left">
								<div className="asset-name">
									{Object.keys(selectedAsset).length > 0
										? selectedAsset.value
										: null}
								</div>
							</div>
							<div className="nf-right">
								<div>
									<label className="cus-label">Asset ID</label>
									<Dropdown
										name={"AssetID"}
										options={assetDropdownList}
										handleChange={handleAssetDropDown}
										value={selectedAsset}
										defaultValue={""}
										loading={loadingAssetDropdownList}
									/>
								</div>
								<div>
									<label className="cus-label">Model Name</label>
									<Dropdown
										name={"Model Name"}
										options={modelDropdownList}
										handleChange={handleModeldDropDown}
										defaultValue={""}
										value={selectedModel}
										loading={loadingModelNameDropdownList}
									/>
								</div>
								<div>
									<label className="cus-label">Model Status</label>
									<Dropdown
										name={"Model Status"}
										options={modelStatusDropdownList}
										handleChange={handleModeldStatusDropDown}
										defaultValue={""}
										value={selectedModelStatus}
										loading={loadingModelStatusDropdownList}
									/>
								</div>
								<div>
									<label className="cus-label">State</label>
									<Dropdown
										name={"State"}
										options={plantAlertListStateDropdown}
										handleChange={handleStateDropDown}
										value={selectedState}
										defaultValue={""}
										loading={loadingPlantAlertListStateDropdown}
									/>
								</div>
							</div>
						</div>
						<div className="common-box-content">
							<AlertListTable
								userId={userId}
								data={myAlertListTable}
								loading={loadingalertlisttable}
								onClickPlotPage={onClickPlotPage}
								onClickWorkFlowPage={onClickWorkFlowPage}
							/>
						</div>
					</div>
				) : (
					<>
						{/* <Workflow
              alertId={alertId}
              currentStage={currentStage}
              setShowWorkflow={setShowWorkflow}
            /> */}
						<Outlet />
					</>
				)}
			</div>
		</>
	);
};
export default AlertList;
