// @ts-nocheck
import React, { useRef, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./Reports.scss";
import {
	getreporttable,
	getAlertManagementAffiliatesDroprdown,
	getAlertManagementPlantDroprdown,
	getAlertManagementAssetIdDroprdown,
	getAlertManagementAlertIdDroprdown,
	getcurrentstageDropdownList,
	getLongLeadActionDropdownList,
	getStatusDropdownList,
	getAlertManagementPlantDroprdownEmpty,
	getAlertManagementAssetIdDroprdownEmpty,
	getAlertManagementAlertIdDroprdownEmpty,
} from "../../../../redux/reducers/CommonReducer";
import Dropdown from "components/Dropdown";
import ReportTable from "table/ReportTable";
interface Props {
	buttonName: string;
	onClickHandler: any;
}
// calendar============start
import ReportCalendarPopup from "../../../../components/ReportCalendarPopup/ReportCalendarPopup";
import useOnClickOutside from "../../../../hooks/useOnClickOutside";
import moment from "moment";
import iconCalendar from "../../../../assets/images/icon_calendar.svg";
import { useLocation, useNavigate, Outlet } from "react-router-dom";
import AlertDetails from "../AlertDetails";
import "../AlertManagementPage.scss";
import { encryptRSAData } from "../../../../utility/rsa";

const Reports = () => {
	let dispatch = useDispatch();
	const navigate = useNavigate();

	const [selectedAffiliate, setSelectedAffiliate] = useState<any>("");
	const [selectedPlant, setSelectedPlant] = useState<any>("");
	const [selectedAssetId, setSelectedAssetId] = useState<any>("");
	const [selectedAlertID, setSelectedAlertID] = useState<any>("");
	const [selectedCurrentStage, setSelectedCurrentStage] = useState<any>("");
	const [selectedLongLeadAction, setSelectedLongLeadAction] = useState<any>("");
	const [selectedStatus, setSelectedStatus] = useState<any>("");

	// const [loading, setLoading] = useState<any>(false);
	// const [reportTableData, setReportTableData] = useState<any>([]);

	const [showAlertDetails, setShowAlertDetails] = useState<boolean>(false);
	const [alertId, setAlertId] = useState<any>("");
	const [currentStage, setCurrentStage] = useState<any>("");

	// From Date To Date Start
	const [commonReportFromDateFormat, setcommonReportFromDateFormat] =
		useState<any>();
	const [commonReportToDateFormat, setcommonReportToDateFormat] =
		useState<any>();
	const [commonReportFromDate, setcommonReportFromDate] = useState<any>();
	const [commonReportToDate, setcommonReportToDate] = useState<any>();
	const [showPicker, setShowPicker] = useState(false);

	const ref = useRef(null);
	useOnClickOutside(ref, () => setShowPicker(false));
	// From Date To Date End

	const {
		reporttable,
		alertManagementAffiliatesDroprdown,
		alertManagementPlantDroprdown,
		alertManagementAssetIdDroprdown,
		alertManagementAlertIdDroprdown,
		currentstageDropdownList,
		longLeadActionDropdownList,
		statusDropdownList,
		globalSelecetedAffiliate,
		globalSelecetedPlant,
		globalSelecetedRegion,
		loadingreporttable,
		loadingAlertManagementAffiliatesDroprdown,
		loadingAlertManagementPlantDroprdown,
		loadingAlertManagementAssetIdDroprdown,
		loadingAlertManagementAlertIdDroprdown,
		loadingAffiliateDropdownList,
	} = useSelector((state: any) => ({
		reporttable: state.Common.reporttable,

		alertManagementAffiliatesDroprdown:
			state.Common.alertManagementAffiliatesDroprdown,
		alertManagementPlantDroprdown: state.Common.alertManagementPlantDroprdown,
		alertManagementAssetIdDroprdown:
			state.Common.alertManagementAssetIdDroprdown,
		alertManagementAlertIdDroprdown:
			state.Common.alertManagementAlertIdDroprdown,
		currentstageDropdownList: state.Common.currentstageDropdownList,
		longLeadActionDropdownList: state.Common.longLeadActionDropdownList,
		statusDropdownList: state.Common.statusDropdownList,

		globalSelecetedAffiliate: state.Common.globalSelecetedAffiliate,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		globalSelecetedRegion: state.Common.globalSelecetedRegion,

		loadingreporttable: state.Common.loadingreporttable, // loader table

		loadingAlertManagementAffiliatesDroprdown:
			state.Common.loadingAlertManagementAffiliatesDroprdown, // loader Affliate Dropdown
		loadingAlertManagementPlantDroprdown:
			state.Common.loadingAlertManagementPlantDroprdown, // loader Plant Dropdown
		loadingAlertManagementAssetIdDroprdown:
			state.Common.loadingAlertManagementAssetIdDroprdown, // loader Asset Dropdown
		loadingAlertManagementAlertIdDroprdown:
			state.Common.loadingAlertManagementAlertIdDroprdown, // loader Alert Dropdown
	}));

	useEffect(() => {
		// Setting global value to local region useState
		if (
			Object.keys(globalSelecetedAffiliate).length > 0 &&
			Object.keys(globalSelecetedPlant).length > 0
		) {
			setSelectedAffiliate(globalSelecetedAffiliate);
			setSelectedPlant(globalSelecetedPlant);
			dispatch(getAlertManagementAffiliatesDroprdown(""));
			dispatch(
				getAlertManagementPlantDroprdown(
					encryptRSAData(`affilliate=${globalSelecetedAffiliate.value}`)
				)
			);
			dispatch(
				getAlertManagementAssetIdDroprdown(
					encryptRSAData(
						`affilliate=${globalSelecetedAffiliate.value}&plantId=${globalSelecetedPlant.value}`
					)
				)
			);
		} else {
			dispatch(getAlertManagementAffiliatesDroprdown(""));
		}
	}, []);

	useEffect(() => {
		dispatch(getcurrentstageDropdownList(""));
		dispatch(getLongLeadActionDropdownList(""));
		dispatch(getStatusDropdownList(""));
	}, []);

	const handleAffiliateDropDown = (e: any) => {
		setSelectedAffiliate(e);
		setSelectedAssetId("");
		setSelectedAlertID("");
		dispatch(
			getAlertManagementPlantDroprdown(encryptRSAData(`affilliate=${e.value}`))
		);
	};
	const handlePlantDropDown = (e: any) => {
		setSelectedPlant(e);
		setSelectedAlertID("");
		dispatch(
			getAlertManagementAssetIdDroprdown(
				encryptRSAData(
					`affilliate=${selectedAffiliate.value}&plantId=${e.value}`
				)
			)
		);
	};
	const handleAssetDropDown = (e: any) => {
		setSelectedAssetId(e);
		dispatch(
			getAlertManagementAlertIdDroprdown(
				encryptRSAData(`affilliate=${selectedAffiliate.value}&plantId=${selectedPlant.value}&assetId=${e.value}`)
			)
		);
	};
	const handleAlertIDDropDown = (e: any) => {
		setSelectedAlertID(e);
	};
	const handleCurrentStageDropdown = (e: any) => {
		setSelectedCurrentStage(e);
	};
	const handlelongLeadActionDropdown = (e: any) => {
		setSelectedLongLeadAction(e);
	};
	const handleStatusDropdown = (e: any) => {
		setSelectedStatus(e);
	};
	// Report Date Start======================

	const handleReportFromDate = (date: any) => {
		setcommonReportFromDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonReportFromDateFormat(upatedDate);
	};

	const handleReportToDate = (date: any) => {
		setcommonReportToDate(date);
		let upatedDate = moment(date).format("YYYY-MM-DD");
		setcommonReportToDateFormat(upatedDate);
	};

	const reportFromDate =
		commonReportFromDateFormat !== undefined ? commonReportFromDateFormat : "";
	const reportToDate =
		commonReportToDateFormat !== undefined ? commonReportToDateFormat : "";
	// Report Date End======================

	const showReportTable = () => {
		let getselectedAssetId =
			selectedAssetId !== "" ? selectedAssetId.value : null;
		let getselectedAlertID =
			selectedAlertID !== "" ? selectedAlertID.value : null;
		let getreportFromDate = reportFromDate !== "" ? reportFromDate : null;
		let getreportToDate = reportToDate !== "" ? reportToDate : null;
		let getselectedCurrentStage =
			selectedCurrentStage !== "" ? selectedCurrentStage.value : null;
		let getselectedStatus = selectedStatus !== "" ? selectedStatus.value : null;
		let getselectedLongLeadAction =
			selectedLongLeadAction !== "" ? selectedLongLeadAction.value : null;
		let transformGetselectedLongLeadAction =
			getselectedLongLeadAction !== null
				? getselectedLongLeadAction === 1
					? true
					: false
				: null;

		dispatch(
			getreporttable(
				encryptRSAData(
					`affiliate=${selectedAffiliate.label}&plant=${selectedPlant.label}&assetId=${getselectedAssetId}&alertId=${getselectedAlertID}&fromDate=${getreportFromDate}&toDate=${getreportToDate}&currentStage=${getselectedCurrentStage}&statuses=${getselectedStatus}&requireLeadAction=${transformGetselectedLongLeadAction}`
				)
			)
		);
	};

	const clearAllReportsFields = () => {
		setSelectedAssetId("");
		setSelectedAffiliate("");
		setSelectedPlant("");
		setSelectedAlertID("");
		setSelectedCurrentStage("");
		setSelectedLongLeadAction("");
		setSelectedStatus("");
		setcommonReportFromDateFormat("");
		setcommonReportToDateFormat("");
		setcommonReportFromDate("");
		setcommonReportToDate("");
		dispatch(getAlertManagementPlantDroprdownEmpty(encryptRSAData("")));
		dispatch(getAlertManagementAssetIdDroprdownEmpty(encryptRSAData("")));
		dispatch(getAlertManagementAlertIdDroprdownEmpty(encryptRSAData("")));
	};

	const handleClick = (alertId: any, currentStage: string) => {
		setAlertId(alertId);
		setCurrentStage(currentStage);
		setShowAlertDetails(true);
	};

	const handleClickMyReport = () => {
		document.getElementById("handleClickReport").click();
	};

	return (
		<>
			{!showAlertDetails ? (
				<>
					<div id="ahcreport">
						<div className="common-box-inner">
							<div className="title"> AHC REPORT </div>
							<div className="reports-filter">
								<div>
									<label>AFFILIATE</label>
									<Dropdown
										name={"Select Affiliate"}
										handleChange={handleAffiliateDropDown}
										options={alertManagementAffiliatesDroprdown}
										defaultValue={""}
										value={selectedAffiliate}
										loading={loadingAlertManagementAffiliatesDroprdown}
									/>
								</div>
								<div>
									<label>PLANT</label>
									<Dropdown
										name={"Select Plant"}
										handleChange={handlePlantDropDown}
										options={alertManagementPlantDroprdown}
										defaultValue={""}
										value={selectedPlant}
										loading={loadingAlertManagementPlantDroprdown}
									/>
								</div>
								<div>
									<label>ASSET ID</label>
									<Dropdown
										name={"Asset ID"}
										handleChange={handleAssetDropDown}
										options={alertManagementAssetIdDroprdown}
										value={selectedAssetId}
										defaultValue={""}
										loading={loadingAlertManagementAssetIdDroprdown}
									/>
								</div>
								<div>
									<label>ALERT ID</label>
									<Dropdown
										name={"Alert ID"}
										handleChange={handleAlertIDDropDown}
										options={alertManagementAlertIdDroprdown}
										value={selectedAlertID}
										defaultValue={""}
										loading={loadingAlertManagementAlertIdDroprdown}
									/>
								</div>
								<div className="setdate">
									<label>SET DATE</label>
									{/* Report Date Start component====================== */}
									<div id="ReportCalendar" ref={ref}>
										<input
											type="text"
											value={`${reportFromDate} ${reportToDate}`}
											style={{ float: "left" }}
										/>
										<a
											className="mobile-calendar"
											onClick={() => setShowPicker(!showPicker)}
										>
											<img
												src={iconCalendar}
												title="calendar"
												style={{ float: "left" }}
											/>
										</a>
										{showPicker ? (
											<ReportCalendarPopup
												commonReportFromDateFormat={commonReportFromDateFormat}
												commonReportToDateFormat={commonReportToDateFormat}
												commonReportFromDate={commonReportFromDate}
												commonReportToDate={commonReportToDate}
												handleReportFromDate={handleReportFromDate}
												handleReportToDate={handleReportToDate}
											/>
										) : null}
									</div>
									{/* Report Date End component====================== */}
								</div>
								<div>
									<label>CURRENT STAGE</label>
									<Dropdown
										name={"CurrentStage"}
										handleChange={handleCurrentStageDropdown}
										options={currentstageDropdownList}
										value={selectedCurrentStage}
										defaultValue={""}
									/>
								</div>
								<div>
									<label>LONG LEAD ACTION</label>
									<Dropdown
										name={"LongLeadAction"}
										handleChange={handlelongLeadActionDropdown}
										options={longLeadActionDropdownList}
										defaultValue={""}
										value={selectedLongLeadAction}
									/>
								</div>
								<div>
									<label>STATUS</label>
									<Dropdown
										name={"Status"}
										handleChange={handleStatusDropdown}
										options={statusDropdownList}
										defaultValue={""}
										value={selectedStatus}
									/>
								</div>
								<div className="report-btns">
									<button className="ahc-ete" onClick={handleClickMyReport}>
										EXPORT TO EXCEL{" "}
									</button>
									<button onClick={clearAllReportsFields}>CLEAR </button>
									<button onClick={() => showReportTable()}>SUBMIT </button>
								</div>
							</div>
							<div className="common-box-content">
								<ReportTable
									data={reporttable}
									handleClick={handleClick}
									loading={loadingreporttable}
								/>
								{/* <ReportTable data={reportTableData}/> */}
							</div>
						</div>
					</div>
				</>
			) : (
				<>
					<AlertDetails
						alertId={alertId}
						currentStage={currentStage}
						setShowAlertDetails={setShowAlertDetails}
					/>
				</>
			)}
		</>
	);
};
export default Reports;
