/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useState } from "react"
import { Button, Grid, Icon } from "semantic-ui-react"
import styles from "./CarouselWizard.scss"
import cx from "classnames"
import range from "lodash.range"
import en from "../../../resources/translations/en-US"
import LeaveProtocolTransferConfirmDlg from "../../../components/protocol-transfer/leave-protocol-transfer-confirm-dlg/LeaveProtocolTransferConfirmDlg"
import { dispatchToParentStore, fetchGlobalCurrentUser } from "../../../redux/store/externalAppStates"
import { GLOBAL_SET_ACTIVE_TAB } from "../../../redux/actions/types"
import { EGridWidth, ILeaveProtocolTransferConfirmProps, IStore, IWizardStep } from "../../../redux/interfaces/types"
import { sendLogsToAzure } from "@rocc/rocc-logging-module"
import { useSelector } from "react-redux"
import { initLeaveProtocolTransferDlgModel } from "../../constants/constants"
import { getIntlProvider } from "@rocc/rocc-global-components"

interface ICarouselWizardProps {
  numberOfSteps: number
  activeStep: IWizardStep
  hideControlsOnLastStep: boolean
  onNextClicked: () => void
  onPrevClicked: () => void
}

const CarouselWizard = (props: ICarouselWizardProps) => {
  const {
    protocolTransferStatus,
    currentStep,
  } = useSelector((state: IStore) => ({
    protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
    currentStep: state.protocolTransferReducer.currentStep
  }))
  const currentUser = fetchGlobalCurrentUser()
  const { intl } = getIntlProvider()

  const { numberOfSteps, activeStep, hideControlsOnLastStep } = props
  const [leaveProtocolTransferDlgModel, setLeaveProtocolTransferDlgModel] = useState(initLeaveProtocolTransferDlgModel)
  const [stepArray,] = useState(range(1, numberOfSteps + 1))

  const previousButton = () => (
    <Button id="previous" className={cx(styles.wizardButton, styles.prevButton)} onClick={props.onPrevClicked} disabled={!activeStep.isPrevEnabled}>
      <i className={cx("icon NavigationLeft", styles.prevIcon)} />
      <span className={styles.buttonLabel}>
        {intl.formatMessage({ id: "content.prev.btn", defaultMessage: en["content.prev.btn"] })}
      </span>
    </Button>
  )

  const nextButton = () => (
    <Button id="next" className={cx(styles.wizardButton, styles.nextButton)} onClick={props.onNextClicked} disabled={!activeStep.isNextEnabled}>
      <span className={styles.buttonLabel}>
        {intl.formatMessage({ id: "content.next.btn", defaultMessage: en["content.next.btn"] })}
      </span>
      <i className={cx("icon NavigationRight", styles.nextIcon)} />
    </Button>
  )

  const wizardStep = () => (
    <Grid centered={true} className={styles.stepsContainer} width={EGridWidth.ELEVEN}>
      {stepArray.map((step) => {
        return (
          <span key={`wizard_step_${step}`}
            className={cx(styles.stepDot, (step !== activeStep.stepNumber) ? styles.inactiveStep : styles.activeStep)}
          />
        )
      })}
    </Grid>
  )

  const carouselControls = () => (
    !(hideControlsOnLastStep && activeStep.stepNumber === numberOfSteps) ?
      <Grid.Row className={styles.wizardRow}>
        <Grid.Column width={EGridWidth.TWELVE}>
          <Grid centered={true} className={styles.wizardControls}>
            <Grid.Column className={styles.prevButtonColumn} width={EGridWidth.ONE}>
              {activeStep.stepNumber !== 1 &&
                <Grid className={styles.buttonContainer}>
                  {previousButton()}
                </Grid>
              }
            </Grid.Column>
            <Grid.Column width={EGridWidth.TEN}>
              {wizardStep()}
            </Grid.Column>
            <Grid.Column className={styles.nextButtonColumn} width={EGridWidth.ONE}>
              <Grid className={styles.buttonContainer}>
                {nextButton()}
              </Grid>
            </Grid.Column>
          </Grid>
        </Grid.Column>
      </Grid.Row> : null
  )

  const handleProtocolTransferExit = (action = () => { "" }) => {
    if (protocolTransferStatus) {
      sendLogsToAzure({ contextData: { component: "CarouselWizard", event: `Clicked leave protocol transfer from step ${currentStep}`, Event_By: currentUser.uuid } })
      showConfirmLeavingProtocolTransferDlg(action)
    } else {
      action()
    }
  }

  const onLeaveProtocolTransferDlgClosed = () => {
    setLeaveProtocolTransferDlgModel(initLeaveProtocolTransferDlgModel)
    dispatchToParentStore({ type: GLOBAL_SET_ACTIVE_TAB, payload: { activeTabIndex: 0 } })
  }

  const showConfirmLeavingProtocolTransferDlg = (postConfirmCallback = () => { "" }) => {
    const leaveProtocolTransferDlgModelObject: ILeaveProtocolTransferConfirmProps = {
      show: true,
      postConfirmCallback: postConfirmCallback,
      onDialogClosed: onLeaveProtocolTransferDlgClosed
    }
    setLeaveProtocolTransferDlgModel(leaveProtocolTransferDlgModelObject)
  }

  const carouselContent = () => (
    <Grid.Row className={styles.wizardRow}>
      <Grid.Column className={styles.wizardColumn}>
        <span onClick={() => handleProtocolTransferExit()} id={"leaveProtocolTransfer"}>
          <Icon className={"icon Cross"} />
        </span>
        {activeStep.content}
      </Grid.Column>
    </Grid.Row>
  )

  return (
    <>
      {leaveProtocolTransferDlgModel.show &&
        <LeaveProtocolTransferConfirmDlg show={leaveProtocolTransferDlgModel.show}
          postConfirmCallback={leaveProtocolTransferDlgModel.postConfirmCallback}
          onDialogClosed={leaveProtocolTransferDlgModel.onDialogClosed}
        />
      }
      <Grid id={"carouselWizardComponent"} centered={true} className={styles.wizard} padded={"horizontally"} style={{ width: `${window.innerWidth}px` }}>
        {carouselContent()}
        {carouselControls()}
      </Grid>
    </>
  )
}

export default CarouselWizard
