import React from "react";

const InputField = ({ multiline, onChange, ...otherProps }: any) => {
	if (multiline) {
		return <textarea onChange={onChange} {...otherProps} />;
	} else {
		return <input onChange={onChange} {...otherProps} />;
	}
};

export default InputField;
