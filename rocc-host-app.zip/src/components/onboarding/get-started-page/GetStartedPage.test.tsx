/*
 * Created on Fri May 28 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@dls-pdv/semantic-react-components"
import { EClinicalRole, IUserInfo } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import { Button } from "semantic-ui-react"
import GetStartedPage from "./GetStartedPage"

describe("GetStartedPage component", () => {
    let wrapper: any
    const currentUser: IUserInfo = {
        accessToken: "", accessTokenExpiryTime: "", allRoles: [], email: "", id: "", locale: "", modalities: [], name: "", onBoarded: false,
        orgId: "", phoneNumber: "", roomName: "", sessionId: "", siteId: [], status: EUserPresence.OFFLINE, uuid: "",
        clinicalRole: EClinicalRole.DEFAULT, secondaryUUID: "", secondaryName: "", description: "",
    }
    beforeEach(() => {
        wrapper = shallow(<GetStartedPage currentUser={currentUser} getFinish={jest.fn()} />)
    })
    it("should render header", () => {
        const welcomeHeader = wrapper.find("Header")
        expect(welcomeHeader).toHaveLength(1)
    })

    it("should render item content", () => {
        const divs = wrapper.find("ItemContent")
        expect(divs).toHaveLength(1)
        expect(divs.at(0).find("Button").children()).toHaveLength(1)
    })

    it("should render a modal window with 1 buttons", () => {
        expect(wrapper.find(Button).children()).toHaveLength(1)
    })

})
