/*
 * Created on Tue Nov 2 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ConsoleOperations, EIconType } from "@rocc/rocc-console-components"
import { getIntlProvider } from "@rocc/rocc-global-components"
import React, { useEffect, useRef, useState } from "react"
import { useSelector } from "react-redux"
import { onReceiverUseConfirmation } from "../../common/helpers/consoleUtility"
import { checkIfEmeraldEnabled, checkIfMultiRoomIsDisabled, checkIfViewConsoleEnabled, isRoomMonitoringEnabled } from "../../common/helpers/helpers"
import { IReceiverSelectionModal, IStore } from "../../redux/interfaces/types"
import en from "../../resources/translations/en-US"
import { EConnectionType, EPosition, getRoomDetailFromUuid } from "@rocc/rocc-client-services"
import { dispatchToParentStore, fetchRooms } from "../../redux/store/externalAppStates"
import { connectionUtility, getConnectionAdapter } from "../../common/helpers/connection"
import { GLOBAL_LEFTSIDE_PANEL } from "../../redux/actions/types"
import { EModalityConnectionMode, EModalitySubConnectionMode } from "@rocc/rocc-rconnect-common-js-sdk"

interface IViewConsole {
    roomUuid: string
    showTitle?: boolean
    iconPosition?: EPosition
    setReceiverSelectionModal: React.Dispatch<React.SetStateAction<IReceiverSelectionModal>>
    component?: string
}

const ViewConsole = (props: IViewConsole) => {

    const { roomUuid, showTitle, iconPosition, setReceiverSelectionModal } = props
    const {
        featureFlags,
        consoleSessions,
        commandCenterSeat,
        receivers,
        consoleOperation,
        protocolTransferStatus,
        currentUser,
        permissions
    } = useSelector((state: IStore) => ({
        commandCenterSeat: state.consoleReducer.commandCenterDetails.commandCenterSeat,
        receivers: state.consoleReducer.commandCenterDetails.commandCenterSeat.receivers,
        currentUser: state.externalReducer.currentUser,
        featureFlags: state.externalReducer.featureFlags,
        consoleSessions: state.consoleReducer.consoleSessions,
        consoleOperation: state.consoleReducer.consoleOperation,
        protocolTransferStatus: state.protocolTransferReducer.protocolTransferStatus,
        permissions: state.externalReducer.permissions
    }))

    const { intl } = getIntlProvider()

    const [dropdownOptions, setDropdownOptions] = useState([] as any)
    const [loading, setLoading] = useState(false)
    const [disabled, setDisabled] = useState(false)
    const [connectionState, setConnectionState] = useState(false)
    const consoleSessionsRef = useRef(consoleSessions)

    const componentName = "View Console"
    const { VIEW } = EConnectionType
    const { HORIZONTAL } = EPosition
    useEffect(() => {
        consoleSessionsRef.current = consoleSessions
    }, [consoleSessions])

    const viewConnectionHandler = (connectionMode: EModalityConnectionMode , subConnectionMode : EModalitySubConnectionMode | null) => {

        const props = {
            connectionMode,
            subConnectionMode,
            roomUuid,
            connectionType: VIEW,
            receivers,
            consoleSessions: consoleSessionsRef.current,
            onReceiverSelectionRequired: ()=> setReceiverSelectionModal({ showReceiverModal: true, connectionType: VIEW }),
            onReceiverUseConfirmation : (props: any)=> onReceiverUseConfirmation({...props, setReceiverSelectionModal}),
            featureFlags,
            componentName
        }
        
        if (subConnectionMode === EModalitySubConnectionMode.CC) {
            checkIfMultiRoomIsDisabled(featureFlags, receivers) ? getConnectionAdapter().connect(props)
                : setReceiverSelectionModal({ showReceiverModal: true, connectionType: VIEW })
        } else {
            getConnectionAdapter().connect(props)
        }
    }

    useEffect(() => {
        const getViewingOptions = []  
        const availableConnections = connectionUtility.createConnectionList(getRoomDetailFromUuid(fetchRooms(), roomUuid),{
            username : currentUser.kvmUsername,
            seatname: commandCenterSeat.seatName
        })
        if (availableConnections.length == 0){
            return
        }
        const preferredConnection = getConnectionAdapter().getPreferredConnection(availableConnections, EConnectionType.VIEW)
        
        if (preferredConnection.connectionMode == EModalityConnectionMode.KVM){
            if(preferredConnection.subConnectionMode.includes(EModalitySubConnectionMode.CC)){
                if(checkIfViewConsoleEnabled(permissions, receivers)){
                    getViewingOptions.push({
                        key: getViewingOptions.length,
                        value: intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] }),
                        className: "About",
                        handlerFunction: () => viewConnectionHandler(EModalityConnectionMode.KVM, EModalitySubConnectionMode.CC)
                    })
                }
            }
            if(preferredConnection.subConnectionMode.includes(EModalitySubConnectionMode.EMERALD)){
                const emeraldEditEnabled = checkIfEmeraldEnabled(!!permissions.CONSOLE_VIEW, currentUser.kvmUsername)
                const isEmeraldEnabled = isRoomMonitoringEnabled(featureFlags) ?
                    emeraldEditEnabled && receivers.length === 0 :
                    emeraldEditEnabled
                if (isEmeraldEnabled) {
                    getViewingOptions.push({
                        key: getViewingOptions.length,
                        value: intl.formatMessage({ id: "content.menu.emerald", defaultMessage: en["content.menu.emerald"] }),
                        className: "LinkExternal",
                        handlerFunction: () => viewConnectionHandler(EModalityConnectionMode.KVM, EModalitySubConnectionMode.EMERALD)
                    })
                }
            }
        }else{
            const connectionMode = preferredConnection.connectionMode
            getViewingOptions.push({
                key: getViewingOptions.length,
                value: intl.formatMessage({ id: "content.startViewing.rocc", defaultMessage: en["content.startViewing.rocc"] }),
                className: "About",
                handlerFunction: () => viewConnectionHandler(connectionMode, null)
            })
        }
        setDropdownOptions(getViewingOptions)
    }, [featureFlags, commandCenterSeat, consoleSessions])

    useEffect(() => {
        const { connectionState, loading, disabled } = getConnectionAdapter().getViewOrPMConsoleStatus({
            consoleOperation, consoleSessions: consoleSessionsRef.current, roomUuid, connectionType: VIEW, protocolTransferStatus
        })
        setLoading(loading)
        setDisabled(disabled)
        setConnectionState(connectionState)
    }, [consoleOperation, consoleSessionsRef.current, protocolTransferStatus])

    const performConsoleDisconnectionOps = () => {
        const { status }= getConnectionAdapter().disconnect({ roomUuid, connectionType: VIEW })
        if(status){
            dispatchToParentStore({
                type: GLOBAL_LEFTSIDE_PANEL,
                payload: {
                    displayLeftSidePanel: false,
                    activeLeftPanel: "",
                    desktopFullScreen: false,
                }
            })
        }
    }

    const startViewing = intl.formatMessage({ id: "content.startViewing.btn", defaultMessage: en["content.startViewing.btn"] })
    const stopViewing = intl.formatMessage({ id: "content.stopViewing.btn", defaultMessage: en["content.stopViewing.btn"] })
    return (
        <ConsoleOperations
            consoleOperationProps={{
                start: {
                    icon: EIconType.VIEW_START_ICON,
                    type: VIEW,
                    title: startViewing
                },
                stop: {
                    icon: EIconType.VIEW_STOP_ICON,
                    type: VIEW,
                    title: stopViewing
                }
            }}
            loading={loading}
            disabled={disabled}
            connectionState={connectionState}
            dropdownOptions={dropdownOptions}
            iconPosition={iconPosition ? iconPosition : HORIZONTAL}
            showTitle={showTitle ?? false}
            stopConsoleOperationHandler={performConsoleDisconnectionOps} showToolTip={false} tooltipMessage={""}
        />
    )
}

export default ViewConsole
