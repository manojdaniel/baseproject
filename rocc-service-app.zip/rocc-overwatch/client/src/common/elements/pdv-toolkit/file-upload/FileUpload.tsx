import { EFileUploadStatus } from "common/modules/bulk-upload/types"
import React from "react"
import { Grid, Header, Button, List, Loader, GridColumn, Popup, Icon } from "semantic-ui-react"
import { UPLOAD_ATTACHMENT, UPLOAD_INFO_SIZE, UPLOAD_INFO_FILETYPE, BUTTON_UPLOAD } from "constants/messages"
import { INTEGER_RADIX_TEN, NUMBERS_LIST } from "constants/constants"

enum EFileupload {
    bytes = "Bytes",
    kb = "KB",
    mb = "MB",
    gb = "GB",
    tb = "TB",
    fileType = ".xlsx",
}

interface IFileUpload {
    handleFileSelect: (fileObject: any) => void
    uploadFormat: EFileUploadStatus
    deleteUploadedFile: () => void
    fileObject: any
    errorMessage: string
}

export const ExampleFileupload = ({ fileObject, handleFileSelect, uploadFormat, deleteUploadedFile, errorMessage }: IFileUpload) => {

    const onUploadFileChange = (event: any) => {
        handleFileSelect(event.target.files[0])
    }

    const bytesToSize = (bytes: any) => {
        const sizes = [EFileupload.bytes, EFileupload.kb, EFileupload.mb, EFileupload.gb, EFileupload.tb]
        if (bytes === 0) {
            return "N/A"
        }
        const bytesConvert: any = Math.floor(Math.log(bytes) / Math.log(1024))
        const i = parseInt(bytesConvert, INTEGER_RADIX_TEN)
        if (i === 0) { return bytes + " " + sizes[i] }
        return (bytes / Math.pow(NUMBERS_LIST.BYTE_VALUE, i)).toFixed(1) + "  " + sizes[i]
    }

    return (
        <Grid columns={1}>
            <Grid.Row>
                <GridColumn>
                    <Header as="h5" style={{ marginBottom: "4px" }}>
                        {UPLOAD_ATTACHMENT}
                        <Popup
                            trigger={<Icon className="InformationCircle" style={{ fontSize: "1rem", marginLeft: "8px" }} />}
                            position="right center"
                            inverted
                        >
                            <Popup.Content>
                                <span>{UPLOAD_INFO_SIZE}</span>
                                <br /> <br />
                                <span>{UPLOAD_INFO_FILETYPE}</span>
                            </Popup.Content>
                        </Popup>
                    </Header>
                </GridColumn>
                <GridColumn>
                    <Button primary={true} as="label" htmlFor="file" disabled={uploadFormat !== EFileUploadStatus.IDLE}>{BUTTON_UPLOAD}</Button>
                    <input type="file" id="file" hidden={true} onChange={onUploadFileChange} accept={EFileupload.fileType} />
                </GridColumn>
            </Grid.Row>
            {
                fileObject && fileObject.name && <>
                    {uploadFormat === EFileUploadStatus.SUCCESS && <Grid.Row>
                        <List className={"dls-fileupload"}>
                            <List.Item>
                                <List.Icon className="CheckmarkCircle signal-success" />

                                <List.Content>
                                    <a href="/">{fileObject.name}</a>
                                    <List.Description>
                                        <Header as="h6">
                                            <Header.Content>{"(" + bytesToSize(fileObject.size) + ")"}</Header.Content>
                                        </Header>
                                    </List.Description>
                                </List.Content>

                                <List.Icon className="DeleteTrash" size={"small"} floated="right" onClick={deleteUploadedFile} style={{ cursor: "pointer" }} />
                            </List.Item>
                        </List>
                    </Grid.Row>}

                    {uploadFormat === EFileUploadStatus.FAILED && <Grid.Row>
                        <List className={"dls-fileupload-error"}>
                            <List.Item>
                                <List.Icon className="ExclamationMarkCircle signal-validation" size={"large"} />

                                <List.Content>
                                    {fileObject.name}
                                    <List.Description>
                                        <Header as="h6" className="signal-validation">
                                            <Header.Content>{errorMessage}</Header.Content>
                                        </Header>
                                    </List.Description>
                                </List.Content>

                                <List.Icon className="RotateCCW" size={"large"} floated="right" onClick={() => { }} />
                                <List.Icon className="CrossCircle" floated="right" onClick={deleteUploadedFile} style={{ cursor: "pointer" }} />
                            </List.Item>
                        </List>
                    </Grid.Row>}

                    {uploadFormat === EFileUploadStatus.LOADING && <Grid.Row>
                        <List className={"dls-fileupload-inprogress"}>
                            <List.Item>
                                <List.Icon className={"inlineLoader"}>
                                    <Loader active inline="centered" size={"small"} />
                                </List.Icon>

                                <List.Content>
                                    {fileObject.name}
                                    <List.Description>
                                        <Header as="h6">
                                            <Header.Content>{"(" + bytesToSize(fileObject.size) + ")"}</Header.Content>
                                        </Header>
                                    </List.Description>
                                </List.Content>

                                <List.Icon className="CrossCircle" floated="right" onClick={() => { }} />
                            </List.Item>
                        </List>
                    </Grid.Row>}
                </>
            }
        </Grid >
    )
}
