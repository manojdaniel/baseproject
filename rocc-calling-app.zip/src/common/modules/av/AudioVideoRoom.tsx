/*
 * Created on Thu Sept 23 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus, IParticipantInfo, parseIntBase10 } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, formatMessage, infoLogger, sendLogsToAzure, warningLogger } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import RoccTimer from "../../../components/timer/RoccTimer"
import { CALL_FAILED, CALL_HOLD, CALL_RESUME, COMMUNICATION_VENDOR_NAME_UNAVAILABLE, TELEPRESENCE_SIDEBAR, VIDEO, AUDIO, DATA } from "../../../constants/constants"
import { setCallMessage } from "../../../redux/actions/callActions"
import { GLOBAL_RIGHTSIDE_PANEL } from "../../../redux/actions/types"
import { IStore } from "../../../redux/interfaces/types"
import { dispatchToParentStore, fetchGlobalConfigs } from "../../../redux/store/externalAppStates"
import en from "../../../resources/translations/en-US"
import { checkIfMultiAudioEnabled } from "../../helpers/helpers"
import { guestUserVideoEvent } from "../../helpers/TelemetryTrackingHelper"
import { videoCallHandler, onCallReject } from "../avmessages/av-messages/MessageHelper"
import { IAudioVideoCallingProps } from "./AudioVideoCalling"
import AudioVideoCallWindow from "./AudioVideoCallWindow"
import { evaluateInitialVideoStatus, getAVEventType, leaveRoom, transitionResumeToConnected, updateCallDetails, updateNumOfParticipants } from "./AudioVideoHelper"
import styles from "./AudioVideoRoom.scss"
import { EComponentStatus } from "./types"
import {
    EAvCallType, IPreRequisiteResponse, ITrackOptions, ICallOptions, EResolutionType, RoccAvRoom, RoccException, RoccLocalParticipant, LocalParticipantEvents,
    RoomEvents, AV_SIGNAL_STRENGTH, RoccRemoteParticipant, IRoccVideoCall, RoccAVError, RoccAvLocalTrack, RoccParticipant, RoccAVTrack
} from "@rocc/rocc-av-communication-sdk"
import { AVFactory } from "./AVFactory"
interface IRoomProps extends IAudioVideoCallingProps {
    renderDimensions: any
}

const { INITIATION, CANCELLED, LOADING, COMPLETED } = EComponentStatus
let componentStatus: EComponentStatus = EComponentStatus.INITIATION
let vendorService: IRoccVideoCall
const UNLOAD = "unload"
const component = "Audio Video Room"
const BEFORE_UNLOAD = "beforeunload"
const AudioVideoRoom = (props: IRoomProps) => {
    const { activeCall } = props
    const {
        videoSource,
        audioSource,
        currentUser,
        communicationVendor,
        featureFlags
    } = useSelector((state: IStore) => ({
        videoSource: state.callReducer.videoSource,
        audioSource: state.callReducer.audioSource,
        currentUser: state.externalReducer.currentUser,
        communicationVendor: state.callReducer.communicationVendor,
        featureFlags: state.externalReducer.featureFlags
    }))

    const [activeRoom, setActiveRoom] = useState(undefined as unknown as RoccAvRoom)
    const [previewTracks, setPreviewTracks] = useState([] as RoccAvLocalTrack[])
    const [videoStatus, setVideoStatus] = useState(false)
    const [remoteUserVideoStatus, setRemoteUserVideoStatus] = useState(false)
    const [dominantSpeaker, setDominantSpeaker] = useState(undefined as unknown as IParticipantInfo)
    const [signalStrength, setSignalStrength] = useState(-1)
    const [remoteAudioTrackStatus, setRemoteAudioTrackStatus] = useState(true)
    const [visibility, setVisibility] = useState(true)

    const localMediaRef = useRef()
    const remoteMediaRef = useRef()
    const previewTracksRef = useRef(previewTracks)
    const activeRoomRef = useRef(activeRoom)
    const activeCallDetailsRef = useRef(activeCall)

    const callDuration = <RoccTimer />

    const dispatch = useDispatch()
    const { intl } = getIntlProvider()
    let timerId: any
    const initialVideoStatus = evaluateInitialVideoStatus(currentUser)
    const trackOption: ITrackOptions = {
        audioSource: {
            device: audioSource,
            required: true
        },
        videoSource: {
            device: initialVideoStatus ? videoSource : initialVideoStatus,
            required: true
        },


    }
    const { MAX_SUBSCRIPTION_BITRATE, MAX_VIDEO_BITRATE, SIGNALING_REGION } = fetchGlobalConfigs()
    const additionalAttributes = {
        renderDimension: EResolutionType.GOOD,
        signalingRegion: SIGNALING_REGION,
        maxSubscriptionBitrate: MAX_SUBSCRIPTION_BITRATE,
        maxVideoBitrate: MAX_VIDEO_BITRATE
    }

    const makePreRequisiteCheckCall = async () => {
        let returnValue
        let localTracks
        try {
            infoLogger(`Performing preRequisite check for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
            const response: IPreRequisiteResponse = await vendorService.preRequisiteCheck({ trackOption })
            returnValue = response.status
            localTracks = response.localTracks
        } catch (error) {
            const err = error as RoccException
            errorLogger(`preRequisiteCheck error from sdk with status code: , ${err.statusCode}, error message:, ${err.errorMessage} 
            for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
            populateErrorResponse(err.errorMessage)
        }
        return { returnValue, localTracks }
    }

    const makevendorServiceInitaiteCall = async (localTracks: any) => {
        infoLogger(`AudioVideoRoom.tsx: vendor Service InitaiteCall() for room: ${formatMessage(activeCallDetailsRef.current.roomName)} 
        for user ${currentUser.uuid}`)
        const callOption: ICallOptions = {
            avToken: activeCallDetailsRef.current.twilioToken,
            roomId: activeCallDetailsRef.current.roomName,
            additionalAttributes: additionalAttributes,
            localTracks: localTracks
        }
        return await vendorService.initiateCall(callOption)
    }
    const getVendorName = async () => {
        infoLogger(`getting communication vendor name for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
        return AVFactory.getAvVendor(communicationVendor.vendorName as EAvCallType, currentUser, dispatch)
    }
    const makeAVCall = async (retry: number = 0) => {
        if (retry < 2) {
            if (activeCallDetailsRef.current?.participants.length > 0) {
                window.addEventListener(UNLOAD, () => {
                    leaveRoom(activeCallDetailsRef.current, activeRoomRef.current, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
                })
                const { returnValue, localTracks } = await makePreRequisiteCheckCall()
                if (returnValue && localTracks) {
                    initiateAudioVideoCall(localTracks)
                }
            } else {
                errorLogger(`AudioVideoRoom.tsx: Participants doesn't exist for call context: ${activeCallDetailsRef.current.contextId} and for user user ${currentUser.uuid}`)
                retry = retry + 1
                setTimeout(() => {
                    warningLogger(`AudioVideoRoom.tsx: Retrying to initiate call with context: 
                    ${activeCallDetailsRef.current.contextId}, retry number: ${retry}`)
                    makeAVCall(retry)
                }, 500)
            }
        } else {
            disconnectCallDuringError(previewTracks, "No participant exist Error")
        }
    }

    useEffect(() => {
        if (activeRoomRef.current) {
            setVisibility(activeCall.callStatus !== ECallStatus.PAUSED)
            switch (activeCall.callStatus) {
                case ECallStatus.PAUSED:
                    handleActiveCallHold()
                    break

                case ECallStatus.RESUMED:
                    handleCallResume()
                    break
                default:
            }

        }
    }, [activeCall.callStatus])

    useEffect(() => {
        getVendorName().then((response: any) => {
            if (response != COMMUNICATION_VENDOR_NAME_UNAVAILABLE) {
                vendorService = response
                componentStatus = EComponentStatus.INITIATION
                makeAVCall()
            } else {
                errorLogger(`AudioVideoRoom.tsx: Not able to fetch communication vendor name for call context: ${activeCallDetailsRef.current.contextId}`)
                const { contextId } = activeCallDetailsRef.current
                onCallReject({ contextId: contextId, setState: true, dispatch })
            }
        })
        return (() => {
            window.removeEventListener(BEFORE_UNLOAD, () => {
                leaveRoom(activeCallDetailsRef.current, activeRoom, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
            })
            componentStatus = componentStatus === COMPLETED ? INITIATION : CANCELLED
            leaveRoom(activeCallDetailsRef.current, activeRoomRef.current, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
        })
    }, [])

    useEffect(() => {
        const configs = fetchGlobalConfigs()
        if (activeCall.numOfParticipants === 0 || !activeCall.participants.length) {
            timerId = setTimeout(() => {
                (activeCall.numOfParticipants === 0 || !activeCall.participants.length) && activeRoomRef.current
                    && leaveRoom(activeCallDetailsRef.current, activeRoomRef.current, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
            }, parseIntBase10(configs.AV_AUTO_DISCONNECT_TIMEOUT) * 1000)
        }
        return () => clearTimeout(timerId)
    }, [activeCall.numOfParticipants, activeCall.participants.length])

    useEffect(() => {
        activeCallDetailsRef.current = activeCall
    }, [activeCall])

    useEffect(() => {
        if (activeRoomRef.current) {
            infoLogger(`Toggling microphone for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
            vendorService.toggleMicrophone(activeRoomRef.current, !activeCallDetailsRef.current.isMuted)
        }
    }, [activeCallDetailsRef.current.isMuted])

    useEffect(() => {
        if (activeRoomRef.current) {
            infoLogger(`Toggling speaker for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
            const remoteParticipants = vendorService.getAVParticipants(activeRoomRef.current)
            remoteParticipants.forEach(
                (participant: RoccRemoteParticipant) => {
                    if (activeCallDetailsRef.current.isDeafened) {
                        vendorService.detachRemoteParticipantTracks(participant, [AUDIO])
                    } else {
                        vendorService.attachRemoteParticipantTrackKinds(participant, remoteMediaRef.current, [AUDIO])
                    }
                })
        }
    }, [activeCallDetailsRef.current.isDeafened])

    const handleActiveCallHold = () => {
        infoLogger(`Call on hold for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
        sendLogsToAzure({
            contextData: {
                component, event: `Web To Web call: : Call Hold`, Call_From: currentUser.uuid,
                Event_By: currentUser.uuid, ContextId: activeCallDetailsRef.current.contextId
            }
        })

        if (checkIfMultiAudioEnabled(featureFlags)) {
            infoLogger(`multi audio or multi edit without park and resume is enabled user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
            callOnHoldWhenMultiAudioFeatureEnabled()
        } else {
            callOnHoldWhenMultiAudioFeatureDisabled()
        }
        videoCallHandler(CALL_HOLD, activeCall.contextId)
    }

    const callOnHoldWhenMultiAudioFeatureEnabled = () => {
        // Stop video and data tracks
        vendorService.updateRemoteParticipantTrackStates(activeRoomRef.current, { [VIDEO]: false, [DATA]: false })
        // Stop receiving video and data participant tracks
        const remoteParticipants = vendorService.getAVParticipants(activeRoomRef.current)
        remoteParticipants.forEach(
            (participant: RoccRemoteParticipant) => {
                vendorService.detachRemoteParticipantTracks(participant, [VIDEO, DATA])
            })
    }

    const callOnHoldWhenMultiAudioFeatureDisabled = () => {
        vendorService.updateLocalParticipantTracks(activeRoomRef.current, false)
        vendorService.detachAVParticipants(activeRoomRef.current)
    }

    const handleCallResume = () => {
        infoLogger(`Call resume for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
        sendLogsToAzure({
            contextData: {
                component, event: `Web To Web call: : Call Resume`, Call_From: currentUser.uuid,
                Event_By: currentUser.uuid, ContextId: activeCallDetailsRef.current.contextId
            }
        })
        const newUserPreviewContainer = remoteMediaRef.current
        if (checkIfMultiAudioEnabled(featureFlags)) {
            callResumeWhenMultiAudioFeatureEnabled(newUserPreviewContainer)
        } else {
            callResumeWhenMultiAudioFeatureDisabled(newUserPreviewContainer)
        }
        // API call to update the status
        transitionResumeToConnected(activeCall, dispatch)
        videoCallHandler(CALL_RESUME, activeCall.contextId)
        dispatchToParentStore({ type: GLOBAL_RIGHTSIDE_PANEL, payload: { activeRightPanel: TELEPRESENCE_SIDEBAR, displayRightSidePanel: true, desktopFullScreen: false } })
    }

    const callResumeWhenMultiAudioFeatureEnabled = (newUserPreviewContainer: any) => {
        // Start local tracks
        vendorService.updateRemoteParticipantTrackStates(activeRoomRef.current, { [VIDEO]: true, [DATA]: true })
        const remoteParticipants = vendorService.getAVParticipants(activeRoomRef.current)
        remoteParticipants.forEach(
            (participant: RoccRemoteParticipant) => {
                vendorService.attachRemoteParticipantTrackKinds(participant, newUserPreviewContainer, [VIDEO, DATA])
            })
    }

    const callResumeWhenMultiAudioFeatureDisabled = (newUserPreviewContainer: any) => {
        vendorService.updateLocalParticipantTracks(activeRoomRef.current, true)
        const remoteParticipants = vendorService.getAVParticipants(activeRoomRef.current)
        remoteParticipants.forEach(
            (participant: RoccRemoteParticipant) => {
                vendorService.attachRemoteParticipantTracks(participant, newUserPreviewContainer)
            })

    }
    const populateErrorResponse = (errorMessage: any) => {
        const errorCode = errorMessage
        switch (errorCode) {
            case "MEDIA_DEVICE_UNAVAILABLE": disconnectRoccCall(intl.formatMessage({
                id: "content.callMessage.mediaDevicesUnavailable", defaultMessage: en["content.callMessage.mediaDevicesUnavailable"]
            }))
                break
            case "NO_MEDIA_PERMISSION": disconnectRoccCall(
                intl.formatMessage({ id: "content.callMessage.noMediaPermission", defaultMessage: en["content.callMessage.noMediaPermission"] }
                ))
                break
            case "AUDIO_INPUT_UNAVAILABLE": disconnectRoccCall(intl.formatMessage({
                id: "content.callMessage.audioInputUnavailable", defaultMessage: en["content.callMessage.audioInputUnavailable"]
            }))
                break
            case "CALL_CONNECTION_ERROR": disconnectRoccCall(intl.formatMessage({
                id: "content.callMessage.callConnectionError", defaultMessage: en["content.callMessage.callConnectionError"]
            }))
                break

        }
    }

    useEffect(() => {
        if (activeRoom) {
            activeRoomRef.current = activeRoom
            componentStatus = COMPLETED
        }
    }, [activeRoom])

    const disconnectRoccCall = (message: string) => {
        const participant = activeCallDetailsRef.current.participants.length ? activeCallDetailsRef.current.participants[0] : DEFAULT_CONTACT_INFO
        leaveRoom(activeCallDetailsRef.current, activeRoom, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
        dispatch(setCallMessage({
            messageType: CALL_FAILED, message, contact: participant,
        }))
    }

    useEffect(() => {
        previewTracksRef.current = previewTracks
    }, [previewTracks])

    const roomJoined = async (room: RoccAvRoom) => {
        const { localParticipant, participantSize } = await getLocalandRemotePartcipantSize(room)
        if (componentStatus === CANCELLED) {
            await vendorService.stopLocalAVTracks(previewTracksRef.current)
        } else {
            setActiveRoom(room)
            setVideoStatus(initialVideoStatus)
            if (initialVideoStatus) {
                sendLogsToAzure({ contextData: { component: "AudioVideoCalling: Audio Video Room", event: guestUserVideoEvent(currentUser) } })
            }
            await attachContainer(localParticipant)
            updateParticipantAndSignalStrengthDetails(participantSize, localParticipant)
            initializeRoomAndLocalParticipant(room, localParticipant)
        }
    }

    const attachContainer = async (localParticipant: RoccLocalParticipant) => {
        const previewContainer = localMediaRef.current
        /* Attach LocalParticipant's Tracks, if not already attached. */
        if ((previewContainer) && !(previewContainer as HTMLElement).querySelector(VIDEO)) {
            await vendorService.attachContainer(localParticipant, previewContainer)
        }
    }

    const getLocalandRemotePartcipantSize = async (room: RoccAvRoom) => {
        const localParticipant: RoccLocalParticipant = await vendorService.getLocalParticipant(room)
        const participants = await vendorService.getAVParticipants(room)
        const participantSize = participants.length
        return { localParticipant, participantSize }
    }

    const updateParticipantAndSignalStrengthDetails = (participantSize: number, localParticipant: RoccLocalParticipant) => {
        if (participantSize) {
            updateNumOfParticipants(participantSize, activeCall.contextId, dispatch)
        }
        if (localParticipant.networkQualityLevel) {
            setSignalStrength(localParticipant.networkQualityLevel)
        }
    }

    const initializeRoomAndLocalParticipant = async (room: RoccAvRoom, localParticipant: RoccLocalParticipant) => {
        await vendorService.initializeLocalParticipant(localParticipant, [getAVEventType(LocalParticipantEvents.NETWORK_QUALITY_LEVEL_CHANGED, updateSignalStrength)])
        await vendorService.initializeRoom(room, getRoomEvents())
    }
    const updateSignalStrength = (signalStrength: AV_SIGNAL_STRENGTH) => {
        setSignalStrength(signalStrength)
    }

    const getRoomEvents = () => {
        const reconnectingEventType = getAVEventType(RoomEvents.RECONNECTING, roomReconnecting)
        const reconnectedEventType = getAVEventType(RoomEvents.RECONNECTED, roomReconnected)
        const disconnectedEventType = getAVEventType(RoomEvents.DISCONNECTED, roomDisconnected)
        return [reconnectingEventType, reconnectedEventType, disconnectedEventType]
    }
    const roomReconnecting = (error: Error) => {
        if (error) {
            errorLogger(`AudioVideoRoom.tsx: Error while reconnecting signaling connection : ${JSON.stringify(error.message)} user ${currentUser.uuid} 
            for call contextId ${activeCallDetailsRef.current.contextId}`)
        }
    }

    const roomReconnected = () => {
        infoLogger(`${formatMessage(activeRoomRef.current)} is reconnected for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
    }

    const roomDisconnected = async (room: RoccAvRoom, error: RoccAVError) => {

        if (error) {
            handleRoomDisconenctError(room, error)
        }

        vendorService.detachLocalParticipant(room)
        vendorService.detachAVParticipants(room)
        vendorService.stopLocalAVTracks(previewTracksRef.current)

        setPreviewTracks([])
        setActiveRoom(undefined as unknown as RoccAvRoom)
        infoLogger(`AudioVideoRoom.tsx: Disconnected from Room ${formatMessage(room.name)} successfully for user ${currentUser.uuid} for call contextId ${activeCallDetailsRef.current.contextId}`)
    }

    const handleRoomDisconenctError = (room: RoccAvRoom, error: RoccAVError) => {
        errorLogger(`AudioVideoRoom.tsx: Unexpectedly room was disconnected because of error: ${JSON.stringify(error)} for user ${currentUser.uuid} and 
        call contextId ${activeCallDetailsRef.current.contextId}`)
        let contact = DEFAULT_CONTACT_INFO
        if (activeCallDetailsRef.current && activeCallDetailsRef.current.participants.length) {
            contact = activeCallDetailsRef.current.participants[0]
        }
        leaveRoom(activeCallDetailsRef.current, room, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
        dispatch(setCallMessage({
            messageType: intl.formatMessage({
                id: "content.callMessage.callDisconnected", defaultMessage: en["content.callMessage.callDisconnected"]
            }),
            contact,
            message: intl.formatMessage({
                id: "content.callMessage.callDisconnectWithError", defaultMessage: en["content.callMessage.callDisconnectWithError"]
            }),
        }, true))

    }

    const updateRemoteAudioTrackStatus = (status: boolean, participant: RoccParticipant) => {

        const { participants } = activeCallDetailsRef.current

        const particiapntIdentity = vendorService?.getParticipantIdentity(participant as RoccParticipant)
        const participantIndex = participants.findIndex(
            (callParticipant) => particiapntIdentity ? particiapntIdentity : participant.identity === callParticipant.uuid)
        infoLogger(`AudioVideoRoom.tsx: updateRemoteAudioTrackStatus() participantIndex is ${participantIndex} for user ${currentUser.uuid} 
            for call contextId ${activeCallDetailsRef.current.contextId}`)
        if (participantIndex >= 0) {
            participants[participantIndex].audioTrackStatus = status
            updateCallDetails({ ...activeCallDetailsRef.current }, dispatch, true)
        }
        setRemoteAudioTrackStatus(status)
    }

    const initiateAudioVideoCall = async (localTracks: RoccAvLocalTrack[]) => {
        componentStatus = LOADING
        try {
            setPreviewTracks(localTracks)
            if (currentUser) {
                setDominantSpeaker(activeCallDetailsRef.current.participants[0])
            }
            const room: RoccAvRoom = await makevendorServiceInitaiteCall(localTracks)
            roomJoined(room)
        } catch (error) {
            errorLogger(`AudioVideoRoom.tsx: Exception occurred while initiating AV call due to error : ${error} user ${currentUser.uuid} and 
            call contextId ${activeCallDetailsRef.current.contextId}`)
            disconnectCallDuringError(previewTracks)
        }
    }

    const disconnectCallDuringError = (previewTracks: RoccAVTrack[], errorMessage: string = "") => {
        const { participants, contextId } = activeCallDetailsRef.current
        errorLogger(`AudioVideoRoom.tsx: Disconnecting AV call with context: ${contextId} due to ${errorMessage || "call error"} for user ${currentUser.uuid}`)
        const participant = participants.length ? participants[0] : DEFAULT_CONTACT_INFO
        leaveRoom(activeCallDetailsRef.current, activeRoom, dispatch, vendorService, props.connectedCallProps?.callOperations?.callEnd)
        vendorService.detachAVTrack(previewTracks)
        dispatch(setCallMessage({
            messageType: CALL_FAILED,
            message: intl.formatMessage({ id: "content.callMessage.callConnectionError", defaultMessage: en["content.callMessage.callConnectionError"] }),
            contact: participant
        }))
    }

    return (
        <div id={activeCall.contextId} className={cx(
            styles.audioVideoCallWindow,
            !visibility && styles.hideRoom)
        }>
            <AudioVideoCallWindow
                activeRoom={activeRoom}
                remoteMediaRef={remoteMediaRef}
                setRemoteUserVideoStatus={setRemoteUserVideoStatus}
                dominantSpeaker={dominantSpeaker}
                setDominantSpeaker={setDominantSpeaker}
                updateRemoteAudioTrackStatus={updateRemoteAudioTrackStatus}
                localMediaRef={localMediaRef}
                signalStrength={signalStrength}
                remoteUserVideoStatus={remoteUserVideoStatus}
                remoteAudioTrackStatus={remoteAudioTrackStatus}
                previewTracks={previewTracks}
                videoStatus={videoStatus}
                setVideoStatus={setVideoStatus}
                callDuration={callDuration}
                vendorService={vendorService}
                {...props}
            />
        </div>
    )
}

export default AudioVideoRoom
