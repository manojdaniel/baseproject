"""
 Created on Fri Sep 11 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from flask import request, g
from flask_restful import Resource, reqparse

from src.constants.config_keys import CUSTOMER_OB_LOCALE, CUSTOMER_OB_ANALYTICS_LOG_CONSENT, CUSTOMER_OB_CONSOLE_IP, \
    CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE, CUSTOMER_OB_ROCC_MEDIA_REGION, CUSTOMER_OB_ROCC_SIGNALING_REGION, CUSTOMER_OB_SELECTED_ROLES, CUSTOMER_OB_SESSION_IDLE_TIMEOUT, \
    CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT, CUSTOMER_OB_ROCC_HELPLINE_NUMBER, \
    CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS, CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, \
    CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS, CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, CUSTOMER_OB_BOXILLA_USER_PASS_VALUE, \
    CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE, CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING, CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS, \
    CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION, CUSTOMER_OB_NO_OF_PIN_DIGITS, CUSTOMER_OB_COUNTRY_ISO_CODE, CUSTOMER_OB_PRIVACY_POLICY_URL, CUSTOMER_OB_KVM_VENDOR_TYPE, \
    CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY, CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL, CUSTOMER_OB_MFA_ORG_POLICY
from src.constants.constants import API_VERSION, AUTHORIZATION, RESPONSE_RESOURCE_TYPE, RESPONSE_OPERATION_TYPE, RESPONSE_IDENTIFIER, HELP_MSG, MANDATORY_ORG_ROLES
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.operation_management.bulk_upload_existing_customer_operation import BulkUploadExistingCustomer
from src.modules.operation_management.new_customer_onboard_operation import NewCustomerOnboard
from src.services.customer_services import CustomerService
from src.utility.semver import parse_version
from src.utility.utility import construct_negative_response

LOG = create_logger("CustomerController")

class Customer(Resource):
    existing_customer_parser = reqparse.RequestParser()
    existing_customer_parser.add_argument("file_identifier", type=str, required=True, help=HELP_MSG)
    existing_customer_parser.add_argument("identifier", type=str, required=True, help=HELP_MSG)

    new_customer_parser = reqparse.RequestParser()
    new_customer_parser.add_argument("file_identifier", type=str, required=True, help=HELP_MSG)
    new_customer_parser.add_argument("identifier", type=str, required=True, help=HELP_MSG)
    new_customer_parser.add_argument("customer_object", type=dict, required=True, help=HELP_MSG)

    customer_ob_parser = reqparse.RequestParser()
    customer_ob_parser.add_argument(CUSTOMER_OB_LOCALE, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_COUNTRY_ISO_CODE, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ANALYTICS_LOG_CONSENT, type=bool, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_CONSOLE_IP, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_KVM_VENDOR_TYPE, type=str, required = True, help = HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_BOXILLA_USER_PASS_VALUE, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_BOXILLA_REST_USER_PASS_VALUE, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_CONSOLE_DISCONNECT_DELAY, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_BOXILLA_EMERALD_APP_PUBLIC_KEY, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_BOXILLA_EMERALD_APP_USER_CREDENTIAL, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_SESSION_IDLE_TIMEOUT, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_SESSION_IDLE_DEVICE_TIMEOUT, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_HELPLINE_NUMBER, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_VIDEO_BITRATE_IN_KBPS, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_CALL_DESKTOP_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_VIDEO_BITRATE_IN_KBPS, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_CALL_DEVICE_MAX_SUBSCRIPTION_BITRATE_IN_KBPS, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_MEDIA_REGION, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_ROCC_SIGNALING_REGION, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_MAX_SUPPORTED_DEVICE_USB_CAMERAS, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_MAX_NUM_OF_CONSOLE_SESSION, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_NO_OF_PIN_DIGITS, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITH_HARDWARE, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_MAX_NUM_OF_NFCC_SESSION_WITHOUT_HARDWARE, type=int, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_PRIVACY_POLICY_URL, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_MFA_ORG_POLICY, type=str, required=True, help=HELP_MSG, location=("customer_object",))
    customer_ob_parser.add_argument(CUSTOMER_OB_SELECTED_ROLES, type=dict,
                                    required=True, help=HELP_MSG, location=("customer_object",))
    #pylint: disable=too-many-return-statements
    def post(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        body = Customer.new_customer_parser.parse_args()
        customer_object_args = {}
        try:
            customer_object_args = Customer.customer_ob_parser.parse_args(req=body)
            if not set(MANDATORY_ORG_ROLES).issubset(set(customer_object_args[CUSTOMER_OB_SELECTED_ROLES]["ROLES"])):
                LOG.exception("Customer should have have mandatory roles")
                return {"message": "Field: customer should have mandatory roles"}, 400
        except Exception as ex:
            LOG.exception(f"Exception while parsing customer_object_args, error: {ex}")
            return {"message": "Field: 'customer_object_args' does not have all the required keys"}, 400

        try:
            obj = NewCustomerOnboard(customer_identifier=body["identifier"],
                                    file_identifier=body["file_identifier"],
                                    customer_object=customer_object_args,
                                    user_detail=g.userdetails)

            response = obj.initiate_operation()
            if response["success"]:
                transaction_id = response["message"]
                LOG.info(f"Customer: {body['identifier']} onboarding initiated with transaction: {transaction_id}")
                return {RESPONSE_RESOURCE_TYPE: "Operation",
                        RESPONSE_OPERATION_TYPE: "New customer onboarding is initiated",
                        RESPONSE_IDENTIFIER: transaction_id}, 202
            else:
                return {"message": response["message"]}, response["status"]
        except RoccException as ex:
            LOG.exception(f"Failed to initiate new customer onboarding with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to initiate new customer onboarding with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to initiate new customer onboarding, please contact administrator"), 500

    def put(self):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            body = Customer.existing_customer_parser.parse_args()
            obj = BulkUploadExistingCustomer(body["identifier"], user_detail=g.userdetails)
            transaction_id = obj.initiate_operation(entity_identifier=body["identifier"],
                                                   file_identifier=body["file_identifier"])
            LOG.info(f"Initiating Bulk upload for customer: {body['identifier']} with context: {body['file_identifier']}")
            return {RESPONSE_RESOURCE_TYPE: "Operation",
                    RESPONSE_OPERATION_TYPE: "Update Customer data",
                    RESPONSE_IDENTIFIER: transaction_id}, 202
        except RoccException as ex:
            LOG.exception(f"Failed to initiate new data insertion for existing customer with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title if ex.title else "Internal server error",
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Failed to initiate new data insertion for existing customer with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to initiate new data insertion for existing customer, please contact administrator"), 500

    def delete(self, customer_identifier, customer_org_infra_uuid):
        try:
            api_version = request.headers[API_VERSION]
            if parse_version(api_version) != parse_version("1.0.0"):
                return construct_negative_response(code="400 Bad Request",
                                                   title=f"Invalid {API_VERSION}",
                                                   error_message=f"'{API_VERSION}' supported is 1.0.0"), 400
        except KeyError:
            return construct_negative_response(code="400 Bad Request",
                                               title="Invalid headers",
                                               error_message=f"{API_VERSION} header is needed to process this request"), 400
        try:
            LOG.info(f"Customer: {customer_identifier} offboarding initiated")
            existing_customer_parser = reqparse.RequestParser()
            existing_customer_parser.add_argument("force_clean", type=str, required=False)
            body = existing_customer_parser.parse_args()
            force_clean = body.get("force_clean", False) if body else False
            customer_service = CustomerService(service_user_uuid=g.userdetails,token=request.headers[AUTHORIZATION],
                                               customer_org_infra_uuid=customer_org_infra_uuid,
                                               customer_identifer=customer_identifier,
                                               force_clean=force_clean)
            customer_service.offboard_customer()
            return {"message": "Customer offboarded successfully"}, 204
        except RoccException as ex:
            LOG.exception(f"Customer offboarding failed with error: {ex}")
            return construct_negative_response(code=ex.status_code,
                                               title=ex.title,
                                               error_message=ex.payload), ex.status_code
        except Exception as ex:
            LOG.exception(f"Customer offboarding failed with error: {ex}")
            return construct_negative_response(code=500,
                                               title="Internal server error",
                                               error_message="Failed to offboard customer, please contact administrator"), 500
