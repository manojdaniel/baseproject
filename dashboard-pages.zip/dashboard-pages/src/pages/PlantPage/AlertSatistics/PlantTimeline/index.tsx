import React, { useRef, useEffect, useState } from "react";
import PlantTimelineChart from "charts/PlantTimelineChart";
import { useDispatch, useSelector } from "react-redux";
import { getPlantTimelineByPlantId } from "../../../../redux/reducers/CommonReducer";
import moment from "moment";
import Loader from "components/Loader";
import { encryptRSAData } from "../../../../utility/rsa";
import "./PlantTimelineChart.scss";
import NoData from "components/NoData";

const PlantTimeline = () => {
	let dispatch = useDispatch();

	const {
		plantTimelineByPlant,
		commonFromDateFormat,
		commonToDateFormat,
		breadCrumbDateFormated,
		globalSelecetedPlant,
		loadingplantTimelineByPlant,
	} = useSelector((state: any) => ({
		plantTimelineByPlant: state.Common.plantTimelineByPlant,

		commonFromDateFormat: state.Common.commonFromDateFormat,
		commonToDateFormat: state.Common.commonToDateFormat,
		breadCrumbDateFormated: state.Common.breadCrumbDateFormated,
		globalSelecetedPlant: state.Common.globalSelecetedPlant,
		loadingplantTimelineByPlant: state.Common.loadingplantTimelineByPlant,
	}));

	const userId = 18; // Add user ID===================

	//Initial Loading with 3M============================
	const currentdate = new Date();
	const last3Month = new Date(currentdate.setMonth(currentdate.getMonth() - 1));
	let last3MonthDate = moment(last3Month).format("YYYY-MM-DD");
	// let today = moment(new Date()).format("YYYY-MM-DD")

	// BreadCrumb Date Formate
	useEffect(() => {
		let today = moment(new Date()).format("YYYY-MM-DD");
		if (breadCrumbDateFormated !== "") {
			dispatch(
				getPlantTimelineByPlantId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&fromDate=${breadCrumbDateFormated}&toDate=${today}`
					)
				)
			); //{assetId}/{fromDate}/{toDate}/{today}
		} else {
			dispatch(
				getPlantTimelineByPlantId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&fromDate=${last3MonthDate}&toDate=${today}`
					)
				)
			); //{plantId}/{userId}/{fromDate}/{toDate}
		}
	}, [breadCrumbDateFormated]);

	// Custom date Formate
	useEffect(() => {
		if (
			commonToDateFormat !== "" &&
			Object.keys(globalSelecetedPlant).length > 0
		) {
			dispatch(
				getPlantTimelineByPlantId(
					encryptRSAData(
						`plantId=${globalSelecetedPlant.value}&fromDate=${commonFromDateFormat}&toDate=${commonToDateFormat}`
					)
				)
			); //{plantId}/{userId}/{fromDate}/{toDate}
		}
	}, [commonToDateFormat]);

	return (
		<>
			{loadingplantTimelineByPlant ? (
				<div id="asset-timeline">
					<div id="asset-timeline-left"><div className="common-box-inner"><div className="departmentloader"><Loader /></div></div></div>
					<div id="asset-timeline-right"><div className="common-box-inner"><div className="departmentloader"><Loader /></div></div></div>
				</div>
			) : plantTimelineByPlant.length === 0 ? (
				<div id="asset-timeline">
					<div id="asset-timeline-left"><div className="common-box-inner"><div className="departmentloader"><NoData /></div></div></div>
					<div id="asset-timeline-right"><div className="common-box-inner"><div className="departmentloader"><NoData /></div></div></div>
				</div>
			) : (
				<PlantTimelineChart plantTimelineData={plantTimelineByPlant} />
			)}
		</>
	);
};
export default PlantTimeline;

// // Custom Date Formate
// useEffect(() => {
//     if (commonToDateFormat !== "" && Object.keys(globalSelecetedPlant).length > 0) {
//         dispatch(getPlantTimelineByPlantId(`${globalSelecetedPlant.value}/${userId}/${last3MonthDate}/${today}`)); //{plantId}/{userId}/{fromDate}/{toDate}
//     }
// }, [commonToDateFormat]);
