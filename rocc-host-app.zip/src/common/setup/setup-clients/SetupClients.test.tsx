/*
 * Created on Wed Oct 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import SetupClients from "./SetupClients"
import { shallow } from "enzyme"

jest.mock("react-redux", () => ({
    useSelector: () => ({
        token: "token",
        sessionId: "sessionID",
        urls: {},
        orgInfraUuid: "",
        currentUser: { accessToken: "" }
    }),
    useDispatch: () => void (0),
}))
jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: () => "",
}))
jest.mock("../../../utility/api/apiUtility", () => ({
    setupAxiosHandler: jest.fn(),
}))

describe("SetupClients", () => {
    let wrapper: any
    beforeEach(() => {
        wrapper = shallow(<SetupClients />)
    })
    it("should render NetworkDetector component", () => {
        expect(wrapper.find("NetworkDetector")).toHaveLength(1)
    })
})
