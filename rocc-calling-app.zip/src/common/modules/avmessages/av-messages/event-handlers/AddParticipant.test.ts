/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECallStatus } from "@rocc/rocc-client-services"
import { addParticipant } from "./AddParticipant"
import * as apiUtility from "../../../../helpers/apiUtility"

jest.mock("../../../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn(),
    CreateStore: jest.fn(),
}))

jest.mock("../../../../../redux/store/externalAppStates", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/externalAppStates")
    return {
        ...actualFn,
        fetchGlobalURLs: jest.fn().mockReturnValue({
            urls: { COMMUNICATION_SERVICES_URL: "https://communicationServiceUrl" }
        })
    }
})

jest.mock("../../../../../redux/store/store", () => {
    const actualFn = jest.requireActual("../../../../../redux/store/store")
    return {
        ...actualFn,
        getState: jest.fn().mockImplementation(() => ({
            callReducer: {
                videoCallStatus: [{ callStatus: ECallStatus.RINGING, contextId: "contextId" }],
            },
            externalReducer: {
                currentUser: {
                    accessToken: "accessToken", sessionId: "sessionId", uuid: "uuid"
                }
            }

        }))
    }
})

jest.spyOn(apiUtility, "putService").mockImplementation(jest.fn())
const dispatch = jest.fn()

describe("AddParticipant tests", () => {
    it("should able to add participant", () => {
        addParticipant({ contextId: "contextId", dispatch, participant: "participant" })
        expect(dispatch).toBeDefined()
    })
})
