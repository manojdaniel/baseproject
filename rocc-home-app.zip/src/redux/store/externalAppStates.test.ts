/*
 * Created on Fri Oct 01 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { USER_REDUCER } from "../../constants/constants"
import globalStore from "./globalStore"
import { fetchGlobalActiveLocation, fetchGlobalConfigs, fetchGlobalContacts, fetchGlobalFeatureFlags, fetchGlobalLocations, fetchGlobalMetaSite, fetchGlobalOrgUUID, fetchGlobalRooms, fetchGlobalSideBar, fetchGlobalURLs, fetchMetaSiteId, getGlobalStoreDetails } from "./externalAppStates"

jest.mock("../../redux/store/globalStore", () => ({ GetGlobalState: jest.fn() }))

describe("getGlobalStoreDetails tests", () => {
    it("get specific reducer value", () => {
        const storeData = {
            CC_HOST: {
                userReducer: {
                    currentUser: {
                        name: "Dummy user",
                        uuid: "uuid"
                    },
                    contacts: []
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(getGlobalStoreDetails({ storeName: "CC_HOST", reducerPath: USER_REDUCER }).currentUser.uuid).toBe("uuid")
        expect(fetchGlobalContacts()).toEqual(storeData.CC_HOST.userReducer.contacts)
    })

    it("should fetch global URLS", () => {
        const storeData = {
            CC_HOST: {
                configReducer: {
                    urls: {
                        IAM_SERVICES_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        COMMUNICATION_SERVICES_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        CONSOLE_SERVICES_URL: "https://INGBTCPIC6VL128.code1.emi.philips.com:8498/philips/rocc",
                        PROXY_URL: "https://platinum-rocc.cloud.pcftest.com",
                        MANAGEMENT_SERVICE_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc",
                        GRAPHQL_API_HSDP_URI: "https://platinum-rocc.cloud.pcftest.com/v1/graphql",
                        GRAPHQL_API_HSDP_WS_URI: "wss://platinum-rocc.cloud.pcftest.com:4443/v1/graphql",
                        RBAC_SERVICE_URL: "https://platinum-rocc.cloud.pcftest.com/philips/rocc"

                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalURLs()).toBe(storeData.CC_HOST.configReducer.urls)
    })


    it("should fetch global configs", () => {
        const storeData = {
            CC_HOST: {
                configReducer: {
                    configs: {
                        ADMIN_MANUAL_PATH: "",
                        DEMO_ENV: "false",
                        QUERY_LIMIT_ADMIN_USERS: "500",
                        ROCC_HELPLINE: "+18176776567",
                        SESSION_IDLE_TIMEOUT: "11",
                        ROCC_DEV: "true",
                        PING_URL: "/ping",
                        LOG_LEVEL: "INFO",
                        INSIGHTS_KEY: "c4009677-6574-43a9-96d5-bb03411aa661",
                        CUSTOMER_ANALYTICS_LOG_CONSENT: "true",
                        USER_MANUAL_PATH: "",
                        QUERY_LIMIT_CONTACTS: "300",
                        MAX_VIDEO_BITRATE: "2000000",
                        MAX_SUBSCRIPTION_BITRATE: "8000000",
                        CONSOLE_DISCONNECT_DELAY: "6",
                        DANGLING_CONSOLE_CONNECTIONS_CLEANUP_INTERVAL: "5",
                        MAX_SUPPORTED_DEVICE_USB_CAMERAS: "2",
                        DEVICE_USB_CAMERAS_LIMIT_FOR_STREAMING: "2",
                        AX_NUM_OF_CONSOLE_SESSION: "3",
                        COUNTRY_ISO_CODE: "US",
                        REGION: "ALL",
                        IS_PROXY: "true",
                        CRYPT_ENABLED: "false",

                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalConfigs()).toBe(storeData.CC_HOST.configReducer.configs)
    })

    it("should fetch global feature flags", () => {
        const storeData = {
            CC_HOST: {
                featureFlagsReducer: {
                    featureFlags: {
                        "rocc-emerald": false,
                        "rocc-emerald-edit": true,
                        "rocc-emerald-view": true,
                        "rocc-multi-camera": false,
                        "rocc-multi-console": false,
                        "rocc-patient-details-visibility": true,
                        "rocc-protocol-transfer": true,
                        "rocc-radconnect": true,
                        "rocc-scheduler": false,
                        "rocc-self-service": false,
                        "rocc-vnc": false
                    }
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalFeatureFlags()).toBe(storeData.CC_HOST.featureFlagsReducer.featureFlags)
    })

    it("should fetch global values from customer reducer", () => {
        const storeData = {
            CC_HOST: {
                customerReducer: {
                    metaData: {
                        id: -1,
                        displayName: "",
                        name: "",
                        orgId: "e9101b82-493c-40df-b539-d605732ffbb4",
                        contacts: []
                    },
                    activeLocationId: 3,
                    rooms: [],
                    locations: []
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalOrgUUID()).toBe(storeData.CC_HOST.customerReducer.metaData.orgId)
        expect(fetchMetaSiteId()).toBe(storeData.CC_HOST.customerReducer.metaData.id)
        expect(fetchGlobalActiveLocation()).toBe(storeData.CC_HOST.customerReducer.activeLocationId)
        expect(fetchGlobalRooms()).toBe(storeData.CC_HOST.customerReducer.rooms)
        expect(fetchGlobalLocations()).toBe(storeData.CC_HOST.customerReducer.locations)
        expect(fetchGlobalMetaSite()).toBe(storeData.CC_HOST.customerReducer.metaData.displayName)  
    })

    it("should fetch global sidebar", () => {
        const storeData = {
            CC_HOST: {
                appReducer: {
                    sideBar: "",
                    version: "test-123"
                }
            }
        }
        jest.spyOn(globalStore, "GetGlobalState").mockReturnValue(storeData)
        expect(fetchGlobalSideBar()).toBe(storeData.CC_HOST.appReducer.sideBar)
    })
})
