import React from "react";
import "./Footer.scss";
const Footer = () => {
	return (
		<div id="footer">
			<div className="footer-inner">
				<p>&copy; Copyright 2023 SABIC</p>
			</div>
		</div>
	);
};

export default Footer;
