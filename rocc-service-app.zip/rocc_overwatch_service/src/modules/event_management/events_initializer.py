"""
 Created on Thu Sep 24 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import ast
import os

from threading import Thread

from src.constants.constants import UTF_8, ROCC_SERVICE_TOOL_ROUTING_KEY
from src.exceptions.RoccException import RoccException
from src.loggers.log import create_logger
from src.modules.event_management.event_handler import handle_event
from src.utility.utility import log_to_handle_unused_variable
from src.wrappers.cf.cf_utility import get_rabbitmq_credentials
from src.wrappers.rabbitmq.consumer import Consumer, ConsumerConfig
from src.wrappers.rabbitmq.rabbitmq_utility import compute_rmq_exchange_name, compute_rmq_queue_name

LOG = create_logger("EventsInitiatlizer")


def setup_listeners():
    try:
        LOG.info("Setting up Event listeners")
        rabbit_consumer_ob = initialize_rabbitmq_consumers()
        thread = Thread(target=rabbit_consumer_ob.listener, daemon=True)
        LOG.info("Starting thread with event listeners")
        thread.start()
    except RoccException as ex:
        raise ex
    except Exception as ex:
        LOG.exception(f"Exception occurred while setting up listeners: {ex}")
        raise RoccException(title="RabbitMQ listeners run failed", payload="Failed to setup RabbitMQ listeners with an error") from ex


def initialize_rabbitmq_consumers():
    cf_rabbitmq_host = get_rabbitmq_credentials()
    # TODO: Need to remove localhost
    rabbitmq_host = cf_rabbitmq_host if cf_rabbitmq_host else os.environ.get("RABBITMQ_HOST", "localhost")
    LOG.info(f"RabbitMQ loaded with host: {rabbitmq_host}")
    return Consumer(ConsumerConfig(host=rabbitmq_host,
                                   queue=compute_rmq_queue_name(),
                                   exchange=compute_rmq_exchange_name(),
                                   routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                   callback=listener_call_back))


def listener_call_back(channel, method, properties, body):
    payload = ast.literal_eval(body.decode(UTF_8))
    LOG.info(f"[x] Received message: {payload}")
    log_to_handle_unused_variable(LOG, channel, method, properties)
    handle_event(payload=payload)
