# rocc-nginx
[![Master-Build](https://github.com/philips-internal/rocc-nginx/actions/workflows/master.yml/badge.svg)](https://github.com/philips-internal/rocc-nginx/actions/workflows/master.yml)
[![Tag-Build](https://github.com/philips-internal/rocc-nginx/actions/workflows/tag.yml/badge.svg)](https://github.com/philips-internal/rocc-nginx/actions/workflows/tag.yml)
<a href=https://codescene.ta.philips.com/1722/analyses/latest/dashboard> <img src="https://codescene.com/status/analyzed-by-codescene-badge.svg" width="130"></a>
### Install Rocc DB

    1. Login to hsdp docker hub
        ```docker login docker.na1.hsdp.io -u <cf_username>```
    2. Change directory to rocc-datamodel
    3. execute install.sh command
        ```bash install.sh```
    4. Login to Postgres through pgAdmin
    5. Connect to local db with postgres user
    6. Right click on Login/Group Roles
            Create --> Login/group Roles
            #### Move along multiple tabs to fill these values
            RoleName: graphql
            Password: <password>
            Privileges: Select all privileges
            Membership: harbinger

        Click on ```Save```
    7. Go to rocc-graphql folder and open docker-compose.yaml file
        ```
        vi docker-compose.yaml
        Update ${SERVER_FQDN}:8080 with host.docker.internal:80
        :wq
        ```
        
    8. execute docker-compose up -d
    9. move to import_schema directory and execute import_metadata.sh file
        ```
            cd import_schema
            bash import_metadata.sh
        ```
    10. Login to graphql
        ```
            http://localhost:8081/console
        ```
