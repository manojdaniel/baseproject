export const getReferenceTableModelDataInput = [
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Press 230PI227A",
        "high": 704.953,
        "low": 646.99,
        "uom": "kg/cm2"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp 1St Disch Press 230PI269",
        "high": 1710.678,
        "low": 1580.279,
        "uom": "kg/hr"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Cwr Temp  230TI212",
        "high": 47.293,
        "low": 32.943,
        "uom": "m/s"
    },
    {
        "modelName": "Compressor Performance Stage 1",
        "sensorName": "N2 A Comp Suct Temp 230TI224",
        "high": 43.879,
        "low": 15.801,
        "uom": "kg/cm2"
    }
]

export const getOfflineModelDataInput = [
    {
        "offlineCondition": "N2 A Comp 1St Disch Press 230PI269 < 800",
        "assetName": "JSW N2 compressors"
    }]