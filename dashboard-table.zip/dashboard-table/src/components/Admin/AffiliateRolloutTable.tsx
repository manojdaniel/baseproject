import React, { useEffect, useState } from "react";
import { Table, Switch } from "antd";
import "../../assets/common/CommonTables.scss";
import "./admin-table.scss";

interface Props {
	data: any[];
	handleUpdate;
}
const AffiliateRolloutTable = ({ data, handleUpdate }: Props) => {
	// Data Formate work :Start
	const [affiliateRolloutTableData, setAffiliateRolloutTableData] =
		useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				affiliate: item.affiliateName,
				country: item.countryName,
				abbreviation: item.abbreviation,
				longitude: item.longitude,
				lattitude: item.lattitude,
				rollout: (
					<Switch
						onChange={() => handleClick(item.affiliate, item.rollout)}
						checkedChildren="Yes"
						unCheckedChildren="No"
						checked={item.rollout}
					/>
				),
			};
		});
		setAffiliateRolloutTableData(mydata);
	}, [data]);

	// Data Formate work :End

	const handleClick = (affiliateID, isRollout) => {
		// alert('handleClick'+affiliateId+isRollout);
		handleUpdate(affiliateID, !isRollout);
	};
	const columns = [
		{
			title: "AFFILIATE",
			dataIndex: "affiliate",
			key: "affiliate",
			width: "15%",
		},
		{
			title: "COUNTRY",
			dataIndex: "country",
			key: "country",
			width: "15%",
		},
		{
			title: "ABBREVIATION",
			dataIndex: "abbreviation",
			key: "abbreviation",
			width: "15%",
		},
		{
			title: "LONGITUDE",
			dataIndex: "longitude",
			key: "longitude",
			width: "20%",
		},
		{
			title: "LATTITUDE",
			dataIndex: "lattitude",
			key: "lattitude",
			width: "20%",
		},
		{
			title: "ROLLOUT",
			dataIndex: "rollout",
			key: "rollout",
			width: "10%",
		},
	];

	const mobileColumns = [
		{
			title: "AFFILIATE",
			dataIndex: "affiliate",
			key: "affiliate",
			width: 100,
		},
		{
			title: "COUNTRY",
			dataIndex: "country",
			key: "country",
			width: 100,
		},
		{
			title: "ABBREVIATION",
			dataIndex: "abbreviation",
			key: "abbreviation",
			width: 100,
		},
		{
			title: "LONGITUDE",
			dataIndex: "longitude",
			key: "longitude",
			width: 100,
		},
		{
			title: "LATTITUDE",
			dataIndex: "lattitude",
			key: "lattitude",
			width: 100,
		},
		{
			title: "ROLLOUT",
			dataIndex: "rollout",
			key: "rollout",
			width: 100,
		},
	];
	return (
		<div>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Table
							columns={columns}
							dataSource={affiliateRolloutTableData}
							tableLayout="fixed"
							pagination={{ pageSize: 10, showSizeChanger: false }}
						/>
					);
				} else {
					return (
						<Table
							columns={mobileColumns}
							tableLayout={undefined}
							dataSource={affiliateRolloutTableData}
							pagination={{ pageSize: 10, showSizeChanger: false }}
							scroll={{ x: "700px", y: 300 }}
						/>
					);
				}
			})()}
		</div>
	);
};
export default AffiliateRolloutTable;
