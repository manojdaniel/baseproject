import React from "react";
import "../assets/common/notfound.scss"
import whatIsTheAssetHealthCareIllustration from '../assets/images/whatIsTheAssetHealthCareIllustration.svg';
import image_Sabic_Logo from '../assets/images/image_Sabic_Logo.svg';

const NotFound = () => {
    return (
        <div id="notfound">
            <div id="container">
                <div id="header">
                    <div className="header-inner">
                        <div className="logoname">ASSET HEALTH CARE</div>
                        <div className="rightside"><img src={image_Sabic_Logo} /></div>
                    </div>
                </div>
                <div id="content">
                    <div><img src={whatIsTheAssetHealthCareIllustration} /></div>
                    <h3>You are not permitted to access this resource, Contact Administrator</h3>
                </div>
            </div>

        </div>
    )
}
export default NotFound;