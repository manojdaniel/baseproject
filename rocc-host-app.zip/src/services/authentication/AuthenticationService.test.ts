import { ELOGIN_STATUS } from "../../types/types"
import * as authenticationService from "./AuthenticationService"

jest.mock("../../redux/store/store", () => ({
    getState: jest.fn().mockReturnValue({
        userReducer: {
            currentUser: {
                id: "1", uuid: "1", clinicalRole: "Expert user", onBoarded: true, allRoles: ["Expert user"], accessToken: "token"
            }
        }
    })
}))

describe("LoginService API call", () => {
    const props = {
        loginUserName: "userName",
        loginUserKey: "userKey",
    }
    it("Should get api data", async () => {
        const spy = jest.spyOn(authenticationService, "loginService")
        authenticationService.loginService(props)
        expect(spy).toHaveBeenCalled()
    })
})
describe("ForgotPasswordService API call", () => {
    const props = {
        email: "junobravo@yopmail.com"
    }
    it("Should get api data", async () => {
        const spy = jest.spyOn(authenticationService, "forgotPasswordService")
        authenticationService.forgotPasswordService(props)
        expect(spy).toHaveBeenCalled()
    })
})
describe("SetPasswordService API call", () => {
    const props = {
        email: "junobravo@yopmail.com",
        userKey: "userKey",
        confirmationCode: "",
        context: "createuser"
    }
    it("Should get api data", async () => {
        const spy = jest.spyOn(authenticationService, "setPasswordService")
        authenticationService.setPasswordService(props.email, props.userKey, props.confirmationCode, props.context)
        expect(spy).toHaveBeenCalled()
    })
})

describe("checkAndRefreshToken API call", () => {
    const props = {
        token: "accessToken",
        sessionId: "sessionId",
        authUrl: "https://authUrl",
        dispatch: jest.fn()
    }
    it("Should get api data", async () => {
        const spy = jest.spyOn(authenticationService, "setPasswordService")
        authenticationService.checkAndRefreshToken(props)
        expect(spy).toHaveBeenCalled()
    })
})
describe("login handler test cases", () => {
    it("Should dispatch login fail messages", async () => {
        const dispatch = jest.fn()
        authenticationService.loginHandler({ loginUserKey: "", loginUserName: "", codeGrant: "", redirectUrl: "" }, dispatch)
        expect(dispatch.mock.calls.length).toEqual(2)
    })
    it("Should dispatch login success", async () => {
        const dispatch = jest.fn()
        const spy = jest.spyOn(authenticationService, "loginService")
        const data = {
            loginResponse: {
                accessToken: "accessToken",
                sessionId: "sessionId",
                userId: "userId",
                orgId: "orgId",
                userName: "userName",
                allOrgList: ["orgId"]
            },
            configs: {},
        }
        spy.mockResolvedValue({ data, status: ELOGIN_STATUS.SUCCESS, statusCode: 200 })
        authenticationService.loginHandler({ loginUserKey: "", loginUserName: "", codeGrant: "", redirectUrl: "" }, dispatch)
        expect(dispatch).toBeCalled()
        expect(spy).toBeCalled()
    })
})
