// @ts-nocheck
import React, { useLayoutEffect } from "react";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

interface Props {
	data: any[];
	selectedSensor: any[];
}

const SensorChart = ({ data, selectedSensor }: Props) => {
	useLayoutEffect(() => {
		try {
			if (selectedSensor.length > 0 && Object.keys(data).length > 0) {
				// Create root element
				// https://www.amcharts.com/docs/v5/getting-started/#Root_element
				let root = am5.Root.new("chartdiv1");

				/* remove amchart logo */

				root._logo.dispose();

				// Set themes
				// https://www.amcharts.com/docs/v5/concepts/themes/
				root.setThemes([am5themes_Animated.new(root)]);

				let data_list_deepcopy = JSON.parse(JSON.stringify(data));

				// Create chart
				// https://www.amcharts.com/docs/v5/charts/xy-chart/
				let chart = root.container.children.push(
					am5xy.XYChart.new(root, {
						panX: false,
						panY: false,
						wheelY: "zoomX",
						pinchZoomX: true,

					})
				);


				chart.get("colors").set("colors", [
					am5.color(0xe35205), //red
					am5.color(0x3bb44a), //green
					am5.color(0x929292), //Gray
					am5.color(0x009fdf), //sky blue
					am5.color(0xffcd00), //yellow
					am5.color(0x4e79a7), //Light sky blue
				]);

				//Zoom in zoom out

				chart.set(
					"scrollbarX",

					am5.Scrollbar.new(root, {
						orientation: "horizontal",
					})
				); //zoom
				// Add cursor
				// https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
				let cursor = chart.set(
					"cursor",
					am5xy.XYCursor.new(root, {
						behavior: "none",
					})
				);
				cursor.lineY.set("visible", false);

				// Create axes
				// https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
				let xAxis0 = chart.xAxes.push(
					am5xy.DateAxis.new(root, {
						baseInterval: { timeUnit: "minute", count: 1 },
						renderer: am5xy.AxisRendererX.new(root, {}),
						tooltip: am5.Tooltip.new(root, {
							dy: -10,
						}),
						tooltipDateFormat: "yyyy-MM-dd HH:mm:ss",
					})
				);
				xAxis0.get("renderer").labels.template.setAll({
                    fontSize: "0.8rem"
                  });
				function createAxisAndSeries(field, name, data) {
					let yRenderer = am5xy.AxisRendererY.new(root, {
						pan: "zoom",
					});
					let yAxis = chart.yAxes.push(
						am5xy.ValueAxis.new(root, {
							maxDeviation: 1,
							renderer: yRenderer,
						})
					);
					yAxis.get("renderer").labels.template.setAll({fontSize: "0.8rem"  });
					if (chart.yAxes.indexOf(yAxis) > 0) {
						yAxis.set("syncWithAxis", chart.yAxes.getIndex(0));
					}

					// Add series
					// https://www.amcharts.com/docs/v5/charts/xy-chart/series/
					let series = chart.series.push(
						am5xy.LineSeries.new(root, {
							name: "name",
							xAxis: xAxis0,
							yAxis,
							valueYField: "value",
							valueXField: "ConvertedTimeStamp",
							tooltip: am5.Tooltip.new(root, {
								pointerOrientation: "horizontal",
								labelText: "{valueY}",
								autoTextColor: true,
							}),
						})
					);

					series.strokes.template.setAll({ strokeWidth: 1 });

					yRenderer.grid.template.set("strokeOpacity", 0.05);
					yRenderer.labels.template.set("fill", series.get("fill"));
					yRenderer.setAll({
						stroke: series.get("fill"),
						strokeOpacity: 1,
						opacity: 1,
					});

					// Set up data processor to parse string dates
					// https://www.amcharts.com/docs/v5/concepts/data/#Pre_processing_data
					series.data.processor = am5.DataProcessor.new(root, {
						dateFormat: "yyyy-MM-dd HH:mm:ss",
						dateFields: ["ConvertedTimeStamp"],
					});

					series.data.setAll(data);

					chart.set(
						"cursor",
						am5xy.XYCursor.new(root, {
							behavior: "zoomXY",
							xAxis: xAxis0,
							yAxis: yAxis
						})
					);
					series.appear(1000);


				}

				if (selectedSensor.length > 0) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data0);
				}
				if (selectedSensor.length > 1) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data1);
				}
				if (selectedSensor.length > 2) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data2);
				}
				if (selectedSensor.length > 3) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data3);
				}
				if (selectedSensor.length > 4) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data4);
				}
				if (selectedSensor.length > 5) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data5);
				}
				if (selectedSensor.length > 6) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data6);
				}
				if (selectedSensor.length > 7) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data7);
				}
				if (selectedSensor.length > 8) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data8);
				}
				if (selectedSensor.length > 9) {
					createAxisAndSeries("power", "POWER", data_list_deepcopy.data9);
				}

				chart.appear(1000, 100);

				return () => {
					root.dispose();
				};
			}
		} catch (error) {
			// Need to write error part
		}
	}, [data, selectedSensor]);

	return (
		<div className="sensor-plot-graph">
			<div id="chartdiv1" style={{ width: "100%", height: "250px" }}></div>
		</div>
	);
};

export default SensorChart;
