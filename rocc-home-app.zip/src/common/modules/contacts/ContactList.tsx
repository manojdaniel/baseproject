/*
 * Created on Mon Sep 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IContactType, SpeedDials, UserList } from "@rocc/rocc-calling-components"
import { EClinicalRole, FeatureFlagHelper, IContactInfo, ROCC_FEATURES } from "@rocc/rocc-client-services"
import { getIntlProvider, NoRecordsContent, SearchBar } from "@rocc/rocc-global-components"
import { errorLogger, errorParser, sendLogsToAzure } from "@rocc/rocc-logging-module"
import cx from "classnames"
import React, { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import en from "../../../resources/translations/en-US"
import { ESidePanelTabs } from "../../../lib/types"
import styles from "./ContactList.scss"
import { convertContactToDisplayList, sortContacts } from "../../helpers/listUtility"
import { IChatContact, IStore } from "../../../redux/interfaces/types"
import { CURRENT_APP_NAME, PARENT_STORE } from "../../../constants/constants"

const remoteLoadFailMsg = `In app: ${CURRENT_APP_NAME}, failed to load`
const WebCallFeature = React.lazy(() => import("roccCalling/WebCallFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} WebCallFeature with error: ${errorParser(ex)}`)))
const PhoneCallFeature = React.lazy(() => import("roccCalling/PhoneCallFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} PhoneCallFeature with error: ${errorParser(ex)}`)))
const ChatTriggerFeature = React.lazy(() => import("roccChat/ChatTriggerFeature").catch((ex) => errorLogger(`${remoteLoadFailMsg} ChatTrigger with error: ${errorParser(ex)}`)))

export interface IContactProps {
    contact: IContactInfo
    permissions: any
    featureFlags?: any
}

export const contactCardActions = ({ contact, permissions, featureFlags }: IContactProps) => {
    const actions = []
    const { uuid, phoneNumber, modalities, name, clinicalRole, status } = contact
    if (uuid && permissions.CALL_WEB_TO_WEB) {
        actions.push(
            <WebCallFeature
                contactUuid={uuid}
                modalityName={modalities[0]}
            />
        )
    }
    /* TODO: Correct the spacing and styles for this chat trigger */
    if (uuid && !!FeatureFlagHelper.isFeatureEnabled(featureFlags ?? [], ROCC_FEATURES.FLAG_CHAT, false) && permissions.CHAT_CREATE) {
        actions.push(<ChatTriggerFeature
            chatContacts={[{ uuid, name, clinicalRole, presence: status } as IChatContact]}
            chatMetadata={{ title: name, description: clinicalRole, useDefaultWindow: true }}
            parentStoreName={PARENT_STORE}
        />)
    }
    if (phoneNumber && permissions.CALL_WEB_TO_PHONE) {
        actions.push(
            <PhoneCallFeature
                contactUuid={uuid}
                phoneNumbers={[{
                    key: phoneNumber,
                    value: phoneNumber,
                    text: phoneNumber
                }]}
                showTitle={true}
            />
        )
    }
    return actions
}

export interface ISidebarContent {
    contacts: IContactInfo[]
    activeItem: ESidePanelTabs
}
const { intl } = getIntlProvider()
/* Speed dial roles */
export const SPEED_DIAL_ROLES: IContactType[] = [
    {
        active: true,
        clinicalRole: EClinicalRole.EXPERTUSER,
        contactTitle: intl.formatMessage({ id: "content.roles.expertUser", defaultMessage: en["content.roles.expertUser"] })
    },
    {
        active: true,
        clinicalRole: EClinicalRole.TECHNOLOGIST,
        contactTitle: intl.formatMessage({ id: "content.roles.technologist", defaultMessage: en["content.roles.technologist"] })
    },
    {
        active: true,
        clinicalRole: EClinicalRole.FRONTDESK,
        contactTitle: intl.formatMessage({ id: "content.roles.frontdesk", defaultMessage: en["content.roles.frontdesk"] })
    },
    {
        active: true,
        clinicalRole: EClinicalRole.SCHEDULER,
        contactTitle: intl.formatMessage({ id: "content.roles.scheduler", defaultMessage: en["content.roles.scheduler"] })
    },
    {
        active: true,
        clinicalRole: EClinicalRole.ADMIN,
        contactTitle: intl.formatMessage({ id: "content.roles.Admin", defaultMessage: en["content.roles.Admin"] })
    }
]
const ContactsList = (props: ISidebarContent) => {

    const { contacts, activeItem } = props
    const { intl } = getIntlProvider()

    const [searchValue, setSearchValue] = useState("")
    const [speedDialRole, setSpeedDialRole] = useState([] as EClinicalRole[])

    const {
        videoCallStatus, phoneCallStatus, permissions, featureFlags, } = useSelector((state: IStore) => ({
            videoCallStatus: state.externalReducer?.callingDetails?.videoCallStatus,
            phoneCallStatus: state.externalReducer?.callingDetails?.phoneCallStatus,
            permissions: state.externalReducer?.permissions,
            featureFlags: state.externalReducer.featureFlags,
        }))
    const computeContactsToDisplay = (contacts: IContactInfo[]) => (
        sortContacts(contacts).map(contact => convertContactToDisplayList(contact, () => contactCardActions({ contact, permissions, featureFlags, })))
    )

    const [userList, setUserList] = useState(computeContactsToDisplay(contacts))

    useEffect(() => {
        let filterResult: IContactInfo[] = [...contacts]
        const checkIfContactCallIsNotEmpty = (contact: IContactInfo) => {
            return contact.uuid === "" && (contact.phoneNumber === "" || !permissions.CALL_WEB_TO_PHONE)
        }
        filterResult = filterResult.filter((contact) => !checkIfContactCallIsNotEmpty(contact))
        if (speedDialRole.length) {
            filterResult = filterResult.filter((contact) => contact.allRoles.some((role) => speedDialRole.includes(role)))
        }
        if (searchValue) {
            filterResult = filterResult.filter((contact: IContactInfo) =>
                contact.name.toLowerCase().indexOf(searchValue) > -1)
        }
        const users = computeContactsToDisplay(filterResult)
        setUserList(users)
    }, [contacts, searchValue, speedDialRole, videoCallStatus, phoneCallStatus, permissions])

    const handleClear = () => {
        setSearchValue("")
    }

    const handleSearch = (event: any) => {
        sendLogsToAzure({ contextData: { component: "Search:Expert User View:Contact List Panel", SearchEvent: event.target.value } })
        setSearchValue(event.target.value.toLowerCase())
    }

    const renderCards = () => {
        return activeItem === ESidePanelTabs.Contacts && userList.length ?
            <div className={styles.contactListContainer}>
                <UserList
                    data={userList}
                    boldUserName={false}
                    alternateAvatar={true}
                    activeCall={false}
                    optimizedRendering={true}
                />
            </div> :
            <div className={styles.noRecords} >
                <NoRecordsContent
                    content={intl.formatMessage({ id: "content.phoneBook.noContacts", defaultMessage: en["content.phoneBook.noContacts"] })}
                />
            </div>
    }

    return (
        <div className={styles.contactList} id={"contactList"} >
            <div className="ui form"><div><i className={"delete icon"} /></div>
                <div id="contactListSearch" className={cx(searchValue.length ? "hideContactsSearchIcon" : "showContactsSearchIcon", styles.searchBarContainer)}>
                    <SearchBar
                        clearButton
                        handleClear={handleClear}
                        handleSearch={(e) => { handleSearch(e) }}
                        placeholder={intl.formatMessage({ id: "content.placeholder.search", defaultMessage: en["content.placeholder.search"] })}
                        searchValue={searchValue}
                        showNoResults={false}
                    />
                </div>
            </div>
            {permissions.CALL_CONTACT_SPEED_DIAL && <SpeedDials
                contactTypes={SPEED_DIAL_ROLES}
                setSpeedDialsRole={setSpeedDialRole}
                speedDialsRole={speedDialRole}
            />}
            {renderCards()}
        </div>
    )

}

export default ContactsList
