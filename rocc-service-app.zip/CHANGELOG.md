# Changelog

## [1.1.1](https://github.com/philips-internal/rocc-service-app/compare/1.1.0...1.1.1) (2022-11-25)


### Bug Fixes

* fixed bug and removed unused code ([3245b72](https://github.com/philips-internal/rocc-service-app/commit/3245b72796befeeebefab2adbed90518b93f777f))

## [1.1.0](https://github.com/philips-internal/rocc-service-app/compare/1.0.13...1.1.0) (2022-11-23)


### Features

* updated test ([0441350](https://github.com/philips-internal/rocc-service-app/commit/04413508fbdc6dbdeb1b0562cfed35658788124a))

## [1.0.13](https://github.com/philips-internal/rocc-service-app/compare/1.0.12...1.0.13) (2022-11-21)


### Bug Fixes

* updated manifest file to use environment id and application id from vars file ([b9800f1](https://github.com/philips-internal/rocc-service-app/commit/b9800f141ce20289f1dc5f1f5b736546abf667ff))

## [1.0.12](https://github.com/philips-internal/rocc-service-app/compare/1.0.11...1.0.12) (2022-11-21)


### Bug Fixes

* font issue resolved ([706cd0d](https://github.com/philips-internal/rocc-service-app/commit/706cd0d6de54fdc52fa5bd8029db020f7b1fa977))
* new line added ([89b049b](https://github.com/philips-internal/rocc-service-app/commit/89b049b45a5d482a4ba79f27e0287dc31aadef2a))
* new line removed ([569033c](https://github.com/philips-internal/rocc-service-app/commit/569033c3a609ed8ae963022d1a705fa28c7b8580))
* sample release to test autoversion ([b5b1a55](https://github.com/philips-internal/rocc-service-app/commit/b5b1a55491a5ee3e4c00d31f4e59488e999fb347))

## [1.0.11](https://github.com/philips-internal/rocc-service-app/compare/1.0.10...1.0.11) (2022-11-08)


### Bug Fixes

* enabled auto-versioning ([d428742](https://github.com/philips-internal/rocc-service-app/commit/d4287429e8b213eba83df0478c2e507412271a5f))
* enabled auto-versioning ([a9f1efe](https://github.com/philips-internal/rocc-service-app/commit/a9f1efec202a1af7b184fa47aff79e56a8262d48))

## [1.0.10](https://github.com/philips-internal/rocc-service-app/compare/v1.0.10...1.0.10) (2022-11-08)

### Bug Fixes

* added ALL to constants ([f6c582c](https://github.com/philips-internal/rocc-service-app/commit/f6c582cfe8472963b8abdef25eff48d07aa179b9))
