/*
 * Created on Wed Nov 11 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React from "react"
import CarouselWizard from "./CarouselWizard"


jest.mock("react-redux", () => ({
    useSelector: () => ({
        protocolTransferStatus: true,
        currentUser: {}
    }),
    useDispatch: () => void (0),
}))

describe("CarouselWizard", () => {
    let wrapper: any
    const defaultContent = <div id="contentDiv" style={{ height: "200px", backgroundColor: "#fff000" }}></div>
    const defaultActiveStep = {
        stepNumber: 2,
        isPrevEnabled: true,
        isNextEnabled: true,
        content: defaultContent
    }
    let nextBtnClicked = false
    let prevBtnClicked = false
    let wizardComponent: any
    let wizardRows: any
    const mockProps: any = {
        numberOfSteps: 5,
        activeStep: { ...defaultActiveStep },
        hideControlsOnLastStep: true,
        onNextClicked: () => { nextBtnClicked = !nextBtnClicked },
        onPrevClicked: () => { prevBtnClicked = !prevBtnClicked },
        isCentered: true,
        customStyles: { widthInPixels: 200, centered: true }
    }

    beforeEach(() => {
        wrapper = shallow(
            <CarouselWizard numberOfSteps={mockProps.numberOfSteps}
                activeStep={mockProps.activeStep}
                hideControlsOnLastStep={mockProps.hideControlsOnLastStep}
                onNextClicked={mockProps.onNextClicked}
                onPrevClicked={mockProps.onPrevClicked} />)
        wizardComponent = wrapper.find("#carouselWizardComponent")
        wizardRows = wrapper.find("#carouselWizardComponent").find("GridRow")

    })
    it("should render with the correct id", () => {
        expect(wizardComponent).toHaveLength(1)
    })
    it("should render with 2 Grid Rows. One for content and other for wizard controls", () => {
        expect(wizardRows).toHaveLength(2)
    })
    it("should render the wizard content above the wizard controls", () => {
        expect(wizardRows).toHaveLength(2)
        const contentRow = wizardRows.at(0)
        const contentDiv = contentRow.find("GridColumn").find("#contentDiv")
        expect(contentDiv).toHaveLength(1)
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        expect(controlColumns).toHaveLength(3)
    })
    it("should render prev button with NavigationRight icon when at step 2", () => {
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const prevIcon = controlColumns.at(0).find(".NavigationLeft")
        expect(prevIcon).toHaveLength(1)
    })
    it("should not render prev button when at step 1", () => {
        wrapper = shallow(
            <CarouselWizard numberOfSteps={mockProps.numberOfSteps}
                activeStep={{ ...mockProps.activeStep, stepNumber: 1 }}
                hideControlsOnLastStep={mockProps.hideControlsOnLastStep}
                onNextClicked={mockProps.onNextClicked}
                onPrevClicked={mockProps.onPrevClicked} />)
        const wizardRows = wrapper.find("#carouselWizardComponent").find("GridRow")
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const previousButton = controlColumns.at(0).find("FormattedMessage")
        expect(previousButton).toHaveLength(0)
    })
    it("should render next button with NavigationRight icon ", () => {
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const prevIcon = controlColumns.at(2).find(".NavigationRight")
        expect(prevIcon).toHaveLength(1)
    })

    it("should enable the next button based on the isNextEnabled property of the activeStep", () => {
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const next = controlColumns.at(2).find("Button")
        expect(next.prop("disabled")).toBe(false)
    })

    it("should disable the next button based on the isNextEnabled property of the activeStep", () => {
        wrapper = shallow(
            <CarouselWizard numberOfSteps={mockProps.numberOfSteps}
                activeStep={{ ...mockProps.activeStep, isNextEnabled: false }}
                hideControlsOnLastStep={mockProps.hideControlsOnLastStep}
                onNextClicked={mockProps.onNextClicked}
                onPrevClicked={mockProps.onPrevClicked} />)
        const wizardRows = wrapper.find("#carouselWizardComponent").find("GridRow")
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const next = controlColumns.at(2).find("Button")
        expect(next.prop("disabled")).toBe(true)
    })

    it("should enable the prev button based on the isPrevEnabled property of the activeStep", () => {
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const prev = controlColumns.at(0).find("Button")
        expect(prev.prop("disabled")).toBe(false)
    })

    it("should disable the prev button based on the isPrevEnabled property of the activeStep", () => {
        wrapper = shallow(
            <CarouselWizard numberOfSteps={mockProps.numberOfSteps}
                activeStep={{ ...mockProps.activeStep, isPrevEnabled: false }}
                hideControlsOnLastStep={mockProps.hideControlsOnLastStep}
                onNextClicked={mockProps.onNextClicked}
                onPrevClicked={mockProps.onPrevClicked} />)
        const wizardRows = wrapper.find("#carouselWizardComponent").find("GridRow")
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const prev = controlColumns.at(0).find("Button")
        expect(prev.prop("disabled")).toBe(true)
    })

    it("should render the given content", () => {
        const contentRow = wizardRows.at(0)
        expect(contentRow.contains(defaultContent)).toEqual(true)
    })
    it("should render step dots as per number of steps passed in", () => {
        const controlsRow = wizardRows.at(1)
        const controlColumns = controlsRow.find("GridColumn").find("Grid").find("GridColumn")
        const spanNodes = controlColumns.at(1).find("Grid").find("span")
        const stepDotNodes = spanNodes.findWhere((spanNode: any) => {
            return spanNode.key().indexOf("wizard_step_") > -1
        })
        expect(stepDotNodes).toHaveLength(mockProps.numberOfSteps)
    })
    it("should hide the wizard controls when at last step", () => {
        wrapper = shallow(
            <CarouselWizard numberOfSteps={mockProps.numberOfSteps}
                activeStep={{ ...mockProps.activeStep, stepNumber: 5 }}
                hideControlsOnLastStep={mockProps.hideControlsOnLastStep}
                onNextClicked={mockProps.onNextClicked}
                onPrevClicked={mockProps.onPrevClicked} />)
        const wizardRows = wrapper.find("#carouselWizardComponent").find("GridRow")
        expect(wizardRows).toHaveLength(1)
        const contentDiv = wizardRows.at(0).find("GridColumn").find("#contentDiv")
        expect(contentDiv).toHaveLength(1)
    })
    it("should render leave protocol transfer button and leave protocol transfer session", () => {
        const closeProtocolTransferButton = wizardRows.at(0).find("#leaveProtocolTransfer")
        closeProtocolTransferButton.simulate("click")
        expect(closeProtocolTransferButton).toBeDefined()
    })
})
