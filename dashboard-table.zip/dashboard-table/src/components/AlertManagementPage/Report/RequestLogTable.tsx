import React, { useEffect, useState } from "react";
import { Table } from "antd";
import "../../../assets/common/CommonTables.scss";

interface Props {
	data: any[];
	// handleClick: any;
	loading?: any;
}
const RequestLogTable = ({ data, loading }: Props) => {
	// Time Formate work :Start
	const [logTable, setLogTable] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				processStage: item.processStage,
				activityAction: item.activityAction,
				commentedByName: item.commentedByName,
				comments: item.comments,
				commentedOn: item.commentedOn,
				commentedByNTID: item.commentedByNTID,
				requestLogID: item.requestLogID,
				requestID: item.requestID,
				isActive: item.isActive,
				// View: <div onClick={() => handleClick(item.alertID)}>View</div>
				//View: <button type="button" className="cus-button">VIEW</button>,
			};
		});
		setLogTable(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "PROCESS STAGE",
			dataIndex: "processStage",
			key: "processStage",
			width: '10%',
		},
		{
			title: "ACTIVITY ACTION",
			dataIndex: "activityAction",
			key: "activityAction",
			width: '10%',
		},
		{
			title: "COMMENTED BY NAME",
			dataIndex: "commentedByName",
			key: "commentedByName",
			width: '10%',
		},
		{
			title: "COMMENTS",
			dataIndex: "comments",
			key: "comments",
			width: '10%',
		},
		{
			title: "COMMENTED ON",
			dataIndex: "commentedOn",
			key: "commentedOn",
			width: '10%',
		},
		{
			title: "COMMENTED BY BTTD ",
			dataIndex: "commentedByNTID",
			key: "commentedByNTID",
			width: '10%',
		},
		{
			title: "REQUEST LOG ID",
			dataIndex: "requestLogID",
			key: "requestLogID",
			width: '10%',
		},
		{
			title: "REQUEST ID",
			dataIndex: "requestID",
			key: "requestID",
			width: '10%',
		},
		{
			title: "ISACTIVE",
			dataIndex: "isActive",
			key: "isActive",
			width: '10%',
		},
		// {
		// 	title: "VIEW",
		// 	dataIndex: "View",
		// 	key: "View",
		// 	width: '10%',
		// },
	];
	const mobileColumns = [
		{
			title: "PROCESS STAGE",
			dataIndex: "processStage",
			key: "processStage",
			width: 50,
		},
		{
			title: "ACTIVITY ACTION",
			dataIndex: "activityAction",
			key: "activityAction",
			width: 80,
		},
		{
			title: "COMMENTED BY NAME",
			dataIndex: "commentedByName",
			key: "commentedByName",
			width: 100,
		},
		{
			title: "COMMENTS",
			dataIndex: "comments",
			key: "comments",
			width: 150,
		},
		{
			title: "COMMENTED ON",
			dataIndex: "commentedOn",
			key: "commentedOn",
			width: 130,
		},
		{
			title: "COMMENTED BY BTTD ",
			dataIndex: "commentedByNTID",
			key: "commentedByNTID",
			width: 150,
		},
		{
			title: "REQUEST LOG ID",
			dataIndex: "requestLogID",
			key: "requestLogID",
			width: 100,
		},
		{
			title: "REQUEST ID",
			dataIndex: "requestID",
			key: "requestID",
			width: 80,
		},
		{
			title: "ISACTIVE",
			dataIndex: "isActive",
			key: "isActive",
			width: 80,
		},
		// {
		// 	title: "VIEW",
		// 	dataIndex: "View",
		// 	key: "View",
		// 	width: 100,
		// },
	];

	return (
		<div>
			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Table
							loading={loading}
							columns={columns}
							dataSource={logTable}
							tableLayout="fixed"
							pagination={{ pageSize: 10 }}
							scroll={{ y: 200 }}
						/>
					);
				} else {
					return (
						<Table
							loading={loading}
							columns={mobileColumns}
							tableLayout={undefined}
							dataSource={logTable}
							pagination={{ pageSize: 10 }}
							scroll={{ x: '690px', y: 200 }}
						/>
					);
				}
			})()}
		</div>
	);
};

export default RequestLogTable;
