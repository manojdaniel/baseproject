/*
 * Created on Mon Oct 11 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import * as CallingUtility from "./CallingUtility"
import { ECallStatus } from "@rocc/rocc-client-services"

describe("Calling helper", () => {
    it("should return true if there is call going on", () => {
        const phoneCallStatus = ECallStatus.CALLING
        const videoCallStatus = [{ contextId: "", callStatus: ECallStatus.IDLE }]
        expect(CallingUtility.checkIfCallGoingOn(phoneCallStatus, videoCallStatus)).toBe(true)
    })
})
