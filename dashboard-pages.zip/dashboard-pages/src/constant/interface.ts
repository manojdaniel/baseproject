interface IBreadCrumbList {
    title: string;
    key: string;
}

export type {
    IBreadCrumbList
}