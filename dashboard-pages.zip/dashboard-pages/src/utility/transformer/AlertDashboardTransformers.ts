

export const stackedBarAssetTransformer = (data: any) => {
    let result = []
    result = Object.values(data.reduce((acc: any, cur: any) => {
        if (!acc[cur.assetID]) {
            acc[cur.assetID] = {
                assetID: cur.assetID,
                overdue: null,
                closed: null,
                "work in progress": null
            };
        }
        acc[cur.assetID][cur.state.toLowerCase()] += cur.count;
        return acc;
    }, {}));

    return result
}
export const stackedBarDepartmentTransformer = (data: any) => {
    let result = []
    result = Object.values(data.reduce((acc: any, cur: any) => {
        if (!acc[cur.department]) {
            acc[cur.department] = {
                department: cur.department,
                overdue: null,
                closed: null,
                under: null
            };
        }
        acc[cur.department][cur.state.toLowerCase()] += cur.count;
        return acc;
    }, {}));

    return result
}