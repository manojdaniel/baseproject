export const plantUtilizationResponseTime = [
    {
        "averageResponseTime": 33,
        "utilization": 83.45,
        "plantId": 55
    }
]

export const plantAlertListStateDropdownJSON = [
    {
        "state": "Overdue"
    },
    {
        "state": "Work in Progress"
    },
    {
        "state": "Active"
    }
]

export const plantAlertListDepartmentDropdownJSON = [
    {
        "department": "Digitalization Champion"
    },
    {
        "department": "Technology Enablement"
    }
]
