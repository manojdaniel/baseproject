"""
 Created on Thu Oct 01 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""
import os

from src.constants.constants import FAILED, FAILED_AT, HSDP_ORGANIZATION_ID, JOB_LIST, CURRENT_JOB, INIT, COMPLETED, JOB_NAME, INDEX, STATUS, ENTITY_ID, HSDP_IAM_URL, SERVICE_AUTH_ISSUER, \
    SERVICE_AUTH_PRIVATE_KEY, DATA, TRANSACTION_ID, TRANSACTION_DATA, ID, PROCESS_COMPLETE, TEMPLATE_DETAILS, SKIPPED, TEMPLATE_VERSION_1_0_3
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.raw_data_transformer import fetch_dict_from_transaction_id
from src.modules.db_operations.management_data_insertion.mgmt_data_insertion import fetch_tasks_for_job, get_service_job_transactions_details, \
    update_tasks_for_transaction, update_service_job_transaction_status, fetch_job_id_from_name, fetch_task_id_from_name, update_transaction_object_in_db
from src.modules.event_management.event_enums import EJobs, ETasks
from src.modules.event_management.event_publisher import publish_message
from src.modules.job_management.job_handler import JobHandler
from src.modules.validation_management.cc_data_validation import CcDataValidation
from src.modules.validation_management.eula_data_validation import EulaDataValidation
from src.modules.validation_management.kvm_config_data_validation import KvmConfigDataValidation
from src.modules.validation_management.rooms_data_validation import RoomsDataValidation
from src.modules.validation_management.site_data_validation import SiteDataValidation
from src.modules.validation_management.user_data_validation import UserDataValidation
from src.wrappers.graphql.connection.connection import get_client_connection
from src.wrappers.infrastructure_services.hsdp_iam_services.manage_token_services import create_service_token_from_vault
from src.wrappers.infrastructure_services.vault_services.manage_vault_services import get_path_specific_vault_values
from src.utility.semver import parse_version

LOG = create_logger("DataValidationJob")


class DataValidationJob(JobHandler):
    def __init__(self):
        self._success = False

    def start_job(self, payload):
        """
        Orchestrate all tasks in Job
        1. Fetch job_id from job name
        2. Fetch the task id for first job
        3. Fetch all tasks under this job id
        4. Update the transaction in db with current job_id and task_id
        5. Fetch corresponding transaction from transaction table
        6. Initiate execution of tasks in order
        7. After completion of all tasks in the Job send a RabbitMQ message
        8. Roll-back, if there is a failed task
        """
        try:
            self._payload = payload
            LOG.info(f"Starting Job: {self._payload[CURRENT_JOB]}")
            self._transaction_id = self._payload[TRANSACTION_ID]
            customer_vault_values = get_path_specific_vault_values(
                path_name=self._payload[ENTITY_ID])
            self._locale = customer_vault_values[DATA]["locale"]
            self._org_infra_uuid = customer_vault_values[DATA][HSDP_ORGANIZATION_ID]
            self._customer_service_token = create_service_token_from_vault(iam_url=os.environ.get(HSDP_IAM_URL),
                                                                           issuer=customer_vault_values[
                                                                               DATA][SERVICE_AUTH_ISSUER],
                                                                           private_key=customer_vault_values[DATA][SERVICE_AUTH_PRIVATE_KEY])
            self._client = get_client_connection(
                self._customer_service_token, org_infra_uuid=self._org_infra_uuid)

            self._job_id = fetch_job_id_from_name(
                EJobs.VALIDATE_ONBOARDED_DATA.value, self._client)
            task_id = fetch_task_id_from_name(
                ETasks.SITE_DATA_VALIDATION.value, self._client)

            self.fetch_all_tasks()
            self.update_transaction_details(
                transaction_id=self._transaction_id, job_id=self._job_id, task_id=task_id)

            self._data_dict, transaction_id = fetch_dict_from_transaction_id(
                self._transaction_id, self._client)
            LOG.info(f"fetch_dict_from_transaction_id: {transaction_id}")
            job_transaction_details = self.fetch_transaction_from_db(
                transaction_id=self._transaction_id)
            self._transaction_data = job_transaction_details[0][TRANSACTION_DATA]
            to_process = self.verify_if_task_complete(
                transaction_data=job_transaction_details[0][TRANSACTION_DATA])
            if to_process:
                self.update_transaction_in_db_wrt_job(status=INIT,
                                                      task_name=ETasks.SITE_DATA_VALIDATION.value,
                                                      job_status_update=True,
                                                      update_record_status=False)
                self.execute_tasks()
                self._payload[PROCESS_COMPLETE] = True
            else:
                self._payload[PROCESS_COMPLETE] = False
                LOG.info(
                    f"Not initiating job {self._payload['CURRENT_JOB']} since the previous Jobs are not complete")
            self._success = True
            self.post_message(payload=self._payload)
            LOG.info(f"Finished Job: {EJobs.VALIDATE_ONBOARDED_DATA.value}")
        except Exception as ex:
            LOG.exception(f"Failed to validate inserted data with error: {ex}")
            self.post_message(payload=self._payload,
                              error_message=repr(ex.args))

    def fetch_all_tasks(self):
        """Fetch all tasks under this job"""
        self._tasks_list = fetch_tasks_for_job(
            job_id=self._job_id, client=self._client)
        LOG.info(
            f"List of Tasks needed to be performed, {self._tasks_list} ,for current job id, {self._job_id}")

    def fetch_transaction_from_db(self, transaction_id):
        """Fetch corresponding transaction from transaction table"""
        transaction_details = get_service_job_transactions_details(
            transaction_id, client=self._client)
        LOG.info(
            f"Fetch job details for transaction_id, {transaction_id} is successful")
        return transaction_details

    def update_transaction_in_db_wrt_job(self, status, task_name, job_status_update=False, update_record_status=False, error_reason=""):
        """Update corresponding transaction from transaction table"""
        if update_record_status:
            """Update corresponding transaction from transaction table"""
            update_service_job_transaction_status(transaction_id=self._transaction_id,
                                                  status=status,
                                                  client=self.client)
            LOG.info(
                f"Job Status transaction_id, {self._transaction_id} updated and status is, {status}")
        self._transaction_data = update_tasks_for_transaction(transaction_id=self._transaction_id,
                                                              job_id=self._job_id,
                                                              task_id=([x for x in self._tasks_list if x["task_name"] == task_name][0])[
                                                                  ID],
                                                              transaction_data_object=self._transaction_data,
                                                              status=status,
                                                              client=self._client,
                                                              job_status_update=job_status_update,
                                                              reason=error_reason)

    def update_transaction_details(self, transaction_id, job_id, task_id):
        LOG.info(
            f"Updating the current job{EJobs.VALIDATE_ONBOARDED_DATA} details in transaction table for transaction_id {transaction_id}")
        update_transaction_object_in_db(
            job_id=job_id, task_id=task_id, transaction_id=transaction_id, client=self._client)

    def execute_tasks(self):
        """
        TASKS:
        - SITE_DATA_VALIDATION
        - CC_DATA_VALIDATION
        - ROOMS_DATA_VALIDATION
        - USERS_DATA_VALIDATION
        - EULA_DATA_VALIDATION
        """
        # Handle Site data validation
        site_validation = SiteDataValidation(
            service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
        self._data_dict, self._transaction_data = site_validation.initiate_data_validation(
            data_dict=self._data_dict, transaction_data=self._transaction_data)

        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.SITE_DATA_VALIDATION.value)

        # Handle Command Center data validation
        cc_validation = CcDataValidation(
            service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
        self._data_dict, self._transaction_data = cc_validation.initiate_data_validation(
            data_dict=self._data_dict, transaction_data=self._transaction_data)
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.CC_DATA_VALIDATION.value)

        # Handle Rooms data validation
        rooms_validation = RoomsDataValidation(
            service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
        self._data_dict, self._transaction_data = rooms_validation.initiate_data_validation(
            data_dict=self._data_dict, transaction_data=self._transaction_data)
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.ROOMS_DATA_VALIDATION.value)

        # Handle User Data validation
        user_validation = UserDataValidation(
            service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
        self._data_dict, self._transaction_data = user_validation.initiate_data_validation(
            data_dict=self._data_dict, transaction_data=self._transaction_data)
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.USERS_DATA_VALIDATION.value)

        # Handle Eula Data validation
        eula_validation = EulaDataValidation(
            service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
        self._data_dict = eula_validation.initiate_data_validation(
            self._payload["ENTITY_ID"], data_dict=self._data_dict, locale=self._locale)
        self.update_transaction_in_db_wrt_job(
            COMPLETED, ETasks.EULA_DATA_VALIDATION.value, job_status_update=True)

        if parse_version(self._data_dict[TEMPLATE_DETAILS]["version"]) >= parse_version(TEMPLATE_VERSION_1_0_3):
            kvm_data_validation = KvmConfigDataValidation(
                service_token=self._customer_service_token, org_infra_uuid=self._org_infra_uuid)
            self._data_dict, self._transaction_data = kvm_data_validation.initiate_data_validation(
                data_dict=self._data_dict, transaction_data=self._transaction_data)
            self.update_transaction_in_db_wrt_job(
                COMPLETED, ETasks.KVM_CONFIGURATION_DATA_VALIDATION.value, job_status_update=True)
        else:
            LOG.info(
                f"Skipping task : {ETasks.KVM_CONFIGURATION_DATA_VALIDATION.value} since version is below template version {TEMPLATE_VERSION_1_0_3}")
            self.update_transaction_in_db_wrt_job(
                SKIPPED, ETasks.KVM_CONFIGURATION_DATA_VALIDATION.value, job_status_update=True)

    def post_message(self, payload, error_message=""):
        """
        1. Post message to RabbitMQ with Payload
        """
        try:
            if self._success:
                LOG.info(
                    "Publishing a rabbitMQ message after completing current Job: DataValidationJob")
                current_record = list(filter(
                    lambda item: item[JOB_NAME] == EJobs.VALIDATE_ONBOARDED_DATA.value, payload[JOB_LIST]))[0]
                for job in payload[JOB_LIST]:
                    if job[JOB_NAME] == EJobs.VALIDATE_ONBOARDED_DATA.value:
                        job[STATUS] = COMPLETED
                    if job[INDEX] == current_record[INDEX] + 1:
                        payload[CURRENT_JOB] = job[JOB_NAME]
                        job[STATUS] = INIT
            else:
                self.update_transaction_in_db_wrt_job(
                    FAILED, ETasks.EULA_DATA_VALIDATION.value, job_status_update=True, error_reason=error_message)
                payload[CURRENT_JOB] = EJobs.FAILED.value
                payload[FAILED_AT] = EJobs.VALIDATE_ONBOARDED_DATA.value
                LOG.warn(
                    f"Publishing FAILED rabbitMQ message, since the current job: {EJobs.VALIDATE_ONBOARDED_DATA.value} is failed")
            publish_message(payload=payload)
        except Exception as ex:
            LOG.error(f"Failed to post message with error: {ex}")

    def roll_back_on_failure(self, tasks, failed_tasks):
        """ Roll-back, if there is a failed task """

    def check_if_task_is_complete(self, transaction_data):
        is_complete = True
        in_complete_task = list(filter(
            lambda items: items["status"] != COMPLETED and items["status"] != SKIPPED, transaction_data))
        if len(in_complete_task) > 0:
            is_complete = False
            LOG.info(
                f"Details of Tasks that are not completed are ,{in_complete_task}")

        return is_complete

    def verify_if_task_complete(self, transaction_data):
        to_process_flag = True
        for job_transaction in transaction_data["jobs"]:
            if job_transaction["name"] == EJobs.CUSTOMER_DATA_INSERTION.value:
                to_process_flag = self.check_if_task_is_complete(
                    transaction_data=job_transaction["tasks"])

        return to_process_flag
