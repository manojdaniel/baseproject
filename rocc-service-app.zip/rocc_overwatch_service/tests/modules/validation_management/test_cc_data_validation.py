import unittest
from unittest.mock import patch
from src.modules.validation_management.cc_data_validation import CcDataValidation


class CcDataValidationTest(unittest.TestCase):
    @patch("src.modules.validation_management.cc_data_validation.get_client_connection", side_effect=lambda service_token, org_infra_uuid: {"data": {"hsdpOrganizationId": "abc"}})
    @patch("src.modules.validation_management.cc_data_validation.update_summary_for_entity", side_effect=lambda param_1, param_2, param_3, param_4: {"data": {"success"}})
    def test_cc_data_validation(self, con, update_summery):
        con.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        update_summery.return_value = {"data": "success"}
        cc_data_validation = CcDataValidation("service-token", "org-uuid")
        cc_data_validation._transaction_data = {
            "summary": {
                "cc": {
                    "new": "abc"
                }
            }
        }
        cc_data_validation.update_summary_object("cc", {"isPresent": False,
                                                        "Receiver IP (To be filled by Philips)": ""}, "abc")
        cc_data_validation.update_summary_object("cc", {"isPresent": False,
                                                        "Receiver IP (To be filled by Philips)": ""}, "")
        self.assertIsNotNone(cc_data_validation)

    @patch("src.modules.validation_management.cc_data_validation.get_client_connection", side_effect=lambda service_token, org_infra_uuid: {"data": {"hsdpOrganizationId": "abc"}})
    @patch("src.modules.validation_management.cc_data_validation.update_summary_for_entity", side_effect=lambda param_1, param_2, param_3, param_4: {"data": {"success"}})
    def test_cc_data_validation_1(self, con, update_summery):
        con.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        update_summery.return_value = {"data": "success"}
        cc_data_validation = CcDataValidation("service-token", "org-uuid")
        cc_data_validation._transaction_data = {
            "summary": {
                "cc": {
                    "new": {}
                }
            }
        }
        cc_data_validation.initiate_data_validation({"COMMAND_CENTERS_DICT": {}, "TEMPLATE_DETAILS": {
            "version": "1"
        }}, cc_data_validation._transaction_data)
        self.assertIsNotNone(cc_data_validation)
