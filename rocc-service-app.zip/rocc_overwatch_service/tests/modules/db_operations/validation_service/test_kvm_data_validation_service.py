import unittest
from unittest.mock import Mock
from src.constants.headers import EXCEL_KVM_BOXILLA_REST_USER_NAME, EXCEL_KVM_BOXILLA_IP, EXCEL_KVM_BOXILLA_USER_NAME
from src.modules.db_operations.validation_service.kvm_data_validation_service import check_if_data_exists


class KvmDataValidationTest(unittest.TestCase):
    def check_if_data_exists(self):
        org_db_id = {}
        kvm_details = {}
        kvm_details[EXCEL_KVM_BOXILLA_IP] = "Hospital/DIC Identifier- To be filled by Philips"
        kvm_details[EXCEL_KVM_BOXILLA_USER_NAME] = "hospital city"
        kvm_details[EXCEL_KVM_BOXILLA_REST_USER_NAME] = ""
        returned_data = check_if_data_exists({}, kvm_details, org_db_id)
        self.assertIsNone(returned_data)

    def test_check_if_data_exists_with_no_data(self):
        kvm_details = {"EXCEL_KVM_BOXILLA_IP": "KVM Boxilla IP- To be filled by Philips",
        "EXCEL_KVM_BOXILLA_USER_NAME": "KVM Boxilla User Name - To be filled by Philips",
        "EXCEL_KVM_BOXILLA_REST_USER_NAME": "KVM Boxilla Rest User Name - To be filled by Philips"}
        kvm_details = Mock()
        kvm_details.execute.return_value = {
            "boxilla_user_name": [
                {"id": 100, "data": "construct_kvm_boxilla_object"}
            ]
        }
        returned_data = check_if_data_exists({}, kvm_details, {})
        self.assertIsNotNone(returned_data)
