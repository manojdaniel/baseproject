/*
 * Created on Fri Nov 11 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2022 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { shallow } from "enzyme"
import React, { Fragment } from "react"
import { mockedGlobalStore } from "./mocks/mock-data"
import SidebarContentFeature from "./SidebarContentFeature"

jest.mock("./common/modules/child-apps-setup/ChildAppsSetup", () => {
    return <></>
})
jest.mock("@rocc/rocc-http-client", () => ({
    useRoccHttpClient: jest.fn(),
    HttpClientProvider: <Fragment />
}))
jest.mock("./common/helpers/apicall", () => ({
    setupAxiosHandler: jest.fn(),
}))

jest.mock("redux-micro-frontend", () => {
    return mockedGlobalStore
})
jest.mock("react-redux", () => ({
    Provider: <Fragment />
}))

describe("SidebarContentFeature test cases", () => {

    it("SidebarContentFeature should be rendered with id", () => {
        const wrapper = shallow(<SidebarContentFeature contacts={[]} />)
        const sidebarContent = wrapper.find("SidebarContent")
        expect(sidebarContent).toHaveLength(1)
    })
})
