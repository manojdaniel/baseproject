"""
 Created on Wed Oct 28 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

import time
import json
import requests

from src.loggers.log import create_logger
from src.constants.constants import API_VERSION, CONTENT_TYPE, APPLICATION_JSON, AUTHORIZATION, SEP

LOG = create_logger("ManageHSDPOrgServices")


def create_org_service(idm_url, parent_org_id, token, customer_name):
    LOG.info(f"Creating HSDP Org for customer: {customer_name}")
    org_id = 0
    error_reasn = ""
    iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                   AUTHORIZATION: f"Bearer {token}", API_VERSION: "2"}
    org_data = {
        "schemas": [
            "urn:ietf:params:scim:schemas:core:philips:hsdp:2.0:Organization"
        ],
        "name": customer_name,
        "description": customer_name,
        "parent": {
            "value": parent_org_id
        }
    }
    try:
        response = requests.post(f"{idm_url}/authorize/scim/v2/Organizations",
                                 data=json.dumps(org_data),
                                 headers=iam_headers)
        if response.status_code == 201:
            org_id = response.json()["id"]
            LOG.info(
                f"Org created for customer: {customer_name} with id: {org_id}\n")
        elif response.status_code == 409:
            error_reasn = f"Org: {customer_name} is already present."
            LOG.error(f"Org: {customer_name} is already present.")
            LOG.warning("Please delete the org and re-try")
        elif response.status_code == 422:
            LOG.error(f"Org: {parent_org_id} is invalid.")
            error_reasn = f"Org: {parent_org_id} is invalid."
        else:
            LOG.error(
                f"Org Creation Failed with error: {response.json()['detail']}")
            error_reasn = f"Org Creation Failed with error: {response.json()['detail']}"
    except Exception as ex:
        LOG.exception("Org Creation Failed.")
        error_reasn = f"Org Creation Failed.{repr(ex.args)}"
    return org_id, error_reasn


def get_org_details_from_org_id_service(idm_url, org_id, token):
    try:
        iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {token}", API_VERSION: "2"}
        response = requests.get(f"{idm_url}/authorize/scim/v2/Organizations/{org_id}",
                                headers=iam_headers)
        if response.status_code == 200:
            LOG.info(
                f"Org details for org_id: {org_id} are\n: {response.json()}\n{SEP}")
            return response.json()
        else:
            LOG.info(
                f"Org details for org_id: {org_id} are not found or failed with\n: {json.dumps(response.json())}")
    except Exception as ex:
        LOG.error(
            f"Fetching org details for org_id: {org_id} failed with\n: {ex}")
        raise ex


def delete_org_service(idm_url, org_id, token):
    try:
        iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {token}", API_VERSION: "2", "If-Method": "DELETE"}
        response = requests.delete(f"{idm_url}/authorize/scim/v2/Organizations/{org_id}",
                                   headers=iam_headers)
        if response.status_code == 202:
            LOG.info(f"Delete of org: {org_id} initiated")
            ctr = 0
            while ctr < 10:
                ctr = ctr + 1
                del_response = delete_org_status(
                    idm_url=idm_url, org_id=org_id, token=token)
                if del_response == "IN_PROGRESS":
                    time.sleep(15)
                else:
                    ctr = 10
            return True

        else:
            LOG.error(
                f"Deletion of org failed with: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.exception(f"Deletion of org failed with: {ex}")

    return False


def delete_org_status(idm_url, org_id, token):
    try:
        iam_headers = {CONTENT_TYPE: APPLICATION_JSON,
                       AUTHORIZATION: f"Bearer {token}", API_VERSION: "2", "If-Method": "DELETE"}
        response = requests.get(f"{idm_url}/authorize/scim/v2/Organizations/{org_id}/deleteStatus",
                                headers=iam_headers)
        if response.status_code == 200:
            LOG.info(
                f"Delete of org: {org_id} current status: {response.json()['status']}")
            return response.json()["status"]
        else:
            LOG.error(
                f"Checking of deletion of org status failed with: {json.dumps(response.json())}")
            response.raise_for_status()
    except Exception as ex:
        LOG.error(f"Checking of deletion of org status failed with: {ex}")
