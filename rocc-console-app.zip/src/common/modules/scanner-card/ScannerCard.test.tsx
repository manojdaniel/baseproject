/*
 * Created on Wed Nov 11 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EUserPresence } from "@rocc/rocc-client-services"
import { shallow } from "enzyme"
import React from "react"
import ScannerCard from "./ScannerCard"

jest.mock("../../../assets/images/MR.svg")
jest.mock("../../../assets/images/CT.svg")

describe("ScannerCard component", () => {
    let wrapper: any
    let scannerCard: any
    let cardContent: any
    const mockProps = {
        hospitalLocation: "Bond St. Community Hospital",
        isHighlighted: true,
        roomDetails: {
            identity: { id: 1, name: "CT Room-004", uuid: "5080ba3d-f77c-4962-a38e-ea1620f58fe8" },
            locationId: 1, address: "Research Department", modality: "CT", modalityId: "", favourite: true, phoneNumber: "",
            presenceData: { presence: EUserPresence.IN_CALL, mapId: "" },
            disabled: false,
            isConnecting: false,
            loggedInTech: { techUuid: "", techName: "" },
            isRoomStarred: false,
            monitorsCount: 1
        }
    }
    beforeEach(() => {
        wrapper = shallow(<ScannerCard room={mockProps.roomDetails} hospitalLoc={mockProps.hospitalLocation} isHighlighted={mockProps.isHighlighted} />)
        scannerCard = wrapper.find("#scannerCard")
        cardContent = scannerCard.find("CardContent")
    })

    it("should render 1 card", () => {
        expect((scannerCard).find("Card")).toHaveLength(1)
    })

    it("should render card with 1 card content", () => {
        expect(cardContent).toHaveLength(1)
    })

    it("should render card content with 2 grid columns", () => {
        expect(cardContent.at(0).find("Grid").at(0).find("GridColumn")).toHaveLength(2)
    })

    it("should render Grid columns with 1 div and 3 card descriptions", () => {
        const gridColumn = cardContent.at(0).find("Grid").at(0).find("GridColumn")
        expect(gridColumn.at(0).find("div")).toHaveLength(1)
        expect(gridColumn.at(1).find("CardDescription")).toHaveLength(3)
    })

    it("should render first column with CT or MR image ", () => {
        const gridColumn = cardContent.at(0).find("Grid").at(0).find("GridColumn")
        expect(gridColumn.at(0).find("div").at(0).find("InlineSVG").prop("src")).toBeDefined()
    })

    it("should render component as per the props", () => {
        const gridColumn = cardContent.at(0).find("Grid").at(0).find("GridColumn")
        expect(gridColumn.at(1).find("CardDescription").at(0).contains(mockProps.hospitalLocation)).toEqual(true)
        expect(gridColumn.at(1).find("CardDescription").at(1).contains(mockProps.roomDetails.identity.name)).toEqual(true)
        expect(gridColumn.at(1).find("CardDescription").at(2).contains(mockProps.roomDetails.address)).toEqual(true)
    })
})
