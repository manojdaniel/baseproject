import unittest
from unittest.mock import Mock, patch, call
from src.constants.constants import RETURNING

from tests.mocks.random import rand_string
from tests.mocks.mock_rooms import generate_mock_rooms, prepare_room_db_mapping
from src.modules.db_operations.insertion_services.room_db_services import *


class RoomCheckCommunicationMappingTestCase(unittest.TestCase):
    def setUp(self):
        self.complete_room = {
            "instance_id": rand_string(10),
            "communication_profile": rand_string(10),
            "rbac_mapping": rand_string(10),
        }

        self.all_expected_messages = [
            f"Instance identity mapping is not created.",
            f"Communication profile mapping is not created.",
            f"Rbac role mapping is not created."
        ]

    def test_check_communication_mapping_no_instance_id(self):
        room = empty_key(self.complete_room, ["instance_id"])

        expected_messages = [self.all_expected_messages[0]]

        is_eligible, messages = check_if_communication_mappings_are_created_for_room(room)

        self.assertFalse(is_eligible, "Incorrect eligibility validation result")
        self.assertListEqual(messages, expected_messages, "Message were not generated as expected: {}".format(messages))

    def test_check_communication_mapping_no_communication_profile(self):
        room = empty_key(self.complete_room, ["communication_profile"])

        expected_messages = [self.all_expected_messages[1]]

        is_eligible, messages = check_if_communication_mappings_are_created_for_room(room)

        self.assertFalse(is_eligible, "Incorrect eligibility validation result")
        self.assertListEqual(messages, expected_messages, "Message were not generated as expected: {}".format(messages))

    def test_check_communication_mapping_no_rbac_mapping(self):
        room = empty_key(self.complete_room, ["rbac_mapping"])

        expected_messages = [self.all_expected_messages[2]]

        is_eligible, messages = check_if_communication_mappings_are_created_for_room(room)

        self.assertFalse(is_eligible, "Incorrect eligibility validation result")
        self.assertListEqual(messages, expected_messages, "Message list tested {}".format(messages))

    def test_check_communication_mapping_full(self):
        room = self.complete_room

        is_eligible, messages = check_if_communication_mappings_are_created_for_room(room)

        self.assertTrue(is_eligible, "Incorrect eligibility validation result")
        self.assertFalse(len(messages), "Message were not generated as expected: {}".format(messages))


class InsertRoomDataTestCase(unittest.TestCase):
    def setUp(self):
        self.transaction_data = {
            "summary": {
                "rooms": {state.value: [] for state in ESummaryStates}
            }
        }
        self.new_rooms_dict, self.new_rooms_dict_scanner = generate_mock_rooms(newCount=2, existingCount=0)
        self.existing_rooms_dict, self.existing_rooms_dict_scanner = generate_mock_rooms(newCount=0, existingCount=2)
        self.mixed_rooms_dict = dict(self.existing_rooms_dict, **self.new_rooms_dict)
        self.mixed_rooms_dict_scanner = dict(self.existing_rooms_dict_scanner, **self.new_rooms_dict_scanner)

        self.new_room_db_mapping, self.new_room_db_mapping_scanner = prepare_room_db_mapping(self.new_rooms_dict_scanner)

        self.result_object = "Results"
        self.mutation_results = {
            f"{INSERT}{RESOURCES}": {
                f"{RETURNING}": self.result_object
            }
        }

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_none_eligible(self, mock_mapping, mock_summary_update, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        errors = [rand_string(20), rand_string(20)]
        rooms = self.new_rooms_dict

        # Mock objects
        mock_client = Mock()

        # Mocked returns
        mock_mapping.return_value = False, errors
        mock_summary_update.return_value = self.transaction_data
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.INSERTION_FAILED) for room_id in self.new_rooms_dict.keys()
        ]
        logger_calls = [
            call(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since: {errors} ") for room in self.new_rooms_dict.values()
        ] + [
            call(f"Skipping room data insertion, since there are no eligible rooms")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list({}))

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_dicts_with_inserted_ids")
    @patch("src.modules.db_operations.room_data_services.room_db_services.extract_response_from_mutation_response")
    @patch("src.modules.db_operations.room_data_services.room_db_services.get_demographic_id_with_excel_header")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_some_eligible(
            self, mock_mapping, mock_summary_update, mock_demographic, mock_extract_mutation_response, mock_update_dicts, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        rooms = self.new_rooms_dict
        errors = [rand_string(20), rand_string(20)]
        faulty_room, insertable_rooms = dict(list(rooms.items())[:1]), dict(list(rooms.items())[1:])

        # Mock objects
        mock_client = Mock()

        # Side effects
        mock_mapping.side_effect = [(False, errors)] + [(True, [])] * (len(rooms.keys()) - 1)
        demographic_ids = [demo_data["demographic_type_id"] for room in list(self.new_room_db_mapping.values())[1:] for demo_data in room["resourcesByResourcesDemoId"]["data"]]
        mock_demographic.side_effect = demographic_ids

        # Mocked returns
        mock_client.execute.return_value = self.mutation_results
        mock_summary_update.return_value = self.transaction_data
        mock_extract_mutation_response.return_value = self.result_object
        mock_update_dicts.return_value = rooms
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", list(faulty_room.keys())[0], ESummaryStates.INSERTION_FAILED),
        ] + [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.NEW) for room_id in insertable_rooms.keys()
        ]
        logger_calls = [
            call(f"Skipping room: {list(faulty_room.values())[0][EXCEL_ROOM_IDENTIFIER]}, since: {errors} ")
        ] + [
            call(f"Room: {room[EXCEL_ROOM_IDENTIFIER]} is eligible for insertion") for room in insertable_rooms.values()
        ] + [
            call(f"Inserting data for rooms: {list(self.new_room_db_mapping.values())[1:]}")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_client.execute.assert_called_with(insert_rooms_in_bulk, variable_values={OBJECTS: list(self.new_room_db_mapping.values())[1:]})
        mock_extract_mutation_response.assert_called_with(self.mutation_results, f"{INSERT}{RESOURCES}")
        mock_update_dicts.assert_called_with(dicts=rooms,
                                             results=self.mutation_results[f"{INSERT}{RESOURCES}"][RETURNING],
                                             item_id_name="resource_id",
                                             item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                             result_unique_name="resource")
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list({}))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    def test_room_insertion_empty(self, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        rooms = {}

        # Mock objects
        mock_client = Mock()

        # Mocked returns
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion in execution order
        mock_info.assert_called_with(f"Skipping room data insertion, since there are no eligible rooms")
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list({}))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)

    # TODO: Mock extend_with_scanner_details
    # TODO: Test the TypeError and Exception branch
    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_dicts_with_inserted_ids")
    @patch("src.modules.db_operations.room_data_services.room_db_services.extract_response_from_mutation_response")
    @patch("src.modules.db_operations.room_data_services.room_db_services.get_demographic_id_with_excel_header")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_new(self, mock_mapping, mock_summary_update, mock_demographic, mock_extract_mutation_response, mock_update_dicts, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        rooms = self.new_rooms_dict

        # Mock objects
        mock_client = Mock()

        # Side effects
        demographic_ids = [demo_data["demographic_type_id"] for room in self.new_room_db_mapping.values() for demo_data in room["resourcesByResourcesDemoId"]["data"]]
        mock_demographic.side_effect = demographic_ids

        # Mocked returns
        mock_client.execute.return_value = self.mutation_results
        mock_mapping.return_value = True, []
        mock_summary_update.return_value = self.transaction_data
        mock_extract_mutation_response.return_value = self.result_object
        mock_update_dicts.return_value = rooms
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.NEW) for room_id in self.new_rooms_dict.keys()
        ]
        logger_calls = [
            call(f"Room: {room[EXCEL_ROOM_IDENTIFIER]} is eligible for insertion") for room in rooms.values()
        ] + [
            call(f"Inserting data for rooms: {list(self.new_room_db_mapping.values())}")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_client.execute.assert_called_with(insert_rooms_in_bulk, variable_values={OBJECTS: list(self.new_room_db_mapping.values())})
        mock_extract_mutation_response.assert_called_with(self.mutation_results, f"{INSERT}{RESOURCES}")
        mock_update_dicts.assert_called_with(dicts=rooms,
                                             results=self.mutation_results[f"{INSERT}{RESOURCES}"][RETURNING],
                                             item_id_name="resource_id",
                                             item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                             result_unique_name="resource")
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list({}))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_existing(self, mock_mapping, mock_summary_update, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        rooms = self.existing_rooms_dict

        # Mock objects
        mock_client = Mock()

        # Mocked returns
        mock_mapping.return_value = True, []
        mock_summary_update.return_value = self.transaction_data
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.EXISTING) for room_id in self.existing_rooms_dict.keys()
        ]
        logger_calls = [
            call(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since it is not a new room") for room in rooms.values()
        ] + [
            call(f"Skipping room data insertion, since there are no eligible rooms")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list(self.existing_rooms_dict.values()))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_dicts_with_inserted_ids")
    @patch("src.modules.db_operations.room_data_services.room_db_services.extract_response_from_mutation_response")
    @patch("src.modules.db_operations.room_data_services.room_db_services.get_demographic_id_with_excel_header")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_mixed(
            self, mock_mapping, mock_summary_update, mock_demographic, mock_extract_mutation_response, mock_update_dicts, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = False
        rooms = self.mixed_rooms_dict

        # Mock objects
        mock_client = Mock()

        # Side effects
        demographic_ids = [demo_data["demographic_type_id"] for room in self.new_room_db_mapping.values() for demo_data in room["resourcesByResourcesDemoId"]["data"]]
        mock_demographic.side_effect = demographic_ids

        # Mocked returns
        mock_client.execute.return_value = self.mutation_results
        mock_mapping.return_value = True, []
        mock_summary_update.return_value = self.transaction_data
        mock_extract_mutation_response.return_value = self.result_object
        mock_update_dicts.return_value = rooms
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.EXISTING) for room_id in self.existing_rooms_dict.keys()
        ] + [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.NEW) for room_id in self.new_rooms_dict.keys()
        ]
        logger_calls = [
            call(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since it is not a new room") for room in self.existing_rooms_dict.values()
        ] + [
            call(f"Room: {room[EXCEL_ROOM_IDENTIFIER]} is eligible for insertion") for room in self.new_rooms_dict.values()
        ] + [
            call(f"Inserting data for rooms: {list(self.new_room_db_mapping.values())}")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_client.execute.assert_called_with(insert_rooms_in_bulk, variable_values={OBJECTS: list(self.new_room_db_mapping.values())})
        mock_extract_mutation_response.assert_called_with(self.mutation_results, f"{INSERT}{RESOURCES}")
        mock_update_dicts.assert_called_with(dicts=rooms,
                                             results=self.mutation_results[f"{INSERT}{RESOURCES}"][RETURNING],
                                             item_id_name="resource_id",
                                             item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                             result_unique_name="resource")
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list(self.existing_rooms_dict.values()))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)

    @patch("src.modules.db_operations.room_data_services.room_db_services.create_logger.info")
    @patch("src.modules.db_operations.room_data_services.room_db_services.handle_existing_rooms")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_dicts_with_inserted_ids")
    @patch("src.modules.db_operations.room_data_services.room_db_services.extract_response_from_mutation_response")
    @patch("src.modules.db_operations.room_data_services.room_db_services.get_demographic_id_with_excel_header")
    @patch("src.modules.db_operations.room_data_services.room_db_services.update_summary_for_entity")
    @patch("src.modules.db_operations.room_data_services.room_db_services.check_if_communication_mappings_are_created_for_room")
    def test_room_insertion_scanner(
            self, mock_mapping, mock_summary_update, mock_demographic, mock_extract_mutation_response, mock_update_dicts, mock_handle_existing_rooms, mock_info):
        # Defining constants
        scanner_data_support = True
        rooms = self.mixed_rooms_dict_scanner

        # Mock objects
        mock_client = Mock()

        # Side effects
        demographic_ids = [demo_data["demographic_type_id"] for room in self.new_room_db_mapping_scanner.values() for demo_data in room["resourcesByResourcesDemoId"]["data"]]
        mock_demographic.side_effect = demographic_ids

        # Mocked returns
        mock_client.execute.return_value = self.mutation_results
        mock_mapping.return_value = True, []
        mock_summary_update.return_value = self.transaction_data
        mock_extract_mutation_response.return_value = self.result_object
        mock_update_dicts.return_value = rooms
        mock_handle_existing_rooms.return_value = rooms

        # Main Test Method
        returned_rooms, returned_transaction_data = insert_room_data_in_db(mock_client, rooms, self.transaction_data, scanner_data_support)

        # Assertion constants
        mapping_calls = [call(rooms[room_id]) for room_id in rooms.keys()]
        summary_calls = [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.EXISTING) for room_id in self.existing_rooms_dict_scanner.keys()
        ] + [
            call(self.transaction_data, "rooms", room_id, ESummaryStates.NEW) for room_id in self.new_rooms_dict_scanner.keys()
        ]
        logger_calls = [
            call(f"Skipping room: {room[EXCEL_ROOM_IDENTIFIER]}, since it is not a new room") for room in self.existing_rooms_dict_scanner.values()
        ] + [
            call(f"Room: {room[EXCEL_ROOM_IDENTIFIER]} is eligible for insertion") for room in self.new_rooms_dict_scanner.values()
        ] + [
            call(f"Inserting data for rooms: {list(self.new_room_db_mapping_scanner.values())}")
        ]

        # Assertion in execution order
        mock_info.assert_has_calls(logger_calls)
        mock_mapping.assert_has_calls(mapping_calls)
        mock_summary_update.assert_has_calls(summary_calls, any_order=True)
        mock_client.execute.assert_called_with(insert_rooms_in_bulk, variable_values={OBJECTS: list(self.new_room_db_mapping_scanner.values())})
        mock_extract_mutation_response.assert_called_with(self.mutation_results, f"{INSERT}{RESOURCES}")
        mock_update_dicts.assert_called_with(dicts=rooms,
                                             results=self.mutation_results[f"{INSERT}{RESOURCES}"][RETURNING],
                                             item_id_name="resource_id",
                                             item_excel_header=EXCEL_ROOM_IDENTIFIER,
                                             result_unique_name="resource")
        mock_handle_existing_rooms.assert_called_with(mock_client, rooms, list(self.existing_rooms_dict_scanner.values()))

        self.assertEqual(rooms, returned_rooms)
        self.assertEqual(self.transaction_data, returned_transaction_data)


if __name__ == "__main__":
    unittest.main()
