/*
 * Created on Thu May 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

/* API Method */
export const HTTP_METHOD = {
    POST: "POST"
}
/* API Headers Values*/
export const HTTP_HEADERS_VALUE = {
    APPLICATION_JSON: "application/json",
    ORG_ID_HEADER_TEXT: "Org-Id",
}
/* API Headers keys*/
export const HTTP_HEADERS_KEY = {
    CONTENT_TYPE: "Content-Type",
    AUTHORIZATION: "Authorization",
}
/** API Status codes */
export const STATUS_CODES = {
    OK: 200,
    CREATED: 201,
    UNAUTHORIZED: 401,
}
