import unittest
from unittest.mock import patch
from src.modules.insertion_management.manage_users import ManageUsers
from src.constants.constants import EMP_DICT, ROOMS_DICT, SITES_DICT


class ManageRoomsTest(unittest.TestCase):
    @patch("src.wrappers.infrastructure_services.vault_services.manage_vault_services.get_path_specific_vault_values")
    def test_start_job(self, mock_fn):
        mock_fn.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        data_dict = {}
        data_dict[ROOMS_DICT] = "room"
        data_dict[SITES_DICT] = "site"
        data_dict[EMP_DICT] = {}
        manage_user = ManageUsers(
            data_dict, {}, 1234, "abc", "kvm_config_id", {}, 11)
        self.assertIsNotNone(manage_user)

    @patch("src.wrappers.infrastructure_services.vault_services.manage_vault_services.get_path_specific_vault_values")
    def test_start_job_second(self, mock_fn):
        mock_fn.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        data_dict = {}
        data_dict[ROOMS_DICT] = "room"
        data_dict[SITES_DICT] = "site"
        data_dict[EMP_DICT] = {"abc": {"Email ID /Unique ID": "abc"}}
        manage_user = ManageUsers(
            data_dict, {}, 1234, "abc", "kvm_config_id", {}, 11)
        manage_user.convert_email_to_lowercase()
        self.assertIsNotNone(manage_user)

    @patch("src.wrappers.infrastructure_services.vault_services.manage_vault_services.get_path_specific_vault_values")
    def test_start_job_third(self, mock_fn):
        mock_fn.return_value = {"data": {"hsdpOrganizationId": "abc"}}
        data_dict = {}
        data_dict[ROOMS_DICT] = "room"
        data_dict[SITES_DICT] = "site"
        data_dict[EMP_DICT] = {"abc": {"Email ID /Unique ID": "abc"}}
        manage_user = ManageUsers(
            data_dict, {}, 1234, "abc", "kvm_config_id", {}, 11)
        with self.assertRaises(Exception):
            manage_user.add_new_users({})
        with self.assertRaises(Exception):
            manage_user.create_add_users_list()
        with self.assertRaises(Exception):
            manage_user.compute_user_eligibility()
        with self.assertRaises(Exception):
            manage_user.rollback_failed_users("abc")
