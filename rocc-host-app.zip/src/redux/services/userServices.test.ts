/*
 * Created on Thu Jan 5 2022
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { EResponse } from "@rocc/rocc-client-services"
import * as apiUtility from "../../utility/api/apiUtility"
import { closeSessionFromServer, logoutSession } from "./userServices"

const getAxiosResponse = (data: any, responseCode: number = 200) => {
    return {
        data: { ...data },
        status: responseCode,
        statusText: "OK",
        headers: {},
        config: {}
    }
}

describe("logoutSession tests", () => {
    const user: any = { sessionId: "session", accessToken: "accessToken", uuid: "uuid" }
    const authUrl = "http://localhost"
    it("should able to logout successfully", () => {
        const spy = jest.spyOn(apiUtility, "deleteService").mockReturnValue(Promise.resolve(getAxiosResponse({}, 204)))
        logoutSession(user, authUrl).then(response => {
            expect(response).toBe(EResponse.SUCCESS)
        })
        expect(spy).toBeCalled()
    })

    it("should not able to logout successfully", () => {
        const spy = jest.spyOn(apiUtility, "deleteService").mockReturnValue(Promise.reject(new Error()))
        logoutSession(user, authUrl).catch(response => {
            expect(response).toBe(EResponse.ERROR)
        })
        expect(spy).toBeCalled()
    })
})

describe("closeSessionFromServer tests", () => {
    const user: any = { sessionId: "session", accessToken: "accessToken", uuid: "uuid" }
    it("should able to close the session", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.resolve(getAxiosResponse({}, 204)))
        closeSessionFromServer(user, "")
        expect(spy).toBeCalled()
    })

    it("should not able to close the session", () => {
        const spy = jest.spyOn(apiUtility, "postService").mockReturnValue(Promise.reject(new Error()))
        closeSessionFromServer(user, "")
        expect(spy).toBeCalled()
    })
})
