import React, { useEffect, useState } from "react";
import { Table, Layout } from "antd";
import moment from "moment";
import { Pagination } from 'antd';
import { getDateTimeFormatted } from "../../utility/helper";
import "../../assets/common/CommonTables.scss";


interface Props {
	data: any[];
	page: any;
	setPage: any;
	loading?: any;
}
const LiveTrackingTable = ({ data, page, setPage, loading }: Props) => {
	// Time Formate work :Start
	const [livetrackinglist, setLivetrackinglist] = useState<any>();
	const [currentScreenWidth, setCurrentScreenWidth] = useState<number>(0);
	useEffect(() => {
		setCurrentScreenWidth(window.innerWidth);
		let mydata = data.map(function (item: any) {
			return {
				//timeStamp: moment(new Date(`${item.timeStamp}`)).format("DD/MM/YYYY HH:MM:SS A"),
				timeStamp: getDateTimeFormatted(item.timeStamp),
				status: item.status,
				modelName: item.modelName,
				influencingSensor1: item.influencingSensor1,
				influencingSensor2: item.influencingSensor2,
				influencingSensor3: item.influencingSensor3,
				influencingSensor4: item.influencingSensor4,
				influencingSensor5: item.influencingSensor5,
				influencingSensor6: item.influencingSensor6,
			};
		});
		setLivetrackinglist(mydata);
	}, [data]);
	// Time Formate work :End
	const columns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: currentScreenWidth > 1200 ? "9%" : "5%",
		},
		{
			title: "MODEL STATUS",
			dataIndex: "status",
			key: "status",
			width: "5%",
		},

		{
			title: "MODEL NAME",
			dataIndex: "modelName",
			key: "modelName",
			width: "10%",
		},
		{
			title: "INFLUENCING SENSOR1",
			dataIndex: "influencingSensor1",
			key: "influencingSensor1",
			width: "12%",
		},
		{
			title: "INFLUENCING SENSOR2",
			dataIndex: "influencingSensor2",
			key: "influencingSensor2",
			width: "14%",
		},
		{
			title: "INFLUENCING SENSOR3",
			dataIndex: "influencingSensor3",
			key: "influencingSensor3",
			width: "14%",
		},
		{
			title: "INFLUENCING SENSOR4",
			dataIndex: "influencingSensor4",
			key: "influencingSensor4",
			width: "14%",
		},
		{
			title: "INFLUENCING SENSOR5",
			dataIndex: "influencingSensor5",
			key: "influencingSensor5",
			width: "14%",
		},
		{
			title: "INFLUENCING SENSOR6",
			dataIndex: "influencingSensor6",
			key: "influencingSensor6",
			width: "14%",
		},
	];

	const mobileColumns = [
		{
			title: "TIME STAMP",
			dataIndex: "timeStamp",
			key: "timeStamp",
			width: 100,
		},
		{
			title: "MODEL STATUS",
			dataIndex: "status",
			key: "status",
			width: 100,
		},

		{
			title: "MODEL NAME",
			dataIndex: "modelName",
			key: "modelName",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR1",
			dataIndex: "influencingSensor1",
			key: "influencingSensor1",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR2",
			dataIndex: "influencingSensor2",
			key: "influencingSensor2",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR3",
			dataIndex: "influencingSensor3",
			key: "influencingSensor3",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR4",
			dataIndex: "influencingSensor4",
			key: "influencingSensor4",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR5",
			dataIndex: "influencingSensor5",
			key: "influencingSensor5",
			width: 100,
		},
		{
			title: "INFLUENCING SENSOR6",
			dataIndex: "influencingSensor6",
			key: "influencingSensor6",
			width: 100,
		},
	];
	return (
		<>

			{(() => {
				if (currentScreenWidth > 1200) {
					return (
						<Layout style={{ minHeight: "100%" }}>
							<Table
								loading={loading}
								columns={columns}
								dataSource={livetrackinglist}
								tableLayout="fixed"
								pagination={{ pageSize: 10, showSizeChanger: false }}
							/>
						</Layout>
					);
				} else {
					return (
						<Layout style={{ minHeight: "100%", }}>
							<Table
								loading={loading}
								columns={mobileColumns}
								tableLayout={undefined}
								dataSource={livetrackinglist}
								pagination={{ pageSize: 10, showSizeChanger: false }}
								scroll={{ x: '900px' }}
							/>
						</Layout>
					);
				}
			})()}
			{/* <Layout style={{ minHeight: "100%" }}>
			<Table
				loading={loading}
				tableLayout={undefined}
				scroll={{ x: true }}
				columns={columns}
				dataSource={livetrackinglist}
			// pagination={{
			// 	current: page,
			// 	total: 5,
			// 	onChange: (page) => {
			// 		setPage(page);
			// 	},
			// }}
			/>
			</Layout> */}
			{/* <Pagination
				style={{ display: "flex", justifyContent: "flex-end", marginTop: "30px" }}
				defaultCurrent={page}
				total={50}
				onChange={(page) => setPage(page)}
			/> */}
		</>
	);
};

export default LiveTrackingTable;
