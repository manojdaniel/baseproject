/*
 * Created on Mon Nov 12 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, EConnectionMode, EConnectionState, EConnectionType, ERoccWorkflow, ETransactionStatus, IWorkflow } from "@rocc/rocc-client-services"
import configureMockStore, { MockStoreEnhanced } from "redux-mock-store"
import thunk from "redux-thunk"
import * as helpers from "../../common/helpers/helpers"
import { ECommandCenterAccessMode, IStore } from "../interfaces/types"
import { DEFAULT_CONSOLE_OPERATIONS } from "../reducers/consoleReducer"
import { dispatchToParentStore, fetchRooms } from "../store/externalAppStates"
import { registerWorkflow, resetConsoleSession, sendWorkflowEvent, setConsoleOperations, updateCommandCenterSeat, updateConsoleSession, updatePidMapping, updateRoomCameraAvailability, updateSpecificDataToTransaction, updateSpecificDataToTransactionGroup } from "./consoleActions"

const middlewares = [thunk]
const mockStore = configureMockStore(middlewares)

jest.mock("../store/externalAppStates", () => ({
    fetchGlobalURLs: jest.fn().mockReturnValue({
        MANAGEMENT_SERVICE_URL: "MANAGEMENT_SERVICE_URL",
    }),
    fetchGlobalCurrentUser: jest.fn().mockReturnValue({}),
    dispatchToParentStore: jest.fn(),
    fetchRooms: jest.fn(),
}))

jest.mock("../store/syncSessions", () => ({
    syncSessions: jest.fn()
}))

jest.mock("../store/globalStore", () => ({
    CreateStore: jest.fn()
}))

jest.mock("../store/store", () => ({
    store: jest.fn(),
    persistor: jest.fn(),
    getState: jest.fn().mockReturnValue({
        externalReducer: {
            featureFlags: {
                "rocc-room-monitoring": false,
                "multi-edit-without-park-and-resume": false
            },
        }
    })
}))

jest.mock("../store/syncSessions", () => ({
    __esModule: true, // this property makes it work
    default: {
        postMessage: jest.fn().mockReturnValue({})
    }
}))

jest.mock("redux-micro-frontend", () => ({
    GlobalStore: {
        Get: jest.fn().mockReturnValue({
            GetGlobalState: jest.fn().mockReturnValue({
                CC_HOST: {
                    configReducer: { configs: { ROCC_DEV: "false" } }
                }
            }),
            DispatchAction: jest.fn(),
        })
    }
}))

describe("console Actions tests", () => {
    const workflow = {
        id: "selector",
        type: ERoccWorkflow.PARK_AND_INITIATE_CALL,
        workflow: {} as IWorkflow["workflow"],
        state: {} as IWorkflow["state"],
        eventQueue: []
    }
    const consoleSession = [{
        contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: "", connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC,
        requester: "", connectionStatus: EConnectionState.DEFAULT, receiverName: "", displayCameraToggle: false,
        mediaRoomDetails: {
            cameraStreamAvailable: ECameraStreamAvailable.IDLE,
            mediaRoomId: "",
            mediaRoomToken: ""
        },
        multiCameraList: [{
            cameraStreamName: "",
            selected: false
        }]
    }]
    const mockData = {
        externalReducer: {
            currentUser: {
                id: "1",
                accessToken: "token"
            },
            featureFlags: {
                "rocc-room-monitoring": false,
                "multi-edit-without-park-and-resume": false
            },
            workflows: [workflow],
            activeTabIndex: 1
        },
        consoleReducer: {
            consoleSessions: [{ contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC },],
            commandCenterDetails: { initialised: false, commandCenterSeat: { organizationId: "", seatName: "", receivers: [] } },
            consoleOperation: DEFAULT_CONSOLE_OPERATIONS,
            consoleMessages: []
        }
    }
    let store: MockStoreEnhanced<unknown, {}>

    beforeEach(() => {
        store = mockStore(mockData)
        store.clearActions()
    })

    it("updateConsoleSession is defined", () => {
        const consoleSession: any = { contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC }
        store.dispatch(updateConsoleSession(consoleSession, true) as any)
        expect(store.getActions()[0].consoleSessions.length).toBe(1)
        store.clearActions()
    })

    it("updateConsoleSession for new session is defined", () => {
        const consoleSession: any = { contextId: "contextId1", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC }
        store.dispatch(updateConsoleSession(consoleSession, true) as any)
        expect(store.getActions()[0].consoleSessions.length).toBe(2)
        store.clearActions()
    })

    it("updateConsoleSession to remove existing sessionis defined", () => {
        const consoleSession: any = { contextId: "contextId", roomUuid: "roomUuid", consoleStartTime: new Date(), connectionType: EConnectionType.VIEW, connectionMode: EConnectionMode.CC }
        store.dispatch(updateConsoleSession(consoleSession, false) as any)
        expect(store.getActions()[0].consoleSessions.length).toBe(0)
        store.clearActions()
    })

    it("define registerWorkflow and dispatch REGISTER_WORKFLOW action", () => {
        store.dispatch(registerWorkflow(ERoccWorkflow.LOGOUT) as any)
        expect(dispatchToParentStore).toBeCalledWith(expect.objectContaining({ type: "REGISTER_WORKFLOW", payload: { type: "LOGOUT" } }))
        store.clearActions()
    })
    it("define sendWorkflowEvent and dispatch ADD_WORKFLOW_EVENT action", () => {
        const workflows = (store.getState() as IStore).externalReducer.workflows
        store.dispatch(sendWorkflowEvent(workflows[0].id, "") as any)
        expect(dispatchToParentStore).toBeCalledWith(expect.objectContaining({ type: "ADD_WORKFLOW_EVENT" }))
        store.clearActions()
    })
    it("resetConsoleSession is defined", () => {
        const { consoleSessions } = (store.getState() as IStore).consoleReducer
        jest.spyOn(helpers, "isRoomMonitoringEnabled").mockReturnValue(true)
        store.dispatch(resetConsoleSession({ consoleSessions, isFailed: false, updateActiveTab: true }) as any)
        expect(dispatchToParentStore).toBeCalledWith({ type: "GLOBAL_SET_ACTIVE_TAB", payload: { activeTabIndex: 1 } })
        store.clearActions()
    })
    it("updateRoomCameraAvailability is defined", () => {
        const mockRooms = [
            {
                identity: { uuid: "other-uuid" },
                cameraAvailable: false,
            },
            {
                identity: { uuid: "target-uuid" },
                cameraAvailable: false,
            },
        ]
        const expectedRooms = [
            {
                identity: { uuid: "other-uuid" },
                cameraAvailable: false,
            },
            {
                identity: { uuid: "target-uuid" },
                cameraAvailable: true,
            },
        ]
        { (fetchRooms as jest.Mock).mockReturnValue(mockRooms) }
        store.dispatch(updateRoomCameraAvailability("target-uuid", true) as any)
        expect(dispatchToParentStore).toBeCalledWith(expect.objectContaining({ payload: expect.objectContaining({ rooms: expectedRooms }) }))
    })
    it("setConsoleConnectionInprogress is defined", () => {
        store.dispatch(setConsoleOperations(DEFAULT_CONSOLE_OPERATIONS) as any)
        expect(store.getActions()[0].consoleOperation.operationId).toBe("")
        store.clearActions()
    })
    it("updateSpecificDataToTransaction is defined", () => {
        store = mockStore({
            ...mockData,
            consoleReducer: {
                consoleOperation: {
                    transactions: [{ transactionStatus: ETransactionStatus.RUNNING }]
                },
            }
        })
        const expectedTransactions = [{ transactionStatus: ETransactionStatus.RUNNING, key: "value" }]
        store.dispatch(updateSpecificDataToTransaction("key", "value") as any)
        expect(store.getActions()).toBeDefined()
        expect(store.getActions()[0]).toStrictEqual(expect.objectContaining({ consoleOperation: expect.objectContaining({ transactions: expectedTransactions }) }))
        store.clearActions()
    })
    it("updateSpecificDataToTransactionGroup is defined", () => {
        store = mockStore({
            ...mockData,
            consoleReducer: {
                consoleOperation: {
                    transactions: [
                        { groupId: "other-group", transactionStatus: ETransactionStatus.RUNNING },
                        { groupId: "target-group", transactionStatus: ETransactionStatus.RUNNING },
                    ]
                },
            }
        })
        const expectedTransactions = [
            { groupId: "other-group", transactionStatus: ETransactionStatus.RUNNING },
            { groupId: "target-group", transactionStatus: ETransactionStatus.RUNNING, key: "value" },
        ]
        store.dispatch(updateSpecificDataToTransactionGroup("key", "value", "target-group") as any)
        expect(store.getActions()).toBeDefined()
        expect(store.getActions()[0]).toStrictEqual(expect.objectContaining({ consoleOperation: expect.objectContaining({ transactions: expectedTransactions }) }))
        store.clearActions()
    })
    it("updateCommandCenterSeat is defined", () => {
        const props = {
            initialised: ECommandCenterAccessMode.WITHOUT_HARDWARE,
            commandCenterSeat: {
                organizationId: 1,
                seatName: "seat1",
                receivers: [{
                    id: 1,
                    receiverName: "receiver",
                    monitorName: "monitor",
                    isSelected: true
                }]
            }
        }
        store.dispatch(updateCommandCenterSeat(props, true) as any)
        expect(store.getActions()).toBeDefined()
        store.clearActions()
    })

    it("updatePidMapping is defined", () => {
        store.dispatch(updatePidMapping([], []) as any)
        expect(String(store.getActions()[0].type)).toBeDefined()
        store.clearActions()
    })

    it("resetConsoleSession is defined", () => {
        mockData.externalReducer.featureFlags["rocc-room-monitoring"] = true
        store = mockStore(mockData)
        store.dispatch(resetConsoleSession({ consoleSessions: consoleSession, isFailed: false, updateActiveTab: true }) as any)
        expect(String(store.getActions()[0].type)).toBeDefined()
        store.clearActions()
    })
})
