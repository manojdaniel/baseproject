declare module "app2/homeApp"
declare module "enzyme"

// App consumes components from app2, and declares its types
// declare module "app2/Button" {
//     const Button: React.ComponentType

//     export default Button
//   }
