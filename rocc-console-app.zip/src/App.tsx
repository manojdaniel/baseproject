/*
 * Created on Tues Nov 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect } from "react"
import "@dls-pdv/semantic-ui-foundation/dist/semantic.min.css"
import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import store, { persistor } from "./redux/store/store"
import { defineMessages, IntlProvider } from "react-intl"
import CommandCenterLocationController from "./components/command-center-locations-controller/CommandCenterLocationsController"
import ConsoleEventHandler from "./common/modules/console-event-handler/ConsoleEventHandler"
import SyncExternalRedux from "./common/modules/setup/SyncExternalRedux"
import SyncConsoleSessions from "./components/sync-console-sessions/SyncConsoleSessions"
import ConversationClient from "./common/modules/consolemessages/ConversationClient"
import ProtocolTransferController from "./components/protocol-transfer/ProtocolTransferController"
import { setupLogger } from "@rocc/rocc-logging-module"
import { isDev } from "./common/helpers/helpers"
import messages from "./resources/translations/messages"
import { EN_LANGUAGE, EN_LOCALE } from "./common/constants/constants"
import { WorkflowController } from "./common/modules/workflow-controller/WorkflowController"
import ConnectionHandler from "./common/modules/connection-handler/ConnectionHandler"

const App = () => {
	const httpClient = useRoccHttpClient()
	useEffect(() => {
		setupAxiosHandler(httpClient)
		setupLogger({ isDev: isDev() })
	}, [])

	const locale = sessionStorage.getItem("locale")
	const language = sessionStorage.getItem("language")
	const defaultLocale = language || EN_LOCALE
	const defaultMessage = (locale: string) => defineMessages(messages[locale])
	return <>
		< Provider store={store} >
			<PersistGate loading={null} persistor={persistor}>
				<HttpClientProvider client={httpClient}>
					<ConnectionHandler/>
					<IntlProvider
						defaultLocale={defaultLocale}
						locale={defaultLocale}
						messages={locale === null ? defaultMessage(EN_LANGUAGE) : defaultMessage(locale)}
					>
						<>
							<CommandCenterLocationController />
							<ConsoleEventHandler />
							<SyncExternalRedux />
							<SyncConsoleSessions />
							<ConversationClient />
							<ProtocolTransferController />
							<WorkflowController />
						</>
					</IntlProvider>
				</HttpClientProvider>
			</PersistGate>
		</Provider >
	</>
}

export default App
