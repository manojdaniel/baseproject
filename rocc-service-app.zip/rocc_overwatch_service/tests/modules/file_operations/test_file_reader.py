import unittest
from unittest.mock import Mock, patch
from src.modules.file_operations.file_reader import get_book_handle,read_excel,terms_of_service,get_excel_template_version,get_unique_customers,release_book_handle,gen_dicts, get_modality_dict

class FileReaderTest(unittest.TestCase):
    def test_get_book_handle(self):
        self.assertRaises(Exception, get_book_handle, 1)
    def test_release_book_handle(self):
        mock_client = Mock()
        mock_client.execute.return_value = {"raw_data": []}
        self.assertRaises(Exception, read_excel, 1,mock_client,"1.0.6","")
    def test_terms_of_service(self):
        self.assertRaises(Exception, terms_of_service, "abc")
    def test_get_excel_template_version(self):
        self.assertRaises(Exception, get_excel_template_version, "abc")
    def test_get_unique_customers(self):
        sites = {
            "IDN/Customer Identifier- To be filled by Philips":"GlobalHealth"
        }
        metasites = get_unique_customers(sites)
        self.assertIsNone(metasites)
    def test_terms_of_service_present(self):
        documents = terms_of_service("fr-FR")
        self.assertIsNotNone(documents)
    def test_release_book_handle2(self):
        documents = release_book_handle({})
        self.assertIsNone(documents)
    def test_gen_dicts(self):
        documents = gen_dicts({},{},{},{},{})
        self.assertIsNone(documents)

    @patch("src.modules.file_operations.file_reader.open_workbook")
    def test_get_modality_dict(self,xlrd_mock):
        book = xlrd_mock
        book.sheet_names("somesheet")
        documents = get_modality_dict(book, {"ROOMS_DICT": {}}, [])
        self.assertIsNotNone(documents)
