"""
 Created on Mon May 23 2022
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""


import unittest

from unittest.mock import patch
from src.constants.constants import ROCC_SERVICE_TOOL_ROUTING_KEY
from src.exceptions.RoccException import RoccException

from src.wrappers.rabbitmq.producer import ProducerConfig, Producer
from tests.mocks.mock_rabbitmq import MockBlockingConnection, MockURLParameters


class TestProducer(unittest.TestCase):
    def mock_call_back(self):
        pass

    def test_producer_class_init_fail(self):
        with self.assertRaises(RoccException):
            Producer(ProducerConfig(host="//DUmmyY6pI8EVPyAOjn4s:dUmmYtTMf3FJiKvXahL1@ip:port/dummy",
                                    queue="dummy_queue",
                                    exchange="dummy_exchange",
                                    routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                    delay_queue=False))

    @patch("src.wrappers.rabbitmq.producer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.producer.pika.URLParameters", side_effect=MockURLParameters)
    def test_producer_init_success(self, m_pbc, m_pup):
        Producer(ProducerConfig(host="rabbitmq_host",
                                queue="dummy_queue",
                                exchange="dummy_exchange",
                                routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                delay_queue=False))
        m_pbc.assert_called()
        m_pup.assert_called()

    @patch("src.wrappers.rabbitmq.producer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.producer.pika.URLParameters", side_effect=MockURLParameters)
    def test_producer_init_delay_queue(self, m_pbc, m_pup):
        Producer(ProducerConfig(host="rabbitmq_host",
                                queue="dummy_queue",
                                exchange="dummy_exchange",
                                routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                delay_queue=True))
        m_pbc.assert_called()
        m_pup.assert_called()

    @patch("src.wrappers.rabbitmq.producer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.producer.pika.URLParameters", side_effect=MockURLParameters)
    def test_producer_publish(self, m_pbc, m_pup):
        producer = Producer(ProducerConfig(host="rabbitmq_host",
                                           queue="dummy_queue",
                                           exchange="dummy_exchange",
                                           routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                           delay_queue=False))
        producer.publish()
        m_pbc.assert_called()
        m_pup.assert_called()

    @patch("src.wrappers.rabbitmq.producer.pika.BlockingConnection", side_effect=MockBlockingConnection)
    @patch("src.wrappers.rabbitmq.producer.pika.URLParameters", side_effect=MockURLParameters)
    def test_producer_publish_fordelay_queue(self, m_pbc, m_pup):
        producer = Producer(ProducerConfig(host="rabbitmq_host",
                                           queue="dummy_queue",
                                           exchange="dummy_exchange",
                                           routing_key=ROCC_SERVICE_TOOL_ROUTING_KEY,
                                           delay_queue=True))
        producer.publish()
        m_pbc.assert_called()
        m_pup.assert_called()


suite = unittest.TestSuite()

suite.addTest(TestProducer("test_producer_class_init_fail"))
suite.addTest(TestProducer("test_producer_init_success"))
suite.addTest(TestProducer("test_producer_init_delay_queue"))
suite.addTest(TestProducer("test_producer_publish"))
suite.addTest(TestProducer("test_producer_publish_fordelay_queue"))

unittest.TextTestRunner(verbosity=0).run(suite)
