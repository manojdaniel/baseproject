/*
 * Created on Mon Aug 9 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React from "react"
import { shallow } from "enzyme"
import AppLayout from "./AppLayout"
import { EClinicalRole, EConnectionStatus } from "@rocc/rocc-client-services"

const mockDispatch = jest.fn()

jest.mock("../../../redux/store/globalStore", () => ({
    GetGlobalState: jest.fn().mockReturnValue({
        CALLING_APP_STORE: {
            callReducer: {
                videoCallStatus: [{ contextId: "", callStatus: "idle" }],
                phoneCallStatus: "idle"
            }
        },
        CONSOLE_APP_STORE: {
            consoleReducer: {
                consoleSessions: []
            },
        }
    }),
    CreateStore: jest.fn(),
    SubscribeToPartnerState: jest.fn()
}))

jest.mock("react-redux", () => ({
    useSelector: () => ({
        config: {},
        customerName: "",
        currentUser: { onBoarded: true, allRoles: [EClinicalRole.EXPERTUSER] },
        appState: "READY",
        notificationMessage: {
            showNotification: false
        },
        notificationModal: {
            showModal: false
        },
        sideBar: {
            displayRightSidePanel: false
        },
        applicationConnectionState: EConnectionStatus.OFFLINE,
        workflows: [],
        permissions: { CONSOLE_EDIT: true }
    }),
    useDispatch: () => mockDispatch
}))

describe("AppLayout Component", () => {
    let wrapper: any
    let useEffect: { mockImplementationOnce: (arg0: (f: any) => any) => void }
    beforeEach(() => {
        useEffect = jest.spyOn(React, "useEffect")
        const mockUseEffect = () => {
            useEffect.mockImplementationOnce(f => f())
        }

        (window as any).crypto = jest.fn().mockReturnValue({ getRandomValues: jest.fn().mockReturnValue(new Uint16Array(1)) })
        Object.defineProperties(window, {
            "performance": {
                value: {
                    getEntriesByType: jest.fn().mockReturnValue([{ type: "reload" }])
                }
            }
        })

        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()
        mockUseEffect()

        wrapper = shallow(<AppLayout ComponentToLoad={<div />} />)
    })
    afterEach(() => {
        jest.clearAllMocks()
    })
    it("should render with the correct id", () => {
        expect(wrapper.find("#AppLayout")).toHaveLength(1)
    })

    it("should render prompt", () => {
        expect(wrapper.find("Prompt")).toHaveLength(1)
    })

    it("should render navbar", () => {
        expect(wrapper.find("Navbar")).toHaveLength(1)
    })
})
