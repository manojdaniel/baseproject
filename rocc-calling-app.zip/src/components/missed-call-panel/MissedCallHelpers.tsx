/*
 * Created on Mon Sep 20 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { IMissedCallData } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, errorParser } from "@rocc/rocc-logging-module"
import React from "react"
import { Dispatch } from "redux"
import { DE_LOCALE, FR_LOCALE, MONTHS } from "../../constants/constants"
import { setMissedCalls } from "../../redux/actions/callActions"
import en from "../../resources/translations/en-US"
import { getMissedCallsService } from "./MissedCallServices"

export const getMissedCalls = async (currentUser: any, dispatch: Dispatch<any>, url: string, secondaryUuid: any) => {
    try {
        const { accessToken, uuid } = currentUser
        let data: IMissedCallData[] = []
        if (secondaryUuid) {
            const response = await Promise.all([
                getMissedCallsService(url, uuid, accessToken),
                getMissedCallsService(url, secondaryUuid, accessToken),
            ])
            const roomMissedCalls: IMissedCallData[] = response[0]
            const techMissedCalls: IMissedCallData[] = response[1]
            data = [...new Set([...roomMissedCalls, ...techMissedCalls])]
        } else {
            data = await getMissedCallsService(url, uuid, accessToken)
        }
        if (data) {
            dispatch(setMissedCalls(data))
        }
    } catch (error) {
        errorLogger(`Encountered error while fetching missed call, error: ${errorParser(error)}`)
    }
}

export const formattedDateTimeMsg = (preStr: number, id: string, defaultConst: string, language: string) => {
    const { intl } = getIntlProvider()
    const selectedLanguage: boolean = [DE_LOCALE, FR_LOCALE].includes(language.toLowerCase())
    return selectedLanguage ?
        <>
            {intl.formatMessage({ id: "content.missedCall.ago", defaultMessage: en["content.missedCall.ago"] })} {preStr} {intl.formatMessage({ id: id, defaultMessage: defaultConst })}
        </>
        :
        <>
            {preStr} {intl.formatMessage({ id: id, defaultMessage: defaultConst })} {intl.formatMessage({ id: "content.missedCall.ago", defaultMessage: en["content.missedCall.ago"] })}
        </>
}


export const getLocalTime = (utcTime: string, currentTime: Date, language: string) => {
    const { intl } = getIntlProvider()
    const refTime = new Date(utcTime)
    const ONE_MINUTE = 60 * 1000
    const ONE_HOUR = 60 * 60 * 1000
    const ONE_DAY = 24 * ONE_HOUR
    if (currentTime.getTime() - refTime.getTime() < ONE_MINUTE) {
        return <span>
            {intl.formatMessage({ id: "content.missedCall.justNow", defaultMessage: en["content.missedCall.justNow"] })}
        </span>
    } else if (currentTime.getTime() - refTime.getTime() < 2 * ONE_MINUTE) {
        return formattedDateTimeMsg(1, "content.missedCall.minute", en["content.missedCall.minute"], language)
    } else if (currentTime.getTime() - refTime.getTime() < ONE_HOUR) {
        return formattedDateTimeMsg(Math.floor((currentTime.valueOf() - refTime.valueOf()) / ONE_MINUTE), "content.missedCall.minutes", en["content.missedCall.minutes"], language)
    } else if (currentTime.getTime() - refTime.getTime() < 2 * ONE_HOUR) {
        return formattedDateTimeMsg(1, "content.missedCall.hour", en["content.missedCall.hour"], language)
    } else if (currentTime.getTime() - refTime.getTime() < ONE_DAY) {
        return formattedDateTimeMsg(Math.floor((currentTime.valueOf() - refTime.valueOf()) / ONE_HOUR), "content.missedCall.hours", en["content.missedCall.hours"], language)
    } else if (currentTime.getDate() - refTime.getDate() === 1) {
        return formattedDateTimeMsg(1, "content.missedCall.day", en["content.missedCall.day"], language)
    } else if (currentTime.getMonth() === refTime.getMonth()) {
        return formattedDateTimeMsg(currentTime.getDate() - refTime.getDate(), "content.missedCall.days", en["content.missedCall.days"], language)
    } else if (currentTime.getMonth() - refTime.getMonth() === 1) {
        return formattedDateTimeMsg(1, "content.missedCall.month", en["content.missedCall.month"], language)
    } else if (currentTime.getMonth() - refTime.getMonth() > 1) {
        return formattedDateTimeMsg(currentTime.getMonth() - refTime.getMonth(), "content.missedCall.months", en["content.missedCall.months"], language)
    }
    return `${refTime.getDate()}-${MONTHS[refTime.getMonth()]}-${refTime.getFullYear()}`
}
