/*
 * Created on Wed Oct 06 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import React, { useEffect } from "react"
import { IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import store, { persistor } from "./redux/store/store"
import { PersistGate } from "redux-persist/integration/react"
import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupLogger } from "@rocc/rocc-logging-module"
import { isDev } from "./common/helpers/helpers"
import { setupAxiosHandler } from "./common/helpers/apicall"
import SidebarContent, { ISidebarContent } from "./common/modules/sidebar-content/SidebarContent"
import SyncExternalRedux from "./common/modules/setup/SyncExternalRedux"
import ChildAppsSetup from "./common/modules/child-apps-setup/ChildAppsSetup"

const SidebarContentFeature = (props: ISidebarContent) => {
    const httpClient = useRoccHttpClient()
    useEffect(() => {
        setupAxiosHandler(httpClient)
        setupLogger({ isDev: isDev() })
    }, [])
    /* Note: SyncExternalRedux & ChildAppsSetup components are moved here, since SidebarContent component is loaded before APP. 
        We can move it back to app, if that becomes the first component to load or re-look at this once injectReducer is introduced*/
    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                <HttpClientProvider client={httpClient}>
                    <IntlProvider
                        defaultLocale={"en-US"}
                        locale={"en"}
                    >
                        <>
                            <SyncExternalRedux />
                            <ChildAppsSetup />
                            <SidebarContent {...props} />
                        </>
                    </IntlProvider>
                </HttpClientProvider>
            </PersistGate>
        </Provider>
    </>
}

export default SidebarContentFeature
