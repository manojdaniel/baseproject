/*
 * Created on Thu Sept 02 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { DEFAULT_CONTACT_INFO, ECallStatus, getDetailsByUUID, ICallStatus, IContactInfo, IIncomingCallDetails } from "@rocc/rocc-client-services"
import { getIntlProvider } from "@rocc/rocc-global-components"
import { errorLogger, infoLogger, sendLogsToAzure, warningLogger } from "@rocc/rocc-logging-module"
import { Dispatch } from "redux"
import { CALL_MESSAGES, HTTP_STATUS, TIMEOUT_30000 } from "../../../../../constants/constants"
import { setCallMessage, setCallRingStatus, setIncomingCallDetails, setVideoCallStatus, updateCallTimeout } from "../../../../../redux/actions/callActions"
import { DEFAULT_CALL_MESSAGE } from "../../../../../redux/reducers/callReducer"
import { fetchGlobalURLs } from "../../../../../redux/store/externalAppStates"
import store from "../../../../../redux/store/store"
import en from "../../../../../resources/translations/en-US"
import { getCallStatusFromICallStatus, upsertCallStatus } from "../../../../helpers/callUtility"
import { getCustomrReducerFromGlobalStore, getUserReducerFromGlobalStore } from "../../../../helpers/helpers"
import { getContextDetails } from "../../messageService"
import { onCallReject, onCallTimeout } from "../MessageHelper"
import { ICallDetails, TRACKING_VALUES } from "../types"

interface IIncomingCall {
    contextId: string
    dispatch: Dispatch<any>
}

const { RINGING, FAILED } = ECallStatus

export const incomingCall = async (props: IIncomingCall) => {

    const { videoCallStatus, currentUser, urls } = initialiseReduxValues()
    const { component, event } = TRACKING_VALUES

    const { contextId, dispatch } = props
    const { intl } = getIntlProvider()

    const updateIncomingCallDetails = async (contextId: string, data: ICallDetails) => {
        if (data.participants.length) {
            const appendNewCallState = upsertCallStatus(contextId, RINGING)
            dispatch(setVideoCallStatus(appendNewCallState))
            const { caller, callerUuid } = await fetchCallerDetails(data)
            sendLogsToAzure({ contextData: { component, event: `${event} Incoming Call`, Call_From: callerUuid, Call_To: currentUser.uuid, contextId } })
            if (caller.uuid) {
                infoLogger(`User ${currentUser.uuid} received an incoming call from ${callerUuid}`)
                const callTimeoutID = setTimeout(() => onCallTimeout({
                    isCallee: true, callee: currentUser, caller,
                    lastCallStatus: RINGING, contextId, dispatch,
                }), TIMEOUT_30000)
                dispatch(updateCallTimeout({ contextId, timeoutId: callTimeoutID }, true))
                const incomingCall: IIncomingCallDetails = { contextId: contextId, participant: caller, requester: data.requester }
                dispatch(setIncomingCallDetails(incomingCall))
                dispatch(setCallRingStatus(true))
            } else {
                failedToFetchCallerDetails(appendNewCallState, callerUuid)
            }
        }
    }

    const failedToFetchCallerDetails = (appendNewCallState: ICallStatus[], callerUuid: string) => {
        setCallRingStatus(false)
        errorLogger(`Call with contextId: ${contextId} failed as th details for user: ${callerUuid} could not be fetched`)
        setCallMessage({
            messageType: CALL_MESSAGES.CALL_FAILED, contact: DEFAULT_CONTACT_INFO,
            message: intl.formatMessage({ id: "content.callMessages.callDetailsFetchFailed", defaultMessage: en["content.callMessages.callDetailsFetchFailed"] }),
        })
        const callIndex = appendNewCallState.findIndex((callState) => callState.contextId === contextId)
        if (callIndex > -1) {
            appendNewCallState[callIndex].callStatus = FAILED
            setVideoCallStatus([...appendNewCallState])
        }
    }

    /*  Check if user is idle or in call and not receiving another call */
    const callStatuses = getCallStatusFromICallStatus(videoCallStatus)
    if (!callStatuses.includes(RINGING)) {
        const contextDetails = await getContextDetails(contextId, currentUser, urls.COMMUNICATION_SERVICES_URL)
        if (contextDetails.status === HTTP_STATUS.OK) {
            const data: ICallDetails = contextDetails.data
            dispatch(setCallMessage(DEFAULT_CALL_MESSAGE))
            if (data.requester.userContext) {
                data.requester.userContext.twilioToken = ""
            }
            updateIncomingCallDetails(contextId, data)
        }
    } else {
        /*  Reject this call With Appropriate Message. */
        warningLogger(`Rejecting call since ${currentUser.uuid} is already receiving another call`)
        onCallReject({ setState: false, contextId, skipAudioPause: true, dispatch })
    }
}

const fetchCallerDetails = async (data: ICallDetails) => {
    const { rooms, contacts } = initialiseReduxValues()
    let callerUuid = data.participants[0].primaryUuid
    if (data.requester.userContext && data.requester.userContext.callerId) {
        callerUuid = data.requester.userContext.callerId
    }
    const caller: IContactInfo = await getDetailsByUUID(callerUuid, contacts, rooms)
    return { caller, callerUuid }
}

const initialiseReduxValues = () => {
    const state = store.getState()
    const { currentUser } = state.externalReducer
    const { contacts } = getUserReducerFromGlobalStore()
    const { rooms } = getCustomrReducerFromGlobalStore()
    return { currentUser, urls: fetchGlobalURLs(), contacts, rooms, videoCallStatus: state.callReducer.videoCallStatus }
}
