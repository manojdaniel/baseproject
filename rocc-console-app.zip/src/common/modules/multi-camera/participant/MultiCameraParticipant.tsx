/*
 * Created on Fri Dec 03 2021
 *
 * Copyright (c) 2019 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { ECameraStreamAvailable, ETrackKind, EVENT_DOMINANT_SPEAKER_CHANGED, EVENT_PARTICIPANT_CONNECTED, EVENT_PARTICIPANT_DISCONNECTED, EVENT_TRACK_DISABLED, EVENT_TRACK_SUBSCRIBED, EVENT_TRACK_UNSUBSCRIBED, IConsoleSession, 
    IMultiCameraListItem, EVENT_PARTICIPANT_RECONNECTING, EVENT_TRACK_DIMENSIONS_CHANGED, EVENT_TRACK_MESSAGE, EVENT_TRACK_PUBLISHPRIORITY_CHANGED, EVENT_STARTED_TRACK, EVENT_TRACK_SUBSCRIPTION_FAILED, EVENT_TRACK_SWITCHED_OFF, EVENT_TRACK_SWITCHED_ON
} from "@rocc/rocc-client-services"
import React, { MutableRefObject, useEffect, useRef } from "react"
import { useDispatch } from "react-redux"
import { Participant, RemoteDataTrack, RemoteParticipant, RemoteTrack, RemoteTrackPublication, RemoteVideoTrack, Room, Track, TwilioError } from "twilio-video"
import { detachTracks } from "../../../helpers/multiCameraUtility"
import { updateConsoleSession } from "../../../../redux/actions/consoleActions"
import { errorLogger, infoLogger, warningLogger } from "@rocc/rocc-logging-module"
import { IMultiCamVideoTrack } from "../MultiCameraTypes"
import store from "../../../../redux/store/store"
import syncSessions from "../../../../redux/store/syncSessions"
import { CONSOLE_MEDIA_ROOM_UPDATE } from "../../../constants/constants"

const FILENAME = "MultiCameraParticipant.tsx : "

interface IMultiCameraParticipantProps {
    activeRoom: Room | null
    consoleSession: IConsoleSession
    onDevice: boolean
    videoTracksRef: MutableRefObject<any>
    isSyncConsoleSession?: boolean
    setVideoTracks: (tracks: IMultiCamVideoTrack[]) => void
    setFullscreenState: (status: boolean) => void
    setRemoteVideoStatus?: (status: boolean) => void
}

const MultiCameraParticipant = (props: IMultiCameraParticipantProps) => {

    const { consoleSession, activeRoom, setVideoTracks, videoTracksRef, setRemoteVideoStatus, setFullscreenState, onDevice, isSyncConsoleSession } = props
    const dispatch = useDispatch()
    const activeRoomRef = useRef(activeRoom)
    const { contextId, mediaRoomDetails } = consoleSession
    const contextIdRef = useRef(contextId)
    const mediaRoomDetailsRef = useRef(mediaRoomDetails)
    const loggerInitialMessage = `${FILENAME}: For user: ${consoleSession.requester} - Console session ${consoleSession.contextId}`

    useEffect(() => {
        /* TODO: Re-look if these ref is really needed */
        contextIdRef.current = contextId
        mediaRoomDetailsRef.current = mediaRoomDetails
    }, [consoleSession.contextId, consoleSession.mediaRoomDetails])

    const checkIfTrackExist = (trackName: string) => {
        return videoTracksRef.current ?
            videoTracksRef.current.findIndex((videoTrackItem: IMultiCamVideoTrack) => videoTrackItem.videoTrack.name === trackName) > -1
            : false
    }

    useEffect(() => {
        if (activeRoom) {
            activeRoomRef.current = activeRoom
            activeRoom.on(EVENT_TRACK_SUBSCRIBED, trackSubscribed)
            activeRoom.on(EVENT_TRACK_UNSUBSCRIBED, trackUnsubscribed)
            activeRoom.on(EVENT_PARTICIPANT_DISCONNECTED, participantDisconnected)
            activeRoom.on(EVENT_PARTICIPANT_CONNECTED, participantConnected)
            activeRoom.on(EVENT_TRACK_DISABLED, trackDisabled)
            activeRoom.on(EVENT_DOMINANT_SPEAKER_CHANGED, dominantSpeakerChanged)
            activeRoom.on(EVENT_PARTICIPANT_RECONNECTING, participantReconnecting)
            activeRoom.on(EVENT_TRACK_DIMENSIONS_CHANGED, trackDimensionsChanged)
            activeRoom.on(EVENT_TRACK_MESSAGE, trackMessage)
            activeRoom.on(EVENT_TRACK_PUBLISHPRIORITY_CHANGED, trackPublishPriorityChanged)
            activeRoom.on(EVENT_STARTED_TRACK, trackStarted)
            activeRoom.on(EVENT_TRACK_SUBSCRIPTION_FAILED, trackSubscriptionFailed)
            activeRoom.on(EVENT_TRACK_SWITCHED_ON, trackSwitchedOn)
            activeRoom.on(EVENT_TRACK_SWITCHED_OFF, trackSwitchedOff)
        }
    }, [activeRoom])

    const trackDisabled = (_publication: RemoteTrackPublication, participant: RemoteParticipant) => {
        /* Check if Track is disabled from Device side */
        warningLogger(`${loggerInitialMessage} - Track is disabled for participant ${participant.identity}.`)
    }

    const trackSubscribed = (track: Track) => {
        infoLogger(`${loggerInitialMessage} - Handling track subscribed event ${track.name}.`)
        if (track.kind === ETrackKind.VIDEO) {
            if (!checkIfTrackExist(track.name)) {
                infoLogger(`${loggerInitialMessage} - Adding unique track ${track.name}.`)
                const newTracks = [...videoTracksRef.current]
                const videoTrackObj: IMultiCamVideoTrack = {
                    fullScreen: false,
                    videoTrack: track
                }
                newTracks.push(videoTrackObj)
                videoTracksRef.current = [...newTracks]
                setVideoTracks([...newTracks])
                if (setRemoteVideoStatus) {
                    const multiCameraListObj: IMultiCameraListItem = {
                        cameraStreamName: track.name,
                        selected: true
                    }
                    consoleSession.multiCameraList.push(multiCameraListObj)
                    dispatch(updateConsoleSession({ ...consoleSession }, true, false))
                }
            }
        }
    }

    const trackUnsubscribed = (track: Track,) => {
        infoLogger(`${loggerInitialMessage} - Handling track unsubscribe event ${track.name}.`)
        detachTracks([track])
    }

    const updateCameraStatus = (streamAvailable: ECameraStreamAvailable, setRemoteVideoStatus?: (status: boolean) => void) => {
        if (isSyncConsoleSession) {
            syncSessions.postMessage({
                type: CONSOLE_MEDIA_ROOM_UPDATE,
                cameraStreamStatus: {
                    contextId: contextIdRef.current,
                    mediaRoomDetails: {
                        cameraStreamAvailable: streamAvailable,
                        mediaRoomId: mediaRoomDetailsRef.current.mediaRoomId,
                        mediaRoomToken: mediaRoomDetailsRef.current.mediaRoomToken
                    }
                }
            })
        } else {
            const state = store.getState()
            const { consoleSessions } = state.consoleReducer
            const currentSession = consoleSessions.find((session: IConsoleSession) => session.contextId === contextIdRef.current)
            if (currentSession) {
                const newConsoleSession: IConsoleSession = { ...currentSession }
                newConsoleSession.multiCameraList = []
                dispatch(updateConsoleSession(newConsoleSession, true, false))
            }
        }
        setFullscreenState(false)
        setVideoTracks([])
        videoTracksRef.current = []
        setRemoteVideoStatus && setRemoteVideoStatus(false)
    }

    const participantDisconnected = (participant: Participant) => {
        errorLogger(`${loggerInitialMessage} - Participant ${participant.identity} left the media room.`)
    }

    const participantConnected = (participant: Participant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} connected the media room.`)
        if (consoleSession.roomUuid === participant.identity && !onDevice) {
            infoLogger(`${FILENAME}: For user ${consoleSession.requester} - Device connected - updating camera stream availablity: ${ECameraStreamAvailable.INITIATED}.`)
            updateCameraStatus(ECameraStreamAvailable.INITIATED, setRemoteVideoStatus)
        }
    }
    
    const participantReconnecting = (participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} is reconnecting.`)
    }

    const dominantSpeakerChanged = (dominantSpeaker: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Dominant speaker changed to ${dominantSpeaker.identity}.`)
    }

    const trackDimensionsChanged = (track: RemoteVideoTrack, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} has changed track ${track.name} dimensions.`)
    }

    const trackMessage = (data: string | ArrayBuffer, track: RemoteDataTrack, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} has message ${data} for track ${track.name}.`)
    }

    const trackPublishPriorityChanged = (priority: Track.Priority, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Console session ${consoleSession.contextId} - Participant ${participant.identity} remote track ${publication.trackName} priority changed to ${priority}.`)
    }

    const trackStarted = (track: RemoteTrack, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} track has ${track.name} started.`)
    }

    const trackSubscriptionFailed = (error: TwilioError, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
        infoLogger(`${FILENAME}: For user ${consoleSession.requester} - Participant ${participant.identity} track ${publication.trackName} subcription has failed due to Error ${error.code}: ${error.message}.`)
    }

    const trackSwitchedOn = (track: RemoteTrack, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} track ${track.name} with track id ${publication.trackSid} is switched on.`)
    }

    const trackSwitchedOff = (track: RemoteTrack, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
        infoLogger(`${loggerInitialMessage} - Participant ${participant.identity} track ${track.name} with track id ${publication.trackSid} is switched off.`)
    }

    return <></>
}

export default MultiCameraParticipant
