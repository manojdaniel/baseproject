import moment from "moment"
import React, { Fragment } from "react"
import { Table, Label, Checkbox, SemanticWIDTHS, CheckboxProps, List, Popup } from "semantic-ui-react"
import { ITableBody, ITableColumn, EColumn } from "../types"
import _ from "lodash"
import { fetchStatusColor } from "utility/listUtility"
import { debugLogger } from "common/logger/logger"
import "./TableBody.scss"

/* eslint-disable jsx-a11y/anchor-is-valid */
const PDVTableBody: React.FC<ITableBody> = ({ loading, data, columns, initialPageSize, selectedRowIndex, currentRow, multiSelect, onRowClick, onDrillDown }) => {

    const getDisplayColumns = () => {
        return columns.filter((column: ITableColumn) => {
            return column.display === true
        })
    }
    const renderCell = (type: string, value: any, row: any) => {
        switch (type) {
            case EColumn[EColumn.date]:
                return moment(value).format("MMM D, YYYY")  // TODO: these would come from some global settings or a format string in  column config
            case EColumn[EColumn.datetime]:
                return moment(value).format("MMM D, YYYY:HHMM")
            case EColumn[EColumn.number]:
                return value
            case EColumn[EColumn.string]:
                return value
            case EColumn[EColumn.status]:
                return (
                    <>
                        <Label
                            circular
                            empty
                            className={`tiny  ${fetchStatusColor(value)}`}
                        />
                        {value}
                    </>
                )
            case EColumn[EColumn.link]:
                return <a href={value} target="_blank" rel="noreferrer" onClick={(event: any) => { event && event.stopPropagation() }}>{value}</a>
            case EColumn[EColumn.object]:
                return renderObject(value)
            case EColumn[EColumn.overflow]:
                return renderOverflowObject(value)
            case EColumn[EColumn.list]:
                return renderList(value)
            case EColumn[EColumn.name]:
                return <a onClick={(event: any) => { handleDrillDown(event, row) }} >{value}</a>
            default:
                return <div>{value}</div>
        }
    }
    const renderObject = (value: any) => {
        return <List style={{ border: "0" }}>
            <List.Item style={{ padding: "0" }}>
                <List.Content title={value}>
                    {renderListObject(value)}
                </List.Content>
            </List.Item>
        </List>
    }
    const renderOverflowObject = (value: any) => {
        return <List style={{ border: "0" }}>
            <List.Item style={{ padding: "0" }}>
                <List.Content title={value}>
                    <List.Description>{value}</List.Description>
                </List.Content>
            </List.Item>
        </List>
    }

    const renderListObject = (value: any) => {
        return <List.Description style={{ whiteSpace: "initial" }}>{value}</List.Description>
    }

    const renderList = (value: any) => {
        const columnList = 3
        return returnWithPopUp(value, columnList)
    }

    const returnWithPopUp = (listData: any[], rowLimit: number) => {
        let returnData: any = listData.map((item: string, index: number) => renderListObject(item))
        if (listData.length > rowLimit) {
            const displayList = listData.slice(0, rowLimit)
            const popUpList = listData.slice(rowLimit, listData.length)
            returnData = <Fragment>
                {displayList.map((item: string, index: number) => renderListObject(item))}
                <Popup
                    trigger={renderListObject(<a>{`+${popUpList.length}`}</a>)}
                    content={popUpList.map((item: string, index: number) => <div key={`${index}${rowLimit}`}>{renderListObject(item)}</div>)}
                    position={"bottom center"}
                    pinned
                    inverted
                />
            </Fragment>
        }
        return <List style={{ border: "0" }}>
            <List.Item style={{ padding: "0" }}>
                <List.Content>
                    {returnData}
                </List.Content>
            </List.Item>
        </List>
    }

    const handleDrillDown = (event: any, row: any) => {
        if (onDrillDown) {
            event && event.stopPropagation()
            onDrillDown(row.id)
        }
    }

    const raiseRowClick = (row: any, rowIndex: number) => {
        try {
            if (onRowClick) {
                onRowClick(row.id, row)
                debugLogger(`Current row changed from ${currentRow} to ${row.id}`)
                currentRow = row.id
            }
        } catch (error) {
            // TODO: setup error handling in Toolkit ... use global err handling package and build it in as a feature of each component
            console.log("Error in PDVTableBody.raiseRowClick()", error)
        }
    }

    const handleMultiSelect = (event: React.MouseEvent<HTMLInputElement, MouseEvent>, checkBoxData: CheckboxProps, row: any, rowIndex: number) => {
        raiseRowClick(row, rowIndex)
    }

    const isSelected = (rowIndex: number): boolean => {
        return currentRow === rowIndex
    }

    const gridNumber = 12
    const colWidth = Math.floor(gridNumber / getDisplayColumns().length)

    return (
        // <Table.Body style={{ height: `calc(40px * ${initialPageSize})` }}>
        <Table.Body>
            {loading && (
                <Table.Row className="loading">
                    <Table.Cell textAlign="center" verticalAlign="middle" colSpan={12}>
                        {/* TODO: this should really be its own customized PDVLoader component */}
                        {/* <SVG
              src={ProgressIndicatorLargeSVG}
              className="progressIndicator progressCircleIndeterminate rotateCounter medium"
            /> */}
                    </Table.Cell>
                </Table.Row>
            )}
            {!loading && data.map((row: any, rowIndex: number) => {
                return (
                    <Table.Row
                        key={rowIndex}
                        onClick={(e: React.MouseEvent<HTMLInputElement, MouseEvent>) => raiseRowClick(row, rowIndex)}
                        className={isSelected(row.id) ? "selected" : "notSelected"}
                    >
                        {getDisplayColumns().map((column: ITableColumn, colIndex: number) => {
                            const { type, path, width, className } = column
                            return (
                                <Table.Cell
                                    id={`${rowIndex}_${colIndex}`}
                                    key={`${rowIndex}_${colIndex}`}
                                    width={width ? width as SemanticWIDTHS : Number(colWidth) as SemanticWIDTHS}
                                    style={{ height: "inherit" }}
                                    className={`wrapContent ${className}`}
                                >
                                    {multiSelect && colIndex === 0 && <Checkbox label="" onClick={(e: React.MouseEvent<HTMLInputElement, MouseEvent>, checkBoxData) => handleMultiSelect(e, checkBoxData, row, rowIndex)} />}
                                    {renderCell(type, _.get(row, path), row)}
                                </Table.Cell>
                            )
                        })}
                    </Table.Row>
                )
            })}
        </Table.Body>
    )
}

export default PDVTableBody
