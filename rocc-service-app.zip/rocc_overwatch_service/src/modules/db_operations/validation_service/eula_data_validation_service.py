"""
 Created on Thu Oct 30 2020
 Copyright (c) 2019 Philips
 (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 Reproduction or transmission in whole or in part, in any form or by any
 means, electronic, mechanical or otherwise, is prohibited without the prior
 written consent of the copyright owner.
"""

from src.constants.constants import ROCC_DOCUMENTS
from src.loggers.log import create_logger
from src.modules.db_operations.db_utility.graphql_response_parser import check_if_id_is_present
from src.wrappers.graphql.queries.queries import verify_eula_data

LOG = create_logger("CcDataValidationService")


def verify_if_eula_data_exists(client, document_name, data):
    try:
        response = check_if_id_is_present(client.execute(verify_eula_data, variable_values={"data_blob": data, "document_type": document_name}), ROCC_DOCUMENTS)
        return response
    except Exception as ex:
        LOG.exception("Exception while verifying data for EULA, {}".format(ex))
