/*
 * Created on Mon Aug 1 2022
 *
 * Copyright (c) 2022 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

const HtmlWebpackPlugin = require("html-webpack-plugin")
const ModuleFederationPlugin = require("webpack").container.ModuleFederationPlugin
const WebpackBundleAnalyzer = require("webpack-bundle-analyzer").BundleAnalyzerPlugin
const path = require("path")
const dependencies = require("../../package.json").dependencies
const styleLoader = "style-loader"
const cssLoader = "css-loader"
const fileLoader = "file-loader"
const bundleLoader = "bundle-loader"
const babelLoader = "babel-loader"
const sassLoader = "sass-loader"
const APP_NAME = "roccConsole"

module.exports = {
  entry: "./src/index",
  devServer: {
    contentBase: path.join(__dirname, "../../", "dist"),
    port: 3021,
  },
  output: {
    publicPath: "auto",
    filename: "static/js/[name].[contenthash].js",
    chunkFilename: "static/js/[name].[contenthash].chunk.js",
    path: path.resolve(__dirname, "../../", "dist"),
  },
  optimization: {
    moduleIds: "deterministic",
    splitChunks: {
      chunks: "all",
      cacheGroups: {
        consoleReact: {
          test: /[\\/]node_modules[\\/](react|react-dom)[\\/]/,
          name: "console_react"
        },
        consoleSemantic: {
          test: /[\\/]node_modules[\\/](@dls-pdv\/semantic-react-components|@dls-pdv\/semantic-ui-foundation|semantic-ui-react)[\\/]/,
          name: "console_semantic"
        },
        consoleReduxt: {
          test: /[\\/]node_modules[\\/](react-redux|redux|redux-micro-frontend|redux-persist)[\\/]/,
          name: "console_redux"
        },
        otherVendor: {
          test: /[\\/]node_modules[\\/](!react)(!react-dom)(!@dls-pdv\/semantic-react-components)(!@dls-pdv\/semantic-ui-foundation)(!react-redux)(!redux)(!redux-micro-frontend)(!redux-persist)[\\/]/,
          name: "console_vendors"
        },
        app: {
          name: "console_app",
          test: /[\\/]src[\\/]/
        }
      },
    },
  },
  resolve: {
    extensions: [".ts", ".tsx", ".js", ".json"],
    fallback: {
      "child_process": false,
      "fs": false,
      "http": false,
      "https": false,
    }
  },
  module: {
    rules: [
      {
        test: /bootstrap\.tsx$/,
        loader: bundleLoader,
        options: {
          lazy: true,
        },
      },
      {
        test: /\.tsx?$/,
        loader: babelLoader,
        exclude: /node_modules/,
        options: {
          presets: ["@babel/preset-react", "@babel/preset-typescript"],
        },
      },
      {
        test: /\.css$/,
        use: [
          styleLoader,
          {
            loader: cssLoader,
            options: {
              importLoaders: 1,
              modules: true
            }
          }
        ],
        include: /\.module\.css$/
      },
      {
        test: /\.css$/,
        use: [
          styleLoader,
          cssLoader
        ],
        exclude: /\.module\.css$/
      },
      {
        test: /\.(scss)$/,
        include: [path.resolve("src")],
        use: [
          {
            loader: styleLoader,
          },
          {
            loader: cssLoader,
            options: {
              importLoaders: 1,
              modules: true,
            },
          },
          {
            loader: sassLoader,
            options: {
              sourceMap: true,
            },
          },
        ],
      },
      {
        test: /\.(png|svg|woff2|woff|ttf|eot)$/,
        use: [fileLoader]
      },
      {
        test: /\.(ico)$/,
        exclude: /node_modules/,
        use: ["file-loader?name=[name].[ext]"]
      },
      {
        oneOf: [
          {
            test: /\.wasm$/,
            type: "javascript/auto",
            loader: "file-loader",
          }],
      }
    ],
  },
  plugins: [
    new WebpackBundleAnalyzer({ analyzerMode: "disabled", openAnalyzer: false }),
    new ModuleFederationPlugin({
      name: APP_NAME,
      filename: "remoteEntry.js",
      exposes: {
        "./App": "./src/App",
        "./ConsoleTrigger": "./src/ConsoleTrigger",
        "./ActiveConsoleSessionFeature": "./src/ActiveConsoleSessionFeature",
        "./CommandCenterSettingsFeature": "./src/CommandCenterSettingsFeature",
        "./MultiCameraSettingsFeature": "./src/MultiCameraSettingsFeature",
        "./RoomMonitoringWindowFeature": "./src/RoomMonitoringWindowFeature"
      },
      remotes: {
        roccCalling: "roccCalling@app/calling/remoteEntry.js",
      },
      shared: {
        ...dependencies,
        react: {
          singleton: true,
          requiredVersion: dependencies.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: dependencies["react-dom"],
        },
        "react-intl": {
          singleton: true,
          requiredVersion: dependencies["react-intl"]
        },
        "semantic-ui-react": {
          singleton: true,
          requiredVersion: dependencies["semantic-ui-react"],
        },
        "@dls-pdv/semantic-react-components": {
          singleton: true,
          requiredVersion: dependencies["@dls-pdv/semantic-react-components"],
        },
        "@dls-pdv/semantic-ui-foundation": {
          singleton: true,
          requiredVersion: dependencies["@dls-pdv/semantic-ui-foundation"],
        },
        "@rocc/rocc-http-client": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-http-client"],
        },
        "@rocc/rocc-client-services": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-client-services"],
        },
        "@rocc/rocc-logging-module": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-logging-module"],
        },
        "@rocc/rocc-chat-library": {
          singleton: true,
          requiredVersion: dependencies["@rocc/rocc-chat-library"],
        }
      },
    }),
    new HtmlWebpackPlugin({
      template: "./public/index.html",
      filename: "./index.html",
      favicon: "./public/favicon.ico"
    }),
  ],
}
