/*
 * Created on Tue Nov 02 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2021 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import { HttpClientProvider, useRoccHttpClient } from "@rocc/rocc-http-client"
import { setupLogger } from "@rocc/rocc-logging-module"
import React, { useEffect } from "react"
import { IntlProvider } from "react-intl"
import { Provider } from "react-redux"
import { PersistGate } from "redux-persist/integration/react"
import { setupAxiosHandler } from "./common/helpers/apiUtility"
import { isDev } from "./common/helpers/helpers"
import AvSettingController, { IAvSettingsProps } from "./common/modules/av-settings/AvSettingsController"
import store, { persistor } from "./redux/store/store"

const AVSettingsFeature = (props: IAvSettingsProps) => {
    const httpClient = useRoccHttpClient()
    useEffect(() => { 
        setupAxiosHandler(httpClient)
        setupLogger({ isDev: isDev() }) 
    }, [])
    return <>
        <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
                <HttpClientProvider client={httpClient}>
                    <IntlProvider
                        defaultLocale={"en-US"}
                        locale={"en"}
                    >
                        <>
                            <AvSettingController {...props} />
                        </>
                    </IntlProvider>
                </HttpClientProvider>
            </PersistGate>
        </Provider>
    </>
}

export default AVSettingsFeature
