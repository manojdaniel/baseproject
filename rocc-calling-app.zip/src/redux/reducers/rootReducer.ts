/*
 * Created on Mon Aug 23 2021
 *
 * Copyright (c) 2021 Philips
 * (C) Koninklijke Philips Electronics N.V. 2017 * * All rights are reserved.
 * Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior
 * written consent of the copyright owner.
 */

import callReducer, { initialStatesForCall } from "./callReducer"
import externalReducer, { initialStateForExternalReducer } from "./externalReducer"
import { combineReducers } from "redux"
import { IStore } from "../interfaces/types"

const rootReducer = (state: IStore | undefined, action: any) => combineReducers({
    callReducer,
    externalReducer,
})(state, action)

export const initialStateForAllReducers = {
    callReducer: initialStatesForCall,
    externalReducer: initialStateForExternalReducer
}

export default rootReducer
